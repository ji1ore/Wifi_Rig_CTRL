import SwiftUI
import Foundation

// MARK: - Data model

struct Ft8Msg: Identifiable {
    let id = UUID()
    let freq: Int
    let snr: Int
    let dt: Double
    let msg: String
    let utcSec: Int
    let period: Int
    var isTx: Bool = false
    var epochMs: Double

    static func utcSecToEpochMs(_ utcSec: Int) -> Double {
        let nowMs = Date().timeIntervalSince1970 * 1000
        let nowUtcSec = Int(nowMs / 1000) % 60
        let secAgo = ((nowUtcSec - utcSec) + 60) % 60
        return nowMs - Double(secAgo) * 1000
    }
}

enum Ft8TxState { case off, auto, cqAuto }

struct QsoStartData {
    var candidates: [String]
    var myCall: String
    var myGrid: String
    var defaultTxMode: String
    var snrFromMsg: String
    var dxFreqHz: Int
}

private struct WfMarker {
    var rowsFromBottom: Int
    let label: String
}

// MARK: - Waterfall Canvas

private struct WaterfallCanvas: View {
    let rows: [[UInt8]]
    let markers: [WfMarker]
    let txFreqHz: Int
    let maxAudioHz: Int
    let brightness: Float
    var onFreqTap: ((Int) -> Void)?

    var body: some View {
        GeometryReader { geo in
            Canvas { ctx, size in
                let w = size.width
                let n = rows.count
                guard n > 0 else { return }
                let rowH = size.height / CGFloat(n)

                for (ri, row) in rows.reversed().enumerated() {
                    let nBins = row.count
                    guard nBins > 0 else { continue }
                    let y = size.height - CGFloat(ri + 1) * rowH
                    let binW = w / CGFloat(nBins)
                    for bi in 0..<nBins {
                        let v = min(Float(row[bi]) / 255.0 * brightness, 1.0)
                        ctx.fill(
                            Path(CGRect(x: CGFloat(bi) * binW, y: y,
                                        width: binW + 0.5, height: rowH + 0.5)),
                            with: .color(spectrumColor(v))
                        )
                    }
                }

                // TX freq marker
                if maxAudioHz > 0 {
                    let x = CGFloat(txFreqHz) / CGFloat(maxAudioHz) * w
                    ctx.stroke(
                        Path { p in p.move(to: .init(x: x, y: 0)); p.addLine(to: .init(x: x, y: size.height)) },
                        with: .color(.orange), lineWidth: 2
                    )
                }

                // Period markers
                for m in markers {
                    let y = size.height - CGFloat(m.rowsFromBottom) * rowH
                    guard y >= 0 && y <= size.height else { continue }
                    ctx.stroke(
                        Path { p in p.move(to: .init(x: 0, y: y)); p.addLine(to: .init(x: w, y: y)) },
                        with: .color(.white.opacity(0.5)), lineWidth: 0.5
                    )
                    ctx.draw(
                        Text(m.label).font(.system(size: 7, design: .monospaced)).foregroundColor(.white.opacity(0.85)),
                        at: .init(x: 2, y: y + 2), anchor: .topLeading
                    )
                }
            }
            .background(Color.black)
            .contentShape(Rectangle())
            .onTapGesture { loc in
                guard maxAudioHz > 0 else { return }
                let hz = Int(loc.x / geo.size.width * CGFloat(maxAudioHz))
                onFreqTap?(max(100, min(hz, 2900)))
            }
        }
    }

    private func spectrumColor(_ v: Float) -> Color {
        switch v {
        case ..<0.2: return Color(red: 0, green: 0, blue: Double(v / 0.2))
        case ..<0.4: let t = Double((v - 0.2) / 0.2); return Color(red: 0, green: t, blue: 1)
        case ..<0.6: let t = Double((v - 0.4) / 0.2); return Color(red: 0, green: 1, blue: 1 - t)
        case ..<0.8: let t = Double((v - 0.6) / 0.2); return Color(red: t, green: 1, blue: 0)
        default:     let t = Double((v - 0.8) / 0.2); return Color(red: 1, green: 1 - t, blue: 0)
        }
    }
}

// MARK: - Main view

struct Ft8View: View {
    @Bindable var vm: MainViewModel

    // SSE tasks
    @State private var sseTask: Task<Void, Never>?
    @State private var spectrumTask: Task<Void, Never>?

    // Messages
    @State private var rxMsgs: [Ft8Msg] = []
    @State private var txMsgs: [Ft8Msg] = []
    @State private var pendingTxEpochMs: Double = -1
    @State private var lastMsgId: UUID? = nil

    // Waterfall
    @State private var wfRows: [[UInt8]] = []
    @State private var wfMarkers: [WfMarker] = []
    @State private var wfBrightness: Float = 1.0
    @State private var markedUtcSecs: Set<Int> = []

    // TX state
    @State private var txState: Ft8TxState = .off
    @State private var txMsg: String = ""
    @State private var txFreqHz: Int = 1500
    @State private var autoTxMode: String = "even"
    @State private var filterEnabled: Bool = false
    @State private var filterDxFreq: Int = 0
    @State private var decodeDepth: Int = 1
    @State private var isFt4: Bool = false
    @State private var qsoLogSaved: Bool = false

    // Status
    @State private var statusText: String = "---"

    // Sheet flags
    @State private var showCallsignSheet = false
    @State private var showQsoStartSheet = false
    @State private var showQsoLogSheet = false
    @State private var showTxFreqSheet = false
    @State private var showFreqPicker = false
    @State private var showPowerPicker = false
    @State private var qsoStartData: QsoStartData? = nil
    @State private var txFreqInput: String = ""
    @State private var showDebugAlert = false
    @State private var debugText = ""

    private let powerSteps: [Double] = [0.05,0.10,0.20,0.30,0.40,0.50,0.60,0.70,0.80,0.90,1.00]

    private func powerButton(_ v: Double) -> some View {
        Button("\(Int(v * 100))%") { Task { await vm.setPower(v) } }
    }
    private let ft8Bands: [(label: String, hz: Int64)] = [
        ("160m  1.840 MHz",        1_840_000),
        ("160m  1.908 MHz (JA)",   1_908_000),
        ("80m   3.573 MHz",        3_573_000),
        ("80m   3.531 MHz (JA)",   3_531_000),
        ("40m   7.074 MHz",        7_074_000),
        ("40m   7.041 MHz (JA)",   7_041_000),
        ("30m  10.136 MHz",       10_136_000),
        ("20m  14.074 MHz",       14_074_000),
        ("17m  18.100 MHz",       18_100_000),
        ("15m  21.074 MHz",       21_074_000),
        ("12m  24.915 MHz",       24_915_000),
        ("10m  28.074 MHz",       28_074_000),
        ("6m   50.313 MHz",       50_313_000),
        ("2m  144.174 MHz",      144_174_000),
        ("2m  144.060 MHz (JA)", 144_060_000),
        ("70cm 430.510 MHz (JA)", 430_510_000),
        ("70cm 432.174 MHz",      432_174_000),
    ]

    // MARK: Body

    var body: some View {
        VStack(spacing: 0) {
            topBar
            WaterfallCanvas(rows: wfRows, markers: wfMarkers,
                            txFreqHz: txFreqHz, maxAudioHz: 3000,
                            brightness: wfBrightness) { hz in
                txFreqHz = hz
                vm.ft8AudioFreqHz = hz
                vm.persistFt8Settings()
            }
            .frame(height: 120)
            msgListView
            statusBarView
            txControlsView
        }
        .background(Color.black)
        .navigationBarHidden(true)
        .onAppear { onViewAppear() }
        .onDisappear { onViewDisappear() }
        .sheet(isPresented: $showCallsignSheet) { callsignSheetView }
        .sheet(isPresented: $showQsoStartSheet) {
            if let data = qsoStartData {
                QsoStartSheet(data: data,
                              onStart: handleQsoStart,
                              onLog:   handleQsoLog)
            }
        }
        .sheet(isPresented: $showQsoLogSheet) { qsoLogSheetView }
        .sheet(isPresented: $showTxFreqSheet) { txFreqSheetView }
        .confirmationDialog("FT8 Band", isPresented: $showFreqPicker, titleVisibility: .visible) {
            ForEach(ft8Bands, id: \.hz) { b in
                Button(b.label) { selectBand(b.hz) }
            }
            Button("Cancel", role: .cancel) {}
        }
        .confirmationDialog("Power", isPresented: $showPowerPicker, titleVisibility: .visible) {
            ForEach(powerSteps, id: \.self) { v in powerButton(v) }
            Button("Cancel", role: .cancel) {}
        }
        .alert("jt9 decode debug", isPresented: $showDebugAlert) {
            Button("OK", role: .cancel) {}
        } message: { Text(debugText) }
    }

    // MARK: - Top bar

    private var topBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6) {
                Button { vm.path.removeLast() } label: {
                    Image(systemName: "chevron.left").font(.caption.bold())
                }
                Button {
                    isFt4.toggle()
                    vm.ft8IsFt4 = isFt4
                    vm.persistFt8Settings()
                } label: {
                    Text("FT4")
                        .font(.caption.bold())
                        .foregroundStyle(isFt4 ? .white : .secondary)
                        .padding(.horizontal, 6).padding(.vertical, 3)
                        .background(isFt4 ? Color.blue : Color.gray.opacity(0.3), in: Capsule())
                }
                Button {
                    let next = vm.ft8TxMode == "USB" ? "PKTUSB" : "USB"
                    vm.ft8TxMode = next
                    Task { await vm.setMode(next, width: 3000) }
                } label: {
                    Text(vm.ft8TxMode == "PKTUSB" ? "PKT" : vm.ft8TxMode)
                        .font(.caption.monospacedDigit())
                }
                Button { showPowerPicker = true } label: {
                    Text("PWR \(Int(vm.sharedPower * 100))")
                        .font(.caption.monospacedDigit())
                }
                Button { showFreqPicker = true } label: {
                    Text(vm.sharedFreq <= 0 ? "--.-"
                         : String(format: "%.3f", Double(vm.sharedFreq) / 1_000_000.0))
                        .font(.caption.monospacedDigit())
                }
                Divider().frame(height: 16)
                // Depth cycle: 1→2→3→1
                Button {
                    decodeDepth = decodeDepth % 3 + 1
                    vm.ft8DecodeDepth = decodeDepth
                    vm.persistFt8Settings()
                    Task { try? await vm.ft8SetDepth(decodeDepth) }
                } label: {
                    Text("D:\(decodeDepth)").font(.caption.monospacedDigit())
                }
                // Filter toggle
                Button {
                    filterEnabled.toggle()
                    vm.ft8Filter = filterEnabled
                    vm.persistFt8Settings()
                    if !filterEnabled {
                        filterDxFreq = 0
                        Task { try? await vm.ft8SetDecodeFilter(freqs: [], bw: 150) }
                    } else if filterDxFreq > 0 {
                        let f = filterDxFreq
                        Task { try? await vm.ft8SetDecodeFilter(freqs: [f], bw: 150) }
                    }
                } label: {
                    Text("FILTER")
                        .font(.caption.bold())
                        .foregroundStyle(filterEnabled ? .white : .secondary)
                        .padding(.horizontal, 6).padding(.vertical, 3)
                        .background(filterEnabled ? Color.indigo : Color.gray.opacity(0.3), in: Capsule())
                }
                Divider().frame(height: 16)
                // Brightness
                Button {
                    wfBrightness = max(0.2, wfBrightness - 0.2)
                } label: { Image(systemName: "sun.min").font(.caption) }
                Button {
                    wfBrightness = min(4.0, wfBrightness + 0.2)
                } label: { Image(systemName: "sun.max").font(.caption) }
                Divider().frame(height: 16)
                // Sync
                Button {
                    Task { await syncTime() }
                } label: {
                    Image(systemName: "clock.arrow.2.circlepath").font(.caption)
                }
                // PSK Reporter
                Button {
                    showPskReporter()
                } label: {
                    Text("GL").font(.caption.bold())
                }
                // QSO Log
                Button { showQsoLogSheet = true } label: {
                    Image(systemName: "list.bullet").font(.caption)
                }
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 7)
        }
        .background(Color(.secondarySystemBackground))
    }

    // MARK: - Message list

    private var msgListView: some View {
        let combined = combinedMsgs
        return ScrollViewReader { proxy in
            List(combined) { item in
                msgRow(item)
                    .listRowBackground(rowBackground(item))
                    .listRowInsets(EdgeInsets(top: 1, leading: 6, bottom: 1, trailing: 6))
                    .onTapGesture { if !item.isTx { onMsgTapped(item) } }
            }
            .listStyle(.plain)
            .environment(\.defaultMinListRowHeight, 20)
            .onChange(of: combined.last?.id) { _, id in
                if let id { withAnimation { proxy.scrollTo(id, anchor: .bottom) } }
            }
        }
    }

    private var combinedMsgs: [Ft8Msg] {
        let rx = filterEnabled && filterDxFreq > 0
            ? rxMsgs.filter { abs($0.freq - filterDxFreq) <= 150 }
            : rxMsgs
        return (rx + txMsgs).sorted { $0.epochMs < $1.epochMs }
    }

    @ViewBuilder
    private func msgRow(_ item: Ft8Msg) -> some View {
        let timeStr: String = {
            let date = Date(timeIntervalSince1970: item.epochMs / 1000)
            let fmt = DateFormatter()
            fmt.dateFormat = "HH:mm:ss"
            fmt.timeZone = TimeZone(identifier: "UTC")
            return fmt.string(from: date)
        }()
        let isEven = item.utcSec % 30 == 0

        if item.isTx {
            HStack(spacing: 4) {
                Text(timeStr).font(.system(size: 10, design: .monospaced))
                    .foregroundStyle(isEven ? Color(hex: 0x88AAFF) : Color(hex: 0x88FF44))
                Text("TX▶").font(.system(size: 10, design: .monospaced))
                    .foregroundStyle(Color(hex: 0xFF6622))
                Text(item.msg).font(.system(size: 10, design: .monospaced))
                    .foregroundStyle(Color(hex: 0xFF9944))
                Spacer()
            }
        } else {
            let myCall = vm.ft8MyCall.uppercased()
            let parts = item.msg.trimmingCharacters(in: .whitespaces).uppercased()
                .components(separatedBy: .whitespaces).filter { !$0.isEmpty }
            let isToMe = !myCall.isEmpty && parts.first == myCall
            let isCq   = item.msg.hasPrefix("CQ ")
            let snrStr = item.snr >= 0 ? "+\(item.snr)" : "\(item.snr)"
            HStack(spacing: 4) {
                Text(timeStr).font(.system(size: 10, design: .monospaced))
                    .foregroundStyle(isEven ? Color(hex: 0x88AAFF) : Color(hex: 0x88FF44))
                Text(String(format: "%4d", item.freq)).font(.system(size: 10, design: .monospaced))
                    .foregroundStyle(isToMe ? Color(hex: 0xFFDD44) : Color(hex: 0xAAAAAA))
                Text(String(format: "%4s", snrStr)).font(.system(size: 10, design: .monospaced))
                    .foregroundStyle(Color(hex: 0x888888))
                Text(item.msg).font(.system(size: 10, design: .monospaced))
                    .foregroundStyle(isToMe ? Color(hex: 0xFFFF00)
                                    : isCq   ? Color(hex: 0x88FF88)
                                    :           Color(hex: 0xCCCCCC))
                Spacer()
            }
        }
    }

    private func rowBackground(_ item: Ft8Msg) -> Color {
        if item.isTx { return Color(hex: 0x2A1400) }
        let myCall = vm.ft8MyCall.uppercased()
        let parts = item.msg.trimmingCharacters(in: .whitespaces).uppercased()
            .components(separatedBy: .whitespaces).filter { !$0.isEmpty }
        let isToMe = !myCall.isEmpty && parts.first == myCall
        let isCq   = item.msg.hasPrefix("CQ ")
        if isToMe { return Color(hex: 0x1A1A00) }
        if isCq   { return Color(hex: 0x1A2C1A) }
        return Color(hex: 0x0A0A0A)
    }

    // MARK: - Status bar

    private var statusBarView: some View {
        HStack {
            Text(vm.sharedMode.isEmpty ? "---" : vm.sharedMode)
                .font(.system(size: 11, design: .monospaced)).foregroundStyle(.secondary)
            Spacer()
            Text(statusText)
                .font(.system(size: 11, design: .monospaced)).foregroundStyle(.primary)
                .lineLimit(1).truncationMode(.tail)
            Spacer()
            Text(vm.sharedFreq <= 0 ? "---.--- MHz"
                 : String(format: "%.3f MHz", Double(vm.sharedFreq) / 1_000_000.0))
                .font(.system(size: 11, design: .monospaced)).foregroundStyle(.secondary)
        }
        .padding(.horizontal, 8).padding(.vertical, 4)
        .background(Color(.secondarySystemBackground))
    }

    // MARK: - TX controls

    private var txControlsView: some View {
        VStack(spacing: 4) {
            // TX message field
            HStack(spacing: 6) {
                // CQ quick-fill; long-press → callsign dialog
                Button { fillCqMsg() } label: {
                    Text("CQ").font(.caption.bold())
                        .frame(minWidth: 36).padding(.vertical, 5)
                        .background(Color(.systemGray5), in: RoundedRectangle(cornerRadius: 6))
                }
                .simultaneousGesture(LongPressGesture().onEnded { _ in showCallsignSheet = true })

                TextField("TX message", text: $txMsg)
                    .font(.system(size: 12, design: .monospaced))
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.characters)
                    .padding(.horizontal, 6).padding(.vertical, 4)
                    .background(Color(.systemGray6), in: RoundedRectangle(cornerRadius: 6))

                // TX freq
                Button { showTxFreqSheet = true } label: {
                    Text("TX:\(txFreqHz)").font(.caption.monospacedDigit())
                        .frame(minWidth: 54).padding(.vertical, 5)
                        .background(Color(.systemGray5), in: RoundedRectangle(cornerRadius: 6))
                }
            }
            .padding(.horizontal, 8)

            // TX action row
            HStack(spacing: 6) {
                // EVEN/ODD toggle
                Button {
                    autoTxMode = autoTxMode == "even" ? "odd" : "even"
                    vm.ft8AutoTxMode = autoTxMode
                    vm.persistFt8Settings()
                    if txState == .auto {
                        let m = txMsg; let hz = txFreqHz; let mode = autoTxMode
                        Task { try? await vm.ft8SetAutoTx(active: true, mode: mode, msg: m, audioFreqHz: hz) }
                    }
                } label: {
                    let isEven = autoTxMode == "even"
                    Text(isEven ? "EVEN" : "ODD ")
                        .font(.caption.bold().monospacedDigit())
                        .foregroundStyle(isEven ? Color(hex: 0x88AAFF) : Color(hex: 0x88FF44))
                        .frame(minWidth: 44).padding(.vertical, 5)
                        .background(isEven ? Color(hex: 0x1A237E) : Color(hex: 0x1A3700),
                                    in: RoundedRectangle(cornerRadius: 6))
                }

                Spacer()

                // Clear
                Button {
                    rxMsgs.removeAll(); txMsgs.removeAll()
                    statusText = "---"
                } label: {
                    Text("CLR").font(.caption)
                        .frame(minWidth: 36).padding(.vertical, 5)
                        .background(Color(.systemGray5), in: RoundedRectangle(cornerRadius: 6))
                }
                .simultaneousGesture(LongPressGesture().onEnded { _ in
                    Task {
                        let info = (try? await vm.ft8DecodeDebug()) ?? "—"
                        await MainActor.run { debugText = info; showDebugAlert = true }
                    }
                })

                // TX / AUTO / CQ AUTO button
                // Short press: AUTO/CQ_AUTO → OFF
                // Long press:  OFF → CQ AUTO
                Button { handleTxButtonTap() } label: {
                    txButtonLabel
                }
                .simultaneousGesture(LongPressGesture(minimumDuration: 0.6).onEnded { _ in
                    handleTxButtonLongPress()
                })
            }
            .padding(.horizontal, 8)
            .padding(.bottom, 6)
        }
        .background(Color(.secondarySystemBackground))
    }

    private var txButtonLabel: some View {
        let (label, bg, fg): (String, Color, Color) = {
            switch txState {
            case .off:    return ("TX",       Color(hex: 0x546E7A), Color(hex: 0xAAAAAA))
            case .auto:   return ("AUTO",     Color(hex: 0xB71C1C), .white)
            case .cqAuto: return ("CQ AUTO",  Color(hex: 0xE65100), .white)
            }
        }()
        return Text(label)
            .font(.caption.bold())
            .foregroundStyle(fg)
            .frame(minWidth: 68).padding(.vertical, 5)
            .background(bg, in: RoundedRectangle(cornerRadius: 6))
    }

    // MARK: - TX Freq sheet

    private var txFreqSheetView: some View {
        NavigationStack {
            Form {
                Section(header: Text("TX Audio Frequency (Hz)  100–2900")) {
                    TextField("1500", text: $txFreqInput)
                        .keyboardType(.numberPad)
                        .font(.title2.monospacedDigit())
                }
            }
            .navigationTitle("TX Freq")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { showTxFreqSheet = false }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("OK") {
                        if let hz = Int(txFreqInput) {
                            txFreqHz = max(100, min(hz, 2900))
                            vm.ft8AudioFreqHz = txFreqHz
                            vm.persistFt8Settings()
                        }
                        showTxFreqSheet = false
                    }
                }
            }
            .onAppear { txFreqInput = "\(txFreqHz)" }
        }
        .presentationDetents([.height(200)])
    }

    // MARK: - Callsign sheet

    private var callsignSheetView: some View {
        NavigationStack {
            Form {
                Section(header: Text("My Station")) {
                    LabeledContent("Callsign") {
                        TextField("JA1XXX", text: $vm.ft8MyCall)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .multilineTextAlignment(.trailing)
                    }
                    LabeledContent("Grid") {
                        TextField("PM85", text: $vm.ft8MyGrid)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .multilineTextAlignment(.trailing)
                    }
                }
                Section {
                    Button("Get Grid from GPS") { applyGridFromGps(); showCallsignSheet = false }
                }
            }
            .navigationTitle("Callsign / Grid")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") {
                        vm.ft8MyCall = vm.ft8MyCall.uppercased()
                        vm.ft8MyGrid = vm.ft8MyGrid.uppercased()
                        vm.persistFt8Settings()
                        showCallsignSheet = false
                    }
                }
            }
        }
        .presentationDetents([.medium])
    }

    // MARK: - QSO Log sheet

    private var qsoLogSheetView: some View {
        NavigationStack {
            let entries = loadQsoLog()
            Group {
                if entries.isEmpty {
                    Text("No QSOs logged yet.")
                        .foregroundStyle(.secondary).padding()
                } else {
                    List(entries.indices, id: \.self) { i in
                        let e = entries[i]
                        VStack(alignment: .leading, spacing: 2) {
                            HStack {
                                Text(e.call).font(.system(size: 13, design: .monospaced).bold())
                                Spacer()
                                Text(freqToBand(e.freq)).font(.caption).foregroundStyle(.secondary)
                                Text(e.mode).font(.caption).foregroundStyle(.secondary)
                            }
                            Text("\(formatDt(e.dt))  RST S:\(e.rstS) R:\(e.rstR)")
                                .font(.system(size: 10, design: .monospaced))
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .navigationTitle("QSO Log (\(entries.count))")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { showQsoLogSheet = false }
                }
                ToolbarItem(placement: .primaryAction) {
                    Menu {
                        Button("Export ADIF") { exportAdif(entries) }
                        Button("Clear Log", role: .destructive) {
                            vm.ft8QsoLog = "[]"
                            vm.persistFt8Settings()
                        }
                    } label: { Image(systemName: "ellipsis.circle") }
                }
            }
        }
    }

    // MARK: - Actions

    private func onViewAppear() {
        vm.captureFt8RestorePoint()
        isFt4 = vm.ft8IsFt4
        txFreqHz = vm.ft8AudioFreqHz > 0 ? vm.ft8AudioFreqHz : 1500
        decodeDepth = vm.ft8DecodeDepth > 0 ? vm.ft8DecodeDepth : 1
        autoTxMode = vm.ft8AutoTxMode
        filterEnabled = vm.ft8Filter
        UIApplication.shared.isIdleTimerDisabled = true

        Task {
            await vm.audioRxStopIfRunning()
            await vm.enterFt8Mode()
            try? await vm.ft8Start()
        }
        startMsgSse()
        startSpectrumSse()
    }

    private func onViewDisappear() {
        sseTask?.cancel()
        spectrumTask?.cancel()
        UIApplication.shared.isIdleTimerDisabled = false
        if txState == .auto {
            let mode = autoTxMode; let hz = txFreqHz
            Task { try? await vm.ft8SetAutoTx(active: false, mode: mode, msg: "", audioFreqHz: hz) }
        }
        if txState == .cqAuto {
            let mode = autoTxMode; let hz = txFreqHz
            Task { try? await vm.ft8CqAuto(active: false, msg: "", mode: mode, audioFreqHz: hz, myCall: "", myGrid: "") }
        }
        Task {
            try? await vm.ft8CancelQso()
            await vm.exitFt8Mode()
        }
        vm.applyWakeLock()
    }

    private func selectBand(_ hz: Int64) {
        vm.ft8LastFreq = hz
        Task { await vm.setFreq(hz) }
    }

    private func fillCqMsg() {
        let call = vm.ft8MyCall
        let grid = vm.ft8MyGrid
        if call.isEmpty { showCallsignSheet = true; return }
        txMsg = "CQ \(call) \(String(grid.prefix(4)))".trimmingCharacters(in: .whitespaces)
    }

    private func handleTxButtonTap() {
        switch txState {
        case .auto:
            txState = .off
            removePendingTx()
            let mode = autoTxMode; let hz = txFreqHz
            Task { try? await vm.ft8SetAutoTx(active: false, mode: mode, msg: "", audioFreqHz: hz) }
        case .cqAuto:
            txState = .off
            removePendingTx()
            let mode = autoTxMode; let hz = txFreqHz
            Task { try? await vm.ft8CqAuto(active: false, msg: "", mode: mode, audioFreqHz: hz, myCall: "", myGrid: "") }
        case .off:
            break
        }
    }

    private func handleTxButtonLongPress() {
        guard txState == .off else { return }
        let msg = txMsg.trimmingCharacters(in: .whitespaces)
        if msg.isEmpty { statusText = "Enter a message in the TX field"; return }
        let myCall = vm.ft8MyCall; let myGrid = vm.ft8MyGrid
        if myCall.isEmpty { showCallsignSheet = true; return }
        txState = .cqAuto
        let mode = autoTxMode; let hz = txFreqHz
        Task { try? await vm.ft8CqAuto(active: true, msg: msg, mode: mode, audioFreqHz: hz, myCall: myCall, myGrid: myGrid) }
    }

    private func removePendingTx() {
        guard pendingTxEpochMs >= 0 else { return }
        let ms = pendingTxEpochMs
        pendingTxEpochMs = -1
        txMsgs.removeAll { $0.isTx && $0.epochMs == ms }
    }

    private func syncTime() async {
        statusText = "Syncing time..."
        guard let offset = try? await vm.syncFt8Clock() else {
            statusText = "Time sync error"; return
        }
        statusText = "Synced drift=\(offset)ms — restarting..."
        try? await Task.sleep(nanoseconds: 300_000_000)
        try? await vm.ft8Stop()
        try? await Task.sleep(nanoseconds: 500_000_000)
        try? await vm.ft8Start()
        statusText = "Synced drift=\(offset)ms — FT8 restarted"
    }

    private func applyGridFromGps() {
        vm.requestLocationAuthorization()
        guard let fix = vm.currentLocationFix() else { statusText = "No GPS fix"; return }
        let grid = MainViewModel.latLonToGrid(lat: fix.lat, lon: fix.lon)
        vm.ft8MyGrid = grid
        vm.persistFt8Settings()
    }

    private func showPskReporter() {
        let myCall = vm.ft8MyCall
        let freqHz = vm.sharedFreq
        let bandMhz = bandMhzFor(freqHz)
        var urlStr = "https://pskreporter.info/pskmap.html?"
        if !myCall.isEmpty { urlStr += "callsign=\(myCall)&" }
        if bandMhz > 0 { urlStr += "band=\(bandMhz)&" }
        urlStr += "mode=FT8"
        if let url = URL(string: urlStr) { UIApplication.shared.open(url) }
    }

    private func bandMhzFor(_ hz: Int64) -> Int {
        switch hz {
        case 1_800_000..<2_000_000:   return 1
        case 3_500_000..<4_000_000:   return 3
        case 7_000_000..<7_300_000:   return 7
        case 10_100_000..<10_150_000: return 10
        case 14_000_000..<14_350_000: return 14
        case 18_068_000..<18_168_000: return 18
        case 21_000_000..<21_450_000: return 21
        case 24_890_000..<24_990_000: return 24
        case 28_000_000..<29_700_000: return 28
        case 50_000_000..<54_000_000: return 50
        case 144_000_000..<148_000_000: return 144
        case 430_000_000..<440_000_000: return 430
        default: return 0
        }
    }

    // MARK: - QSO start handling

    private func onMsgTapped(_ item: Ft8Msg) {
        let myCall = vm.ft8MyCall.isEmpty ? "" : vm.ft8MyCall.uppercased()
        guard !myCall.isEmpty else { showCallsignSheet = true; return }
        let myGrid = vm.ft8MyGrid.uppercased()
        let parts = item.msg.trimmingCharacters(in: .whitespaces).uppercased()
            .components(separatedBy: .whitespaces).filter { !$0.isEmpty }
        let searchParts = parts.count >= 3 ? Array(parts.dropLast()) : parts
        let candidates = extractCallsigns(searchParts).filter { $0 != myCall }
        guard !candidates.isEmpty else { return }
        let snrStr = item.snr >= 0 ? "+\(item.snr)" : "\(item.snr)"
        let txMode = (item.utcSec % 30 == 0) ? "odd" : "even"
        qsoStartData = QsoStartData(candidates: candidates, myCall: myCall, myGrid: myGrid,
                                    defaultTxMode: txMode, snrFromMsg: snrStr, dxFreqHz: item.freq)
        showQsoStartSheet = true
    }

    private func extractCallsigns(_ parts: [String]) -> [String] {
        let keywords: Set<String> = ["CQ","DX","RR73","RRR","73","DE","QRZ","TU","TNX"]
        return parts.filter { t in
            t.count >= 3 && t.count <= 13 &&
            t.first?.isLetter == true &&
            !keywords.contains(t) &&
            !t.matches(pattern: "^[+-]\\d{1,3}$") &&
            !t.matches(pattern: "^R[+-]\\d{1,3}$") &&
            !t.matches(pattern: "^[A-Z]{2}\\d{2}([A-Z]{2})?$") &&
            t.contains(where: \.isNumber) &&
            t.contains(where: \.isLetter)
        }
    }

    private func handleQsoStart(_ result: QsoStartResult) {
        autoTxMode = result.txMode
        vm.ft8AutoTxMode = result.txMode
        txState = .auto
        qsoLogSaved = false
        txMsg = result.firstMsg
        statusText = "QSO start: \(result.dxCall)"
        if result.dxFreqHz > 0 {
            filterDxFreq = result.dxFreqHz
            let f = result.dxFreqHz
            Task { try? await vm.ft8SetDecodeFilter(freqs: [f], bw: 150) }
        }
        let r = result
        Task {
            try? await vm.ft8StartQso(
                firstMsg: r.msg1, dxCall: r.dxCall, myCall: r.myCall,
                txMode: r.txMode, audioFreqHz: txFreqHz,
                initialState: r.initialState,
                step2Msg: r.msg2, step3Msg: r.msg3, step4Msg: r.msg4)
        }
    }

    private func handleQsoLog(_ entry: QsoLogParams) {
        saveQsoLogEntry(dxCall: entry.dxCall, myCall: entry.myCall,
                        snrRcvd: entry.snrRcvd, snrSent: entry.snrSent)
    }

    // MARK: - SSE

    private func startMsgSse() {
        sseTask?.cancel()
        sseTask = Task { await connectMsgSse() }
    }

    private func connectMsgSse() async {
        await MainActor.run { statusText = "RX: connecting..." }
        let sseConfig = URLSessionConfiguration.default
        sseConfig.timeoutIntervalForRequest = 15
        sseConfig.timeoutIntervalForResource = 86400
        let session = URLSession(configuration: sseConfig)

        while !Task.isCancelled {
            guard let req = await vm.makeFt8SseRequest(path: "/ft8/rx_msgs") else {
                try? await Task.sleep(nanoseconds: 3_000_000_000); continue
            }
            do {
                let (bytes, resp) = try await session.bytes(for: req)
                guard let httpResp = resp as? HTTPURLResponse,
                      (200..<300).contains(httpResp.statusCode) else {
                    await MainActor.run { statusText = "RX: HTTP error" }
                    try? await Task.sleep(nanoseconds: 5_000_000_000); continue
                }
                await MainActor.run { statusText = "RX: connected" }
                try? await vm.ft8SetDepth(decodeDepth)
                let syncFreq = await MainActor.run { filterEnabled && filterDxFreq > 0 ? filterDxFreq : 0 }
                if syncFreq > 0 { try? await vm.ft8SetDecodeFilter(freqs: [syncFreq], bw: 150) }
                else            { try? await vm.ft8SetDecodeFilter(freqs: [], bw: 150) }
                for try await line in bytes.lines {
                    guard !Task.isCancelled else { break }
                    if line.hasPrefix("data: ") {
                        await parseSseLine(String(line.dropFirst(6)))
                    }
                }
            } catch {
                if Task.isCancelled { break }
            }
            if !Task.isCancelled {
                await MainActor.run { statusText = "RX: reconnecting..." }
                try? await Task.sleep(nanoseconds: 3_000_000_000)
            }
        }
    }

    private func startSpectrumSse() {
        spectrumTask?.cancel()
        spectrumTask = Task { await connectSpectrumSse() }
    }

    private func connectSpectrumSse() async {
        let sseConfig = URLSessionConfiguration.default
        sseConfig.timeoutIntervalForRequest = 15
        sseConfig.timeoutIntervalForResource = 86400
        let session = URLSession(configuration: sseConfig)

        while !Task.isCancelled {
            guard let req = await vm.makeFt8SseRequest(path: "/ft8/spectrum") else {
                try? await Task.sleep(nanoseconds: 3_000_000_000); continue
            }
            do {
                let (bytes, resp) = try await session.bytes(for: req)
                guard let httpResp = resp as? HTTPURLResponse,
                      (200..<300).contains(httpResp.statusCode) else {
                    try? await Task.sleep(nanoseconds: 5_000_000_000); continue
                }
                for try await line in bytes.lines {
                    guard !Task.isCancelled else { break }
                    if line.hasPrefix("data: ") {
                        await parseSpectrumLine(String(line.dropFirst(6)))
                    }
                }
            } catch {
                if Task.isCancelled { break }
            }
            if !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 3_000_000_000)
            }
        }
    }

    @MainActor
    private func parseSseLine(_ json: String) {
        guard let data = json.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return }
        let type = obj["type"] as? String ?? ""
        switch type {
        case "decode":
            let period  = obj["period"] as? Int ?? 0
            let utcSec  = obj["utc_sec"] as? Int ?? 0
            guard let msgs = obj["msgs"] as? [[String: Any]] else { return }
            let rxEpochMs = Ft8Msg.utcSecToEpochMs(utcSec)
            let newItems = msgs.map { m in
                Ft8Msg(freq: m["freq"] as? Int ?? 0,
                       snr:  m["snr"]  as? Int ?? 0,
                       dt:   m["dt"]   as? Double ?? 0,
                       msg:  m["msg"]  as? String ?? "",
                       utcSec: utcSec, period: period,
                       epochMs: rxEpochMs)
            }
            rxMsgs.append(contentsOf: newItems)
            rxMsgs.sort { $0.epochMs < $1.epochMs }
            if rxMsgs.count > 200 { rxMsgs.removeFirst(rxMsgs.count - 200) }
            statusText = "P\(period) | \(utcSec)s | \(newItems.count) decoded"
            if markedUtcSecs.insert(utcSec).inserted {
                if markedUtcSecs.count > 8 { markedUtcSecs.removeFirst() }
                var utcCal = Calendar(identifier: .gregorian)
                utcCal.timeZone = TimeZone(identifier: "UTC")!
                let comps = utcCal.dateComponents([.hour, .minute], from: Date())
                let hhmm = String(format: "%02d:%02d", comps.hour ?? 0, comps.minute ?? 0)
                wfMarkers.append(WfMarker(rowsFromBottom: 1, label: "\(hhmm) P\(period)"))
                if wfMarkers.count > 8 { wfMarkers.removeFirst() }
            }

        case "tx_pending":
            let txMsgStr  = obj["msg"] as? String ?? ""
            let utcAt     = obj["utc_at_tx"] as? Int ?? 0
            let txPeriodSec = ((utcAt + 7) / 15) * 15 % 60
            let txEpochMs = Ft8Msg.utcSecToEpochMs(txPeriodSec)
            if !txMsgStr.isEmpty {
                txMsgs.append(Ft8Msg(freq: 0, snr: 0, dt: 0, msg: txMsgStr,
                                     utcSec: txPeriodSec, period: -1, isTx: true, epochMs: txEpochMs))
                if txMsgs.count > 20 { txMsgs.removeFirst() }
                pendingTxEpochMs = txEpochMs
            }
            statusText = "TX▶ \(txMsgStr)"

        case "auto_tx_sent":
            pendingTxEpochMs = -1
            let msg = obj["msg"] as? String ?? ""
            statusText = "AutoTX done: \(msg)"

        case "auto_tx_error":
            let err = obj["error"] as? String ?? ""
            removePendingTx()
            statusText = "AutoTX error: \(err)"

        case "tx_scheduled":
            let txMsgStr = obj["msg"] as? String ?? ""
            let waitSec  = obj["wait_sec"] as? Double ?? 0
            let utcAt    = obj["utc_at_tx"] as? Int ?? 0
            let periodSec = ((utcAt + 7) / 15) * 15 % 60
            statusText = "TX waiting \(txMsgStr)  (in \(Int(waitSec))s → UTC \(periodSec)s)"

        case "period_start":
            let utcSecPs = obj["utc_sec"] as? Int ?? 0
            markedUtcSecs.insert(utcSecPs)
            if markedUtcSecs.count > 8 { markedUtcSecs.removeFirst() }

        case "qso_state":
            let state   = obj["state"]    as? String ?? ""
            let msg     = obj["msg"]      as? String ?? ""
            let dx      = obj["dx_call"]  as? String ?? ""
            let snr     = obj["snr"]      as? String ?? ""
            let txMode  = obj["tx_mode"]  as? String ?? ""
            let snrRcvd = obj["snr_rcvd"] as? String ?? ""
            let snrSent = obj["snr_sent"] as? String ?? ""
            let myCall  = (obj["my_call"] as? String ?? "").isEmpty ? vm.ft8MyCall : (obj["my_call"] as? String ?? "")
            statusText = switch state {
                case "pending":    "QSO pending[\(dx)]: \(msg)"
                case "tx_start":   "TX: \(msg)"
                case "got_report": "Report \(snr) rcvd → \(msg)"
                case "sending_73": "RR73 rcvd → sending 73: \(msg)"
                case "retry_rr73": "RR73 retry: \(msg)"
                default:           "QSO: \(msg)"
            }
            if !msg.isEmpty { txMsg = msg }
            if !txMode.isEmpty { autoTxMode = txMode }
            if txState != .auto && txState != .cqAuto { txState = .auto }
            if state == "sending_73" && !dx.isEmpty && !qsoLogSaved {
                qsoLogSaved = true
                saveQsoLogEntry(dxCall: dx, myCall: myCall, snrRcvd: snrRcvd, snrSent: snrSent)
            }

        case "cq_auto_restart":
            let cqMsg = obj["msg"] as? String ?? ""
            if !cqMsg.isEmpty { txMsg = cqMsg }
            txState = .cqAuto
            qsoLogSaved = false
            statusText = "CQ AUTO: \(cqMsg)"

        case "qso_done":
            let dx      = obj["dx_call"]  as? String ?? ""
            let myCall  = (obj["my_call"] as? String ?? "").isEmpty ? vm.ft8MyCall : (obj["my_call"] as? String ?? "")
            let snrRcvd = obj["snr_rcvd"] as? String ?? ""
            let snrSent = obj["snr_sent"] as? String ?? ""
            if txState != .cqAuto { txState = .off }
            statusText = "QSO done! \(dx)"
            if !qsoLogSaved {
                qsoLogSaved = true
                saveQsoLogEntry(dxCall: dx, myCall: myCall, snrRcvd: snrRcvd, snrSent: snrSent)
            }
            filterDxFreq = 0
            Task { try? await vm.ft8SetDecodeFilter(freqs: [], bw: 150) }

        default: break
        }
    }

    @MainActor
    private func parseSpectrumLine(_ json: String) {
        guard let data = json.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let arr = obj["bins"] as? [Int] else { return }
        let bins = arr.map { UInt8(clamping: $0) }
        let isNewPeriod = obj["new_period"] as? Bool ?? false
        let period      = obj["period"] as? Int ?? 0
        let utcSec      = obj["utc_sec"] as? Int ?? 0

        // Each new row pushes all markers upward; drop any that scrolled off the top
        wfMarkers = wfMarkers.compactMap { m in
            let u = WfMarker(rowsFromBottom: m.rowsFromBottom + 1, label: m.label)
            return u.rowsFromBottom < 80 ? u : nil
        }

        if isNewPeriod && markedUtcSecs.insert(utcSec).inserted {
            if markedUtcSecs.count > 8 { markedUtcSecs.removeFirst() }
            var utcCal = Calendar(identifier: .gregorian)
            utcCal.timeZone = TimeZone(identifier: "UTC")!
            let comps = utcCal.dateComponents([.hour, .minute], from: Date())
            let hhmm = String(format: "%02d:%02d", comps.hour ?? 0, comps.minute ?? 0)
            wfMarkers.append(WfMarker(rowsFromBottom: 0, label: "\(hhmm) P\(period)"))
            if wfMarkers.count > 8 { wfMarkers.removeFirst() }
        }

        wfRows.append(bins)
        if wfRows.count > 80 { wfRows.removeFirst() }
    }

    // MARK: - QSO log helpers

    private func saveQsoLogEntry(dxCall: String, myCall: String, snrRcvd: String, snrSent: String) {
        guard !dxCall.isEmpty, !myCall.isEmpty else { return }
        let fmt = DateFormatter()
        fmt.dateFormat = "yyyyMMddHHmmss"
        fmt.timeZone = TimeZone(identifier: "UTC")
        let dt = fmt.string(from: Date())
        let mode = isFt4 ? "FT4" : "FT8"
        var arr = (try? JSONSerialization.jsonObject(with: Data(vm.ft8QsoLog.utf8)) as? [[String: Any]]) ?? []
        arr.append(["dt": dt, "call": dxCall, "freq": vm.sharedFreq, "mode": mode,
                    "rstS": snrSent.isEmpty ? "-00" : snrSent,
                    "rstR": snrRcvd.isEmpty ? "-00" : snrRcvd,
                    "grid": "", "myCall": myCall, "myGrid": vm.ft8MyGrid])
        if let data = try? JSONSerialization.data(withJSONObject: arr),
           let str = String(data: data, encoding: .utf8) {
            vm.ft8QsoLog = str
        }
    }

    private struct LogEntry {
        let dt: String; let call: String; let freq: Int64; let mode: String
        let rstS: String; let rstR: String; let myCall: String; let myGrid: String
    }

    private func loadQsoLog() -> [LogEntry] {
        guard let arr = try? JSONSerialization.jsonObject(with: Data(vm.ft8QsoLog.utf8)) as? [[String: Any]] else { return [] }
        return arr.map { o in
            LogEntry(dt: o["dt"] as? String ?? "", call: o["call"] as? String ?? "",
                     freq: Int64(o["freq"] as? Int ?? 0), mode: o["mode"] as? String ?? "FT8",
                     rstS: o["rstS"] as? String ?? "", rstR: o["rstR"] as? String ?? "",
                     myCall: o["myCall"] as? String ?? "", myGrid: o["myGrid"] as? String ?? "")
        }
    }

    private func formatDt(_ dt: String) -> String {
        guard dt.count >= 14 else { return dt }
        return "\(dt.prefix(4))-\(dt.dropFirst(4).prefix(2))-\(dt.dropFirst(6).prefix(2)) \(dt.dropFirst(8).prefix(2)):\(dt.dropFirst(10).prefix(2))Z"
    }

    private func freqToBand(_ hz: Int64) -> String {
        switch hz {
        case 1_800_000..<2_000_000:   return "160M"
        case 3_500_000..<4_000_000:   return "80M"
        case 7_000_000..<7_300_000:   return "40M"
        case 10_100_000..<10_150_000: return "30M"
        case 14_000_000..<14_350_000: return "20M"
        case 18_068_000..<18_168_000: return "17M"
        case 21_000_000..<21_450_000: return "15M"
        case 24_890_000..<24_990_000: return "12M"
        case 28_000_000..<29_700_000: return "10M"
        case 50_000_000..<54_000_000: return "6M"
        case 144_000_000..<148_000_000: return "2M"
        case 420_000_000..<450_000_000: return "70CM"
        default: return ""
        }
    }

    private func exportAdif(_ entries: [LogEntry]) {
        func f(_ tag: String, _ v: String) -> String {
            v.isEmpty ? "" : "<\(tag):\(v.count)>\(v) "
        }
        var adif = "ADIF Export from Wifi_RIG_CTRL\n<EOH>\n\n"
        for e in entries {
            let freq = e.freq > 0 ? String(format: "%.4f", Double(e.freq) / 1_000_000.0) : ""
            adif += f("CALL",e.call) + f("MODE",e.mode) + f("BAND",freqToBand(e.freq))
            adif += f("FREQ",freq) + f("QSO_DATE",String(e.dt.prefix(8))) + f("TIME_ON",String(e.dt.dropFirst(8).prefix(6)))
            adif += f("RST_SENT",e.rstS) + f("RST_RCVD",e.rstR)
            adif += f("OPERATOR",e.myCall) + f("MY_GRIDSQUARE",e.myGrid)
            adif += "<EOR>\n"
        }
        let fmt = DateFormatter(); fmt.dateFormat = "yyyyMMdd"; fmt.timeZone = TimeZone(identifier: "UTC")
        let fname = "qso_\(fmt.string(from: Date())).adi"
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(fname)
        try? adif.write(to: url, atomically: true, encoding: .utf8)
        let av = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        if let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let vc = scene.windows.first?.rootViewController {
            av.popoverPresentationController?.sourceView = vc.view
            vc.present(av, animated: true)
        }
    }
}

// MARK: - QSO Start Sheet

struct QsoStartResult {
    let dxCall: String; let myCall: String; let txMode: String
    let firstMsg: String; let msg1: String; let msg2: String; let msg3: String; let msg4: String
    let initialState: Int; let dxFreqHz: Int
}

struct QsoLogParams {
    let dxCall: String; let myCall: String; let snrRcvd: String; let snrSent: String
}

struct QsoStartSheet: View {
    let data: QsoStartData
    let onStart: (QsoStartResult) -> Void
    let onLog:   (QsoLogParams) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var selectedDx: String
    @State private var msg1: String; @State private var msg2: String
    @State private var msg3: String; @State private var msg4: String
    @State private var startStep: Int = 1   // 1..4
    @State private var txMode: String

    init(data: QsoStartData, onStart: @escaping (QsoStartResult) -> Void, onLog: @escaping (QsoLogParams) -> Void) {
        self.data = data; self.onStart = onStart; self.onLog = onLog
        let dx = data.candidates.last ?? ""
        _selectedDx = State(initialValue: dx)
        _txMode     = State(initialValue: data.defaultTxMode)
        _msg1 = State(initialValue: "\(dx) \(data.myCall) \(String(data.myGrid.prefix(4)))".trimmingCharacters(in: .whitespaces))
        _msg2 = State(initialValue: "\(dx) \(data.myCall) R\(data.snrFromMsg)".trimmingCharacters(in: .whitespaces))
        _msg3 = State(initialValue: "\(dx) \(data.myCall) RR73")
        _msg4 = State(initialValue: "\(dx) \(data.myCall) 73")
    }

    var body: some View {
        NavigationStack {
            Form {
                if data.candidates.count > 1 {
                    Section(header: Text("DX Station")) {
                        Picker("DX", selection: $selectedDx) {
                            ForEach(data.candidates, id: \.self) { Text($0).tag($0) }
                        }
                        .onChange(of: selectedDx) { _, dx in
                            msg1 = "\(dx) \(data.myCall) \(String(data.myGrid.prefix(4)))".trimmingCharacters(in: .whitespaces)
                            msg2 = "\(dx) \(data.myCall) R\(data.snrFromMsg)".trimmingCharacters(in: .whitespaces)
                            msg3 = "\(dx) \(data.myCall) RR73"
                            msg4 = "\(dx) \(data.myCall) 73"
                        }
                    }
                }
                Section(header: Text("Messages")) {
                    LabeledContent("Step1 (grid)") {
                        TextField("", text: $msg1).multilineTextAlignment(.trailing)
                            .autocorrectionDisabled().textInputAutocapitalization(.characters)
                            .font(.system(size: 12, design: .monospaced))
                    }
                    LabeledContent("Step2 (R+SNR)") {
                        TextField("", text: $msg2).multilineTextAlignment(.trailing)
                            .autocorrectionDisabled().textInputAutocapitalization(.characters)
                            .font(.system(size: 12, design: .monospaced))
                    }
                    LabeledContent("Step3 (RR73)") {
                        TextField("", text: $msg3).multilineTextAlignment(.trailing)
                            .autocorrectionDisabled().textInputAutocapitalization(.characters)
                            .font(.system(size: 12, design: .monospaced))
                    }
                    LabeledContent("Step4 (73)") {
                        TextField("", text: $msg4).multilineTextAlignment(.trailing)
                            .autocorrectionDisabled().textInputAutocapitalization(.characters)
                            .font(.system(size: 12, design: .monospaced))
                    }
                }
                Section(header: Text("Start step")) {
                    Picker("Step", selection: $startStep) {
                        Text("Step1 (grid)").tag(1)
                        Text("Step2 (R+SNR)").tag(2)
                        Text("Step3 (RR73)").tag(3)
                        Text("Step4 (73)").tag(4)
                    }.pickerStyle(.segmented)
                }
                Section(header: Text("TX Period")) {
                    Picker("Period", selection: $txMode) {
                        Text("Even (0/30s)").tag("even")
                        Text("Odd (15/45s)").tag("odd")
                    }.pickerStyle(.segmented)
                }
            }
            .navigationTitle("Start QSO")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .primaryAction) {
                    HStack {
                        Button("Log") {
                            let m2parts = msg2.uppercased().components(separatedBy: .whitespaces)
                            let snrSent = m2parts.count >= 3 ? m2parts[2] : ""
                            onLog(QsoLogParams(dxCall: selectedDx, myCall: data.myCall,
                                               snrRcvd: data.snrFromMsg, snrSent: snrSent))
                            dismiss()
                        }
                        Button("Start TX") {
                            let initState = (startStep - 1) * 2  // step1→0, step2→2, step3→4, step4→6
                            let first: String
                            switch startStep {
                            case 4: first = msg4
                            case 3: first = msg3
                            case 2: first = msg2
                            default: first = msg1
                            }
                            onStart(QsoStartResult(
                                dxCall: selectedDx, myCall: data.myCall, txMode: txMode,
                                firstMsg: first, msg1: msg1, msg2: msg2, msg3: msg3, msg4: msg4,
                                initialState: initState, dxFreqHz: data.dxFreqHz))
                            dismiss()
                        }
                        .bold()
                    }
                }
            }
        }
        .presentationDetents([.large])
    }
}

// MARK: - Helpers

extension Color {
    init(hex: UInt32) {
        let r = Double((hex >> 16) & 0xFF) / 255
        let g = Double((hex >>  8) & 0xFF) / 255
        let b = Double( hex        & 0xFF) / 255
        self.init(red: r, green: g, blue: b)
    }
}

extension String {
    func matches(pattern: String) -> Bool {
        (try? NSRegularExpression(pattern: pattern))
            .map { $0.firstMatch(in: self, range: NSRange(self.startIndex..., in: self)) != nil } ?? false
    }
}
