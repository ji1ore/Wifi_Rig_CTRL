# Google Play Console — Wifi_RIG_CTRL v3.03 提出ガイド

**バージョン**: 3.03 (versionCode 81)  
**リリース日**: 2026-09-17

---

## 1. AAB ファイル

```
Wifi_RIG_CTRL_v3.03.aab  （このフォルダ内）
```

Play Console → 製品版 → リリースを作成 → AAB をアップロード

---

## 2. リリース名

```
3.03
```

---

## 3. リリースノート（日本語）

```
v3.03 更新内容

・SOTAスポット取得をREST APIに変更（telnetクラスター廃止）→ スポット表示が安定
・SOTA表示を直近2時間のスポットに絞り込み（従来24時間）→ 現在運用中の局のみ表示
```

---

## 4. リリースノート（英語）

```
What's new in v3.03

• SOTA spot fetching now uses the REST API (replaces telnet cluster) — spots load reliably
• SOTA list limited to the last 2 hours (was 24 hours) — shows only currently active stations
```

---

## 5. 提出チェックリスト

- [ ] AAB アップロード完了
- [ ] リリースノート（ja-JP / en-US）入力
- [ ] 審査なしロールアウト or 段階的ロールアウト（20%→100%）選択
- [ ] 「リリースを確認」→「製品版として公開」
