# Wifi_RIG_CTRL v3.03 リリースノート

**バージョン**: 3.03 (versionCode 81)  
**リリース日**: 2026-09-17

## 変更内容

### SOTAスポット取得方式の変更

telnetクラスター（cluster.sota.org.uk:7300）からSOTA公式REST API（api2.sota.org.uk）に変更しました。

- スポットが確実に取得・表示されるようになりました
- telnetクラスターで発生していた接続不安定・タイムアウトが解消されます
- APIはSOTA公式（api2.sota.org.uk/api/spots）を使用

### SOTA表示期間の変更

直近24時間 → **直近2時間** に変更。現在運用中のアクティベーターのスポットのみを表示します。

## ファイル

| ファイル | 用途 |
|---|---|
| `Wifi_RIG_CTRL_v3.03.apk` | 直接インストール用 |
| `Wifi_RIG_CTRL_v3.03.aab` | Google Play ストア提出用 |
