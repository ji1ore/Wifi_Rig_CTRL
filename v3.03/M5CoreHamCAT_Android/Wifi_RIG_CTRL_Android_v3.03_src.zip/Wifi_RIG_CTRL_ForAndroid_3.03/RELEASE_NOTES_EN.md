# Wifi_RIG_CTRL v3.03 Release Notes

**Version**: 3.03 (versionCode 81)  
**Release Date**: 2026-09-17

## Changes

### SOTA Spot Fetching via REST API

Switched from telnet cluster (cluster.sota.org.uk:7300) to the official SOTA REST API (api2.sota.org.uk).

- SOTA spots now load reliably every time
- Eliminates connection timeouts and instability that occurred with the telnet cluster
- Uses the official SOTA API: api2.sota.org.uk/api/spots

### SOTA Display Window

Changed from last 24 hours to **last 2 hours**. Only spots from currently active stations are shown.

## Files

| File | Purpose |
|---|---|
| `Wifi_RIG_CTRL_v3.03.apk` | Direct sideload install |
| `Wifi_RIG_CTRL_v3.03.aab` | Google Play Store submission |
