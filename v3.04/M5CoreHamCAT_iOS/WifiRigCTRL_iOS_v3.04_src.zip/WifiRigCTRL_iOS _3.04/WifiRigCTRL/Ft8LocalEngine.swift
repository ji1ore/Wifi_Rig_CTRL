import Foundation

// MARK: - Thread-safe WiFi RX ring buffer (mirrors Android Channel<ShortArray> DROP_OLDEST)

private final class WifiRxChannel: @unchecked Sendable {
    private let lock = NSLock()
    private var queue: [[Int16]] = []
    private let maxSize: Int

    init(maxSize: Int = 400) { self.maxSize = maxSize }

    func send(_ samples: [Int16]) {
        lock.lock()
        if queue.count >= maxSize { queue.removeFirst() }
        queue.append(samples)
        lock.unlock()
    }

    func tryReceive() -> [Int16]? {
        lock.lock(); defer { lock.unlock() }
        return queue.isEmpty ? nil : queue.removeFirst()
    }

    func drain() { lock.lock(); queue.removeAll(); lock.unlock() }

    // Poll every 20ms until data arrives or deadline (mirrors Android withTimeoutOrNull).
    func receive(timeoutMs: Int) async -> [Int16]? {
        let deadline = Date().addingTimeInterval(Double(timeoutMs) / 1000.0)
        while !Task.isCancelled && Date() < deadline {
            if let item = tryReceive() { return item }
            try? await Task.sleep(nanoseconds: 20_000_000)
        }
        return nil
    }
}

// MARK: - Ft8LocalEngine

/// Local FT8 engine for CI-V WiFi mode (mirrors Android Ft8LocalEngine.kt).
/// Audio RX arrives via CivService.rxAudioCallback (RS-BA1 8 kHz S16LE PCM).
/// Events are emitted via `sseStream` and `spectrumStream` for Ft8View to consume.
final class Ft8LocalEngine: @unchecked Sendable {

    // MARK: Output streams (consumed by Ft8View)

    struct SpectrumFrame {
        let bins: [UInt8]; let newPeriod: Bool; let period: Int; let utcSec: Int
    }
    typealias SseEvent = (type: String, data: [String: Any])

    private(set) var sseStream: AsyncStream<SseEvent>
    private(set) var spectrumStream: AsyncStream<SpectrumFrame>
    private var sseCont: AsyncStream<SseEvent>.Continuation?
    private var specCont: AsyncStream<SpectrumFrame>.Continuation?

    // MARK: State (lock-protected)

    private enum TxState { case off, oneShot, auto, cqAuto }
    private let stateLock = NSLock()
    private var _txState:    TxState = .off
    private var _autoMsg:    String  = ""
    private var _autoMode:   String  = "even"
    private var _txFreqHz:   Float   = 1500
    private var _myCall:     String  = ""
    private var _myGrid:     String  = ""
    private var _qsoDxCall:  String  = ""
    private var _qsoWaitFor: String  = ""
    private var _periodNo:   Int     = 0

    private func withState<T>(_ block: () -> T) -> T {
        stateLock.lock(); defer { stateLock.unlock() }; return block()
    }
    private var txState:   TxState { withState { _txState } }
    private var autoMsg:   String  { withState { _autoMsg } }
    private var autoMode:  String  { withState { _autoMode } }
    private var txFreqHz:  Float   { withState { _txFreqHz } }
    private var myCall:    String  { withState { _myCall } }
    private var qsoDxCall: String  { withState { _qsoDxCall } }

    // MARK: Config

    let SAMPLE_RATE     = 8000
    let PERIOD_S        = 15.0
    var PERIOD_SAMPLES: Int { Int(PERIOD_S * Double(SAMPLE_RATE)) }   // 120 000
    let SPECTRUM_CHUNK  = 1280                                         // ~160 ms at 8 kHz

    var ntpOffsetMs: Int64 = 0
    var rxGain: Float = 1.0
    var txGain: Float = 0.43   // adjustable from Ft8View; default matches original TX_GAIN

    // MARK: Private

    private weak var civ: CivService?
    private let wifiRx = WifiRxChannel(maxSize: 400)
    private var engineTask: Task<Void, Never>?
    private var isRunning  = false
    private var isTxing    = false

    // MARK: Init

    init(civ: CivService) {
        self.civ = civ

        var sc: AsyncStream<SseEvent>.Continuation?
        sseStream = AsyncStream<SseEvent>(bufferingPolicy: .bufferingNewest(200)) { sc = $0 }
        sseCont = sc

        var spec: AsyncStream<SpectrumFrame>.Continuation?
        spectrumStream = AsyncStream<SpectrumFrame>(bufferingPolicy: .bufferingNewest(50)) { spec = $0 }
        specCont = spec
    }

    // MARK: Public API

    func start(myCallSign: String, myGrid: String) {
        guard !isRunning else { return }
        stateLock.lock(); _myCall = myCallSign; _myGrid = myGrid; stateLock.unlock()
        isRunning = true
        civ?.rxAudioCallback = { [weak self] data in self?.onWifiRxAudio(data) }
        NSLog("[Ft8Engine] started myCall=\(myCallSign) sampleRate=\(SAMPLE_RATE)")
        engineTask = Task.detached(priority: .userInitiated) { [weak self] in
            guard let self else { return }
            while self.isRunning && !Task.isCancelled {
                do    { try await self.rxLoop() }
                catch is CancellationError { break }
                catch {
                    NSLog("[Ft8Engine] rxLoop error: \(error)")
                    if self.isRunning { try? await Task.sleep(nanoseconds: 1_000_000_000) }
                }
            }
        }
    }

    func stop() {
        guard isRunning else { return }
        isRunning = false
        civ?.rxAudioCallback = nil
        wifiRx.drain()
        engineTask?.cancel()
        sseCont?.finish()
        specCont?.finish()
        stateLock.lock(); _txState = .off; stateLock.unlock()
        NSLog("[Ft8Engine] stopped")
    }

    func sendOneShotTx(msg: String, audioFreqHz: Int, mode: String) {
        stateLock.lock()
        _autoMsg = msg; _txFreqHz = Float(audioFreqHz); _autoMode = mode; _txState = .oneShot
        stateLock.unlock()
    }

    func setAutoTx(active: Bool, mode: String, msg: String, audioFreqHz: Int) {
        stateLock.lock()
        _autoMode = mode; _txFreqHz = Float(audioFreqHz)
        if active { _autoMsg = msg; _txState = .auto } else { _txState = .off }
        stateLock.unlock()
    }

    func startCqAuto(active: Bool, msg: String, mode: String,
                     audioFreqHz: Int, call: String, grid: String) {
        stateLock.lock()
        if !call.isEmpty { _myCall = call }
        if !grid.isEmpty { _myGrid = grid }
        _txFreqHz = Float(audioFreqHz); _autoMode = mode
        if active { _autoMsg = msg; _txState = .cqAuto } else { _txState = .off }
        stateLock.unlock()
    }

    func startQso(dxCall: String, firstMsg: String, txMode: String,
                  audioFreqHz: Int, initialState: Int) {
        stateLock.lock()
        _qsoDxCall  = dxCall
        _qsoWaitFor = initialState == 0 ? "snr" : (initialState == 1 ? "r_snr" : "rr73")
        _autoMode   = txMode; _txFreqHz = Float(audioFreqHz)
        _autoMsg    = firstMsg; _txState = .auto
        stateLock.unlock()
    }

    func cancelQso() {
        stateLock.lock()
        _qsoDxCall = ""; _qsoWaitFor = ""
        if _txState == .auto { _txState = .off }
        stateLock.unlock()
    }

    // MARK: - RX loop

    private var nowMs: Int64 { Int64(Date().timeIntervalSince1970 * 1000) + ntpOffsetMs }

    private var _specFrameCount = 0

    private func rxLoop() async throws {
        while isRunning && !Task.isCancelled {
            let now        = nowMs
            let utcMs      = now % Int64(PERIOD_S * 1000)
            let waitMs     = Int64(PERIOD_S * 1000) - utcMs
            let utcSec     = Int((now / 1000) % 60)
            let alignedSec = (utcSec / 15) * 15

            stateLock.lock(); _periodNo += 1; let pNo = _periodNo; stateLock.unlock()
            NSLog("[Ft8Engine] period start pNo=\(pNo) alignedSec=\(alignedSec) waitMs=\(waitMs)")

            specCont?.yield(SpectrumFrame(bins: [], newPeriod: true, period: pNo, utcSec: alignedSec))

            let shouldTx = shouldTransmitThisPeriod(alignedSec)
            let txMsg    = shouldTx ? buildNextTxMsg() : nil

            if let msg = txMsg {
                sseCont?.yield(("tx_pending", ["msg": msg, "utc_at_tx": alignedSec]))
                try await Task.sleep(nanoseconds: UInt64(max(0, waitMs)) * 1_000_000)
                do    { try await doTx(msg) }
                catch is CancellationError { throw CancellationError() }
                catch { NSLog("[Ft8Engine] doTx error: \(error)") }
            } else {
                if waitMs > 50 {
                    await dispatchSpectrumDuringWait(waitMs: waitMs, pNo: pNo, utcSec: alignedSec)
                } else if waitMs > 0 {
                    try? await Task.sleep(nanoseconds: UInt64(waitMs) * 1_000_000)
                }
                wifiRx.drain()

                var buf = [Int16](repeating: 0, count: PERIOD_SAMPLES)
                let recorded = await recordPeriodWifiCiv(into: &buf, pNo: pNo, utcSec: alignedSec)

                if recorded >= PERIOD_SAMPLES / 2 {
                    let g = rxGain
                    let snapshot: [Int16] = g == 1.0 ? Array(buf.prefix(PERIOD_SAMPLES)) :
                        buf.prefix(PERIOD_SAMPLES).map { s in
                            Int16(clamping: Int(Float(s) * g))
                        }
                    let pDecoded = pNo
                    Task.detached { [weak self] in
                        self?.decodeAndDispatch(snapshot, pNo: pDecoded, utcSec: alignedSec)
                    }
                }
            }
        }
    }

    private func shouldTransmitThisPeriod(_ utcSec: Int) -> Bool {
        if txState == .off { return false }
        let isEven = (utcSec % 30 == 0)
        return autoMode == "odd" ? !isEven : isEven
    }

    private func buildNextTxMsg() -> String? {
        stateLock.lock(); defer { stateLock.unlock() }
        switch _txState {
        case .off: return nil
        case .oneShot:
            let m = _autoMsg; _txState = .off; return m.isEmpty ? nil : m
        case .auto, .cqAuto:
            return _autoMsg.isEmpty ? nil : _autoMsg
        }
    }

    // MARK: - TX

    private func doTx(_ msg: String) async throws {
        guard isRunning else { return }
        isTxing = true
        defer { isTxing = false }
        NSLog("[Ft8Engine] TX start: msg=\(msg) freqHz=\(txFreqHz)")

        let hz = txFreqHz
        var encoded = ft8lib_encode(msg, hz, Int32(SAMPLE_RATE))
        defer { ft8lib_free_encode_result(&encoded) }
        guard encoded.count > 0, let rawPtr = encoded.samples else {
            NSLog("[Ft8Engine] encode failed for: \(msg)"); return
        }

        let total = Int(encoded.count)
        let gain = txGain
        let pcm: [Int16] = (0..<total).map { i in
            Int16(clamping: Int(Float(rawPtr[i]) * gain))
        }
        NSLog("[Ft8Engine] TX encode OK: samples=\(total)")

        pttOn()
        try? await Task.sleep(nanoseconds: 50_000_000)
        await streamViaCiv(pcm)
        pttOff()

        sseCont?.yield(("auto_tx_sent", ["msg": msg]))

        let upper = msg.uppercased().trimmingCharacters(in: .whitespaces)
        if upper.hasSuffix("73") || upper.hasSuffix("RR73") {
            handleSentFinalMsg()
        }
    }

    private func pttOn()  { civ?.civPttDown() }
    private func pttOff() { civ?.civPttUp() }

    // Stream FT8 PCM to IC-705 via RS-BA1 in 160-sample (20ms) chunks.
    private func streamViaCiv(_ pcm: [Int16]) async {
        let chunkSamples = 160          // 20 ms at 8 kHz
        let intervalMs   = 20
        var offset       = 0
        var pktCount     = 0
        var nextSendMs   = Int64(Date().timeIntervalSince1970 * 1000)
        NSLog("[Ft8Engine] streamViaCiv start totalSamples=\(pcm.count)")
        while offset < pcm.count && isRunning {
            guard civ?.isConnected == true else {
                NSLog("[Ft8Engine] streamViaCiv: connection lost at pkt=\(pktCount)"); break
            }
            let len = min(chunkSamples, pcm.count - offset)
            var data = Data(count: len * 2)
            data.withUnsafeMutableBytes { (ptr: UnsafeMutableRawBufferPointer) in
                for i in 0..<len {
                    let s = pcm[offset + i]
                    ptr[i * 2]     = UInt8(bitPattern: Int8(truncatingIfNeeded: s))
                    ptr[i * 2 + 1] = UInt8(bitPattern: Int8(truncatingIfNeeded: s >> 8))
                }
            }
            civ?.sendTxAudioDirect(data)
            offset += len; pktCount += 1

            nextSendMs += Int64(intervalMs)
            let waitMs = nextSendMs - Int64(Date().timeIntervalSince1970 * 1000)
            if waitMs > 1 {
                try? await Task.sleep(nanoseconds: UInt64(waitMs) * 1_000_000)
            }
        }
        NSLog("[Ft8Engine] streamViaCiv done pktSent=\(pktCount)")
    }

    private func handleSentFinalMsg() {
        stateLock.lock()
        let st = _txState; let origMsg = _autoMsg
        stateLock.unlock()
        switch st {
        case .cqAuto:
            stateLock.lock(); _qsoDxCall = ""; _qsoWaitFor = ""; stateLock.unlock()
            sseCont?.yield(("cq_auto_restart", ["msg": origMsg]))
        case .auto:
            let mc = myCall
            stateLock.lock(); _txState = .off; _qsoDxCall = ""; _qsoWaitFor = ""; stateLock.unlock()
            sseCont?.yield(("qso_done", ["dx_call": "", "my_call": mc, "snr_rcvd": "", "snr_sent": ""]))
        default: break
        }
    }

    // MARK: - Audio RX

    private var _audioPacketCount = 0

    private func onWifiRxAudio(_ data: Data) {
        guard isRunning, !isTxing, data.count >= 2 else { return }
        _audioPacketCount += 1
        if _audioPacketCount <= 3 || _audioPacketCount % 500 == 0 {
            NSLog("[Ft8Engine] rxAudio pkt=\(_audioPacketCount) bytes=\(data.count)")
        }
        let count   = data.count / 2
        let samples: [Int16] = data.withUnsafeBytes { (ptr: UnsafeRawBufferPointer) in
            (0..<count).map { i -> Int16 in
                let lo = UInt16(ptr.load(fromByteOffset: i * 2,     as: UInt8.self))
                let hi = UInt16(ptr.load(fromByteOffset: i * 2 + 1, as: UInt8.self))
                return Int16(bitPattern: lo | (hi << 8))
            }
        }
        wifiRx.send(samples)
    }

    // MARK: - Spectrum dispatch during wait period

    private func dispatchSpectrumDuringWait(waitMs: Int64, pNo: Int, utcSec: Int) async {
        let deadline = Date().addingTimeInterval(Double(waitMs) / 1000.0)
        var frameCount = 0
        while Date() < deadline && isRunning && !Task.isCancelled {
            let remaining = Int(deadline.timeIntervalSinceNow * 1000.0)
            guard remaining > 0 else { break }
            if let samples = await wifiRx.receive(timeoutMs: min(300, remaining)) {
                let bins = computeSpectrum(samples)
                _specFrameCount += 1; frameCount += 1
                if _specFrameCount <= 5 || _specFrameCount % 100 == 0 {
                    NSLog("[Ft8Engine] specFrame #\(_specFrameCount) bins=\(bins.count) audioRx=\(samples.count)")
                }
                specCont?.yield(SpectrumFrame(bins: bins, newPeriod: false, period: pNo, utcSec: utcSec))
            } else {
                _specFrameCount += 1; frameCount += 1
                if _specFrameCount <= 5 || _specFrameCount % 100 == 0 {
                    NSLog("[Ft8Engine] specFrame #\(_specFrameCount) bins=256 (silence, no audio)")
                }
                specCont?.yield(SpectrumFrame(bins: [UInt8](repeating: 0, count: 256),
                                              newPeriod: false, period: pNo, utcSec: utcSec))
            }
        }
        NSLog("[Ft8Engine] dispatchSpectrumDuringWait done pNo=\(pNo) frameCount=\(frameCount)")
    }

    // MARK: - Record 15-second period

    private func recordPeriodWifiCiv(into buf: inout [Int16], pNo: Int, utcSec: Int) async -> Int {
        var pos      = 0
        var accum    = [Int16](repeating: 0, count: SPECTRUM_CHUNK)
        var accumPos = 0

        while pos < buf.count && isRunning && !isTxing {
            guard let samples = await wifiRx.receive(timeoutMs: 300) else {
                specCont?.yield(SpectrumFrame(bins: [UInt8](repeating: 0, count: 256),
                                              newPeriod: false, period: pNo, utcSec: utcSec))
                continue
            }

            var si = 0
            while si < samples.count {
                let toCopy = min(samples.count - si, SPECTRUM_CHUNK - accumPos)
                accum.replaceSubrange(accumPos..<(accumPos + toCopy),
                                      with: samples[si..<(si + toCopy)])
                si       += toCopy
                accumPos += toCopy

                if accumPos >= SPECTRUM_CHUNK {
                    let copyToBuf = min(SPECTRUM_CHUNK, buf.count - pos)
                    if copyToBuf > 0 {
                        buf.replaceSubrange(pos..<(pos + copyToBuf),
                                             with: accum[0..<copyToBuf])
                        pos += copyToBuf
                    }
                    specCont?.yield(SpectrumFrame(bins: computeSpectrum(Array(accum.prefix(SPECTRUM_CHUNK))),
                                                  newPeriod: false, period: pNo, utcSec: utcSec))
                    accumPos = 0
                    if pos >= buf.count { break }
                }
            }
            if pos >= buf.count { break }
        }
        return pos
    }

    // MARK: - Decode

    private func decodeAndDispatch(_ samples: [Int16], pNo: Int, utcSec: Int) {
        let myC: String; let dxC: String
        stateLock.lock(); myC = _myCall; dxC = _qsoDxCall; stateLock.unlock()

        var decoded = ft8lib_decode(samples, Int32(samples.count), Int32(SAMPLE_RATE),
                                    100.0, 3000.0, myC, dxC, 50)
        defer { ft8lib_free_decode_result(&decoded) }
        guard decoded.count > 0 else { return }

        for i in 0..<Int(decoded.count) {
            guard let cPtr = decoded.messages?[i] else { continue }
            let jsonStr = String(cString: cPtr)
            guard let data = jsonStr.data(using: String.Encoding.utf8),
                  let obj  = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
            else { continue }

            let msg  = obj["msg"]  as? String ?? ""
            let freq = (obj["freq"] as? Double ?? 0.0)
            let snr  = (obj["snr"]  as? Double ?? 0.0)
            let dt   = obj["dt"]   as? Double ?? 0.0

            sseCont?.yield(("decode_msg",
                            ["freq": Int(freq), "snr": Int(snr), "dt": dt,
                             "msg": msg, "period": pNo, "utc_sec": utcSec]))
            handleIncomingMsg(msg: msg, freq: Int(freq), snr: Int(snr), pNo: pNo)
        }
    }

    // MARK: - QSO state machine

    private func handleIncomingMsg(msg: String, freq: Int, snr: Int, pNo: Int) {
        let parts = msg.uppercased().trimmingCharacters(in: .whitespaces)
            .components(separatedBy: .whitespaces).filter { !$0.isEmpty }
        guard parts.count >= 2 else { return }

        stateLock.lock()
        let st  = _txState
        let myC = _myCall.uppercased()
        let dxC = _qsoDxCall.uppercased()
        stateLock.unlock()

        switch st {
        case .cqAuto:
            guard parts.count >= 3, parts[1] == myC else { return }
            let dx     = parts[0]
            let report = parts[2]
            let rsnr   = report.hasPrefix("R") ? report : buildSnrReport(snr, rPrefix: true)
            let reply  = "\(myC) \(dx.uppercased()) \(rsnr)"
            stateLock.lock()
            _qsoDxCall = dx; _qsoWaitFor = "r_snr"; _autoMsg = reply; _txState = .auto
            stateLock.unlock()
            sseCont?.yield(("qso_state", ["state": "calling_back", "msg": reply,
                                          "dx_call": dx, "my_call": myC,
                                          "snr_rcvd": report, "snr_sent": ""]))

        case .auto:
            guard !dxC.isEmpty, parts.count >= 3,
                  parts[0] == dxC, parts[1] == myC else { return }
            let word = parts[2]
            if word == "RR73" || word == "73" {
                stateLock.lock(); _txState = .off; _qsoDxCall = ""; _qsoWaitFor = ""; stateLock.unlock()
                sseCont?.yield(("qso_done", ["dx_call": dxC, "my_call": myC,
                                             "snr_rcvd": word, "snr_sent": ""]))
            } else if word.hasPrefix("R"), word.dropFirst().first?.isNumber == true {
                let rr73 = "\(myC) \(dxC) RR73"
                stateLock.lock(); _qsoWaitFor = "rr73"; _autoMsg = rr73; stateLock.unlock()
                sseCont?.yield(("qso_state", ["state": "sending_rr73", "msg": rr73,
                                              "dx_call": dxC, "my_call": myC,
                                              "snr_rcvd": word, "snr_sent": ""]))
            } else if word.first?.isNumber == true || word.hasPrefix("-") || word.hasPrefix("+") {
                let rsnr  = buildSnrReport(snr, rPrefix: true)
                let reply = "\(myC) \(dxC) \(rsnr)"
                stateLock.lock(); _qsoWaitFor = "r_snr"; _autoMsg = reply; stateLock.unlock()
                sseCont?.yield(("qso_state", ["state": "sending_r_snr", "msg": reply,
                                              "dx_call": dxC, "my_call": myC,
                                              "snr_rcvd": word, "snr_sent": ""]))
            }
        default: break
        }
    }

    private func buildSnrReport(_ snr: Int, rPrefix: Bool) -> String {
        let c = max(-30, min(30, snr))
        let s = c >= 0 ? String(format: "+%02d", c) : String(format: "%+03d", c)
        return rPrefix ? "R\(s)" : s
    }

    // MARK: - Spectrum (simple DFT, mirrors Android computeSpectrum)

    private func computeSpectrum(_ samples: [Int16]) -> [UInt8] {
        let fftSize = min(SPECTRUM_CHUNK, samples.count)
        var out     = [UInt8](repeating: 0, count: 256)
        guard fftSize >= 64 else { return out }

        let maxBin = min(
            Int(Double(3000) / Double(SAMPLE_RATE / 2) * Double(fftSize / 2)),
            fftSize / 2 - 1)
        let binsPerOut = Double(maxBin) / Double(out.count)
        let floats     = (0..<fftSize).map { Double(samples[$0]) / 32768.0 }
        let twoPi      = 2.0 * Double.pi

        for k in 0..<out.count {
            let binIdx = min(maxBin, Int(Double(k) * binsPerOut))
            let freq   = Double(binIdx) / Double(fftSize)
            var re = 0.0, im = 0.0
            for n in 0..<fftSize {
                let angle = twoPi * freq * Double(n)
                re += floats[n] * cos(angle)
                im += floats[n] * sin(angle)
            }
            let mag = (re * re + im * im).squareRoot()
            let db  = 20.0 * log10(mag + 1e-10) + 80.0
            out[k]  = UInt8(max(0, min(120, Int(db))))
        }
        return out
    }
}
