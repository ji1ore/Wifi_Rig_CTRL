#ifndef FT8LIB_API_H
#define FT8LIB_API_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int16_t* samples;
    int      count;
} Ft8EncodeResult;

typedef struct {
    char** messages;
    int    count;
} Ft8DecodeResult;

// Encode FT8 message to S16LE PCM (caller must call ft8lib_free_encode_result).
// Returns {NULL, 0} on error.
Ft8EncodeResult ft8lib_encode(const char* msg, float base_hz, int sample_rate);
void            ft8lib_free_encode_result(Ft8EncodeResult* r);

// Decode one 15-second audio window to FT8 messages.
// Each message is a JSON string: {"freq":1234.5,"snr":3.5,"dt":0.15,"msg":"CQ JA1XXX PM85"}
// Caller must call ft8lib_free_decode_result when done.
Ft8DecodeResult ft8lib_decode(const int16_t* samples, int n_samples, int sample_rate,
                               float freq_min, float freq_max,
                               const char* my_call, const char* dx_call,
                               int max_results);
void            ft8lib_free_decode_result(Ft8DecodeResult* r);

#ifdef __cplusplus
}
#endif

#endif /* FT8LIB_API_H */
