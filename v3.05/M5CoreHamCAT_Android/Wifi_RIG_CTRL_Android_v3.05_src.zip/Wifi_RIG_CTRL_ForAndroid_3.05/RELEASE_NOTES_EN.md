# Wifi_RIG_CTRL v3.04 Release Notes

**Version**: 3.04 (versionCode 82)  
**Release Date**: 2026-09-18

## Changes

### Fix: Duplicate SOTA Spots in Display

When multiple spots are received for the same callsign and summit, only the latest one is now shown.

- Applies to both the SOTA tab in the Memory screen and the SOTA overlay in FT8 view
- Fixes the issue where the same station kept appearing multiple times as their frequency was updated

### Fix: Frequency Offset When Changing Modes

Fixed a frequency drift issue that occurred when recalling a memory, tapping a SOTA/POTA spot, or responding to an SP2ALERT notification that requires a mode change.

- ICOM rigs automatically adjust the VFO frequency by the CW pitch offset when switching modes via CI-V. Sending frequency before mode caused the final VFO to be off by that offset
- Changed the command order to **set mode first, then frequency** across all code paths: memory recall, POTA spots, SOTA spots, and SP2ALERT integration

## Files

| File | Purpose |
|---|---|
| `Wifi_RIG_CTRL_v3.04.apk` | Direct sideload install |
| `Wifi_RIG_CTRL_v3.04.aab` | Google Play Store submission |
