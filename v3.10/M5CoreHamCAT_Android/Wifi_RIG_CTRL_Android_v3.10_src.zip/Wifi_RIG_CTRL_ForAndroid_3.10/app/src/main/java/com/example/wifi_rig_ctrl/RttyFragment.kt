package com.ji1ore.wifi_rig_ctrl

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.ji1ore.wifi_rig_ctrl.databinding.FragmentRttyBinding
import com.ji1ore.wifi_rig_ctrl.viewmodel.MainViewModel
import kotlinx.coroutines.*

class RttyFragment : Fragment() {

    private var _binding: FragmentRttyBinding? = null
    private val binding get() = _binding!!
    private val vm: MainViewModel by activityViewModels()

    private var preMode  = ""
    private var preWidth = 0

    private var isRttyR = false   // false=RTTY, true=RTTYR
    private var pttActive = false
    private var txJob: Job? = null

    private var modem: RttyModem? = null
    private val rxBuf = StringBuilder()

    // Peak detection
    private companion object { const val PEAK_BUF_SIZE = 2048 }
    private var detectedMarkHz  = 0.0
    private var detectedSpaceHz = 0.0
    private var lastMarkHz  = 2125.0   // persists across modem restarts
    private var lastSpaceHz = 2295.0
    private val peakBuf = ShortArray(PEAK_BUF_SIZE)
    private var peakPos = 0

    // --- Lifecycle ---

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentRttyBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Save pre-RTTY mode
        preMode  = vm.sharedMode.value  ?: ""
        preWidth = vm.sharedWidth.value ?: 0

        // Keep screen on
        requireActivity().window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Observe freq / mode from rig
        updateFreqDisplay(vm.sharedFreq.value ?: 0L)
        vm.sharedFreq.observe(viewLifecycleOwner) { updateFreqDisplay(it) }
        binding.tvMode.text = vm.sharedMode.value?.takeIf { it.isNotEmpty() } ?: "---"
        vm.sharedMode.observe(viewLifecycleOwner) { binding.tvMode.text = it.ifEmpty { "---" } }

        setupButtons()
        binding.tvFreq.setOnClickListener { showFreqDialog() }

        // Waterfall: show initial markers, wire touch → update modem decode frequency
        binding.rttyWaterfall.setMarkers(lastMarkHz, lastSpaceHz)
        binding.rttyWaterfall.onDecodeFreqSelected = { mark, space ->
            lastMarkHz = mark; lastSpaceHz = space
            modem?.updateFrequencies(mark, space)
            updateStatus("Decode: ${mark.toInt()} / ${space.toInt()} Hz")
        }

        // Set rig to RTTY mode on entry
        applyRigMode()

        startRx()
    }

    override fun onResume() {
        super.onResume()
        requireActivity().window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onPause() {
        super.onPause()
        requireActivity().window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        stopRx()
        cancelTx()
        if (pttActive) vm.setPttEnabled(false)
        // Restore previous mode
        if (preMode.isNotEmpty()) vm.sendMode(preMode, preWidth)
        _binding = null
    }

    // --- UI setup ---

    private fun setupButtons() {
        binding.btnBack.setOnClickListener { findNavController().popBackStack() }

        binding.btnRttyR.setOnClickListener {
            isRttyR = !isRttyR
            binding.btnRttyR.text = if (isRttyR) "RTTYR" else "RTTY"
            applyRigMode()
            // Swap mark/space to invert polarity for RTTYR
            val tmp = lastMarkHz; lastMarkHz = lastSpaceHz; lastSpaceHz = tmp
            modem?.updateFrequencies(lastMarkHz, lastSpaceHz)
            binding.rttyWaterfall.setMarkers(lastMarkHz, lastSpaceHz)
            updateStatus(if (isRttyR) "RTTYR" else "RTTY")
        }

        binding.btnBaud.setOnClickListener {
            val newBaud = if (modem?.baudRate == 45.45) 75.0 else 45.45
            restartModem(newBaud)
            binding.btnBaud.text = if (newBaud == 45.45) "45.45bd" else "75bd"
        }

        binding.btnClear.setOnClickListener {
            rxBuf.clear()
            binding.tvRx.text = ""
        }

        setupPresets()
        binding.btnTx.setOnClickListener { startTx() }
        binding.btnTune.setOnClickListener { applyTune() }

        binding.btnPtt.setOnClickListener {
            if (txJob?.isActive == true) {
                cancelTx()
            } else {
                toggleManualPtt()
            }
        }

        binding.etTx.setOnEditorActionListener { _, _, _ -> startTx(); true }
    }

    // --- Preset messages ---

    private fun setupPresets() {
        val call = vm.prefs.ft8MyCall.uppercase().ifEmpty { "MYCALL" }
        val presets = listOf(
            binding.btnPresetCq  to "CQ CQ CQ DE $call $call K",
            binding.btnPresetRst to "UR 599 $call $call K",
            binding.btnPresetTu  to "TU 73 DE $call K",
            binding.btnPresetQrz to "QRZ DE $call K",
            binding.btnPresetBk  to "BK",
            binding.btnPresetAgn to "PSE AGN",
            binding.btnPresetDe  to "DE $call"
        )
        for ((btn, text) in presets) {
            btn.setOnClickListener { binding.etTx.setText(text) }
        }
    }

    // --- Rig mode ---

    private fun applyRigMode() {
        val mode = if (isRttyR) "RTTYR" else "RTTY"
        vm.sendMode(mode, 0)
        updateStatus("Mode: $mode")
    }

    // --- RX: receive rig audio from RS-BA1 UDP (CI-V WiFi) or Pi proxy HTTP stream ---

    private fun startRx(baudRate: Double = modem?.baudRate ?: 45.45) {
        val sampleRate = 8000
        val m = RttyModem(sampleRate = sampleRate, baudRate = baudRate,
                          markHz = lastMarkHz, spaceHz = lastSpaceHz) { ch ->
            activity?.runOnUiThread { appendRx(ch) }
        }
        modem = m
        peakPos = 0

        fun feedSamples(shorts: ShortArray, count: Int) {
            m.feed(shorts, count)
            var src = 0; var rem = count
            while (rem > 0) {
                val take = minOf(rem, PEAK_BUF_SIZE - peakPos)
                shorts.copyInto(peakBuf, peakPos, src, src + take)
                peakPos += take; src += take; rem -= take
                if (peakPos >= PEAK_BUF_SIZE) {
                    peakPos = 0
                    val snap   = peakBuf.copyOf()
                    val powers = RttyModem.scanPowers(snap, PEAK_BUF_SIZE, sampleRate)
                    val peaks  = RttyModem.findPeaks(powers)
                    activity?.runOnUiThread {
                        if (_binding != null) {
                            binding.rttyWaterfall.addRow(powers)
                            updatePeakDisplay(peaks)
                        }
                    }
                }
            }
        }

        val isCivWifi = vm.useCIV.value == true && vm.civConnectionType.value != "BT"
        if (isCivWifi) {
            // RS-BA1 UDP audio from IC-705 (Int16 LE PCM at 8 kHz)
            vm.civ.rxAudioCallback = { buf, offset, len ->
                val count = len / 2
                if (count > 0) {
                    val shorts = ShortArray(count) { i ->
                        val lo = buf[offset + i * 2].toInt() and 0xFF
                        val hi = buf[offset + i * 2 + 1].toInt() and 0xFF
                        ((hi shl 8) or lo).toShort()
                    }
                    feedSamples(shorts, count)
                }
            }
        } else {
            // Pi proxy HTTP audio stream
            vm.audio.audioSampleListener = { shorts ->
                feedSamples(shorts, shorts.size)
            }
        }

        updateStatus("RX")
    }

    private fun stopRx() {
        modem = null
        if (vm.useCIV.value == true && vm.civConnectionType.value != "BT") {
            vm.civ.rxAudioCallback = null
        } else {
            vm.audio.audioSampleListener = null
        }
    }

    private fun updatePeakDisplay(peaks: Pair<Double, Double>?) {
        if (_binding == null) return
        if (peaks != null) {
            detectedMarkHz  = peaks.first
            detectedSpaceHz = peaks.second
            binding.tvPeakFreq.text = "${peaks.first.toInt()} / ${peaks.second.toInt()} Hz"
            binding.btnTune.isEnabled = true
        } else {
            binding.tvPeakFreq.text = "--- / --- Hz"
            binding.btnTune.isEnabled = false
        }
    }

    private fun applyTune() {
        val m = modem ?: return
        if (detectedMarkHz <= 0 || detectedSpaceHz <= 0) return
        lastMarkHz  = detectedMarkHz
        lastSpaceHz = detectedSpaceHz
        m.updateFrequencies(lastMarkHz, lastSpaceHz)
        binding.rttyWaterfall.setMarkers(lastMarkHz, lastSpaceHz)
        updateStatus("Tuned: ${lastMarkHz.toInt()} / ${lastSpaceHz.toInt()} Hz")
    }

    private fun restartModem(newBaud: Double) {
        stopRx()
        startRx(newBaud)
    }

    private fun appendRx(ch: Char) {
        if (_binding == null) return
        rxBuf.append(ch)
        // Trim old history to keep memory bounded
        if (rxBuf.length > 8000) rxBuf.delete(0, rxBuf.length - 6000)
        binding.tvRx.text = rxBuf.toString()
        binding.scrollRx.post { binding.scrollRx.fullScroll(View.FOCUS_DOWN) }
    }

    // --- TX ---

    private fun startTx() {
        if (txJob?.isActive == true) return
        val text = binding.etTx.text.toString().trim()
        if (text.isEmpty()) return

        val m = modem ?: return
        val samples = m.encode(text)

        txJob = lifecycleScope.launch(Dispatchers.IO) {
            stopRx()                                 // pause RX while TX
            withContext(Dispatchers.Main) {
                setPttUi(true)
                binding.tvRx.append("\n[TX] $text\n")
            }
            vm.setPttEnabled(true)
            pttActive = true
            delay(100)                               // PTT settle

            playAudio(samples)

            delay(50)
            vm.setPttEnabled(false)
            pttActive = false

            withContext(Dispatchers.Main) {
                setPttUi(false)
                binding.etTx.text?.clear()
            }
            startRx()                                // resume RX
        }
    }

    private fun cancelTx() {
        txJob?.cancel()
        txJob = null
        if (pttActive) { vm.setPttEnabled(false); pttActive = false }
        lifecycleScope.launch(Dispatchers.Main) { setPttUi(false) }
        lifecycleScope.launch(Dispatchers.IO) { startRx() }
    }

    private fun toggleManualPtt() {
        pttActive = !pttActive
        vm.setPttEnabled(pttActive)
        setPttUi(pttActive)
        updateStatus(if (pttActive) "TX (manual PTT)" else "RX")
    }

    private fun setPttUi(tx: Boolean) {
        binding.tvRxTx.text  = if (tx) "TX" else "RX"
        binding.tvRxTx.setTextColor(if (tx) 0xFFFF4444.toInt() else 0xFF44FF44.toInt())
        binding.btnPtt.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (tx) 0xFFD32F2F.toInt() else 0xFF6A1B9A.toInt()
        )
        binding.btnTx.isEnabled = !tx
        binding.btnTx.alpha     = if (tx) 0.4f else 1.0f
    }

    private fun playAudio(samples: ShortArray) {
        val sampleRate = modem?.sampleRate ?: 8000
        val bufSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        track.play()
        var pos = 0
        val chunk = bufSize / 2
        while (pos < samples.size) {
            val end = minOf(pos + chunk, samples.size)
            track.write(samples, pos, end - pos)
            pos = end
        }
        track.stop()
        track.release()
    }

    // --- Frequency dialog ---

    private fun showFreqDialog() {
        val labels = arrayOf(
            "160m   1.838 MHz",
            " 80m   3.535 MHz (JP)", " 80m   3.580 MHz",
            " 40m   7.030 MHz (JP)", " 40m   7.035 MHz",
            " 30m  10.142 MHz",
            " 20m  14.080 MHz",      " 20m  14.090 MHz",
            " 17m  18.102 MHz",
            " 15m  21.080 MHz",
            " 12m  24.920 MHz",
            " 10m  28.080 MHz",
            "  6m  50.300 MHz",
            "  2m 144.600 MHz (JP)", "  2m 144.800 MHz",
            " 70c 430.600 MHz (JP)", " 70c 432.600 MHz"
        )
        val freqs = longArrayOf(
            1_838_000L,
            3_535_000L,  3_580_000L,
            7_030_000L,  7_035_000L,
            10_142_000L,
            14_080_000L, 14_090_000L,
            18_102_000L,
            21_080_000L,
            24_920_000L,
            28_080_000L,
            50_300_000L,
            144_600_000L, 144_800_000L,
            430_600_000L, 432_600_000L
        )
        val current = vm.sharedFreq.value ?: 0L
        val idx = freqs.indexOfFirst { it == current }.coerceAtLeast(-1)
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("RTTY Band")
            .setSingleChoiceItems(labels, idx) { dialog, which ->
                vm.sendFreq(freqs[which])
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // --- Helpers ---

    private fun updateStatus(msg: String) {
        activity?.runOnUiThread { _binding?.tvStatus?.text = msg }
    }

    private fun updateFreqDisplay(hz: Long) {
        if (hz <= 0L) { binding.tvFreq.text = "---.--- MHz"; return }
        val mhz = hz / 1_000_000.0
        binding.tvFreq.text = "%,.3f MHz".format(mhz)
    }
}
