import Foundation
import Darwin

actor RigApiService {
    private(set) var host: String = ""
    private(set) var apiPort: Int = AppConstants.defaultApiPort
    private(set) var apiKey: String = ""

    /// Resolved IP (used in URLs to avoid iOS 26 URLSession mDNS issues with `.local`).
    /// Falls back to `host` if resolution fails.
    private var resolvedHost: String = ""

    private let session: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 3.0
        config.timeoutIntervalForResource = 10.0
        config.waitsForConnectivity = false
        config.httpAdditionalHeaders = ["Accept": "application/json"]
        return URLSession(configuration: config)
    }()

    func configure(host: String, apiPort: Int, apiKey: String) {
        self.host = host
        self.apiPort = apiPort
        self.apiKey = apiKey
        // Resolve once via getaddrinfo (mDNS-aware on iOS) and cache the IP.
        // iOS 26 URLSession sometimes can't resolve `.local` hostnames reliably,
        // so we pre-resolve and use a literal IP in the URL.
        self.resolvedHost = resolveIPv4(host) ?? host
    }

    var baseURL: String { "http://\(resolvedHost.isEmpty ? host : resolvedHost):\(apiPort)" }

    /// Synchronously resolve a hostname to its first IPv4 address via getaddrinfo.
    /// Returns nil if not resolvable. Numeric IPs pass through unchanged.
    private nonisolated func resolveIPv4(_ host: String) -> String? {
        if host.isEmpty { return nil }
        // If already a numeric IP, return as-is.
        var test = in_addr()
        if host.withCString({ inet_pton(AF_INET, $0, &test) }) == 1 {
            return host
        }
        var hints = addrinfo()
        hints.ai_family = AF_INET
        hints.ai_socktype = SOCK_STREAM
        hints.ai_protocol = IPPROTO_TCP
        var result: UnsafeMutablePointer<addrinfo>? = nil
        let rv = host.withCString { getaddrinfo($0, nil, &hints, &result) }
        guard rv == 0, let info = result else { return nil }
        defer { freeaddrinfo(info) }
        let sa = info.pointee.ai_addr.withMemoryRebound(to: sockaddr_in.self, capacity: 1) { $0.pointee }
        var addrCopy = sa.sin_addr
        var buf = [CChar](repeating: 0, count: Int(INET_ADDRSTRLEN))
        guard inet_ntop(AF_INET, &addrCopy, &buf, socklen_t(INET_ADDRSTRLEN)) != nil else {
            return nil
        }
        return String(cString: buf)
    }

    private func makeRequest(path: String, query: [URLQueryItem] = [], method: String = "GET", body: Data? = nil, contentType: String? = nil, timeout: TimeInterval? = nil) throws -> URLRequest {
        var comps = URLComponents(string: baseURL + path)
        if !query.isEmpty { comps?.queryItems = query }
        guard let url = comps?.url else { throw RigApiError.invalidURL }
        var req = URLRequest(url: url)
        req.httpMethod = method
        if !apiKey.isEmpty { req.setValue(apiKey, forHTTPHeaderField: "X-API-Key") }
        if let contentType { req.setValue(contentType, forHTTPHeaderField: "Content-Type") }
        if let body { req.httpBody = body }
        if let timeout { req.timeoutInterval = timeout }
        return req
    }

    private func perform(_ req: URLRequest) async throws -> (Data, HTTPURLResponse) {
        let (data, response): (Data, URLResponse)
        do {
            (data, response) = try await session.data(for: req)
        } catch {
            throw RigApiError.transport(error)
        }
        guard let http = response as? HTTPURLResponse else { throw RigApiError.httpStatus(-1) }
        guard (200..<300).contains(http.statusCode) else { throw RigApiError.httpStatus(http.statusCode) }
        return (data, http)
    }

    private func decode<T: Decodable>(_ type: T.Type, from data: Data) throws -> T {
        do { return try JSONDecoder().decode(T.self, from: data) }
        catch { throw RigApiError.decoding(String(describing: error)) }
    }

    private func form(_ pairs: [String: String]) -> Data {
        let s = pairs.map { (k, v) in
            "\(percentEncode(k))=\(percentEncode(v))"
        }.joined(separator: "&")
        return Data(s.utf8)
    }

    private func percentEncode(_ s: String) -> String {
        s.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? s
    }

    // MARK: - Endpoints

    func getRigs() async throws -> [RigInfo] {
        let req = try makeRequest(path: "/rigs", timeout: 10.0)
        let (data, _) = try await perform(req)
        return try decode(RigsResponse.self, from: data).rigs
    }

    func getDevices() async throws -> DevicesResponse {
        let req = try makeRequest(path: "/devices", timeout: 10.0)
        let (data, _) = try await perform(req)
        return try decode(DevicesResponse.self, from: data)
    }

    func openRig(model: Int, cat: String, baud: Int, ptt: String, pttType: String) async throws {
        let q = [
            URLQueryItem(name: "model", value: String(model)),
            URLQueryItem(name: "cat", value: cat),
            URLQueryItem(name: "baud", value: String(baud)),
            URLQueryItem(name: "ptt", value: ptt),
            URLQueryItem(name: "ptt_type", value: pttType)
        ]
        let req = try makeRequest(path: "/radio/open", query: q, timeout: 5.0)
        _ = try await perform(req)
    }

    func getStatus() async throws -> RigStatus {
        let req = try makeRequest(path: "/radio/status")
        let (data, _) = try await perform(req)
        return try decode(RigStatus.self, from: data)
    }

    func getCaps() async throws -> CapsResponse {
        let req = try makeRequest(path: "/radio/caps")
        let (data, _) = try await perform(req)
        return try decode(CapsResponse.self, from: data)
    }

    func setFreq(hz: Int64) async throws {
        let body = form(["f": String(hz)])
        let req = try makeRequest(path: "/radio/setfreq", method: "POST", body: body, contentType: "application/x-www-form-urlencoded")
        _ = try await perform(req)
    }

    func setTxShift(shiftHz: Int64) async throws {
        let body = form(["shift_hz": String(shiftHz)])
        let req = try makeRequest(path: "/radio/set_tx_shift", method: "POST", body: body, contentType: "application/x-www-form-urlencoded")
        _ = try await perform(req)
    }

    func setMode(mode: String, width: Int) async throws {
        let body = form(["mode": mode, "width": String(width)])
        let req = try makeRequest(path: "/radio/setmode", method: "POST", body: body, contentType: "application/x-www-form-urlencoded")
        _ = try await perform(req)
    }

    func setLevel(name: String, value: Double) async throws {
        let body = form(["name": name, "value": String(format: "%.3f", value)])
        let req = try makeRequest(path: "/radio/setlevel", method: "POST", body: body, contentType: "application/x-www-form-urlencoded")
        _ = try await perform(req)
    }

    func setPower(value: Double) async throws {
        let body = form(["value": String(format: "%.3f", value)])
        let req = try makeRequest(path: "/radio/setpower", method: "POST", body: body, contentType: "application/x-www-form-urlencoded")
        _ = try await perform(req)
    }

    func setPtt(state: Bool) async throws {
        let body = form(["state": state ? "1" : "0"])
        let req = try makeRequest(path: "/radio/ptt", method: "POST", body: body, contentType: "application/x-www-form-urlencoded")
        guard state else {
            // OFF: 単発送信。確実な送達はPi側のPTT OFF watchdogが担う。
            _ = try await perform(req)
            return
        }
        // ON: FTX-1F等、PTT ONで音声USBが瞬断しPi側のrigctldごと再起動することがあり
        // (USB再列挙+CAT再接続で通常2〜3秒、まれにそれ以上)、1回きりの送信では復旧を
        // 待ちきれず取りこぼすことがあった。最大5秒間、経過時間ベースでリトライする
        // (M5/ESP32・Android側と同じ方針)。
        let deadline = Date().addingTimeInterval(5.0)
        while true {
            do {
                _ = try await perform(req)
                return
            } catch {
                if Date() >= deadline { throw error }
                try? await Task.sleep(nanoseconds: 200_000_000)
            }
        }
    }

    /// Pi-side API + rigctld version (used by About view to warn on mismatch with the app).
    /// Returns ("?", reason) on failure so the caller can still display something useful.
    func getServerVersion() async -> (apiVersion: String, rigctld: String) {
        do {
            let req = try makeRequest(path: "/admin/version", timeout: 5.0)
            let (data, _) = try await perform(req)
            struct Resp: Decodable { let api_version: String?; let rigctld: String? }
            let r = try? JSONDecoder().decode(Resp.self, from: data)
            return (r?.api_version ?? "?", r?.rigctld ?? "?")
        } catch {
            return ("?", error.localizedDescription)
        }
    }

    /// Set Noise Reduction level (0=Off, 1..5). Endpoint mirrors Android's `/radio/noise_reduction`.
    func setNrLevel(_ level: Int) async throws {
        let body = form(["level": String(level)])
        let req = try makeRequest(path: "/radio/noise_reduction", method: "POST", body: body, contentType: "application/x-www-form-urlencoded")
        _ = try await perform(req)
    }

    func setPoll(state: Bool) async throws {
        let body = form(["state": state ? "1" : "0"])
        let req = try makeRequest(path: "/radio/poll", method: "POST", body: body, contentType: "application/x-www-form-urlencoded")
        _ = try await perform(req)
    }

    func setAudioDevice(capture: String, playback: String) async throws {
        let json: [String: String] = ["capture": capture, "playback": playback]
        let body = try JSONSerialization.data(withJSONObject: json)
        let req = try makeRequest(path: "/radio/audio_device", method: "POST", body: body, contentType: "application/json")
        _ = try await perform(req)
    }

    func getPiTimeMs() async throws -> Int64 {
        let req = try makeRequest(path: "/time")
        let (data, _) = try await perform(req)
        return try decode(PiTime.self, from: data).ms
    }

    func pttHeartbeat() async throws {
        let req = try makeRequest(path: "/radio/ptt_heartbeat", method: "POST", body: Data(), contentType: "application/x-www-form-urlencoded", timeout: 1.2)
        _ = try await perform(req)
    }

    func setBkIn(on: Bool) async throws {
        let body = form(["state": on ? "1" : "0"])
        let req = try makeRequest(path: "/radio/setbkin", method: "POST", body: body, contentType: "application/x-www-form-urlencoded")
        _ = try await perform(req)
    }

    func getBkIn() async throws -> Bool {
        let req = try makeRequest(path: "/radio/getbkin")
        let (data, _) = try await perform(req)
        return try decode(BkInResponse.self, from: data).bk_in
    }

    // MARK: - APRS

    func sendAprsConfig(_ config: AprsConfig) async throws {
        let body = try JSONEncoder().encode(config)
        let req = try makeRequest(path: "/aprs_config", method: "POST", body: body, contentType: "application/json")
        _ = try await perform(req)
    }

    func startAprs(_ config: AprsConfig) async throws {
        // Build JSON for the subset (Android-compatible).
        let payload: [String: Any] = [
            "callsign": config.callsign,
            "ssid": config.ssid,
            "path": config.path,
            "interval": config.interval,
            "freq": config.freq,
            "baud": config.baud,
            "use_gps": config.use_gps,
            "manual_lat": config.manual_lat,
            "manual_lon": config.manual_lon
        ]
        let body = try JSONSerialization.data(withJSONObject: payload)
        let req = try makeRequest(path: "/aprs_start", method: "POST", body: body, contentType: "application/json")
        _ = try await perform(req)
    }

    func stopAprs() async throws {
        let req = try makeRequest(path: "/aprs_stop", method: "POST", body: Data(), contentType: "text/plain")
        _ = try await perform(req)
    }

    func getAprsReceived() async throws -> [AprsStation] {
        let req = try makeRequest(path: "/aprs_received")
        let (data, _) = try await perform(req)
        return try decode(AprsReceivedResponse.self, from: data).stations
    }

    func aprsHeartbeat() async throws {
        let req = try makeRequest(path: "/aprs_heartbeat", method: "POST", body: Data(), contentType: "text/plain", timeout: 2.0)
        _ = try await perform(req)
    }

    func sendGps(lat: Double, lon: Double) async throws {
        let payload: [String: Any] = ["lat": lat, "lon": lon]
        let body = try JSONSerialization.data(withJSONObject: payload)
        let req = try makeRequest(path: "/gps", method: "POST", body: body, contentType: "application/json")
        _ = try await perform(req)
    }

    // MARK: - VFO (v2.20)

    func getVfoMode() async throws -> VfoResponse {
        let req = try makeRequest(path: "/radio/vfo_current")
        let (data, _) = try await perform(req)
        return try decode(VfoResponse.self, from: data)
    }

    func toggleVfo() async throws -> VfoResponse {
        let req = try makeRequest(path: "/radio/vfo_toggle", method: "POST", body: Data(), contentType: "text/plain")
        let (data, _) = try await perform(req)
        return try decode(VfoResponse.self, from: data)
    }

    // MARK: - v2.02 additions

    /// Improved Pi clock offset: RTT-corrected `(piMs + rtt/2 - t2)`.
    func getPiClockOffsetMs() async throws -> Int64 {
        let t1 = Int64(Date().timeIntervalSince1970 * 1000)
        let req = try makeRequest(path: "/time")
        let (data, _) = try await perform(req)
        let t2 = Int64(Date().timeIntervalSince1970 * 1000)
        let piMs = try decode(PiTime.self, from: data).ms
        return piMs + (t2 - t1) / 2 - t2
    }

    /// Audio device for FT8 only (independent of main audio device).
    func setAudioDeviceFt8(capture: String) async throws {
        let json: [String: String] = ["capture": capture]
        let body = try JSONSerialization.data(withJSONObject: json)
        let req = try makeRequest(path: "/radio/audio_device_ft8", method: "POST", body: body, contentType: "application/json")
        _ = try await perform(req)
    }

    /// Server-side FT8/FT4 TX.
    func ft8Tx(msg: String, audioFreqHz: Int = 1500, rate: Int = 12000, isFt4: Bool = false) async throws {
        let payload: [String: Any] = [
            "msg": msg,
            "audio_freq": audioFreqHz,
            "rate": rate,
            "is_ft4": isFt4
        ]
        let body = try JSONSerialization.data(withJSONObject: payload)
        let req = try makeRequest(path: "/radio/ft8_tx", method: "POST", body: body, contentType: "application/json", timeout: 20.0)
        _ = try await perform(req)
    }

    // MARK: - v2.02 CW bridge

    func cwStatus() async throws -> CwStatus {
        let req = try makeRequest(path: "/cw/status")
        let (data, _) = try await perform(req)
        return try decode(CwStatus.self, from: data)
    }

    func cwOpen(port: String = "ttyACM0", delayMs: Int = 0) async throws {
        let q = [URLQueryItem(name: "port", value: port), URLQueryItem(name: "delay_ms", value: String(delayMs))]
        let req = try makeRequest(path: "/cw/open", query: q)
        _ = try await perform(req)
    }

    func cwClose() async throws {
        let req = try makeRequest(path: "/cw/close", method: "POST", body: Data(), contentType: "text/plain")
        _ = try await perform(req)
    }

    func cwKey(_ on: Bool) async throws {
        let body = form(["is_on": on ? "true" : "false"])
        let req = try makeRequest(path: "/cw/key", method: "POST", body: body, contentType: "application/x-www-form-urlencoded")
        _ = try await perform(req)
    }

    func cwSendMorse(text: String, wpm: Int) async throws {
        let body = form(["text": text, "wpm": String(wpm)])
        let req = try makeRequest(path: "/cw/send_morse", method: "POST", body: body, contentType: "application/x-www-form-urlencoded")
        _ = try await perform(req)
    }

    func cwStopMorse() async throws {
        let req = try makeRequest(path: "/cw/stop_morse", method: "POST", body: Data(), contentType: "text/plain")
        _ = try await perform(req)
    }

    func cwMorseStatus() async throws -> Bool {
        let req = try makeRequest(path: "/cw/morse_status")
        let (data, _) = try await perform(req)
        struct Resp: Decodable { let sending: Bool? }
        return (try? decode(Resp.self, from: data).sending) ?? false
    }

    // MARK: - v2.02 Admin (firmware/script upload)

    /// Returns nil on success, or an error message string on failure.
    func sendCwBridgeUpdate(_ content: Data) async throws {
        let req = try makeRequest(path: "/admin/update_cw_bridge", method: "POST", body: content, contentType: "text/plain", timeout: 30.0)
        _ = try await perform(req)
    }

    func sendApiUpdate(_ content: Data) async throws {
        let req = try makeRequest(path: "/admin/update", method: "POST", body: content, contentType: "text/plain", timeout: 30.0)
        _ = try await perform(req)
    }

    func sendSetupScript(_ content: Data) async throws {
        let req = try makeRequest(path: "/admin/setup", method: "POST", body: content, contentType: "application/x-sh", timeout: 30.0)
        _ = try await perform(req)
    }

    /// Returns (running, log).
    func getSetupLog() async throws -> (running: Bool, log: String) {
        let req = try makeRequest(path: "/admin/setup_log", timeout: 10.0)
        let (data, _) = try await perform(req)
        struct Resp: Decodable { let running: Bool?; let log: String? }
        let r = try decode(Resp.self, from: data)
        return (r.running ?? false, r.log ?? "")
    }

    func sendHamlibInstall(_ content: Data) async throws {
        let req = try makeRequest(path: "/admin/install_hamlib", method: "POST", body: content, contentType: "application/x-sh", timeout: 30.0)
        _ = try await perform(req)
    }

    /// Returns (running, log).
    func getHamlibLog() async throws -> (running: Bool, log: String) {
        let req = try makeRequest(path: "/admin/hamlib_log", timeout: 10.0)
        let (data, _) = try await perform(req)
        struct Resp: Decodable { let running: Bool?; let log: String? }
        let r = try decode(Resp.self, from: data)
        return (r.running ?? false, r.log ?? "")
    }

    // MARK: - v3.01 Admin (reboot / mfsk / syncTime)

    /// POST /admin/reboot — returns true if Pi accepted the command.
    func rebootPi() async -> Bool {
        guard let req = try? makeRequest(path: "/admin/reboot", method: "POST", timeout: 5.0) else { return false }
        return (try? await perform(req)) != nil
    }

    /// POST /admin/build_mfsk[?force=true]
    func triggerMfskBuild(force: Bool = false) async throws {
        let path = force ? "/admin/build_mfsk?force=true" : "/admin/build_mfsk"
        let req = try makeRequest(path: path, method: "POST", timeout: 10.0)
        _ = try await perform(req)
    }

    /// GET /admin/mfsk_build_log — returns (running, log).
    func getMfskBuildLog() async throws -> (running: Bool, log: String) {
        let req = try makeRequest(path: "/admin/mfsk_build_log", timeout: 10.0)
        let (data, _) = try await perform(req)
        struct Resp: Decodable { let status: String?; let log: String? }
        let r = try decode(Resp.self, from: data)
        let running = (r.status ?? "") == "building"
        let log = r.log ?? ""
        return (running, log)
    }

    /// POST /admin/set_time {"ms": <epoch_ms>} — returns (ok, source, driftMs).
    func syncTime(ms: Int64) async throws -> (ok: Bool, source: String, driftMs: Int) {
        let body = Data("{\"ms\":\(ms)}".utf8)
        let req = try makeRequest(path: "/admin/set_time", method: "POST", body: body,
                                  contentType: "application/json", timeout: 10.0)
        let (data, resp) = try await perform(req)
        guard (resp as? HTTPURLResponse)?.statusCode == 200 else { return (false, "error", 0) }
        struct Resp: Decodable { let source: String?; let drift_ms: Int? }
        let r = (try? decode(Resp.self, from: data))
        return (true, r?.source ?? "unknown", r?.drift_ms ?? 0)
    }

    // MARK: - FT8 native (v3.00)

    func makeSseRequest(path: String) throws -> URLRequest {
        let keyParam = apiKey.isEmpty ? "" : "?api_key=\(apiKey)"
        guard let url = URL(string: "\(baseURL)\(path)\(keyParam)") else { throw RigApiError.invalidURL }
        var req = URLRequest(url: url)
        req.setValue("text/event-stream", forHTTPHeaderField: "Accept")
        if !apiKey.isEmpty { req.setValue(apiKey, forHTTPHeaderField: "X-API-Key") }
        req.timeoutInterval = 120
        return req
    }

    func ft8Start() async throws {
        let req = try makeRequest(path: "/ft8/start", method: "POST", body: Data(), contentType: "text/plain")
        _ = try await perform(req)
    }

    func ft8Stop() async throws {
        let req = try makeRequest(path: "/ft8/stop", method: "POST", body: Data(), contentType: "text/plain")
        _ = try await perform(req)
    }

    func ft8SetAutoTx(active: Bool, mode: String, msg: String, audioFreqHz: Int) async throws {
        let payload: [String: Any] = ["active": active, "mode": mode, "msg": msg, "audio_freq": audioFreqHz]
        let body = try JSONSerialization.data(withJSONObject: payload)
        let req = try makeRequest(path: "/ft8/auto_tx", method: "POST", body: body, contentType: "application/json")
        _ = try await perform(req)
    }

    func ft8CqAuto(active: Bool, msg: String, mode: String, audioFreqHz: Int,
                   myCall: String, myGrid: String) async throws {
        let payload: [String: Any] = ["active": active, "msg": msg, "mode": mode,
                                      "audio_freq": audioFreqHz, "my_call": myCall, "my_grid": myGrid]
        let body = try JSONSerialization.data(withJSONObject: payload)
        let req = try makeRequest(path: "/ft8/cq_auto", method: "POST", body: body, contentType: "application/json")
        _ = try await perform(req)
    }

    func ft8StartQso(firstMsg: String, dxCall: String, myCall: String, txMode: String,
                     audioFreqHz: Int, initialState: Int = 0, stepSnrMsg: String = "",
                     step2Msg: String = "", step3Msg: String = "", step4Msg: String = "") async throws {
        let payload: [String: Any] = [
            "first_msg": firstMsg, "dx_call": dxCall, "my_call": myCall,
            "tx_mode": txMode, "audio_freq": audioFreqHz, "initial_state": initialState,
            "step_snr_msg": stepSnrMsg, "step2_msg": step2Msg, "step3_msg": step3Msg, "step4_msg": step4Msg
        ]
        let body = try JSONSerialization.data(withJSONObject: payload)
        let req = try makeRequest(path: "/ft8/start_qso", method: "POST", body: body, contentType: "application/json")
        _ = try await perform(req)
    }

    func ft8CancelQso() async throws {
        let req = try makeRequest(path: "/ft8/cancel_qso", method: "POST", body: Data(), contentType: "application/json")
        _ = try await perform(req)
    }

    func ft8SetDepth(_ depth: Int) async throws {
        let req = try makeRequest(path: "/ft8/set_depth",
                                  query: [URLQueryItem(name: "depth", value: String(depth))],
                                  method: "POST", body: Data(), contentType: "text/plain")
        _ = try await perform(req)
    }

    func ft8SetFt4(_ isFt4: Bool) async throws {
        let req = try makeRequest(path: "/ft8/set_ft4",
                                  query: [URLQueryItem(name: "is_ft4", value: isFt4 ? "true" : "false")],
                                  method: "POST", body: Data(), contentType: "text/plain")
        _ = try await perform(req)
    }

    func ft8SetTxGain(_ gain: Float) async throws {
        let req = try makeRequest(path: "/ft8/set_tx_gain",
                                  query: [URLQueryItem(name: "gain", value: String(gain))],
                                  method: "POST", body: Data(), contentType: "text/plain")
        _ = try await perform(req)
    }

    func ft8SetDecodeFilter(freqs: [Int], bw: Int = 150) async throws {
        let payload: [String: Any] = ["freqs": freqs, "range": bw]
        let body = try JSONSerialization.data(withJSONObject: payload)
        let req = try makeRequest(path: "/ft8/set_decode_filter", method: "POST", body: body, contentType: "application/json")
        _ = try await perform(req)
    }

    func ft8DecodeDebug() async throws -> String {
        let req = try makeRequest(path: "/ft8/decode_debug")
        let (data, _) = try await perform(req)
        return String(data: data, encoding: .utf8) ?? ""
    }
}


