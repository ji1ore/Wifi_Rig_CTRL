package com.ji1ore.wifi_rig_ctrl

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.ji1ore.wifi_rig_ctrl.data.SAMPLING_RATES
import com.ji1ore.wifi_rig_ctrl.databinding.FragmentRttyBinding
import com.ji1ore.wifi_rig_ctrl.viewmodel.MainViewModel
import kotlinx.coroutines.*
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.sqrt

class RttyFragment : Fragment() {

    private var _binding: FragmentRttyBinding? = null
    private val binding get() = _binding!!
    private val vm: MainViewModel by activityViewModels()

    private var preMode  = ""
    private var preWidth = 0

    private var isRttyR = false   // false=RTTY, true=RTTYR
    private var pttActive = false
    private var txJob: Job? = null


    @Volatile private var modem: RttyModem? = null
    private var recorder: AudioRecord? = null
    private var rxJob: Job? = null
    private val rxSpan = SpannableStringBuilder()
    @Volatile private var usingPiAudio = false
    private var rttyStartedAudio = false

    // Peak detection
    private companion object { const val PEAK_BUF_SIZE = 2048 }
    private var peakBuf = ShortArray(PEAK_BUF_SIZE)
    private var peakPos = 0
    private var detectedMarkHz  = 0.0
    private var detectedSpaceHz = 0.0
    private var lastMarkHz  = 2125.0   // persists across modem restarts
    private var lastSpaceHz = 2295.0
    // Auto-tune hysteresis: the candidate pair, how many consecutive analyses it has held,
    // and when the modem was last retuned. See the auto-tune block in startRx().
    private var candMarkHz   = 0.0
    private var candSpaceHz  = 0.0
    private var candCount    = 0
    private var lastRetuneMs = 0L
    /** When a convincing tone pair was last seen; drives the fall-back to the standard tones. */
    private var lastPairSeenMs = System.currentTimeMillis()
    /**
     * Fix mode. Long-press the Tune button to toggle. While fixed, auto-tune and the fall-back
     * to the standard tones are off, and the decode position moves only when the operator taps
     * the waterfall. Persisted so a fixed setting survives leaving the screen.
     */
    private var tuneFixed: Boolean
        get() = vm.prefs.rttyTuneFixed
        set(v) { vm.prefs.rttyTuneFixed = v }
    private var currentBaud = 45.45
    @Volatile private var rxLevelDb: Int = -100
    private var logChunkCount = 0

    private val recordPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startRx() else updateStatus("RECORD_AUDIO permission denied")
    }

    // --- Lifecycle ---

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentRttyBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Save pre-RTTY mode
        preMode  = vm.sharedMode.value  ?: ""
        preWidth = vm.sharedWidth.value ?: 0

        // Keep screen on
        requireActivity().window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Observe freq / mode from rig
        updateFreqDisplay(vm.sharedFreq.value ?: 0L)
        vm.sharedFreq.observe(viewLifecycleOwner) { updateFreqDisplay(it) }
        binding.tvMode.text = vm.sharedMode.value?.takeIf { it.isNotEmpty() } ?: "---"
        vm.sharedMode.observe(viewLifecycleOwner) { binding.tvMode.text = it.ifEmpty { "---" } }

        setupButtons()
        binding.tvFreq.setOnClickListener { showFreqDialog() }

        // Waterfall: show initial markers, wire touch → update modem decode frequency
        binding.rttyWaterfall.setMarkers(lastMarkHz, lastSpaceHz)
        binding.rttyWaterfall.onDecodeFreqSelected = { mark, space ->
            // Only in Fix mode. In Tune mode the auto-tuner owns the decode position and
            // would immediately override a tap.
            if (tuneFixed) {
                lastMarkHz = mark; lastSpaceHz = space
                modem?.updateFrequencies(mark, space)
                binding.rttyWaterfall.setMarkers(mark, space)
                updateTuneButton()
                updateStatus("FIX: ${mark.toInt()} / ${space.toInt()} Hz")
            } else {
                updateStatus("Tune長押しでFIXにするとタップで位置を移動できます")
            }
        }
        updateTuneButton()

        // Set rig to RTTY mode on entry
        applyRigMode()

        // Auto-start Pi audio stream for RTTY if SPK is not already on
        rttyStartedAudio = !vm.audio.isStreamActive && vm.spkEnabled.value != true
        if (rttyStartedAudio) vm.startAudio()

        // Start receiver
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED) {
            startRx()
        } else {
            recordPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    override fun onResume() {
        super.onResume()
        requireActivity().window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onPause() {
        super.onPause()
        requireActivity().window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        stopRx()
        cancelTx()
        if (pttActive) vm.setPttEnabled(false)
        // Stop Pi audio only if RTTY started it (SPK was off)
        if (rttyStartedAudio && vm.spkEnabled.value != true) {
            vm.audio.stop()
            rttyStartedAudio = false
        }
        // Restore previous mode
        if (preMode.isNotEmpty()) vm.sendMode(preMode, preWidth)
        _binding = null
    }

    // --- UI setup ---

    private fun setupButtons() {
        binding.btnBack.setOnClickListener { findNavController().popBackStack() }

        binding.btnRttyR.setOnClickListener {
            isRttyR = !isRttyR
            binding.btnRttyR.text = if (isRttyR) "RTTYR" else "RTTY"
            applyRigMode()
            // Swap mark/space to invert polarity for RTTYR
            val tmp = lastMarkHz; lastMarkHz = lastSpaceHz; lastSpaceHz = tmp
            modem?.updateFrequencies(lastMarkHz, lastSpaceHz)
            binding.rttyWaterfall.setMarkers(lastMarkHz, lastSpaceHz)
            updateStatus(if (isRttyR) "RTTYR" else "RTTY")
        }

        binding.btnBaud.setOnClickListener {
            // Future: baud rate selection. For now toggle 45.45 / 75
            val newBaud = if (modem?.baudRate == 45.45) 75.0 else 45.45
            restartModem(newBaud)
            binding.btnBaud.text = if (newBaud == 45.45) "45.45bd" else "75bd"
        }

        binding.btnClear.setOnClickListener {
            rxSpan.clear()
            binding.tvRx.text = ""
        }

        setupPresets()
        binding.btnTx.setOnClickListener { startTx() }
        // Tap: jump to the detected pair (Tune mode only). Long-press: toggle FIX, which
        // freezes the decode position where it is, stops auto-tune and the standard-tone
        // fall-back, and lets a tap on the waterfall move it instead. Long-press again to
        // hand control back to the auto-tuner.
        binding.btnTune.setOnClickListener { applyTune() }
        binding.btnTune.setOnLongClickListener { toggleTuneFixed(); true }

        binding.btnPtt.setOnClickListener {
            if (txJob?.isActive == true) {
                cancelTx()
            } else {
                toggleManualPtt()
            }
        }

        binding.etTx.setOnEditorActionListener { _, _, _ -> startTx(); true }
    }

    // --- Preset messages ---

    private fun setupPresets() {
        val call = vm.prefs.ft8MyCall.uppercase().ifEmpty { "MYCALL" }
        val presets = listOf(
            binding.btnPresetCq  to "CQ CQ CQ DE $call $call K",
            binding.btnPresetRst to "UR 599 $call $call K",
            binding.btnPresetTu  to "TU 73 DE $call K",
            binding.btnPresetQrz to "QRZ DE $call K",
            binding.btnPresetBk  to "BK",
            binding.btnPresetAgn to "PSE AGN",
            binding.btnPresetDe  to "DE $call"
        )
        for ((btn, text) in presets) {
            btn.setOnClickListener { binding.etTx.setText(text) }
        }
    }

    // --- Rig mode ---

    private fun applyRigMode() {
        val mode = if (isRttyR) "RTTYR" else "RTTY"
        vm.sendMode(mode, 0)
        updateStatus("Mode: $mode")
    }

    // --- RX ---

    private fun startRx() {
        peakPos = 0
        val sIdx = vm.selectedSamplingIndex.value ?: 1
        val selectedRate = SAMPLING_RATES.getOrElse(sIdx) { 8000 }.let { if (it == 0) 8000 else it }

        // setPttEnabled(true) calls audio.stop() — restart Pi audio if RTTY owns it
        if (rttyStartedAudio && !vm.audio.isStreamActive) vm.startAudio()

        // Use the rate of the already-running stream (e.g. SPK was on before entering RTTY).
        // selectedSamplingIndex may differ from the running rate and would cause a mismatch.
        val piRate = if (vm.audio.isStreamActive && vm.audio.currentSampleRate > 0)
            vm.audio.currentSampleRate else selectedRate

        usingPiAudio = vm.audio.isStreamActive
        val initialRate = if (usingPiAudio) piRate else 8000
        Log.d("RTTY", "startRx: usingPiAudio=$usingPiAudio piRate=$piRate streamActive=${vm.audio.isStreamActive} currentRate=${vm.audio.currentSampleRate} modemRate=$initialRate")
        modem = RttyModem(
            sampleRate = initialRate,
            baudRate = currentBaud, markHz = lastMarkHz, spaceHz = lastSpaceHz
        ) { ch -> activity?.runOnUiThread { appendRx(ch) } }

        // Wire audioSampleListener. The running stream's own rate is the ground truth, so
        // it is read here rather than predicted in advance: startAudio() above is async,
        // so at this point the stream is usually not up yet and piRate is only the
        // sampling setting. If the stream then runs at a different rate, the Goertzel
        // coefficients sit on the wrong frequencies — the tones still show in the
        // waterfall, but nothing decodes.
        vm.audio.audioSampleListener = { shorts ->
            val streamRate = vm.audio.currentSampleRate.takeIf { it > 0 } ?: piRate
            if (!usingPiAudio) {
                usingPiAudio = true
                rxJob?.cancel(); rxJob = null
                val r = recorder; recorder = null
                r?.stop(); r?.release()
                updateStatus("RX (Pi)")
            }
            if (modem?.sampleRate != streamRate) {
                modem = RttyModem(
                    sampleRate = streamRate, baudRate = currentBaud,
                    markHz = lastMarkHz, spaceHz = lastSpaceHz
                ) { ch -> activity?.runOnUiThread { appendRx(ch) } }
                Log.d("RTTY", "modem (re)built at stream rate=$streamRate (piRate was $piRate)")
            }
            // Rate-limited diagnostic: log audio level every ~80 chunks
            if (++logChunkCount % 80 == 0) {
                val sq = shorts.sumOf { it.toDouble() * it.toDouble() }
                val rms = sqrt(sq / shorts.size) / 32768.0
                val db = if (rms > 1e-10) log10(rms).times(20).toInt() else -100
                Log.d("RTTY", "Pi audio: ${shorts.size}smp ${db}dB usingPi=$usingPiAudio modem=${modem?.sampleRate}Hz")
            }
            modem?.feed(shorts, shorts.size)
            processForWaterfall(shorts, shorts.size, streamRate)
        }

        if (usingPiAudio) {
            updateStatus("RX (Pi)")
            return
        }

        // Pi not yet active: start phone microphone as fallback
        val sampleRate = 8000
        val minBuf = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val rec = AudioRecord(
            MediaRecorder.AudioSource.MIC, sampleRate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minBuf, sampleRate / 2 * 2)
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            updateStatus("AudioRecord init failed")
            return
        }
        recorder = rec
        rec.startRecording()
        updateStatus("RX (MIC)")

        rxJob = lifecycleScope.launch(Dispatchers.IO) {
            val buf = ShortArray(minBuf / 2)
            while (isActive && !usingPiAudio) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) continue
                if (!usingPiAudio) {
                    modem?.feed(buf, n)
                    processForWaterfall(buf, n, sampleRate)
                }
            }
        }
    }

    private fun processForWaterfall(buf: ShortArray, n: Int, sampleRate: Int) {
        var src = 0; var rem = n
        while (rem > 0) {
            val take = minOf(rem, PEAK_BUF_SIZE - peakPos)
            buf.copyInto(peakBuf, peakPos, src, src + take)
            peakPos += take; src += take; rem -= take
            if (peakPos >= PEAK_BUF_SIZE) {
                peakPos = 0
                val snap   = peakBuf.copyOf()
                val sq     = snap.sumOf { it.toDouble() * it.toDouble() }
                val rms    = sqrt(sq / PEAK_BUF_SIZE.toDouble()) / 32768.0
                rxLevelDb  = if (rms > 1e-10) log10(rms).times(20).toInt() else -100
                val powers = RttyModem.scanPowers(snap, PEAK_BUF_SIZE, sampleRate)
                val peaks  = RttyModem.findPeaks(powers)
                lifecycleScope.launch(Dispatchers.Main) {
                    if (_binding != null) binding.rttyWaterfall.addRow(powers)
                    updatePeakDisplay(peaks)
                    // Auto-tune, with hysteresis. Every retune resets the demodulator and
                    // abandons the frame in progress, so chasing each momentary peak costs
                    // more characters than it saves. findPeaks already rejects noise and
                    // sidelobes; on top of that the same pair must be seen in three
                    // consecutive analyses, must differ from the current tuning by more than
                    // one scan bin, and retunes are spaced at least two seconds apart.
                    // RTTYR: higher peak = mark, lower = space (same as iOS RttyView).
                    if (peaks != null) {
                        val lo = peaks.first; val hi = peaks.second
                        val m = if (isRttyR) hi else lo
                        val s = if (isRttyR) lo else hi
                        val moved = abs(m - lastMarkHz) > 25 || abs(s - lastSpaceHz) > 25
                        if (moved) {
                            if (abs(m - candMarkHz) <= 25 && abs(s - candSpaceHz) <= 25) candCount++
                            else { candMarkHz = m; candSpaceHz = s; candCount = 1 }
                        } else {
                            candCount = 0
                        }
                        val nowMs = System.currentTimeMillis()
                        lastPairSeenMs = nowMs
                        if (!tuneFixed && moved && candCount >= 3 && nowMs - lastRetuneMs >= 2_000L) {
                            lastMarkHz = m; lastSpaceHz = s
                            lastRetuneMs = nowMs; candCount = 0
                            modem?.updateFrequencies(m, s)
                            if (_binding != null) binding.rttyWaterfall.setMarkers(m, s)
                        }
                    } else {
                        candCount = 0
                        // No convincing signal. If the modem was retuned away from the
                        // standard tones and the signal that justified it has been gone for a
                        // while, go back to the standard pair. Without this a single retune to
                        // a slightly off-frequency station stuck for the rest of the session:
                        // the iOS log showed decodeAt=2200/2380 persisting through a
                        // transmission that actually arrived at 2125/2295, 75 Hz off and about
                        // 1.6 Goertzel bins wide of each tone, which decoded with errors while
                        // the rig's own demodulator read the same signal cleanly.
                        val stdMark  = if (isRttyR) RttyModem.TX_SPACE_HZ else RttyModem.TX_MARK_HZ
                        val stdSpace = if (isRttyR) RttyModem.TX_MARK_HZ  else RttyModem.TX_SPACE_HZ
                        val offStandard = abs(lastMarkHz - stdMark) > 25 || abs(lastSpaceHz - stdSpace) > 25
                        val nowMs = System.currentTimeMillis()
                        if (!tuneFixed && offStandard && nowMs - lastPairSeenMs >= 5_000L) {
                            lastMarkHz = stdMark; lastSpaceHz = stdSpace
                            lastRetuneMs = nowMs; lastPairSeenMs = nowMs
                            modem?.updateFrequencies(stdMark, stdSpace)
                            if (_binding != null) binding.rttyWaterfall.setMarkers(stdMark, stdSpace)
                            Log.d("RTTY", "no signal for 5 s — back to standard ${stdMark.toInt()}/${stdSpace.toInt()}")
                        }
                    }
                }
            }
        }
    }

    private fun stopRx() {
        vm.audio.audioSampleListener = null  // always clear so Pi audio doesn't stale-feed a gone modem
        usingPiAudio = false
        rxJob?.cancel(); rxJob = null
        recorder?.stop(); recorder?.release(); recorder = null
    }

    private fun updatePeakDisplay(peaks: Pair<Double, Double>?) {
        if (_binding == null) return
        val lvl = rxLevelDb.let { if (it > -100) "  ${it}dB" else "" }
        if (peaks != null) {
            detectedMarkHz  = peaks.first
            detectedSpaceHz = peaks.second
            binding.tvPeakFreq.text = "${peaks.first.toInt()} / ${peaks.second.toInt()} Hz$lvl"
            binding.btnTune.isEnabled = true
        } else {
            binding.tvPeakFreq.text = "--- / --- Hz$lvl"
            // In Fix mode the button must stay usable so the long-press can release it.
            binding.btnTune.isEnabled = tuneFixed
        }
    }

    /** Long-press handler for the Tune button: enter or leave Fix mode. */
    private fun toggleTuneFixed() {
        tuneFixed = !tuneFixed
        candCount = 0
        lastPairSeenMs = System.currentTimeMillis()
        updateTuneButton()
        updateStatus(
            if (tuneFixed) "FIX: ${lastMarkHz.toInt()} / ${lastSpaceHz.toInt()} Hz — タップで移動、長押しで解除"
            else "Tune: 自動追従に戻しました"
        )
    }

    private fun updateTuneButton() {
        if (_binding == null) return
        binding.btnTune.text = if (tuneFixed) "FIX ${lastMarkHz.toInt()}/${lastSpaceHz.toInt()}" else "Tune"
        binding.btnTune.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (tuneFixed) 0xFF5A3A00.toInt() else 0xFF1A2A0A.toInt())
        if (tuneFixed) binding.btnTune.isEnabled = true
    }

    private fun applyTune() {
        if (tuneFixed) return   // the position is frozen; long-press to release it first
        val m = modem ?: return
        if (detectedMarkHz <= 0 || detectedSpaceHz <= 0) return
        lastMarkHz  = detectedMarkHz
        lastSpaceHz = detectedSpaceHz
        m.updateFrequencies(lastMarkHz, lastSpaceHz)
        binding.rttyWaterfall.setMarkers(lastMarkHz, lastSpaceHz)
        updateStatus("Tuned: ${lastMarkHz.toInt()} / ${lastSpaceHz.toInt()} Hz")
    }

    private fun restartModem(newBaud: Double) {
        currentBaud = newBaud
        stopRx()
        startRx()
    }

    private fun appendRx(ch: Char) {
        if (_binding == null) return
        if (rxSpan.length > 8000) rxSpan.delete(0, rxSpan.length - 6000)
        val ss = SpannableString(ch.toString())
        ss.setSpan(ForegroundColorSpan(Color.GREEN), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        rxSpan.append(ss)
        binding.tvRx.text = rxSpan
        binding.scrollRx.post { binding.scrollRx.fullScroll(View.FOCUS_DOWN) }
    }

    // --- TX mode ---


    /**
     * The transmit path, always decided automatically: CI-V when the radio is reached
     * directly, otherwise AFSK audio through the Pi.
     *
     * There used to be a selector that also offered serial FSK keying. Neither rig here can
     * use it. The IC-705 has no external FSK shift input, since its USB ports are CDC-ACM, so
     * toggling DTR keys nothing while the Pi still returns HTTP 200. The FT-991A does accept
     * DTR as FSK shift, but the Pi times the keying in software and every DTR change costs a
     * USB control transfer of 15-50 ms against a 22 ms bit period at 45.45 baud. Measured for
     * 27 characters, where 5.3 s was expected: 8.2, 15.1, 18.2, 30.5 s. It also saturated the
     * shared CP2105 and starved rigctld's polling, taking CAT control down for about 16 s each
     * time. There was nothing worth choosing, so the selector is gone.
     */
    private fun resolvedTxMode(): String = if (vm.useCIV.value == true) "civ" else "pi_afsk"

    /**
     * The rig's DATA-mode audio reference tone, in Hz: the audio frequency that its data-mode
     * dial reading actually refers to. Subtracted from the mark offset.
     *
     * The app's model is that in PKTLSB the displayed frequency *is* the suppressed carrier, so
     * an audio tone f lands at `display - f` and the dial has to sit one mark tone above the
     * RTTY mark. That holds on the IC-705, which transmitted RTTY on frequency with no
     * correction at all.
     *
     * The FT-991A's DATA SHIFT menu makes its dial refer to a 1000 Hz audio tone instead of the
     * carrier, the convention PSK31 uses. A tone f therefore lands at `display - f + 1000` and
     * the dial must sit only `2125 - 1000` above the RTTY mark, not the full 2125. The CAT path
     * was already correct when this was found: the frequency read back as exactly the
     * 144.602125 the app asked for, which rules out a control bug and leaves the rig's own
     * shift as the only candidate.
     *
     * The sign was wrong on the first attempt. Adding this value instead of subtracting it made
     * the error larger, which is what settled the direction: the original observation that
     * 144.601 decoded while 144.600 did not was the *receiver* being retuned up to meet a
     * signal already transmitting 1000 Hz high, not the transmitter needing to go up.
     *
     * Setting that menu to 0 on the rig makes this correction unnecessary, and then this should
     * be 0 too.
     */
    private fun dataShiftHz(): Long = when (
        (vm.rigList.value ?: emptyList()).getOrNull(vm.selectedRigIndex.value ?: 0)?.id
    ) {
        // FT-991A. 1000 Hz was the menu value and got the signal decoding; the receiver's
        // peak log then showed its mark arriving at about 2260 Hz instead of 2125, a residual
        // of +135 Hz in audio, which in LSB means the carrier was 135 Hz low. The space tone at
        // ~2430 Hz fell outside the IC-705's 500 Hz RTTY filter (about 1875–2375 Hz), which is
        // why that direction failed while the reverse was perfect. Raising the dial by 135 Hz
        // is the same as lowering this value by 135. The 20 Hz scan-bin resolution puts the
        // true value within roughly ±20 Hz of this.
        1035 -> 865L
        else -> 0L
    }

    // --- TX ---

    private fun startTx() {
        if (txJob?.isActive == true) return
        val text = binding.etTx.text.toString().trim()
        if (text.isEmpty()) return

        val resolved = resolvedTxMode()
        if (resolved == "civ" && vm.useCIV.value != true) {
            updateStatus("RTTY TX: CI-V未接続")
            return
        }
        // Refuse to transmit while the dial is unknown. sharedFreq is 0 whenever the control
        // link has dropped, and a transmission started then went out with no frequency or mode
        // command at all, on whatever the rig happened to be tuned to.
        if ((vm.sharedFreq.value ?: 0L) <= 0L) {
            updateStatus("TX: 周波数不明 — 接続が復帰するまで送信しません")
            return
        }

        txJob = lifecycleScope.launch(Dispatchers.IO) {
            stopRx()
            withContext(Dispatchers.Main) {
                setPttUi(true)
                val txLabel = "\n[TX] $text\n"
                val ss = SpannableString(txLabel)
                ss.setSpan(ForegroundColorSpan(Color.YELLOW), 0, txLabel.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                if (rxSpan.length > 8000 - txLabel.length)
                    rxSpan.delete(0, rxSpan.length - (6000 - txLabel.length).coerceAtLeast(0))
                rxSpan.append(ss)
                binding.tvRx.text = rxSpan
                binding.scrollRx.post { binding.scrollRx.fullScroll(View.FOCUS_DOWN) }
            }
            pttActive = true
            try {
                run {
                    // RS-BA1 CI-V audio is fixed at 8 kHz. The Pi path uses 48 kHz, the native
                    // rate of the rig's USB codec, so ALSA's plug layer has nothing to
                    // resample. At 8 kHz the Pi ran aplay through plughw, whose rate converter
                    // is a linear interpolator: fine for voice, but interpolating the 2125 and
                    // 2295 Hz tones up to the codec rate adds harmonics and images inside the
                    // SSB passband, which puts a dirty, undecodable signal on the air.
                    val txRate = if (vm.useCIV.value == true) 8000 else 48000
                    val encoder = RttyModem(txRate, RttyModem.TX_MARK_HZ, RttyModem.TX_SPACE_HZ, currentBaud) { }
                    val samples = encoder.encode(text)
                    val txMode = if (isRttyR) "PKTUSB" else "PKTLSB"
                    val rxMode = if (isRttyR) "RTTYR" else "RTTY"
                    val rxFreq = vm.sharedFreq.value ?: 0L
                    val markOffsetHz = RttyModem.TX_MARK_HZ.toLong()
                    val totalOffset = markOffsetHz - dataShiftHz()
                    val txFreq = if (rxFreq > 0L) {
                        if (isRttyR) rxFreq - totalOffset else rxFreq + totalOffset
                    } else 0L
                    // streamRttyTx picks CI-V or the Pi audio path from the connection type,
                    // so name whichever one is actually about to run.
                    val pathName = if (vm.useCIV.value == true) "CIV" else "AFSK-Pi"
                    Log.d("RTTY", "startTx $pathName: ${samples.size}smp @${txRate}Hz txMode=$txMode " +
                            "rxFreq=$rxFreq txFreq=$txFreq mark=$markOffsetHz dataShift=${dataShiftHz()} " +
                            "(${"%.1f".format(samples.size.toDouble() / txRate)}s)")
                    // Stand the Pi receive stream down for the transmission. stopRx() only
                    // clears the local listener and recorder; the HTTP stream keeps running.
                    // The Pi's /radio/audio_tx kills its capture processes before it starts
                    // aplay, so that stream dies anyway, and leaving it connected only means
                    // the app notices the death and starts reconnecting mid-transmission. On
                    // the single-core Pi that reconnect storm, each attempt spawning a fresh
                    // ffmpeg, competed with aplay and rigctld until /radio/status timed out and
                    // the control link was declared lost. Repeated transmit/receive cycles in
                    // RTTY dropped the connection this way.
                    val audioWasActive = vm.audio.isStreamActive
                    if (audioWasActive) withContext(Dispatchers.Main) { vm.stopAudio() }
                    vm.streamRttyTx(samples, txMode, rxMode, txFreq, rxFreq, txRate)
                    if (audioWasActive) withContext(Dispatchers.Main) { vm.startAudio() }
                }
            } finally {
                pttActive = false
                withContext(Dispatchers.Main) {
                    setPttUi(false)
                    binding.etTx.text?.clear()
                }
                startRx()
            }
        }
    }

    private fun cancelTx() {
        txJob?.cancel()
        txJob = null
        if (pttActive) { vm.setPttEnabled(false); pttActive = false }
        lifecycleScope.launch(Dispatchers.Main) { setPttUi(false) }
        lifecycleScope.launch(Dispatchers.IO) { startRx() }
    }

    private fun toggleManualPtt() {
        pttActive = !pttActive
        vm.setPttEnabled(pttActive)
        setPttUi(pttActive)
        updateStatus(if (pttActive) "TX (manual PTT)" else "RX")
    }

    private fun setPttUi(tx: Boolean) {
        binding.tvRxTx.text  = if (tx) "TX" else "RX"
        binding.tvRxTx.setTextColor(if (tx) 0xFFFF4444.toInt() else 0xFF44FF44.toInt())
        binding.btnPtt.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (tx) 0xFFD32F2F.toInt() else 0xFF6A1B9A.toInt()
        )
        binding.btnTx.isEnabled = !tx
        binding.btnTx.alpha     = if (tx) 0.4f else 1.0f
    }

    // suspend so delay() can wait for all samples to play before releasing the track.
    private suspend fun playAudio(samples: ShortArray, sampleRate: Int) {
        val bufBytes = samples.size * 2
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufBytes)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        track.write(samples, 0, samples.size)
        track.play()
        // Wait for the full message to play out before releasing.
        val durationMs = samples.size.toLong() * 1000L / sampleRate
        delay(durationMs + 200)
        track.stop()
        track.release()
    }

    // --- Frequency dialog ---

    private fun showFreqDialog() {
        val labels = arrayOf(
            "160m   1.838 MHz",
            " 80m   3.535 MHz (JP)", " 80m   3.580 MHz",
            " 40m   7.030 MHz (JP)", " 40m   7.035 MHz",
            " 30m  10.142 MHz",
            " 20m  14.080 MHz",      " 20m  14.090 MHz",
            " 17m  18.102 MHz",
            " 15m  21.080 MHz",
            " 12m  24.920 MHz",
            " 10m  28.080 MHz",
            "  6m  50.300 MHz",
            "  2m 144.600 MHz (JP)", "  2m 144.800 MHz",
            " 70c 430.600 MHz (JP)", " 70c 432.600 MHz"
        )
        val freqs = longArrayOf(
            1_838_000L,
            3_535_000L,  3_580_000L,
            7_030_000L,  7_035_000L,
            10_142_000L,
            14_080_000L, 14_090_000L,
            18_102_000L,
            21_080_000L,
            24_920_000L,
            28_080_000L,
            50_300_000L,
            144_600_000L, 144_800_000L,
            430_600_000L, 432_600_000L
        )
        val current = vm.sharedFreq.value ?: 0L
        val idx = freqs.indexOfFirst { it == current }.coerceAtLeast(-1)
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("RTTY Band")
            .setSingleChoiceItems(labels, idx) { dialog, which ->
                vm.sendFreq(freqs[which])
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // --- Helpers ---

    private fun updateStatus(msg: String) {
        activity?.runOnUiThread { _binding?.tvStatus?.text = msg }
    }

    private fun updateFreqDisplay(hz: Long) {
        if (hz <= 0L) { binding.tvFreq.text = "---.--- MHz"; return }
        val mhz = hz / 1_000_000.0
        binding.tvFreq.text = "%,.3f MHz".format(mhz)
    }
}
