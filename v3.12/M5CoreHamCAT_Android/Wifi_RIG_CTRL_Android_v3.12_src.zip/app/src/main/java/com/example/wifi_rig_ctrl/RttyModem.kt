package com.ji1ore.wifi_rig_ctrl

import kotlin.math.*

/**
 * Software AFSK RTTY modem.
 * RX: Goertzel-based mark/space detector → ITA2 (Baudot) state machine.
 * TX: generates continuous-phase FSK audio samples ready for AudioTrack.
 *
 * Standard parameters: mark=2125 Hz, space=2295 Hz, 45.45 baud, ITA2 encoding.
 */
class RttyModem(
    val sampleRate: Int = 8000,
    markHz: Double = 2125.0,
    spaceHz: Double = 2295.0,
    val baudRate: Double = 45.45,
    private val onChar: (Char) -> Unit
) {
    var markHz: Double = markHz
        private set
    var spaceHz: Double = spaceHz
        private set

    val samplesPerBit = (sampleRate / baudRate).roundToInt()

    // Goertzel coefficients (recomputed on updateFrequencies)
    private var markCoeff  = 2.0 * cos(2.0 * PI * markHz  / sampleRate)
    private var spaceCoeff = 2.0 * cos(2.0 * PI * spaceHz / sampleRate)

    /**
     * Full-bit circular buffer. The detector integrates over one whole bit, so the window
     * ending at sample X measures exactly the bit that ended at X.
     */
    private val halfStep = samplesPerBit / 2
    private val gbuf     = DoubleArray(samplesPerBit)
    private var gbWrite  = 0

    /**
     * How often the mark/space discriminator runs while hunting for a start bit. This sets
     * how precisely the start-bit edge can be placed, and therefore how well the data-bit
     * windows line up with the bits.
     */
    private val edgeStep = maxOf(1, samplesPerBit / 16)

    // Demodulator state
    private var lastIsMark = true  // MARK = idle tone

    private enum class FrameState { IDLE, DATA }
    private var frameState = FrameState.IDLE
    private var frameData  = 0
    private var isFigs     = false

    /** Running sample index. Bit sampling is scheduled against this. Long: an Int would
     *  wrap after about 12 hours of continuous 48 kHz audio. */
    private var total = 0L
    /** Next sample index at which to run the discriminator while idle. */
    private var nextEval = 0L
    /** Sample index at which the current bit should be sampled. */
    private var sampleAt = 0L
    /** Data bit being collected (0..4), then 5 for the stop bit. */
    private var bitIndex = 0
    /** Estimated sample index at which the start bit began. */
    private var startIndex = 0L

    init {
        // Let the integration buffer fill before trusting the discriminator.
        nextEval = samplesPerBit.toLong()
    }

    /**
     * Feed raw 16-bit PCM samples from AudioRecord. Thread-safe: call from a single thread.
     *
     * Bit sampling is scheduled on the running sample index, measured from the detected
     * start-bit edge. A free-running half-bit tick does not work here: the integration
     * window is a full bit, so whenever the tick grid happens to sit half a bit out of
     * phase with the start bit, every data-bit window straddles two adjacent bits and the
     * frame decodes to noise. That phase depends on where the character happens to fall in
     * the sample stream, so roughly half of all frames were corrupted.
     */
    fun feed(samples: ShortArray, count: Int = samples.size) {
        for (i in 0 until count) {
            gbuf[gbWrite] = samples[i] / 32768.0
            gbWrite = (gbWrite + 1) % samplesPerBit
            total++

            if (frameState == FrameState.IDLE) {
                if (total < nextEval) continue
                nextEval = total + edgeStep
                val isMark = goertzelMark()
                if (lastIsMark && !isMark) {
                    // The full-bit window reads half mark / half space exactly when the
                    // edge sits at its midpoint, so the transition is about half a bit
                    // behind the current sample.
                    startIndex = total - halfStep
                    frameState = FrameState.DATA
                    bitIndex   = 0
                    frameData  = 0
                    sampleAt   = startIndex + samplesPerBit * 2
                }
                lastIsMark = isMark
            } else {
                if (total < sampleAt) continue
                val isMark = goertzelMark()
                if (bitIndex < 5) {
                    // Frame layout in bit slots from the start of the start bit:
                    //   [0,1) start (space), [1,2)..[5,6) data bits 0..4, [6,7.5) stop (mark).
                    // Data bit k is sampled at the end of its slot, where the full-bit
                    // window covers exactly that bit. ITA2 is LSB first; mark = 1.
                    if (isMark) frameData = frameData or (1 shl bitIndex)
                    bitIndex++
                    sampleAt = startIndex + samplesPerBit * (bitIndex + 2)
                } else {
                    // Stop bit must be mark; anything else means this was a false start.
                    frameState = FrameState.IDLE
                    lastIsMark = isMark
                    nextEval   = total + edgeStep
                    if (isMark) decodeChar(frameData)
                }
            }
        }
    }

    private fun goertzelMark(): Boolean {
        var mq1 = 0.0; var mq2 = 0.0
        var sq1 = 0.0; var sq2 = 0.0
        var idx = gbWrite   // oldest sample
        repeat(samplesPerBit) {
            val s = gbuf[idx]; idx = (idx + 1) % samplesPerBit
            val qm = markCoeff  * mq1 - mq2 + s; mq2 = mq1; mq1 = qm
            val qs = spaceCoeff * sq1 - sq2 + s; sq2 = sq1; sq1 = qs
        }
        val mp = mq1 * mq1 + mq2 * mq2 - markCoeff  * mq1 * mq2
        val sp = sq1 * sq1 + sq2 * sq2 - spaceCoeff * sq1 * sq2
        return mp > sp
    }

    private fun decodeChar(code: Int) {
        when (code) {
            LTRS_SHIFT -> isFigs = false
            FIGS_SHIFT -> isFigs = true
            // Unshift on space, and on the two line-ending codes. Senders routinely fall
            // back to letters implicitly instead of transmitting another LTRS shift, and
            // without this a single figures shift invented by noise garbles every letter
            // that follows it until the next real LTRS: "ICOM" comes out as "8:9." while
            // stuck in figures.
            4 -> { isFigs = false; onChar(' ') }
            8 -> { isFigs = false; onChar('\r') }
            2 -> { isFigs = false; onChar('\n') }
            0 -> { /* NUL */ }
            else -> {
                val c = if (isFigs) FIGS[code] else LTRS[code]
                if (c != ' ') onChar(c)
            }
        }
    }

    fun reset() {
        lastIsMark = true
        frameState = FrameState.IDLE
        isFigs     = false
        frameData  = 0
        bitIndex   = 0
        nextEval   = total + samplesPerBit
    }

    /** Update mark/space frequencies. */
    fun updateFrequencies(newMarkHz: Double, newSpaceHz: Double) {
        markHz  = newMarkHz
        spaceHz = newSpaceHz
        markCoeff  = 2.0 * cos(2.0 * PI * markHz  / sampleRate)
        spaceCoeff = 2.0 * cos(2.0 * PI * spaceHz / sampleRate)
        // Clear the sample history so the new coefficients take effect immediately, and
        // hold the discriminator off until it refills. Any frame in progress is abandoned:
        // its remaining bits would be measured through a window that is part stale.
        gbuf.fill(0.0)
        gbWrite = 0
        frameState = FrameState.IDLE
        lastIsMark = true
        nextEval = total + samplesPerBit
    }

    // --- TX encoder ---

    /**
     * Encode [text] to 16-bit PCM AFSK samples at the modem's sample rate.
     * [amplitude] is in range 0..1 (default 0.8 = -2 dBFS).
     * Returns a ShortArray ready to write to AudioTrack.
     *
     * Build the instance with TX_MARK_HZ / TX_SPACE_HZ for transmission. Encoding with the
     * receive side's auto-tuned mark/space makes the transmitted frequency move a little on
     * every transmission, because those values follow the incoming signal.
     */
    fun encode(text: String, amplitude: Double = 0.8): ShortArray {
        val spb  = samplesPerBit
        val stop = (spb * 1.5).roundToInt()
        val buf  = ArrayList<Short>(text.length * (7 * spb + stop))
        var phase = 0.0
        var txFigs = false

        fun tone(isMark: Boolean, samples: Int) {
            val freq   = if (isMark) markHz else spaceHz
            val dPhase = 2.0 * PI * freq / sampleRate
            repeat(samples) {
                buf.add((sin(phase) * amplitude * Short.MAX_VALUE).toInt().toShort())
                phase += dPhase
            }
        }

        fun sendCode(code: Int) {
            tone(false, spb)                                         // start bit (SPACE)
            for (b in 0 until 5) tone((code shr b) and 1 == 1, spb)  // 5 data bits LSB-first
            tone(true, stop)                                         // stop bit (MARK, 1.5 bits)
        }

        // Leading MARK idle, about half a second, then the LTRS shift. Three bits was not
        // enough: the receiver needs a steady mark to settle its start-bit edge detector on
        // before real data arrives, and the transmitter's own attack eats the beginning.
        // Operators send a long idle here for exactly this reason.
        tone(true, spb * 24)

        // Sends a shift twice. Setting the shift is idempotent at the receiver, so the repeat
        // costs one character and makes a single lost character harmless. Losing a shift is
        // not harmless: every letter after it is looked up in the wrong table, so one dropped
        // character corrupts the rest of the message. Observed on the air as JI1ORE arriving
        // as JI143, where the LTRS after the 1 went missing and R and E were read from the
        // figures table as 4 and 3.
        fun sendShift(code: Int) { sendCode(code); sendCode(code) }

        sendShift(LTRS_SHIFT)

        for (c in text.uppercase()) {
            // Space and the two control codes mean the same thing in both shifts, so they
            // are sent directly. Looking them up in the tables would match a reserved slot
            // instead — space would match NUL at code 0, which the receiver discards, so
            // every space in the message was silently lost. They also clear the shift
            // state, because the receiver unshifts on them, so a figure following a space
            // needs a fresh FIGS shift.
            val direct = when (c) {
                ' '  -> 4
                '\n' -> 2
                '\r' -> 8
                else -> -1
            }
            if (direct >= 0) {
                sendCode(direct)
                txFigs = false
                continue
            }

            var code = -1
            var needFigs = false
            for (i in LTRS.indices) {
                if (i in RESERVED_CODES) continue
                if (LTRS[i] == c) { code = i; break }
            }
            if (code < 0) {
                for (i in FIGS.indices) {
                    if (i in RESERVED_CODES) continue
                    if (FIGS[i] == c) { code = i; needFigs = true; break }
                }
            }
            if (code < 0) continue

            if (needFigs && !txFigs) { sendShift(FIGS_SHIFT); txFigs = true }
            else if (!needFigs && txFigs) { sendShift(LTRS_SHIFT); txFigs = false }
            sendCode(code)
        }

        // Trailing MARK idle, about half a second, so the receiver has a clean stop bit after
        // the last character and nothing is lost to the PTT release transient.
        tone(true, spb * 24)
        return buf.toShortArray()
    }

    companion object {
        const val SCAN_LO   = 1200
        const val SCAN_HI   = 3200
        const val SCAN_STEP = 20
        const val SCAN_BINS = 101   // (SCAN_HI - SCAN_LO) / SCAN_STEP + 1

        /**
         * Standard AFSK RTTY tone pair: 2125 Hz mark with a 170 Hz shift.
         *
         * Transmission must always use these fixed values. The receive side retunes itself
         * to follow whatever is coming in, so its mark/space wander with the received
         * signal, and feeding those moving values into the encoder made the transmitted
         * frequency shift a little on every transmission. With fixed tones the transmit
         * frequency depends only on the dial. To answer a station that is off frequency,
         * move the dial.
         */
        const val TX_MARK_HZ  = 2125.0
        const val TX_SHIFT_HZ = 170.0
        const val TX_SPACE_HZ = TX_MARK_HZ + TX_SHIFT_HZ

        /** ITA2 shift codes. */
        const val FIGS_SHIFT = 27
        const val LTRS_SHIFT = 31

        /**
         * Slots that carry no printable letter or figure of their own: NUL, LF, SP, CR and
         * the two shifts. The encoder must not match a character against these.
         */
        val RESERVED_CODES = setOf(0, 2, 4, 8, 27, 31)

        /** Goertzel power scan over SCAN_LO..SCAN_HI at SCAN_STEP Hz intervals. */
        fun scanPowers(samples: ShortArray, count: Int, sampleRate: Int): DoubleArray {
            val powers = DoubleArray(SCAN_BINS)
            for (b in 0 until SCAN_BINS) {
                val f = SCAN_LO + b * SCAN_STEP
                val coeff = 2.0 * cos(2.0 * PI * f / sampleRate)
                var q1 = 0.0; var q2 = 0.0
                for (i in 0 until count) {
                    val q = coeff * q1 - q2 + samples[i] / 32768.0
                    q2 = q1; q1 = q
                }
                powers[b] = q1 * q1 + q2 * q2 - coeff * q1 * q2
            }
            return powers
        }

        /** Find two strongest peaks in a pre-computed power array. Returns (lowerHz, upperHz) or null. */
        /**
         * Finds a mark/space tone pair in a [scanPowers] spectrum, or null when there is no
         * convincing RTTY signal present.
         *
         * The previous version returned a pair for almost any input. It accepted the strongest
         * bin if it was five times the *mean* power, which the maximum of a hundred noise bins
         * exceeds routinely, and then took the next-strongest bin anywhere else as the partner
         * with no strength test at all. On noise that produced a random pair every analysis; on
         * a real signal whose space tone was attenuated it paired the mark with its own Goertzel
         * sidelobe 80 Hz away. The receiver then retuned to that pair several times a second,
         * resetting the demodulator each time, so the decoder never ran at the right frequencies
         * for long enough to read a character. Seen in the iOS log as a shift reading wandering
         * between 80 and 420 Hz while the actual signal sat at a steady 170.
         *
         * Four rules fix that. The partner is searched only where a real space tone can be, one
         * RTTY shift away on either side, so a bin next to the mark is never a candidate. The
         * partner must be a local maximum, so the smooth leakage skirt of a lone strong tone
         * does not qualify. The partner must be within 18 dB of the main peak, which keeps a
         * space tone attenuated by the rig's receive filter (the FT-991A case) while rejecting
         * leakage, which sits far below that. And the noise reference is *in-band*: the mean of
         * the bins near the main peak, excluding the two peaks themselves.
         *
         * That last rule matters more than it looks. A global median was tried first and failed
         * in practice: the rig's 500 Hz RTTY filter concentrates all the noise into about 25 of
         * the 101 scan bins, so the median comes from the near-silent out-of-band bins and every
         * in-band noise bump clears "8x the median". The iOS log showed pairs reported on pure
         * noise, mark readings scattered 1960-2320 Hz, exactly as before. Measured against the
         * local in-band mean instead, the maximum of ~25 noise bins is only 3-4x the mean, while
         * a real tone is far above it. Verified on synthetic band-limited noise: six noise-only
         * spectra all return null (the median rule returned a random pair for every one), and a
         * clean pair, a weak-space pair, an off-frequency pair and an inverted RTTY-R pair all
         * lock.
         */
        const val PAIR_SHIFT_HZ     = 170.0
        const val PAIR_SHIFT_TOL_HZ = 30.0
        const val PAIR_MAIN_SNR     = 8.0
        const val PAIR_PARTNER_SNR  = 4.0
        const val PAIR_MAX_RATIO    = 64.0
        const val PAIR_NOISE_SPAN   = 12      // bins either side of the main peak

        fun findPeaks(powers: DoubleArray): Pair<Double, Double>? {
            if (powers.size != SCAN_BINS) return null
            val peak1 = powers.indices.maxByOrNull { powers[it] } ?: return null

            val minBins = kotlin.math.floor((PAIR_SHIFT_HZ - PAIR_SHIFT_TOL_HZ) / SCAN_STEP).toInt()
            val maxBins = kotlin.math.ceil((PAIR_SHIFT_HZ + PAIR_SHIFT_TOL_HZ) / SCAN_STEP).toInt()
            fun isLocalMax(i: Int) =
                (i == 0 || powers[i] >= powers[i - 1]) &&
                (i == powers.size - 1 || powers[i] >= powers[i + 1])
            val peak2 = powers.indices
                .filter { val d = abs(it - peak1); d in minBins..maxBins && isLocalMax(it) }
                .maxByOrNull { powers[it] } ?: return null

            // In-band noise: bins around the main peak, minus the peaks and their neighbours.
            val nLo = maxOf(0, peak1 - PAIR_NOISE_SPAN); val nHi = minOf(powers.size - 1, peak1 + PAIR_NOISE_SPAN)
            var sum = 0.0; var n = 0
            for (i in nLo..nHi) if (abs(i - peak1) > 1 && abs(i - peak2) > 1) { sum += powers[i]; n++ }
            if (n == 0) return null
            val noise = sum / n
            if (noise <= 0.0) return null
            if (powers[peak1] < noise * PAIR_MAIN_SNR) return null
            if (powers[peak2] < noise * PAIR_PARTNER_SNR) return null
            if (powers[peak2] < powers[peak1] / PAIR_MAX_RATIO) return null

            val lo = minOf(peak1, peak2); val hi = maxOf(peak1, peak2)
            return Pair((SCAN_LO + lo * SCAN_STEP).toDouble(), (SCAN_LO + hi * SCAN_STEP).toDouble())
        }

        fun findPeaks(samples: ShortArray, count: Int, sampleRate: Int): Pair<Double, Double>? =
            findPeaks(scanPowers(samples, count, sampleRate))

        /**
         * Standard ITA2 letter assignments. These must match the wire codes other stations
         * send, so they are not free to rearrange: a table shifted by two positions decodes
         * a transmitted 'T' as 'C' and drops 'C' entirely.
         */
        val LTRS = charArrayOf(
            ' ', 'E', '\n', 'A', ' ', 'S', 'I', 'U',
            '\r', 'D', 'R', 'J', 'N', 'F', 'C', 'K',
            'T', 'Z', 'L', 'W', 'H', 'Y', 'P', 'Q',
            'O', 'B', 'G', ' ', 'M', 'X', 'V', ' '
        )
        /** US-TTY figures shift, as used on the amateur bands. */
        val FIGS = charArrayOf(
            ' ', '3', '\n', '-', ' ', ' ', '8', '7',
            '\r', '$', '4', '\'', ',', '!', ':', '(',
            '5', '"', ')', '2', '#', '6', '0', '1',
            '9', '?', '&', ' ', '.', '/', ';', ' '
        )
    }
}
