package com.ji1ore.wifi_rig_ctrl

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/**
 * Real-time RTTY signal strength graph for SCAN_LO..SCAN_HI Hz.
 * Replaces the scrolling waterfall — shows only the current spectrum frame as a filled bar chart.
 * Same public API as RttyWaterfallView: addRow(), setMarkers(), onDecodeFreqSelected.
 */
class RttySpectrumView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private val loHz = RttyModem.SCAN_LO.toDouble()
    private val hiHz = RttyModem.SCAN_HI.toDouble()
    private val bins = RttyModem.SCAN_BINS

    private var powers: DoubleArray = DoubleArray(bins)
    private var noiseEst = 1e-9
    private var peakEst  = 1e-6

    private val dp = context.resources.displayMetrics.density
    private val sp = context.resources.displayMetrics.scaledDensity

    private val barPaint = Paint().apply { isAntiAlias = false }
    private val linePaint = Paint().apply { isAntiAlias = true; strokeWidth = dp }
    private val peakPaint = Paint().apply {
        isAntiAlias = true; style = Paint.Style.STROKE; strokeWidth = dp * 1.5f
        color = 0xFF00FF88.toInt()
    }
    private val gridPaint = Paint().apply {
        isAntiAlias = false; strokeWidth = dp * 0.5f; color = 0x33FFFFFF
    }
    private val txtPaint  = Paint().apply { isAntiAlias = true; textSize = sp * 9f }
    private val path = Path()

    var markHz  = 2125.0; private set
    var spaceHz = 2295.0; private set

    var onDecodeFreqSelected: ((markHz: Double, spaceHz: Double) -> Unit)? = null

    fun addRow(pows: DoubleArray) {
        powers = pows.copyOf()
        val avg = pows.average()
        val mx  = pows.maxOrNull() ?: 0.0
        noiseEst = noiseEst * 0.95 + avg * 0.05
        peakEst  = if (mx > peakEst) peakEst * 0.5 + mx * 0.5 else peakEst * 0.995 + mx * 0.005
        invalidate()
    }

    fun setMarkers(mark: Double, space: Double) {
        markHz = mark; spaceHz = space; invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width; val h = height
        if (w <= 0 || h <= 0) return

        canvas.drawColor(0xFF000A0A.toInt())

        // Horizontal grid lines
        for (i in 1 until 4) {
            val y = h * i / 4f
            canvas.drawLine(0f, y, w.toFloat(), y, gridPaint)
        }

        val range = (peakEst - noiseEst).coerceAtLeast(1e-9)

        // Filled spectrum bars
        val bw = w.toFloat() / bins
        for (b in 0 until bins) {
            val norm = ((powers[b] - noiseEst) / range).toFloat().coerceIn(0f, 1f)
            val barH = norm * h
            val x = b * bw
            val hue = norm   // 0=blue, 0.5=cyan, 1=green/yellow
            barPaint.color = spectrumColor(norm)
            canvas.drawRect(x, h - barH, x + bw + 0.5f, h.toFloat(), barPaint)
        }

        // Peak outline (smooth line over top of bars)
        path.reset()
        var first = true
        for (b in 0 until bins) {
            val norm = ((powers[b] - noiseEst) / range).toFloat().coerceIn(0f, 1f)
            val x = (b + 0.5f) * bw
            val y = h - norm * h
            if (first) { path.moveTo(x, y); first = false } else path.lineTo(x, y)
        }
        canvas.drawPath(path, peakPaint)

        // Mark / space markers
        drawMarker(canvas, markHz,  0xFFFFDD00.toInt(), "M", w, h)
        drawMarker(canvas, spaceHz, 0xFF44FFFF.toInt(), "S", w, h)
    }

    private fun drawMarker(canvas: Canvas, hz: Double, color: Int, label: String, w: Int, h: Int) {
        val x = ((hz - loHz) / (hiHz - loHz) * w).toFloat()
        if (x < 0f || x > w) return
        linePaint.color = color
        canvas.drawLine(x, 0f, x, h.toFloat(), linePaint)
        txtPaint.color = color
        val lx = if (x + sp * 18 < w) x + dp * 2 else x - sp * 14
        canvas.drawText(label, lx, sp * 10 + dp * 2, txtPaint)
    }

    private fun spectrumColor(v: Float): Int {
        val c = v.coerceIn(0f, 1f)
        return when {
            c < 0.25f -> android.graphics.Color.rgb(0, (c / 0.25f * 80).toInt(), (c / 0.25f * 180).toInt())
            c < 0.50f -> { val t = (c - 0.25f) / 0.25f; android.graphics.Color.rgb(0, (80 + t * 140).toInt(), (180 - t * 60).toInt()) }
            c < 0.75f -> { val t = (c - 0.50f) / 0.25f; android.graphics.Color.rgb((t * 180).toInt(), 220, (120 - t * 120).toInt()) }
            else       -> { val t = (c - 0.75f) / 0.25f; android.graphics.Color.rgb(180 + (t * 75).toInt(), (255 - t * 100).toInt(), 0) }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_DOWN && e.action != MotionEvent.ACTION_MOVE) return false
        val shift = spaceHz - markHz
        val hz = loHz + e.x / width * (hiHz - loHz)
        markHz  = hz.coerceIn(loHz, hiHz - shift)
        spaceHz = markHz + shift
        onDecodeFreqSelected?.invoke(markHz, spaceHz)
        invalidate()
        return true
    }
}
