package com.ji1ore.wifi_rig_ctrl

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.sin

/**
 * Checks the RTTY modem against the published ITA2 assignments and against waveforms built
 * from standard code numbers, so it verifies interoperability with other stations rather
 * than only self-consistency. Mirrors the checks run on the iOS port.
 */
class RttyModemPortCheck {

    private val std = mapOf(
        'E' to 1, 'A' to 3, 'S' to 5, 'I' to 6, 'U' to 7, 'D' to 9, 'R' to 10, 'J' to 11,
        'N' to 12, 'F' to 13, 'C' to 14, 'K' to 15, 'T' to 16, 'Z' to 17, 'L' to 18,
        'W' to 19, 'H' to 20, 'Y' to 21, 'P' to 22, 'Q' to 23, 'O' to 24, 'B' to 25,
        'G' to 26, 'M' to 28, 'X' to 29, 'V' to 30
    )
    private val SP = 4
    private val LTRS = 31
    private val FIGS = 27

    /** Waveform built from explicit code numbers, independent of the modem's own tables. */
    private fun wave(
        codes: List<Int>, rate: Int, baud: Double,
        mark: Double = 2125.0, space: Double = 2295.0,
        noise: Double = 0.0, leadSamples: Int = 0
    ): ShortArray {
        val spb = (rate / baud).toInt()
        val stop = (spb * 1.5).toInt()
        val out = ArrayList<Short>()
        repeat(leadSamples) { out.add(0) }
        var phase = 0.0
        val rnd = java.util.Random(12345)
        fun tone(isMark: Boolean, n: Int) {
            val d = 2.0 * PI * (if (isMark) mark else space) / rate
            repeat(n) {
                var v = sin(phase) * 0.6
                if (noise > 0) v += (rnd.nextDouble() * 2.0 - 1.0) * noise
                out.add((v.coerceIn(-1.0, 1.0) * 32767).toInt().toShort())
                phase += d
            }
        }
        tone(true, spb * 3)
        for (c in codes) {
            tone(false, spb)
            for (b in 0 until 5) tone((c shr b) and 1 == 1, spb)
            tone(true, stop)
        }
        tone(true, spb * 3)
        return out.toShortArray()
    }

    private fun decode(pcm: ShortArray, rate: Int, baud: Double = 45.45): String {
        val sb = StringBuilder()
        val rx = RttyModem(rate, 2125.0, 2295.0, baud) { sb.append(it) }
        rx.feed(pcm)
        return sb.toString()
    }

    private fun codesFor(text: String): List<Int> {
        val out = ArrayList<Int>()
        out.add(LTRS)
        for (ch in text) out.add(if (ch == ' ') SP else std.getValue(ch))
        return out
    }

    @Test
    fun letterTableMatchesPublishedIta2() {
        val expected = charArrayOf(
            ' ', 'E', '\n', 'A', ' ', 'S', 'I', 'U',
            '\r', 'D', 'R', 'J', 'N', 'F', 'C', 'K',
            'T', 'Z', 'L', 'W', 'H', 'Y', 'P', 'Q',
            'O', 'B', 'G', ' ', 'M', 'X', 'V', ' '
        )
        for (i in 0 until 32) {
            assertEquals("letter code $i", expected[i], RttyModem.LTRS[i])
        }
        assertEquals(27, RttyModem.FIGS_SHIFT)
        assertEquals(31, RttyModem.LTRS_SHIFT)
    }

    @Test
    fun decodesWaveformBuiltFromStandardCodes() {
        val text = "CQ CQ DE TOKYO VY FB K"
        for (rate in listOf(8000, 16000, 22050, 44100)) {
            val got = decode(wave(codesFor(text), rate, 45.45), rate)
            assertEquals("rate $rate", text, got)
        }
    }

    @Test
    fun decodesDespiteNoise() {
        val text = "CQ DE TOKYO K"
        for (noise in listOf(0.0, 0.05, 0.15, 0.30)) {
            val got = decode(wave(codesFor(text), 16000, 45.45, noise = noise), 16000)
            assertEquals("noise $noise", text, got)
        }
    }

    /** The old decoder sampled on a free-running half-bit tick, so the result depended on
     *  where the character happened to land in the sample stream. */
    @Test
    fun decodeIsIndependentOfSignalTimingOffset() {
        val text = "CQ DE TOKYO K"
        for (lead in listOf(0, 11, 22, 44, 88, 131, 176, 263)) {
            val got = decode(wave(codesFor(text), 16000, 45.45, leadSamples = lead), 16000)
            assertEquals("offset $lead", text, got)
        }
    }

    /** A figures shift invented by noise must not garble the rest of the transmission. */
    @Test
    fun unshiftsOnSpaceAfterStrayFiguresShift() {
        val codes = ArrayList<Int>()
        codes.add(FIGS)
        for (ch in "ICOM ICOM K") codes.add(if (ch == ' ') SP else std.getValue(ch))
        val got = decode(wave(codes, 16000, 45.45), 16000)
        assertTrue("should recover after the first space, got '$got'",
                   got.endsWith("ICOM K"))
    }

    @Test
    fun decodesFiguresSentAfterASpace() {
        val codes = ArrayList<Int>()
        codes.add(LTRS)
        for (ch in "RST") codes.add(std.getValue(ch))
        codes.addAll(listOf(SP, FIGS, 16, 24, 24, SP, LTRS))   // "599 "
        for (ch in "QTH") codes.add(std.getValue(ch))
        assertEquals("RST 599 QTH", decode(wave(codes, 16000, 45.45), 16000))
    }

    @Test
    fun encoderRoundTripsIncludingSpacesAndFigures() {
        val msg = "RST 599 QTH TOKYO DE JA1ABC K"
        for (rate in listOf(8000, 16000, 44100)) {
            val tx = RttyModem(rate, RttyModem.TX_MARK_HZ, RttyModem.TX_SPACE_HZ, 45.45) { }
            val sb = StringBuilder()
            val rx = RttyModem(rate, RttyModem.TX_MARK_HZ, RttyModem.TX_SPACE_HZ, 45.45) {
                sb.append(it)
            }
            rx.feed(tx.encode(msg))
            assertEquals("rate $rate", msg, sb.toString())
        }
    }

    /** Transmission must not inherit the receive side's auto-tuned tones. */
    @Test
    fun transmitTonesAreTheFixedStandardPair() {
        assertEquals(2125.0, RttyModem.TX_MARK_HZ, 0.0)
        assertEquals(2295.0, RttyModem.TX_SPACE_HZ, 0.0)

        val tx = RttyModem(8000, RttyModem.TX_MARK_HZ, RttyModem.TX_SPACE_HZ, 45.45) { }
        val pcm = tx.encode("TEST")
        val powers = RttyModem.scanPowers(pcm.copyOfRange(0, 4096), 4096, 8000)
        val top = powers.indices.sortedByDescending { powers[it] }.take(2)
            .map { RttyModem.SCAN_LO + it * RttyModem.SCAN_STEP }.sorted()
        assertEquals("strongest tones in TX audio", listOf(2120, 2300), top)
    }
}
