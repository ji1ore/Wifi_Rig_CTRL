import Foundation
import Observation
import SwiftUI
import AVFoundation
import CoreLocation

// International Morse code table used for local sidetone generation in CW TX screen.
private let cwMorseTable: [Character: String] = [
    "A": ".-",   "B": "-...", "C": "-.-.", "D": "-..",
    "E": ".",    "F": "..-.", "G": "--.",  "H": "....",
    "I": "..",   "J": ".---", "K": "-.-", "L": ".-..",
    "M": "--",   "N": "-.",   "O": "---", "P": ".--.",
    "Q": "--.-", "R": ".-.",  "S": "...", "T": "-",
    "U": "..-",  "V": "...-", "W": ".--", "X": "-..-",
    "Y": "-.--", "Z": "--..",
    "0": "-----", "1": ".----", "2": "..---", "3": "...--",
    "4": "....-", "5": ".....", "6": "-....", "7": "--...",
    "8": "---..", "9": "----.",
    ".": ".-.-.-", ",": "--..--", "?": "..--..",
    "/": "-..-.",  "+": ".-.-.",  "=": "-...-",
    "!": "-.-.--", "@": ".--.-.", "'": ".----.",
    "(": "-.--.",  ")": "-.--.-", "&": ".-...",
    ";": "-.-.-.", ":": "---...", "-": "-....-",
]

enum AppRoute: Hashable {
    case rigSelect
    case mainControl
    case pttSettings
    case aprsSettings
    case ft8
    case profiles
    case bleKeyer
    case about
    case cw
    case admin
    case help
    case rtty
}

@MainActor
@Observable
final class MainViewModel {
    // Navigation
    var path: [AppRoute] = []

    // CW BLE keyer service — owned here so it survives navigation. Connects to DualKey-BLE
    // (AtomS3 BLE keyer) via Nordic UART Service and bridges packets to Pi over WiFi UDP.
    let cwBle = CwBleService()

    // Connection settings (persisted)
    var hostName: String = UserDefaults.standard.string(forKey: "hostName") ?? "raspberrypi.local"
    var apiPort: Int = UserDefaults.standard.integer(forKey: "apiPort").nonZeroOr(AppConstants.defaultApiPort)
    var audioPort: Int = UserDefaults.standard.integer(forKey: "audioPort").nonZeroOr(AppConstants.defaultAudioPort)
    /// IP literal captured from RigApiService after `configure`. Raw stream URLs
    /// (audio RX/TX, CW tone) are built outside the API actor, so they must use this
    /// instead of `hostName`: iOS 26 URLSession can fail to resolve `.local` names,
    /// which left the audio stream retrying silently while the API kept working.
    private var resolvedStreamHost: String = ""
    private var streamHost: String { resolvedStreamHost.isEmpty ? hostName : resolvedStreamHost }
    var apiKey: String = UserDefaults.standard.string(forKey: "apiKey") ?? ""
    /// First-launch: derive from hostName so the default `raspberrypi.local` toggles mDNS on.
    var useMDNS: Bool = {
        if UserDefaults.standard.object(forKey: "useMDNS") != nil {
            return UserDefaults.standard.bool(forKey: "useMDNS")
        }
        let host = UserDefaults.standard.string(forKey: "hostName") ?? "raspberrypi.local"
        return host.hasSuffix(".local")
    }()

    // PTT routing
    var useWifiPTT: Bool = UserDefaults.standard.bool(forKey: "useWifiPTT")
    var pttHost: String = UserDefaults.standard.string(forKey: "pttHost") ?? ""
    var pttPort: Int = UserDefaults.standard.integer(forKey: "pttPort").nonZeroOr(AppConstants.defaultPttPort)

    // CI-V: RS-BA1 direct IC-705/IC-7300/IC-9700 WiFi (bypasses Pi FastAPI)
    var useCivMode: Bool = UserDefaults.standard.bool(forKey: "useCivMode")
    var civHost: String = UserDefaults.standard.string(forKey: "civHost") ?? ""
    var civUsername: String = UserDefaults.standard.string(forKey: "civUsername") ?? "user"
    var civPassword: String = UserDefaults.standard.string(forKey: "civPassword") ?? ""
    var civPort1: Int = UserDefaults.standard.integer(forKey: "civPort1").nonZeroOr(50001)
    var civPort2: Int = UserDefaults.standard.integer(forKey: "civPort2").nonZeroOr(50002)
    var civPort3: Int = UserDefaults.standard.integer(forKey: "civPort3").nonZeroOr(50003)
    var civAddressHex: String = UserDefaults.standard.string(forKey: "civAddressHex") ?? "A4"
    var civError: String = ""
    var civConnected: Bool = false
    var civConnecting: Bool = false
    var civConnectStep: String = ""

    // Discovery
    var rigList: [RigInfo] = []
    var catList: [String] = []
    var soundDeviceList: [SoundDevice] = []
    var supportedModes: [String] = []

    // Selection (persisted — restored on launch + reconciled after server discovery)
    var selectedRigIndex: Int = 0
    var selectedCatIndex: Int = 0
    var selectedBaudIndex: Int = {
        let v = UserDefaults.standard.object(forKey: "selectedBaudIndex") as? Int
        let idx = v ?? AppConstants.defaultBaudIndex
        // Clamp: a stale/imported value beyond the current array would crash the
        // direct subscripts in RigSelectView / openSelectedRig (black-screen symptom).
        return AppConstants.baudRates.indices.contains(idx) ? idx : AppConstants.defaultBaudIndex
    }()
    var selectedSamplingIndex: Int = {
        let v = UserDefaults.standard.object(forKey: "selectedSamplingIndex") as? Int
        let idx = v ?? AppConstants.defaultSamplingIndex
        return AppConstants.samplingRates.indices.contains(idx) ? idx : AppConstants.defaultSamplingIndex
    }()
    var selectedPttDevice: String = UserDefaults.standard.string(forKey: "selectedPttDevice") ?? "NONE"
    var selectedPttType: PttType = PttType(rawValue: UserDefaults.standard.string(forKey: "selectedPttType") ?? "RTS") ?? .rts
    var selectedAudioCapture: String = UserDefaults.standard.string(forKey: "selectedAudioCapture") ?? ""
    var selectedAudioPlayback: String = UserDefaults.standard.string(forKey: "selectedAudioPlayback") ?? ""

    /// Last-used rig id (stable across restarts, used to restore `selectedRigIndex` after server discovery).
    private var savedRigId: Int = UserDefaults.standard.integer(forKey: "savedRigId")
    /// Last-used CAT device path.
    private var savedCatDevice: String = UserDefaults.standard.string(forKey: "savedCatDevice") ?? ""

    // Version mismatch flags
    var piVersionMismatch: Bool = false


    // Connection state
    var isConnectedToRig: Bool = false {
        didSet { if isConnectedToRig { applyPendingIfConnected() } }
    }
    var isBusy: Bool = false

    // SP2ALART連携: 接続前に受け取った周波数・モードをpendingとして保持
    private var pendingFreqHz: Int64 = 0
    private var pendingSpotMode: String? = nil

    func setPendingFreqMode(freqHz: Int64, spotMode: String) {
        pendingFreqHz = freqHz
        pendingSpotMode = spotMode
        applyPendingIfConnected()
    }

    private func applyPendingIfConnected() {
        guard isConnectedToRig,
              pendingFreqHz > 0,
              let spotMode = pendingSpotMode else { return }
        let freqHz = pendingFreqHz
        let upper = spotMode.uppercased().trimmingCharacters(in: .whitespaces)
        let isFt = upper == "FT8" || upper == "FT4"
        let (rawMode, width) = Self.mapSpotMode(spotMode, freqHz: freqHz)
        let rigMode = resolveMode(rawMode, freqHz: freqHz)
        pendingFreqHz = 0
        pendingSpotMode = nil
        if isFt { ft8IsFt4 = (upper == "FT4") }
        Task { @MainActor [weak self] in
            await self?.setMode(rigMode, width: width)
            await self?.setFreq(freqHz)
            guard let self else { return }
            if isFt && self.path.last != .ft8 { self.path.append(.ft8) }
        }
    }

    /** SSBモードをリグが持たない場合、周波数に応じて USB/LSB に変換する */
    func resolveMode(_ mode: String, freqHz: Int64) -> String {
        if mode.uppercased() == "SSB" &&
           !supportedModes.contains(where: { $0.uppercased() == "SSB" }) {
            return freqHz >= 10_000_000 ? "USB" : "LSB"
        }
        return mode
    }

    // POTAスポットモード → 無線機モード変換
    static func mapSpotMode(_ spotMode: String, freqHz: Int64) -> (String, Int) {
        func usbOrLsb() -> String { freqHz >= 10_000_000 ? "USB" : "LSB" }
        switch spotMode.uppercased().trimmingCharacters(in: .whitespaces) {
        case "CW", "CW-R":                                          return ("CW",        500)
        case "FM", "C4FM", "D-STAR", "DSTAR", "DMR":               return ("FM",      15000)
        case "AM":                                                   return ("AM",       6000)
        case "FT8", "FT4", "JS8", "RTTY", "PSK31",
             "PSKR", "DIGI", "MSK144":                              return (usbOrLsb(), 3000)
        case "SSB":                                                  return ("SSB",      3000)
        case "USB":                                                  return ("USB",      3000)
        case "LSB":                                                  return ("LSB",      3000)
        default:                                                     return (usbOrLsb(), 3000)
        }
    }
    var errorMessage: String?

    // MARK: - POTA/SOTA spot cache + hunter store (v3.01)

    var hunterStore = HunterStore()

    // Activator map keyed by uppercased BASE callsign (suffix after "/" stripped).
    // Populated when MemoryPotaView / MemorySotaView fetches live spots.
    private(set) var potaActivatorMap: [String: [PotaSpot]] = [:]
    private(set) var sotaActivatorSet: Set<String> = []

    func updatePotaCache(_ spots: [PotaSpot]) {
        var map: [String: [PotaSpot]] = [:]
        for spot in spots {
            let base = spot.activator.uppercased().components(separatedBy: "/").first ?? spot.activator.uppercased()
            map[base, default: []].append(spot)
        }
        potaActivatorMap = map
    }

    func updateSotaCache(_ spots: [SotaSpot]) {
        sotaActivatorSet = Set(spots.compactMap {
            $0.activatorCallsign?.uppercased().components(separatedBy: "/").first
        })
    }

    // Rig status (live)
    var sharedFreq: Int64 = 0
    var sharedMode: String = ""
    var sharedSignal: Double = 0       // S0..S15
    var sharedTx: Bool = false
    var sharedPower: Double = 0
    var sharedWidth: Int = 0
    var sharedSQL: Double = 0
    var sharedBkIn: Bool = false
    var sharedRfOut: Double = 0
    var sharedAlc: Double = 0

    // PTT/Audio toggles
    var txEnabled: Bool = false        // PTT armed?
    var spkEnabled: Bool = false
    var micGain: Float = UserDefaults.standard.float(forKey: "micGain").nonZeroOr(1.0)
    var sharedVolume: Double = 0.5     // not server-side; UI hint only for now

    // Editing step
    var selectedStepIndex: Int = 2  // 1 kHz

    // Display preferences (persisted)
    // -1=always on, 0=system default, 5/15/30/60=minutes until screen off (resets on poll activity)
    var screenTimeoutMinutes: Int = {
        let ud = UserDefaults.standard
        if let stored = ud.object(forKey: "screenTimeoutMinutes") as? Int { return stored }
        if let old = ud.object(forKey: "keepScreenAwake") as? Bool { return old ? -1 : 0 }
        return 15
    }()
    private var _lastActivityTime: Date = Date()
    private var _screenMonitorTask: Task<Void, Never>?

    // VFO state (v2.20)
    var vfoMode: String = ""      // "ab" | "mainsub"
    var vfoCurrentSide: String = ""  // "A"/"B" or "Main"/"M/S"/"S/M"

    // Repeater settings (persisted)
    var repeaterOffsetDir: String = UserDefaults.standard.string(forKey: "repeaterOffsetDir") ?? ""
    var repeaterOffsetHz: Int64 = Int64(UserDefaults.standard.integer(forKey: "repeaterOffsetHz"))
    var repeaterToneMode: String = UserDefaults.standard.string(forKey: "repeaterToneMode") ?? ""
    var repeaterToneHz: Double = (UserDefaults.standard.object(forKey: "repeaterToneHz") as? Double) ?? 0.0

    /// TX output frequency: RX freq ± repeater offset during transmit, else RX freq.
    var displayFreq: Int64 {
        guard txEnabled, !repeaterOffsetDir.isEmpty, repeaterOffsetHz > 0 else { return sharedFreq }
        return repeaterOffsetDir == "-" ? sharedFreq - repeaterOffsetHz : sharedFreq + repeaterOffsetHz
    }

    func setRepeater(toneMode: String, toneHz: Double, offsetDir: String, offsetHz: Int64) {
        repeaterOffsetDir = offsetDir; UserDefaults.standard.set(offsetDir, forKey: "repeaterOffsetDir")
        repeaterOffsetHz  = offsetHz;  UserDefaults.standard.set(Int(offsetHz), forKey: "repeaterOffsetHz")
        repeaterToneMode  = toneMode;  UserDefaults.standard.set(toneMode, forKey: "repeaterToneMode")
        repeaterToneHz    = toneHz;    UserDefaults.standard.set(toneHz, forKey: "repeaterToneHz")
    }

    func clearRepeater() { setRepeater(toneMode: "", toneHz: 0, offsetDir: "", offsetHz: 0) }

    var cwTxShiftHz: Int64 = 0
    var cwBaseFreqHz: Int64 = 0

    func setCwTxShift(_ shiftHz: Int64) {
        cwTxShiftHz = shiftHz
        if isDemoMode { return }
        if useCivMode {
            // CI-V mode: DUP+/DUP- interferes with CW TX — force Simplex
            if civ.isConnected { Task { civ.setTxShift(0) } }
            return
        }
        if shiftHz != 0 {
            if cwBaseFreqHz == 0 { cwBaseFreqHz = sharedFreq }
            let base = cwBaseFreqHz
            Task {
                do {
                    try await api.setTxShift(shiftHz: shiftHz)
                    try await api.setCwBaseFreq(freqHz: base)
                } catch { }
            }
        } else {
            cwBaseFreqHz = 0
            Task { do { try await api.setTxShift(shiftHz: 0) } catch { } }
        }
    }

    // APRS state (persisted where indicated)
    var aprsEnabled: Bool = UserDefaults.standard.bool(forKey: "aprsEnabled")
    var aprsCallsign: String = UserDefaults.standard.string(forKey: "aprsCallsign") ?? ""
    var aprsSSID: Int = UserDefaults.standard.integer(forKey: "aprsSSID")
    var aprsPath: String = UserDefaults.standard.string(forKey: "aprsPath") ?? "WIDE1-1"
    var aprsDestination: String = UserDefaults.standard.string(forKey: "aprsDestination") ?? "APRS00"
    var aprsSymbol: String = UserDefaults.standard.string(forKey: "aprsSymbol") ?? "/["
    var aprsIntervalSec: Int = UserDefaults.standard.integer(forKey: "aprsIntervalSec").nonZeroOr(60)
    var aprsBaud: Int = UserDefaults.standard.integer(forKey: "aprsBaud").nonZeroOr(1200)
    var aprsTxFreq: Double = (UserDefaults.standard.object(forKey: "aprsTxFreq") as? Double) ?? 144.660
    var aprsUseGPS: Bool = UserDefaults.standard.bool(forKey: "aprsUseGPS")
    var aprsManualLat: Double = (UserDefaults.standard.object(forKey: "aprsManualLat") as? Double) ?? 0.0
    var aprsManualLon: Double = (UserDefaults.standard.object(forKey: "aprsManualLon") as? Double) ?? 0.0
    var aprsSoundDevice: String = UserDefaults.standard.string(forKey: "aprsSoundDevice") ?? ""
    var aprsComment: String = UserDefaults.standard.string(forKey: "aprsComment") ?? ""
    var aprsActive: Bool = false
    var aprsCurrentLat: Double = 0
    var aprsCurrentLon: Double = 0

    // APRS rig modem state (v2.20, persisted)
    var aprsUseRigModem: Bool = UserDefaults.standard.bool(forKey: "aprsUseRigModem")
    var aprsModemSel: Int = UserDefaults.standard.integer(forKey: "aprsModemSel").nonZeroOr(2)
    var aprsPreset1Freq: Double = (UserDefaults.standard.object(forKey: "aprsPreset1Freq") as? Double) ?? 144.660
    var aprsPreset1Baud: Int = UserDefaults.standard.integer(forKey: "aprsPreset1Baud").nonZeroOr(9600)
    var aprsPreset2Freq: Double = (UserDefaults.standard.object(forKey: "aprsPreset2Freq") as? Double) ?? 144.660
    var aprsPreset2Baud: Int = UserDefaults.standard.integer(forKey: "aprsPreset2Baud").nonZeroOr(1200)
    var aprsAtPreset2: Bool = false   // true when AP12 (preset2) is active
    var aprsReceivedStations: [AprsStation] = []

    // Default filter widths (v2.31)
    var defaultSsbWidth: Int {
        get { UserDefaults.standard.integer(forKey: "defaultSsbWidth").nonZeroOr(3000) }
        set { UserDefaults.standard.set(newValue, forKey: "defaultSsbWidth") }
    }
    var defaultCwWidth: Int {
        get { UserDefaults.standard.integer(forKey: "defaultCwWidth").nonZeroOr(500) }
        set { UserDefaults.standard.set(newValue, forKey: "defaultCwWidth") }
    }

    func modeDefaultWidth(_ mode: String) -> Int {
        let m = mode.uppercased()
        if m == "FM" || m == "PKTFM" { return 12000 }
        if m == "FMN"                { return 9000 }
        if m.hasPrefix("CW")         { return defaultCwWidth }
        if m == "USB" || m == "LSB"  { return defaultSsbWidth }
        return 0
    }

    // FT8 settings (persisted)
    var ft8MyCall: String = UserDefaults.standard.string(forKey: "ft8MyCall") ?? ""
    var ft8MyGrid: String = UserDefaults.standard.string(forKey: "ft8MyGrid") ?? ""
    var ft8DxCall: String = UserDefaults.standard.string(forKey: "ft8DxCall") ?? ""
    var ft8LatencyMs: Int = UserDefaults.standard.integer(forKey: "ft8LatencyMs")
    var ft8TxMode: String = UserDefaults.standard.string(forKey: "ft8TxMode") ?? "USB"
    var ft8LastFreq: Int64 = Int64(UserDefaults.standard.integer(forKey: "ft8LastFreq"))
    var ft8IsFt4: Bool = UserDefaults.standard.bool(forKey: "ft8IsFt4")
    var ft8QsoLog: String = UserDefaults.standard.string(forKey: "ft8QsoLog") ?? "[]"
    var ft8PskReporter: Bool = (UserDefaults.standard.object(forKey: "ft8PskReporter") as? Bool) ?? true
    var ft8AudioFreqHz: Int = {
        let v = UserDefaults.standard.integer(forKey: "ft8AudioFreqHz")
        return v > 0 ? v : 1500
    }()
    var ft8DecodeDepth: Int = {
        let v = UserDefaults.standard.integer(forKey: "ft8DecodeDepth")
        return v > 0 ? v : 1
    }()
    var ft8AutoTxMode: String = UserDefaults.standard.string(forKey: "ft8AutoTxMode") ?? "even"
    var ft8Filter: Bool = UserDefaults.standard.bool(forKey: "ft8Filter")

    // CW settings (v2.02, persisted)
    var cwPort: String = UserDefaults.standard.string(forKey: "cwPort") ?? "ttyACM0"
    var cwDelayMs: Int = UserDefaults.standard.integer(forKey: "cwDelayMs")
    var cwFmDelayMs: Int = UserDefaults.standard.integer(forKey: "cwFmDelayMs")
    var cwSidetoneEnabled: Bool = (UserDefaults.standard.object(forKey: "cwSidetoneEnabled") as? Bool) ?? true
    var cwWpm: Int = UserDefaults.standard.integer(forKey: "cwWpm").nonZeroOr(20)
    var cwLastText: String = UserDefaults.standard.string(forKey: "cwLastText") ?? ""

    // CW TX operator screen state (persisted)
    var cwDxCall: String = UserDefaults.standard.string(forKey: "cwDxCall") ?? ""
    var cwRst: String = { let v = UserDefaults.standard.string(forKey: "cwRst") ?? ""; return v.isEmpty ? "599" : v }()
    var cwPota: String = UserDefaults.standard.string(forKey: "cwPota") ?? ""
    var cwJcc: String = UserDefaults.standard.string(forKey: "cwJcc") ?? ""
    var cwPttPoll: Bool = (UserDefaults.standard.object(forKey: "cwPttPoll") as? Bool) ?? false
    var cwCqRepeat: Int = max(1, min(3, UserDefaults.standard.integer(forKey: "cwCqRepeat").nonZeroOr(1)))
    var cwCqPota: Bool = (UserDefaults.standard.object(forKey: "cwCqPota") as? Bool) ?? false
    var cwCqJcc: Bool = (UserDefaults.standard.object(forKey: "cwCqJcc") as? Bool) ?? false
    var cwAnsGreeting: String = UserDefaults.standard.string(forKey: "cwAnsGreeting") ?? ""
    var cwAnsPota: Bool = (UserDefaults.standard.object(forKey: "cwAnsPota") as? Bool) ?? false
    var cwAnsJcc: Bool = (UserDefaults.standard.object(forKey: "cwAnsJcc") as? Bool) ?? false
    var cwQsl: String = UserDefaults.standard.string(forKey: "cwQsl") ?? ""
    var cwCqLoopCount: Int = UserDefaults.standard.integer(forKey: "cwCqLoopCount")  // 0=∞
    var cwCqLoopInterval: Int = UserDefaults.standard.integer(forKey: "cwCqLoopInterval").nonZeroOr(15)
    var cwRstRepeat: Int = max(1, min(3, UserDefaults.standard.integer(forKey: "cwRstRepeat").nonZeroOr(1)))
    var cwCqTabActive: Bool = true
    var cwCqRepeating: Bool = false
    var cwCqRepeatStatus: String = ""
    private var cwCqRepeatTask: Task<Void, Never>?
    /// Noise reduction level (0=Off, 1..5). Sent to rig via /radio/noise_reduction (Android-compatible).
    var noiseReductionLevel: Int = UserDefaults.standard.integer(forKey: "noiseReductionLevel")
    /// CW decode panel visibility on main control screen (mirrors Android `llCwDecoder`).
    var cwDecodeActive: Bool = false
    /// Live RX-decoded morse text buffer (last N chars).
    var cwRxDecodedText: String = ""
    /// Live TX-decoded morse text buffer (last N chars).
    var cwTxDecodedText: String = ""

    // Pre-FT8 rig state (restored on exit)
    var preFt8Freq: Int64 = 0
    var preFt8Mode: String = ""
    var preFt8Width: Int = 0

    private let api = RigApiService()
    private let ptt = PttService()
    private let audioRx = AudioRxService()
    private let audioTx = AudioTxService()
    nonisolated(unsafe) let civ = CivService()
    private let location = LocationService()
    private var cwDecoder = CwDecoder(sampleRate: 8000)
    var rttyAudioHandler: (([Int16]) -> Void)? = nil
    private let cwDecodeMaxChars = 100
    private var pollTask: Task<Void, Never>?
    private var aprsReceivedPollCount: Int = 0
    private var pttHeartbeatTask: Task<Void, Never>?
    private var aprsHeartbeatTask: Task<Void, Never>?
    private var aprsGpsTask: Task<Void, Never>?
    private var locationObserveTask: Task<Void, Never>?

    // FM-CW (Android-compatible): when rig is in FM mode, key state is converted to
    // PTT on/off instead of being forwarded to Pi cw_bridge. PTT-off is delayed for a
    // VOX tail so multi-character sentences don't drop the carrier.
    private var fmTxActive: Bool = false
    private var fmTailTask: Task<Void, Never>?
    private let fmVoxTailMs: UInt64 = 500_000_000   // 500 ms tail

    // TX CW decode (key state → characters)
    private var txKeyOnTime: Date?
    private var txLastOffTime: Date?
    private var txElements: String = ""
    private var txDitMs: Double = 60.0   // adaptive dit estimate, starts at ~20 WPM
    private var txCharFlushTask: Task<Void, Never>?
    /// Streams a 700 Hz sine wave to `POST /radio/audio_tx` so the rig has audio to
    /// modulate while PTT is keyed (matches Android's `cwBle.startCwAudioStream`).
    let cwAudioStream = CwAudioStream(toneHz: 700, sampleRate: 8000)

    init() {
        wireCwBleCallbacks()
    }

    /// Hook the BLE keyer's key-state callback. CW packets are forwarded inside
    /// `CwBleService.handleKey`; only the FM-CW (PTT) path needs MainViewModel.
    private func wireCwBleCallbacks() {
        // Share AudioRxService's engine with the sidetone so both run on one
        // AVAudioEngine, eliminating hardware output contention on iOS.
        cwBle.audioRx = audioRx
        // Surface AudioRx engine errors in the UI.
        audioRx.onError = { [weak self] msg in self?.errorMessage = msg }

        cwBle.onKeyStateChange = { [weak self] isOn, _ in
            guard let self else { return }
            Task { @MainActor in
                self.handleBleKeyForFmMode(isOn: isOn)
                self.decodeTxKey(isOn: isOn)
            }
        }

        // Android版connectCwBle()に合わせ: piHostはメインリグのhostNameを使用 (CW_UDP_PORT=8889は固定)
        cwBle.piHost = hostName
        cwBle.keeyerWpm = cwWpm

        // BLE接続時にpiHostとkeeyerWpmを最新値で上書きし、cw_bridge.pyを起動する (Android connectCwBle()と同様)
        cwBle.onConnectionStateChange = { [weak self] isConnected in
            guard let self, isConnected else { return }
            self.cwBle.piHost = self.hostName
            self.cwBle.keeyerWpm = self.cwWpm
            Task { await self.cwOpen() }
        }
    }

    /// Engaged only when `sharedMode` contains "FM". CW mode is handled entirely by
    /// CwBleService → Pi UDP forwarding.
    private func handleBleKeyForFmMode(isOn: Bool) {
        let bleMode = cwBle.currentMode.uppercased()
        guard bleMode.contains("FM") || bleMode == "DSTAR" || bleMode == "D-STAR" else {
            // Mode changed mid-key: drop any pending tail so we don't leave PTT stuck on.
            fmTailTask?.cancel(); fmTailTask = nil
            cwAudioStream.keyOff()
            return
        }
        let isCiv = useCivMode && civ.isConnected
        if isOn {
            fmTailTask?.cancel(); fmTailTask = nil
            if isCiv {
                // CI-V: PTT + 700Hz トーンを RS-BA1 TX audio 経由で IC-705 へ送信
                if !fmTxActive {
                    fmTxActive = true
                    txEnabled = true
                    civ.prepareFmCwTone()  // トーンスレッド準備（非ブロッキング）
                }
                civ.civPttDown()
                civ.fmCwKeyOn()
            } else {
                // WiFi: 700Hz tone to Pi API + PTT via Hamlib
                if !cwAudioStream.isRunning {
                    cwAudioStream.start(host: streamHost, apiPort: apiPort, apiKey: apiKey)
                }
                cwAudioStream.keyOn()
                if !fmTxActive {
                    fmTxActive = true
                    txEnabled = true
                    Task { try? await self.api.setPtt(state: true) }
                }
            }
        } else {
            if isCiv {
                civ.fmCwKeyOff()  // トーン即停止
            } else {
                cwAudioStream.keyOff()
            }
            fmTailTask?.cancel()
            fmTailTask = Task { [weak self, isCiv] in
                try? await Task.sleep(nanoseconds: 500_000_000)
                guard let self, !Task.isCancelled else { return }
                if isCiv {
                    self.civ.civPttUp()
                    self.civ.endFmCwTone()
                } else {
                    try? await self.api.setPtt(state: false)
                }
                self.fmTxActive = false
                self.txEnabled = false
                self.fmTailTask = nil
            }
        }
    }

    // MARK: - TX CW decode (key state → cwTxDecodedText)

    /// Called each time the BLE keyer reports a key state change.
    /// Measures element durations and gap durations to decode dit/dah sequences.
    private func decodeTxKey(isOn: Bool) {
        guard cwDecodeActive else { return }
        let now = Date()
        if isOn {
            txCharFlushTask?.cancel(); txCharFlushTask = nil
            if let offTime = txLastOffTime {
                let gapMs = now.timeIntervalSince(offTime) * 1000
                if gapMs >= txDitMs * 2.5 {
                    flushTxChar()
                    if gapMs >= txDitMs * 7 { appendTxText(" ") }
                }
            }
            txKeyOnTime = now
        } else {
            if let onTime = txKeyOnTime {
                let durMs = now.timeIntervalSince(onTime) * 1000
                if durMs < txDitMs * 1.8 {
                    txElements += "."
                    txDitMs = txDitMs * 0.95 + durMs * 0.05
                } else {
                    txElements += "-"
                    txDitMs = txDitMs * 0.95 + (durMs / 3.0) * 0.05
                }
                txKeyOnTime = nil
            }
            txLastOffTime = now
            let ditMs = txDitMs
            txCharFlushTask = Task { [weak self] in
                try? await Task.sleep(nanoseconds: UInt64(ditMs * 3.0 * 1_000_000))
                guard !Task.isCancelled, let self else { return }
                self.flushTxChar()
                try? await Task.sleep(nanoseconds: UInt64(ditMs * 4.0 * 1_000_000))
                guard !Task.isCancelled else { return }
                self.appendTxText(" ")
            }
        }
    }

    private func flushTxChar() {
        guard !txElements.isEmpty else { return }
        let elems = txElements; txElements = ""
        if let char = CwDecoder.morseTable[elems] { appendTxText(String(char)) }
    }

    private func appendTxText(_ s: String) {
        cwTxDecodedText += s
        if cwTxDecodedText.count > cwDecodeMaxChars {
            cwTxDecodedText = String(cwTxDecodedText.suffix(cwDecodeMaxChars))
        }
    }

    private func resetTxDecoder() {
        txCharFlushTask?.cancel(); txCharFlushTask = nil
        txKeyOnTime = nil; txLastOffTime = nil
        txElements = ""; txDitMs = 60.0
    }

    // MARK: - Persistence

    func persistConnectionSettings() {
        let d = UserDefaults.standard
        d.set(hostName, forKey: "hostName")
        d.set(apiPort, forKey: "apiPort")
        d.set(audioPort, forKey: "audioPort")
        d.set(apiKey, forKey: "apiKey")
        d.set(useMDNS, forKey: "useMDNS")
        d.set(useWifiPTT, forKey: "useWifiPTT")
        d.set(pttHost, forKey: "pttHost")
        d.set(pttPort, forKey: "pttPort")
        d.set(micGain, forKey: "micGain")
        d.set(screenTimeoutMinutes, forKey: "screenTimeoutMinutes")
        d.set(useCivMode, forKey: "useCivMode")
        d.set(civHost, forKey: "civHost")
        d.set(civUsername, forKey: "civUsername")
        d.set(civPassword, forKey: "civPassword")
        d.set(civPort1, forKey: "civPort1")
        d.set(civPort2, forKey: "civPort2")
        d.set(civPort3, forKey: "civPort3")
        d.set(civAddressHex, forKey: "civAddressHex")
    }

    func persistAprsSettings() {
        let d = UserDefaults.standard
        d.set(aprsEnabled, forKey: "aprsEnabled")
        d.set(aprsCallsign, forKey: "aprsCallsign")
        d.set(aprsSSID, forKey: "aprsSSID")
        d.set(aprsPath, forKey: "aprsPath")
        d.set(aprsDestination, forKey: "aprsDestination")
        d.set(aprsSymbol, forKey: "aprsSymbol")
        d.set(aprsIntervalSec, forKey: "aprsIntervalSec")
        d.set(aprsBaud, forKey: "aprsBaud")
        d.set(aprsTxFreq, forKey: "aprsTxFreq")
        d.set(aprsUseGPS, forKey: "aprsUseGPS")
        d.set(aprsManualLat, forKey: "aprsManualLat")
        d.set(aprsManualLon, forKey: "aprsManualLon")
        d.set(aprsSoundDevice, forKey: "aprsSoundDevice")
        d.set(aprsComment, forKey: "aprsComment")
        d.set(aprsUseRigModem, forKey: "aprsUseRigModem")
        d.set(aprsModemSel, forKey: "aprsModemSel")
        d.set(aprsPreset1Freq, forKey: "aprsPreset1Freq")
        d.set(aprsPreset1Baud, forKey: "aprsPreset1Baud")
        d.set(aprsPreset2Freq, forKey: "aprsPreset2Freq")
        d.set(aprsPreset2Baud, forKey: "aprsPreset2Baud")
    }

    /// Persist CW settings (v2.02).
    func persistCwSettings() {
        let d = UserDefaults.standard
        d.set(cwPort, forKey: "cwPort")
        d.set(cwDelayMs, forKey: "cwDelayMs")
        d.set(cwFmDelayMs, forKey: "cwFmDelayMs")
        d.set(cwSidetoneEnabled, forKey: "cwSidetoneEnabled")
        d.set(cwWpm, forKey: "cwWpm")
        d.set(cwLastText, forKey: "cwLastText")
        d.set(cwDxCall, forKey: "cwDxCall")
        d.set(cwRst, forKey: "cwRst")
        d.set(cwPota, forKey: "cwPota")
        d.set(cwJcc, forKey: "cwJcc")
        d.set(cwPttPoll, forKey: "cwPttPoll")
        d.set(cwCqRepeat, forKey: "cwCqRepeat")
        d.set(cwCqPota, forKey: "cwCqPota")
        d.set(cwCqJcc, forKey: "cwCqJcc")
        d.set(cwAnsGreeting, forKey: "cwAnsGreeting")
        d.set(cwAnsPota, forKey: "cwAnsPota")
        d.set(cwAnsJcc, forKey: "cwAnsJcc")
        d.set(cwQsl, forKey: "cwQsl")
        d.set(cwCqLoopCount, forKey: "cwCqLoopCount")
        d.set(cwCqLoopInterval, forKey: "cwCqLoopInterval")
        d.set(cwRstRepeat, forKey: "cwRstRepeat")
    }

    func applyMDNSSuffix() {
        let h = hostName.trimmingCharacters(in: .whitespaces)
        if useMDNS, !h.isEmpty, !h.hasSuffix(".local") {
            hostName = h + ".local"
        } else if !useMDNS, h.hasSuffix(".local") {
            hostName = String(h.dropLast(".local".count))
        }
    }

    // MARK: - Connect / discover

    func connectToRasPi() async -> String? {
        let h = hostName.trimmingCharacters(in: .whitespaces)
        guard !h.isEmpty else { return NSLocalizedString("enter_host", comment: "") }
        isBusy = true
        defer { isBusy = false }
        await api.configure(host: h, apiPort: apiPort, apiKey: apiKey)
        resolvedStreamHost = await api.streamHost
        do {
            let rigs = try await api.getRigs()
            let devices = try await api.getDevices()
            self.rigList = rigs
            self.catList = devices.serial
            self.soundDeviceList = devices.audio
            restoreSelectionsFromSaved()
            persistSelections()
            persistConnectionSettings()
            updateActiveProfile()
            return nil
        } catch {
            return error.localizedDescription
        }
    }

    /// アクティブなプロファイルに現在の接続設定を上書き保存する。
    private func updateActiveProfile() {
        guard let activeId = ProfileStore.activeId,
              let idx = profiles.firstIndex(where: { $0.id == activeId }) else { return }
        var p = snapshotCurrentProfile(name: profiles[idx].name)
        p.id = activeId
        profiles[idx] = p
        ProfileStore.saveAll(profiles)
    }

    /// Reconcile saved (id/name) selections against the freshly discovered lists.
    /// Falls back to index 0 when the previously-saved item is no longer present.
    private func restoreSelectionsFromSaved() {
        // Rig: match by stable id
        if let idx = rigList.firstIndex(where: { $0.id == savedRigId }) {
            selectedRigIndex = idx
        } else if selectedRigIndex >= rigList.count {
            selectedRigIndex = 0
        }
        // CAT device: match by path string
        if !savedCatDevice.isEmpty,
           let idx = catList.firstIndex(of: savedCatDevice) {
            selectedCatIndex = idx
        } else if selectedCatIndex >= catList.count {
            selectedCatIndex = 0
        }
        // Audio capture/playback: only clear if the server returned devices and the saved id is absent.
        // An empty soundDeviceList means the fetch hasn't completed or the Pi has no devices —
        // in that case keep the saved selection so it isn't accidentally erased.
        if !selectedAudioCapture.isEmpty,
           !soundDeviceList.isEmpty,
           !soundDeviceList.contains(where: { $0.id == selectedAudioCapture }) {
            selectedAudioCapture = ""
        }
        if !selectedAudioPlayback.isEmpty,
           !soundDeviceList.isEmpty,
           !soundDeviceList.contains(where: { $0.id == selectedAudioPlayback }) {
            selectedAudioPlayback = ""
        }
        // PTT device: only clear if catList is non-empty and the saved device is absent.
        if selectedPttDevice != "NONE",
           !catList.isEmpty,
           !catList.contains(selectedPttDevice) {
            selectedPttDevice = "NONE"
        }
    }

    /// Persist the rig/CAT/PTT/audio/sampling selections for next launch.
    func persistSelections() {
        let d = UserDefaults.standard
        if rigList.indices.contains(selectedRigIndex) {
            savedRigId = rigList[selectedRigIndex].id
            d.set(savedRigId, forKey: "savedRigId")
        }
        if catList.indices.contains(selectedCatIndex) {
            savedCatDevice = catList[selectedCatIndex]
            d.set(savedCatDevice, forKey: "savedCatDevice")
        }
        d.set(selectedBaudIndex, forKey: "selectedBaudIndex")
        d.set(selectedSamplingIndex, forKey: "selectedSamplingIndex")
        d.set(selectedPttDevice, forKey: "selectedPttDevice")
        d.set(selectedPttType.rawValue, forKey: "selectedPttType")
        d.set(selectedAudioCapture, forKey: "selectedAudioCapture")
        d.set(selectedAudioPlayback, forKey: "selectedAudioPlayback")
    }

    func openSelectedRig() async -> String? {
        guard !rigList.isEmpty else { return NSLocalizedString("no_rigs", comment: "") }
        if isDemoMode {
            // Demo mode: skip the real server handshake and go straight to Main Control.
            isConnectedToRig = true
            return nil
        }
        isBusy = true
        defer { isBusy = false }
        let rig = rigList[selectedRigIndex]
        let cat = catList.indices.contains(selectedCatIndex) ? catList[selectedCatIndex] : ""
        let baud = AppConstants.baudRates[selectedBaudIndex]
        let pttDev = selectedPttDevice == "NONE" ? "" : selectedPttDevice
        do {
            // Pi may need to close the existing CAT port first; retry once on failure.
            do {
                try await api.openRig(model: rig.id, cat: cat, baud: baud, ptt: pttDev, pttType: selectedPttType.rawValue)
            } catch {
                try? await Task.sleep(nanoseconds: 1_000_000_000)
                try await api.openRig(model: rig.id, cat: cat, baud: baud, ptt: pttDev, pttType: selectedPttType.rawValue)
            }
            let caps = (try? await api.getCaps()) ?? CapsResponse(modes: [])
            self.supportedModes = caps.modes
            self.isConnectedToRig = true
            // Pi の _detect_vfo_mode がバックグラウンドで動作中のため、
            // C4FM/DSTAR が初回 getCaps に含まれない場合は 3 秒後に再取得する。
            if !caps.modes.contains("C4FM") && !caps.modes.contains("DSTAR") {
                Task { [weak self] in
                    try? await Task.sleep(nanoseconds: 3_000_000_000)
                    guard let self, self.isConnectedToRig else { return }
                    if let caps2 = try? await self.api.getCaps(), !caps2.modes.isEmpty {
                        self.supportedModes = caps2.modes
                    }
                }
            }
            if !selectedAudioCapture.isEmpty {
                // Use the same device for both capture (radio→PC) and playback (PC→radio).
                try? await api.setAudioDevice(capture: selectedAudioCapture, playback: selectedAudioCapture)
            }
            // FT8 uses its own capture-device endpoint so the audio_sub stream uses the
            // correct ALSA device independently of the main SPK/TX device.
            if !selectedAudioPlayback.isEmpty {
                try? await api.setAudioDeviceFt8(capture: selectedAudioPlayback)
            }
            persistSelections()
            updateActiveProfile()
            startStatusPolling()
            Task { await fetchVfoState() }   // non-blocking; don't delay connect flow
            if useWifiPTT, !pttHost.isEmpty {
                await ptt.connect(host: pttHost, port: pttPort)
            }
            // Restart cw_bridge.py on Pi so CW keying works immediately.
            // Needed when Pi was restarted while BLE keyer remained connected (no BLE reconnect event).
            Task { _ = await cwOpen() }
            return nil
        } catch {
            return error.localizedDescription
        }
    }

    /// Convenience wrapper around `api.getServerVersion()` used by AboutView.
    func fetchServerVersion() async -> (apiVersion: String, rigctld: String) {
        if isDemoMode { return ("DEMO", "DEMO") }
        // Only configure if api has never been configured (avoids blocking DNS re-resolution
        // during an active session, which would stall the polling actor queue).
        if await api.host.isEmpty { await adminEnsureConfigured() }
        return await api.getServerVersion()
    }

    func disconnect() {
        stopStatusPolling()
        stopPttHeartbeat()
        cwAudioStream.stop()
        fmTailTask?.cancel(); fmTailTask = nil
        fmTxActive = false
        Task {
            await audioRx.stop()
            await audioTx.stop()
            await ptt.disconnect()
        }
        if civ.isConnected { Task.detached { [civ = self.civ] in civ.disconnect() } }
        civConnected = false
        isConnectedToRig = false
        spkEnabled = false
        txEnabled = false
        stopWakeLock()
    }

    // MARK: - Screen timeout management

    func applyWakeLock() {
        _screenMonitorTask?.cancel()
        _screenMonitorTask = nil
        switch screenTimeoutMinutes {
        case -1:
            UIApplication.shared.isIdleTimerDisabled = true
        case 0:
            UIApplication.shared.isIdleTimerDisabled = false
        default:
            UIApplication.shared.isIdleTimerDisabled = true
            _lastActivityTime = Date()
            let minutes = screenTimeoutMinutes
            _screenMonitorTask = Task { [weak self] in
                while !Task.isCancelled {
                    try? await Task.sleep(nanoseconds: 30_000_000_000)
                    guard let self, !Task.isCancelled else { return }
                    let elapsed = Date().timeIntervalSince(self._lastActivityTime)
                    UIApplication.shared.isIdleTimerDisabled = elapsed < Double(minutes) * 60
                }
            }
        }
    }

    func stopWakeLock() {
        _screenMonitorTask?.cancel()
        _screenMonitorTask = nil
        UIApplication.shared.isIdleTimerDisabled = false
    }

    func noteActivity() {
        _lastActivityTime = Date()
        if screenTimeoutMinutes > 0, !UIApplication.shared.isIdleTimerDisabled {
            UIApplication.shared.isIdleTimerDisabled = true
        }
    }

    // MARK: - CI-V (RS-BA1 direct WiFi to IC-705)

    /// Blocking CI-V connect. Call from a background Task.
    /// Returns nil on success, or a localized error string on failure.
    func civConnect() async -> String? {
        civConnecting = true
        civConnectStep = ""
        defer { civConnecting = false; civConnectStep = "" }
        // Yield to let SwiftUI render the connecting state before blocking work starts.
        await Task.yield()
        civError = ""
        persistConnectionSettings()
        let host = civHost.trimmingCharacters(in: .whitespaces)
        guard !host.isEmpty else { civError = String(localized: "CI-V ホスト未入力"); return civError }
        // Request mic permission before connecting so initAudioPlayer() can activate the
        // microphone hardware (and the iOS privacy indicator) when the engine starts.
        let micGranted = await ensureMicPermission()
        if !micGranted {
            civError = String(localized: "マイク権限が必要です — 設定 → WifiRigCTRL でマイクを許可してください")
            return civError
        }
        // Apply manual CI-V address if set (auto-detection during connect may override)
        let addrHex = civAddressHex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        if !addrHex.isEmpty, let addr = Int(addrHex, radix: 16), addr > 0 {
            civ.civAddress = addr
        }
        civ.onConnectStep = { [weak self] step in
            DispatchQueue.main.async { self?.civConnectStep = step }
        }
        let ok = await Task.detached(priority: .userInitiated) { [civ = self.civ, host,
            p1 = self.civPort1, p2 = self.civPort2, p3 = self.civPort3,
            u = self.civUsername, pw = self.civPassword] in
            civ.connect(host: host, port1: p1, port2: p2, port3: p3, username: u, password: pw)
        }.value
        civ.onConnectStep = nil
        if !ok {
            civError = civ.lastError.isEmpty ? String(localized: "CI-V 接続失敗") : civ.lastError
            return civError
        }
        // Sync back auto-detected CI-V address
        let detectedHex = String(civ.civAddress, radix: 16).uppercased()
        civAddressHex = detectedHex
        UserDefaults.standard.set(detectedHex, forKey: "civAddressHex")
        supportedModes = civ.getSupportedModes()
        civConnected = true
        isConnectedToRig = true
        startStatusPolling()
        // Keep the overlay visible until the first successful frequency poll.
        civConnectStep = String(localized: "周波数確認中…")
        let freqDeadline = Date().addingTimeInterval(30)
        while Date() < freqDeadline {
            if sharedFreq != 0 { break }
            try? await Task.sleep(nanoseconds: 200_000_000)
        }
        // CI-V stream is now confirmed open — reset DUP to Simplex
        Task { civ.setTxShift(0) }
        return nil
    }

    /// Disconnect CI-V and stop polling.
    func civDisconnect() {
        stopStatusPolling()
        stopPttHeartbeat()
        civConnected = false
        isConnectedToRig = false
        spkEnabled = false
        txEnabled = false
        Task.detached { [civ = self.civ] in civ.disconnect() }
    }

    // MARK: - Status polling (200 ms)

    func startStatusPolling() {
        stopStatusPolling()
        aprsReceivedPollCount = 0
        loggedFirstPollError = false
        consecutivePollFailures = 0
        pollFailuresSince = nil
        linkLost = false
        pollSuppressed = false
        pollTask = Task { [weak self] in
            while let self, !Task.isCancelled {
                await self.pollOnce()
                // Skip the APRS fetch while the link is down: it would just pile up more
                // failing requests against a server that is not answering.
                if !self.linkLost {
                    self.aprsReceivedPollCount += 1
                    if self.aprsReceivedPollCount >= 10 {   // every ~2 s
                        self.aprsReceivedPollCount = 0
                        await self.refreshAprsReceived()
                    }
                }
                try? await Task.sleep(nanoseconds: self.linkLost ? Self.pollRetryNs
                                                                 : Self.pollIntervalNs)
            }
        }
    }

    func stopStatusPolling() {
        pollTask?.cancel()
        pollTask = nil
    }

    private var loggedFirstPollError: Bool = false
    private var consecutivePollFailures: Int = 0
    var pollSuppressed: Bool = false

    /// True while status polling is failing but the session is being kept alive.
    /// The UI can show this instead of silently freezing its readouts.
    var linkLost: Bool = false
    /// When the current run of consecutive poll failures started.
    private var pollFailuresSince: Date?
    /// How long polling must fail continuously before the link counts as lost.
    ///
    /// This used to be a count of 5 failures, and with a 200 ms poll interval that is
    /// about one second — so a Pi reboot, a service restart or a brief Wi-Fi stall tore
    /// the session down. Worse, it called `disconnect()` and stopped polling, so the app
    /// never came back on its own even once the Pi returned: readouts simply stopped
    /// updating, which is what looked like a freeze.
    private static let pollFailGraceSec: TimeInterval = 8
    /// When the Pi answers but reports `freq == 0` for this long, rigctld is not open and the
    /// rig needs re-opening. See the check in `pollOnce`.
    private var zeroFreqSince: Date?
    private static let zeroFreqGraceSec: TimeInterval = 6
    /// Poll interval while the link is healthy, and the slower one used while it is lost
    /// so a down server is not hammered 5 times a second.
    private static let pollIntervalNs: UInt64 =   200_000_000
    private static let pollRetryNs:    UInt64 = 2_000_000_000
    private static let expectedPiApiVersion = "3.12"

    private func pollOnce() async {
        // CI-V direct path (bypasses Pi FastAPI entirely).
        // Guarded on useCivMode alone: when the link drops, this must still take the CI-V
        // branch rather than falling through and starting to poll the Pi instead.
        if useCivMode {
            guard civ.isConnected else {
                if civConnected { civConnected = false }
                isConnectedToRig = false
                stopStatusPolling()
                return
            }
            let s = await Task.detached(priority: .userInitiated) { [civ = self.civ] in
                civ.pollStatus()
            }.value
            // CivService drops the link from its own watchdogs without telling the view
            // model, so civConnected used to stay true forever. That left the UI showing
            // "connected" while every CI-V command was rejected internally, and kept
            // RTTY's TX:AUTO routing (isCivMode) pointed at a dead session.
            if civConnected != civ.isConnected { civConnected = civ.isConnected }
            guard let s else {
                if !civ.isConnected { isConnectedToRig = false; stopStatusPolling() }
                return
            }
            self.sharedFreq = s.freq
            if let m = s.mode {
                if m.name != self.sharedMode {
                    self.applyStepForMode(m.name)
                    if m.name.uppercased().contains("CW") && self.cwBle.sidetoneEnabled { self.cwBle.startSidetoneLazy() }
                }
                self.sharedMode = m.name; self.sharedWidth = m.filterWidth; self.cwBle.currentMode = m.name
            }
            self.sharedSignal = normalizedSignal(Double(s.signal ?? 0))
            self.sharedTx = s.tx
            if let p = s.power { self.sharedPower = Double(p) }
            if let sq = s.sql { self.sharedSQL = Double(sq) }
            if let bk = s.bkIn { self.sharedBkIn = bk }
            if let ro = s.rfOut { self.sharedRfOut = Double(ro) } else if !s.tx { self.sharedRfOut = 0 }
            if let al = s.alc  { self.sharedAlc   = Double(al) } else if !s.tx { self.sharedAlc   = 0 }
            loggedFirstPollError = false
            consecutivePollFailures = 0
            noteActivity()
            return
        }

        do {
            let s = try await api.getStatus()
            self.sharedFreq = s.freq
            if s.mode != self.sharedMode {
                self.applyStepForMode(s.mode)
                if s.mode.uppercased().contains("CW") && self.cwBle.sidetoneEnabled { self.cwBle.startSidetoneLazy() }
            }
            self.sharedMode = s.mode
            self.cwBle.currentMode = s.mode  // keep FM-CW PTT path in sync with rig polling
            self.sharedSignal = normalizedSignal(s.signal)
            self.sharedTx = s.tx
            self.sharedPower = s.power
            self.sharedWidth = s.width
            self.sharedSQL = s.sql
            self.sharedBkIn = s.bk_in ?? false
            if let v = s.api_version, !v.isEmpty { self.piVersionMismatch = (v != Self.expectedPiApiVersion) }
            if let v = s.rf_out, s.tx { self.sharedRfOut = v } else if !s.tx { self.sharedRfOut = 0 }
            if let v = s.alc,    s.tx { self.sharedAlc   = v } else if !s.tx { self.sharedAlc   = 0 }
            loggedFirstPollError = false
            consecutivePollFailures = 0
            if linkLost { await handleLinkRestored() }
            pollFailuresSince = nil
            // The Pi answers but reports no frequency: rigctld is not open, so its polling
            // threads have nothing to read. That is the state a service restart leaves behind,
            // and a restart short enough not to trip the link-lost grace period used to leave
            // it this way forever, with the app showing a healthy connection that could do
            // nothing. Re-open the rig once the zero has persisted, long enough that a single
            // stale reading during a normal mode change does not trigger it.
            // Never while transmitting: PTT is on and the rig may legitimately not be
            // reporting a frequency, and re-opening would drop the transmission.
            if s.freq == 0, !txEnabled, !sharedTx {
                if zeroFreqSince == nil { zeroFreqSince = Date() }
                if let since = zeroFreqSince,
                   Date().timeIntervalSince(since) >= Self.zeroFreqGraceSec {
                    zeroFreqSince = nil
                    await reopenRig(reason: "freq=0")
                }
            } else {
                zeroFreqSince = nil
            }
            noteActivity()
        } catch {
            consecutivePollFailures += 1
            if pollFailuresSince == nil { pollFailuresSince = Date() }
            if !loggedFirstPollError {
                loggedFirstPollError = true
                let msg = "/radio/status poll failed: \(error.localizedDescription)"
                print("[Poll] \(msg)")
                errorMessage = msg
            }
            // Keep the session and keep polling. Only flag the link as lost so the UI can
            // say so and the retry slows down — never disconnect from here, or the app
            // will not come back by itself when the server returns.
            if !linkLost, let since = pollFailuresSince,
               Date().timeIntervalSince(since) >= Self.pollFailGraceSec {
                linkLost = true
                print("[Poll] link lost after \(Int(Date().timeIntervalSince(since)))s — keeping session, retrying")
            }
        }
    }

    /// Runs once when status polling starts answering again after `linkLost`.
    ///
    /// Re-opens the rig, because the usual reason for a multi-second outage is that the Pi
    /// restarted its services or rebooted. In that case it has lost the rig selection and
    /// its background polling threads, and rigctld is not running, so just resuming our
    /// own polling would read zeros forever.
    private func handleLinkRestored() async {
        let downFor = pollFailuresSince.map { Int(Date().timeIntervalSince($0)) } ?? 0
        linkLost = false
        errorMessage = ""
        print("[Poll] link restored after \(downFor)s")
        await reopenRig(reason: "link restored")
    }

    /// Re-issues `/radio/open` with the stored selections.
    ///
    /// Rate-limited, and that limit is not optional. `rigctld` needs several seconds after a
    /// re-open before it reports a frequency, so the zero-frequency check that calls this
    /// would see another zero and call it again, and each call restarts rigctld. The result
    /// was a self-sustaining loop that knocked the rig's control link over repeatedly, which
    /// looked like the connection dying after a few RTTY decodes.
    private var lastReopenAt: Date?
    private static let reopenCooldownSec: TimeInterval = 30

    private func reopenRig(reason: String) async {
        if let last = lastReopenAt,
           Date().timeIntervalSince(last) < Self.reopenCooldownSec {
            return
        }
        guard !isDemoMode, !useCivMode,
              rigList.indices.contains(selectedRigIndex),
              AppConstants.baudRates.indices.contains(selectedBaudIndex) else { return }
        lastReopenAt = Date()
        let rig  = rigList[selectedRigIndex]
        let cat  = catList.indices.contains(selectedCatIndex) ? catList[selectedCatIndex] : ""
        let baud = AppConstants.baudRates[selectedBaudIndex]
        let ptt  = selectedPttDevice == "NONE" ? "" : selectedPttDevice
        do {
            try await api.openRig(model: rig.id, cat: cat, baud: baud,
                                  ptt: ptt, pttType: selectedPttType.rawValue)
            isConnectedToRig = true
            print("[Poll] rig reopened (model=\(rig.id) cat=\(cat)) — \(reason)")
        } catch {
            print("[Poll] rig reopen failed: \(error.localizedDescription)")
        }
    }

    /// Hamlib STRENGTH (dBm) → 0…15 S-unit scale.
    /// - S0 ≈ −54 dBm, S9 = 0 dBm, +6 dB per S-unit.
    /// - S9+30 dB ≈ 5 over → maps to 14, S9+60 dB → 15 (capped).
    /// Matches Android `(signal + 54) / 6` formula in MainViewModel.kt.
    private func normalizedSignal(_ raw: Double) -> Double {
        let s = (raw + 54.0) / 6.0
        return min(max(s, 0.0), 15.0)
    }

    // MARK: - Control

    private var isDemoMode: Bool {
        return demoMode
    }

    func setFreq(_ hz: Int64) async {
        sharedFreq = hz
        if isDemoMode { return }
        if useCivMode, civ.isConnected {
            _ = await Task.detached(priority: .userInitiated) { [civ = self.civ, hz] in civ.setFrequency(hz) }.value
            return
        }
        do { try await api.setFreq(hz: hz) } catch { errorMessage = error.localizedDescription }
    }

    func setMode(_ mode: String, width: Int) async {
        // C4FM: Hamlib の FT-991A フィルターテーブルに 12000 の登録がないため width=0 を強制
        let effectiveWidth = (mode == "C4FM") ? 0 : width
        sharedMode = mode; sharedWidth = effectiveWidth
        cwBle.currentMode = mode
        applyStepForMode(mode)
        if mode.uppercased().contains("CW") && cwBle.sidetoneEnabled { cwBle.startSidetoneLazy() }
        if isDemoMode { return }
        // "USB-D" is the display label for PKTUSB (IC-7300/IC-705 data mode).
        let modeToSend = (mode.uppercased() == "USB-D") ? "PKTUSB" : mode
        if useCivMode, civ.isConnected {
            _ = await Task.detached(priority: .userInitiated) { [civ = self.civ, modeToSend, effectiveWidth] in civ.setMode(modeToSend, width: effectiveWidth) }.value
            return
        }
        do { try await api.setMode(mode: modeToSend, width: effectiveWidth) }
        catch { errorMessage = error.localizedDescription }
    }

    /// Apply the step preset for a given mode (saved user preference, or default).
    /// Call this whenever sharedMode changes — whether from the app UI or from polling.
    func applyStepForMode(_ mode: String) {
        let key = "step_\(mode.uppercased())"
        if let stored = UserDefaults.standard.object(forKey: key) as? Int,
           AppConstants.stepHz.indices.contains(stored) {
            selectedStepIndex = stored
        } else {
            selectedStepIndex = AppConstants.defaultStepIndex(forMode: mode)
        }
    }

    /// Remember the user's chosen step for the current mode (v2.02 mode-specific step memory).
    func rememberStepForCurrentMode() {
        if sharedMode.isEmpty { return }
        UserDefaults.standard.set(selectedStepIndex, forKey: "step_\(sharedMode.uppercased())")
    }

    func setSquelch(_ value: Double) async {
        sharedSQL = value
        if isDemoMode { return }
        if useCivMode, civ.isConnected {
            _ = await Task.detached(priority: .userInitiated) { [civ = self.civ, value] in civ.setSql(Float(value)) }.value
            return
        }
        do { try await api.setLevel(name: "SQL", value: value) }
        catch { errorMessage = error.localizedDescription }
    }

    func setVolume(_ value: Double) async {
        sharedVolume = value
        if isDemoMode { return }
        do { try await api.setLevel(name: "VOL", value: value) }
        catch { errorMessage = error.localizedDescription }
    }

    func setPower(_ value: Double) async {
        sharedPower = value
        if isDemoMode { return }
        if useCivMode, civ.isConnected {
            _ = await Task.detached(priority: .userInitiated) { [civ = self.civ, value] in civ.setRfPower(Float(value)) }.value
            return
        }
        do { try await api.setPower(value: value) }
        catch { errorMessage = error.localizedDescription }
    }

    func stepFreq(_ direction: Int) async {
        let step = AppConstants.stepHz[selectedStepIndex]
        let newFreq = max(0, sharedFreq + Int64(direction * step))
        await setFreq(newFreq)
    }

    // MARK: - PTT

    /// Requests microphone permission. Returns true if granted (or already granted).
    /// Must be called BEFORE touching `AVAudioEngine.inputNode` to avoid the synchronous
    /// permission dialog blocking the audio engine setup.
    private func ensureMicPermission() async -> Bool {
        if #available(iOS 17.0, *) {
            switch AVAudioApplication.shared.recordPermission {
            case .granted: return true
            case .denied: return false
            case .undetermined:
                return await withCheckedContinuation { (cont: CheckedContinuation<Bool, Never>) in
                    AVAudioApplication.requestRecordPermission { granted in
                        cont.resume(returning: granted)
                    }
                }
            @unknown default: return false
            }
        } else {
            let session = AVAudioSession.sharedInstance()
            switch session.recordPermission {
            case .granted: return true
            case .denied: return false
            case .undetermined:
                return await withCheckedContinuation { (cont: CheckedContinuation<Bool, Never>) in
                    session.requestRecordPermission { granted in cont.resume(returning: granted) }
                }
            @unknown default: return false
            }
        }
    }

    /// - Parameter micAudio: when false (RTTY/data TX that streams its own PCM), the
    ///   microphone upload is not started; PTT and the heartbeat still run.
    func setPtt(on: Bool, micAudio: Bool = true) async {
        txEnabled = on
        sharedTx = on
        if isDemoMode { return }

        // CI-V direct path — TX audio is handled internally by CivService (UDP to IC-705)
        if useCivMode, civ.isConnected {
            if on {
                let granted = await ensureMicPermission()
                guard granted else {
                    errorMessage = "Microphone permission denied — enable it in Settings → WifiRigCTRL."
                    txEnabled = false; sharedTx = false; return
                }
            }
            _ = await Task.detached(priority: .userInitiated) { [civ = self.civ, on] in civ.setPtt(on) }.value
            return
        }

        // 1) Hamlib HTTP path
        do { try await api.setPtt(state: on) } catch { errorMessage = error.localizedDescription }
        // 2) WiFi UDP path to M5Atom (if enabled)
        if useWifiPTT {
            await ptt.sendPtt(on: on)
        }
        if on {
            startPttHeartbeat()
            // Data-mode TX (RTTY) streams pre-built PCM to /radio/audio_tx itself;
            // starting the mic upload too would open a second, competing audio_tx stream.
            guard micAudio else { return }
            // Mic permission pre-flight (avoids freeze when AVAudioEngine.inputNode
            // synchronously triggers the iOS permission dialog).
            let granted = await ensureMicPermission()
            guard granted else {
                errorMessage = "Microphone permission denied — enable it in Settings → WifiRigCTRL."
                return
            }
            // Start TX audio upload
            do { try await audioTx.start(host: streamHost, port: apiPort, apiKey: apiKey) }
            catch { errorMessage = error.localizedDescription }
        } else {
            stopPttHeartbeat()
            await audioTx.stop()
        }
    }

    private func startPttHeartbeat() {
        stopPttHeartbeat()
        pttHeartbeatTask = Task { [weak self] in
            while let self, !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 500_000_000)
                try? await self.api.pttHeartbeat()
                if self.useWifiPTT { await self.ptt.sendPtt(on: true) }
            }
        }
    }

    private func stopPttHeartbeat() {
        pttHeartbeatTask?.cancel()
        pttHeartbeatTask = nil
    }

    // MARK: - SPK (audio RX)

    func setSpk(on: Bool) async {
        spkEnabled = on
        if useCivMode, civ.isConnected {
            civ.spkEnabled = on
            return
        }
        if on {
            let rate = AppConstants.samplingRates[selectedSamplingIndex]
            if rate > 0 {
                await audioRx.start(host: streamHost, port: audioPort, sampleRate: rate, apiKey: apiKey)
            }
        } else {
            await audioRx.stop()
        }
    }

    func setMicGain(_ g: Float) {
        micGain = g
        audioTx.micGain = g
        civ.micGain = g
        UserDefaults.standard.set(g, forKey: "micGain")
    }

    // MARK: - APRS

    func buildAprsConfig(freq: Double? = nil, baud: Int? = nil) -> AprsConfig {
        let rigId: String
        if rigList.indices.contains(selectedRigIndex) {
            rigId = String(rigList[selectedRigIndex].id)
        } else {
            rigId = ""
        }
        let catDevice = catList.indices.contains(selectedCatIndex) ? catList[selectedCatIndex] : ""
        return AprsConfig(
            callsign: aprsCallsign,
            ssid: aprsSSID,
            path: aprsPath,
            interval: aprsIntervalSec,
            freq: freq ?? aprsTxFreq,
            baud: baud ?? aprsBaud,
            use_gps: aprsUseGPS,
            manual_lat: aprsManualLat,
            manual_lon: aprsManualLon,
            symbol: aprsSymbol,
            comment: aprsComment,
            destination: aprsDestination,
            sound_device: aprsSoundDevice,
            rig_id: rigId,
            cat_device: catDevice,
            use_rig_modem: aprsUseRigModem,
            modem_sel: aprsModemSel
        )
    }

    // MARK: - VFO (v2.20)

    func fetchVfoState() async {
        guard !isDemoMode else { vfoMode = "ab"; vfoCurrentSide = "A"; return }
        if let r = try? await api.getVfoMode() {
            vfoMode = r.mode
            vfoCurrentSide = r.side
        }
    }

    func toggleVfo() async {
        guard !isDemoMode else {
            if vfoMode == "mainsub" {
                let cycle = ["Main", "M/S", "S/M"]
                let idx = (cycle.firstIndex(of: vfoCurrentSide) ?? 0 + 1) % 3
                vfoCurrentSide = cycle[idx]
            } else {
                vfoCurrentSide = vfoCurrentSide == "A" ? "B" : "A"
            }
            return
        }
        if let r = try? await api.toggleVfo() {
            vfoMode = r.mode
            vfoCurrentSide = r.side
        }
    }

    /// TX Method (Rig Modem ↔ DireWolf) を切り替える。
    /// APRS 送信中、またはリグモデムモードから切り替える場合は先に stopAprs() でリグ側を停止してから切り替える。
    /// (Rig Modem → DireWolf 時: /aprs_stop が BEACON TYPE=OFF を送信するため必須)
    func switchAprsTxMethod() async {
        if aprsActive || aprsUseRigModem {
            await stopAprs()
        }
        aprsUseRigModem.toggle()
        persistAprsSettings()
    }

    /// Saves APRS settings locally and POSTs full config to /aprs_config.
    /// Returns nil on success, or a localized error message on failure.
    func saveAndSendAprsConfig() async -> String? {
        persistAprsSettings()
        if isDemoMode { return nil }
        let cfg = buildAprsConfig()
        do {
            try await api.sendAprsConfig(cfg)
            return nil
        } catch {
            return error.localizedDescription
        }
    }

    /// Toggle APRS — rig modem mode cycles OFF→AP96→AP12→OFF; DireWolf mode toggles ON/OFF.
    func toggleAprs() async -> String? {
        if isDemoMode {
            if aprsUseRigModem {
                if !aprsActive {
                    aprsActive = true; aprsAtPreset2 = false
                } else if !aprsAtPreset2 {
                    aprsAtPreset2 = true
                } else {
                    aprsActive = false; aprsAtPreset2 = false
                }
            } else {
                if aprsActive { await stopAprs() } else { return await startAprs() }
            }
            return nil
        }
        if aprsUseRigModem {
            if !aprsActive {
                // Start AP96 (preset1)
                let cfg = buildAprsConfig(freq: aprsPreset1Freq, baud: aprsPreset1Baud)
                do {
                    try await api.sendAprsConfig(cfg)
                    try await api.startAprs(cfg)
                    aprsActive = true; aprsAtPreset2 = false
                    startAprsHeartbeat()
                    return nil
                } catch { return error.localizedDescription }
            } else if !aprsAtPreset2 {
                // Switch to AP12 (preset2) without stopping
                let cfg = buildAprsConfig(freq: aprsPreset2Freq, baud: aprsPreset2Baud)
                do {
                    try await api.sendAprsConfig(cfg)
                    try await api.startAprs(cfg)
                    aprsAtPreset2 = true
                    return nil
                } catch { return error.localizedDescription }
            } else {
                // Stop
                await stopAprs()
                return nil
            }
        } else {
            if aprsActive { await stopAprs(); return nil }
            else { return await startAprs() }
        }
    }

    /// POSTs /aprs_config (sets aprs_cfg on server; restarts DireWolf only if conf changed),
    /// then /aprs_start to begin TX loop and heartbeat.
    func startAprs() async -> String? {
        if isDemoMode {
            aprsActive = true
            aprsCurrentLat = aprsManualLat == 0 ? 35.6586 : aprsManualLat
            aprsCurrentLon = aprsManualLon == 0 ? 139.7454 : aprsManualLon
            return nil
        }
        let cfg = buildAprsConfig()
        do {
            try await api.sendAprsConfig(cfg)   // sets aprs_cfg; restarts DireWolf only when conf changes
            try await api.startAprs(cfg)
            aprsActive = true
            startAprsHeartbeat()
            if aprsUseGPS { startAprsGpsStreaming() }
            await refreshAprsReceived()
            return nil
        } catch {
            return error.localizedDescription
        }
    }

    func stopAprs() async {
        if isDemoMode {
            aprsActive = false; aprsAtPreset2 = false
            return
        }
        stopAprsHeartbeat()
        stopAprsGpsStreaming()
        do { try await api.stopAprs() } catch { /* ignore */ }
        aprsActive = false
        aprsAtPreset2 = false
    }

    /// In demo mode, skip the actual API call but persist locally.
    /// Note: saveAndSendAprsConfig uses this internally via isDemoMode check.

    private func startAprsHeartbeat() {
        stopAprsHeartbeat()
        aprsHeartbeatTask = Task { [weak self] in
            var tick = 0
            while let self, !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 5_000_000_000)
                try? await self.api.aprsHeartbeat()
                tick += 1
                // 30秒ごとに設定を再送してサーバーとの不整合を防ぐ
                if tick % 6 == 0 {
                    // rig modem mode: use active preset freq/baud (not DireWolf defaults)
                    let cfg: AprsConfig
                    if self.aprsUseRigModem {
                        if self.aprsAtPreset2 {
                            cfg = self.buildAprsConfig(freq: self.aprsPreset2Freq, baud: self.aprsPreset2Baud)
                        } else {
                            cfg = self.buildAprsConfig(freq: self.aprsPreset1Freq, baud: self.aprsPreset1Baud)
                        }
                    } else {
                        cfg = self.buildAprsConfig()
                    }
                    try? await self.api.sendAprsConfig(cfg)
                }
            }
        }
    }

    private func stopAprsHeartbeat() {
        aprsHeartbeatTask?.cancel()
        aprsHeartbeatTask = nil
    }

    private func startAprsGpsStreaming() {
        stopAprsGpsStreaming()
        location.start()
        locationObserveTask = Task { [weak self] in
            guard let self else { return }
            for await loc in self.location.updates {
                if Task.isCancelled { return }
                self.aprsCurrentLat = loc.coordinate.latitude
                self.aprsCurrentLon = loc.coordinate.longitude
            }
        }
        aprsGpsTask = Task { [weak self] in
            while let self, !Task.isCancelled {
                if self.aprsCurrentLat != 0 || self.aprsCurrentLon != 0 {
                    try? await self.api.sendGps(lat: self.aprsCurrentLat, lon: self.aprsCurrentLon)
                }
                try? await Task.sleep(nanoseconds: 10_000_000_000)
            }
        }
    }

    private func stopAprsGpsStreaming() {
        aprsGpsTask?.cancel()
        aprsGpsTask = nil
        locationObserveTask?.cancel()
        locationObserveTask = nil
        location.stop()
    }

    func requestLocationAuthorization() {
        location.requestAuthorization()
    }

    var isLocationAuthorized: Bool { location.isAuthorized }

    // MARK: - APRS compass (v2.20)

    /// Best available current position (GPS if active, else manual).
    var selfPosition: (lat: Double, lon: Double)? {
        if aprsCurrentLat != 0 || aprsCurrentLon != 0 {
            return (aprsCurrentLat, aprsCurrentLon)
        }
        if aprsManualLat != 0 || aprsManualLon != 0 {
            return (aprsManualLat, aprsManualLon)
        }
        return nil
    }

    /// Bearing in degrees (0=N, 90=E, 180=S, 270=W).
    nonisolated static func bearing(from: (lat: Double, lon: Double), to: (lat: Double, lon: Double)) -> Double {
        let φ1 = from.lat * .pi / 180
        let φ2 = to.lat  * .pi / 180
        let Δλ = (to.lon - from.lon) * .pi / 180
        let y = sin(Δλ) * cos(φ2)
        let x = cos(φ1) * sin(φ2) - sin(φ1) * cos(φ2) * cos(Δλ)
        return (atan2(y, x) * 180 / .pi + 360).truncatingRemainder(dividingBy: 360)
    }

    /// Great-circle distance in km.
    nonisolated static func distanceKm(from: (lat: Double, lon: Double), to: (lat: Double, lon: Double)) -> Double {
        let R = 6371.0
        let φ1 = from.lat * .pi / 180
        let φ2 = to.lat  * .pi / 180
        let Δφ = (to.lat - from.lat) * .pi / 180
        let Δλ = (to.lon - from.lon) * .pi / 180
        let a = sin(Δφ/2)*sin(Δφ/2) + cos(φ1)*cos(φ2)*sin(Δλ/2)*sin(Δλ/2)
        return R * 2 * atan2(sqrt(a), sqrt(1-a))
    }

    func refreshAprsReceived() async {
        if useCivMode { return }
        if isDemoMode {
            aprsReceivedStations = [
                AprsStation(call: "JA1XXX-9", lat: 35.681, lon: 139.767, symbol: ">", comment: "Demo car", age_sec: 30),
                AprsStation(call: "JA2YYY-5", lat: 35.690, lon: 139.700, symbol: "[", comment: "Demo pedestrian", age_sec: 120),
            ]
            return
        }
        if let stations = try? await api.getAprsReceived() {
            aprsReceivedStations = stations
        }
    }

    // MARK: - FT8

    func persistFt8Settings() {
        let d = UserDefaults.standard
        d.set(ft8MyCall, forKey: "ft8MyCall")
        d.set(ft8MyGrid, forKey: "ft8MyGrid")
        d.set(ft8LatencyMs, forKey: "ft8LatencyMs")
        d.set(ft8TxMode, forKey: "ft8TxMode")
        d.set(Int(ft8LastFreq), forKey: "ft8LastFreq")
        d.set(ft8AudioFreqHz, forKey: "ft8AudioFreqHz")
        d.set(ft8DecodeDepth, forKey: "ft8DecodeDepth")
        d.set(ft8AutoTxMode, forKey: "ft8AutoTxMode")
        d.set(ft8Filter, forKey: "ft8Filter")
        d.set(ft8IsFt4, forKey: "ft8IsFt4")
        d.set(ft8PskReporter, forKey: "ft8PskReporter")
    }

    func ft8SetPskReporter(_ enabled: Bool) async {
        ft8PskReporter = enabled
        persistFt8Settings()
        try? await api.ft8SetPskReporter(enabled)
    }

    /// Stash current rig freq/mode/width so we can restore them on exiting FT8.
    func captureFt8RestorePoint() {
        preFt8Freq = sharedFreq
        preFt8Mode = sharedMode
        preFt8Width = sharedWidth
    }

    /// Switch radio to FT8 TX mode (USB or PKTUSB) and prior FT8 freq if any.
    func enterFt8Mode() async {
        if useCivMode, civ.isConnected {
            let mode = ft8TxMode; let freq = ft8LastFreq
            _ = await Task.detached(priority: .userInitiated) { [civ = self.civ] in
                _ = civ.setMode(mode, width: 3000)
                if freq > 0 { _ = civ.setFrequency(freq) }
            }.value
            return
        }
        do {
            try await api.setMode(mode: ft8TxMode, width: 3000)
            if ft8LastFreq > 0 { try await api.setFreq(hz: ft8LastFreq) }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    /// Restore previous mode/freq when leaving FT8.
    func exitFt8Mode() async {
        if sharedFreq > 0 { ft8LastFreq = sharedFreq }
        persistFt8Settings()
        if useCivMode, civ.isConnected {
            let mode = preFt8Mode; let freq = preFt8Freq; let width = preFt8Width
            _ = await Task.detached(priority: .userInitiated) { [civ = self.civ] in
                if !mode.isEmpty { _ = civ.setMode(mode, width: width) }
                if freq > 0 { _ = civ.setFrequency(freq) }
            }.value
        } else {
            do {
                if !preFt8Mode.isEmpty { try await api.setMode(mode: preFt8Mode, width: preFt8Width) }
                if preFt8Freq > 0 { try await api.setFreq(hz: preFt8Freq) }
            } catch {
                errorMessage = error.localizedDescription
            }
        }
        if preFt8Freq > 0 { sharedFreq = preFt8Freq }
        if !preFt8Mode.isEmpty { sharedMode = preFt8Mode }
    }

    func setFt8TxMode(_ m: String) async {
        ft8TxMode = m
        persistFt8Settings()
        if useCivMode, civ.isConnected {
            _ = await Task.detached(priority: .userInitiated) { [civ = self.civ, m] in
                _ = civ.setMode(m, width: 3000)
            }.value
            return
        }
        do { try await api.setMode(mode: m, width: 3000) }
        catch { errorMessage = error.localizedDescription }
    }

    func updateFt8LatencyMs(_ ms: Int) {
        ft8LatencyMs = max(-10000, min(10000, ms))
        persistFt8Settings()
    }

    /// Fetch Pi server time, compute clock offset (Pi_ms - iOS_ms), and return it.
    /// Returns 0 on failure.
    func syncFt8Clock() async throws -> Int64 {
        return try await api.getPiClockOffsetMs()
    }

    /// Server-side FT8/FT4 TX (v2.02). Composes a basic CQ message if dxCall is empty.
    func ft8ServerTx() async -> String? {
        let call = ft8MyCall.uppercased()
        let grid = ft8MyGrid.uppercased()
        let dx = ft8DxCall.uppercased()
        let msg: String
        if dx.isEmpty {
            msg = "CQ \(call) \(String(grid.prefix(4)))"
        } else {
            msg = "\(dx) \(call) \(String(grid.prefix(4)))"
        }
        if isDemoMode { return nil }
        do {
            try await api.ft8Tx(msg: msg, audioFreqHz: 1500, rate: 12000, isFt4: ft8IsFt4)
            return nil
        } catch {
            return error.localizedDescription
        }
    }

    func rttyFskTx(port: String, text: String, baud: Double = 45.45, fskPin: String = "DTR") async -> Bool {
        if isDemoMode { return false }
        stopStatusPolling()
        defer { startStatusPolling() }
        do {
            try await api.rttyFskTx(port: port, text: text, baud: baud, fskPin: fskPin)
            return true
        } catch {
            return false
        }
    }

    private let rttyAudioTx = RttyPiAudioTx()

    /// Transmits a pre-built AFSK RTTY burst through the Pi's audio output: switch the rig to
    /// the data mode, key PTT, stream the PCM to `/radio/audio_tx`, then restore the RX
    /// frequency and mode. Mirrors the Android `streamRttyTx` Pi branch.
    ///
    /// This is the path that works on both rigs here. Serial FSK keying cannot be used: the
    /// IC-705 has no FSK shift input, and on the FT-991A the Pi's software DTR timing is far
    /// too coarse for a 22 ms bit period. Audio is clocked by the sound card, so the bit
    /// timing is exact no matter how busy the Pi is.
    ///
    /// Returns nil on success, or a message describing what failed.
    func rttyPiAudioTx(pcm: Data, sampleRate: Int, txMode: String, rxMode: String,
                       txFreq: Int64, rxFreq: Int64) async -> String? {
        if isDemoMode { return "demo mode" }
        let audioSeconds = Double(pcm.count / 2) / Double(sampleRate)
        // Every step here is timed, because the symptom of a broken RTTY transmission is
        // "it sounded right but nothing decoded", and the only way to tell a stalled audio
        // handover apart from a slow CAT round trip is to measure them separately.
        var marks: [(String, TimeInterval)] = []
        var last = Date()
        func mark(_ name: String) {
            let now = Date()
            marks.append((name, now.timeIntervalSince(last)))
            last = now
        }

        stopStatusPolling()
        // Mode FIRST, then frequency. Leaving RTTY for a data mode moves the FT-991A's VFO,
        // because the two modes do not display the same point: RTTY shows the mark, PKTLSB
        // shows the suppressed carrier. Setting the frequency before the mode therefore had
        // the rig shift it afterwards, landing the signal about 1 kHz off, which is why the
        // transmission only decoded when the dial was moved from 144.600 to 144.601 by hand.
        await setMode(txMode, width: 3000); mark("setMode")
        // Let the mode change land before pinning the frequency, or the rig's own shift
        // arrives after ours and undoes it.
        try? await Task.sleep(nanoseconds: 1_200_000_000)
        if txFreq > 0 { await setFreq(txFreq); mark("setFreq") }
        // Read the frequency back: this is the step that was silently wrong before, so it is
        // worth knowing whether the rig actually accepted it.
        if let st = try? await api.getStatus() {
            mark("verify")
            if txFreq > 0 && abs(st.freq - txFreq) > 10 {
                NSLog("[RTTY TX] frequency mismatch: asked %lld, rig reports %lld (mode=%@)",
                      txFreq, st.freq, st.mode)
            }
        }

        var failure: String?
        // micAudio: false — this path supplies its own PCM, and the mic uploader would open a
        // second, competing audio_tx stream.
        await setPtt(on: true, micAudio: false); mark("pttOn")
        try? await Task.sleep(nanoseconds: 300_000_000)
        var handover: TimeInterval = 0
        do {
            handover = try await rttyAudioTx.send(pcm: pcm, host: streamHost, apiPort: apiPort,
                                                  apiKey: apiKey, sampleRate: sampleRate)
            mark("stream")
        } catch {
            failure = error.localizedDescription
            mark("stream-failed")
        }
        // `send` now returns when the Pi answers, and it only answers after aplay has played
        // every sample, so the audio has already finished here. All that is left is a short
        // margin for the rig's own TX-to-RX turnaround.
        //
        // This used to guess: hold PTT for `audioSeconds - handover` plus 0.4 s. The guess was
        // always short, because aplay does not start until the Pi has killed its capture
        // processes and spawned it, which costs several hundred milliseconds on a Pi Zero. PTT
        // therefore dropped before the tail played and the last character was lost every time.
        let remaining = 0.4
        try? await Task.sleep(nanoseconds: UInt64(remaining * 1_000_000_000))
        await setPtt(on: false, micAudio: false); mark("pttOff")
        // Same order on the way back: returning to RTTY moves the VFO too, so restore the
        // mode first and only then put the frequency where the operator left it.
        await setMode(rxMode, width: 0)
        try? await Task.sleep(nanoseconds: 1_200_000_000)
        if rxFreq > 0 { await setFreq(rxFreq) }
        mark("restore")
        startStatusPolling()

        let detail = marks.map { "\($0.0)=\(String(format: "%.2f", $0.1))s" }.joined(separator: " ")
        NSLog("[RTTY TX] AFSK audio=%.2fs handover=%.2fs hold=%.2fs | %@",
              audioSeconds, handover, remaining, detail)
        return failure
    }

    // MARK: FT8 native API wrappers (v3.00)

    func ft8Start() async throws { try await api.ft8Start() }
    func ft8Stop()  async throws { try await api.ft8Stop() }

    func ft8SetAutoTx(active: Bool, mode: String, msg: String, audioFreqHz: Int) async throws {
        try await api.ft8SetAutoTx(active: active, mode: mode, msg: msg, audioFreqHz: audioFreqHz)
    }

    func ft8CqAuto(active: Bool, msg: String, mode: String, audioFreqHz: Int,
                   myCall: String, myGrid: String) async throws {
        try await api.ft8CqAuto(active: active, msg: msg, mode: mode, audioFreqHz: audioFreqHz,
                                myCall: myCall, myGrid: myGrid)
    }

    func ft8StartQso(firstMsg: String, dxCall: String, myCall: String, txMode: String,
                     audioFreqHz: Int, initialState: Int = 0, stepSnrMsg: String = "",
                     step2Msg: String = "", step3Msg: String = "", step4Msg: String = "") async throws {
        try await api.ft8StartQso(firstMsg: firstMsg, dxCall: dxCall, myCall: myCall,
                                   txMode: txMode, audioFreqHz: audioFreqHz,
                                   initialState: initialState, stepSnrMsg: stepSnrMsg,
                                   step2Msg: step2Msg, step3Msg: step3Msg, step4Msg: step4Msg)
    }

    func ft8CancelQso() async throws { try await api.ft8CancelQso() }

    func ft8SetDepth(_ depth: Int) async throws { try await api.ft8SetDepth(depth) }

    func ft8SetFt4(_ isFt4: Bool) async throws { try await api.ft8SetFt4(isFt4) }

    func ft8SetTxGain(_ gain: Float) async throws { try await api.ft8SetTxGain(gain) }

    func ft8SetDecodeFilter(freqs: [Int], bw: Int = 150) async throws {
        try await api.ft8SetDecodeFilter(freqs: freqs, bw: bw)
    }

    func ft8DecodeDebug() async throws -> String { try await api.ft8DecodeDebug() }

    func makeFt8SseRequest(path: String) async -> URLRequest? {
        try? await api.makeSseRequest(path: path)
    }

    /// Convert lat/lon to 6-character Maidenhead grid locator.
    nonisolated static func latLonToGrid(lat: Double, lon: Double) -> String {
        guard lat.isFinite, lon.isFinite else { return "" }
        let adjLon = max(0.0, min(lon + 180.0, 360.0))
        let adjLat = max(0.0, min(lat + 90.0, 180.0))
        let scalar = UnicodeScalar("A").value
        let zeroAscii = UnicodeScalar("0").value
        func chr(_ n: Int, base: UInt32) -> Character { Character(UnicodeScalar(base + UInt32(n))!) }
        let f1 = Int(adjLon / 20.0)
        let f2 = Int(adjLat / 10.0)
        let s1 = Int(adjLon.truncatingRemainder(dividingBy: 20) / 2)
        let s2 = Int(adjLat.truncatingRemainder(dividingBy: 10))
        let sub1 = Int(adjLon.truncatingRemainder(dividingBy: 2) / 2.0 * 24.0)
        let sub2 = Int(adjLat.truncatingRemainder(dividingBy: 1) * 24.0)
        return String([
            chr(f1, base: scalar),
            chr(f2, base: scalar),
            chr(s1, base: zeroAscii),
            chr(s2, base: zeroAscii),
            chr(sub1, base: scalar),
            chr(sub2, base: scalar)
        ])
    }

    /// Get a one-shot location fix for grid locator. Returns nil if no fix.
    func currentLocationFix() -> (lat: Double, lon: Double)? {
        guard let l = location.latest else { return nil }
        return (l.coordinate.latitude, l.coordinate.longitude)
    }

    /// Read-only access for FT8 view to compose its WebView URL/headers and JS.
    var ft8Host: String { hostName }
    var ft8ApiKey: String { apiKey }
    var ft8ApiPort: Int { apiPort }

    // MARK: - Profiles

    var profiles: [ProfileConfig] = ProfileStore.loadAll()

    /// Capture current connection-related state into a ProfileConfig.
    func snapshotCurrentProfile(name: String) -> ProfileConfig {
        ProfileConfig(
            name: name,
            hostName: hostName,
            apiPort: apiPort,
            audioPort: audioPort,
            useMDNS: useMDNS,
            apiKey: apiKey,
            savedRigId: rigList.indices.contains(selectedRigIndex) ? rigList[selectedRigIndex].id : -1,
            savedCat: catList.indices.contains(selectedCatIndex) ? catList[selectedCatIndex] : "",
            savedPttDevice: selectedPttDevice,
            savedPttType: selectedPttType.rawValue,
            savedBaudIndex: selectedBaudIndex,
            savedSamplingIndex: selectedSamplingIndex,
            useWifiPTT: useWifiPTT,
            pttHost: pttHost,
            pttPort: pttPort,
            alsaDevice: selectedAudioCapture,
            alsaDeviceFt8: selectedAudioPlayback,
            useCivMode: useCivMode,
            civHost: civHost,
            civUsername: civUsername,
            civPassword: civPassword,
            civPort1: civPort1,
            civPort2: civPort2,
            civPort3: civPort3,
            civAddressHex: civAddressHex
        )
    }

    func saveProfile(name: String) {
        var p = snapshotCurrentProfile(name: name)
        if let idx = profiles.firstIndex(where: { $0.name == name }) {
            p.id = profiles[idx].id
            profiles[idx] = p
        } else {
            profiles.append(p)
        }
        ProfileStore.saveAll(profiles)
        ProfileStore.activeId = p.id
    }

    func deleteProfile(_ id: UUID) {
        profiles.removeAll(where: { $0.id == id })
        ProfileStore.saveAll(profiles)
        if ProfileStore.activeId == id { ProfileStore.activeId = nil }
    }

    func loadProfile(_ p: ProfileConfig) {
        hostName = p.hostName
        apiPort = p.apiPort
        audioPort = p.audioPort
        useMDNS = p.useMDNS
        apiKey = p.apiKey
        selectedPttDevice = p.savedPttDevice
        selectedPttType = PttType(rawValue: p.savedPttType) ?? .rts
        // Clamp profile-saved indices to the current arrays — an out-of-range value
        // (older app build / imported profile) otherwise crashes the direct subscripts
        // in RigSelectView / openSelectedRig, which surfaces as a stuck black screen.
        selectedBaudIndex = AppConstants.baudRates.indices.contains(p.savedBaudIndex)
            ? p.savedBaudIndex : AppConstants.defaultBaudIndex
        selectedSamplingIndex = AppConstants.samplingRates.indices.contains(p.savedSamplingIndex)
            ? p.savedSamplingIndex : AppConstants.defaultSamplingIndex
        useWifiPTT = p.useWifiPTT
        pttHost = p.pttHost
        pttPort = p.pttPort
        selectedAudioCapture = p.alsaDevice
        selectedAudioPlayback = p.alsaDeviceFt8
        useCivMode = p.useCivMode
        civHost = p.civHost
        civUsername = p.civUsername
        civPassword = p.civPassword
        civPort1 = p.civPort1
        civPort2 = p.civPort2
        civPort3 = p.civPort3
        civAddressHex = p.civAddressHex
        ProfileStore.activeId = p.id
        savedRigId = p.savedRigId
        savedCatDevice = p.savedCat
        let d = UserDefaults.standard
        d.set(p.savedRigId, forKey: "savedRigId")
        d.set(p.savedCat, forKey: "savedCatDevice")
        d.set(selectedBaudIndex, forKey: "selectedBaudIndex")
        d.set(selectedSamplingIndex, forKey: "selectedSamplingIndex")
        d.set(selectedPttDevice, forKey: "selectedPttDevice")
        d.set(selectedPttType.rawValue, forKey: "selectedPttType")
        d.set(selectedAudioCapture, forKey: "selectedAudioCapture")
        d.set(selectedAudioPlayback, forKey: "selectedAudioPlayback")
        persistConnectionSettings()
    }

    // MARK: - CW (v2.02 server-side bridge)

    var cwBridgeStatus: CwStatus?
    var cwMorseSending: Bool = false
    private var cwSidetoneTask: Task<Void, Never>?
    /// Single in-flight CW send/poll task. Cancelled before starting a new one
    /// (prevents the "endless send" symptom from a stuck or duplicated polling loop).
    private var cwTextTask: Task<Void, Never>?

    func cwRefreshStatus() async {
        if isDemoMode {
            cwBridgeStatus = CwStatus(connected: true, synced: true, offset_ms: 12, max_late_ms: 3)
            return
        }
        cwBridgeStatus = try? await api.cwStatus()
    }

    func cwOpen() async -> String? {
        persistCwSettings()
        if isDemoMode { return nil }
        do { try await api.cwOpen(port: cwPort, delayMs: cwDelayMs); return nil }
        catch { return error.localizedDescription }
    }

    func cwClose() async {
        if isDemoMode { return }
        try? await api.cwClose()
    }

    func cwKey(_ on: Bool) async {
        if isDemoMode { return }
        try? await api.cwKey(on)
    }

    /// Normalize full-width ASCII (`！..～`) and ideographic space (`　`) into half-width.
    /// Mirrors the v2.02 Android `sendCwText` normalization step.
    private func normalizeCwText(_ s: String) -> String {
        String(s.map { c -> Character in
            let scalar = c.unicodeScalars.first!.value
            if scalar >= 0xFF01 && scalar <= 0xFF5E {  // ！..～ → !..~
                return Character(UnicodeScalar(scalar - 0xFEE0)!)
            }
            if scalar == 0x3000 { return " " }  // U+3000 ideographic space
            return c
        })
    }

    func cwSendMorse() async -> String? {
        let raw = cwLastText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return "Empty text" }
        let text = normalizeCwText(raw)
        persistCwSettings()

        // Cancel any previous in-flight CW send job to guarantee a single active poll loop.
        cwTextTask?.cancel()
        cwTextTask = nil

        if isDemoMode {
            cwMorseSending = true
            startLocalCwSidetone(text: text, wpm: cwWpm)
            cwTextTask = Task { @MainActor [weak self] in
                try? await Task.sleep(nanoseconds: 1_500_000_000)
                self?.cwMorseSending = false
                self?.stopLocalCwSidetone()
            }
            return nil
        }

        // CI-V direct path: IC-705内蔵キーヤーまたはPTT-per-elementで送信。
        // mode チェックは省略: sharedModeが未取得でもCI-V接続中ならCI-Vパスを使う。
        if useCivMode, civ.isConnected {
            return await civCwSendMorse(text: text)
        }

        // Pause status polling while CW transmits — matches Android v2.02 setPoll(false) pattern.
        try? await api.setPoll(state: false)

        // FM mode: pre-build full CW PCM and stream to Pi audio endpoint (same as CI-V path)
        if sharedMode.uppercased().contains("FM") || sharedMode.uppercased() == "DSTAR" || sharedMode.uppercased() == "D-STAR" {
            cwMorseSending = true
            startLocalCwSidetone(text: text, wpm: cwWpm)
            let ditMs = 1200.0 / Double(max(5, min(60, cwWpm)))
            let pcm = buildCwPcm(text: text.uppercased(), ditMs: ditMs)
            try? await api.setPtt(state: true)
            await streamCwPcmToWifi(pcm: pcm)
            try? await Task.sleep(nanoseconds: 600_000_000)
            try? await api.setPtt(state: false)
            try? await api.setPoll(state: true)
            cwMorseSending = false
            stopLocalCwSidetone()
            return nil
        }

        do {
            // Start local sidetone in parallel with sending text to Pi.
            // Android方式: サイドトーンはWifi_Rig_CWとは独立してiOS側タイミングで生成。
            startLocalCwSidetone(text: text, wpm: cwWpm)
            try await api.cwSendMorse(text: text, wpm: cwWpm)
            // CQ repeatでSTOPが押されると呼び元タスクがキャンセルされる。
            // awaitから戻った後にキャンセル済みなら cwTextTask を作らず即終了。
            if Task.isCancelled {
                stopLocalCwSidetone()
                try? await api.cwStopMorse()
                try? await api.setPoll(state: true)
                return nil
            }
            cwMorseSending = true
        } catch {
            stopLocalCwSidetone()
            try? await api.setPoll(state: true)
            return error.localizedDescription
        }

        cwTextTask = Task { @MainActor [weak self] in
            guard let self else { return }
            while !Task.isCancelled, self.cwMorseSending {
                try? await Task.sleep(nanoseconds: 500_000_000)
                if Task.isCancelled { break }
                let stillSending = (try? await self.api.cwMorseStatus()) ?? false
                if !stillSending { break }
            }
            // Skip cleanup if cancelled — the canceller (new send or cwStopMorse) owns cleanup.
            guard !Task.isCancelled else { return }
            self.cwMorseSending = false
            // Do NOT stop sidetone here — let it self-terminate so the last character
            // is not cut off. stopLocalCwSidetone() is called by cwStopMorse() on
            // manual stop, and by startLocalCwSidetone() when the next send begins.
            try? await self.api.cwStopMorse()
            try? await self.api.setPtt(state: false)
            try? await self.api.setPoll(state: true)
            self.cwTextTask = nil
        }
        return nil
    }

    // CI-V CW送信: BK-IN ONなら内蔵キーヤー、OFFならPTT-per-element (Android 2.15同等)
    // getBkIn() のみ blocking socket I/O のため Task.detached; UDP送信メソッドは直接呼び出し。
    private func civCwSendMorse(text: String) async -> String? {
        cwMorseSending = true
        startLocalCwSidetone(text: text, wpm: cwWpm)

        let ditMs = 1200.0 / Double(max(5, min(60, cwWpm)))
        // IC-705 internal keyer (cmd 0x17) only works in CW mode.
        // FM mode must use PCM audio streaming regardless of BK-IN setting.
        let isFm = sharedMode.uppercased().contains("FM")
            || sharedMode.uppercased() == "DSTAR" || sharedMode.uppercased() == "D-STAR"
        let isBkIn = isFm ? false : await Task.detached(priority: .userInitiated) { [civ = self.civ] in
            civ.getBkIn() ?? false
        }.value

        if isBkIn {
            // IC-705内蔵キーヤーでCW送信 (BK-IN ON)
            civ.setKeySpeed(cwWpm)
            try? await Task.sleep(nanoseconds: 50_000_000)

            var chunks: [String] = []
            var buf = ""
            for ch in text.uppercased() {
                buf.append(ch)
                if buf.count >= 30 { chunks.append(buf); buf = "" }
            }
            if !buf.isEmpty { chunks.append(buf) }

            for chunk in chunks {
                if Task.isCancelled { break }
                civ.sendCwMessage(chunk)
                let units = civMorseDurationUnits(chunk)
                let durNs = UInt64(Double(units) * ditMs * 1_000_000) + 300_000_000
                try? await Task.sleep(nanoseconds: durNs)
            }
            civ.stopCwMessage()
        } else if isFm {
            // FM-CW: 完全なCW PCM（700Hzトーン＋無音）を事前生成し RS-BA1 TX audio に直接ストリーミング
            // Android の sendCwTextCiv (non-CW mode path) と同じ方式
            let pcm = buildCwPcm(text: text.uppercased(), ditMs: ditMs)
            _ = await Task.detached(priority: .userInitiated) { [civ = self.civ] in
                civ.setPtt(true)
            }.value
            civ.stopTxAudioCapture()  // マイク入力を止め、CWトーンのみを送る
            let chunkSize = 320       // 20ms @ 8000 Hz (160 samples × 2 bytes)
            var offset = 0
            var nextMs = Int64(Date().timeIntervalSince1970 * 1000)
            while offset < pcm.count {
                if Task.isCancelled { break }
                let end = min(offset + chunkSize, pcm.count)
                civ.sendTxAudioDirect(pcm.subdata(in: offset..<end))
                offset = end
                nextMs += 20
                let sleepMs = nextMs - Int64(Date().timeIntervalSince1970 * 1000)
                if sleepMs > 1 { try? await Task.sleep(nanoseconds: UInt64(sleepMs) * 1_000_000) }
            }
            try? await Task.sleep(nanoseconds: 600_000_000)
            _ = await Task.detached(priority: .userInitiated) { [civ = self.civ] in
                _ = civ.setPtt(false)
            }.value
        } else {
            // CW mode PTT-per-element (BK-IN OFF)
            let seq = cwMorseSequence(for: text.uppercased(), unitMs: ditMs)
            for (isOn, durMs) in seq {
                if Task.isCancelled { break }
                if isOn { civ.civPttDown() } else { civ.civPttUp() }
                try? await Task.sleep(nanoseconds: UInt64(max(1, durMs) * 1_000_000))
            }
            civ.civPttUp()
        }

        cwMorseSending = false
        stopLocalCwSidetone()
        return nil
    }

    /// Android の buildCwPcm() 相当: 700Hz サイン波（要素ON）と無音（要素OFF）を連結した 8kHz 16bit PCM を生成する。
    private func buildCwPcm(text: String, ditMs: Double, sampleRate: Int = 8000) -> Data {
        let seq = cwMorseSequence(for: text, unitMs: ditMs)
        var pcm = Data()
        var phase = 0.0
        for (isOn, durMs) in seq {
            let nSamples = max(1, Int(durMs * Double(sampleRate) / 1000.0))
            var chunk = Data(count: nSamples * 2)
            chunk.withUnsafeMutableBytes { raw in
                let dst = raw.baseAddress!.assumingMemoryBound(to: Int16.self)
                for i in 0..<nSamples {
                    if isOn {
                        phase += 2.0 * .pi * 700.0 / Double(sampleRate)
                        dst[i] = Int16(clamping: Int(32767.0 * 0.7 * sin(phase)))
                    } else {
                        dst[i] = 0
                    }
                }
            }
            if isOn { phase = phase.truncatingRemainder(dividingBy: 2.0 * .pi) }
            pcm.append(chunk)
        }
        return pcm
    }

    /// WiFi FM-CW: pre-built PCM を Pi の /radio/audio_tx へストリーミング送信する。
    /// CwAudioStream と同じ bound-streams + DispatchQueue パターン (Swift Task ではブロッキング書き込みがコープスレッドを占有するため)。
    /// Stream pre-built 8 kHz PCM-16 mono to the Pi TX audio endpoint (RTTY AFSK etc.).
    /// `isCancelled` is polled between chunks so the caller can abort mid-message.
    func streamPcmToPi(_ pcm: Data, isCancelled: (@Sendable () -> Bool)? = nil) async {
        await streamCwPcmToWifi(pcm: pcm, isCancelled: isCancelled)
    }

    private func streamCwPcmToWifi(pcm: Data, isCancelled: (@Sendable () -> Bool)? = nil) async {
        let host = hostName
        let port = apiPort
        let key = apiKey
        await withCheckedContinuation { (continuation: CheckedContinuation<Void, Never>) in
            guard !host.isEmpty,
                  let url = URL(string: "http://\(host):\(port)/radio/audio_tx?rate=8000") else {
                continuation.resume()
                return
            }
            var inS: InputStream?
            var outS: OutputStream?
            Stream.getBoundStreams(withBufferSize: 16384, inputStream: &inS, outputStream: &outS)
            guard let inputStream = inS, let outputStream = outS else {
                continuation.resume()
                return
            }
            outputStream.open()
            var req = URLRequest(url: url)
            req.httpMethod = "POST"
            req.httpBodyStream = inputStream
            req.setValue("application/octet-stream", forHTTPHeaderField: "Content-Type")
            if !key.isEmpty { req.setValue(key, forHTTPHeaderField: "X-API-Key") }
            let config = URLSessionConfiguration.ephemeral
            config.timeoutIntervalForRequest = .infinity
            config.timeoutIntervalForResource = .infinity
            let session = URLSession(configuration: config)
            let task = session.uploadTask(withStreamedRequest: req)
            task.resume()
            DispatchQueue(label: "cw.wifi.pcm", qos: .userInitiated).async {
                let chunkSize = 160  // 10ms @ 8000 Hz
                var offset = 0
                var nextMs = Date().timeIntervalSince1970 * 1000
                while offset < pcm.count {
                    if isCancelled?() == true { break }
                    nextMs += 10
                    let end = min(offset + chunkSize, pcm.count)
                    let chunk = pcm.subdata(in: offset..<end)
                    var waited = 0
                    while waited < 100 {
                        if outputStream.hasSpaceAvailable { break }
                        Thread.sleep(forTimeInterval: 0.005)
                        waited += 1
                    }
                    _ = chunk.withUnsafeBytes { ptr -> Int in
                        guard let base = ptr.baseAddress?.assumingMemoryBound(to: UInt8.self) else { return 0 }
                        return outputStream.write(base, maxLength: chunk.count)
                    }
                    offset = end
                    let sleepMs = nextMs - Date().timeIntervalSince1970 * 1000
                    if sleepMs > 0 { Thread.sleep(forTimeInterval: sleepMs / 1000.0) }
                }
                outputStream.close()
                task.cancel()
                session.invalidateAndCancel()
                continuation.resume()
            }
        }
    }

    // テキスト中の全符号要素のdit単位数合計を返す (チャンク待機時間計算用)
    private func civMorseDurationUnits(_ text: String) -> Int {
        var units = 0
        let words = text.uppercased().split(separator: " ", omittingEmptySubsequences: true)
        for (wi, word) in words.enumerated() {
            if wi > 0 { units += 7 }  // inter-word gap (7 dits)
            var charsDone = 0
            for ch in word {
                guard let code = cwMorseTable[ch] else { continue }
                if charsDone > 0 { units += 3 }  // inter-char gap
                for (ei, e) in code.enumerated() {
                    if ei > 0 { units += 1 }
                    units += (e == ".") ? 1 : 3
                }
                charsDone += 1
            }
        }
        return units
    }

    /// Toggle CW break-in on the rig.
    func setBkIn(on: Bool) async {
        sharedBkIn = on
        if isDemoMode { return }
        if useCivMode, civ.isConnected {
            _ = await Task.detached(priority: .userInitiated) { [civ = self.civ, on] in civ.setBkIn(on) }.value
            return
        }
        do { try await api.setBkIn(on: on) }
        catch { errorMessage = "BK-IN: \(error.localizedDescription)" }
    }

    /// Persist current NR level and apply to rig via Hamlib FastAPI endpoint.
    /// `0` = Off, `1..5` = NR strength.
    func applyNoiseReduction() async {
        UserDefaults.standard.set(noiseReductionLevel, forKey: "noiseReductionLevel")
        if isDemoMode { return }
        do { try await api.setNrLevel(noiseReductionLevel) }
        catch { errorMessage = "NR: \(error.localizedDescription)" }
    }

    /// Cycle NR Off → 1 → 2 → 3 → 4 → 5 → Off. Mirrors Android `cycleNoiseReduction()`.
    func cycleNoiseReduction() async {
        noiseReductionLevel = (noiseReductionLevel + 1) % 6
        await applyNoiseReduction()
    }

    /// Set NR level directly from button grid.
    func setNoiseReduction(_ level: Int) async {
        noiseReductionLevel = max(0, min(5, level))
        await applyNoiseReduction()
    }

    /// Toggle CW decode panel + wire/unwire the audio→decoder pipeline.
    // MARK: - Band Memory (v2.31)

    var userMemories: [MemoryEntry] {
        guard let data = UserDefaults.standard.data(forKey: "user_memories_json"),
              let list = try? JSONDecoder().decode([MemoryEntry].self, from: data)
        else { return [] }
        return list
    }

    func saveUserMemories(_ list: [MemoryEntry]) {
        if let data = try? JSONEncoder().encode(list) {
            UserDefaults.standard.set(data, forKey: "user_memories_json")
        }
    }

    var customPresets: [MemoryEntry] {
        guard let data = UserDefaults.standard.data(forKey: "custom_presets_json"),
              let list = try? JSONDecoder().decode([MemoryEntry].self, from: data),
              !list.isEmpty
        else { return PRESET_MEMORIES }
        return list
    }

    func saveCustomPresets(_ list: [MemoryEntry]) {
        if let data = try? JSONEncoder().encode(list) {
            UserDefaults.standard.set(data, forKey: "custom_presets_json")
        }
    }

    func resetCustomPresets() {
        UserDefaults.standard.removeObject(forKey: "custom_presets_json")
    }

    func recallMemory(_ entry: MemoryEntry) async {
        try? await Task.sleep(nanoseconds: 100_000_000)  // 0.1s — screen transition
        let resolvedMode = entry.mode.isEmpty ? "" : resolveMode(entry.mode, freqHz: entry.freqHz)
        let w = resolvedMode.isEmpty ? 0 : modeDefaultWidth(resolvedMode)
        if !resolvedMode.isEmpty {
            for _ in 0..<2 {
                try? await Task.sleep(nanoseconds: 150_000_000)  // 150ms
                await setMode(resolvedMode, width: w > 0 ? w : sharedWidth)
            }
            let stepIdx = entry.stepIndex >= 0 ? entry.stepIndex
                        : AppConstants.defaultStepIndex(forMode: resolvedMode)
            selectedStepIndex = stepIdx
            rememberStepForCurrentMode()
        }
        for _ in 0..<3 {
            try? await Task.sleep(nanoseconds: 150_000_000)  // 150ms
            if !resolvedMode.isEmpty {
                await setMode(resolvedMode, width: w > 0 ? w : sharedWidth)
                await setFreq(entry.freqHz)
            } else {
                await setFreq(entry.freqHz)
            }
        }
    }

    func toggleCwDecode() async {
        cwDecodeActive.toggle()
        if cwDecodeActive {
            // Use the actual streaming sample rate so timing parameters are correct.
            // If SPK is off (rate=0), fall back to 8000 Hz.
            let rate = AppConstants.samplingRates[selectedSamplingIndex]
            cwDecoder = CwDecoder(sampleRate: rate > 0 ? rate : 8000)
            cwRxDecodedText = ""
            cwTxDecodedText = ""
            resetTxDecoder()
            cwDecoder.onCharDecoded = { [weak self] char, channel in
                guard channel == 0 else { return }
                Task { @MainActor [weak self] in
                    guard let self else { return }
                    self.cwRxDecodedText += String(char)
                    if self.cwRxDecodedText.count > self.cwDecodeMaxChars {
                        self.cwRxDecodedText = String(self.cwRxDecodedText.suffix(self.cwDecodeMaxChars))
                    }
                }
            }
            refreshAudioRxSampleDispatch()
        } else {
            cwDecoder.onCharDecoded = nil
            cwDecoder.reset()
            resetTxDecoder()
            refreshAudioRxSampleDispatch()
        }
    }

    /// The sample rate the Pi audio stream is currently running at (0 if not running).
    /// Used by RTTY / CW views to create modems at the exact stream rate.
    var audioRxSampleRate: Int { audioRx.isRunning ? audioRx.sampleRate : 0 }

    /// Fan out audioRx samples to CW decoder and optional RTTY handler.
    func refreshAudioRxSampleDispatch() {
        let cwActive = cwDecodeActive
        if !cwActive && rttyAudioHandler == nil {
            audioRx.onSamples = nil
            return
        }
        audioRx.onSamples = { [weak self] samples in
            if cwActive { self?.cwDecoder.processSamples(samples) }
            self?.rttyAudioHandler?(samples)
        }
    }

    func cwStopMorse() async {
        // Cancel local polling first so the cleanup branch doesn't double-fire.
        cwTextTask?.cancel()
        cwTextTask = nil
        cwMorseSending = false
        stopLocalCwSidetone()
        if isDemoMode { return }
        if useCivMode, civ.isConnected {
            civ.stopCwMessage()
            civ.civPttUp()
            return
        }
        // v2.02 cleanup triplet — guarantees Pi-side stops keying and resumes polling.
        try? await api.cwStopMorse()
        try? await api.setPtt(state: false)
        try? await api.setPoll(state: true)
    }

    // MARK: - Local sidetone for CW TX text (Android方式: Pi CWとは独立したタイミング管理)

    private func startLocalCwSidetone(text: String, wpm: Int) {
        cwSidetoneTask?.cancel()
        guard cwBle.sidetoneEnabled else { return }
        // Lazy-start sidetone engine if not yet initialized (BLE keyer not connected)
        cwBle.startSidetoneLazy()
        let unitMs = 1200.0 / Double(max(1, wpm))
        let seq = cwMorseSequence(for: text.uppercased(), unitMs: unitMs)
        guard !seq.isEmpty else { return }
        let cwBleRef = cwBle
        // Task.detached: バックグラウンドスレッドで絶対時刻ベースのタイミング管理。
        // @MainActor + 相対sleep は UIレンダリングに競合してジッタが生じるため、
        // nonisolated の setSidetoneKeyRealtime() を直接呼んで符号精度を確保する。
        // 20ms先読みバッファにより処理落ち時も正しく発音できる。
        cwSidetoneTask = Task.detached(priority: .userInteractive) {
            let lookaheadNs: UInt64 = 20_000_000  // 20ms lookahead buffer
            var targetNs = DispatchTime.now().uptimeNanoseconds + lookaheadNs
            for (isOn, durMs) in seq {
                if Task.isCancelled { break }
                let now = DispatchTime.now().uptimeNanoseconds
                if targetNs > now {
                    try? await Task.sleep(nanoseconds: targetNs - now)
                }
                // Re-check after sleep: cancellation swallowed by try? must not
                // let a key-ON write slip through after stopLocalCwSidetone() ran.
                if Task.isCancelled { break }
                cwBleRef.setSidetoneKeyRealtime(isOn)
                targetNs += UInt64(max(1, durMs) * 1_000_000)
            }
            // Wait until the scheduled end of the last element before turning key off.
            // Without this sleep the final dash/dot key-ON is immediately followed by key-OFF
            // (loop exits without sleeping), causing the last character to produce no sound.
            if !Task.isCancelled {
                let now = DispatchTime.now().uptimeNanoseconds
                if targetNs > now {
                    try? await Task.sleep(nanoseconds: targetNs - now)
                }
            }
            // Always turn key off — covers both normal completion and cancellation.
            cwBleRef.setSidetoneKeyRealtime(false)
        }
    }

    private func stopLocalCwSidetone() {
        cwSidetoneTask?.cancel()
        cwSidetoneTask = nil
        cwBle.setSidetoneKey(false)
    }

    private func cwMorseSequence(for text: String, unitMs: Double) -> [(Bool, Double)] {
        var result: [(Bool, Double)] = []
        let words = text.split(separator: " ", omittingEmptySubsequences: true)
        for (wi, word) in words.enumerated() {
            if wi > 0 { result.append((false, unitMs * 7)) }
            var charsDone = 0
            for ch in word {
                guard let code = cwMorseTable[ch] else { continue }
                if charsDone > 0 { result.append((false, unitMs * 3)) }
                for (ei, e) in code.enumerated() {
                    if ei > 0 { result.append((false, unitMs)) }
                    result.append((true, e == "." ? unitMs : unitMs * 3))
                }
                charsDone += 1
            }
        }
        return result
    }

    // MARK: - CW TX helper (direct text send from CW screen)

    func cwSendText(_ text: String) async {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty, !cwMorseSending else { return }
        cwLastText = t
        _ = await cwSendMorse()
    }

    func cwStartCqRepeat(_ text: String) {
        guard !cwCqRepeating else { cwStopCqRepeat(); return }
        cwCqRepeating = true
        let count = cwCqLoopCount
        let intervalSec = cwCqLoopInterval
        cwCqRepeatTask = Task { @MainActor [weak self] in
            guard let self else { return }
            var i = 0
            while self.cwCqRepeating && (count == 0 || i < count) {
                let n = i + 1
                let cntStr = count == 0 ? "∞" : String(count)
                self.cwCqRepeatStatus = "\(n)/\(cntStr)"
                await self.cwSendText(text)
                guard self.cwCqRepeating else { break }
                for sec in stride(from: intervalSec, through: 1, by: -1) {
                    guard self.cwCqRepeating else { break }
                    self.cwCqRepeatStatus = String(localized: "待機 \(sec)s…")
                    try? await Task.sleep(nanoseconds: 1_000_000_000)
                }
                i += 1
            }
            self.cwCqRepeating = false
            self.cwCqRepeatStatus = ""
        }
    }

    func cwStopCqRepeat() {
        cwCqRepeating = false
        cwCqRepeatTask?.cancel(); cwCqRepeatTask = nil
        cwCqRepeatStatus = ""
        Task { await self.cwStopMorse() }
    }

    // MARK: - Admin (api.py upload)

    var adminSetupLog: String = ""
    var adminSetupRunning: Bool = false

    private func adminEnsureConfigured() async {
        let h = hostName.trimmingCharacters(in: .whitespaces)
        guard !h.isEmpty else { return }
        await api.configure(host: h, apiPort: apiPort, apiKey: apiKey)
        resolvedStreamHost = await api.streamHost
    }

    func adminUploadApi(_ data: Data) async -> String? {
        if isDemoMode { return nil }
        await adminEnsureConfigured()
        do { try await api.sendApiUpdate(data); return nil }
        catch { return error.localizedDescription }
    }

    func adminPollSetupLog() async {
        if isDemoMode {
            adminSetupRunning = true
            adminSetupLog = "[DEMO] sample setup log\n  step 1: ok\n  step 2: ok\n"
            return
        }
        await adminEnsureConfigured()
        if let (running, log) = try? await api.getSetupLog() {
            adminSetupRunning = running
            adminSetupLog = log
        }
    }

    /// Android の updatePiSoftware() と同じ 2 ステップ更新 (v3.12 で揃えた):
    /// 1. api.py 送信 → Pi (FastAPI) 再起動待ち
    /// 2. create_api.sh 送信 → setup_log に "=== DONE ===" が出るまで監視 (最大 8 分)
    ///
    /// api.py は再送しない。create_api.sh は末尾で api.py.bak2 (①で送った最新版) を
    /// 復元するので再送は不要で、再送すると FastAPI 側の _restart() が同じ cgroup の
    /// reboot サブプロセスを殺し、続く Pi 再起動が無言で失敗する (Android 側コメント参照)。
    /// 完了マーカーは create_api.sh が echo する ASCII の "=== DONE ===" に合わせる。
    /// 以前の "=== 完了 ===" はスクリプトが出力しないため、常にタイムアウトまで待っていた。
    func adminUpdatePi(apiData: Data, scriptData: Data) async -> String? {
        if isDemoMode { adminSetupLog = "[DEMO]\n=== DONE ===\n"; return nil }
        await adminEnsureConfigured()
        adminSetupLog = "① api.py 送信中…"
        do { try await api.sendApiUpdate(apiData) }
        catch { return "api.py upload failed: \(error.localizedDescription)" }
        // Pi Zero の FastAPI 再起動は 20〜30 秒かかることがある: 5 秒 × 8 回 = 40 秒リトライ
        adminSetupLog = "② Pi 再起動中… (最大40秒待機)"
        var scriptSent = false
        for attempt in 1...8 {
            try? await Task.sleep(nanoseconds: 5_000_000_000)
            adminSetupLog = "② Pi 再起動中… (\(attempt * 5)s)"
            do { try await api.sendSetupScript(scriptData); scriptSent = true; break }
            catch { }
        }
        guard scriptSent else { return "create_api.sh upload failed — Pi not responding after 40s" }
        // Pi Zero の SD カードへの heredoc 書き込みは数分かかるため、Android と同じく 8 分待つ
        adminSetupLog = "③ セットアップスクリプト実行中… (ログ待機)"
        let deadline = Date().addingTimeInterval(480)
        var setupFinished = false
        while Date() < deadline {
            try? await Task.sleep(nanoseconds: 3_000_000_000)
            if let (running, log) = try? await api.getSetupLog() {
                adminSetupRunning = running
                adminSetupLog = log.isEmpty ? "③ セットアップ実行中… (ログなし)" : log
                if log.contains("=== DONE ===") { setupFinished = true; break }
            }
        }
        guard setupFinished else { return "setup timeout. Restart Pi." }
        return nil
    }

    // MARK: - Admin (mfsk build log — v3.01)

    var adminMfskLog: String = ""
    var adminMfskRunning: Bool = false

    func adminPollMfskLog() async {
        if isDemoMode { adminMfskLog = "[DEMO] mfsk-decode build ok\n=== 完了 ===\n"; return }
        await adminEnsureConfigured()
        if let (running, log) = try? await api.getMfskBuildLog() {
            adminMfskRunning = running
            adminMfskLog = log
        }
    }

    /// Pi リブート待機（オフライン検出 → 再起動完了まで最大150秒）
    func rebootPiAndWait() async -> String {
        if isDemoMode { return "Pi reboot complete (demo)" }
        await adminEnsureConfigured()
        var rebooted = false
        let readyDeadline = Date().addingTimeInterval(30)
        while Date() < readyDeadline {
            if await api.rebootPi() { rebooted = true; break }
            try? await Task.sleep(nanoseconds: 3_000_000_000)
        }
        guard rebooted else { return "Reboot failed — Pi unreachable" }
        let offlineDeadline = Date().addingTimeInterval(45)
        while Date() < offlineDeadline {
            try? await Task.sleep(nanoseconds: 3_000_000_000)
            if (try? await api.getStatus()) == nil { break }
        }
        let onlineDeadline = Date().addingTimeInterval(150)
        while Date() < onlineDeadline {
            if (try? await api.getStatus()) != nil { return "Pi reboot complete" }
            try? await Task.sleep(nanoseconds: 5_000_000_000)
        }
        return "Pi reboot timeout — check connection"
    }

    /// Update Pi 後に mfsk-decode をバックグラウンドビルドさせる
    func triggerMfskBuildAfterUpdate() async -> String {
        if isDemoMode { adminMfskLog = "[DEMO] mfsk build started"; return "mfsk build started (demo)" }
        await adminEnsureConfigured()
        for _ in 1...20 {
            try? await Task.sleep(nanoseconds: 3_000_000_000)
            if (try? await api.triggerMfskBuild(force: true)) != nil {
                let deadline = Date().addingTimeInterval(15)
                while Date() < deadline {
                    try? await Task.sleep(nanoseconds: 2_000_000_000)
                    if let (running, log) = try? await api.getMfskBuildLog() {
                        adminMfskLog = log
                        if running || log.contains("ビルド開始") { return "mfsk build started" }
                    }
                }
                return "mfsk build started (log pending)"
            }
        }
        return "mfsk build trigger failed (Pi unreachable?)"
    }

    /// Pi の時刻を Android / NTP と同期する
    func syncPiTime() async -> String {
        if isDemoMode { return "Sync OK[demo]" }
        await adminEnsureConfigured()
        let nowMs = Int64(Date().timeIntervalSince1970 * 1000)
        guard let (ok, source, drift) = try? await api.syncTime(ms: nowMs), ok else {
            return "Sync failed"
        }
        let s = drift > 0 ? "+\(drift)" : "\(drift)"
        return "Sync OK[\(source)] (drift \(s)ms)"
    }

    // MARK: - Admin (Hamlib install)

    var adminHamlibLog: String = ""
    var adminHamlibRunning: Bool = false

    func adminPollHamlibLog() async {
        if isDemoMode {
            adminHamlibRunning = false
            adminHamlibLog = "[DEMO] Hamlib 4.7.2 installed\n=== 完了 ===\n"
            return
        }
        if await api.host.isEmpty { await adminEnsureConfigured() }
        if let (running, log) = try? await api.getHamlibLog() {
            adminHamlibRunning = running
            adminHamlibLog = log
        }
    }

    /// Send install_hamlib.sh and poll hamlib_log until "=== 完了 ===" (max 60 min).
    func adminInstallHamlib(_ scriptData: Data) async -> String? {
        if isDemoMode { adminHamlibLog = "[DEMO]\n=== 完了 ===\n"; return nil }
        await adminEnsureConfigured()
        adminHamlibLog = "① install_hamlib.sh 送信中…"
        do { try await api.sendHamlibInstall(scriptData) }
        catch { return "install_hamlib.sh upload failed: \(error.localizedDescription)" }
        adminHamlibLog = "② Hamlib ビルド中… (Pi Zero: 30〜60分)"
        adminHamlibRunning = true
        let deadline = Date().addingTimeInterval(3_600)
        while Date() < deadline {
            try? await Task.sleep(nanoseconds: 10_000_000_000)
            if let (running, log) = try? await api.getHamlibLog() {
                adminHamlibRunning = running
                adminHamlibLog = log.isEmpty ? "② ビルド中… (ログなし)" : log
                if log.contains("=== 完了 ===") { return nil }
                if log.contains("エラー:") || log.contains("Error:") {
                    let errLine = log.split(separator: "\n").last(where: {
                        $0.contains("エラー:") || $0.contains("Error:")
                    }).map(String.init) ?? "Build error"
                    return errLine
                }
            }
        }
        return "Build timeout (60 min exceeded)"
    }

    /// Stop local audio RX (used when entering FT8 so the WebView gets exclusive access).
    func audioRxStopIfRunning() async {
        if spkEnabled {
            spkEnabled = false
            await audioRx.stop()
        }
    }

    enum PiAudioStart {
        case started(rate: Int)      // we started the stream; caller must stop it on exit
        case alreadyRunning          // SPK stream is already delivering samples
        case unavailable(String)     // no Pi audio possible (reason for the status line)
    }

    /// Start Pi audio for RTTY without changing spkEnabled.
    /// Unlike SPK, a sample-rate setting of "Off" does not disable this: the RTTY
    /// demodulator needs RX audio, so it falls back to 8 kHz.
    func ensurePiAudioStarted() async -> PiAudioStart {
        guard !useCivMode || !civ.isConnected else { return .unavailable("CI-V") }
        if audioRx.isRunning { return .alreadyRunning }
        guard !hostName.isEmpty else { return .unavailable("not connected") }
        let selected = AppConstants.samplingRates.indices.contains(selectedSamplingIndex)
            ? AppConstants.samplingRates[selectedSamplingIndex] : 0
        let rate = selected > 0 ? selected : 8000
        await audioRx.start(host: streamHost, port: audioPort, sampleRate: rate, apiKey: apiKey)
        return audioRx.isRunning ? .started(rate: rate) : .unavailable("stream failed")
    }

    /// Stop Pi audio only if SPK is not on (i.e., RTTY started it).
    func stopPiAudioIfNotSpk() async {
        guard !spkEnabled else { return }
        await audioRx.stop()
    }

    /// Stops the Pi RX audio stream for the duration of a transmission, ignoring SPK, and
    /// reports whether it was running so the caller knows to bring it back.
    ///
    /// The Pi's `/radio/audio_tx` kills its capture processes before it starts aplay, so the
    /// RX stream dies regardless. Leaving the app's receiver connected only means it notices
    /// the death and starts reconnecting while the transmission is still going. On the
    /// single-core Pi that reconnect storm, each attempt spawning a fresh ffmpeg, competed
    /// with aplay and rigctld until `/radio/status` timed out and the control link was
    /// declared lost. Repeated transmit/receive cycles in RTTY dropped the connection this
    /// way. Standing down for the transmission avoids the fight.
    func suspendPiAudioForTx() async -> Bool {
        guard audioRx.isRunning else { return false }
        await audioRx.stop()
        return true
    }

    /// Demo mode flag — when true, server calls are skipped and signal value is simulated.
    var demoMode: Bool = false
    private var demoTickTask: Task<Void, Never>?

    /// Populate UI state with mock data so the next screens render without a real server.
    func loadMockData() {
        demoMode = true
        rigList = [
            RigInfo(id: 1035, name: "Yaesu FT-991"),
            RigInfo(id: 122, name: "Icom IC-7300"),
            RigInfo(id: 2, name: "Dummy (no rig)")
        ]
        catList = ["/dev/ttyUSB0", "/dev/ttyACM0"]
        soundDeviceList = [
            SoundDevice(id: "hw:0,0", label: "USB Audio CODEC"),
            SoundDevice(id: "default", label: "Default Output")
        ]
        supportedModes = ["USB", "LSB", "CW", "AM", "FM", "PKTUSB", "PKTLSB"]
        selectedRigIndex = 0
        selectedCatIndex = 0
        sharedFreq = 14_250_000
        sharedMode = "USB"
        sharedSignal = 6.5
        sharedTx = false
        sharedPower = 0.5
        sharedWidth = 2400
        sharedSQL = 0.2
        sharedBkIn = false
        isConnectedToRig = true
        aprsCallsign = "JI1ORE"
        aprsSSID = 9
        startDemoTicker()
    }

    private func startDemoTicker() {
        demoTickTask?.cancel()
        demoTickTask = Task { [weak self] in
            while let self, !Task.isCancelled, self.demoMode {
                try? await Task.sleep(nanoseconds: 800_000_000)
                // Wave-shaped S-meter wandering 2..10
                let phase = Date().timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 8.0)
                let s = 6.0 + 4.0 * sin(phase / 8.0 * 2.0 * .pi)
                self.sharedSignal = s
            }
        }
    }
}

private extension Int {
    func nonZeroOr(_ fallback: Int) -> Int { self == 0 ? fallback : self }
}

private extension Float {
    func nonZeroOr(_ fallback: Float) -> Float { self == 0 ? fallback : self }
}
