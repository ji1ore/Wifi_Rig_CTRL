package com.ji1ore.wifi_rig_ctrl

import android.Manifest
import android.annotation.SuppressLint
import android.app.Dialog
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.activityViewModels
import com.ji1ore.wifi_rig_ctrl.data.JccTable
import com.ji1ore.wifi_rig_ctrl.data.QsoEntry
import com.ji1ore.wifi_rig_ctrl.data.QsoStore
import com.ji1ore.wifi_rig_ctrl.viewmodel.MainViewModel
import java.util.Locale

class LogQsoDialogFragment : DialogFragment() {

    private val vm: MainViewModel by activityViewModels()

    companion object {
        private const val ARG_CALLSIGN = "callsign"
        private const val ARG_POTA     = "pota"
        private const val ARG_SOTA     = "sota"
        private const val ARG_RST_S    = "rstS"
        private const val ARG_RST_R    = "rstR"

        fun newInstance(
            callsign: String = "",
            pota: String = "",
            sota: String = "",
            rstSent: String = "",
            rstRcvd: String = ""
        ) = LogQsoDialogFragment().apply {
            arguments = Bundle().apply {
                putString(ARG_CALLSIGN, callsign)
                putString(ARG_POTA, pota)
                putString(ARG_SOTA, sota)
                putString(ARG_RST_S, rstSent)
                putString(ARG_RST_R, rstRcvd)
            }
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val ctx = requireContext()
        val args = arguments ?: Bundle()
        val initCall = args.getString(ARG_CALLSIGN, "").ifEmpty { vm.pendingLogCallsign }
        // POTA/SOTA: only use explicit args (from CW TX screen), never from pendingLog (memset/SP2)
        val initPota = args.getString(ARG_POTA, "")
        val initSota = args.getString(ARG_SOTA, "")
        val initRstS = args.getString(ARG_RST_S, "")
        val initRstR = args.getString(ARG_RST_R, "")

        val freqHz = vm.sharedFreq.value ?: 0L
        val mode   = vm.sharedMode.value ?: ""
        val myCall = vm.prefs.ft8MyCall
        val myGrid = vm.prefs.ft8MyGrid

        val freqMhz = if (freqHz > 0) "%.4f MHz".format(freqHz / 1_000_000.0) else "---"
        val band    = QsoStore.freqToBand(freqHz)
        val isCw     = mode.startsWith("CW", ignoreCase = true)
        val isFtRtty = mode.startsWith("FT") || mode.equals("RTTY", ignoreCase = true)
        val defaultRst = when { isCw -> "599"; isFtRtty -> "-00"; else -> "59" }

        // ─── helpers ──────────────────────────────────────────────────────────

        fun dp(n: Int) = (n * ctx.resources.displayMetrics.density + 0.5f).toInt()

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(16))
        }

        fun label(text: String) = TextView(ctx).apply {
            this.text = text; textSize = 13f
            setTextColor(0xFF777777.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.topMargin = dp(10) }
        }

        fun editText(hint: String, init: String = "", numOnly: Boolean = false): EditText =
            EditText(ctx).apply {
                this.hint = hint; setText(init)
                setHintTextColor(0xFF505050.toInt()); setTextColor(0xFFCCCCCC.toInt())
                backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF333333.toInt())
                textSize = 16f; setSingleLine(true)
                setPadding(dp(8), dp(8), dp(8), dp(8))
                inputType = if (numOnly) InputType.TYPE_CLASS_NUMBER
                else InputType.TYPE_CLASS_TEXT or
                        InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or
                        InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                layoutParams = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

        fun clearBtn(target: EditText) = Button(ctx).apply {
            text = "×"; textSize = 12f; setPadding(0, 0, 0, 0)
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF444444.toInt())
            setTextColor(0xFFAAAAAA.toInt())
            layoutParams = LinearLayout.LayoutParams(dp(28), dp(36)).also { it.marginStart = dp(3) }
            setOnClickListener { target.text.clear(); target.requestFocus() }
        }

        fun hrow(vararg views: View) = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.bottomMargin = dp(2) }
            views.forEach { addView(it) }
        }

        // RST selector rows — returns views to add to root
        fun rstSelectorViews(target: EditText): List<View> {
            val views = mutableListOf<View>()
            val selTint   = 0xFF1B5E20.toInt()
            val unselTint = 0xFF263238.toInt()

            fun presetRow(values: List<String>, height: Int = dp(34)) = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    .also { it.topMargin = dp(3); it.bottomMargin = dp(2) }
                val btns = Array<Button?>(values.size) { null }
                values.forEachIndexed { i, v ->
                    val btn = Button(ctx).apply {
                        text = v; textSize = 12f; setPadding(0, 0, 0, 0)
                        backgroundTintList = android.content.res.ColorStateList.valueOf(unselTint)
                        setTextColor(0xFF80CBC4.toInt())
                        layoutParams = LinearLayout.LayoutParams(0, height, 1f)
                            .also { if (i > 0) it.marginStart = dp(2) }
                        setOnClickListener {
                            btns.forEach { b -> b?.backgroundTintList = android.content.res.ColorStateList.valueOf(unselTint) }
                            backgroundTintList = android.content.res.ColorStateList.valueOf(selTint)
                            target.setText(v)
                        }
                    }
                    btns[i] = btn; addView(btn)
                }
            }

            if (isCw) {
                views += presetRow((1..9).map { "5${it}9" })
                return views
            }

            if (isFtRtty) {
                views += presetRow(listOf("-20", "-15", "-10", "-05", "00", "+05", "+10"), dp(32))
                return views
            }

            // SSB: 51〜59
            views += presetRow((1..9).map { "5$it" })
            return views
        }

        // ─── Freq / mode / myCall ────────────────────────────────────────────

        root.addView(TextView(ctx).apply {
            text = "$freqMhz  $band  $mode   MY: ${myCall.ifEmpty { "(not set)" }}"
            textSize = 14f; setTextColor(0xFF00E5FF.toInt()); setPadding(0, 0, 0, dp(4))
        })

        // ─── Date / Time (UTC) ───────────────────────────────────────────────

        fun utcDtToLocal(dt: String): String {
            if (dt.length < 8) return ""
            return try {
                val sdf = java.text.SimpleDateFormat("yyyyMMddHHmmss", Locale.US).apply {
                    timeZone = java.util.TimeZone.getTimeZone("UTC")
                }
                val date = sdf.parse(dt.padEnd(14, '0')) ?: return ""
                val local = java.text.SimpleDateFormat("MM/dd HH:mm", Locale.getDefault()).apply {
                    timeZone = java.util.TimeZone.getDefault()
                }
                "Local: ${local.format(date)}"
            } catch (_: Exception) { "" }
        }

        val nowUtc = QsoEntry.utcNow()
        root.addView(label("日時 UTC (yyyyMMdd  HHmmss)"))
        val etDate = EditText(ctx).apply {
            setText(nowUtc.take(8)); hint = "yyyyMMdd"
            setHintTextColor(0xFF505050.toInt()); setTextColor(0xFFFFFFFF.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF333333.toInt())
            textSize = 16f; setSingleLine(true); setPadding(dp(8), dp(8), dp(8), dp(8))
            inputType = InputType.TYPE_CLASS_NUMBER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val etTime = EditText(ctx).apply {
            setText(nowUtc.drop(8)); hint = "HHmmss"
            setHintTextColor(0xFF505050.toInt()); setTextColor(0xFFFFFFFF.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF333333.toInt())
            textSize = 16f; setSingleLine(true); setPadding(dp(8), dp(8), dp(8), dp(8))
            inputType = InputType.TYPE_CLASS_NUMBER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        root.addView(hrow(etDate, clearBtn(etDate), etTime, clearBtn(etTime)))

        val tvLocalTime = TextView(ctx).apply {
            text = utcDtToLocal(nowUtc)
            textSize = 12f; setTextColor(0xFF888888.toInt())
            setPadding(dp(4), 0, 0, dp(2))
        }
        root.addView(tvLocalTime)
        val dtWatcher = object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                tvLocalTime.text = utcDtToLocal(etDate.text.toString() + etTime.text.toString())
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        }
        etDate.addTextChangedListener(dtWatcher)
        etTime.addTextChangedListener(dtWatcher)

        // ─── DX callsign ─────────────────────────────────────────────────────

        root.addView(label("DX Callsign"))
        val etCall = EditText(ctx).apply {
            hint = "JA2ABC/1"; setText(initCall)
            setHintTextColor(0xFF555555.toInt()); setTextColor(0xFFFFEB3B.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF1A237E.toInt())
            textSize = 18f; setSingleLine(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            inputType = InputType.TYPE_CLASS_TEXT or
                    InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS or
                    InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            imeOptions = EditorInfo.IME_FLAG_FORCE_ASCII or EditorInfo.IME_ACTION_NEXT
            isFocusableInTouchMode = true
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            filters = arrayOf(android.text.InputFilter { source, _, _, _, _, _ ->
                source.toString().uppercase()
                    .filter { it.isLetter() && it.code < 128 || it.isDigit() && it.code < 128 || it == '/' }
            })
        }
        root.addView(hrow(etCall, clearBtn(etCall)))

        // ─── RST Sent ────────────────────────────────────────────────────────

        root.addView(label("RST 送信"))
        val etRstS = EditText(ctx).apply {
            hint = defaultRst; setText(initRstS.ifEmpty { defaultRst })
            setHintTextColor(0xFF505050.toInt()); setTextColor(0xFFFFFFFF.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF333333.toInt())
            textSize = 20f; setSingleLine(true); setPadding(dp(10), dp(8), dp(10), dp(8))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        root.addView(hrow(etRstS, clearBtn(etRstS)))
        rstSelectorViews(etRstS).forEach { root.addView(it) }

        // ─── RST Rcvd ────────────────────────────────────────────────────────

        root.addView(label("RST 受信"))
        val etRstR = EditText(ctx).apply {
            hint = defaultRst; setText(initRstR.ifEmpty { defaultRst })
            setHintTextColor(0xFF505050.toInt()); setTextColor(0xFFFFFFFF.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF333333.toInt())
            textSize = 20f; setSingleLine(true); setPadding(dp(10), dp(8), dp(10), dp(8))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        root.addView(hrow(etRstR, clearBtn(etRstR)))
        rstSelectorViews(etRstR).forEach { root.addView(it) }

        fun potaSotaField(hint: String, init: String, color: Int) = EditText(ctx).apply {
            this.hint = hint; setText(init.uppercase())
            setHintTextColor(0xFF505050.toInt()); setTextColor(color)
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF333333.toInt())
            textSize = 16f; setSingleLine(true); setPadding(dp(8), dp(8), dp(8), dp(8))
            inputType = InputType.TYPE_CLASS_TEXT or
                    InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            filters = arrayOf(android.text.InputFilter { source, _, _, _, _, _ ->
                source.toString().uppercase()
                    .filter { it.isLetter() && it.code < 128 || it.isDigit() || it == '-' || it == '/' }
            })
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }

        // ─── Your POTA / SOTA (DX station's) ────────────────────────────────

        root.addView(label("Your POTA (相手のパーク)"))
        val etYourPota = potaSotaField("例: JP-1234", initPota, 0xFF80CBC4.toInt())
        root.addView(etYourPota)

        root.addView(label("Your SOTA (相手の山)"))
        val etYourSota = potaSotaField("例: JA/KN-001", initSota, 0xFF80CBC4.toInt())
        root.addView(etYourSota)

        // ─── My POTA / SOTA (own) ────────────────────────────────────────────

        val persist = ctx.getSharedPreferences("log_qso_persist", android.content.Context.MODE_PRIVATE)

        root.addView(label("My POTA (自分のパーク)"))
        val etMyPota = potaSotaField("例: JP-1234", persist.getString("myPota", "") ?: "", 0xFFCCCCCC.toInt())
        root.addView(etMyPota)

        root.addView(label("My SOTA (自分の山)"))
        val etMySota = potaSotaField("例: JA/KN-001", persist.getString("mySota", "") ?: "", 0xFFCCCCCC.toInt())
        root.addView(etMySota)

        // ─── JCC / JGC ───────────────────────────────────────────────────────

        root.addView(label("JCC (4桁) / JGC (5桁)"))
        val etJcc = EditText(ctx).apply {
            hint = "例: 2716"; setText(persist.getString("jcc", "") ?: "")
            setHintTextColor(0xFF505050.toInt()); setTextColor(0xFFCCCCCC.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF333333.toInt())
            textSize = 16f; setSingleLine(true); setPadding(dp(8), dp(8), dp(8), dp(8))
            inputType = InputType.TYPE_CLASS_NUMBER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 4f)
        }
        val tvSlash = TextView(ctx).apply {
            text = "  /  "; textSize = 16f; setTextColor(0xFF777777.toInt())
        }
        val etJgc = EditText(ctx).apply {
            hint = "例: 27169"; setText("")
            setHintTextColor(0xFF505050.toInt()); setTextColor(0xFFCCCCCC.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF333333.toInt())
            textSize = 16f; setSingleLine(true); setPadding(dp(8), dp(8), dp(8), dp(8))
            inputType = InputType.TYPE_CLASS_NUMBER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 5f)
        }
        root.addView(hrow(etJcc, tvSlash, etJgc))

        // GPS button + info
        var lastLat = 0.0; var lastLon = 0.0
        val tvGpsInfo = TextView(ctx).apply {
            text = ""; textSize = 12f; setTextColor(0xFF76FF03.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.topMargin = dp(2) }
        }
        root.addView(Button(ctx).apply {
            text = "GPS 位置を取得"; textSize = 13f
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF1565C0.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.topMargin = dp(6) }
            setOnClickListener {
                fetchGpsAndReverse(tvGpsInfo, etJcc, etJgc) { lat, lon -> lastLat = lat; lastLon = lon }
            }
        })
        root.addView(tvGpsInfo)

        // ─── Comment ─────────────────────────────────────────────────────────

        root.addView(label("コメント"))
        val etComment = editText("", persist.getString("comment", "") ?: "")
        root.addView(hrow(etComment, clearBtn(etComment)))

        // ─── Clear persistent fields button ──────────────────────────────────

        root.addView(Button(ctx).apply {
            text = "My POTA / SOTA / JCC / コメント クリア"
            textSize = 12f
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF4A0000.toInt())
            setTextColor(0xFFFF8A80.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.topMargin = dp(12) }
            setOnClickListener {
                etMyPota.text.clear(); etMySota.text.clear()
                etJcc.text.clear(); etJgc.text.clear(); etComment.text.clear()
                persist.edit().remove("myPota").remove("mySota").remove("jcc").remove("comment").apply()
            }
        })

        // Spacer: without this, ScrollView maxScrollY = content_height - sv.height ≈ 0
        // when ADJUST_RESIZE does not shrink sv (Android 11+). The spacer increases content
        // height so the comment field can scroll above the keyboard.
        root.addView(View(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                ctx.resources.displayMetrics.heightPixels / 3
            )
        })

        // ─── dialog ───────────────────────────────────────────────────────────

        val sv = ScrollView(ctx).apply {
            addView(root)
            isVerticalScrollBarEnabled = false
        }

        val dlg = android.app.AlertDialog.Builder(ctx, android.R.style.Theme_Material_Dialog_NoActionBar)
            .setTitle("Log QSO")
            .setView(sv)
            .setPositiveButton("Save", null)   // listener overridden in setOnShowListener
            .setNegativeButton("Cancel", null)
            .create()

        dlg.window?.apply {
            setBackgroundDrawableResource(android.R.color.background_dark)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }

        // Save logic extracted so it can be called from the overridden button listener
        fun doSave() {
            val call = etCall.text.toString().trim().uppercase()
            if (call.isEmpty()) {
                Toast.makeText(ctx, "Callsign required", Toast.LENGTH_SHORT).show()
                return
            }
            val dt = (etDate.text.toString().trim() + etTime.text.toString().trim())
                .padEnd(14, '0').take(14)
            val entry = QsoEntry(
                dt       = dt,
                call     = call,
                freqHz   = freqHz,
                mode     = mode.ifEmpty { "SSB" },
                rstSent  = etRstS.text.toString().trim().ifEmpty { defaultRst },
                rstRcvd  = etRstR.text.toString().trim().ifEmpty { defaultRst },
                dxGrid   = "",
                myCall   = myCall,
                myGrid   = myGrid,
                yourPota = etYourPota.text.toString().trim().uppercase(),
                yourSota = etYourSota.text.toString().trim().uppercase(),
                myPota   = etMyPota.text.toString().trim().uppercase(),
                mySota   = etMySota.text.toString().trim().uppercase(),
                jcc      = etJcc.text.toString().trim(),
                jgc      = etJgc.text.toString().trim(),
                comment  = etComment.text.toString().trim(),
                lat      = lastLat,
                lon      = lastLon
            )
            QsoStore.append(requireContext(), entry)
            persist.edit()
                .putString("myPota",  entry.myPota)
                .putString("mySota",  entry.mySota)
                .putString("jcc",     entry.jcc)
                .putString("comment", entry.comment)
                .apply()
            parentFragmentManager.setFragmentResult("log_qso_done", Bundle())
            Toast.makeText(ctx, "Logged: $call", Toast.LENGTH_SHORT).show()
            // Clear transient fields for next QSO; keep My POTA/SOTA/JCC/JGC/Comment
            etCall.setText(""); etCall.requestFocus()
            etYourPota.setText(""); etYourSota.setText("")
            etRstS.setText(defaultRst); etRstR.setText(defaultRst)
            val next = QsoEntry.utcNow()
            etDate.setText(next.take(8)); etTime.setText(next.drop(8))
        }

        dlg.setOnShowListener {
            dlg.window?.setLayout(
                (ctx.resources.displayMetrics.widthPixels * 0.95).toInt(),
                WindowManager.LayoutParams.MATCH_PARENT
            )
            // Override positive button so dialog stays open after save
            dlg.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener { doSave() }

            // Scroll focused field into view using actual visible height (works even if
            // ADJUST_RESIZE doesn't shrink the dialog window on Android 11+)
            var lastFocused: View? = null
            sv.viewTreeObserver.addOnGlobalFocusChangeListener { _, newFocus ->
                if (newFocus != null && root.findFocus() != null) lastFocused = newFocus
            }
            sv.viewTreeObserver.addOnGlobalLayoutListener {
                val focused = lastFocused ?: return@addOnGlobalLayoutListener
                if (root.findFocus() == null) return@addOnGlobalLayoutListener
                // Measure how much of sv is visible above the keyboard
                val visFrame = android.graphics.Rect()
                sv.getWindowVisibleDisplayFrame(visFrame)
                val loc = IntArray(2)
                sv.getLocationOnScreen(loc)
                val effectiveHeight = (visFrame.bottom - loc[1]).coerceIn(dp(80), sv.height)
                // Get focused view's content position in sv
                val rect = android.graphics.Rect()
                focused.getDrawingRect(rect)
                sv.offsetDescendantRectToMyCoords(focused, rect)
                val target = rect.bottom + dp(20) - effectiveHeight
                if (target > sv.scrollY) sv.smoothScrollTo(0, maxOf(0, target))
            }

            etCall.requestFocus()
            if (initCall.isNotEmpty()) etCall.setSelection(0, etCall.text.length)
        }
        return dlg
    }

    @SuppressLint("MissingPermission")
    private fun fetchGpsAndReverse(
        tvInfo: TextView,
        etJcc: EditText,
        etJgc: EditText,
        onLocation: (Double, Double) -> Unit
    ) {
        val ctx = requireContext()
        val hasFine   = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val hasCoarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!hasFine && !hasCoarse) { tvInfo.text = "位置情報の許可が必要です"; return }

        tvInfo.text = "位置情報取得中…"

        val fusedClient = com.google.android.gms.location.LocationServices
            .getFusedLocationProviderClient(ctx)
        val priority = if (hasFine)
            com.google.android.gms.location.Priority.PRIORITY_HIGH_ACCURACY
        else
            com.google.android.gms.location.Priority.PRIORITY_BALANCED_POWER_ACCURACY
        val cts = com.google.android.gms.tasks.CancellationTokenSource()

        fusedClient.getCurrentLocation(priority, cts.token)
            .addOnSuccessListener { loc ->
                if (loc == null) {
                    fusedClient.lastLocation.addOnSuccessListener { last ->
                        if (last == null) { tvInfo.text = "位置情報が取得できませんでした"; return@addOnSuccessListener }
                        onLocation(last.latitude, last.longitude)
                        tvInfo.text = "%.5f, %.5f (cached)".format(last.latitude, last.longitude)
                        reverseGeocode(ctx, last, tvInfo, etJcc, etJgc)
                    }
                    return@addOnSuccessListener
                }
                onLocation(loc.latitude, loc.longitude)
                tvInfo.text = "%.5f, %.5f".format(loc.latitude, loc.longitude)
                reverseGeocode(ctx, loc, tvInfo, etJcc, etJgc)
            }
            .addOnFailureListener {
                tvInfo.text = "位置情報取得エラー: ${it.localizedMessage}"
            }
    }

    private fun reverseGeocode(ctx: android.content.Context, loc: Location, tvInfo: TextView, etJcc: EditText, etJgc: EditText) {
        if (!Geocoder.isPresent()) return
        Thread {
            try {
                @Suppress("DEPRECATION")
                val addrs = Geocoder(ctx, Locale.JAPANESE).getFromLocation(loc.latitude, loc.longitude, 1)
                if (addrs.isNullOrEmpty()) return@Thread
                val addr        = addrs[0]
                val admin       = addr.adminArea    ?: ""
                val subAdmin    = addr.subAdminArea ?: ""
                val locality    = addr.locality     ?: ""
                val subLocality = addr.subLocality  ?: ""
                val addressLine = addr.getAddressLine(0) ?: ""
                val fullLine    = addressLine.ifEmpty { "$admin$subAdmin$locality" }

                // Normalize kanji alternatives (e.g. Geocoder returns "埼玉市" for さいたま市)
                fun normCity(s: String) = when (s) {
                    "埼玉市" -> "さいたま市"
                    else -> s
                }

                // Determine city (市) from available fields
                val city = normCity(when {
                    subAdmin.endsWith("市") -> subAdmin
                    locality.endsWith("市") -> locality
                    subAdmin.contains("市") && subAdmin.endsWith("区") ->
                        subAdmin.substring(0, subAdmin.indexOf('市') + 1)
                    else -> locality
                })

                // Determine ward (区) — try subLocality, locality, subAdmin, then parse addressLine
                val ward = when {
                    subLocality.endsWith("区") -> subLocality
                    locality.endsWith("区")    -> locality
                    subAdmin.endsWith("区")    -> subAdmin.substringAfterLast("市")
                    else -> {
                        // Extract 〇〇区 from address line after 市
                        val after = addressLine.substringAfter("市", "").trimStart()
                        Regex("^([^\\s\\d丁番号]+区)").find(after)?.groupValues?.getOrNull(1) ?: ""
                    }
                }

                // JCC: city-level code (4-digit for 政令指定都市, or direct match for regular city / Tokyo ward)
                val jcc = run {
                    var found = JccTable.lookupJcc(admin, locality)
                    if (found.isEmpty()) found = JccTable.lookupJcc(admin, city)
                    if (found.isEmpty() && ward.isNotEmpty())
                        found = JccTable.lookupJcc(admin, "$city$ward")
                    // If 6-digit ward code was found but city code exists, prefer city code
                    if (found.length == 6) {
                        val cityCode = JccTable.lookupJcc(admin, city)
                        if (cityCode.isNotEmpty()) found = cityCode
                    }
                    found
                }

                // JGC: ward code (6-digit) for 政令指定都市, or district code for 郡部
                val jgc = run {
                    var found = ""
                    if (ward.isNotEmpty() && city.isNotEmpty())
                        found = JccTable.lookupJcc(admin, "$city$ward")
                    if (found.isEmpty() && subAdmin.isNotEmpty())
                        found = JccTable.lookupJgc(admin, subAdmin, locality)
                    found
                }
                activity?.runOnUiThread {
                    etJcc.setText(jcc)
                    etJgc.setText(jgc)
                    tvInfo.text = when {
                        jcc.isNotEmpty() && jgc.isNotEmpty() -> "$fullLine  → JCC:$jcc JGC:$jgc"
                        jcc.isNotEmpty() -> "$fullLine  → JCC: $jcc"
                        jgc.isNotEmpty() -> "$fullLine  → JGC: $jgc"
                        else -> fullLine
                    }
                }
            } catch (_: Exception) {}
        }.start()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? = null
}
