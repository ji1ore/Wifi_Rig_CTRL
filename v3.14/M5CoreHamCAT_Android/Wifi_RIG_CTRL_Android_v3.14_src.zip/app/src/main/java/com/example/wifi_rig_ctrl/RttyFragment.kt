package com.ji1ore.wifi_rig_ctrl

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.ji1ore.wifi_rig_ctrl.data.SAMPLING_RATES
import com.ji1ore.wifi_rig_ctrl.databinding.FragmentRttyBinding
import com.ji1ore.wifi_rig_ctrl.viewmodel.MainViewModel
import kotlinx.coroutines.*
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.sqrt

class RttyFragment : Fragment() {

    private var _binding: FragmentRttyBinding? = null
    private val binding get() = _binding!!
    private val vm: MainViewModel by activityViewModels()

    private var preMode  = ""
    private var preWidth = 0

    private val myCall: String
        get() = vm.prefs.ft8MyCall.ifEmpty { vm.prefs.aprsCallsign }.uppercase().ifEmpty { "MYCALL" }

    private var isRttyR = false   // false=RTTY, true=RTTYR
    private var pttActive = false
    private var txJob: Job? = null
    private var cqRepeatJob: Job? = null


    @Volatile private var modem: RttyModem? = null
    private var recorder: AudioRecord? = null
    private var rxJob: Job? = null
    private val rxSpan = SpannableStringBuilder()
    @Volatile private var usingPiAudio = false
    private var rttyStartedAudio = false

    // Peak detection
    private companion object { const val PEAK_BUF_SIZE = 2048 }
    private var peakBuf = ShortArray(PEAK_BUF_SIZE)
    private var peakPos = 0
    private var detectedMarkHz  = 0.0
    private var detectedSpaceHz = 0.0
    private var lastMarkHz  = 2125.0   // persists across modem restarts
    private var lastSpaceHz = 2295.0
    // Auto-tune hysteresis: the candidate pair, how many consecutive analyses it has held,
    // and when the modem was last retuned. See the auto-tune block in startRx().
    private var candMarkHz   = 0.0
    private var candSpaceHz  = 0.0
    private var candCount    = 0
    private var lastRetuneMs = 0L
    /** When a convincing tone pair was last seen; drives the fall-back to the standard tones. */
    private var lastPairSeenMs = System.currentTimeMillis()
    /**
     * Fix mode. Long-press the Tune button to toggle. While fixed, auto-tune and the fall-back
     * to the standard tones are off, and the decode position moves only when the operator taps
     * the waterfall. Persisted so a fixed setting survives leaving the screen.
     */
    private var tuneFixed: Boolean
        get() = vm.prefs.rttyTuneFixed
        set(v) { vm.prefs.rttyTuneFixed = v }
    private var currentBaud = 45.45
    @Volatile private var rxLevelDb: Int = -100
    private var logChunkCount = 0

    private val recordPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startRx() else updateStatus("RECORD_AUDIO permission denied")
    }

    // --- Lifecycle ---

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentRttyBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Save pre-RTTY mode
        preMode  = vm.sharedMode.value  ?: ""
        preWidth = vm.sharedWidth.value ?: 0

        // Keep screen on
        requireActivity().window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Observe freq / mode from rig
        updateFreqDisplay(vm.sharedFreq.value ?: 0L)
        vm.sharedFreq.observe(viewLifecycleOwner) { updateFreqDisplay(it) }
        binding.tvMode.text = vm.sharedMode.value?.takeIf { it.isNotEmpty() } ?: "---"
        vm.sharedMode.observe(viewLifecycleOwner) { binding.tvMode.text = it.ifEmpty { "---" } }

        setupButtons()
        binding.tvFreq.setOnClickListener { showFreqDirectInput() }
        binding.tvFreq.setOnLongClickListener {
            MemoryDialogFragment.newInstance(fromRtty = true)
                .show(parentFragmentManager, "rtty_memory")
            true
        }
        binding.btnFreqDown.setOnClickListener {
            val f = vm.sharedFreq.value ?: 0L; if (f > 0L) vm.sendFreq(f - 100L)
        }
        binding.btnFreqUp.setOnClickListener {
            val f = vm.sharedFreq.value ?: 0L; if (f > 0L) vm.sendFreq(f + 100L)
        }

        // Waterfall: show initial markers, wire touch → update modem decode frequency
        binding.rttyWaterfall.setMarkers(lastMarkHz, lastSpaceHz)
        binding.rttyWaterfall.onDecodeFreqSelected = { mark, space ->
            // Only in Fix mode. In Tune mode the auto-tuner owns the decode position and
            // would immediately override a tap.
            if (tuneFixed) {
                lastMarkHz = mark; lastSpaceHz = space
                modem?.updateFrequencies(mark, space)
                binding.rttyWaterfall.setMarkers(mark, space)
                updateTuneButton()
                updateStatus("FIX: ${mark.toInt()} / ${space.toInt()} Hz")
            } else {
                updateStatus("Tune長押しでFIXにするとタップで位置を移動できます")
            }
        }
        updateTuneButton()

        // Set rig to RTTY mode on entry
        applyRigMode()

        // Auto-start Pi audio stream for RTTY if SPK is not already on
        rttyStartedAudio = !vm.audio.isStreamActive && vm.spkEnabled.value != true
        if (rttyStartedAudio) vm.startAudio()

        // Start receiver
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED) {
            startRx()
        } else {
            recordPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    override fun onResume() {
        super.onResume()
        requireActivity().window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onPause() {
        super.onPause()
        requireActivity().window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        stopRx()
        cancelTx()
        stopCqRepeat()
        if (pttActive) vm.setPttEnabled(false)
        // Stop Pi audio only if RTTY started it (SPK was off)
        if (rttyStartedAudio && vm.spkEnabled.value != true) {
            vm.audio.stop()
            rttyStartedAudio = false
        }
        // Restore previous mode
        if (preMode.isNotEmpty()) vm.sendMode(preMode, preWidth)
        _binding = null
    }

    // --- UI setup ---

    private fun setupButtons() {
        binding.btnBack.setOnClickListener { findNavController().popBackStack() }

        binding.btnRttyR.setOnClickListener {
            isRttyR = !isRttyR
            binding.btnRttyR.text = if (isRttyR) "RTTYR" else "RTTY"
            applyRigMode()
            // Swap mark/space to invert polarity for RTTYR
            val tmp = lastMarkHz; lastMarkHz = lastSpaceHz; lastSpaceHz = tmp
            modem?.updateFrequencies(lastMarkHz, lastSpaceHz)
            binding.rttyWaterfall.setMarkers(lastMarkHz, lastSpaceHz)
            updateStatus(if (isRttyR) "RTTYR" else "RTTY")
        }

        binding.btnBaud.setOnClickListener {
            // Future: baud rate selection. For now toggle 45.45 / 75
            val newBaud = if (modem?.baudRate == 45.45) 75.0 else 45.45
            restartModem(newBaud)
            binding.btnBaud.text = if (newBaud == 45.45) "45.45bd" else "75bd"
        }

        binding.btnClear.setOnClickListener {
            rxSpan.clear()
            binding.tvRx.text = ""
        }

        // TX amplitude slider (progress 0–90 → amplitude 10%–100%)
        binding.seekTxGain.progress = ((vm.prefs.rttyTxAmplitude * 100).toInt() - 10).coerceIn(0, 90)
        binding.seekTxGain.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    val amp = (p + 10) / 100f
                    vm.prefs.rttyTxAmplitude = amp
                    if (_binding != null) binding.btnTxGain.text = "${p + 10}%"
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        setupCwStylePanel()
        binding.btnTx.setOnClickListener  { startTx(binding.etTx.text.toString().trim()) }
        binding.btnTx2.setOnClickListener { startTx(binding.etTx.text.toString().trim(), txCount = 2) }
        binding.btnLog.setOnClickListener {
            val callsign = binding.etDxCall.text.toString().trim().uppercase()
            val rstSent  = binding.etMyRst.text.toString().trim().ifEmpty { "599" }
            val rstRcvd  = binding.etRst.text.toString().trim().ifEmpty { "599" }
            val pota     = binding.etPota.text.toString().trim().uppercase()
            LogQsoDialogFragment.newInstance(
                callsign = callsign, pota = pota, rstSent = rstSent, rstRcvd = rstRcvd
            ).show(parentFragmentManager, "rtty_log")
        }
        binding.btnStop.setOnClickListener {
            stopCqRepeat()
            cancelTx()
        }
        parentFragmentManager.setFragmentResultListener("memory_freq_for_rtty", viewLifecycleOwner) { _, _ ->
            // Frequency was set by MEMSET; reassert RTTY mode so the band switch doesn't escape
            applyRigMode()
        }
        parentFragmentManager.setFragmentResultListener("memory_nav_from_rtty", viewLifecycleOwner) { _, _ ->
            preMode = ""  // suppress mode restore — MEM recall already set the target mode
            findNavController().popBackStack()
        }
        // Tap: jump to the detected pair (Tune mode only). Long-press: toggle FIX, which
        // freezes the decode position where it is, stops auto-tune and the standard-tone
        // fall-back, and lets a tap on the waterfall move it instead. Long-press again to
        // hand control back to the auto-tuner.
        binding.btnTune.setOnClickListener { applyTune() }
        binding.btnTune.setOnLongClickListener { toggleTuneFixed(); true }

        for ((btn, hz) in listOf(
            binding.btnShiftMinus20 to -20.0,
            binding.btnShiftMinus5  to  -5.0,
            binding.btnShiftPlus5   to   5.0,
            binding.btnShiftPlus20  to  20.0
        )) {
            btn.setOnClickListener { shiftFreq(hz) }
        }

        binding.btnPtt.setOnClickListener {
            if (txJob?.isActive == true) {
                cancelTx()
            } else {
                toggleManualPtt()
            }
        }

        binding.etTx.setOnEditorActionListener { _, _, _ -> startTx(binding.etTx.text.toString().trim()); true }
    }

    // --- CW-style panel setup ---

    private fun setupCwStylePanel() {
        val prefs = vm.prefs

        // Restore persisted values into fields
        binding.etDxCall.setText(prefs.rttyDxCall)
        binding.etRst.setText(prefs.rttyRst)
        binding.etMyRst.setText(prefs.rttyMyRst)
        binding.etPota.setText(prefs.rttyPota)
        binding.etJcc.setText(prefs.rttyJcc)

        // Persist field changes
        binding.etDxCall.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) prefs.rttyDxCall = binding.etDxCall.text.toString().trim().uppercase() }
        binding.etRst.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) prefs.rttyRst = binding.etRst.text.toString().trim() }
        binding.etMyRst.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) prefs.rttyMyRst = binding.etMyRst.text.toString().trim() }
        binding.etPota.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) prefs.rttyPota = binding.etPota.text.toString().trim().uppercase() }
        binding.etJcc.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) prefs.rttyJcc = binding.etJcc.text.toString().trim() }

        // Clear buttons
        binding.btnDxClear.setOnClickListener { binding.etDxCall.setText(""); prefs.rttyDxCall = "" }
        binding.btnRstClear.setOnClickListener { binding.etRst.setText(""); prefs.rttyRst = "599" }
        binding.btnMyRstClear.setOnClickListener { binding.etMyRst.setText(""); prefs.rttyMyRst = "599" }
        binding.btnPotaClear.setOnClickListener { binding.etPota.setText(""); prefs.rttyPota = "" }
        binding.btnJccClear.setOnClickListener { binding.etJcc.setText(""); prefs.rttyJcc = "" }

        // RST presets (their RST)
        for ((btn, value) in listOf(
            binding.btnRst5NN to "599", binding.btnRst519 to "519",
            binding.btnRst559 to "559", binding.btnRst569 to "569",
            binding.btnRst579 to "579", binding.btnRst589 to "589",
            binding.btnRst599 to "599"
        )) { btn.setOnClickListener { binding.etRst.setText(value); prefs.rttyRst = value } }

        // My RST presets
        for ((btn, value) in listOf(
            binding.btnMyRst5NN to "599", binding.btnMyRst519 to "519",
            binding.btnMyRst559 to "559", binding.btnMyRst569 to "569",
            binding.btnMyRst579 to "579", binding.btnMyRst589 to "589",
            binding.btnMyRst599 to "599"
        )) { btn.setOnClickListener { binding.etMyRst.setText(value); prefs.rttyMyRst = value } }

        // CQ/ANS tab
        fun selectTab(cq: Boolean) {
            binding.panelCq.visibility = if (cq) View.VISIBLE else View.GONE
            binding.panelAns.visibility = if (!cq) View.VISIBLE else View.GONE
            binding.btnTabCq.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (cq) 0xFF2A2000.toInt() else 0xFF1A1A1A.toInt())
            binding.btnTabCq.setTextColor(if (cq) 0xFFFFDD44.toInt() else 0xFF888888.toInt())
            binding.btnTabAns.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (!cq) 0xFF002A2A.toInt() else 0xFF1A1A1A.toInt())
            binding.btnTabAns.setTextColor(if (!cq) 0xFF80CBC4.toInt() else 0xFF888888.toInt())
        }
        binding.btnTabCq.setOnClickListener { selectTab(true) }
        binding.btnTabAns.setOnClickListener { selectTab(false) }
        selectTab(true)

        // ---- CQ panel ----
        // Call repeat selector
        fun selectCqRepeat(n: Int) {
            prefs.rttyCqRepeat = n
            val active = 0xFF1A2A1A.toInt(); val idle = 0xFF1A1A1A.toInt()
            binding.btnCqCall1.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 1) active else idle)
            binding.btnCqCall2.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 2) active else idle)
            binding.btnCqCall3.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 3) active else idle)
            refreshCqButton()
        }
        binding.btnCqCall1.setOnClickListener { selectCqRepeat(1) }
        binding.btnCqCall2.setOnClickListener { selectCqRepeat(2) }
        binding.btnCqCall3.setOnClickListener { selectCqRepeat(3) }
        selectCqRepeat(prefs.rttyCqRepeat.coerceIn(1, 3))

        // POTA/JCC toggles (CQ)
        fun refreshCqToggles() {
            binding.btnCqTogglePota.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (prefs.rttyCqPota) 0xFF0A2A2A.toInt() else 0xFF1A1A1A.toInt())
            binding.btnCqTogglePota.setTextColor(if (prefs.rttyCqPota) 0xFF80CBC4.toInt() else 0xFF888888.toInt())
            binding.btnCqToggleJcc.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (prefs.rttyCqJcc) 0xFF2A1500.toInt() else 0xFF1A1A1A.toInt())
            binding.btnCqToggleJcc.setTextColor(if (prefs.rttyCqJcc) 0xFFFFD54F.toInt() else 0xFF888888.toInt())
            refreshCqButton()
        }
        binding.btnCqTogglePota.setOnClickListener { prefs.rttyCqPota = !prefs.rttyCqPota; refreshCqToggles() }
        binding.btnCqToggleJcc.setOnClickListener { prefs.rttyCqJcc = !prefs.rttyCqJcc; refreshCqToggles() }
        refreshCqToggles()

        // Greeting selector (shared CQ+ANS)
        fun selectGreeting(g: String) {
            prefs.rttyGreeting = g
            val active = 0xFF1A2A1A.toInt(); val idle = 0xFF1A1A1A.toInt()
            for ((btn, v) in listOf(
                binding.btnGreetNone to "", binding.btnGreetGm to "GM",
                binding.btnGreetGe to "GE", binding.btnGreetGa to "GA",
                binding.btnAnsGreetNone to "", binding.btnAnsGreetGm to "GM",
                binding.btnAnsGreetGe to "GE", binding.btnAnsGreetGa to "GA"
            )) {
                btn.backgroundTintList = android.content.res.ColorStateList.valueOf(if (v == g) active else idle)
                btn.setTextColor(if (v == g) 0xFFFFFFFF.toInt() else 0xFF888888.toInt())
            }
        }
        binding.btnGreetNone.setOnClickListener { selectGreeting("") }
        binding.btnGreetGm.setOnClickListener { selectGreeting("GM") }
        binding.btnGreetGe.setOnClickListener { selectGreeting("GE") }
        binding.btnGreetGa.setOnClickListener { selectGreeting("GA") }
        binding.btnAnsGreetNone.setOnClickListener { selectGreeting("") }
        binding.btnAnsGreetGm.setOnClickListener { selectGreeting("GM") }
        binding.btnAnsGreetGe.setOnClickListener { selectGreeting("GE") }
        binding.btnAnsGreetGa.setOnClickListener { selectGreeting("GA") }
        selectGreeting(prefs.rttyGreeting)

        // QSL selector (shared CQ+ANS)
        fun selectQsl(q: String) {
            prefs.rttyQsl = q
            val active = 0xFF1A2A1A.toInt(); val idle = 0xFF1A1A1A.toInt()
            for ((btn, v) in listOf(
                binding.btnQslNone to "", binding.btnQslPse to "PSE QSL", binding.btnQslNo to "NO QSL",
                binding.btnAnsQslNone to "", binding.btnAnsQslPse to "PSE QSL", binding.btnAnsQslNo to "NO QSL"
            )) {
                btn.backgroundTintList = android.content.res.ColorStateList.valueOf(if (v == q) active else idle)
                btn.setTextColor(if (v == q) 0xFFFFFFFF.toInt() else 0xFF888888.toInt())
            }
        }
        binding.btnQslNone.setOnClickListener { selectQsl("") }
        binding.btnQslPse.setOnClickListener { selectQsl("PSE QSL") }
        binding.btnQslNo.setOnClickListener { selectQsl("NO QSL") }
        binding.btnAnsQslNone.setOnClickListener { selectQsl("") }
        binding.btnAnsQslPse.setOnClickListener { selectQsl("PSE QSL") }
        binding.btnAnsQslNo.setOnClickListener { selectQsl("NO QSL") }
        selectQsl(prefs.rttyQsl)

        // RST repeat (CQ panel) — both CQ and ANS panels share the same prefs value
        fun selectRstRep(n: Int) {
            prefs.rttyRstRepeat = n
            val active = 0xFF1A2A1A.toInt(); val idle = 0xFF1A1A1A.toInt()
            binding.btnRstRep1.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 1) active else idle)
            binding.btnRstRep1.setTextColor(if (n == 1) 0xFFFFFFFF.toInt() else 0xFF888888.toInt())
            binding.btnRstRep2.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 2) active else idle)
            binding.btnRstRep2.setTextColor(if (n == 2) 0xFFFFFFFF.toInt() else 0xFF888888.toInt())
            binding.btnRstRep3.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 3) active else idle)
            binding.btnRstRep3.setTextColor(if (n == 3) 0xFFFFFFFF.toInt() else 0xFF888888.toInt())
            binding.btnAnsRstRep1.backgroundTintList = binding.btnRstRep1.backgroundTintList
            binding.btnAnsRstRep1.setTextColor(binding.btnRstRep1.currentTextColor)
            binding.btnAnsRstRep2.backgroundTintList = binding.btnRstRep2.backgroundTintList
            binding.btnAnsRstRep2.setTextColor(binding.btnRstRep2.currentTextColor)
            binding.btnAnsRstRep3.backgroundTintList = binding.btnRstRep3.backgroundTintList
            binding.btnAnsRstRep3.setTextColor(binding.btnRstRep3.currentTextColor)
        }
        binding.btnRstRep1.setOnClickListener { selectRstRep(1) }
        binding.btnRstRep2.setOnClickListener { selectRstRep(2) }
        binding.btnRstRep3.setOnClickListener { selectRstRep(3) }
        binding.btnAnsRstRep1.setOnClickListener { selectRstRep(1) }
        binding.btnAnsRstRep2.setOnClickListener { selectRstRep(2) }
        binding.btnAnsRstRep3.setOnClickListener { selectRstRep(3) }
        selectRstRep(prefs.rttyRstRepeat.coerceIn(1, 3))

        // Loop count selector
        fun selectLoopCount(n: Int) {
            prefs.rttyCqLoopCount = n
            val active = 0xFF1A2A1A.toInt(); val idle = 0xFF1A1A1A.toInt()
            binding.btnLoop3.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 3) active else idle)
            binding.btnLoop5.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 5) active else idle)
            binding.btnLoop10.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 10) active else idle)
            binding.btnLoopInf.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 0) active else idle)
        }
        binding.btnLoop3.setOnClickListener { selectLoopCount(3) }
        binding.btnLoop5.setOnClickListener { selectLoopCount(5) }
        binding.btnLoop10.setOnClickListener { selectLoopCount(10) }
        binding.btnLoopInf.setOnClickListener { selectLoopCount(0) }
        selectLoopCount(prefs.rttyCqLoopCount)

        // Interval selector
        fun selectInterval(s: Int) {
            prefs.rttyCqLoopInterval = s
            val active = 0xFF1A2A1A.toInt(); val idle = 0xFF1A1A1A.toInt()
            binding.btnInt10.backgroundTintList = android.content.res.ColorStateList.valueOf(if (s == 10) active else idle)
            binding.btnInt15.backgroundTintList = android.content.res.ColorStateList.valueOf(if (s == 15) active else idle)
            binding.btnInt30.backgroundTintList = android.content.res.ColorStateList.valueOf(if (s == 30) active else idle)
            binding.btnInt60.backgroundTintList = android.content.res.ColorStateList.valueOf(if (s == 60) active else idle)
        }
        binding.btnInt10.setOnClickListener { selectInterval(10) }
        binding.btnInt15.setOnClickListener { selectInterval(15) }
        binding.btnInt30.setOnClickListener { selectInterval(30) }
        binding.btnInt60.setOnClickListener { selectInterval(60) }
        selectInterval(prefs.rttyCqLoopInterval)

        // ANS POTA/JCC toggles
        fun refreshAnsToggles() {
            binding.btnAnsTogglePota.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (prefs.rttyAnsPota) 0xFF0A2A2A.toInt() else 0xFF1A1A1A.toInt())
            binding.btnAnsTogglePota.setTextColor(if (prefs.rttyAnsPota) 0xFF80CBC4.toInt() else 0xFF888888.toInt())
            binding.btnAnsToggleJcc.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (prefs.rttyAnsJcc) 0xFF2A1500.toInt() else 0xFF1A1A1A.toInt())
            binding.btnAnsToggleJcc.setTextColor(if (prefs.rttyAnsJcc) 0xFFFFD54F.toInt() else 0xFF888888.toInt())
        }
        binding.btnAnsTogglePota.setOnClickListener { prefs.rttyAnsPota = !prefs.rttyAnsPota; refreshAnsToggles() }
        binding.btnAnsToggleJcc.setOnClickListener { prefs.rttyAnsJcc = !prefs.rttyAnsJcc; refreshAnsToggles() }
        refreshAnsToggles()

        // TX amplitude button
        val ampPct = (prefs.rttyTxAmplitude * 100).toInt()
        binding.btnTxGain.text = "$ampPct%"
        binding.btnTxGain.setOnClickListener { showAmplitudeDialog() }

        // Carrier calibration button (per-band FT-991A offset)
        binding.btnRttyCalibration.setOnClickListener { showCarrierCalibrationDialog() }

        // Assembled message buttons
        binding.btnCq.setOnClickListener { startTx(buildCqText()) }
        binding.btnCq.setOnLongClickListener { fillTxField(buildCqText()); true }

        binding.btnCqDxK.setOnClickListener {
            val dx = binding.etDxCall.text.toString().trim().uppercase().ifEmpty { "?" }
            startTx("$dx K")
        }
        binding.btnCqDxK.setOnLongClickListener {
            val dx = binding.etDxCall.text.toString().trim().uppercase().ifEmpty { "?" }
            fillTxField("$dx K"); true
        }
        binding.btnCqDxDeMyK.setOnClickListener {
            val dx = binding.etDxCall.text.toString().trim().uppercase().ifEmpty { "?" }
            val my = myCall
            startTx("$dx DE $my K")
        }
        binding.btnCqDxDeMyK.setOnLongClickListener {
            val dx = binding.etDxCall.text.toString().trim().uppercase().ifEmpty { "?" }
            val my = myCall
            fillTxField("$dx DE $my K"); true
        }
        binding.btnCqUr.setOnClickListener { startTx(buildUrText()) }
        binding.btnCqUr.setOnLongClickListener { fillTxField(buildUrText()); true }
        binding.btnCqTu.setOnClickListener { startTx("TU TU 73 E E") }
        binding.btnCqTu.setOnLongClickListener { fillTxField("TU TU 73 E E"); true }
        binding.btnCqAgn.setOnClickListener { startTx("PSE AGN") }
        binding.btnCqAgn.setOnLongClickListener { fillTxField("PSE AGN"); true }

        binding.btnAnsMyK.setOnClickListener {
            val my = myCall
            startTx("$my K")
        }
        binding.btnAnsMyK.setOnLongClickListener {
            val my = myCall
            fillTxField("$my K"); true
        }
        binding.btnAnsDxDeMyK.setOnClickListener {
            val dx = binding.etDxCall.text.toString().trim().uppercase().ifEmpty { "?" }
            val my = myCall
            startTx("$dx DE $my K")
        }
        binding.btnAnsDxDeMyK.setOnLongClickListener {
            val dx = binding.etDxCall.text.toString().trim().uppercase().ifEmpty { "?" }
            val my = myCall
            fillTxField("$dx DE $my K"); true
        }
        binding.btnAnsUr.setOnClickListener { startTx(buildUrText()) }
        binding.btnAnsUr.setOnLongClickListener { fillTxField(buildUrText()); true }
        binding.btnAnsTu.setOnClickListener { startTx("TU TU 73 E E") }
        binding.btnAnsTu.setOnLongClickListener { fillTxField("TU TU 73 E E"); true }
        binding.btnAnsAgn.setOnClickListener { startTx("PSE AGN") }
        binding.btnAnsAgn.setOnLongClickListener { fillTxField("PSE AGN"); true }

        // Show actual callsign on ANS buttons
        val mc = myCall
        binding.btnAnsMyK.text = "$mc K"
        binding.btnAnsDxDeMyK.text = "{dx}DE $mc K"

        // CQ REPEAT
        binding.btnCqRepeat.setOnClickListener {
            if (cqRepeatJob?.isActive == true) {
                stopCqRepeat()
            } else {
                startCqRepeat()
            }
        }
    }

    private fun fillTxField(text: String) {
        binding.etTx.setText(text)
        binding.etTx.setSelection(text.length)
        binding.etTx.requestFocus()
    }

    private fun buildCqText(): String {
        val my = myCall
        val repeat = vm.prefs.rttyCqRepeat.coerceIn(1, 3)
        val callPart = (1..repeat).joinToString(" ") { my }
        val extras = buildList {
            if (vm.prefs.rttyCqPota) { val p = binding.etPota.text.toString().trim().uppercase(); if (p.isNotEmpty()) add("POTA $p") }
            if (vm.prefs.rttyCqJcc) { val j = binding.etJcc.text.toString().trim(); if (j.isNotEmpty()) add("JCC $j") }
        }.joinToString(" ")
        return "CQ CQ CQ DE $callPart${if (extras.isNotEmpty()) " $extras" else ""} K"
    }

    private fun buildUrText(): String {
        val greet = vm.prefs.rttyGreeting
        val rst = binding.etRst.text.toString().trim().ifEmpty { "599" }
        val repeat = vm.prefs.rttyRstRepeat.coerceIn(1, 3)
        val rstPart = (1..repeat).joinToString(" ") { rst }
        val extras = buildList {
            if (vm.prefs.rttyCqPota && binding.panelCq.visibility == View.VISIBLE ||
                vm.prefs.rttyAnsPota && binding.panelAns.visibility == View.VISIBLE) {
                val p = binding.etPota.text.toString().trim().uppercase()
                if (p.isNotEmpty()) add("POTA $p")
            }
            val qsl = vm.prefs.rttyQsl
            if (qsl.isNotEmpty()) add(qsl)
        }.joinToString(" ")
        return "${if (greet.isNotEmpty()) "$greet " else ""}UR $rstPart${if (extras.isNotEmpty()) " $extras" else ""} BK"
    }

    private fun refreshCqButton() {
        binding.btnCq.text = buildCqText()
    }

    private fun showAmplitudeDialog() {
        val seekBar = android.widget.SeekBar(requireContext()).apply {
            max = 18  // 0.10 to 1.00 in steps of 0.05, so (1.00-0.10)/0.05 = 18 steps
            progress = ((vm.prefs.rttyTxAmplitude - 0.10f) / 0.05f).toInt().coerceIn(0, 18)
        }
        val label = android.widget.TextView(requireContext()).apply {
            text = "TX Gain: ${(vm.prefs.rttyTxAmplitude * 100).toInt()}%"
            textSize = 14f
            setPadding(48, 16, 48, 8)
        }
        seekBar.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar, p: Int, u: Boolean) {
                val amp = (0.10f + p * 0.05f).coerceIn(0.10f, 1.00f)
                label.text = "TX Gain: ${(amp * 100).toInt()}%"
            }
            override fun onStartTrackingTouch(sb: android.widget.SeekBar) {}
            override fun onStopTrackingTouch(sb: android.widget.SeekBar) {}
        })
        val layout = android.widget.LinearLayout(requireContext()).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            addView(label)
            addView(seekBar.also { it.setPadding(48, 0, 48, 16) })
        }
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("RTTY TX 出力")
            .setView(layout)
            .setPositiveButton("OK") { _, _ ->
                val amp = (0.10f + seekBar.progress * 0.05f).coerceIn(0.10f, 1.00f)
                vm.prefs.rttyTxAmplitude = amp
                val pct = (amp * 100).toInt()
                binding.btnTxGain.text = "$pct%"
                binding.seekTxGain.progress = (pct - 10).coerceIn(0, 90)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showCarrierCalibrationDialog() {
        val rigId = (vm.rigList.value ?: emptyList()).getOrNull(vm.selectedRigIndex.value ?: 0)?.id
        if (rigId != 1035) {
            android.widget.Toast.makeText(requireContext(), "この補正設定はFT-991Aのみ有効です", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        val ctx = requireContext()
        val dp = resources.displayMetrics.density

        fun makeRow(labelText: String, initialHz: Int): Triple<android.widget.LinearLayout, android.widget.TextView, IntArray> {
            val current = intArrayOf(initialHz)
            val valueView = android.widget.TextView(ctx).apply {
                text = "${if (current[0] >= 0) "+" else ""}${current[0]} Hz"
                textSize = 14f
                setTextColor(0xFFFFFFFF.toInt())
                gravity = android.view.Gravity.CENTER
                minWidth = (72 * dp).toInt()
            }
            val btnMinus = android.widget.Button(ctx).apply {
                text = "−20"
                textSize = 11f
                minWidth = 0; minimumWidth = 0
            }
            val btnPlus = android.widget.Button(ctx).apply {
                text = "+20"
                textSize = 11f
                minWidth = 0; minimumWidth = 0
            }
            fun refresh() { valueView.text = "${if (current[0] >= 0) "+" else ""}${current[0]} Hz" }
            btnMinus.setOnClickListener { current[0] -= 20; refresh() }
            btnPlus.setOnClickListener  { current[0] += 20; refresh() }
            val label = android.widget.TextView(ctx).apply {
                text = labelText; textSize = 13f
                setTextColor(0xFFAAAAAA.toInt())
                minWidth = (60 * dp).toInt()
            }
            val row = android.widget.LinearLayout(ctx).apply {
                orientation = android.widget.LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding((16 * dp).toInt(), (6 * dp).toInt(), (16 * dp).toInt(), (6 * dp).toInt())
                addView(label)
                addView(btnMinus)
                addView(valueView)
                addView(btnPlus)
            }
            return Triple(row, valueView, current)
        }

        val (rowHf,  _, curHf)  = makeRow("HF (< 50MHz)",  vm.prefs.rttyDataShiftOffsetHf)
        val (row50,  _, cur50)  = makeRow("50 MHz",         vm.prefs.rttyDataShiftOffset50)
        val (row144, _, cur144) = makeRow("144 MHz",        vm.prefs.rttyDataShiftOffset144)
        val (row430, _, cur430) = makeRow("430 MHz",        vm.prefs.rttyDataShiftOffset430)

        val note = android.widget.TextView(ctx).apply {
            text = "dataShift = 865 + オフセット\n（デフォルト: 全バンド 0）"
            textSize = 11f
            setTextColor(0xFF888888.toInt())
            setPadding((16 * dp).toInt(), (4 * dp).toInt(), (16 * dp).toInt(), (8 * dp).toInt())
        }
        val layout = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            addView(rowHf); addView(row50); addView(row144); addView(row430); addView(note)
        }
        android.app.AlertDialog.Builder(ctx)
            .setTitle("RTTY キャリア補正 (FT-991A)")
            .setView(layout)
            .setPositiveButton("OK") { _, _ ->
                vm.prefs.rttyDataShiftOffsetHf  = curHf[0]
                vm.prefs.rttyDataShiftOffset50  = cur50[0]
                vm.prefs.rttyDataShiftOffset144 = cur144[0]
                vm.prefs.rttyDataShiftOffset430 = cur430[0]
            }
            .setNeutralButton("リセット") { _, _ ->
                vm.prefs.rttyDataShiftOffsetHf  = 0
                vm.prefs.rttyDataShiftOffset50  = 0
                vm.prefs.rttyDataShiftOffset144 = 0
                vm.prefs.rttyDataShiftOffset430 = 0
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun startCqRepeat() {
        val text = buildCqText()
        val loopCount = vm.prefs.rttyCqLoopCount  // 0 = ∞
        val intervalMs = vm.prefs.rttyCqLoopInterval * 1000L
        var sent = 0
        cqRepeatJob = lifecycleScope.launch(Dispatchers.Main) {
            binding.btnCqRepeat.text = "■ STOP CQ"
            binding.btnCqRepeat.backgroundTintList = android.content.res.ColorStateList.valueOf(0xFFB71C1C.toInt())
            while (loopCount == 0 || sent < loopCount) {
                sent++
                val countStr = if (loopCount == 0) "∞" else "$sent/$loopCount"
                binding.tvCqRepeatStatus.text = "CQ $countStr…"
                startTx(text)
                // Wait for TX to complete
                while (txJob?.isActive == true) delay(200)
                if (!isActive) break
                if (loopCount != 0 && sent >= loopCount) break
                // Count down interval
                var remaining = intervalMs / 1000L
                while (remaining > 0 && isActive) {
                    binding.tvCqRepeatStatus.text = "CQ $countStr — 次まで ${remaining}s"
                    delay(1000)
                    remaining--
                }
            }
            stopCqRepeat()
        }
    }

    private fun stopCqRepeat() {
        cqRepeatJob?.cancel()
        cqRepeatJob = null
        if (_binding != null) {
            binding.tvCqRepeatStatus.text = ""
            binding.btnCqRepeat.text = "CQ REPEAT"
            binding.btnCqRepeat.backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF2A1A00.toInt())
        }
    }

    // --- Rig mode ---

    private fun applyRigMode() {
        val mode = if (isRttyR) "RTTYR" else "RTTY"
        vm.sendMode(mode, 0)
        updateStatus("Mode: $mode")
    }

    // --- RX ---

    private fun startRx() {
        peakPos = 0
        val sIdx = vm.selectedSamplingIndex.value ?: 1
        val selectedRate = SAMPLING_RATES.getOrElse(sIdx) { 8000 }.let { if (it == 0) 8000 else it }

        // setPttEnabled(true) calls audio.stop() — restart Pi audio if RTTY owns it
        if (rttyStartedAudio && !vm.audio.isStreamActive) vm.startAudio()

        // Use the rate of the already-running stream (e.g. SPK was on before entering RTTY).
        // selectedSamplingIndex may differ from the running rate and would cause a mismatch.
        val piRate = if (vm.audio.isStreamActive && vm.audio.currentSampleRate > 0)
            vm.audio.currentSampleRate else selectedRate

        usingPiAudio = vm.audio.isStreamActive
        val initialRate = if (usingPiAudio) piRate else 8000
        Log.d("RTTY", "startRx: usingPiAudio=$usingPiAudio piRate=$piRate streamActive=${vm.audio.isStreamActive} currentRate=${vm.audio.currentSampleRate} modemRate=$initialRate")
        modem = RttyModem(
            sampleRate = initialRate,
            baudRate = currentBaud, markHz = lastMarkHz, spaceHz = lastSpaceHz
        ) { ch -> activity?.runOnUiThread { appendRx(ch) } }

        // Wire audioSampleListener. The running stream's own rate is the ground truth, so
        // it is read here rather than predicted in advance: startAudio() above is async,
        // so at this point the stream is usually not up yet and piRate is only the
        // sampling setting. If the stream then runs at a different rate, the Goertzel
        // coefficients sit on the wrong frequencies — the tones still show in the
        // waterfall, but nothing decodes.
        vm.audio.audioSampleListener = { shorts ->
            val streamRate = vm.audio.currentSampleRate.takeIf { it > 0 } ?: piRate
            if (!usingPiAudio) {
                usingPiAudio = true
                rxJob?.cancel(); rxJob = null
                val r = recorder; recorder = null
                r?.stop(); r?.release()
                updateStatus("RX (Pi)")
            }
            if (modem?.sampleRate != streamRate) {
                modem = RttyModem(
                    sampleRate = streamRate, baudRate = currentBaud,
                    markHz = lastMarkHz, spaceHz = lastSpaceHz
                ) { ch -> activity?.runOnUiThread { appendRx(ch) } }
                Log.d("RTTY", "modem (re)built at stream rate=$streamRate (piRate was $piRate)")
            }
            // Rate-limited diagnostic: log audio level every ~80 chunks
            if (++logChunkCount % 80 == 0) {
                val sq = shorts.sumOf { it.toDouble() * it.toDouble() }
                val rms = sqrt(sq / shorts.size) / 32768.0
                val db = if (rms > 1e-10) log10(rms).times(20).toInt() else -100
                Log.d("RTTY", "Pi audio: ${shorts.size}smp ${db}dB usingPi=$usingPiAudio modem=${modem?.sampleRate}Hz")
            }
            modem?.feed(shorts, shorts.size)
            processForWaterfall(shorts, shorts.size, streamRate)
        }

        if (usingPiAudio) {
            updateStatus("RX (Pi)")
            return
        }

        // Pi not yet active: start phone microphone as fallback
        val sampleRate = 8000
        val minBuf = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val rec = AudioRecord(
            MediaRecorder.AudioSource.MIC, sampleRate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minBuf, sampleRate / 2 * 2)
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            updateStatus("AudioRecord init failed")
            return
        }
        recorder = rec
        rec.startRecording()
        updateStatus("RX (MIC)")

        rxJob = lifecycleScope.launch(Dispatchers.IO) {
            val buf = ShortArray(minBuf / 2)
            while (isActive && !usingPiAudio) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) continue
                if (!usingPiAudio) {
                    modem?.feed(buf, n)
                    processForWaterfall(buf, n, sampleRate)
                }
            }
        }
    }

    private fun processForWaterfall(buf: ShortArray, n: Int, sampleRate: Int) {
        var src = 0; var rem = n
        while (rem > 0) {
            val take = minOf(rem, PEAK_BUF_SIZE - peakPos)
            buf.copyInto(peakBuf, peakPos, src, src + take)
            peakPos += take; src += take; rem -= take
            if (peakPos >= PEAK_BUF_SIZE) {
                peakPos = 0
                val snap   = peakBuf.copyOf()
                val sq     = snap.sumOf { it.toDouble() * it.toDouble() }
                val rms    = sqrt(sq / PEAK_BUF_SIZE.toDouble()) / 32768.0
                rxLevelDb  = if (rms > 1e-10) log10(rms).times(20).toInt() else -100
                val powers = RttyModem.scanPowers(snap, PEAK_BUF_SIZE, sampleRate)
                val peaks  = RttyModem.findPeaks(powers)
                lifecycleScope.launch(Dispatchers.Main) {
                    if (_binding != null) binding.rttyWaterfall.addRow(powers)
                    updatePeakDisplay(peaks)
                    // Auto-tune, with hysteresis. Every retune resets the demodulator and
                    // abandons the frame in progress, so chasing each momentary peak costs
                    // more characters than it saves. findPeaks already rejects noise and
                    // sidelobes; on top of that the same pair must be seen in three
                    // consecutive analyses, must differ from the current tuning by more than
                    // one scan bin, and retunes are spaced at least two seconds apart.
                    // RTTYR: higher peak = mark, lower = space (same as iOS RttyView).
                    if (peaks != null) {
                        val lo = peaks.first; val hi = peaks.second
                        val m = if (isRttyR) hi else lo
                        val s = if (isRttyR) lo else hi
                        val moved = abs(m - lastMarkHz) > 25 || abs(s - lastSpaceHz) > 25
                        if (moved) {
                            if (abs(m - candMarkHz) <= 25 && abs(s - candSpaceHz) <= 25) candCount++
                            else { candMarkHz = m; candSpaceHz = s; candCount = 1 }
                        } else {
                            candCount = 0
                        }
                        val nowMs = System.currentTimeMillis()
                        lastPairSeenMs = nowMs
                        if (!tuneFixed && moved && candCount >= 3 && nowMs - lastRetuneMs >= 2_000L) {
                            lastMarkHz = m; lastSpaceHz = s
                            lastRetuneMs = nowMs; candCount = 0
                            modem?.updateFrequencies(m, s)
                            if (_binding != null) binding.rttyWaterfall.setMarkers(m, s)
                        }
                    } else {
                        candCount = 0
                        // No convincing signal. If the modem was retuned away from the
                        // standard tones and the signal that justified it has been gone for a
                        // while, go back to the standard pair. Without this a single retune to
                        // a slightly off-frequency station stuck for the rest of the session:
                        // the iOS log showed decodeAt=2200/2380 persisting through a
                        // transmission that actually arrived at 2125/2295, 75 Hz off and about
                        // 1.6 Goertzel bins wide of each tone, which decoded with errors while
                        // the rig's own demodulator read the same signal cleanly.
                        val stdMark  = if (isRttyR) RttyModem.TX_SPACE_HZ else RttyModem.TX_MARK_HZ
                        val stdSpace = if (isRttyR) RttyModem.TX_MARK_HZ  else RttyModem.TX_SPACE_HZ
                        val offStandard = abs(lastMarkHz - stdMark) > 25 || abs(lastSpaceHz - stdSpace) > 25
                        val nowMs = System.currentTimeMillis()
                        if (!tuneFixed && offStandard && nowMs - lastPairSeenMs >= 5_000L) {
                            lastMarkHz = stdMark; lastSpaceHz = stdSpace
                            lastRetuneMs = nowMs; lastPairSeenMs = nowMs
                            modem?.updateFrequencies(stdMark, stdSpace)
                            if (_binding != null) binding.rttyWaterfall.setMarkers(stdMark, stdSpace)
                            Log.d("RTTY", "no signal for 5 s — back to standard ${stdMark.toInt()}/${stdSpace.toInt()}")
                        }
                    }
                }
            }
        }
    }

    private fun stopRx() {
        vm.audio.audioSampleListener = null  // always clear so Pi audio doesn't stale-feed a gone modem
        usingPiAudio = false
        rxJob?.cancel(); rxJob = null
        recorder?.stop(); recorder?.release(); recorder = null
    }

    private fun updatePeakDisplay(peaks: Pair<Double, Double>?) {
        if (_binding == null) return
        val lvl = rxLevelDb.let { if (it > -100) "  ${it}dB" else "" }
        if (peaks != null) {
            detectedMarkHz  = peaks.first
            detectedSpaceHz = peaks.second
            binding.tvPeakFreq.text = "${peaks.first.toInt()} / ${peaks.second.toInt()} Hz$lvl"
            binding.btnTune.isEnabled = true
        } else {
            binding.tvPeakFreq.text = "--- / --- Hz$lvl"
            // In Fix mode the button must stay usable so the long-press can release it.
            binding.btnTune.isEnabled = tuneFixed
        }
    }

    /** Long-press handler for the Tune button: enter or leave Fix mode. */
    private fun toggleTuneFixed() {
        tuneFixed = !tuneFixed
        candCount = 0
        lastPairSeenMs = System.currentTimeMillis()
        updateTuneButton()
        updateStatus(
            if (tuneFixed) "FIX: ${lastMarkHz.toInt()} / ${lastSpaceHz.toInt()} Hz — タップで移動、長押しで解除"
            else "Tune: 自動追従に戻しました"
        )
    }

    private fun updateTuneButton() {
        if (_binding == null) return
        binding.btnTune.text = if (tuneFixed) "FIX ${lastMarkHz.toInt()}/${lastSpaceHz.toInt()}" else "Tune"
        binding.btnTune.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (tuneFixed) 0xFF5A3A00.toInt() else 0xFF1A2A0A.toInt())
        if (tuneFixed) binding.btnTune.isEnabled = true
    }

    private fun shiftFreq(deltaHz: Double) {
        lastMarkHz  = (lastMarkHz  + deltaHz).coerceIn(1200.0, 3000.0)
        lastSpaceHz = (lastSpaceHz + deltaHz).coerceIn(1200.0, 3000.0)
        modem?.updateFrequencies(lastMarkHz, lastSpaceHz)
        binding.rttyWaterfall.setMarkers(lastMarkHz, lastSpaceHz)
        updateTuneButton()
        updateStatus("Shift ${if (deltaHz > 0) "+" else ""}${deltaHz.toInt()} Hz → ${lastMarkHz.toInt()} / ${lastSpaceHz.toInt()} Hz")
    }

    private fun applyTune() {
        if (tuneFixed) return   // the position is frozen; long-press to release it first
        val m = modem ?: return
        if (detectedMarkHz <= 0 || detectedSpaceHz <= 0) return
        lastMarkHz  = detectedMarkHz
        lastSpaceHz = detectedSpaceHz
        m.updateFrequencies(lastMarkHz, lastSpaceHz)
        binding.rttyWaterfall.setMarkers(lastMarkHz, lastSpaceHz)
        updateStatus("Tuned: ${lastMarkHz.toInt()} / ${lastSpaceHz.toInt()} Hz")
    }

    private fun restartModem(newBaud: Double) {
        currentBaud = newBaud
        stopRx()
        startRx()
    }

    private fun appendRx(ch: Char) {
        if (_binding == null) return
        if (rxSpan.length > 8000) rxSpan.delete(0, rxSpan.length - 6000)
        val ss = SpannableString(ch.toString())
        ss.setSpan(ForegroundColorSpan(Color.GREEN), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        rxSpan.append(ss)
        binding.tvRx.text = rxSpan
        binding.scrollRx.post { binding.scrollRx.fullScroll(View.FOCUS_DOWN) }
    }

    // --- TX mode ---


    /**
     * The transmit path, always decided automatically: CI-V when the radio is reached
     * directly, otherwise AFSK audio through the Pi.
     *
     * There used to be a selector that also offered serial FSK keying. Neither rig here can
     * use it. The IC-705 has no external FSK shift input, since its USB ports are CDC-ACM, so
     * toggling DTR keys nothing while the Pi still returns HTTP 200. The FT-991A does accept
     * DTR as FSK shift, but the Pi times the keying in software and every DTR change costs a
     * USB control transfer of 15-50 ms against a 22 ms bit period at 45.45 baud. Measured for
     * 27 characters, where 5.3 s was expected: 8.2, 15.1, 18.2, 30.5 s. It also saturated the
     * shared CP2105 and starved rigctld's polling, taking CAT control down for about 16 s each
     * time. There was nothing worth choosing, so the selector is gone.
     */
    private fun resolvedTxMode(): String = if (vm.useCIV.value == true) "civ" else "pi_afsk"

    /**
     * The rig's DATA-mode audio reference tone, in Hz: the audio frequency that its data-mode
     * dial reading actually refers to. Subtracted from the mark offset.
     *
     * The app's model is that in PKTLSB the displayed frequency *is* the suppressed carrier, so
     * an audio tone f lands at `display - f` and the dial has to sit one mark tone above the
     * RTTY mark. That holds on the IC-705, which transmitted RTTY on frequency with no
     * correction at all.
     *
     * The FT-991A's DATA SHIFT menu makes its dial refer to a 1000 Hz audio tone instead of the
     * carrier, the convention PSK31 uses. A tone f therefore lands at `display - f + 1000` and
     * the dial must sit only `2125 - 1000` above the RTTY mark, not the full 2125. The CAT path
     * was already correct when this was found: the frequency read back as exactly the
     * 144.602125 the app asked for, which rules out a control bug and leaves the rig's own
     * shift as the only candidate.
     *
     * The sign was wrong on the first attempt. Adding this value instead of subtracting it made
     * the error larger, which is what settled the direction: the original observation that
     * 144.601 decoded while 144.600 did not was the *receiver* being retuned up to meet a
     * signal already transmitting 1000 Hz high, not the transmitter needing to go up.
     *
     * Setting that menu to 0 on the rig makes this correction unnecessary, and then this should
     * be 0 too.
     */
    private fun dataShiftHz(rxFreq: Long = 0L): Long = when (
        (vm.rigList.value ?: emptyList()).getOrNull(vm.selectedRigIndex.value ?: 0)?.id
    ) {
        // FT-991A. 1000 Hz was the menu value and got the signal decoding; the receiver's
        // peak log then showed its mark arriving at about 2260 Hz instead of 2125, a residual
        // of +135 Hz in audio, which in LSB means the carrier was 135 Hz low. The space tone at
        // ~2430 Hz fell outside the IC-705's 500 Hz RTTY filter (about 1875–2375 Hz), which is
        // why that direction failed while the reverse was perfect. Raising the dial by 135 Hz
        // is the same as lowering this value by 135. The 20 Hz scan-bin resolution puts the
        // true value within roughly ±20 Hz of this.
        //
        // Per-band calibration: FT-991A VHF/UHF uses different RF stages from HF, and the
        // effective carrier offset differs per band. Measured: on 144 MHz a signal at 2080 Hz
        // decoded only when capturedMarkHz was set to 2040 Hz (−40 Hz error), and on 430 MHz
        // a signal at 2020–2040 Hz decoded only at capturedMarkHz 2100 Hz (+80 Hz error).
        // Corrected by adjusting this value ±40/80 Hz per band so the auto-capture of
        // capturedMarkHz at the actual signal position yields exact TX alignment.
        1035 -> when {
            rxFreq in 50_000_000L..54_000_000L   -> (865 + vm.prefs.rttyDataShiftOffset50).toLong()
            rxFreq in 144_000_000L..146_000_000L -> (865 + vm.prefs.rttyDataShiftOffset144).toLong()
            rxFreq in 430_000_000L..440_000_000L -> (865 + vm.prefs.rttyDataShiftOffset430).toLong()
            else                                  -> (865 + vm.prefs.rttyDataShiftOffsetHf).toLong()
        }
        else -> 0L
    }

    // --- TX ---

    private fun startTx(text: String, txCount: Int = 1) {
        if (txJob?.isActive == true) return
        if (text.isEmpty()) return

        val resolved = resolvedTxMode()
        if (resolved == "civ" && vm.useCIV.value != true) {
            updateStatus("RTTY TX: CI-V未接続")
            return
        }
        // Refuse to transmit while the dial is unknown. sharedFreq is 0 whenever the control
        // link has dropped, and a transmission started then went out with no frequency or mode
        // command at all, on whatever the rig happened to be tuned to.
        if ((vm.sharedFreq.value ?: 0L) <= 0L) {
            updateStatus("TX: 周波数不明 — 接続が復帰するまで送信しません")
            Toast.makeText(requireContext(), "周波数未取得 — しばらく待って再試行", Toast.LENGTH_SHORT).show()
            return
        }

        // Auto-FIX: freeze the decode position before TX so lastMarkHz is stable.
        // Track whether it was set here so we can release it after TX, letting the modem
        // re-track before the next transmission (prevents stale lastMarkHz on band change).
        val autoFixed = !tuneFixed
        if (autoFixed) toggleTuneFixed()
        val capturedMarkHz = lastMarkHz   // capture on Main while FIX holds it stable

        txJob = lifecycleScope.launch(Dispatchers.IO) {
            stopRx()
            withContext(Dispatchers.Main) {
                setPttUi(true)
                val txLabel = "\n[TX] $text\n"
                val ss = SpannableString(txLabel)
                ss.setSpan(ForegroundColorSpan(Color.YELLOW), 0, txLabel.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                if (rxSpan.length > 8000 - txLabel.length)
                    rxSpan.delete(0, rxSpan.length - (6000 - txLabel.length).coerceAtLeast(0))
                rxSpan.append(ss)
                binding.tvRx.text = rxSpan
                binding.scrollRx.post { binding.scrollRx.fullScroll(View.FOCUS_DOWN) }
            }
            pttActive = true
            try {
                run {
                    // RS-BA1 CI-V audio is fixed at 8 kHz. The Pi path uses 48 kHz, the native
                    // rate of the rig's USB codec, so ALSA's plug layer has nothing to
                    // resample. At 8 kHz the Pi ran aplay through plughw, whose rate converter
                    // is a linear interpolator: fine for voice, but interpolating the 2125 and
                    // 2295 Hz tones up to the codec rate adds harmonics and images inside the
                    // SSB passband, which puts a dirty, undecodable signal on the air.
                    val txRate = if (vm.useCIV.value == true) 8000 else 48000
                    val amplitude = vm.prefs.rttyTxAmplitude.toDouble().coerceIn(0.1, 1.0)
                    // Always encode at the standard AFSK frequencies (2125/2295 Hz).
                    // IC-705's internal RTTY decoder expects mark at exactly 2125 Hz.
                    // Frequency alignment is done by the ±100 Hz dial buttons, which shift
                    // the IC-705's carrier so the received signal lands at 2125 Hz on the waterfall.
                    val encoder = RttyModem(txRate, RttyModem.TX_MARK_HZ, RttyModem.TX_SPACE_HZ, currentBaud) { }
                    val single  = encoder.encode(text, amplitude)
                    val samples = if (txCount == 1) single else {
                        ShortArray(single.size * txCount).also { out ->
                            repeat(txCount) { i -> single.copyInto(out, i * single.size) }
                        }
                    }
                    val txMode = if (isRttyR) "PKTUSB" else "PKTLSB"
                    val rxMode = if (isRttyR) "RTTYR" else "RTTY"
                    val rxFreq = vm.sharedFreq.value ?: 0L
                    val markOffsetHz = RttyModem.TX_MARK_HZ.toLong()
                    val totalOffset = markOffsetHz - dataShiftHz(rxFreq)
                    // Shift the carrier by the signal's audio offset from the 2125 Hz standard.
                    // capturedMarkHz is frozen at the actual mark position (e.g. 2080 Hz),
                    // so freqCorrection = −45 Hz shifts the TX carrier down by 45 Hz, landing
                    // the mark RF on the received signal's RF frequency.
                    val freqCorrection = (capturedMarkHz - RttyModem.TX_MARK_HZ).toLong()
                    val txFreq = if (rxFreq > 0L) {
                        if (isRttyR) rxFreq - totalOffset - freqCorrection
                        else         rxFreq + totalOffset + freqCorrection
                    } else 0L
                    val pathName = if (vm.useCIV.value == true) "CIV" else "AFSK-Pi"
                    Log.d("RTTY", "startTx $pathName: ${samples.size}smp @${txRate}Hz txMode=$txMode " +
                            "rxFreq=$rxFreq txFreq=$txFreq mark=$markOffsetHz dataShift=${dataShiftHz(rxFreq)} " +
                            "(${"%.1f".format(samples.size.toDouble() / txRate)}s)")
                    // Stand the Pi receive stream down for the transmission. stopRx() only
                    // clears the local listener and recorder; the HTTP stream keeps running.
                    // The Pi's /radio/audio_tx kills its capture processes before it starts
                    // aplay, so that stream dies anyway, and leaving it connected only means
                    // the app notices the death and starts reconnecting mid-transmission. On
                    // the single-core Pi that reconnect storm, each attempt spawning a fresh
                    // ffmpeg, competed with aplay and rigctld until /radio/status timed out and
                    // the control link was declared lost. Repeated transmit/receive cycles in
                    // RTTY dropped the connection this way.
                    val audioWasActive = vm.audio.isStreamActive
                    if (audioWasActive) withContext(Dispatchers.Main) { vm.stopAudio() }
                    vm.streamRttyTx(samples, txMode, rxMode, txFreq, rxFreq, txRate)
                    if (audioWasActive) withContext(Dispatchers.Main) { vm.startAudio() }
                }
            } finally {
                pttActive = false
                withContext(Dispatchers.Main) {
                    if (_binding != null) {
                        setPttUi(false)
                        binding.etTx.text?.clear()
                        // Release auto-FIX so the modem re-tracks on the next RX cycle.
                        // Reset lastMarkHz to the standard value so a stale position from
                        // a previous band does not corrupt the next transmission's correction.
                        if (autoFixed && tuneFixed) {
                            lastMarkHz  = RttyModem.TX_MARK_HZ
                            lastSpaceHz = RttyModem.TX_SPACE_HZ
                            modem?.updateFrequencies(lastMarkHz, lastSpaceHz)
                            binding.rttyWaterfall.setMarkers(lastMarkHz, lastSpaceHz)
                            toggleTuneFixed()
                        }
                    }
                }
                startRx()
            }
        }
    }

    private fun cancelTx() {
        txJob?.cancel()
        txJob = null
        if (pttActive) { vm.setPttEnabled(false); pttActive = false }
        lifecycleScope.launch(Dispatchers.Main) { if (_binding != null) setPttUi(false) }
        lifecycleScope.launch(Dispatchers.IO) { startRx() }
    }

    private fun toggleManualPtt() {
        pttActive = !pttActive
        vm.setPttEnabled(pttActive)
        setPttUi(pttActive)
        updateStatus(if (pttActive) "TX (manual PTT)" else "RX")
    }

    private fun setPttUi(tx: Boolean) {
        binding.tvRxTx.text  = if (tx) "TX" else "RX"
        binding.tvRxTx.setTextColor(if (tx) 0xFFFF4444.toInt() else 0xFF44FF44.toInt())
        binding.btnPtt.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (tx) 0xFFD32F2F.toInt() else 0xFF6A1B9A.toInt()
        )
        binding.btnTx.isEnabled  = !tx
        binding.btnTx.alpha      = if (tx) 0.4f else 1.0f
        binding.btnTx2.isEnabled = !tx
        binding.btnTx2.alpha     = if (tx) 0.4f else 1.0f
        binding.btnStop.visibility = if (tx) View.VISIBLE else View.GONE
    }

    // suspend so delay() can wait for all samples to play before releasing the track.
    private suspend fun playAudio(samples: ShortArray, sampleRate: Int) {
        val bufBytes = samples.size * 2
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufBytes)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        track.write(samples, 0, samples.size)
        track.play()
        // Wait for the full message to play out before releasing.
        val durationMs = samples.size.toLong() * 1000L / sampleRate
        delay(durationMs + 200)
        track.stop()
        track.release()
    }

    // --- Frequency dialog ---

    private fun showFreqDirectInput() {
        val ctx = requireContext()
        val current = vm.sharedFreq.value ?: 0L
        val et = android.widget.EditText(ctx).apply {
            hint = "例: 14.080"
            if (current > 0) {
                val s = "%.6f".format(current / 1_000_000.0).trimEnd('0').trimEnd('.')
                setText(s)
                selectAll()
            }
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                    android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setPadding(48, 24, 48, 8)
        }
        android.app.AlertDialog.Builder(ctx)
            .setTitle("周波数入力 (MHz)")
            .setView(et)
            .setPositiveButton("OK") { _, _ ->
                val mhz = et.text.toString().replace(',', '.').toDoubleOrNull()
                if (mhz != null && mhz > 0) vm.sendFreq((mhz * 1_000_000 + 0.5).toLong())
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showFreqDialog() {
        val labels = arrayOf(
            "160m   1.838 MHz",
            " 80m   3.535 MHz (JP)", " 80m   3.580 MHz",
            " 40m   7.030 MHz (JP)", " 40m   7.035 MHz",
            " 30m  10.142 MHz",
            " 20m  14.080 MHz",      " 20m  14.090 MHz",
            " 17m  18.102 MHz",
            " 15m  21.080 MHz",
            " 12m  24.920 MHz",
            " 10m  28.080 MHz",
            "  6m  50.300 MHz",
            "  2m 144.600 MHz (JP)", "  2m 144.800 MHz",
            " 70c 430.600 MHz (JP)", " 70c 432.600 MHz"
        )
        val freqs = longArrayOf(
            1_838_000L,
            3_535_000L,  3_580_000L,
            7_030_000L,  7_035_000L,
            10_142_000L,
            14_080_000L, 14_090_000L,
            18_102_000L,
            21_080_000L,
            24_920_000L,
            28_080_000L,
            50_300_000L,
            144_600_000L, 144_800_000L,
            430_600_000L, 432_600_000L
        )
        val current = vm.sharedFreq.value ?: 0L
        val idx = freqs.indexOfFirst { it == current }.coerceAtLeast(-1)
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("RTTY Band")
            .setSingleChoiceItems(labels, idx) { dialog, which ->
                vm.sendFreq(freqs[which])
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // --- Helpers ---

    private fun updateStatus(msg: String) {
        activity?.runOnUiThread { _binding?.tvStatus?.text = msg }
    }

    private fun updateFreqDisplay(hz: Long) {
        if (hz <= 0L) { binding.tvFreq.text = "---.--- MHz"; return }
        val mhz = hz / 1_000_000.0
        binding.tvFreq.text = "%,.3f MHz".format(mhz)
    }
}
