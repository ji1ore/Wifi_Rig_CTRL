import SwiftUI
import Citadel
import NIOCore

struct SshSetupView: View {
    @Bindable var vm: MainViewModel

    @State private var host: String = ""
    @State private var sshUser: String = "pi"
    @State private var sshPassword: String = ""
    @State private var statusText: String = "Pi に SSH で接続してセットアップを実行します"
    @State private var statusColor: Color = .secondary
    @State private var logLines: [String] = []
    @State private var isRunning: Bool = false

    private static let base =
        "https://raw.githubusercontent.com/ji1ore/M5CoreHamCAT/main/v3.16/RaspberryPiSetup"

    var body: some View {
        VStack(spacing: 0) {
            Form {
                Section(header: Label("Pi 接続先", systemImage: "network").foregroundStyle(.indigo)) {
                    LabeledContent("IP / Host") {
                        TextField("192.168.1.100 or raspberrypi.local", text: $host)
                            .multilineTextAlignment(.trailing)
                            .keyboardType(.URL)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                    }
                    LabeledContent("SSH User") {
                        TextField("pi", text: $sshUser)
                            .multilineTextAlignment(.trailing)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                    }
                    LabeledContent("SSH Password") {
                        SecureField("raspberry", text: $sshPassword)
                            .multilineTextAlignment(.trailing)
                    }
                }

                Section {
                    Text("⚠ 実行中は画面OFF・他の画面への移動をしないでください（Pi Zero 2W は 5〜10 分かかります）")
                        .font(.caption)
                        .foregroundStyle(.orange)

                    Button {
                        Task { await runSetup() }
                    } label: {
                        HStack {
                            if isRunning { ProgressView().padding(.trailing, 4) }
                            Text(isRunning ? "セットアップ中..." : "Run Setup")
                                .frame(maxWidth: .infinity)
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.indigo)
                    .disabled(isRunning || host.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
            .frame(maxHeight: 360)

            Text(statusText)
                .font(.callout)
                .foregroundStyle(statusColor)
                .padding(.horizontal)
                .padding(.vertical, 4)

            ScrollViewReader { proxy in
                ScrollView {
                    Text(logLines.joined(separator: "\n"))
                        .font(.system(.caption, design: .monospaced))
                        .foregroundStyle(.green)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(8)
                        .id("logEnd")
                }
                .background(Color(white: 0.05))
                .onChange(of: logLines.count) { _, _ in
                    withAnimation { proxy.scrollTo("logEnd", anchor: .bottom) }
                }
            }
        }
        .navigationTitle("SETUP (SSH)")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            if host.isEmpty { host = vm.hostName }
        }
    }

    // MARK: - SSH setup

    @MainActor
    private func appendLog(_ line: String) {
        logLines.append(line)
    }

    @MainActor
    private func runSetup() async {
        let targetHost = host.trimmingCharacters(in: .whitespaces)
        guard !targetHost.isEmpty else { return }

        logLines = []
        isRunning = true
        statusText = "\(targetHost) に接続中..."
        statusColor = .secondary

        do {
            let client = try await SSHClient.connect(
                host: targetHost,
                authenticationMethod: .passwordBased(username: sshUser, password: sshPassword),
                hostKeyValidator: .acceptAnything(),
                reconnect: .never
            )
            defer { Task { try? await client.close() } }

            appendLog("SSH 接続完了")
            statusText = "ファイルダウンロード中..."

            // Step 1: Download setup files
            let wgetCmd = """
                cd ~ && wget -q \
                '\(Self.base)/setup_fastapi_radio.sh' \
                '\(Self.base)/create_api.sh' \
                '\(Self.base)/api.py' \
                '\(Self.base)/cw_bridge.py' \
                '\(Self.base)/set_api_key.sh'
                """
            _ = try await client.executeCommand(wgetCmd)
            appendLog("✓ ファイルダウンロード完了")

            // Step 2: Set execute permissions
            _ = try await client.executeCommand(
                "chmod +x ~/setup_fastapi_radio.sh ~/create_api.sh ~/set_api_key.sh"
            )
            appendLog("✓ 実行権限設定完了")
            appendLog("セットアップスクリプト実行中... (5〜10 分かかります)")
            statusText = "セットアップ中... しばらくお待ちください"

            // Concurrent timer — shows elapsed time every 30 s while SSH command runs
            let startTime = Date()
            let timerTask = Task { @MainActor in
                while !Task.isCancelled {
                    try? await Task.sleep(nanoseconds: 30_000_000_000)
                    guard !Task.isCancelled else { break }
                    let elapsed = Int(-startTime.timeIntervalSinceNow)
                    appendLog("⏳ 実行中... \(elapsed)秒経過")
                }
            }

            // Step 3: Run setup script via sudo -S (password fed through printf)
            let escapedPass = sshPassword
                .replacingOccurrences(of: "\\", with: "\\\\")
                .replacingOccurrences(of: "'", with: "'\\''")
            let setupCmd =
                "printf '%s\\n' '\(escapedPass)' | sudo -S bash ~/setup_fastapi_radio.sh 2>&1; true"
            let output = try await client.executeCommand(setupCmd, maxResponseSize: 10 * 1024 * 1024)
            timerTask.cancel()

            // Append output lines to log
            if let text = output.getString(at: output.readerIndex, length: output.readableBytes),
               !text.isEmpty {
                for line in text.components(separatedBy: .newlines) where !line.isEmpty {
                    appendLog(line)
                }
            }

            appendLog("── セットアップ完了 ──")
            statusText = "✓ セットアップ完了！mfsk-decode ビルドを開始します..."

            // Step 4: FastAPI 起動を待ってからmfsk-decodeビルドをトリガー
            appendLog("⏳ FastAPI 起動待機中 (5秒)...")
            try? await Task.sleep(nanoseconds: 5_000_000_000)
            do {
                var req = URLRequest(url: URL(string: "http://\(targetHost):8000/admin/build_mfsk?force=true")!)
                req.httpMethod = "POST"
                req.timeoutInterval = 10
                let (_, resp) = try await URLSession.shared.data(for: req)
                if let http = resp as? HTTPURLResponse, http.statusCode == 200 {
                    appendLog("✓ mfsk-decode バックグラウンドビルド開始（10〜20分）")
                    appendLog("  Admin画面の mfsk Build Log で進捗を確認できます")
                } else {
                    appendLog("⚠ mfsk build trigger 失敗 — Admin画面から手動実行してください")
                }
            } catch {
                appendLog("⚠ mfsk build trigger 失敗: \(error.localizedDescription)")
                appendLog("  Admin画面から手動実行してください")
            }

            statusText = "✓ セットアップ完了！Pi 再起動後から利用できます"
            statusColor = .green

        } catch {
            appendLog("ERROR: \(error.localizedDescription)")
            statusText = "Error: \(error.localizedDescription)"
            statusColor = .red
        }

        isRunning = false
    }
}
