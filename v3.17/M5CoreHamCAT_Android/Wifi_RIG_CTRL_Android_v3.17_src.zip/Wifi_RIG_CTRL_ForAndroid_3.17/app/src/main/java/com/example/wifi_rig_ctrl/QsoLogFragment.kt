package com.ji1ore.wifi_rig_ctrl

import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.ji1ore.wifi_rig_ctrl.data.QsoEntry
import com.ji1ore.wifi_rig_ctrl.data.QsoStore
import com.ji1ore.wifi_rig_ctrl.viewmodel.MainViewModel
import java.io.File
import java.util.Calendar
import java.util.TimeZone

class QsoLogFragment : Fragment() {

    private val vm: MainViewModel by activityViewModels()
    private lateinit var listView: ListView
    private lateinit var tvCount: TextView
    private lateinit var btnSelectAll: Button
    private lateinit var btnDeleteSel: Button
    private lateinit var btnAdifSel: Button
    private lateinit var btnAdifAll: Button
    private lateinit var btnAddLog: Button

    private var entries: MutableList<QsoEntry> = mutableListOf()
    private val selected = mutableSetOf<Int>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val ctx = requireContext()
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        // Top toolbar
        val toolbar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 8, 8, 4)
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val btnBack = Button(ctx).apply {
            text = "← 戻る"; textSize = 12f; setPadding(10, 0, 10, 0)
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF37474F.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.marginEnd = 8 }
        }
        tvCount = TextView(ctx).apply {
            textSize = 13f; setTextColor(0xFFCCCCCC.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        btnAddLog = Button(ctx).apply {
            text = "+LOG"; textSize = 11f; setPadding(8, 0, 8, 0)
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF1B5E20.toInt())
            setTextColor(0xFFFFFFFF.toInt())
        }
        toolbar.addView(btnBack); toolbar.addView(tvCount); toolbar.addView(btnAddLog)
        root.addView(toolbar, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        // Selection toolbar
        val selBar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(8, 0, 8, 4)
        }
        btnSelectAll = Button(ctx).apply {
            text = "全選択"; textSize = 11f; setPadding(6, 0, 6, 0)
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF37474F.toInt())
            setTextColor(0xFFAAAAAA.toInt())
        }
        btnDeleteSel = Button(ctx).apply {
            text = "削除"; textSize = 11f; setPadding(6, 0, 6, 0)
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF7A1A1A.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT).also { it.marginStart = 4 }
        }
        btnAdifSel = Button(ctx).apply {
            text = "選択ADIF"; textSize = 11f; setPadding(6, 0, 6, 0)
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF1565C0.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT).also { it.marginStart = 4 }
        }
        btnAdifAll = Button(ctx).apply {
            text = "全ADIF"; textSize = 11f; setPadding(6, 0, 6, 0)
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF006064.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT).also { it.marginStart = 4 }
        }
        selBar.addView(btnSelectAll); selBar.addView(btnDeleteSel)
        selBar.addView(btnAdifSel); selBar.addView(btnAdifAll)
        root.addView(selBar, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        // List
        listView = ListView(ctx).apply {
            setBackgroundColor(0xFF0A0A0A.toInt())
            divider = android.graphics.drawable.ColorDrawable(0xFF222222.toInt())
            dividerHeight = 1
        }
        root.addView(listView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // Back button — find it from the toolbar we built in onCreateView
        (view as ViewGroup).let { root ->
            val toolbar = root.getChildAt(0) as? LinearLayout
            (toolbar?.getChildAt(0) as? Button)?.setOnClickListener {
                findNavController().popBackStack()
            }
        }
        reload()
        setupListeners()
    }

    private fun reload() {
        entries = QsoStore.load(requireContext())
        selected.clear()
        refreshAdapter()
        tvCount.text = "${entries.size} QSO"
    }

    private fun refreshAdapter() {
        val ctx = requireContext()
        listView.adapter = object : BaseAdapter() {
            override fun getCount() = entries.size
            override fun getItem(pos: Int) = entries[pos]
            override fun getItemId(pos: Int) = pos.toLong()

            override fun getView(pos: Int, cv: View?, parent: ViewGroup): View {
                val e = entries[pos]
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(8, 6, 8, 6)
                    setBackgroundColor(if (selected.contains(pos)) 0xFF1A2A3A.toInt() else 0xFF0A0A0A.toInt())
                }
                val txt = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val d = e.dt
                val dtUtc = if (d.length >= 12)
                    "${d.take(4)}-${d.drop(4).take(2)}-${d.drop(6).take(2)} ${d.drop(8).take(2)}:${d.drop(10).take(2)}Z"
                else d
                val dtLocal = utcToLocal(d)
                val dtStr = if (dtLocal.isNotEmpty()) "$dtUtc  [$dtLocal]" else dtUtc
                val band = QsoStore.freqToBand(e.freqHz)
                val freq = if (e.freqHz > 0) "%.3f".format(e.freqHz / 1_000_000.0) else "---"
                val tags = buildString {
                    if (e.yourPota.isNotEmpty()) append("  DX:[${e.yourPota}]")
                    if (e.yourSota.isNotEmpty()) append("  DX:[${e.yourSota}]")
                    if (e.myPota.isNotEmpty())   append("  MY:[${e.myPota}]")
                    if (e.mySota.isNotEmpty())   append("  MY:[${e.mySota}]")
                    if (e.jcc.isNotEmpty())      append("  JCC:${e.jcc}")
                    if (e.jgc.isNotEmpty())      append("  JGC:${e.jgc}")
                }
                // Row 1: date/time + callsign (most important — large)
                txt.addView(TextView(ctx).apply {
                    text = dtStr
                    textSize = 12f; setTextColor(0xFF80CBC4.toInt())
                    typeface = android.graphics.Typeface.MONOSPACE
                })
                txt.addView(TextView(ctx).apply {
                    text = e.call
                    textSize = 16f; setTextColor(0xFFFFEB3B.toInt())
                    typeface = android.graphics.Typeface.MONOSPACE
                    android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD).also { typeface = it }
                })
                // Row 2: RST / band / mode
                txt.addView(TextView(ctx).apply {
                    text = "S:${e.rstSent}  R:${e.rstRcvd}  $band/${e.mode}  $freq MHz"
                    textSize = 12f; setTextColor(0xFFAAAAAA.toInt())
                    typeface = android.graphics.Typeface.MONOSPACE
                })
                // Row 3: awards/tags
                if (tags.isNotEmpty()) {
                    txt.addView(TextView(ctx).apply {
                        text = tags.trim(); textSize = 11f; setTextColor(0xFF76FF03.toInt())
                    })
                }
                // Row 4: comment
                if (e.comment.isNotEmpty()) {
                    txt.addView(TextView(ctx).apply {
                        text = e.comment; textSize = 11f; setTextColor(0xFF888888.toInt())
                    })
                }
                row.addView(txt)
                val cbk = CheckBox(ctx).apply {
                    isChecked = selected.contains(pos)
                    buttonTintList = android.content.res.ColorStateList.valueOf(0xFF4499FF.toInt())
                    isFocusable = false
                    isClickable = false
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT)
                }
                row.addView(cbk)
                return row
            }
        }
        listView.setOnItemClickListener { _, _, pos, _ ->
            if (selected.contains(pos)) selected.remove(pos) else selected.add(pos)
            refreshAdapter()
        }
        listView.setOnItemLongClickListener { _, _, pos, _ ->
            showEditDialog(pos)
            true
        }
    }

    private fun showEditDialog(pos: Int) {
        val ctx = requireContext()
        val e = entries[pos]
        fun dp(n: Int) = (n * ctx.resources.displayMetrics.density + 0.5f).toInt()

        fun field(hint: String, init: String): EditText = EditText(ctx).apply {
            this.hint = hint; setText(init)
            setHintTextColor(0xFF505050.toInt()); setTextColor(0xFFCCCCCC.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF333333.toInt())
            textSize = 16f; setSingleLine(true); setPadding(dp(8), dp(8), dp(8), dp(8))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.topMargin = dp(6) }
        }
        fun lbl(t: String) = TextView(ctx).apply {
            text = t; textSize = 12f; setTextColor(0xFF777777.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.topMargin = dp(10) }
        }

        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        root.addView(TextView(ctx).apply { text = e.dt; textSize = 11f; setTextColor(0xFF666666.toInt()) })
        root.addView(lbl("DX Callsign"))
        val etCall = field("JA2ABC", e.call).also {
            it.setTextColor(0xFFFFEB3B.toInt())
            it.backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF1A237E.toInt())
            it.filters = arrayOf(android.text.InputFilter { src, _, _, _, _, _ ->
                src.toString().uppercase().filter { c -> c.isLetter() && c.code < 128 || c.isDigit() && c.code < 128 || c == '/' }
            })
        }; root.addView(etCall)
        root.addView(lbl("RST 送信 / 受信"))
        val rstRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val etRstS = field("送信", e.rstSent).also {
            it.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also { lp -> lp.topMargin = dp(6) }
        }; rstRow.addView(etRstS)
        val etRstR = field("受信", e.rstRcvd).also {
            it.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also { lp -> lp.topMargin = dp(6); lp.marginStart = dp(8) }
        }; rstRow.addView(etRstR)
        root.addView(rstRow)
        root.addView(lbl("Your POTA / Your SOTA (相手)"))
        val yourPotaRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val etYourPota = field("JP-XXXX", e.yourPota).also {
            it.setTextColor(0xFF80CBC4.toInt())
            it.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also { lp -> lp.topMargin = dp(6) }
        }; yourPotaRow.addView(etYourPota)
        val etYourSota = field("JA/NN-001", e.yourSota).also {
            it.setTextColor(0xFF80CBC4.toInt())
            it.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also { lp -> lp.topMargin = dp(6); lp.marginStart = dp(8) }
        }; yourPotaRow.addView(etYourSota)
        root.addView(yourPotaRow)
        root.addView(lbl("My POTA / My SOTA (自分)"))
        val myPotaRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val etMyPota = field("JP-XXXX", e.myPota).also {
            it.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also { lp -> lp.topMargin = dp(6) }
        }; myPotaRow.addView(etMyPota)
        val etMySota = field("JA/NN-001", e.mySota).also {
            it.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also { lp -> lp.topMargin = dp(6); lp.marginStart = dp(8) }
        }; myPotaRow.addView(etMySota)
        root.addView(myPotaRow)
        root.addView(lbl("コメント"))
        val etComment = field("", e.comment); root.addView(etComment)

        val dlg = android.app.AlertDialog.Builder(ctx, android.R.style.Theme_Material_Dialog_NoActionBar)
            .setTitle("QSO 修正: ${e.call}")
            .setView(ScrollView(ctx).apply { addView(root); isVerticalScrollBarEnabled = false })
            .setPositiveButton("保存") { _, _ ->
                val updated = e.copy(
                    call     = etCall.text.toString().trim().uppercase().ifEmpty { e.call },
                    rstSent  = etRstS.text.toString().trim().ifEmpty { e.rstSent },
                    rstRcvd  = etRstR.text.toString().trim().ifEmpty { e.rstRcvd },
                    yourPota = etYourPota.text.toString().trim().uppercase(),
                    yourSota = etYourSota.text.toString().trim().uppercase(),
                    myPota   = etMyPota.text.toString().trim().uppercase(),
                    mySota   = etMySota.text.toString().trim().uppercase(),
                    comment  = etComment.text.toString().trim()
                )
                entries[pos] = updated
                QsoStore.save(requireContext(), entries)
                vm.prefs.ft8QsoLog = buildJsonArray(entries)
                refreshAdapter()
                toast("保存しました: ${updated.call}")
            }
            .setNegativeButton("キャンセル", null)
            .create()
        dlg.window?.apply {
            setBackgroundDrawableResource(android.R.color.background_dark)
            setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        dlg.setOnShowListener {
            dlg.window?.setLayout(
                (ctx.resources.displayMetrics.widthPixels * 0.95).toInt(),
                android.view.WindowManager.LayoutParams.WRAP_CONTENT
            )
        }
        dlg.show()
    }

    private fun setupListeners() {
        btnAddLog.setOnClickListener {
            LogQsoDialogFragment.newInstance().show(parentFragmentManager, "log_qso")
        }

        parentFragmentManager.setFragmentResultListener("log_qso_done", viewLifecycleOwner) { _, _ ->
            reload()
        }

        btnSelectAll.setOnClickListener {
            if (selected.size == entries.size) {
                selected.clear()
            } else {
                selected.addAll(entries.indices)
            }
            refreshAdapter()
        }

        btnDeleteSel.setOnClickListener {
            if (selected.isEmpty()) { toast("削除する項目を選択してください"); return@setOnClickListener }
            android.app.AlertDialog.Builder(requireContext())
                .setMessage("選択した ${selected.size} 件を削除しますか?")
                .setPositiveButton("削除") { _, _ ->
                    val keep = entries.filterIndexed { i, _ -> !selected.contains(i) }
                    QsoStore.save(requireContext(), keep)
                    vm.prefs.ft8QsoLog = buildJsonArray(keep)
                    reload()
                }
                .setNegativeButton("キャンセル", null).show()
        }

        btnAdifSel.setOnClickListener {
            if (selected.isEmpty()) { toast("エクスポートする項目を選択してください"); return@setOnClickListener }
            val sel = selected.sorted().map { entries[it] }
            shareAdif(sel)
        }

        btnAdifAll.setOnClickListener {
            if (entries.isEmpty()) { toast("ログが空です"); return@setOnClickListener }
            shareAdif(entries)
        }
    }

    private fun shareAdif(list: List<QsoEntry>) {
        val adif = QsoStore.buildAdif(list)
        val cal  = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        val fname = "qso_%04d%02d%02d.adi".format(
            cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
        val file = File(requireContext().cacheDir, fname)
        file.writeText(adif)
        val uri = FileProvider.getUriForFile(requireContext(), "${requireContext().packageName}.provider", file)
        startActivity(android.content.Intent.createChooser(
            android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                putExtra(android.content.Intent.EXTRA_SUBJECT, fname)
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "Share ADIF"))
    }

    private fun buildJsonArray(list: List<QsoEntry>): String {
        val arr = org.json.JSONArray()
        list.forEach { arr.put(it.toJson()) }
        return arr.toString()
    }

    private fun utcToLocal(dt: String): String {
        if (dt.length < 8) return ""
        return try {
            val sdf = java.text.SimpleDateFormat("yyyyMMddHHmmss", java.util.Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            val date = sdf.parse(dt.padEnd(14, '0')) ?: return ""
            val local = java.text.SimpleDateFormat("MM/dd HH:mm", java.util.Locale.getDefault()).apply {
                timeZone = TimeZone.getDefault()
            }
            local.format(date)
        } catch (_: Exception) { "" }
    }

    private fun toast(msg: String) =
        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()

    override fun onResume() {
        super.onResume()
        reload()
    }
}
