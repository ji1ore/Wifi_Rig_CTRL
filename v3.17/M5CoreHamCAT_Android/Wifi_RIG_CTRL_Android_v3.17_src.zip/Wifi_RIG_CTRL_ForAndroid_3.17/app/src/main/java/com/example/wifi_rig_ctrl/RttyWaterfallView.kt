package com.ji1ore.wifi_rig_ctrl

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/**
 * Scrolling waterfall for the RTTY screen.
 * Displays Goertzel power across SCAN_LO..SCAN_HI Hz with draggable mark/space markers.
 * Call addRow() from the main thread with a DoubleArray from RttyModem.scanPowers().
 * Touch sets mark frequency; space tracks at the current FSK shift.
 */
class RttyWaterfallView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private val loHz = RttyModem.SCAN_LO.toDouble()
    private val hiHz = RttyModem.SCAN_HI.toDouble()
    private val bins = RttyModem.SCAN_BINS

    private var bmp: Bitmap? = null
    private var vw = 0; private var vh = 0

    // Circular buffer head: bitmap row where OLDEST (top of screen) data lives
    private var headRow = 0
    // Reusable row buffer — resized in onSizeChanged
    private var rowBuf = IntArray(0)

    // Dynamic range tracking
    private var noiseEst = 1e-9
    private var peakEst  = 1e-6

    private val dp = context.resources.displayMetrics.density
    private val sp = context.resources.displayMetrics.scaledDensity
    private val linePaint = Paint().apply { isAntiAlias = false; strokeWidth = dp }
    private val txtPaint  = Paint().apply { isAntiAlias = true; textSize = sp * 9f }

    // Reusable Rect/RectF for two-part circular draw
    private val srcRect  = Rect()
    private val dstRectA = RectF()
    private val dstRectB = RectF()

    var markHz  = 2125.0; private set
    var spaceHz = 2295.0; private set

    /** Called when the user drags on the waterfall to re-tune. */
    var onDecodeFreqSelected: ((markHz: Double, spaceHz: Double) -> Unit)? = null

    // ---- data ----

    fun addRow(powers: DoubleArray) {
        val w = vw; val h = vh; val b = bmp ?: return
        if (w <= 0 || h <= 0) return

        val avg = powers.average()
        val mx  = powers.maxOrNull() ?: 0.0
        noiseEst = noiseEst * 0.98 + avg * 0.02
        peakEst  = if (mx > peakEst) peakEst * 0.5 + mx * 0.5 else peakEst * 0.997 + mx * 0.003
        val range = (peakEst - noiseEst).coerceAtLeast(1e-9)

        // Write new row to bitmap at headRow (overwriting oldest data)
        if (rowBuf.size < w) rowBuf = IntArray(w)
        for (x in 0 until w) {
            val bin = (x.toLong() * (bins - 1) / (w - 1)).toInt().coerceIn(0, bins - 1)
            val v = ((powers[bin] - noiseEst) / range).toFloat().coerceIn(0f, 1f)
            rowBuf[x] = toColor(v)
        }
        b.setPixels(rowBuf, 0, w, 0, headRow, w, 1)
        headRow = (headRow + 1) % h
        invalidate()
    }

    fun setMarkers(mark: Double, space: Double) {
        markHz = mark; spaceHz = space; invalidate()
    }

    // ---- rendering ----

    override fun onSizeChanged(w: Int, h: Int, oldW: Int, oldH: Int) {
        super.onSizeChanged(w, h, oldW, oldH)
        vw = w; vh = h
        bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        rowBuf = IntArray(w)
        headRow = 0
    }

    override fun onDraw(canvas: Canvas) {
        val b = bmp ?: return
        val w = vw; val h = vh

        // Circular buffer draw: headRow = oldest row (top of screen)
        if (headRow == 0) {
            canvas.drawBitmap(b, 0f, 0f, null)
        } else {
            val topH = h - headRow
            srcRect.set(0, headRow, w, h)
            dstRectA.set(0f, 0f, w.toFloat(), topH.toFloat())
            canvas.drawBitmap(b, srcRect, dstRectA, null)

            srcRect.set(0, 0, w, headRow)
            dstRectB.set(0f, topH.toFloat(), w.toFloat(), h.toFloat())
            canvas.drawBitmap(b, srcRect, dstRectB, null)
        }

        drawMarker(canvas, markHz,  0xFFFFDD00.toInt(), "M")
        drawMarker(canvas, spaceHz, 0xFF44FFFF.toInt(), "S")
    }

    private fun drawMarker(canvas: Canvas, hz: Double, color: Int, label: String) {
        if (vw <= 0) return
        val x = ((hz - loHz) / (hiHz - loHz) * vw).toFloat()
        if (x < 0f || x > vw) return
        linePaint.color = color
        canvas.drawLine(x, 0f, x, vh.toFloat(), linePaint)
        txtPaint.color = color
        val lx = if (x + sp * 18 < vw) x + dp * 2 else x - sp * 14
        canvas.drawText(label, lx, sp * 10 + dp * 2, txtPaint)
    }

    // ---- touch ----

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_DOWN && e.action != MotionEvent.ACTION_MOVE) return false
        val shift = spaceHz - markHz
        val hz = loHz + e.x / vw * (hiHz - loHz)
        markHz  = hz.coerceIn(loHz, hiHz - shift)
        spaceHz = markHz + shift
        onDecodeFreqSelected?.invoke(markHz, spaceHz)
        invalidate()
        return true
    }

    // ---- color map: black→dark-blue→cyan→green→yellow ----

    private fun toColor(v: Float): Int {
        val c = v.coerceIn(0f, 1f)
        return when {
            c < 0.25f -> Color.rgb(0, 0, (c / 0.25f * 180).toInt())
            c < 0.50f -> { val t = (c - 0.25f) / 0.25f; Color.rgb(0, (t * 220).toInt(), (180 + t * 75).toInt()) }
            c < 0.75f -> { val t = (c - 0.50f) / 0.25f; Color.rgb((t * 100).toInt(), 220 + (t * 35).toInt(), (255 - t * 255).toInt()) }
            else       -> { val t = (c - 0.75f) / 0.25f; Color.rgb(100 + (t * 155).toInt(), 255, 0) }
        }
    }
}
