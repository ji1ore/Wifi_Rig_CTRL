package com.ji1ore.wifi_rig_ctrl

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.ji1ore.wifi_rig_ctrl.viewmodel.MainViewModel

/**
 * SP2ALERT(POTA/SOTAスポット通知アプリ)からの周波数・モード連携を受信する。
 * Intent action: com.ji1ore.ACTION_SET_FREQ_MODE
 * Extras:
 *   "freq_hz" : Long   — 周波数(Hz)
 *   "mode"    : String — モード文字列(POTA/SOTA APIの値: SSB/CW/FT8等)
 */
class Sp2alertReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION = "com.ji1ore.ACTION_SET_FREQ_MODE"
        const val EXTRA_FREQ_HZ  = "freq_hz"
        const val EXTRA_MODE     = "mode"
        const val EXTRA_CALLSIGN = "callsign"   // アクティベーター/スポットのコールサイン
        const val EXTRA_POTA     = "pota_ref"   // POTA reference (e.g. "JA-0001")
        const val EXTRA_SOTA     = "sota_ref"   // SOTA summit code

        // POTAスポットAPIのモード → (無線機モード, フィルター幅Hz)
        // SSBは周波数で USB(>=10MHz) / LSB(<10MHz) を自動判定
        fun mapMode(spotMode: String, freqHz: Long): Pair<String, Int> {
            return when (spotMode.uppercase().trim()) {
                "CW", "CW-R"                                         -> Pair("CW",  500)
                "FM", "C4FM", "D-STAR", "DSTAR", "DMR"              -> Pair("FM",  15000)
                "AM"                                                  -> Pair("AM",  6000)
                "FT8", "FT4", "JS8", "RTTY", "PSK31",
                "PSKR", "DIGI", "MSK144"                             -> Pair(usbOrLsb(freqHz), 3000)
                "USB"                                                 -> Pair("USB", 3000)
                "LSB"                                                 -> Pair("LSB", 3000)
                "SSB"                                                 -> Pair("SSB", 3000)
                else                                                  -> Pair(usbOrLsb(freqHz), 3000)
            }
        }

        private fun usbOrLsb(freqHz: Long) = if (freqHz >= 10_000_000L) "USB" else "LSB"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION) return

        val freqHz  = intent.getLongExtra(EXTRA_FREQ_HZ, 0L)
        val spotMode = intent.getStringExtra(EXTRA_MODE) ?: return
        // アマチュア無線帯域外 or 不正に長いモード文字列は無視
        if (freqHz < 1_000_000L || freqHz > 10_000_000_000L) return
        if (spotMode.length > 20) return

        val vm = MainViewModel.instance ?: return

        // プリフィル情報 (コールサイン / POTA / SOTA) を ViewModel に保存
        // → Log QSO ダイアログの DX コールサイン、CW TX の DX 欄に反映される。リグ未接続でも保持する。
        vm.pendingLogCallsign = intent.getStringExtra(EXTRA_CALLSIGN) ?: ""
        vm.pendingLogPota     = intent.getStringExtra(EXTRA_POTA)     ?: ""
        vm.pendingLogSota     = intent.getStringExtra(EXTRA_SOTA)     ?: ""

        if (vm.isConnectedToRig.value != true) return

        val (rawMode, width) = mapMode(spotMode, freqHz)
        val rigMode = vm.resolveMode(rawMode, freqHz)
        vm.recallFreqModeSequenced(freqHz, rigMode, width)

        val upper = spotMode.uppercase().trim()
        if (upper == "FT8" || upper == "FT4") {
            vm.navigateToFt8.postValue(upper == "FT4")
        }
    }
}
