package com.ji1ore.wifi_rig_ctrl

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.jcraft.jsch.ChannelExec
import com.jcraft.jsch.ChannelSftp
import com.jcraft.jsch.JSch
import com.jcraft.jsch.UserInfo
import com.ji1ore.wifi_rig_ctrl.databinding.FragmentSshSetupBinding
import com.ji1ore.wifi_rig_ctrl.viewmodel.MainViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.util.Properties

class SshSetupFragment : Fragment() {

    private var _binding: FragmentSshSetupBinding? = null
    private val binding get() = _binding!!
    private val vm: MainViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSshSetupBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val savedHost = vm.hostName.value ?: ""
        if (savedHost.isNotEmpty()) binding.editSshHost.setText(savedHost)

        binding.btnSshBack.setOnClickListener { findNavController().navigateUp() }

        binding.btnRunSetup.setOnClickListener {
            val host = binding.editSshHost.text.toString().trim()
            val user = binding.editSshUser.text.toString().trim().ifEmpty { "pi" }
            val password = binding.editSshPassword.text.toString()

            if (host.isEmpty()) {
                binding.tvSshStatus.text = "Pi IP / ホスト名を入力してください"
                return@setOnClickListener
            }

            binding.btnRunSetup.isEnabled = false
            binding.tvSshStatus.text = "$host に接続中..."
            binding.tvSshLog.text = ""
            // Keep screen on during setup (can take 5-10 min on Pi Zero)
            activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

            lifecycleScope.launch {
                runSshSetup(host, user, password)
                binding.btnRunSetup.isEnabled = true
                activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }

    private suspend fun runSshSetup(host: String, user: String, password: String) {
        // assets からアップロードするファイル一覧（GitHub 依存を排除し常に最新版を使用）
        val assetNames = listOf("api.py", "create_api.sh", "cw_bridge.py",
                                "setup_fastapi_radio.sh", "set_api_key.sh")
        val assetFiles: List<Pair<String, ByteArray>> = assetNames.map { name ->
            name to requireContext().assets.open(name).readBytes()
        }
        // sudo -S reads password from stdin; we feed it via channel.setInputStream()
        val command = "chmod +x ~/create_api.sh ~/setup_fastapi_radio.sh ~/set_api_key.sh" +
            " && sudo -S bash ~/setup_fastapi_radio.sh 2>&1"

        withContext(Dispatchers.IO) {
            Log.d("SshSetup", "Starting SSH setup: host=$host user=$user")

            // Resolve hostname — for .local, acquire MulticastLock first so Android's
            // WiFi driver doesn't filter the mDNS multicast packets
            val resolvedHost: String
            try {
                resolvedHost = resolveHostWithTimeout(host)
                Log.d("SshSetup", "Resolved $host → $resolvedHost")
            } catch (e: Exception) {
                Log.e("SshSetup", "Hostname resolution failed: host=$host", e)
                val msg = e.message ?: "ホスト解決失敗"
                withContext(Dispatchers.Main) {
                    binding.tvSshStatus.text = "Error: $msg"
                    appendLog("ERROR: $msg")
                }
                return@withContext
            }

            val jsch = JSch()
            // Log JSch activity to logcat
            JSch.setLogger(object : com.jcraft.jsch.Logger {
                override fun isEnabled(level: Int) = true
                override fun log(level: Int, message: String) {
                    val tag = "JSch"
                    when (level) {
                        com.jcraft.jsch.Logger.DEBUG -> Log.d(tag, message)
                        com.jcraft.jsch.Logger.INFO  -> Log.i(tag, message)
                        com.jcraft.jsch.Logger.WARN  -> Log.w(tag, message)
                        else                          -> Log.e(tag, message)
                    }
                }
            })

            var session: com.jcraft.jsch.Session? = null
            var channel: ChannelExec? = null
            try {
                Log.d("SshSetup", "Creating session: $user@$resolvedHost:22")
                session = jsch.getSession(user, resolvedHost, 22)
                session.setPassword(password)

                // Accept any host key (private LAN setup)
                val config = Properties()
                config["StrictHostKeyChecking"] = "no"
                config["PreferredAuthentications"] = "password,keyboard-interactive"
                config["MaxAuthTries"] = "1"
                session.setConfig(config)

                // Provide password for keyboard-interactive prompts (PAM)
                session.userInfo = object : UserInfo {
                    override fun getPassword() = password
                    override fun getPassphrase(): String? = null
                    override fun promptPassword(msg: String): Boolean {
                        Log.d("SshSetup", "UserInfo.promptPassword: $msg")
                        return true
                    }
                    override fun promptPassphrase(msg: String): Boolean {
                        Log.d("SshSetup", "UserInfo.promptPassphrase: $msg")
                        return false
                    }
                    override fun promptYesNo(msg: String): Boolean {
                        Log.d("SshSetup", "UserInfo.promptYesNo: $msg")
                        return true
                    }
                    override fun showMessage(msg: String) {
                        Log.d("SshSetup", "UserInfo.showMessage: $msg")
                    }
                }

                Log.d("SshSetup", "Calling session.connect(30000)")
                session.connect(30_000)
                Log.d("SshSetup", "Session connected successfully")

                withContext(Dispatchers.Main) {
                    binding.tvSshStatus.text = "接続完了 — ファイル転送中..."
                }

                // SFTP でアプリ assets のファイルを Pi ホームディレクトリへアップロード
                val sftp = session.openChannel("sftp") as ChannelSftp
                sftp.connect(10_000)
                try {
                    for ((name, bytes) in assetFiles) {
                        sftp.put(java.io.ByteArrayInputStream(bytes), name)
                        val kb = bytes.size / 1024
                        withContext(Dispatchers.Main) { appendLog("転送: $name (${kb}KB)") }
                    }
                } finally {
                    sftp.disconnect()
                }
                withContext(Dispatchers.Main) {
                    appendLog("── ファイル転送完了 ──")
                    binding.tvSshStatus.text = "転送完了 — セットアップ実行中..."
                }

                channel = session.openChannel("exec") as ChannelExec
                channel.setCommand(command)
                // Feed password to sudo -S via the channel's stdin
                channel.setInputStream(java.io.ByteArrayInputStream("$password\n".toByteArray()))
                val stdout = channel.inputStream
                channel.connect()
                Log.d("SshSetup", "Exec channel connected, reading output...")

                val reader = stdout.bufferedReader()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    val l = line!!
                    Log.d("SshSetup", "stdout: $l")
                    withContext(Dispatchers.Main) { appendLog(l) }
                }

                channel.disconnect()
                val exitCode = channel.exitStatus
                Log.d("SshSetup", "Command finished, exit=$exitCode")

                withContext(Dispatchers.Main) {
                    if (exitCode == 0) {
                        binding.tvSshStatus.setTextColor(0xFF00C853.toInt())
                        binding.tvSshStatus.text = "✓ セットアップ完了！mfsk-decode ビルドを開始します..."
                        appendLog("── セットアップ完了 (exit 0) ──")
                    } else {
                        binding.tvSshStatus.text = "⚠ セットアップ失敗 (exit $exitCode)"
                        appendLog("── 終了コード: $exitCode ──")
                    }
                }

                if (exitCode == 0) {
                    withContext(Dispatchers.Main) {
                        appendLog("── セットアップ完了 ──")
                        appendLog("")
                        appendLog("【次の手順】")
                        appendLog("  1. UPDATE 画面を開く")
                        appendLog("  2. 「Update Pi」を実行する")
                        appendLog("     → mfsk-decode ビルドも自動で開始されます（10〜20分）")
                        binding.tvSshStatus.text = "✓ SETUP 完了 — 次に UPDATE 画面で「Update Pi」を実行してください"
                        binding.tvSshStatus.setTextColor(0xFF00C853.toInt())
                    }
                }

            } catch (e: Exception) {
                Log.e("SshSetup", "SSH exception: ${e.javaClass.name}: ${e.message}", e)
                withContext(Dispatchers.Main) {
                    val detail = "${e.javaClass.simpleName}: ${e.message ?: "(no message)"}" +
                        (e.cause?.let { "\nCause: ${it.javaClass.simpleName}: ${it.message}" } ?: "")
                    binding.tvSshStatus.text = "Error: $detail"
                    appendLog("ERROR: $detail")
                }
            } finally {
                try { channel?.disconnect() } catch (_: Exception) {}
                try { session?.disconnect() } catch (_: Exception) {}
            }
        }
    }

    private fun appendLog(line: String) {
        val current = binding.tvSshLog.text
        binding.tvSshLog.text = if (current.isEmpty()) line else "$current\n$line"
        binding.scrollSshLog.post { binding.scrollSshLog.fullScroll(View.FOCUS_DOWN) }
    }

    // Resolve hostname with 10s timeout.
    // For .local hostnames, acquires a MulticastLock so Android's WiFi driver
    // passes mDNS multicast packets through to InetAddress.getByName().
    private fun resolveHostWithTimeout(host: String): String {
        val wifiMgr = requireContext().applicationContext
            .getSystemService(Context.WIFI_SERVICE) as WifiManager
        val lock = if (host.endsWith(".local")) {
            wifiMgr.createMulticastLock("ssh_mdns").also {
                it.setReferenceCounted(false)
                it.acquire()
            }
        } else null

        try {
            val future = java.util.concurrent.FutureTask {
                val addrs = InetAddress.getAllByName(host)
                // Prefer IPv4 — Android sometimes resolves .local to IPv6 which
                // times out even if the Pi doesn't have reachable IPv6 SSH
                val ipv4 = addrs.filterIsInstance<java.net.Inet4Address>().firstOrNull()
                (ipv4 ?: addrs.firstOrNull())?.hostAddress ?: host
            }
            Thread(future).also { it.isDaemon = true; it.start() }
            return try {
                future.get(10, java.util.concurrent.TimeUnit.SECONDS)
            } catch (e: java.util.concurrent.TimeoutException) {
                future.cancel(true)
                throw Exception(
                    if (host.endsWith(".local"))
                        "「$host」が見つかりません（10秒タイムアウト）\nIPアドレスを直接入力してください"
                    else
                        "「$host」への接続がタイムアウトしました"
                )
            }
        } finally {
            lock?.release()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
