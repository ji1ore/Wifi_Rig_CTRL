package com.ji1ore.wifi_rig_ctrl

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.ji1ore.wifi_rig_ctrl.databinding.FragmentWireguardSetupBinding
import com.ji1ore.wifi_rig_ctrl.viewmodel.MainViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class WireGuardSetupFragment : Fragment() {

    private var _binding: FragmentWireguardSetupBinding? = null
    private val binding get() = _binding!!
    private val vm: MainViewModel by activityViewModels()

    private var pendingConfText: String? = null

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) launchTokenScanner()
        else Toast.makeText(requireContext(), "カメラの許可が必要です", Toast.LENGTH_SHORT).show()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentWireguardSetupBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnWgBack.setOnClickListener { findNavController().navigateUp() }

        // Connect 画面で入力済みの Pi IP を初期値として表示
        val savedHost = vm.hostName.value ?: ""
        if (savedHost.isNotEmpty()) {
            binding.editWgPiHost.setText(savedHost)
            binding.editWgStaticIp.setText(savedHost)
        }

        // API キー: 既存キーがあれば表示、なければ UUID 自動生成
        val existingKey = vm.apiKey.value ?: ""
        binding.editWgApiKey.setText(
            if (existingKey.isNotEmpty()) existingKey
            else java.util.UUID.randomUUID().toString()
        )

        // IP 固定スイッチ → 固定 IP 入力欄の表示/非表示
        binding.switchWgStaticIp.setOnCheckedChangeListener { _, isChecked ->
            binding.rowStaticIp.visibility = if (isChecked) View.VISIBLE else View.GONE
        }

        binding.btnScanToken.setOnClickListener {
            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
                launchTokenScanner()
            } else {
                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }

        binding.btnWgRun.setOnClickListener {
            val piHost    = binding.editWgPiHost.text.toString().trim()
            val domain    = binding.editWgDomain.text.toString().trim().lowercase()
            val token     = binding.editWgToken.text.toString().trim()
            val apiKeyNew = binding.editWgApiKey.text.toString().trim()
            if (piHost.isEmpty() || domain.isEmpty() || token.isEmpty()) {
                binding.tvWgStatus.text = "Pi の IP・DNS ドメイン・トークンをすべて入力してください"
                return@setOnClickListener
            }
            if (apiKeyNew.isEmpty()) {
                binding.tvWgStatus.text = "API キーを入力してください（必須）"
                return@setOnClickListener
            }
            val staticIp = if (binding.switchWgStaticIp.isChecked)
                binding.editWgStaticIp.text.toString().trim() else ""
            val sudoPass = binding.editWgSudoPass.text.toString()
            startSetup(piHost, domain, token, staticIp, sudoPass, apiKeyNew)
        }

        binding.btnWgImport.setOnClickListener {
            pendingConfText?.let { importToWireGuard(it) }
        }
    }

    private fun launchTokenScanner() {
        val dialog = TokenScanDialogFragment()
        dialog.onTokenScanned = { token ->
            binding.editWgToken.setText(token)
            binding.tvWgStatus.text = "トークン読み取り完了"
        }
        dialog.show(parentFragmentManager, "token_scan")
    }

    private fun startSetup(piHost: String, domain: String, token: String, staticIp: String, sudoPass: String = "", newApiKey: String) {
        binding.btnWgRun.isEnabled = false
        binding.btnWgImport.visibility = View.GONE
        binding.tvWgLog.text = ""
        binding.tvWgStatus.text = "api.py を Pi に送信中..."
        pendingConfText = null
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val port   = vm.apiPort.value ?: 8210
        val apiKey = vm.apiKey.value ?: ""

        lifecycleScope.launch {
            // WireGuard Setup 前に api.py を強制更新（404 防止）
            val updateOk = pushApiPy(piHost, port, apiKey)
            if (updateOk) {
                appendLog("[準備] api.py 送信完了 — 5秒待機...")
                kotlinx.coroutines.delay(5_000)
            } else {
                appendLog("[警告] api.py 送信失敗 — そのまま続行")
            }
            binding.tvWgStatus.text = "WireGuard セットアップ中..."
            runSseSetup(piHost, port, apiKey, domain, token, staticIp, sudoPass)

            // API キーを Pi に設定してアプリに保存
            binding.tvWgStatus.text = "API キーを Pi に設定中..."
            val keyOk = setApiKeyOnPi(piHost, port, apiKey, newApiKey)
            withContext(Dispatchers.Main) {
                if (keyOk) {
                    vm.apiKey.value = newApiKey
                    vm.prefs.apiKey = newApiKey
                    vm.api.apiKey = newApiKey
                    appendLog("[API Key] Pi への設定完了・アプリに保存済み")
                    binding.tvWgStatus.text = if (pendingConfText != null)
                        "完了！WireGuard アプリにインポートしてください"
                    else "セットアップ完了"
                } else {
                    appendLog("⚠ API キーの Pi 設定に失敗。Connect 画面で手動設定してください。")
                    binding.tvWgStatus.text = "WireGuard 完了（API Key 設定失敗）"
                }
            }

            binding.btnWgRun.isEnabled = true
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private suspend fun pushApiPy(host: String, port: Int, apiKey: String): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val bytes = requireContext().assets.open("api.py").readBytes()
                val url = URL("http://$host:$port/admin/update")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    setRequestProperty("Content-Type", "application/octet-stream")
                    if (apiKey.isNotEmpty()) setRequestProperty("X-API-Key", apiKey)
                    connectTimeout = 10_000
                    readTimeout = 30_000
                    doOutput = true
                    outputStream.write(bytes)
                }
                val ok = conn.responseCode == 200
                conn.disconnect()
                ok
            } catch (_: Exception) { false }
        }

    private suspend fun setApiKeyOnPi(host: String, port: Int, currentApiKey: String, newApiKey: String): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val url = URL("http://$host:$port/admin/set_api_key")
                val body = JSONObject().put("new_key", newApiKey).toString().toByteArray(Charsets.UTF_8)
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    setRequestProperty("Content-Type", "application/json")
                    if (currentApiKey.isNotEmpty()) setRequestProperty("X-API-Key", currentApiKey)
                    connectTimeout = 10_000
                    readTimeout = 35_000
                    doOutput = true
                    outputStream.write(body)
                }
                val ok = conn.responseCode == 200
                conn.disconnect()
                ok
            } catch (_: Exception) { false }
        }

    private suspend fun runSseSetup(
        host: String, port: Int, apiKey: String,
        domain: String, token: String, staticIp: String,
        sudoPass: String = ""
    ) = withContext(Dispatchers.IO) {
        try {
            val url = URL("http://$host:$port/wireguard/setup")
            val body = JSONObject().apply {
                put("ddns_domain", domain)
                put("ddns_token", token)
                put("static_ip", staticIp)
                put("sudo_pass", sudoPass)
            }.toString().toByteArray(Charsets.UTF_8)

            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "text/event-stream")
                if (apiKey.isNotEmpty()) setRequestProperty("X-API-Key", apiKey)
                connectTimeout = 10_000
                readTimeout = 600_000
                doOutput = true
                outputStream.write(body)
            }

            if (conn.responseCode != 200) {
                val raw = conn.errorStream?.bufferedReader()?.readText() ?: ""
                val msg = if (raw.isNotEmpty()) {
                    try { JSONObject(raw).optString("detail", raw) } catch (_: Exception) { raw }
                } else "HTTP ${conn.responseCode}"
                withContext(Dispatchers.Main) {
                    appendLog("ERROR: $msg")
                    binding.tvWgStatus.text = "エラー: $msg"
                }
                return@withContext
            }

            val reader = BufferedReader(InputStreamReader(conn.inputStream))
            var dataLine = ""
            reader.forEachLine { line ->
                when {
                    line.startsWith("data: ") -> dataLine = line.removePrefix("data: ")
                    line.isEmpty() && dataLine.isNotEmpty() -> {
                        handleEvent(dataLine)
                        dataLine = ""
                    }
                }
            }
            conn.disconnect()

        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                appendLog("接続エラー: ${e.message}")
                binding.tvWgStatus.text = "エラー: ${e.message}"
            }
        }
    }

    private fun handleEvent(data: String) {
        try {
            val json = JSONObject(data)
            when (json.optString("type")) {
                "log" -> {
                    val msg = json.optString("msg", "")
                    lifecycleScope.launch(Dispatchers.Main) { appendLog(msg) }
                }
                "info" -> {
                    val piIp = json.optString("pi_ip", "")
                    if (piIp.isNotEmpty()) {
                        lifecycleScope.launch(Dispatchers.Main) {
                            binding.tvWgStatus.text = "Pi IP: $piIp — 設定中..."
                        }
                    }
                }
                "config" -> {
                    val confText = json.optString("text", "")
                    val piIp    = json.optString("pi_ip", "")
                    if (confText.isNotEmpty()) {
                        pendingConfText = confText
                        lifecycleScope.launch(Dispatchers.Main) {
                            appendLog("=== クライアント設定ファイル生成完了 ===")
                            if (piIp.isNotEmpty()) appendLog("Pi IP: $piIp")
                            binding.btnWgImport.visibility = View.VISIBLE
                        }
                    }
                }
                "error" -> {
                    val msg = json.optString("msg", "Unknown error")
                    lifecycleScope.launch(Dispatchers.Main) {
                        appendLog("ERROR: $msg")
                        binding.tvWgStatus.text = "エラー: $msg"
                    }
                }
            }
        } catch (_: Exception) {
            lifecycleScope.launch(Dispatchers.Main) { appendLog(data) }
        }
    }

    private fun appendLog(msg: String) {
        val current = binding.tvWgLog.text.toString()
        val combined = if (current.isEmpty()) msg else "$current\n$msg"
        val lines = combined.lines()
        binding.tvWgLog.text = if (lines.size > 80) lines.takeLast(80).joinToString("\n") else combined
        binding.scrollWgLog.post {
            binding.scrollWgLog.scrollTo(0, binding.scrollWgLog.getChildAt(0).height)
        }
    }

    private fun importToWireGuard(confText: String) {
        try {
            val confFile = File(requireContext().cacheDir, "wg_android.conf")
            confFile.writeText(confText)

            val uri = FileProvider.getUriForFile(
                requireContext(),
                "${requireContext().packageName}.provider",
                confFile
            )

            // ACTION_SEND でシェアシートを表示 — WireGuard が受け取れる最も互換性の高い方法
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/x-wireguard-config"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(sendIntent, "WireGuard でインポート"))
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "インポートエラー: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
