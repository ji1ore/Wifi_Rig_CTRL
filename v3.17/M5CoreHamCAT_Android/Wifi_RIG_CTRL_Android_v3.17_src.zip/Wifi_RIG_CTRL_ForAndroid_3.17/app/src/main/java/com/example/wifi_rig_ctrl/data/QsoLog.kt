package com.ji1ore.wifi_rig_ctrl.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.TimeZone

data class QsoEntry(
    val dt: String,          // yyyyMMddHHmmss UTC
    val call: String,        // DX callsign
    val freqHz: Long,
    val mode: String,
    val rstSent: String,
    val rstRcvd: String,
    val dxGrid: String,
    val myCall: String,
    val myGrid: String,
    val yourPota: String = "",  // DX station's POTA reference (POTA_REF in ADIF)
    val yourSota: String = "",  // DX station's SOTA summit code (SOTA_REF in ADIF)
    val myPota: String = "",    // My own POTA reference (MY_POTA_REF in ADIF)
    val mySota: String = "",    // My own SOTA summit code (MY_SOTA_REF in ADIF)
    val jcc: String = "",
    val jgc: String = "",
    val comment: String = "",
    val lat: Double = 0.0,
    val lon: Double = 0.0
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("dt", dt); put("call", call); put("freq", freqHz); put("mode", mode)
        put("rstS", rstSent); put("rstR", rstRcvd); put("grid", dxGrid)
        put("myCall", myCall); put("myGrid", myGrid)
        if (yourPota.isNotEmpty()) put("pota",   yourPota)
        if (yourSota.isNotEmpty()) put("sota",   yourSota)
        if (myPota.isNotEmpty())   put("myPota", myPota)
        if (mySota.isNotEmpty())   put("mySota", mySota)
        if (jcc.isNotEmpty())      put("jcc",    jcc)
        if (jgc.isNotEmpty())      put("jgc",    jgc)
        if (comment.isNotEmpty())  put("comment",comment)
        if (lat != 0.0)            put("lat",    lat)
        if (lon != 0.0)            put("lon",    lon)
    }

    companion object {
        fun fromJson(o: JSONObject) = QsoEntry(
            dt       = o.optString("dt"),
            call     = o.optString("call"),
            freqHz   = o.optLong("freq"),
            mode     = o.optString("mode", "FT8"),
            rstSent  = o.optString("rstS"),
            rstRcvd  = o.optString("rstR"),
            dxGrid   = o.optString("grid"),
            myCall   = o.optString("myCall"),
            myGrid   = o.optString("myGrid"),
            yourPota = o.optString("pota"),
            yourSota = o.optString("sota"),
            myPota   = o.optString("myPota"),
            mySota   = o.optString("mySota"),
            jcc      = o.optString("jcc"),
            jgc      = o.optString("jgc"),
            comment  = o.optString("comment"),
            lat      = o.optDouble("lat", 0.0),
            lon      = o.optDouble("lon", 0.0)
        )

        fun utcNow(): String {
            val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
            return "%04d%02d%02d%02d%02d%02d".format(
                cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1,
                cal.get(Calendar.DAY_OF_MONTH), cal.get(Calendar.HOUR_OF_DAY),
                cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND))
        }
    }
}

object QsoStore {
    private const val PREFS_KEY = "ft8QsoLog"

    fun load(context: Context): MutableList<QsoEntry> {
        val prefs = context.getSharedPreferences("wifi_rig_ctrl", Context.MODE_PRIVATE)
        return parseJson(prefs.getString(PREFS_KEY, "[]") ?: "[]")
    }

    fun save(context: Context, entries: List<QsoEntry>) {
        val arr = JSONArray()
        entries.forEach { arr.put(it.toJson()) }
        context.getSharedPreferences("wifi_rig_ctrl", Context.MODE_PRIVATE)
            .edit().putString(PREFS_KEY, arr.toString()).apply()
    }

    fun append(context: Context, entry: QsoEntry) {
        val list = load(context)
        list.add(entry)
        save(context, list)
    }

    fun clear(context: Context) {
        context.getSharedPreferences("wifi_rig_ctrl", Context.MODE_PRIVATE)
            .edit().putString(PREFS_KEY, "[]").apply()
    }

    private fun parseJson(json: String): MutableList<QsoEntry> = try {
        val arr = JSONArray(json)
        (0 until arr.length()).map { QsoEntry.fromJson(arr.getJSONObject(it)) }.toMutableList()
    } catch (_: Exception) { mutableListOf() }

    fun buildAdif(entries: List<QsoEntry>): String {
        fun f(tag: String, v: String) = if (v.isNotEmpty()) "<$tag:${v.length}>$v " else ""
        val sb = StringBuilder("ADIF Export from Wifi_RIG_CTRL\n<EOH>\n\n")
        entries.forEach { e ->
            val freq = if (e.freqHz > 0) "%.4f".format(e.freqHz / 1_000_000.0) else ""
            sb.append(f("CALL", e.call))
              .append(f("MODE", e.mode))
              .append(f("BAND", freqToBand(e.freqHz)))
              .append(f("FREQ", freq))
              .append(f("QSO_DATE", e.dt.take(8)))
              .append(f("TIME_ON", e.dt.drop(8).take(6)))
              .append(f("RST_SENT", e.rstSent))
              .append(f("RST_RCVD", e.rstRcvd))
              .append(f("GRIDSQUARE", e.dxGrid))
              .append(f("OPERATOR", e.myCall))
              .append(f("MY_GRIDSQUARE", e.myGrid))
              .append(f("MY_LAT", if (e.lat != 0.0) "%.6f".format(e.lat) else ""))
              .append(f("MY_LON", if (e.lon != 0.0) "%.6f".format(e.lon) else ""))
              .append(f("POTA_REF", e.yourPota))
              .append(f("SOTA_REF", e.yourSota))
              .append(f("MY_POTA_REF", e.myPota))
              .append(f("MY_SOTA_REF", e.mySota))
              .append(f("COMMENT", e.comment))
              .append("<EOR>\n")
        }
        return sb.toString()
    }

    fun freqToBand(hz: Long) = when {
        hz in 1_800_000..2_000_000     -> "160M"; hz in 3_500_000..4_000_000   -> "80M"
        hz in 7_000_000..7_300_000     -> "40M";  hz in 10_100_000..10_150_000 -> "30M"
        hz in 14_000_000..14_350_000   -> "20M";  hz in 18_068_000..18_168_000 -> "17M"
        hz in 21_000_000..21_450_000   -> "15M";  hz in 24_890_000..24_990_000 -> "12M"
        hz in 28_000_000..29_700_000   -> "10M";  hz in 50_000_000..54_000_000 -> "6M"
        hz in 144_000_000..148_000_000 -> "2M";   hz in 420_000_000..450_000_000 -> "70CM"
        else -> ""
    }
}
