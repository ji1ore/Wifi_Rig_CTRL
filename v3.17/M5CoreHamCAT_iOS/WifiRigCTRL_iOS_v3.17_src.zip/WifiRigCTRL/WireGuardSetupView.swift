import SwiftUI

struct WireGuardSetupView: View {
    @Bindable var vm: MainViewModel

    @State private var piHost: String = ""
    @State private var domain: String = ""
    @State private var token: String = ""
    @State private var staticIp: String = ""
    @State private var useStaticIp: Bool = true
    @State private var newApiKey: String = ""
    @State private var statusText: String = "ドメインとトークンを入力してください（SSH セットアップ完了後に実行）"
    @State private var statusColor: Color = .secondary
    @State private var logLines: [String] = []
    @State private var isRunning: Bool = false
    @State private var pendingConf: String? = nil
    @State private var showTokenScanner: Bool = false

    var body: some View {
        VStack(spacing: 0) {
            Form {
                Section(header: Label("Pi 接続先", systemImage: "network").foregroundStyle(.indigo)) {
                    LabeledContent("Pi IP") {
                        TextField("192.168.1.100", text: $piHost)
                            .multilineTextAlignment(.trailing)
                            .keyboardType(.numbersAndPunctuation)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                    }
                    Toggle("固定 IP を設定する", isOn: $useStaticIp)
                    if useStaticIp {
                        LabeledContent("固定 IP") {
                            TextField("192.168.1.60", text: $staticIp)
                                .multilineTextAlignment(.trailing)
                                .keyboardType(.numbersAndPunctuation)
                                .autocapitalization(.none)
                                .disableAutocorrection(true)
                        }
                    }
                }

                Section(header: Label("DuckDNS", systemImage: "globe").foregroundStyle(.teal)) {
                    LabeledContent("ドメイン") {
                        TextField("myhome", text: $domain)
                            .multilineTextAlignment(.trailing)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                    }
                    LabeledContent("トークン") {
                        HStack(spacing: 6) {
                            TextField("xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx", text: $token)
                                .multilineTextAlignment(.trailing)
                                .autocapitalization(.none)
                                .disableAutocorrection(true)
                            Button {
                                showTokenScanner = true
                            } label: {
                                Image(systemName: "camera.viewfinder")
                                    .foregroundStyle(.teal)
                            }
                            .buttonStyle(.borderless)
                        }
                    }
                }

                Section(header: Label("API キー（必須）", systemImage: "key.fill").foregroundStyle(.yellow)) {
                    LabeledContent("API キー") {
                        TextField("自動生成済み", text: $newApiKey)
                            .multilineTextAlignment(.trailing)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                            .foregroundStyle(.yellow)
                    }
                    Text("WireGuard セットアップ時に Pi へ設定され、アプリに自動保存されます。Connect 画面の「API Key」と一致します。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section(header: Label("前提条件", systemImage: "checkmark.shield").foregroundStyle(.orange)) {
                    Text("SSH セットアップ（SETUP タブ）を先に完了してください。sudoers の NOPASSWD が自動設定されます。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section {
                    Button {
                        Task { await runSetup() }
                    } label: {
                        HStack {
                            if isRunning { ProgressView().padding(.trailing, 4) }
                            Text(isRunning ? "セットアップ中..." : "WireGuard セットアップ開始")
                                .frame(maxWidth: .infinity)
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.blue)
                    .disabled(isRunning || piHost.isEmpty || domain.isEmpty || token.isEmpty || newApiKey.isEmpty)
                }

                if let conf = pendingConf {
                    Section {
                        ShareLink(
                            item: conf,
                            preview: SharePreview(
                                "wg_android.conf",
                                icon: Image(systemName: "doc.fill")
                            )
                        ) {
                            Label("WireGuard アプリにインポート", systemImage: "square.and.arrow.up")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(.green)
                    }
                }
            }
            .frame(maxHeight: 520)

            Text(statusText)
                .font(.callout)
                .foregroundStyle(statusColor)
                .padding(.horizontal)
                .padding(.vertical, 4)

            ScrollViewReader { proxy in
                ScrollView {
                    Text(logLines.joined(separator: "\n"))
                        .font(.system(.caption, design: .monospaced))
                        .foregroundStyle(.green)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(8)
                        .id("logEnd")
                }
                .background(Color(white: 0.05))
                .onChange(of: logLines.count) { _, _ in
                    withAnimation { proxy.scrollTo("logEnd", anchor: .bottom) }
                }
            }
        }
        .sheet(isPresented: $showTokenScanner) {
            TokenCameraScanSheet { found in
                token = found
            }
        }
        .navigationTitle("WireGuard Setup")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            if piHost.isEmpty { piHost = vm.hostName }
            if staticIp.isEmpty { staticIp = vm.hostName }
            // API キー: 既存キーがあれば表示、なければ UUID 自動生成
            if newApiKey.isEmpty {
                newApiKey = vm.apiKey.isEmpty ? UUID().uuidString.lowercased() : vm.apiKey
            }
        }
    }

    // MARK: - Actions

    @MainActor
    private func appendLog(_ line: String) {
        logLines.append(line)
        if logLines.count > 80 { logLines.removeFirst(logLines.count - 80) }
    }

    @MainActor
    private func runSetup() async {
        guard !piHost.isEmpty, !domain.isEmpty, !token.isEmpty, !newApiKey.isEmpty else { return }
        logLines = []
        pendingConf = nil
        isRunning = true
        statusText = "api.py を Pi に送信中..."
        statusColor = .secondary

        let port = vm.apiPort
        let apiKey = vm.apiKey

        // Step 1: push api.py
        let pushOk = await pushApiPy(host: piHost, port: port, apiKey: apiKey)
        if pushOk {
            appendLog("[準備] api.py 送信完了 — 5秒待機...")
            try? await Task.sleep(nanoseconds: 5_000_000_000)
        } else {
            appendLog("[警告] api.py 送信失敗 — そのまま続行")
        }

        // Step 2: WireGuard setup
        statusText = "WireGuard セットアップ中..."
        await runSseSetup(host: piHost, port: port, apiKey: apiKey)

        // Step 3: set API key on Pi and save locally
        statusText = "API キーを Pi に設定中..."
        let keyOk = await setApiKeyOnPi(host: piHost, port: port, currentApiKey: apiKey, newApiKey: newApiKey)
        if keyOk {
            vm.apiKey = newApiKey
            KeychainHelper.save(newApiKey, forKey: "apiKey")
            appendLog("[API Key] Pi への設定完了・アプリに保存済み")
            statusText = pendingConf != nil ? "完了！WireGuard アプリにインポートしてください" : "セットアップ完了"
            statusColor = .green
        } else {
            appendLog("⚠ API キーの Pi 設定に失敗。Connect 画面で手動設定してください。")
            statusText = "WireGuard 完了（API Key 設定失敗）"
            statusColor = .orange
        }

        isRunning = false
    }

    private func pushApiPy(host: String, port: Int, apiKey: String) async -> Bool {
        guard let url = Bundle.main.url(forResource: "api", withExtension: "py"),
              let data = try? Data(contentsOf: url) else { return false }
        guard let endpoint = URL(string: "http://\(host):\(port)/admin/update") else { return false }
        var req = URLRequest(url: endpoint)
        req.httpMethod = "POST"
        req.setValue("application/octet-stream", forHTTPHeaderField: "Content-Type")
        if !apiKey.isEmpty { req.setValue(apiKey, forHTTPHeaderField: "X-API-Key") }
        req.timeoutInterval = 30
        req.httpBody = data
        do {
            let (_, resp) = try await URLSession.shared.data(for: req)
            return (resp as? HTTPURLResponse)?.statusCode == 200
        } catch { return false }
    }

    private func setApiKeyOnPi(host: String, port: Int, currentApiKey: String, newApiKey: String) async -> Bool {
        guard let endpoint = URL(string: "http://\(host):\(port)/admin/set_api_key") else { return false }
        guard let body = try? JSONSerialization.data(withJSONObject: ["new_key": newApiKey]) else { return false }
        var req = URLRequest(url: endpoint)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if !currentApiKey.isEmpty { req.setValue(currentApiKey, forHTTPHeaderField: "X-API-Key") }
        req.timeoutInterval = 35
        req.httpBody = body
        do {
            let (_, resp) = try await URLSession.shared.data(for: req)
            return (resp as? HTTPURLResponse)?.statusCode == 200
        } catch { return false }
    }

    @MainActor
    private func runSseSetup(host: String, port: Int, apiKey: String) async {
        guard let url = URL(string: "http://\(host):\(port)/wireguard/setup") else { return }

        // sudo_pass is intentionally omitted: the SSH setup (SshSetupView) pre-configures
        // NOPASSWD sudoers for the WireGuard commands, so no password is needed or sent.
        let body: [String: Any] = [
            "ddns_domain": domain.trimmingCharacters(in: .whitespaces).lowercased(),
            "ddns_token":  token.trimmingCharacters(in: .whitespaces),
            "static_ip":   useStaticIp ? staticIp.trimmingCharacters(in: .whitespaces) : "",
        ]
        guard let bodyData = try? JSONSerialization.data(withJSONObject: body) else { return }

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("text/event-stream", forHTTPHeaderField: "Accept")
        if !apiKey.isEmpty { req.setValue(apiKey, forHTTPHeaderField: "X-API-Key") }
        req.timeoutInterval = 600
        req.httpBody = bodyData

        do {
            let (asyncBytes, response) = try await URLSession.shared.bytes(for: req)
            guard let http = response as? HTTPURLResponse else { return }
            if http.statusCode != 200 {
                appendLog("ERROR: HTTP \(http.statusCode)")
                statusText = "エラー: HTTP \(http.statusCode)"
                statusColor = .red
                return
            }

            var lineBuffer = ""
            for try await byte in asyncBytes {
                guard let ch = String(bytes: [byte], encoding: .utf8) else { continue }
                lineBuffer += ch
                guard lineBuffer.hasSuffix("\n") else { continue }
                let line = lineBuffer.trimmingCharacters(in: .newlines)
                lineBuffer = ""
                guard line.hasPrefix("data: ") else { continue }
                let jsonStr = String(line.dropFirst(6))
                guard let jsonData = jsonStr.data(using: .utf8),
                      let obj = try? JSONSerialization.jsonObject(with: jsonData) as? [String: Any]
                else { continue }
                handleEvent(obj)
            }

        } catch {
            appendLog("接続エラー: \(error.localizedDescription)")
            statusText = "エラー: \(error.localizedDescription)"
            statusColor = .red
        }
    }

    @MainActor
    private func handleEvent(_ obj: [String: Any]) {
        switch obj["type"] as? String {
        case "log":
            if let msg = obj["msg"] as? String { appendLog(msg) }
        case "info":
            if let ip = obj["pi_ip"] as? String, !ip.isEmpty {
                statusText = "Pi IP: \(ip) — 設定中..."
            }
        case "config":
            if let text = obj["text"] as? String, !text.isEmpty {
                pendingConf = text
                appendLog("=== クライアント設定ファイル生成完了 ===")
            }
        case "error":
            let msg = obj["msg"] as? String ?? "Unknown error"
            appendLog("ERROR: \(msg)")
            statusText = "エラー: \(msg)"
            statusColor = .red
        default: break
        }
    }
}
