package com.ji1ore.wifi_rig_ctrl.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class AppPrefs(context: Context) {
    private val p: SharedPreferences = context.getSharedPreferences("wifi_rig_ctrl", Context.MODE_PRIVATE)
    private val gson = Gson()

    // Encrypted SharedPreferences for sensitive fields only (apiKey, civPassword).
    // Lazily initialised so a KeyStore failure at startup does not crash the app.
    private val ep: SharedPreferences by lazy {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "wifi_rig_ctrl_secure",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    // Read a sensitive string: check encrypted prefs first, fall back to plain prefs
    // and migrate the value on first access (one-time migration for existing installs).
    private fun getSecureString(key: String, default: String = ""): String {
        val encrypted = try { ep.getString(key, null) } catch (_: Exception) { null }
        if (encrypted != null) return encrypted
        // Not yet in encrypted store — migrate from plain prefs if present
        val plain = p.getString(key, null)
        if (plain != null) {
            try { ep.edit().putString(key, plain).apply() } catch (_: Exception) {}
            p.edit().remove(key).apply()
            return plain
        }
        return default
    }

    private fun putSecureString(key: String, value: String) {
        try {
            ep.edit().putString(key, value).apply()
        } catch (_: Exception) {
            // Fallback: store in plain prefs if encryption fails (e.g. old device, broken KeyStore)
            p.edit().putString(key, value).apply()
        }
        // Always remove the plain-prefs copy when writing
        p.edit().remove(key).apply()
    }

    // --- Profile management ---

    fun getProfiles(): MutableList<ProfileConfig> {
        val json = p.getString("profiles_json", null)
        return if (json != null) {
            try {
                val type = object : TypeToken<MutableList<ProfileConfig>>() {}.type
                gson.fromJson(json, type) ?: mutableListOf(createDefaultProfile())
            } catch (_: Exception) { mutableListOf(createDefaultProfile()) }
        } else {
            val default = createDefaultProfile()
            saveProfiles(mutableListOf(default))
            mutableListOf(default)
        }
    }

    fun saveProfiles(profiles: List<ProfileConfig>) {
        p.edit().putString("profiles_json", gson.toJson(profiles)).apply()
    }

    var activeProfileIndex: Int
        get() = p.getInt("active_profile_index", 0)
        set(v) = p.edit().putInt("active_profile_index", v).apply()

    fun getActiveProfile(): ProfileConfig {
        val profiles = getProfiles()
        val idx = activeProfileIndex.coerceIn(0, maxOf(0, profiles.size - 1))
        return profiles.getOrElse(idx) { createDefaultProfile() }
    }

    fun applyProfile(profile: ProfileConfig) {
        p.edit()
            .putString("hostName", profile.hostName)
            .putInt("apiPort", profile.apiPort)
            .putInt("audioPort", profile.audioPort)
            .putBoolean("useMDNS", profile.useMDNS)
            .putInt("rigId", profile.savedRigId)
            .putString("cat", profile.savedCat)
            .putString("pttDevice", profile.savedPttDevice)
            .putString("pttType", profile.savedPttType)
            .putInt("baudIndex", profile.savedBaudIndex)
            .putInt("samplingIndex", profile.savedSamplingIndex)
            .putInt("txSamplingIndex", profile.savedTxSamplingIndex)
            .putInt("timeoutIndex", profile.savedTimeoutIndex)
            .putBoolean("useWifiPTT", profile.useWifiPTT)
            .putString("pttHost", profile.pttHost)
            .putInt("pttPort", profile.pttPort)
            .putInt("cwDelayMs", profile.cwDelayMs)
            .putInt("cwFmDelayMs", profile.cwFmDelayMs)
            .putString("alsaDevice", profile.alsaDevice)
            .putString("alsaDeviceFt8", profile.alsaDeviceFt8)
            .putBoolean("useCIV", profile.useCIV)
            .putString("civHost", profile.civHost)
            .putInt("civPort", profile.civPort)
            .putInt("civPort2", profile.civPort2)
            .putInt("civPort3", profile.civPort3)
            .putString("civUser", profile.civUser)
            .putInt("civAddress", profile.civAddress)
            .putString("civConnectionType", profile.civConnectionType)
            .putString("civBtDeviceAddress", profile.civBtDeviceAddress)
            .apply()
        // Store sensitive fields in encrypted prefs
        putSecureString("apiKey", profile.apiKey)
        putSecureString("civPassword", profile.civPassword)
    }

    private fun createDefaultProfile(): ProfileConfig = ProfileConfig(
        name = "Default",
        hostName = p.getString("hostName", "") ?: "",
        apiPort = p.getInt("apiPort", 8000),
        audioPort = p.getInt("audioPort", 50000).let { if (it == 50000) p.getInt("apiPort", 8000) else it },
        useMDNS = p.getBoolean("useMDNS", false),
        apiKey = getSecureString("apiKey"),
        savedRigId = p.getInt("rigId", -1),
        savedCat = p.getString("cat", "") ?: "",
        savedPttDevice = p.getString("pttDevice", "NONE") ?: "NONE",
        savedPttType = p.getString("pttType", "RIG") ?: "RIG",
        savedBaudIndex = p.getInt("baudIndex", 2),
        savedSamplingIndex = p.getInt("samplingIndex", 1),
        savedTxSamplingIndex = p.getInt("txSamplingIndex", 1),
        savedTimeoutIndex = p.getInt("timeoutIndex", 2),
        useWifiPTT = p.getBoolean("useWifiPTT", false),
        pttHost = p.getString("pttHost", "") ?: "",
        pttPort = p.getInt("pttPort", 8888),
        cwDelayMs = p.getInt("cwDelayMs", 0),
        cwFmDelayMs = p.getInt("cwFmDelayMs", 0),
        alsaDevice = p.getString("alsaDevice", "") ?: "",
        alsaDeviceFt8 = p.getString("alsaDeviceFt8", "") ?: "",
        useCIV = p.getBoolean("useCIV", false),
        civHost = p.getString("civHost", "") ?: "",
        civPort = p.getInt("civPort", 50001),
        civPort2 = p.getInt("civPort2", 50002),
        civPort3 = p.getInt("civPort3", 50003),
        civUser = p.getString("civUser", "") ?: "",
        civPassword = getSecureString("civPassword"),
        civAddress = p.getInt("civAddress", 0xA4),
        civConnectionType = p.getString("civConnectionType", "WIFI") ?: "WIFI",
        civBtDeviceAddress = p.getString("civBtDeviceAddress", "") ?: ""
    )

    // --- Flat prefs (kept in sync with active profile via applyProfile) ---

    var hostName: String get() = p.getString("hostName", "") ?: ""; set(v) = p.edit().putString("hostName", v).apply()
    var apiPort: Int get() = p.getInt("apiPort", 8000); set(v) = p.edit().putInt("apiPort", v).apply()
    var audioPort: Int get() = p.getInt("audioPort", 50000); set(v) = p.edit().putInt("audioPort", v).apply()
    var useMDNS: Boolean get() = p.getBoolean("useMDNS", false); set(v) = p.edit().putBoolean("useMDNS", v).apply()
    var apiKey: String get() = getSecureString("apiKey"); set(v) = putSecureString("apiKey", v)

    var savedRigId: Int get() = p.getInt("rigId", -1); set(v) = p.edit().putInt("rigId", v).apply()
    var savedBaudIndex: Int get() = p.getInt("baudIndex", 2); set(v) = p.edit().putInt("baudIndex", v).apply()
    var savedSamplingIndex: Int get() = p.getInt("samplingIndex", 1); set(v) = p.edit().putInt("samplingIndex", v).apply()
    var savedTxSamplingIndex: Int get() = p.getInt("txSamplingIndex", 1); set(v) = p.edit().putInt("txSamplingIndex", v).apply()
    var savedTimeoutIndex: Int get() = p.getInt("timeoutIndex", 2); set(v) = p.edit().putInt("timeoutIndex", v).apply()
    var savedCat: String get() = p.getString("cat", "") ?: ""; set(v) = p.edit().putString("cat", v).apply()
    var savedPttDevice: String get() = p.getString("pttDevice", "NONE") ?: "NONE"; set(v) = p.edit().putString("pttDevice", v).apply()
    var savedPttType: String get() = p.getString("pttType", "RIG") ?: "RIG"; set(v) = p.edit().putString("pttType", v).apply()

    var useWifiPTT: Boolean get() = p.getBoolean("useWifiPTT", false); set(v) = p.edit().putBoolean("useWifiPTT", v).apply()
    var pttHost: String get() = p.getString("pttHost", "") ?: ""; set(v) = p.edit().putString("pttHost", v).apply()
    var pttPort: Int get() = p.getInt("pttPort", 8888); set(v) = p.edit().putInt("pttPort", v).apply()

    var aprsEnabled: Boolean get() = p.getBoolean("aprsEnabled", false); set(v) = p.edit().putBoolean("aprsEnabled", v).apply()
    var aprsUseGPS: Boolean get() = p.getBoolean("aprsUseGPS", false); set(v) = p.edit().putBoolean("aprsUseGPS", v).apply()
    var aprsLat: Float get() = p.getFloat("aprsLat", 0f); set(v) = p.edit().putFloat("aprsLat", v).apply()
    var aprsLon: Float get() = p.getFloat("aprsLon", 0f); set(v) = p.edit().putFloat("aprsLon", v).apply()
    var aprsTxFreq: Float get() = p.getFloat("aprsTxFreq", 144.660f); set(v) = p.edit().putFloat("aprsTxFreq", v).apply()
    var aprsBaud: Int get() = p.getInt("aprsBaud", 1200); set(v) = p.edit().putInt("aprsBaud", v).apply()
    var aprsCallsign: String get() = p.getString("aprsCallsign", "") ?: ""; set(v) = p.edit().putString("aprsCallsign", v).apply()
    var aprsSSID: Int get() = p.getInt("aprsSSID", 0); set(v) = p.edit().putInt("aprsSSID", v).apply()
    var aprsIntervalSec: Int get() = p.getInt("aprsInterval", 60); set(v) = p.edit().putInt("aprsInterval", v).apply()
    var aprsPath: String get() = p.getString("aprsPath", "WIDE1-1") ?: "WIDE1-1"; set(v) = p.edit().putString("aprsPath", v).apply()
    var aprsSymbol: String get() = p.getString("aprsSymbol", ">") ?: ">"; set(v) = p.edit().putString("aprsSymbol", v).apply()
    var aprsComment: String get() = p.getString("aprsComment", "") ?: ""; set(v) = p.edit().putString("aprsComment", v).apply()
    var aprsDestination: String get() = p.getString("aprsDestination", "APRS00") ?: "APRS00"; set(v) = p.edit().putString("aprsDestination", v).apply()
    var aprsSoundDevice: String get() = p.getString("aprsSoundDevice", "") ?: ""; set(v) = p.edit().putString("aprsSoundDevice", v).apply()
    var aprsUseRigModem: Boolean get() = p.getBoolean("aprsUseRigModem", false); set(v) = p.edit().putBoolean("aprsUseRigModem", v).apply()
    /** RTTY Fix mode: decode position frozen, auto-tune off, waterfall tap moves it. */
    var rttyTuneFixed: Boolean get() = p.getBoolean("rttyTuneFixed", false); set(v) = p.edit().putBoolean("rttyTuneFixed", v).apply()
    var rttyDxCall: String get() = p.getString("rttyDxCall", "") ?: ""; set(v) = p.edit().putString("rttyDxCall", v).apply()
    var rttyRst: String get() = p.getString("rttyRst", "599") ?: "599"; set(v) = p.edit().putString("rttyRst", v).apply()
    var rttyMyRst: String get() = p.getString("rttyMyRst", "599") ?: "599"; set(v) = p.edit().putString("rttyMyRst", v).apply()
    var rttyPota: String get() = p.getString("rttyPota", "") ?: ""; set(v) = p.edit().putString("rttyPota", v).apply()
    var rttyJcc: String get() = p.getString("rttyJcc", "") ?: ""; set(v) = p.edit().putString("rttyJcc", v).apply()
    var rttyCqRepeat: Int get() = p.getInt("rttyCqRepeat", 1); set(v) = p.edit().putInt("rttyCqRepeat", v).apply()
    var rttyRstRepeat: Int get() = p.getInt("rttyRstRepeat", 2); set(v) = p.edit().putInt("rttyRstRepeat", v).apply()
    var rttyCqPota: Boolean get() = p.getBoolean("rttyCqPota", false); set(v) = p.edit().putBoolean("rttyCqPota", v).apply()
    var rttyCqJcc: Boolean get() = p.getBoolean("rttyCqJcc", false); set(v) = p.edit().putBoolean("rttyCqJcc", v).apply()
    var rttyAnsPota: Boolean get() = p.getBoolean("rttyAnsPota", false); set(v) = p.edit().putBoolean("rttyAnsPota", v).apply()
    var rttyAnsJcc: Boolean get() = p.getBoolean("rttyAnsJcc", false); set(v) = p.edit().putBoolean("rttyAnsJcc", v).apply()
    var rttyGreeting: String get() = p.getString("rttyGreeting", "") ?: ""; set(v) = p.edit().putString("rttyGreeting", v).apply()
    var rttyQsl: String get() = p.getString("rttyQsl", "") ?: ""; set(v) = p.edit().putString("rttyQsl", v).apply()
    var rttyCqLoopCount: Int get() = p.getInt("rttyCqLoopCount", 3); set(v) = p.edit().putInt("rttyCqLoopCount", v).apply()
    var rttyCqLoopInterval: Int get() = p.getInt("rttyCqLoopInterval", 15); set(v) = p.edit().putInt("rttyCqLoopInterval", v).apply()
    var rttyAnsCallRepeat: Int get() = p.getInt("rttyAnsCallRepeat", 1); set(v) = p.edit().putInt("rttyAnsCallRepeat", v).apply()
    fun rttyTxAmplitude(rigId: Int, band: String): Float = p.getFloat("rttyTxAmplitude_${rigId}_${band}", 0.8f)
    fun setRttyTxAmplitude(rigId: Int, band: String, v: Float) = p.edit().putFloat("rttyTxAmplitude_${rigId}_${band}", v).apply()
    /** Extra Hz added to the base RTTY shift, per rig and band (all default 0). */
    fun rttyDataShiftOffset(rigId: Int, band: String): Int = p.getInt("rttyDataShiftOffset_${rigId}_${band}", 0)
    fun setRttyDataShiftOffset(rigId: Int, band: String, v: Int) = p.edit().putInt("rttyDataShiftOffset_${rigId}_${band}", v).apply()
    var aprsModemSel: Int get() = p.getInt("aprsModemSel", 2); set(v) = p.edit().putInt("aprsModemSel", v).apply() // 1=AUTO 2=MAIN 3=SUB
    var aprsPreset1Freq: Float get() = p.getFloat("aprsPreset1Freq", 144.660f); set(v) = p.edit().putFloat("aprsPreset1Freq", v).apply() // AP96
    var aprsPreset1Baud: Int get() = p.getInt("aprsPreset1Baud", 9600); set(v) = p.edit().putInt("aprsPreset1Baud", v).apply()
    var aprsPreset2Freq: Float get() = p.getFloat("aprsPreset2Freq", 144.660f); set(v) = p.edit().putFloat("aprsPreset2Freq", v).apply() // AP12
    var aprsPreset2Baud: Int get() = p.getInt("aprsPreset2Baud", 1200); set(v) = p.edit().putInt("aprsPreset2Baud", v).apply()

    var volume: Float get() = p.getFloat("volume", 0.5f); set(v) = p.edit().putFloat("volume", v).apply()
    var micGain: Float get() = p.getFloat("micGain", 1.0f); set(v) = p.edit().putFloat("micGain", v).apply()
    var alsaDevice: String get() = p.getString("alsaDevice", "") ?: ""; set(v) = p.edit().putString("alsaDevice", v).apply()
    var alsaDeviceFt8: String get() = p.getString("alsaDeviceFt8", "") ?: ""; set(v) = p.edit().putString("alsaDeviceFt8", v).apply()

    var rttyTxMode: String
        get() {
            val v = p.getString("rttyTxMode", "auto") ?: "auto"
            if (v == "pi_fsk") { p.edit().putString("rttyTxMode", "auto").apply(); return "auto" }
            return v
        }
        set(v) = p.edit().putString("rttyTxMode", v).apply()
    /** Explicit FSK serial port override. Empty means "use the selected CAT device".
     *  This used to default to /dev/ttyUSB1, which does not exist on a Pi offering
     *  ttyACM0 / ttyACM1, so the port could not be opened and RTTY TX sent nothing at
     *  all. The old value is treated as unset so existing installs pick up the CAT choice. */
    var rttyFskPort: String
        get() {
            val v = p.getString("rttyFskPort", "") ?: ""
            return if (v == "/dev/ttyUSB1") "" else v
        }
        set(v) = p.edit().putString("rttyFskPort", v).apply()

    var ft8MyCall: String get() = p.getString("ft8MyCall", "") ?: ""; set(v) = p.edit().putString("ft8MyCall", v).apply()
    var ft8MyGrid: String get() = p.getString("ft8MyGrid", "") ?: ""; set(v) = p.edit().putString("ft8MyGrid", v).apply()
    var ft8DxCall: String get() = p.getString("ft8DxCall", "") ?: ""; set(v) = p.edit().putString("ft8DxCall", v).apply()
    var ft8TxMode: String get() = p.getString("ft8TxMode", "USB") ?: "USB"; set(v) = p.edit().putString("ft8TxMode", v).apply()
    var ft8LastFreq: Long get() = p.getLong("ft8LastFreq", 0L); set(v) = p.edit().putLong("ft8LastFreq", v).apply()
    var ft8IsFt4: Boolean get() = p.getBoolean("ft8IsFt4", false); set(v) = p.edit().putBoolean("ft8IsFt4", v).apply()
    var ft8QsoLog: String get() = p.getString("ft8QsoLog", "[]") ?: "[]"; set(v) = p.edit().putString("ft8QsoLog", v).apply()
    var ft8AudioFreqHz: Int get() = p.getInt("ft8AudioFreqHz", 1500); set(v) = p.edit().putInt("ft8AudioFreqHz", v).apply()
    var ft8Filter: Boolean get() = p.getBoolean("ft8Filter", false); set(v) = p.edit().putBoolean("ft8Filter", v).apply()
    var ft8DecodeDepth: Int get() = p.getInt("ft8DecodeDepth", 1); set(v) = p.edit().putInt("ft8DecodeDepth", v).apply()
    var ft8AutoTxMode: String get() = p.getString("ft8AutoTxMode", "even") ?: "even"; set(v) = p.edit().putString("ft8AutoTxMode", v).apply()
    var ft8FontSize: Int get() = p.getInt("ft8FontSize", 16); set(v) = p.edit().putInt("ft8FontSize", v).apply()
    var ft8RxGain: Float get() = p.getFloat("ft8RxGain", 1.0f); set(v) = p.edit().putFloat("ft8RxGain", v).apply()
    var ft8TxGain: Float get() = p.getFloat("ft8TxGain", 0.43f); set(v) = p.edit().putFloat("ft8TxGain", v).apply()
    var ft8PskReporter: Boolean get() = p.getBoolean("ft8PskReporter", true); set(v) = p.edit().putBoolean("ft8PskReporter", v).apply()

    // CI-V direct connection
    var useCIV: Boolean get() = p.getBoolean("useCIV", false); set(v) = p.edit().putBoolean("useCIV", v).apply()
    var civHost: String get() = p.getString("civHost", "") ?: ""; set(v) = p.edit().putString("civHost", v).apply()
    var civPort: Int get() = p.getInt("civPort", 50001); set(v) = p.edit().putInt("civPort", v).apply()
    var civPort2: Int get() = p.getInt("civPort2", 50002); set(v) = p.edit().putInt("civPort2", v).apply()
    var civPort3: Int get() = p.getInt("civPort3", 50003); set(v) = p.edit().putInt("civPort3", v).apply()
    var civUser: String get() = p.getString("civUser", "") ?: ""; set(v) = p.edit().putString("civUser", v).apply()
    var civPassword: String get() = getSecureString("civPassword"); set(v) = putSecureString("civPassword", v)
    var civAddress: Int get() = p.getInt("civAddress", 0xA4); set(v) = p.edit().putInt("civAddress", v).apply()
    var civConnectionType: String get() = p.getString("civConnectionType", "WIFI") ?: "WIFI"; set(v) = p.edit().putString("civConnectionType", v).apply()
    var civBtDeviceAddress: String get() = p.getString("civBtDeviceAddress", "") ?: ""; set(v) = p.edit().putString("civBtDeviceAddress", v).apply()

    var cwPort: String get() = p.getString("cwPort", "ttyACM0") ?: "ttyACM0"; set(v) = p.edit().putString("cwPort", v).apply()
    var vncDesktop: String get() = p.getString("vncDesktop", "xfce") ?: "xfce"; set(v) = p.edit().putString("vncDesktop", v).apply()
    var cwDelayMs: Int get() = p.getInt("cwDelayMs", 0); set(v) = p.edit().putInt("cwDelayMs", v).apply()
    var cwFmDelayMs: Int get() = p.getInt("cwFmDelayMs", 0); set(v) = p.edit().putInt("cwFmDelayMs", v).apply()
    var cwSidetoneEnabled: Boolean get() = p.getBoolean("cwSidetoneEnabled", true); set(v) = p.edit().putBoolean("cwSidetoneEnabled", v).apply()
    var cwWpm: Int get() = p.getInt("cwWpm", 20); set(v) = p.edit().putInt("cwWpm", v).apply()
    var cwPaddleSwap: Boolean get() = p.getBoolean("cwPaddleSwap", false); set(v) = p.edit().putBoolean("cwPaddleSwap", v).apply()
    var cwLastText: String get() = p.getString("cwLastText", "") ?: ""; set(v) = p.edit().putString("cwLastText", v).apply()
    var cwPttPoll: Boolean get() = p.getBoolean("cwPttPoll", false); set(v) = p.edit().putBoolean("cwPttPoll", v).apply()
    var cwDxCall: String get() = p.getString("cwDxCall", "") ?: ""; set(v) = p.edit().putString("cwDxCall", v).apply()
    var cwRst: String get() = p.getString("cwRst", "599") ?: "599"; set(v) = p.edit().putString("cwRst", v).apply()
    var cwPota: String get() = p.getString("cwPota", "") ?: ""; set(v) = p.edit().putString("cwPota", v).apply()
    var cwJcc: String get() = p.getString("cwJcc", "") ?: ""; set(v) = p.edit().putString("cwJcc", v).apply()
    var cwCqRepeat: Int get() = p.getInt("cwCqRepeat", 1); set(v) = p.edit().putInt("cwCqRepeat", v).apply()
    var cwCqPota: Boolean get() = p.getBoolean("cwCqPota", false); set(v) = p.edit().putBoolean("cwCqPota", v).apply()
    var cwCqJcc: Boolean get() = p.getBoolean("cwCqJcc", false); set(v) = p.edit().putBoolean("cwCqJcc", v).apply()
    var cwAnsGreeting: String get() = p.getString("cwAnsGreeting", "") ?: ""; set(v) = p.edit().putString("cwAnsGreeting", v).apply()
    var cwAnsPota: Boolean get() = p.getBoolean("cwAnsPota", false); set(v) = p.edit().putBoolean("cwAnsPota", v).apply()
    var cwAnsJcc: Boolean get() = p.getBoolean("cwAnsJcc", false); set(v) = p.edit().putBoolean("cwAnsJcc", v).apply()
    var cwQsl: String
        get() = p.getString("cwQsl", "")?.let { if (it == "TNX QSL") "NO QSL" else it } ?: ""
        set(v) = p.edit().putString("cwQsl", v).apply()
    var cwCqLoopCount: Int get() = p.getInt("cwCqLoopCount", 3); set(v) = p.edit().putInt("cwCqLoopCount", v).apply()
    var cwCqLoopInterval: Int get() = p.getInt("cwCqLoopInterval", 15); set(v) = p.edit().putInt("cwCqLoopInterval", v).apply()
    var cwRstRepeat: Int get() = p.getInt("cwRstRepeat", 2); set(v) = p.edit().putInt("cwRstRepeat", v).apply()
    var nrLevel: Int get() = p.getInt("nrLevel", 0); set(v) = p.edit().putInt("nrLevel", v).apply()

    // CW TX shift persistence
    var cwTxShiftHz: Long get() = p.getLong("cwTxShiftHz", 0L); set(v) = p.edit().putLong("cwTxShiftHz", v).apply()
    var cwShiftStep: Int get() = p.getInt("cwShiftStep", 10); set(v) = p.edit().putInt("cwShiftStep", v).apply()

    // FM デジタルモード設定 (FM ボタン長押しで編集)
    var fmDstarEnabled: Boolean get() = p.getBoolean("fmDstarEnabled", true)
        set(v) = p.edit().putBoolean("fmDstarEnabled", v).apply()

    // Default filter widths (Hz) set on Connect screen
    var defaultSsbWidth: Int get() = p.getInt("default_ssb_width", 3000); set(v) = p.edit().putInt("default_ssb_width", v).apply()
    var defaultCwWidth:  Int get() = p.getInt("default_cw_width",   500); set(v) = p.edit().putInt("default_cw_width",  v).apply()

    // UI カラーテーマ (0=OCEAN 1=AMBER 2=MONO 3=AQUA)
    var colorTheme: Int get() = p.getInt("colorTheme", 0); set(v) = p.edit().putInt("colorTheme", v).apply()

    // MEM dialog UI state
    var memLastTab: Int get() = p.getInt("mem_last_tab", 0); set(v) = p.edit().putInt("mem_last_tab", v).apply()
    var memPotaFilter: String get() = p.getString("mem_pota_filter", "") ?: ""; set(v) = p.edit().putString("mem_pota_filter", v).apply()
    var memSotaFilter: String get() = p.getString("mem_sota_filter", "") ?: ""; set(v) = p.edit().putString("mem_sota_filter", v).apply()
    var memPotaSort: Int get() = p.getInt("mem_pota_sort", 0); set(v) = p.edit().putInt("mem_pota_sort", v).apply()
    var memSotaSort: Int get() = p.getInt("mem_sota_sort", 0); set(v) = p.edit().putInt("mem_sota_sort", v).apply()
    var memPotaModeFilter: String get() = p.getString("mem_pota_mode_f", "") ?: ""; set(v) = p.edit().putString("mem_pota_mode_f", v).apply()
    var memPotaBandFilter: String get() = p.getString("mem_pota_band_f", "") ?: ""; set(v) = p.edit().putString("mem_pota_band_f", v).apply()
    var memPotaProgramFilter: String get() = p.getString("mem_pota_prog_f", "") ?: ""; set(v) = p.edit().putString("mem_pota_prog_f", v).apply()
    var memSotaModeFilter: String get() = p.getString("mem_sota_mode_f", "") ?: ""; set(v) = p.edit().putString("mem_sota_mode_f", v).apply()
    var memSotaBandFilter: String get() = p.getString("mem_sota_band_f", "") ?: ""; set(v) = p.edit().putString("mem_sota_band_f", v).apply()
    var memSotaAreaFilter: String get() = p.getString("mem_sota_area_f", "") ?: ""; set(v) = p.edit().putString("mem_sota_area_f", v).apply()

    // Editable presets (user-modified; defaults to PRESET_MEMORIES when not set)
    fun getCustomPresets(): MutableList<MemoryEntry> {
        val json = p.getString("custom_presets_json", null) ?: return PRESET_MEMORIES.toMutableList()
        return try {
            val type = object : TypeToken<MutableList<MemoryEntry>>() {}.type
            gson.fromJson<MutableList<MemoryEntry>>(json, type) ?: PRESET_MEMORIES.toMutableList()
        } catch (_: Exception) { PRESET_MEMORIES.toMutableList() }
    }

    fun saveCustomPresets(list: List<MemoryEntry>) {
        p.edit().putString("custom_presets_json", gson.toJson(list)).apply()
    }

    fun resetCustomPresets() {
        p.edit().remove("custom_presets_json").apply()
    }

    fun getUserMemories(): MutableList<MemoryEntry> {
        val json = p.getString("user_memories_json", null) ?: return mutableListOf()
        return try {
            val type = object : TypeToken<MutableList<MemoryEntry>>() {}.type
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (_: Exception) { mutableListOf() }
    }

    fun saveUserMemories(list: List<MemoryEntry>) {
        p.edit().putString("user_memories_json", gson.toJson(list)).apply()
    }

    fun getModeStep(mode: String): Int = p.getInt("step_$mode", defaultStepFor(mode))
    fun setModeStep(mode: String, step: Int) = p.edit().putInt("step_$mode", step).apply()

    // リピーター設定（現在適用中）
    var repeaterToneMode: String
        get() = p.getString("rptr_tone_mode", "") ?: ""
        set(v) = p.edit().putString("rptr_tone_mode", v).apply()
    var repeaterToneHz: Double
        get() = java.lang.Double.longBitsToDouble(p.getLong("rptr_tone_hz_bits", java.lang.Double.doubleToLongBits(0.0)))
        set(v) = p.edit().putLong("rptr_tone_hz_bits", java.lang.Double.doubleToLongBits(v)).apply()
    var repeaterOffsetDir: String
        get() = p.getString("rptr_offset_dir", "") ?: ""
        set(v) = p.edit().putString("rptr_offset_dir", v).apply()
    var repeaterOffsetHz: Long
        get() = p.getLong("rptr_offset_hz", 0L)
        set(v) = p.edit().putLong("rptr_offset_hz", v).apply()

    companion object {
        fun defaultStepFor(mode: String): Int {
            val m = mode.uppercase()
            return when {
                m.contains("FM") || m == "DSTAR" || m == "D-STAR" || m == "C4FM" -> 7  // 20kHz
                m.contains("CW") -> 2  // 100Hz
                m.contains("AM") -> 4  // 1kHz
                else -> 2  // 100Hz (SSB/PKT/RTTY等)
            }
        }
    }
}
