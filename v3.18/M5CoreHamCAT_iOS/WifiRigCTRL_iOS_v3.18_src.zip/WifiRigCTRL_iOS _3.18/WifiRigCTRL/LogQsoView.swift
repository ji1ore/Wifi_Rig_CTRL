import SwiftUI
import CoreLocation
import Contacts

private let persistKey = "log_qso_persist"

private func loadPersist() -> [String: String] {
    UserDefaults.standard.dictionary(forKey: persistKey) as? [String: String] ?? [:]
}
private func savePersist(_ d: [String: String]) {
    UserDefaults.standard.set(d, forKey: persistKey)
}


struct LogQsoView: View {
    @Environment(\.dismiss) private var dismiss
    let vm: MainViewModel

    // Pre-filled from caller (CW TX screen etc.)
    var initCallsign: String = ""
    var initPota: String = ""
    var initSota: String = ""
    var initRstSent: String = ""
    /// Called after each successful save (caller can clear its own DX call / RST fields)
    var onSaved: (() -> Void)? = nil

    @FocusState private var focused: Bool

    // Transient fields — cleared after each save
    @State private var callsign: String = ""
    @State private var rstSent: String = ""
    @State private var rstRcvd: String = ""
    @State private var yourPota: String = ""
    @State private var yourSota: String = ""
    @State private var dtDate: String = ""
    @State private var dtTime: String = ""

    // Persistent fields — survive across sessions
    @State private var myPota: String = ""
    @State private var mySota: String = ""
    @State private var jcc: String = ""
    @State private var jgc: String = ""
    @State private var comment: String = ""

    @State private var gpsInfo: String = ""
    @State private var lat: Double = 0.0
    @State private var lon: Double = 0.0

    private var freqHz: Int64 { Int64(vm.sharedFreq) }
    private var mode: String { vm.sharedMode }
    private var myCall: String { vm.ft8MyCall }
    private var myGrid: String { vm.ft8MyGrid }

    private var defaultRst: String {
        let m = mode.uppercased()
        if m.contains("CW") { return "599" }
        if m.hasPrefix("FT") || m == "RTTY" { return "-00" }
        return "59"
    }

    private var rstPresets: [String] {
        let m = mode.uppercased()
        if m.contains("CW") { return (1...9).map { "5\($0)9" } }
        if m.hasPrefix("FT") || m == "RTTY" { return ["-20", "-15", "-10", "-05", "00", "+05", "+10"] }
        return (1...9).map { "5\($0)" }
    }

    @ViewBuilder
    private func rstChipsView(setter: @escaping (String) -> Void) -> some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 4) {
                ForEach(rstPresets, id: \.self) { v in
                    Button(v) { setter(v) }
                        .font(.system(size: 11, design: .monospaced))
                        .foregroundStyle(.cyan)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 3)
                        .background(Color(white: 0.15), in: RoundedRectangle(cornerRadius: 4))
                        .buttonStyle(.plain)
                }
            }
        }
        .frame(height: 26)
    }

    private var localTimeStr: String {
        let s = utcToLocal(dtDate + dtTime)
        return s.isEmpty ? "" : "Local: \(s)"
    }

    var body: some View {
        NavigationStack {
            Form {
                // ── 周波数・自局 ──────────────────────────────────────
                Section("QSO情報") {
                    LabeledContent("周波数") {
                        Text(freqHz > 0
                            ? String(format: "%.3f MHz  %@  %@",
                                     Double(freqHz) / 1_000_000.0,
                                     QsoStore.freqToBand(freqHz), mode)
                            : "---")
                            .font(.system(size: 15, design: .monospaced))
                            .foregroundStyle(.cyan)
                    }
                    LabeledContent("自局") {
                        Text(myCall.isEmpty ? "(未設定)" : myCall)
                            .font(.system(size: 15, design: .monospaced))
                            .foregroundStyle(.cyan)
                    }
                }

                // ── 日時 UTC ──────────────────────────────────────────
                Section {
                    HStack(spacing: 8) {
                        TextField("yyyyMMdd", text: $dtDate)
                            .keyboardType(.numberPad)
                            .font(.system(size: 15, design: .monospaced))
                            .frame(maxWidth: .infinity)
                        TextField("HHmmss", text: $dtTime)
                            .keyboardType(.numberPad)
                            .font(.system(size: 15, design: .monospaced))
                            .frame(maxWidth: .infinity)
                    }
                    if !localTimeStr.isEmpty {
                        Text(localTimeStr)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                } header: {
                    Text("日時 UTC  (yyyyMMdd  HHmmss)")
                }

                // ── 相手局 ───────────────────────────────────────────
                Section("相手局") {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("DX コールサイン").font(.caption).foregroundStyle(.secondary)
                        TextField("JA2ABC", text: $callsign)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .keyboardType(.asciiCapable)
                            .font(.system(size: 22, weight: .bold, design: .monospaced))
                            .foregroundStyle(.yellow)
                            .focused($focused)
                            .onChange(of: callsign) { _, v in
                                callsign = v.uppercased()
                                    .filter { $0.isLetter && $0.asciiValue != nil || $0.isNumber || $0 == "/" }
                            }
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        HStack {
                            Text("RST 送信").foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
                            TextField(defaultRst, text: $rstSent)
                                .autocorrectionDisabled()
                                .textInputAutocapitalization(.characters)
                                .font(.system(size: 17, design: .monospaced))
                        }
                        rstChipsView { rstSent = $0 }
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        HStack {
                            Text("RST 受信").foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
                            TextField(defaultRst, text: $rstRcvd)
                                .autocorrectionDisabled()
                                .textInputAutocapitalization(.characters)
                                .font(.system(size: 17, design: .monospaced))
                        }
                        rstChipsView { rstRcvd = $0 }
                    }
                }

                // ── Your POTA / SOTA (相手局) ─────────────────────────
                Section("相手局 POTA / SOTA") {
                    HStack {
                        Text("POTA").foregroundStyle(.secondary).frame(width: 60, alignment: .leading)
                        TextField("JP-XXXX", text: $yourPota)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .onChange(of: yourPota) { _, v in yourPota = v.uppercased() }
                    }
                    HStack {
                        Text("SOTA").foregroundStyle(.secondary).frame(width: 60, alignment: .leading)
                        TextField("JA/NN-001", text: $yourSota)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .onChange(of: yourSota) { _, v in yourSota = v.uppercased() }
                    }
                }

                // ── My POTA / SOTA (自局) — 永続 ─────────────────────
                Section("自局 POTA / SOTA  (次回も保持)") {
                    HStack {
                        Text("My POTA").foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
                        TextField("JP-XXXX", text: $myPota)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .onChange(of: myPota) { _, v in myPota = v.uppercased() }
                    }
                    HStack {
                        Text("My SOTA").foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
                        TextField("JA/NN-001", text: $mySota)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .onChange(of: mySota) { _, v in mySota = v.uppercased() }
                    }
                }

                // ── JCC / JGC — 永続 ─────────────────────────────────
                Section("JCC / JGC  (次回も保持)") {
                    HStack {
                        Text("JCC").foregroundStyle(.secondary).frame(width: 40, alignment: .leading)
                        TextField("1234", text: $jcc)
                            .keyboardType(.numberPad)
                        Text("JGC").foregroundStyle(.secondary).frame(width: 40, alignment: .leading)
                        TextField("12345", text: $jgc)
                            .keyboardType(.numberPad)
                    }
                    Button("GPS 位置を取得") { fetchGps() }
                    if !gpsInfo.isEmpty {
                        Text(gpsInfo)
                            .font(.caption)
                            .foregroundStyle(.green)
                    }
                }

                // ── コメント — 永続 ───────────────────────────────────
                Section("コメント  (次回も保持)") {
                    TextField("メモ・コメント", text: $comment)
                }

                // ── 永続フィールド クリア ─────────────────────────────
                Section {
                    Button(role: .destructive) {
                        myPota = ""; mySota = ""
                        jcc = ""; jgc = ""; comment = ""
                        var d = loadPersist()
                        d.removeValue(forKey: "myPota"); d.removeValue(forKey: "mySota")
                        d.removeValue(forKey: "jcc");    d.removeValue(forKey: "jgc")
                        d.removeValue(forKey: "comment")
                        savePersist(d)
                    } label: {
                        Text("My POTA / SOTA / JCC / コメント をクリア")
                    }
                }
            }
            .navigationTitle("Log QSO")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("閉じる") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") { saveEntry() }
                        .disabled(callsign.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
        }
        .onAppear { initFields() }
    }

    private func initFields() {
        let now = QsoEntry.utcNow()
        dtDate = String(now.prefix(8))
        dtTime = String(now.dropFirst(8))
        callsign = initCallsign.isEmpty ? vm.pendingLogCallsign : initCallsign
        yourPota = initPota.isEmpty     ? vm.pendingLogPota     : initPota
        yourSota = initSota.isEmpty     ? vm.pendingLogSota     : initSota
        rstSent  = initRstSent.isEmpty  ? defaultRst            : initRstSent
        rstRcvd  = defaultRst
        let p = loadPersist()
        myPota   = p["myPota"]  ?? ""
        mySota   = p["mySota"]  ?? ""
        jcc      = p["jcc"]     ?? ""
        jgc      = p["jgc"]     ?? ""
        comment  = p["comment"] ?? ""
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { focused = true }
    }

    private func saveEntry() {
        let call = callsign.trimmingCharacters(in: .whitespaces).uppercased()
        guard !call.isEmpty else { return }
        let dt = (dtDate.trimmingCharacters(in: .whitespaces)
                + dtTime.trimmingCharacters(in: .whitespaces))
            .padding(toLength: 14, withPad: "0", startingAt: 0)
        let entry = QsoEntry(
            dt:       dt,
            call:     call,
            freq:     freqHz,
            mode:     mode.isEmpty ? "SSB" : mode,
            rstS:     rstSent.isEmpty  ? defaultRst : rstSent,
            rstR:     rstRcvd.isEmpty  ? defaultRst : rstRcvd,
            grid:     "",
            myCall:   myCall,
            myGrid:   myGrid,
            yourPota: yourPota.trimmingCharacters(in: .whitespaces).uppercased(),
            yourSota: yourSota.trimmingCharacters(in: .whitespaces).uppercased(),
            myPota:   myPota.trimmingCharacters(in: .whitespaces).uppercased(),
            mySota:   mySota.trimmingCharacters(in: .whitespaces).uppercased(),
            jcc:      jcc.trimmingCharacters(in: .whitespaces),
            jgc:      jgc.trimmingCharacters(in: .whitespaces),
            comment:  comment.trimmingCharacters(in: .whitespaces),
            lat:      lat, lon: lon
        )
        QsoStore.append(entry)
        vm.ft8QsoLog = QsoStore.jsonString()

        // 永続フィールドを保存
        var d = loadPersist()
        d["myPota"]  = entry.myPota
        d["mySota"]  = entry.mySota
        d["jcc"]     = entry.jcc
        d["jgc"]     = entry.jgc
        d["comment"] = entry.comment
        savePersist(d)

        // 一時フィールドをクリアして次のQSOに備える (ダイアログは閉じない)
        callsign = ""
        yourPota = ""
        yourSota = ""
        rstSent  = defaultRst
        rstRcvd  = defaultRst
        let next = QsoEntry.utcNow()
        dtDate = String(next.prefix(8))
        dtTime = String(next.dropFirst(8))
        focused = true

        // Logged → clear the prefill info and the CW TX screen's DX call / RST,
        // regardless of which screen opened this sheet.
        vm.pendingLogCallsign = ""
        vm.pendingLogPota = ""
        vm.pendingLogSota = ""
        vm.cwDxCall = ""
        vm.cwRst = ""
        vm.persistCwSettings()
        onSaved?()
    }

    private func fetchGps() {
        let mgr = CLLocationManager()
        let status = mgr.authorizationStatus
        guard status == .authorizedWhenInUse || status == .authorizedAlways else {
            gpsInfo = "位置情報の許可が必要です"
            return
        }
        guard let loc = mgr.location else {
            gpsInfo = "GPS fix なし"
            return
        }
        lat = loc.coordinate.latitude
        lon = loc.coordinate.longitude
        gpsInfo = String(format: "%.5f, %.5f", lat, lon)

        CLGeocoder().reverseGeocodeLocation(loc, preferredLocale: Locale(identifier: "ja_JP")) { pms, _ in
            guard let pm = pms?.first else { return }
            let admin       = pm.administrativeArea ?? ""
            let subAdmin    = pm.subAdministrativeArea ?? ""
            let locality    = pm.locality ?? ""
            let subLocality = pm.subLocality ?? ""
            // One-line address (e.g. "東京都千代田区丸の内1丁目") — used for display and as a 区 fallback
            var addressLine = ""
            if let pa = pm.postalAddress {
                addressLine = pa.state + pa.city + pa.subLocality + pa.street
            }
            if addressLine.isEmpty { addressLine = admin + subAdmin + locality + subLocality }

            // Look up JCC / JGC the same way the Android app does
            let r = JccTable.resolve(admin: admin, subAdmin: subAdmin, locality: locality,
                                     subLocality: subLocality, addressLine: addressLine)
            DispatchQueue.main.async {
                // Fill the fields (they are persisted on save, like Android)
                jcc = r.jcc
                jgc = r.jgc
                switch (r.jcc.isEmpty, r.jgc.isEmpty) {
                case (false, false): gpsInfo = "\(addressLine)  → JCC:\(r.jcc) JGC:\(r.jgc)"
                case (false, true):  gpsInfo = "\(addressLine)  → JCC: \(r.jcc)"
                case (true, false):  gpsInfo = "\(addressLine)  → JGC: \(r.jgc)"
                case (true, true):   gpsInfo = addressLine
                }
            }
        }
    }
}
