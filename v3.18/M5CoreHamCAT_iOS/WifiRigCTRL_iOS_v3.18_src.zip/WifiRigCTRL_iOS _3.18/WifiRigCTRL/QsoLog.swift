import Foundation
import CoreLocation

// UTC yyyyMMddHHmmss → ローカルタイム "MM/dd HH:mm"
func utcToLocal(_ dt: String) -> String {
    guard dt.count >= 8 else { return "" }
    let fmt = DateFormatter()
    fmt.dateFormat = "yyyyMMddHHmmss"
    fmt.timeZone = TimeZone(identifier: "UTC")
    let padded = String((dt + "00000000000000").prefix(14))
    guard let date = fmt.date(from: padded) else { return "" }
    let local = DateFormatter()
    local.dateFormat = "MM/dd HH:mm"
    local.timeZone = TimeZone.current
    return local.string(from: date)
}

struct QsoEntry: Identifiable, Codable {
    var id: UUID = UUID()
    var dt: String          // yyyyMMddHHmmss UTC
    var call: String
    var freq: Int64
    var mode: String
    var rstS: String
    var rstR: String
    var grid: String
    var myCall: String
    var myGrid: String
    var yourPota: String = ""
    var yourSota: String = ""
    var myPota: String   = ""
    var mySota: String   = ""
    var jcc: String      = ""
    var jgc: String      = ""
    var comment: String  = ""
    var lat: Double      = 0.0
    var lon: Double      = 0.0

    static func utcNow() -> String {
        let fmt = DateFormatter()
        fmt.dateFormat = "yyyyMMddHHmmss"
        fmt.timeZone = TimeZone(identifier: "UTC")
        return fmt.string(from: Date())
    }

    func toDict() -> [String: Any] {
        var d: [String: Any] = [
            "dt": dt, "call": call, "freq": freq, "mode": mode,
            "rstS": rstS, "rstR": rstR, "grid": grid,
            "myCall": myCall, "myGrid": myGrid
        ]
        if !yourPota.isEmpty { d["yourPota"] = yourPota }
        if !yourSota.isEmpty { d["yourSota"] = yourSota }
        if !myPota.isEmpty   { d["myPota"]   = myPota }
        if !mySota.isEmpty   { d["mySota"]   = mySota }
        if !jcc.isEmpty      { d["jcc"]      = jcc }
        if !jgc.isEmpty      { d["jgc"]      = jgc }
        if !comment.isEmpty  { d["comment"]  = comment }
        if lat != 0.0        { d["lat"]      = lat }
        if lon != 0.0        { d["lon"]      = lon }
        return d
    }

    static func fromDict(_ d: [String: Any]) -> QsoEntry {
        // "pota"/"sota" keys from older data map to yourPota/yourSota
        let legacyPota = d["pota"] as? String ?? ""
        let legacySota = d["sota"] as? String ?? ""
        return QsoEntry(
            dt:       d["dt"]      as? String ?? "",
            call:     d["call"]    as? String ?? "",
            freq:     Int64(d["freq"] as? Int ?? 0),
            mode:     d["mode"]    as? String ?? "FT8",
            rstS:     d["rstS"]    as? String ?? "",
            rstR:     d["rstR"]    as? String ?? "",
            grid:     d["grid"]    as? String ?? "",
            myCall:   d["myCall"]  as? String ?? "",
            myGrid:   d["myGrid"]  as? String ?? "",
            yourPota: (d["yourPota"] as? String ?? legacyPota),
            yourSota: (d["yourSota"] as? String ?? legacySota),
            myPota:   d["myPota"]   as? String ?? "",
            mySota:   d["mySota"]   as? String ?? "",
            jcc:      d["jcc"]      as? String ?? "",
            jgc:      d["jgc"]      as? String ?? "",
            comment:  d["comment"]  as? String ?? "",
            lat:      d["lat"]      as? Double ?? 0.0,
            lon:      d["lon"]      as? Double ?? 0.0
        )
    }
}

enum QsoStore {
    private static let key = "ft8QsoLog"

    static func load() -> [QsoEntry] {
        guard let str = UserDefaults.standard.string(forKey: key),
              let arr = try? JSONSerialization.jsonObject(with: Data(str.utf8)) as? [[String: Any]]
        else { return [] }
        return arr.map { QsoEntry.fromDict($0) }
    }

    static func save(_ entries: [QsoEntry]) {
        let arr = entries.map { $0.toDict() }
        if let data = try? JSONSerialization.data(withJSONObject: arr),
           let str = String(data: data, encoding: .utf8) {
            UserDefaults.standard.set(str, forKey: key)
        }
    }

    static func append(_ entry: QsoEntry) {
        var list = load()
        list.append(entry)
        save(list)
    }

    static func jsonString() -> String {
        UserDefaults.standard.string(forKey: key) ?? "[]"
    }

    static func setFromJsonString(_ s: String) {
        UserDefaults.standard.set(s, forKey: key)
    }

    static func buildAdif(_ entries: [QsoEntry]) -> String {
        func f(_ tag: String, _ v: String) -> String {
            v.isEmpty ? "" : "<\(tag):\(v.count)>\(v) "
        }
        var adif = "ADIF Export from Wifi_RIG_CTRL\n<EOH>\n\n"
        for e in entries {
            let freq = e.freq > 0 ? String(format: "%.4f", Double(e.freq) / 1_000_000.0) : ""
            adif += f("CALL", e.call) + f("MODE", e.mode) + f("BAND", freqToBand(e.freq))
            adif += f("FREQ", freq)
            adif += f("QSO_DATE", String(e.dt.prefix(8)))
            adif += f("TIME_ON", String(e.dt.dropFirst(8).prefix(6)))
            adif += f("RST_SENT", e.rstS) + f("RST_RCVD", e.rstR)
            adif += f("GRIDSQUARE", e.grid)
            adif += f("OPERATOR", e.myCall) + f("MY_GRIDSQUARE", e.myGrid)
            if e.lat != 0.0 { adif += f("MY_LAT", String(format: "%.6f", e.lat)) }
            if e.lon != 0.0 { adif += f("MY_LON", String(format: "%.6f", e.lon)) }
            adif += f("POTA_REF", e.yourPota) + f("SOTA_REF", e.yourSota)
            adif += f("MY_POTA", e.myPota) + f("MY_SOTA", e.mySota)
            adif += f("COMMENT", e.comment)
            adif += "<EOR>\n"
        }
        return adif
    }

    static func freqToBand(_ hz: Int64) -> String {
        switch hz {
        case 1_800_000..<2_000_000:   return "160M"
        case 3_500_000..<4_000_000:   return "80M"
        case 7_000_000..<7_300_000:   return "40M"
        case 10_100_000..<10_150_000: return "30M"
        case 14_000_000..<14_350_000: return "20M"
        case 18_068_000..<18_168_000: return "17M"
        case 21_000_000..<21_450_000: return "15M"
        case 24_890_000..<24_990_000: return "12M"
        case 28_000_000..<29_700_000: return "10M"
        case 50_000_000..<54_000_000: return "6M"
        case 144_000_000..<148_000_000: return "2M"
        case 420_000_000..<450_000_000: return "70CM"
        default: return ""
        }
    }
}
