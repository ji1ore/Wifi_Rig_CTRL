import SwiftUI
import UIKit

struct QsoLogView: View {
    let vm: MainViewModel

    @State private var entries: [QsoEntry] = []
    @State private var selected = Set<UUID>()
    @State private var editMode: EditMode = .inactive
    @State private var showLogEntry = false
    @State private var showDeleteConfirm = false
    @State private var showClearConfirm = false
    @State private var searchText = ""
    @State private var editing: QsoEntry? = nil

    private var filtered: [QsoEntry] {
        if searchText.isEmpty { return entries }
        let q = searchText.lowercased()
        return entries.filter {
            $0.call.lowercased().contains(q) ||
            $0.yourPota.lowercased().contains(q) ||
            $0.yourSota.lowercased().contains(q) ||
            $0.myPota.lowercased().contains(q) ||
            $0.mode.lowercased().contains(q) ||
            $0.jcc.contains(q)
        }
    }

    var body: some View {
        List(selection: $selected) {
            ForEach(filtered) { e in
                if editMode == .active {
                    // Selection mode: let the List handle taps for multi-select
                    qsoRow(e)
                } else {
                    // Normal mode: tap a row to edit it (Android uses long-press)
                    qsoRow(e)
                        .contentShape(Rectangle())
                        .onTapGesture { editing = e }
                        .swipeActions(edge: .leading) {
                            Button {
                                editing = e
                            } label: {
                                Label("編集", systemImage: "pencil")
                            }
                            .tint(.blue)
                        }
                }
            }
            .onDelete(perform: deleteRows)
        }
        .environment(\.editMode, $editMode)
        .searchable(text: $searchText, prompt: "コールサイン・POTA・モードで検索")
        .navigationTitle("QSO Log (\(entries.count)件)")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button {
                    showLogEntry = true
                } label: {
                    Image(systemName: "plus.circle")
                }

                Menu {
                    Button {
                        editMode = editMode == .active ? .inactive : .active
                    } label: {
                        Label(editMode == .active ? "選択終了" : "選択モード",
                              systemImage: "checkmark.circle")
                    }

                    if !selected.isEmpty {
                        Button("選択項目を削除", role: .destructive) {
                            showDeleteConfirm = true
                        }
                        Button {
                            exportAdif(selected)
                        } label: {
                            Label("選択をADIF出力", systemImage: "square.and.arrow.up")
                        }
                    }

                    Divider()

                    Button {
                        exportAdif(nil)
                    } label: {
                        Label("全件ADIF出力", systemImage: "arrow.up.doc")
                    }
                    .disabled(entries.isEmpty)

                    Button("全件削除", role: .destructive) {
                        showClearConfirm = true
                    }
                    .disabled(entries.isEmpty)
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
            }
        }
        .confirmationDialog(
            "選択した\(selected.count)件を削除しますか?",
            isPresented: $showDeleteConfirm,
            titleVisibility: .visible
        ) {
            Button("削除", role: .destructive) {
                deleteSelected()
            }
            Button("キャンセル", role: .cancel) {}
        }
        .confirmationDialog(
            "全\(entries.count)件を削除しますか?",
            isPresented: $showClearConfirm,
            titleVisibility: .visible
        ) {
            Button("全件削除", role: .destructive) {
                QsoStore.save([])
                vm.ft8QsoLog = "[]"
                reload()
            }
            Button("キャンセル", role: .cancel) {}
        }
        .sheet(isPresented: $showLogEntry, onDismiss: reload) {
            LogQsoView(vm: vm)
        }
        .sheet(item: $editing) { e in
            QsoEditView(entry: e) { updated in
                updateEntry(updated)
            }
        }
        .onAppear { reload() }
    }

    // MARK: - Row view

    private func qsoRow(_ e: QsoEntry) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack {
                Text(e.call)
                    .font(.system(size: 13, design: .monospaced).bold())
                    .foregroundStyle(.white)
                Spacer()
                Text("\(QsoStore.freqToBand(e.freq))  \(e.mode)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            HStack(spacing: 6) {
                Text(formatDt(e.dt))
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundStyle(.secondary)
                let local = utcToLocal(e.dt)
                if !local.isEmpty {
                    Text("[\(local)]")
                        .font(.system(size: 10, design: .monospaced))
                        .foregroundStyle(Color(white: 0.55))
                }
            }
            HStack(spacing: 8) {
                Text("S:\(e.rstS) R:\(e.rstR)")
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundStyle(.secondary)
                if !e.yourPota.isEmpty { badge(e.yourPota, color: .green) }
                if !e.yourSota.isEmpty { badge(e.yourSota, color: .blue) }
                if !e.myPota.isEmpty   { badge("MY:\(e.myPota)", color: .teal) }
                if !e.mySota.isEmpty   { badge("MY:\(e.mySota)", color: .indigo) }
                if !e.jcc.isEmpty      { badge("JCC:\(e.jcc)", color: .orange) }
            }
            if !e.comment.isEmpty {
                Text(e.comment)
                    .font(.caption)
                    .foregroundStyle(.green)
            }
        }
        .padding(.vertical, 2)
        .listRowBackground(Color.black)
    }

    private func badge(_ text: String, color: Color) -> some View {
        Text(text)
            .font(.system(size: 9))
            .padding(.horizontal, 4)
            .padding(.vertical, 1)
            .background(color.opacity(0.25))
            .foregroundStyle(color)
            .cornerRadius(4)
    }

    // MARK: - Helpers

    private func reload() {
        entries = QsoStore.load()
        selected.removeAll()
    }

    private func deleteRows(at offsets: IndexSet) {
        var all = entries
        offsets.map { filtered[$0].id }.forEach { id in
            all.removeAll { $0.id == id }
        }
        QsoStore.save(all)
        vm.ft8QsoLog = QsoStore.jsonString()
        reload()
    }

    private func deleteSelected() {
        var all = entries
        all.removeAll { selected.contains($0.id) }
        QsoStore.save(all)
        vm.ft8QsoLog = QsoStore.jsonString()
        reload()
    }

    /// Replaces the entry with the same id and persists the whole log.
    private func updateEntry(_ updated: QsoEntry) {
        var all = entries
        guard let idx = all.firstIndex(where: { $0.id == updated.id }) else { return }
        all[idx] = updated
        QsoStore.save(all)
        vm.ft8QsoLog = QsoStore.jsonString()
        reload()
    }

    private func exportAdif(_ ids: Set<UUID>?) {
        let toExport: [QsoEntry]
        if let ids = ids {
            toExport = entries.filter { ids.contains($0.id) }
        } else {
            toExport = entries
        }
        guard !toExport.isEmpty else { return }
        let adif = QsoStore.buildAdif(toExport)
        let fmt = DateFormatter()
        fmt.dateFormat = "yyyyMMdd"
        fmt.timeZone = TimeZone(identifier: "UTC")
        let fname = "qso_\(fmt.string(from: Date())).adi"
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(fname)
        try? adif.write(to: url, atomically: true, encoding: .utf8)
        let av = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        if let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let vc = scene.windows.first?.rootViewController {
            av.popoverPresentationController?.sourceView = vc.view
            vc.present(av, animated: true)
        }
    }

    private func formatDt(_ dt: String) -> String {
        guard dt.count >= 12 else { return dt }
        let d = dt.prefix(8)
        let t = dt.dropFirst(8).prefix(4)
        return "\(d.prefix(4))-\(d.dropFirst(4).prefix(2))-\(d.dropFirst(6)) \(t.prefix(2)):\(t.dropFirst(2))Z"
    }
}

// MARK: - Edit sheet

/// Edit an existing QSO entry (equivalent to Android's long-press "QSO 修正" dialog).
private struct QsoEditView: View {
    @Environment(\.dismiss) private var dismiss
    let entry: QsoEntry
    let onSave: (QsoEntry) -> Void

    @State private var dtDate: String = ""
    @State private var dtTime: String = ""
    @State private var callsign: String = ""
    @State private var mode: String = ""
    @State private var rstSent: String = ""
    @State private var rstRcvd: String = ""
    @State private var yourPota: String = ""
    @State private var yourSota: String = ""
    @State private var myPota: String = ""
    @State private var mySota: String = ""
    @State private var jcc: String = ""
    @State private var jgc: String = ""
    @State private var comment: String = ""

    private var rstPresets: [String] {
        let m = mode.uppercased()
        if m.contains("CW") { return (1...9).map { "5\($0)9" } }
        if m.hasPrefix("FT") || m == "RTTY" { return ["-20", "-15", "-10", "-05", "00", "+05", "+10"] }
        return (1...9).map { "5\($0)" }
    }

    @ViewBuilder
    private func rstChipsView(setter: @escaping (String) -> Void) -> some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 4) {
                ForEach(rstPresets, id: \.self) { v in
                    Button(v) { setter(v) }
                        .font(.system(size: 11, design: .monospaced))
                        .foregroundStyle(.cyan)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 3)
                        .background(Color(white: 0.15), in: RoundedRectangle(cornerRadius: 4))
                        .buttonStyle(.plain)
                }
            }
        }
        .frame(height: 26)
    }

    private var localTimeStr: String {
        let s = utcToLocal(dtDate + dtTime)
        return s.isEmpty ? "" : "Local: \(s)"
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("QSO情報") {
                    LabeledContent("周波数") {
                        Text(entry.freq > 0
                            ? String(format: "%.3f MHz  %@", Double(entry.freq) / 1_000_000.0,
                                     QsoStore.freqToBand(entry.freq))
                            : "---")
                            .font(.system(size: 15, design: .monospaced))
                            .foregroundStyle(.cyan)
                    }
                    HStack {
                        Text("モード").foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
                        TextField("CW", text: $mode)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .keyboardType(.asciiCapable)
                            .font(.system(size: 15, design: .monospaced))
                            .onChange(of: mode) { _, v in mode = v.uppercased() }
                    }
                }

                Section {
                    HStack(spacing: 8) {
                        TextField("yyyyMMdd", text: $dtDate)
                            .keyboardType(.numberPad)
                            .font(.system(size: 15, design: .monospaced))
                            .frame(maxWidth: .infinity)
                        TextField("HHmmss", text: $dtTime)
                            .keyboardType(.numberPad)
                            .font(.system(size: 15, design: .monospaced))
                            .frame(maxWidth: .infinity)
                    }
                    if !localTimeStr.isEmpty {
                        Text(localTimeStr)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                } header: {
                    Text("日時 UTC  (yyyyMMdd  HHmmss)")
                }

                Section("相手局") {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("DX コールサイン").font(.caption).foregroundStyle(.secondary)
                        TextField("JA2ABC", text: $callsign)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .keyboardType(.asciiCapable)
                            .font(.system(size: 22, weight: .bold, design: .monospaced))
                            .foregroundStyle(.yellow)
                            .onChange(of: callsign) { _, v in
                                callsign = v.uppercased()
                                    .filter { $0.isLetter && $0.asciiValue != nil || $0.isNumber || $0 == "/" }
                            }
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        HStack {
                            Text("RST 送信").foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
                            TextField("599", text: $rstSent)
                                .autocorrectionDisabled()
                                .textInputAutocapitalization(.characters)
                                .font(.system(size: 17, design: .monospaced))
                        }
                        rstChipsView { rstSent = $0 }
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        HStack {
                            Text("RST 受信").foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
                            TextField("599", text: $rstRcvd)
                                .autocorrectionDisabled()
                                .textInputAutocapitalization(.characters)
                                .font(.system(size: 17, design: .monospaced))
                        }
                        rstChipsView { rstRcvd = $0 }
                    }
                }

                Section("相手局 POTA / SOTA") {
                    HStack {
                        Text("POTA").foregroundStyle(.secondary).frame(width: 60, alignment: .leading)
                        TextField("JP-XXXX", text: $yourPota)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .onChange(of: yourPota) { _, v in yourPota = v.uppercased() }
                    }
                    HStack {
                        Text("SOTA").foregroundStyle(.secondary).frame(width: 60, alignment: .leading)
                        TextField("JA/NN-001", text: $yourSota)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .onChange(of: yourSota) { _, v in yourSota = v.uppercased() }
                    }
                }

                Section("自局 POTA / SOTA") {
                    HStack {
                        Text("My POTA").foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
                        TextField("JP-XXXX", text: $myPota)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .onChange(of: myPota) { _, v in myPota = v.uppercased() }
                    }
                    HStack {
                        Text("My SOTA").foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
                        TextField("JA/NN-001", text: $mySota)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .onChange(of: mySota) { _, v in mySota = v.uppercased() }
                    }
                }

                Section("JCC / JGC") {
                    HStack {
                        Text("JCC").foregroundStyle(.secondary).frame(width: 40, alignment: .leading)
                        TextField("1234", text: $jcc)
                            .keyboardType(.numberPad)
                        Text("JGC").foregroundStyle(.secondary).frame(width: 40, alignment: .leading)
                        TextField("12345", text: $jgc)
                            .keyboardType(.numberPad)
                    }
                }

                Section("コメント") {
                    TextField("メモ・コメント", text: $comment)
                }
            }
            .navigationTitle("QSO 修正: \(entry.call)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("キャンセル") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") { save() }
                        .disabled(callsign.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
        }
        .onAppear { load() }
    }

    private func load() {
        dtDate   = String(entry.dt.prefix(8))
        dtTime   = String(entry.dt.dropFirst(8).prefix(6))
        callsign = entry.call
        mode     = entry.mode
        rstSent  = entry.rstS
        rstRcvd  = entry.rstR
        yourPota = entry.yourPota
        yourSota = entry.yourSota
        myPota   = entry.myPota
        mySota   = entry.mySota
        jcc      = entry.jcc
        jgc      = entry.jgc
        comment  = entry.comment
    }

    private func save() {
        func t(_ s: String) -> String { s.trimmingCharacters(in: .whitespaces) }
        func orKeep(_ s: String, _ old: String) -> String { s.isEmpty ? old : s }
        var e = entry
        let dt = (t(dtDate) + t(dtTime)).padding(toLength: 14, withPad: "0", startingAt: 0)
        e.dt       = dt
        e.call     = orKeep(t(callsign).uppercased(), entry.call)
        e.mode     = orKeep(t(mode).uppercased(), entry.mode)
        e.rstS     = orKeep(t(rstSent), entry.rstS)
        e.rstR     = orKeep(t(rstRcvd), entry.rstR)
        e.yourPota = t(yourPota).uppercased()
        e.yourSota = t(yourSota).uppercased()
        e.myPota   = t(myPota).uppercased()
        e.mySota   = t(mySota).uppercased()
        e.jcc      = t(jcc)
        e.jgc      = t(jgc)
        e.comment  = t(comment)
        onSave(e)
        dismiss()
    }
}
