import Foundation

/// Software AFSK RTTY modem.
/// RX: Goertzel-based mark/space detector → ITA2 (Baudot) state machine.
/// TX: generates continuous-phase FSK audio samples.
///
/// Port of Android RttyModem.kt.
final class RttyModem {
    let sampleRate: Int
    private(set) var markHz: Double
    private(set) var spaceHz: Double
    let baudRate: Double
    let samplesPerBit: Int

    private let onChar: (Character) -> Void

    // Goertzel coefficients
    private var markCoeff:  Double
    private var spaceCoeff: Double

    /// Full-bit circular buffer. The detector integrates over one whole bit, so the window
    /// ending at sample X measures exactly the bit that ended at X.
    private let halfStep: Int
    private var gbuf: [Double]
    private var gbWrite = 0

    /// How often the mark/space discriminator runs while hunting for a start bit. This sets
    /// how precisely the start-bit edge can be placed, and therefore how well the data-bit
    /// windows line up with the bits.
    private let edgeStep: Int

    // Demodulator state
    private var lastIsMark = true
    private enum FrameState { case idle, data }
    private var frameState = FrameState.idle
    private var frameData = 0
    private var isFigs = false

    /// Running sample index. Bit sampling is scheduled against this.
    private var total = 0
    /// Next sample index at which to run the discriminator while idle.
    private var nextEval = 0
    /// Sample index at which the current bit should be sampled.
    private var sampleAt = 0
    /// Data bit being collected (0...4), then 5 for the stop bit.
    private var bitIndex = 0
    /// Estimated sample index at which the start bit began.
    private var startIndex = 0

    init(sampleRate: Int = 8000,
         markHz: Double = 2125.0,
         spaceHz: Double = 2295.0,
         baudRate: Double = 45.45,
         onChar: @escaping (Character) -> Void) {
        self.sampleRate = sampleRate
        self.markHz     = markHz
        self.spaceHz    = spaceHz
        self.baudRate   = baudRate
        self.onChar     = onChar
        samplesPerBit   = Int((Double(sampleRate) / baudRate).rounded())
        halfStep        = samplesPerBit / 2
        edgeStep        = max(1, samplesPerBit / 16)
        gbuf            = [Double](repeating: 0, count: samplesPerBit)
        markCoeff  = 2.0 * Foundation.cos(2.0 * .pi * markHz  / Double(sampleRate))
        spaceCoeff = 2.0 * Foundation.cos(2.0 * .pi * spaceHz / Double(sampleRate))
        // Let the integration buffer fill before trusting the discriminator.
        nextEval = samplesPerBit
    }

    /// Feed raw 16-bit PCM.
    ///
    /// Bit sampling is scheduled on the running sample index, measured from the detected
    /// start-bit edge. A free-running half-bit tick does not work here: the integration
    /// window is a full bit, so whenever the tick grid happens to sit half a bit out of
    /// phase with the start bit, every data-bit window straddles two adjacent bits and the
    /// frame decodes to noise. That phase depends on where the character happens to fall in
    /// the sample stream, so roughly half of all frames were corrupted.
    func feed(_ samples: [Int16]) {
        for s in samples {
            gbuf[gbWrite] = Double(s) / 32768.0
            gbWrite = (gbWrite + 1) % samplesPerBit
            total += 1

            switch frameState {
            case .idle:
                guard total >= nextEval else { break }
                nextEval = total + edgeStep
                let isMark = goertzelMark()
                if lastIsMark && !isMark {
                    // The full-bit window reads half mark / half space exactly when the
                    // edge sits at its midpoint, so the transition is about half a bit
                    // behind the current sample.
                    startIndex = total - halfStep
                    frameState = .data
                    bitIndex   = 0
                    frameData  = 0
                    sampleAt   = startIndex + samplesPerBit * 2
                }
                lastIsMark = isMark

            case .data:
                guard total >= sampleAt else { break }
                let isMark = goertzelMark()
                if bitIndex < 5 {
                    // Frame layout in bit slots from the start of the start bit:
                    //   [0,1) start (space), [1,2)...[5,6) data bits 0...4,
                    //   [6,7.5) stop (mark).
                    // Data bit k is sampled at the end of its slot, where the full-bit
                    // window covers exactly that bit. ITA2 is LSB first; mark = 1.
                    if isMark { frameData |= (1 << bitIndex) }
                    bitIndex += 1
                    sampleAt = startIndex + samplesPerBit * (bitIndex + 2)
                } else {
                    // Stop bit must be mark; anything else means this was a false start.
                    frameState = .idle
                    lastIsMark = isMark
                    nextEval   = total + edgeStep
                    if isMark { decodeChar(frameData) }
                }
            }
        }
    }

    private func goertzelMark() -> Bool {
        var mq1 = 0.0, mq2 = 0.0
        var sq1 = 0.0, sq2 = 0.0
        var idx = gbWrite
        for _ in 0..<samplesPerBit {
            let s = gbuf[idx]; idx = (idx + 1) % samplesPerBit
            let qm = markCoeff  * mq1 - mq2 + s; mq2 = mq1; mq1 = qm
            let qs = spaceCoeff * sq1 - sq2 + s; sq2 = sq1; sq1 = qs
        }
        let mp = mq1*mq1 + mq2*mq2 - markCoeff  * mq1*mq2
        let sp = sq1*sq1 + sq2*sq2 - spaceCoeff * sq1*sq2
        return mp > sp
    }

    private func decodeChar(_ code: Int) {
        switch code {
        case Self.ltrsShift: isFigs = false
        case Self.figsShift: isFigs = true
        // Unshift on space, and on the two line-ending codes. Senders routinely fall back
        // to letters implicitly instead of transmitting another LTRS shift, and without
        // this a single figures shift invented by noise garbles every letter that follows
        // it until the next real LTRS: "ICOM" comes out as "8:9." while stuck in figures.
        case 4:  isFigs = false; onChar(" ")
        case 8:  isFigs = false; onChar("\r")
        case 2:  isFigs = false; onChar("\n")
        case 0:  break                     // NUL
        default:
            let c = isFigs ? Self.FIGS[code] : Self.LTRS[code]
            if c != " " { onChar(c) }
        }
    }

    func reset() {
        lastIsMark = true
        frameState = .idle
        isFigs     = false
        frameData  = 0
        bitIndex   = 0
        nextEval   = total + samplesPerBit
    }

    func updateFrequencies(markHz: Double, spaceHz: Double) {
        self.markHz  = markHz
        self.spaceHz = spaceHz
        markCoeff  = 2.0 * Foundation.cos(2.0 * .pi * markHz  / Double(sampleRate))
        spaceCoeff = 2.0 * Foundation.cos(2.0 * .pi * spaceHz / Double(sampleRate))
        // Clear the sample history so the new coefficients take effect immediately, and
        // hold the discriminator off until it refills. Any frame in progress is abandoned:
        // its remaining bits would be measured through a window that is part stale.
        gbuf = [Double](repeating: 0, count: samplesPerBit)
        gbWrite = 0
        frameState = .idle
        lastIsMark = true
        nextEval = total + samplesPerBit
    }

    // MARK: - TX tones

    /// Standard AFSK RTTY tone pair: 2125 Hz mark with a 170 Hz shift.
    ///
    /// Transmission must always use these fixed values. The receive side retunes itself to
    /// follow whatever is coming in, so its mark/space wander with the received signal, and
    /// feeding those moving values into the encoder made the transmitted frequency shift a
    /// little on every transmission. With fixed tones the transmit frequency depends only
    /// on the dial. To answer a station that is off frequency, move the dial.
    static let txMarkHz  = 2125.0
    static let txShiftHz = 170.0
    static var txSpaceHz: Double { txMarkHz + txShiftHz }

    // MARK: - TX encoder

    func encode(text: String, amplitude: Double = 0.8) -> [Int16] {
        let spb  = samplesPerBit
        let stop = Int((Double(spb) * 1.5).rounded())
        var buf: [Int16] = []
        var phase = 0.0
        var txFigs = false

        func tone(_ isMark: Bool, _ count: Int) {
            let freq   = isMark ? markHz : spaceHz
            let dPhase = 2.0 * .pi * freq / Double(sampleRate)
            for _ in 0..<count {
                buf.append(Int16(Int(sin(phase) * amplitude * Double(Int16.max))))
                phase += dPhase
            }
        }

        func sendCode(_ code: Int) {
            tone(false, spb)
            for b in 0..<5 { tone((code >> b) & 1 == 1, spb) }
            tone(true, stop)
        }

        // Leading MARK idle, about half a second. Three bits was not enough: the receiver
        // needs a steady mark to settle its start-bit edge detector on before real data
        // arrives, and the transmitter's own attack eats the beginning. Operators send a long
        // idle here for exactly this reason.
        tone(true, spb * 24)

        /// Sends a shift twice.
        ///
        /// Setting the shift is idempotent at the receiver, so the repeat costs one character
        /// and makes a single lost character harmless. Losing a shift is not harmless: every
        /// letter after it is looked up in the wrong table, so one dropped character corrupts
        /// the rest of the message. Observed on the air as `JI1ORE` arriving as `JI143`, where
        /// the LTRS after the `1` went missing and R and E were read from the figures table as
        /// `4` and `3`.
        func sendShift(_ code: Int) {
            sendCode(code)
            sendCode(code)
        }

        sendShift(Self.ltrsShift)

        for c in text.uppercased() {
            // Space and the two control codes mean the same thing in both shifts, so they
            // are sent directly. Looking them up in the tables would match a reserved slot
            // instead — space would match NUL at code 0, which the receiver discards, so
            // every space in the message was silently lost.
            // txFigs is NOT reset here: MMTTY and most decoders keep the current shift
            // through a space. Resetting it caused the encoder to skip the LTRS shift before
            // letters following a digit run (e.g. "599 JI1ORE" → "`81ORE" in MMTTY).
            switch c {
            case " ":  sendCode(4); continue
            case "\n": sendCode(2); continue
            case "\r": sendCode(8); continue
            default: break
            }
            var code = -1
            var needFigs = false
            for i in Self.LTRS.indices where !Self.reservedCodes.contains(i) {
                if Self.LTRS[i] == c { code = i; break }
            }
            if code < 0 {
                for i in Self.FIGS.indices where !Self.reservedCodes.contains(i) {
                    if Self.FIGS[i] == c { code = i; needFigs = true; break }
                }
            }
            guard code >= 0 else { continue }
            if needFigs && !txFigs { sendShift(Self.figsShift); txFigs = true }
            else if !needFigs && txFigs { sendShift(Self.ltrsShift); txFigs = false }
            sendCode(code)
        }
        // Trailing MARK idle, about half a second, so the receiver has a clean stop bit after
        // the last character and nothing is lost to the PTT release transient.
        tone(true, spb * 24)
        return buf
    }

    // MARK: - Spectrum scan

    static let SCAN_LO   = 1200
    static let SCAN_HI   = 3200
    static let SCAN_STEP = 20
    static let SCAN_BINS = 101

    static func scanPowers(_ samples: [Int16], sampleRate: Int) -> [Double] {
        var powers = [Double](repeating: 0, count: SCAN_BINS)
        for b in 0..<SCAN_BINS {
            let f = Double(SCAN_LO + b * SCAN_STEP)
            let coeff = 2.0 * Foundation.cos(2.0 * .pi * f / Double(sampleRate))
            var q1 = 0.0, q2 = 0.0
            for s in samples {
                let q = coeff * q1 - q2 + Double(s) / 32768.0
                q2 = q1; q1 = q
            }
            powers[b] = q1*q1 + q2*q2 - coeff*q1*q2
        }
        return powers
    }

    /// Finds a mark/space tone pair in a `scanPowers` spectrum, or nil when there is no
    /// convincing RTTY signal present.
    ///
    /// The previous version returned a pair for almost any input. It accepted the strongest
    /// bin if it was five times the *mean* power, which the maximum of a hundred noise bins
    /// exceeds routinely, and then took the next-strongest bin anywhere else as the partner
    /// with no strength test at all. On noise that produced a random pair every analysis; on
    /// a real signal whose space tone was attenuated it paired the mark with its own
    /// Goertzel sidelobe 80 Hz away. The receiver then retuned to that pair several times a
    /// second, resetting the demodulator each time, so the decoder never ran at the right
    /// frequencies for long enough to read a character. Seen in the log as a `shift` reading
    /// wandering between 80 and 420 Hz while the actual signal sat at a steady 170.
    ///
    /// Four rules fix that. The partner is searched only where a real space tone can be, one
    /// RTTY shift away on either side, so a bin next to the mark is never a candidate. The
    /// partner must be a local maximum, so the smooth leakage skirt of a lone strong tone does
    /// not qualify. The partner must be within 18 dB of the main peak, which keeps a space
    /// tone attenuated by the rig's receive filter (the FT-991A case) while rejecting
    /// leakage, which sits far below that. And the noise reference is *in-band*: the mean of
    /// the bins near the main peak, excluding the two peaks themselves.
    ///
    /// That last rule matters more than it looks. A global median was tried first and failed
    /// in practice: the rig's 500 Hz RTTY filter concentrates all the noise into about 25 of
    /// the 101 scan bins, so the median comes from the near-silent out-of-band bins and every
    /// in-band noise bump clears "8× the median". The log showed pairs reported on pure
    /// noise, mark readings scattered 1960-2320 Hz, exactly as before. Measured against the
    /// local in-band mean instead, the maximum of ~25 noise bins is only 3-4× the mean, while
    /// a real tone is far above it. Verified on synthetic band-limited noise: six noise-only
    /// spectra all return nil (the median rule returned a random pair for every one), and a
    /// clean pair, a weak-space pair, an off-frequency pair and an inverted RTTY-R pair all
    /// lock.
    static let pairShiftHz     = 170.0
    static let pairShiftTolHz  = 30.0
    static let pairMainSnr     = 8.0
    static let pairPartnerSnr  = 4.0
    static let pairMaxRatio    = 64.0
    static let pairNoiseSpan   = 12      // bins either side of the main peak

    static func findPeaks(_ powers: [Double]) -> (Double, Double)? {
        guard powers.count == SCAN_BINS,
              let p1 = powers.indices.max(by: { powers[$0] < powers[$1] }) else { return nil }

        let minBins = Int(((pairShiftHz - pairShiftTolHz) / Double(SCAN_STEP)).rounded(.down))
        let maxBins = Int(((pairShiftHz + pairShiftTolHz) / Double(SCAN_STEP)).rounded(.up))
        func isLocalMax(_ i: Int) -> Bool {
            (i == 0 || powers[i] >= powers[i - 1]) &&
            (i == powers.count - 1 || powers[i] >= powers[i + 1])
        }
        let candidates = powers.indices.filter { i in
            let d = abs(i - p1)
            return d >= minBins && d <= maxBins && isLocalMax(i)
        }
        guard let p2 = candidates.max(by: { powers[$0] < powers[$1] }) else { return nil }

        // In-band noise: bins around the main peak, minus the peaks and their neighbours.
        let nLo = max(0, p1 - pairNoiseSpan), nHi = min(powers.count - 1, p1 + pairNoiseSpan)
        var sum = 0.0, n = 0
        for i in nLo...nHi where abs(i - p1) > 1 && abs(i - p2) > 1 {
            sum += powers[i]; n += 1
        }
        guard n > 0 else { return nil }
        let noise = sum / Double(n)
        guard noise > 0,
              powers[p1] >= noise * pairMainSnr,
              powers[p2] >= noise * pairPartnerSnr,
              powers[p2] >= powers[p1] / pairMaxRatio else { return nil }

        let lo = min(p1, p2); let hi = max(p1, p2)
        return (Double(SCAN_LO + lo * SCAN_STEP), Double(SCAN_LO + hi * SCAN_STEP))
    }

    // MARK: - ITA2 tables

    /// ITA2 shift codes.
    static let figsShift = 27
    static let ltrsShift = 31
    /// Slots that carry no printable letter or figure of their own: NUL, LF, SP, CR and the
    /// two shifts. The encoder must not match a character against these.
    static let reservedCodes: Set<Int> = [0, 2, 4, 8, 27, 31]

    /// Standard ITA2 letter assignments. These must match the wire codes other stations
    /// send, so they are not free to rearrange: a table shifted by two positions decodes a
    /// transmitted 'T' as 'C' and drops 'C' entirely.
    static let LTRS: [Character] = [
        " ", "E", "\n", "A", " ", "S", "I", "U",
        "\r", "D", "R", "J", "N", "F", "C", "K",
        "T", "Z", "L", "W", "H", "Y", "P", "Q",
        "O", "B", "G", " ", "M", "X", "V", " "
    ]
    /// US-TTY figures shift, as used on the amateur bands.
    static let FIGS: [Character] = [
        " ", "3", "\n", "-", " ", " ", "8", "7",
        "\r", "$", "4", "'", ",", "!", ":", "(",
        "5", "\"", ")", "2", "#", "6", "0", "1",
        "9", "?", "&", " ", ".", "/", ";", " "
    ]
}
