import Foundation
import Darwin

/// Sends one finite 16-bit PCM mono buffer to `POST /radio/audio_tx?rate=N` on the Pi, paced
/// at real time, so an AFSK RTTY burst can be transmitted through the rig's audio input.
///
/// This is the only transmit path that works on either of the two rigs in this setup:
///
/// - The IC-705 has no external FSK shift input at all. Its USB ports are CDC-ACM, so
///   toggling DTR keys nothing. The Pi still returns HTTP 200 and no RF appears.
/// - The FT-991A does accept DTR as FSK shift, but the keying is timed in software on the
///   Pi, and each DTR change costs a USB control transfer of 15–50 ms against a 22 ms bit
///   period at 45.45 baud. Measured: 27 characters took 8.2 s and 15.1 s against an expected
///   5.3 s, so the effective baud rate was wrong and nothing could decode it.
///
/// Audio, by contrast, is clocked by the sound card, so the bit timing is exact regardless of
/// how loaded the Pi is.
///
/// Implementation notes, carried over from `CwAudioStream` where they were established:
/// - `uploadTask(withStreamedRequest:)` is the only API path that honors `httpBodyStream`.
///   `uploadTask(with:from:)` overrides it and the `OutputStream` writes block forever.
/// - The producer runs on a dedicated `DispatchQueue`, not a Swift `Task`, because a blocked
///   write on a cooperative thread freezes unrelated app work.
/// - `hasSpaceAvailable` is polled with a short sleep rather than blocking on write.
final class RttyPiAudioTx: NSObject, @unchecked Sendable {

    private let producerQueue = DispatchQueue(label: "rtty.audio.tx", qos: .userInitiated)

    /// Streams `pcm` and returns once the whole buffer has been handed to the Pi, or throws.
    /// `pcm` is little-endian signed 16-bit mono at `sampleRate`.
    ///
    /// Returns how long the handover took. The caller needs this because the audio keeps
    /// playing on the Pi after the last byte is written, so PTT has to be held for the
    /// remainder of the buffer's duration.
    @discardableResult
    func send(pcm: Data, host: String, apiPort: Int, apiKey: String,
              sampleRate: Int) async throws -> TimeInterval {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<TimeInterval, Error>) in
            producerQueue.async {
                do {
                    let elapsed = try self.sendSync(pcm: pcm, host: host, apiPort: apiPort,
                                                    apiKey: apiKey, sampleRate: sampleRate)
                    cont.resume(returning: elapsed)
                } catch {
                    cont.resume(throwing: error)
                }
            }
        }
    }

    // MARK: - Runs on `producerQueue`

    private func sendSync(pcm: Data, host: String, apiPort: Int, apiKey: String,
                          sampleRate: Int) throws -> TimeInterval {
        let resolved = Self.resolveIPv4(host) ?? host
        guard !resolved.isEmpty,
              let url = URL(string: "http://\(resolved):\(apiPort)/radio/audio_tx?rate=\(sampleRate)")
        else { throw URLError(.badURL) }

        var inS: InputStream?
        var outS: OutputStream?
        Stream.getBoundStreams(withBufferSize: 16384, inputStream: &inS, outputStream: &outS)
        guard let inputStream = inS, let outputStream = outS else {
            throw URLError(.cannotCreateFile)
        }
        outputStream.open()

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.httpBodyStream = inputStream
        req.setValue("application/octet-stream", forHTTPHeaderField: "Content-Type")
        // Omit Content-Length so URLSession uses chunked transfer encoding.
        if !apiKey.isEmpty { req.setValue(apiKey, forHTTPHeaderField: "X-API-Key") }

        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = TimeInterval.infinity
        config.timeoutIntervalForResource = TimeInterval.infinity
        // A delegate, so the response can be waited for. The Pi's `/radio/audio_tx` closes
        // aplay's stdin and then calls `proc.wait()`, so it answers only once every sample has
        // actually been played. That response is the exact end-of-transmission marker.
        let done = DispatchSemaphore(value: 0)
        let collector = Completion(done: done)
        let session = URLSession(configuration: config, delegate: collector, delegateQueue: nil)
        let task = session.uploadTask(withStreamedRequest: req)
        task.resume()

        defer { session.invalidateAndCancel() }

        // Deliberately NOT paced to real time. The first version wrote 10 ms chunks on a 10 ms
        // clock, which made the on-air bit timing depend on network jitter and on how busy the
        // Pi was: handing over 5.57 s of audio took between 12.4 s and 119 s, so aplay ran dry
        // repeatedly and the gaps destroyed the signal even though it sounded like RTTY.
        //
        // Instead, push as fast as back-pressure allows and let the sound card be the only
        // clock. aplay's stdin pipe and the ALSA buffer absorb the burst and play out at
        // exactly `sampleRate`, so the bit timing is exact no matter what the network does.
        let started = Date()
        let blockBytes = 4096
        var offset = 0

        while offset < pcm.count {
            var waited = 0
            while !outputStream.hasSpaceAvailable {
                // A full buffer is normal: it means the Pi is still draining what it has.
                // Only give up once it has clearly stopped draining altogether.
                if waited > 1000 { throw URLError(.timedOut) }
                Thread.sleep(forTimeInterval: 0.01)
                waited += 1
            }

            let end = min(offset + blockBytes, pcm.count)
            let written = pcm.withUnsafeBytes { raw -> Int in
                guard let base = raw.baseAddress else { return -1 }
                let p = base.advanced(by: offset).assumingMemoryBound(to: UInt8.self)
                return outputStream.write(p, maxLength: end - offset)
            }
            guard written > 0 else { throw URLError(.cannotWriteToFile) }
            offset += written
        }
        // End the request body, then wait for the Pi to answer. It answers after
        // `proc.wait()` on aplay, so the response means the audio has finished playing. The
        // previous version returned as soon as the last byte was handed to URLSession and the
        // caller then guessed the remaining time from the buffer duration. That guess was
        // short, because aplay does not start until the Pi has killed the capture processes
        // and spawned it, so PTT dropped before the tail played and the last character was
        // lost every time.
        outputStream.close()
        // Generous but bounded: the audio itself plus the Pi's start-up and drain.
        let budget = Double(pcm.count / 2) / Double(sampleRate) + 20.0
        if done.wait(timeout: .now() + budget) == .timedOut {
            throw URLError(.timedOut)
        }
        if let err = collector.error { throw err }
        return Date().timeIntervalSince(started)
    }

    /// Signals when the upload task finishes, so the transmission can be timed by the Pi's
    /// response rather than by guesswork.
    private final class Completion: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
        private let done: DispatchSemaphore
        private(set) var error: Error?
        private var signalled = false
        private let lock = NSLock()

        init(done: DispatchSemaphore) { self.done = done }

        func urlSession(_ session: URLSession, task: URLSessionTask,
                        didCompleteWithError error: Error?) {
            lock.lock(); defer { lock.unlock() }
            guard !signalled else { return }
            signalled = true
            if let error { self.error = error }
            else if let http = task.response as? HTTPURLResponse,
                    !(200..<300).contains(http.statusCode) {
                self.error = RigApiError.httpStatus(http.statusCode)
            }
            done.signal()
        }
    }

    /// Resolve hostname → IPv4 via getaddrinfo. iOS 26 URLSession will not resolve `.local`
    /// names for raw stream URLs, so the address has to be handed over already resolved.
    private static func resolveIPv4(_ host: String) -> String? {
        if host.isEmpty { return nil }
        var test = in_addr()
        if host.withCString({ inet_pton(AF_INET, $0, &test) }) == 1 { return host }
        var hints = addrinfo()
        hints.ai_family = AF_INET
        hints.ai_socktype = SOCK_STREAM
        hints.ai_protocol = IPPROTO_TCP
        var result: UnsafeMutablePointer<addrinfo>? = nil
        let rv = host.withCString { getaddrinfo($0, nil, &hints, &result) }
        guard rv == 0, let info = result else { return nil }
        defer { freeaddrinfo(info) }
        let sa = info.pointee.ai_addr.withMemoryRebound(to: sockaddr_in.self, capacity: 1) { $0.pointee }
        var addr = sa.sin_addr
        var buf = [CChar](repeating: 0, count: Int(INET_ADDRSTRLEN))
        guard inet_ntop(AF_INET, &addr, &buf, socklen_t(INET_ADDRSTRLEN)) != nil else { return nil }
        return String(cString: buf)
    }
}
