import SwiftUI

/// Thread-safe cancel flag polled by the Pi PCM streamer between chunks.
private nonisolated final class RttyCancelFlag: @unchecked Sendable {
    private let lock = NSLock()
    private var flag = false
    var isCancelled: Bool { lock.lock(); defer { lock.unlock() }; return flag }
    func cancel() { lock.lock(); flag = true; lock.unlock() }
}

// MARK: - Waterfall view

private struct RttyWaterfallView: View {
    let rows: [[Double]]
    let noiseEst: Double
    let peakEst: Double
    let markHz: Double
    let spaceHz: Double

    var body: some View {
        Canvas { ctx, size in
            guard size.width > 0, size.height > 0 else { return }
            let binW   = size.width / CGFloat(RttyModem.SCAN_BINS)
            let range  = max(peakEst - noiseEst, 1e-9)

            // Layout: top 40% = polyline spectrum (折れ線), bottom 60% = waterfall
            let specH: CGFloat = size.height * 0.4
            let wfY:   CGFloat = specH

            // ── Spectrum line ──────────────────────────────────────────────────
            ctx.fill(Path(CGRect(x: 0, y: 0, width: size.width, height: specH)),
                     with: .color(.black))

            if let lastRow = rows.last {
                let pts: [CGPoint] = lastRow.enumerated().map { i, p in
                    let c = CGFloat(min(max((p - noiseEst) / range, 0), 1))
                    return CGPoint(x: (CGFloat(i) + 0.5) * binW,
                                   y: specH * (1.0 - c * 0.88))  // 12% top margin
                }
                if let first = pts.first {
                    var line = Path(); var fill = Path()
                    line.move(to: first)
                    fill.move(to: CGPoint(x: first.x, y: specH))
                    fill.addLine(to: first)
                    for pt in pts.dropFirst() { line.addLine(to: pt); fill.addLine(to: pt) }
                    if let last = pts.last {
                        fill.addLine(to: CGPoint(x: last.x, y: specH))
                        fill.closeSubpath()
                    }
                    ctx.fill(fill, with: .color(Color.green.opacity(0.25)))
                    ctx.stroke(line, with: .color(.white), lineWidth: 1.5)
                }
            }

            // ── Waterfall ──────────────────────────────────────────────────────
            // Drawn as a single bitmap. Filling one Path per bin per row meant roughly
            // 10,000 CGPath allocations per redraw at ~8 redraws a second, which was a
            // large part of what made the UI freeze while RTTY audio was flowing.
            if let img = Self.waterfallImage(rows: rows, noiseEst: noiseEst, range: range) {
                ctx.draw(Image(decorative: img, scale: 1.0),
                         in: CGRect(x: 0, y: wfY,
                                    width: size.width, height: size.height - specH))
            }

            // ── Frequency markers (full height) ────────────────────────────────
            for (hz, col) in [(markHz, Color.yellow), (spaceHz, Color.cyan)] {
                let binF = (hz - Double(RttyModem.SCAN_LO)) / Double(RttyModem.SCAN_STEP)
                let x = CGFloat(binF) * binW + binW * 0.5
                guard x >= 0 && x <= size.width else { continue }
                var path = Path()
                path.move(to: CGPoint(x: x, y: 0))
                path.addLine(to: CGPoint(x: x, y: size.height))
                ctx.stroke(path, with: .color(col), lineWidth: 1.5)
            }
        }
    }

    /// Build the waterfall as one RGBA bitmap. `rows[0]` (the oldest row) becomes the top
    /// pixel row, which matches the previous per-rectangle drawing order.
    private static func waterfallImage(rows: [[Double]],
                                       noiseEst: Double,
                                       range: Double) -> CGImage? {
        guard let first = rows.first, !first.isEmpty else { return nil }
        let w = first.count
        let h = rows.count
        var px = [UInt8](repeating: 0, count: w * h * 4)
        for (ri, powers) in rows.enumerated() {
            let base = ri * w * 4
            for bi in 0..<w {
                let p = bi < powers.count ? powers[bi] : 0
                let c = min(max((p - noiseEst) / range, 0), 1)
                let (r, g, b) = waterfallRGB(c)
                let o = base + bi * 4
                px[o] = r; px[o + 1] = g; px[o + 2] = b; px[o + 3] = 255
            }
        }
        guard let provider = CGDataProvider(data: Data(px) as CFData) else { return nil }
        return CGImage(width: w, height: h,
                       bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: w * 4,
                       space: CGColorSpaceCreateDeviceRGB(),
                       bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue),
                       provider: provider, decode: nil,
                       shouldInterpolate: false, intent: .defaultIntent)
    }

    /// Same blue → cyan → green → yellow ramp the Path-based renderer used.
    private static func waterfallRGB(_ c: Double) -> (UInt8, UInt8, UInt8) {
        func q(_ v: Double) -> UInt8 { UInt8(max(0, min(255, v * 255))) }
        switch c {
        case ..<0.25:
            return (0, 0, q(c / 0.25 * 0.706))
        case ..<0.5:
            let t = (c - 0.25) / 0.25
            return (0, q(t * 0.863), q(0.706 + t * 0.294))
        case ..<0.75:
            let t = (c - 0.5) / 0.25
            return (q(t * 0.392), q(0.863 + t * 0.137), q(1.0 - t))
        default:
            let t = (c - 0.75) / 0.25
            return (q(0.392 + t * 0.608), 255, 0)
        }
    }
}

// MARK: - Off-main-thread RTTY DSP

/// Runs the RTTY modem and the spectrum scan on a private serial queue and publishes only
/// finished results to the MainActor.
///
/// This mirrors the Android implementation, where `modem.feed` and `scanPowers` run on
/// `Dispatchers.IO` and only the UI update hops to the main thread. Doing that work inline
/// on the MainActor broke RTTY two ways at once: the per-sample `@State` writes and the
/// Goertzel scan saturated the main thread (the screen froze), and starving `feed` made
/// sample delivery bursty, so the half-bit timing drifted and frames never assembled — the
/// tones were still detected and displayed, but no characters decoded.
private final class RttyProcessor: @unchecked Sendable {

    /// One waterfall row plus the derived display values, delivered together so the view
    /// does a single state update per row instead of one per audio chunk.
    struct Frame: Sendable {
        let powers: [Double]
        let noiseEst: Double
        let peakEst: Double
        let detectedMark: Double
        let detectedSpace: Double
        /// True when auto-tune moved the modem; the view mirrors the new mark/space.
        let autoTuned: Bool
        let levelDb: Double
        let chunks: Int
    }

    private static let peakBufSize = 2048

    private let queue = DispatchQueue(label: "rtty.dsp", qos: .userInitiated)
    private var modem: RttyModem?
    private var peakBuf = [Int16](repeating: 0, count: peakBufSize)
    private var peakPos = 0
    private var noiseEst = 1e-9
    private var peakEst  = 1e-6
    private var markHz   = 2125.0
    private var spaceHz  = 2295.0
    private var isRttyR  = false
    private var chunks   = 0
    private var levelDb  = -120.0
    /// Auto-tune hysteresis: the candidate pair, how many consecutive analyses it has held,
    /// and when the modem was last retuned. See `analyze()`.
    private var candMark   = 0.0
    private var candSpace  = 0.0
    private var candCount  = 0
    private var lastRetune = Date.distantPast
    /// When a convincing tone pair was last seen; drives the fall-back to the standard tones.
    private var lastPairSeen = Date()

    /// Both are invoked on the MainActor.
    var onChar:  ((Character) -> Void)?
    var onFrame: ((Frame) -> Void)?

    /// Create or replace the modem. Safe to call while audio is flowing.
    func restart(sampleRate: Int, markHz: Double, spaceHz: Double,
                 baud: Double, isRttyR: Bool) {
        queue.async { [self] in
            self.markHz   = markHz
            self.spaceHz  = spaceHz
            self.isRttyR  = isRttyR
            self.peakPos  = 0
            self.chunks   = 0
            self.noiseEst = 1e-9
            self.peakEst  = 1e-6
            // The modem retains this callback and the processor retains the modem, so the
            // capture has to be weak to avoid a cycle.
            self.modem = RttyModem(sampleRate: sampleRate, markHz: markHz,
                                   spaceHz: spaceHz, baudRate: baud) { [weak self] ch in
                self?.emit(ch)
            }
        }
    }

    func updateFrequencies(markHz: Double, spaceHz: Double) {
        queue.async {
            self.markHz  = markHz
            self.spaceHz = spaceHz
            self.modem?.updateFrequencies(markHz: markHz, spaceHz: spaceHz)
        }
    }

    /// Fix mode: when false, `analyze()` neither retunes to detected peaks nor falls back to
    /// the standard tones, so the decode position stays exactly where the operator put it.
    private var autoTune = true

    func setAutoTune(_ enabled: Bool) {
        queue.async {
            self.autoTune = enabled
            self.candCount = 0
            self.lastPairSeen = Date()
        }
    }

    func setRttyR(_ inverted: Bool) {
        queue.async { self.isRttyR = inverted }
    }

    func feed(_ samples: [Int16]) {
        guard !samples.isEmpty else { return }
        queue.async { self.process(samples) }
    }

    // MARK: - DSP queue

    private func process(_ samples: [Int16]) {
        chunks += 1
        let peakAbs = samples.reduce(0) { max($0, abs(Int($1))) }
        levelDb = 20.0 * log10(max(Double(peakAbs), 1.0) / 32768.0)
        modem?.feed(samples)

        var i = 0
        while i < samples.count {
            let take = min(samples.count - i, Self.peakBufSize - peakPos)
            for j in 0..<take { peakBuf[peakPos + j] = samples[i + j] }
            peakPos += take
            i += take
            if peakPos >= Self.peakBufSize {
                peakPos = 0
                analyze()
            }
        }
    }

    private func analyze() {
        let sr = modem?.sampleRate ?? 8000
        let p = RttyModem.scanPowers(peakBuf, sampleRate: sr)
        let avg = p.reduce(0, +) / Double(p.count)
        let mx  = p.max() ?? 0.0
        noiseEst = noiseEst * 0.98 + avg * 0.02
        peakEst  = mx > peakEst ? peakEst * 0.5 + mx * 0.5
                                : peakEst * 0.997 + mx * 0.003

        var dMark = 0.0, dSpace = 0.0, autoTuned = false
        if let (lo, hi) = RttyModem.findPeaks(p) {
            // For RTTY-R (inverted): higher tone = mark, lower = space.
            let m = isRttyR ? hi : lo
            let s = isRttyR ? lo : hi
            dMark = m; dSpace = s
            // Retune only to a pair that has held still. Every retune resets the demodulator
            // and abandons the frame in progress, so chasing each momentary peak costs more
            // characters than it saves. `findPeaks` already rejects noise and sidelobes; this
            // adds hysteresis on top: the same pair must be seen in consecutive analyses, it
            // must differ from the current tuning by more than one scan bin, and retunes are
            // spaced at least two seconds apart.
            let moved = abs(m - markHz) > 25 || abs(s - spaceHz) > 25
            if moved, autoTune {
                if abs(m - candMark) <= 25 && abs(s - candSpace) <= 25 {
                    candCount += 1
                } else {
                    candMark = m; candSpace = s; candCount = 1
                }
                let now = Date()
                if candCount >= 3,
                   now.timeIntervalSince(lastRetune) >= 2.0 {
                    markHz = m; spaceHz = s
                    modem?.updateFrequencies(markHz: m, spaceHz: s)
                    autoTuned = true
                    lastRetune = now
                    candCount = 0
                }
            } else {
                candCount = 0
            }
            lastPairSeen = Date()
        } else {
            candCount = 0
            // No convincing signal. If the modem was retuned away from the standard tones
            // and the signal that justified it has been gone for a while, go back to the
            // standard pair. Without this a single retune to a slightly off-frequency
            // station stuck for the rest of the session: the log showed `decodeAt=2200/2380`
            // persisting through a transmission that actually arrived at 2125/2295, 75 Hz off
            // and about 1.6 Goertzel bins wide of each tone, which decoded with errors while
            // the rig's own demodulator read the same signal cleanly.
            let stdMark  = isRttyR ? RttyModem.txSpaceHz : RttyModem.txMarkHz
            let stdSpace = isRttyR ? RttyModem.txMarkHz  : RttyModem.txSpaceHz
            let offStandard = abs(markHz - stdMark) > 25 || abs(spaceHz - stdSpace) > 25
            if offStandard, autoTune, Date().timeIntervalSince(lastPairSeen) >= 5.0 {
                markHz = stdMark; spaceHz = stdSpace
                modem?.updateFrequencies(markHz: stdMark, spaceHz: stdSpace)
                autoTuned = true
                dMark = stdMark; dSpace = stdSpace
                lastRetune = Date()
                lastPairSeen = Date()   // do not re-fire every analysis
                print("[RTTY RX] no signal for 5 s — back to standard \(Int(stdMark))/\(Int(stdSpace))")
            }
        }
        publish(Frame(powers: p, noiseEst: noiseEst, peakEst: peakEst,
                      detectedMark: dMark, detectedSpace: dSpace,
                      autoTuned: autoTuned, levelDb: levelDb, chunks: chunks))
    }

    private func emit(_ ch: Character) {
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            MainActor.assumeIsolated { self.onChar?(ch) }
        }
    }

    private func publish(_ frame: Frame) {
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            MainActor.assumeIsolated { self.onFrame?(frame) }
        }
    }
}

// MARK: - RttyView

struct RttyView: View {
    @Bindable var vm: MainViewModel
    /// Owns the modem and the spectrum scan on a background queue (see RttyProcessor).
    @State private var processor = RttyProcessor()
    /// Sample rate the modem was last built at, so it can be rebuilt if the Pi stream
    /// turns out to run at a different rate than the setting predicted.
    @State private var modemRate = 0
    @State private var rxDisplay = AttributedString()
    @State private var txText = ""
    @State private var pttOn = false
    @State private var isTxing = false
    @State private var waterfallRows: [[Double]] = []
    @State private var noiseEst = 1e-9
    @State private var peakEst  = 1e-6
    @State private var markHz  = 2125.0
    @State private var spaceHz = 2295.0
    @State private var detectedMark  = 0.0
    @State private var detectedSpace = 0.0
    /// Rate limiter for the `[RTTY RX] peak` log line in `applyFrame`.
    @State private var peakLogCounter = 0
    @State private var isRttyR = false
    @State private var baud: Double = 45.45
    @State private var status = ""
    @State private var txTask: Task<Void, Never>? = nil
    @State private var preMode = ""
    @State private var preWidth = 0
    @State private var showFreqInput = false   // 周波数手入力 (タップ)
    @State private var showMemSheet = false    // MEMSET (長押し)
    @State private var setupAsCiv = false
    @State private var rttyStartedAudio = false   // true if RTTY view started Pi audio (SPK was off)
    // RX audio diagnostics: chunks received since the view appeared, and the peak level
    // of the latest chunk. "No audio" here means the Pi/CI-V stream is not delivering.
    @State private var rxChunkCount = 0
    @State private var rxLevelDb = -120.0

    /// How the rig's dial relates to the RTTY signal in RTTY/RTTYR mode.
    /// Icom/Kenwood/Elecraft display the MARK frequency; Yaesu displays the carrier
    /// (zero-beat) point with the mark tone 2125 Hz away. Decides the TX dial offset.
    /// "auto" infers from the connection type / hamlib rig name; "mark" / "carrier" override.
    @AppStorage("rttyDialConvention") private var dialConvention = "auto"
    /// Fix mode. Long-press the Tune button to toggle. While fixed, auto-tune and the
    /// fall-back to the standard tones are off, and the decode position moves only when the
    /// operator taps the waterfall. Persisted so a fixed setting survives leaving the screen.
    @AppStorage("rttyTuneFixed") private var tuneFixed = false
    // Per-band carrier calibration for FT-991A (extra Hz added to the 865 Hz base dataShift).
    @AppStorage("rttyDataShiftOffsetHf")  private var rttyDataShiftOffsetHf  = 0
    @AppStorage("rttyDataShiftOffset50")  private var rttyDataShiftOffset50  = 0
    @AppStorage("rttyDataShiftOffset144") private var rttyDataShiftOffset144 = 0
    @AppStorage("rttyDataShiftOffset430") private var rttyDataShiftOffset430 = 0
    @State private var showCalibSheet = false
    @State private var showLogQso = false
    @State private var showAmplitudeSheet = false
    @State private var showPowerSheet = false
    @AppStorage("rttyTxAmplitude") private var rttyTxAmplitude: Double = 0.8
    @AppStorage("rttyCqTabActive") private var rttyCqTabActive = true
    @AppStorage("rttyRst") private var rttyRst = "599"
    @AppStorage("rttyCqLoopCount")    private var rttyCqLoopCount    = 3
    @AppStorage("rttyCqLoopInterval") private var rttyCqLoopInterval = 15
    @AppStorage("rttyCqCallRepeat")   private var rttyCqCallRepeat   = 1
    @AppStorage("rttyAnsCallRepeat")  private var rttyAnsCallRepeat  = 1
    @State private var repeatJob: Task<Void, Never>? = nil
    @State private var isRepeating = false
    @State private var repeatStatus = ""
    /// The rig's DATA-mode audio reference tone, in Hz: the audio frequency that its data-mode
    /// dial reading actually refers to. Subtracted from the mark offset.
    ///
    /// The app's model is that in PKTLSB the displayed frequency *is* the suppressed carrier,
    /// so an audio tone f lands at `display - f` and the dial has to sit one mark tone above
    /// the RTTY mark. That holds on the IC-705, which transmitted RTTY on frequency with no
    /// correction at all.
    ///
    /// The FT-991A's DATA SHIFT menu makes its dial refer to a 1000 Hz audio tone instead of
    /// the carrier, the convention PSK31 uses. A tone f therefore lands at `display - f + 1000`
    /// and the dial must sit only `2125 - 1000` above the RTTY mark, not the full 2125. The CAT
    /// path was already correct when this was found: the frequency read back as exactly the
    /// 144.602125 the app asked for, which rules out a control bug and leaves the rig's own
    /// shift as the only candidate.
    ///
    /// The sign was wrong on the first attempt. Adding this value instead of subtracting it
    /// made the error larger, which is what settled the direction: the original observation
    /// that 144.601 decoded while 144.600 did not was the *receiver* being retuned up to meet
    /// a signal already transmitting 1000 Hz high, not the transmitter needing to go up.
    ///
    /// Setting that menu to 0 on the rig makes this correction unnecessary, and then this
    /// should be 0 too.
    private var dataShiftHz: Int64 {
        guard vm.rigList.indices.contains(vm.selectedRigIndex) else { return 0 }
        switch vm.rigList[vm.selectedRigIndex].id {
        // FT-991A. 1000 Hz was the menu value and got the signal decoding; the receiver's
        // peak log then showed its mark arriving at about 2260 Hz instead of 2125, a residual
        // of +135 Hz in audio, which in LSB means the carrier was 135 Hz low. The space tone
        // at ~2430 Hz fell outside the IC-705's 500 Hz RTTY filter (about 1875–2375 Hz), which
        // is why that direction failed while the reverse was perfect. Raising the dial by 135
        // Hz is the same as lowering this value by 135. The 20 Hz scan-bin resolution puts the
        // true value within roughly ±20 Hz of this.
        //
        // Per-band calibration: FT-991A VHF/UHF uses different RF stages, so the effective
        // carrier offset differs per band. User-configurable offsets (default HF/50→0,
        // 144→+40, 430→-80) are stored in AppStorage and adjustable via the 補正 sheet.
        case 1035:
            switch vm.sharedFreq {
            case 50_000_000..<54_000_000:   return Int64(865 + rttyDataShiftOffset50)
            case 144_000_000..<148_000_000: return Int64(865 + rttyDataShiftOffset144)
            case 430_000_000..<440_000_000: return Int64(865 + rttyDataShiftOffset430)
            default:                         return Int64(865 + rttyDataShiftOffsetHf)
            }
        default: return 0
        }
    }

    private var dialShowsMark: Bool {
        switch dialConvention {
        case "mark":    return true
        case "carrier": return false
        default:        return true  // All modern rigs (Icom, Yaesu) display Mark in RTTY mode
        }
    }

    private var rxAudioLabel: String {
        guard rxChunkCount > 0 else { return "No audio from rig" }
        let peak = detectedMark > 0
            ? "Peak \(Int(detectedMark)) / \(Int(detectedSpace)) Hz"
            : "No signal"
        return peak + String(format: "  %.0f dBFS", rxLevelDb)
    }

    private static let maxWaterfallRows = 100

    private var isCivMode: Bool { vm.useCivMode && vm.civConnected }

    /// The transmit path, always decided automatically: CI-V when the radio is reached
    /// directly, otherwise AFSK audio through the Pi.
    ///
    /// There used to be a selector that also offered serial FSK keying. Neither rig here can
    /// use it. The IC-705 has no external FSK shift input, since its USB ports are CDC-ACM, so
    /// toggling DTR keys nothing while the Pi still returns HTTP 200. The FT-991A does accept
    /// DTR as FSK shift, but the Pi times the keying in software and every DTR change costs a
    /// USB control transfer of 15-50 ms against a 22 ms bit period at 45.45 baud. Measured for
    /// 27 characters, where 5.3 s was expected: 8.2, 15.1, 18.2, 30.5 s. It also saturated the
    /// shared CP2105 and starved rigctld's polling, taking CAT control down for about 16 s
    /// each time. There was nothing worth choosing, so the selector is gone.
    private var resolvedTxMode: String { isCivMode ? "civ" : "pi_afsk" }

    var body: some View {
        VStack(spacing: 0) {
            // Waterfall
            GeometryReader { geo in
                RttyWaterfallView(rows: waterfallRows, noiseEst: noiseEst, peakEst: peakEst,
                                  markHz: markHz, spaceHz: spaceHz)
                    .gesture(
                        DragGesture(minimumDistance: 0)
                            .onChanged { value in
                                // Only in Fix mode. In Tune mode the auto-tuner owns the
                                // decode position and would immediately override a tap.
                                guard tuneFixed else {
                                    status = "長押しでFIXにするとタップで位置を移動できます"
                                    return
                                }
                                let hz = Double(RttyModem.SCAN_LO)
                                    + value.location.x / geo.size.width
                                    * Double(RttyModem.SCAN_HI - RttyModem.SCAN_LO)
                                let shift = spaceHz - markHz
                                markHz  = max(Double(RttyModem.SCAN_LO),
                                              min(hz, Double(RttyModem.SCAN_HI) - shift))
                                spaceHz = markHz + shift
                                processor.updateFrequencies(markHz: markHz, spaceHz: spaceHz)
                                status = "FIX: \(Int(markHz)) / \(Int(spaceHz)) Hz"
                            }
                    )
            }
            .frame(height: 160)
            .background(Color.black)

            // Rig frequency display
            // Tap: direct frequency input / Long-press: memory recall (freq + mode)
            HStack {
                Text(formatRigFreq(vm.sharedFreq))
                    .font(.title3.monospacedDigit())
                    .foregroundStyle(.cyan)
                    .padding(.horizontal, 4)
                    .contentShape(Rectangle())
                    .onTapGesture { showFreqInput = true }
                    .onLongPressGesture(minimumDuration: 0.5) { showMemSheet = true }
                Spacer()
                Text(vm.sharedMode.isEmpty ? "---" : vm.sharedMode)
                    .font(.caption).foregroundStyle(.secondary)
                    .padding(.trailing, 8)
            }
            .padding(.horizontal, 8).padding(.vertical, 4)
            .background(Color(white: 0.12))

            // Peak freq info + RX audio diagnostics
            HStack {
                Text(rxAudioLabel)
                    .font(.caption)
                    .foregroundStyle(rxChunkCount > 0 ? Color.secondary : Color.red)
                Spacer()
                // Dial convention for the TX offset (see dialShowsMark). Cycles auto → mark → carrier.
                Button((dialShowsMark ? "Dial:Mark" : "Dial:Carrier") + (dialConvention == "auto" ? "*" : "")) {
                    dialConvention = switch dialConvention {
                        case "auto": "mark"; case "mark": "carrier"; default: "auto"
                    }
                }
                .buttonStyle(.bordered)
                .font(.caption)
                Button("補正") { showCalibSheet = true }
                    .buttonStyle(.bordered)
                    .font(.caption)
                    .tint(.green)
                // Tap: jump to the detected pair (Tune mode only). Long-press: toggle FIX,
                // which freezes the decode position where it is, stops auto-tune and the
                // standard-tone fall-back, and lets a tap on the waterfall move it instead.
                // Long-press again to hand control back to the auto-tuner.
                //
                // Not a `Button`. A disabled Button receives no gestures at all, and the first
                // version disabled itself whenever no tone pair was detected, which with the
                // new detector is most of the time on noise. The result was a control that
                // flickered between enabled and disabled several times a second and a long
                // press that was cancelled the moment the button went disabled under the
                // finger. A plain view with its own tap and long-press gestures is always
                // live; "nothing detected" is shown by dimming the label, not by disabling.
                Text(tuneFixed ? "FIX \(Int(markHz))/\(Int(spaceHz))" : "Tune")
                    .font(.caption)
                    .padding(.horizontal, 10).padding(.vertical, 5)
                    .background(
                        RoundedRectangle(cornerRadius: 6)
                            .fill(tuneFixed ? Color.orange.opacity(0.35) : Color.gray.opacity(0.25))
                    )
                    .foregroundStyle(tuneFixed ? Color.orange
                                     : (detectedMark > 0 ? Color.primary : Color.secondary))
                    .contentShape(Rectangle())
                    .onLongPressGesture(minimumDuration: 0.6) {
                        tuneFixed.toggle()
                        processor.setAutoTune(!tuneFixed)
                        status = tuneFixed
                            ? "FIX: \(Int(markHz)) / \(Int(spaceHz)) Hz — タップで移動、長押しで解除"
                            : "Tune: 自動追従に戻しました"
                    }
                    .onTapGesture {
                        guard !tuneFixed else {
                            status = "FIX中 — 長押しで解除、ウォーターフォールのタップで移動"
                            return
                        }
                        guard detectedMark > 0 else {
                            status = "Tune: 信号が検出されていません"
                            return
                        }
                        markHz  = detectedMark
                        spaceHz = detectedSpace
                        processor.updateFrequencies(markHz: markHz, spaceHz: spaceHz)
                        status = "Tuned: \(Int(markHz)) / \(Int(spaceHz)) Hz"
                    }
            }
            .padding(.horizontal, 8).padding(.vertical, 4)

            // Status
            Text(status)
                .font(.caption2).foregroundStyle(.yellow)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 8)

            // RX text (green RX, yellow TX)
            ScrollView {
                Text(rxDisplay.characters.isEmpty ? AttributedString(" ") : rxDisplay)
                    .font(.system(.body, design: .monospaced))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(6)
            }
            .frame(maxHeight: .infinity)
            .background(Color.black)

            Divider()

            // Controls
            HStack(spacing: 8) {
                Button(isRttyR ? "RTTYR" : "RTTY") {
                    isRttyR.toggle()
                    let tmp = markHz; markHz = spaceHz; spaceHz = tmp
                    processor.setRttyR(isRttyR)
                    processor.updateFrequencies(markHz: markHz, spaceHz: spaceHz)
                    Task { await vm.setMode(isRttyR ? "RTTYR" : "RTTY", width: 0) }
                }
                .buttonStyle(.bordered)

                Button(baud == 45.45 ? "45.45bd" : "75bd") {
                    baud = baud == 45.45 ? 75.0 : 45.45
                    restartModem()
                }
                .buttonStyle(.bordered)

                Button("Clear") {
                    rxDisplay = AttributedString()
                }
                .buttonStyle(.bordered)

                Button("−") {
                    let cur = Int((vm.sharedPower * 100).rounded())
                    let next = max(5, cur - 5)
                    Task { await vm.setPower(Double(next) / 100.0) }
                }
                .buttonStyle(.bordered).font(.caption).tint(.orange)
                Button("PWR \(Int(vm.sharedPower * 100))%") {
                    showPowerSheet = true
                }
                .buttonStyle(.bordered)
                .font(.caption)
                .tint(.orange)
                Button("+") {
                    let cur = Int((vm.sharedPower * 100).rounded())
                    let next = min(100, cur + 5)
                    Task { await vm.setPower(Double(next) / 100.0) }
                }
                .buttonStyle(.bordered).font(.caption).tint(.orange)

                // The TX-path selector is gone: the path is always chosen automatically.
                // CI-V when the radio is reached directly, otherwise AFSK audio through the
                // Pi. The serial FSK options it used to offer could not work on either rig
                // here and took CAT control down with them, so there was nothing to choose.

                Spacer()

                Button(pttOn ? "PTT ON" : "PTT") {
                    pttOn.toggle()
                    Task { await vm.setPtt(on: pttOn) }
                    if !pttOn { cancelTx() }
                    status = pttOn ? "PTT ON" : "PTT OFF"
                }
                .buttonStyle(.borderedProminent)
                .tint(pttOn ? .red : .blue)
            }
            .padding(.horizontal, 8)

            // PO meter
            HStack(spacing: 4) {
                Text("PO")
                    .font(.caption2).foregroundStyle(Color(red: 1, green: 0.43, blue: 0))
                    .fontWeight(.bold)
                    .frame(width: 28, alignment: .leading)
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Rectangle().fill(Color(white: 0.06))
                        Rectangle()
                            .fill(vm.sharedRfOut < 0.6 ? Color.orange :
                                  vm.sharedRfOut < 0.85 ? Color.yellow : Color.red)
                            .frame(width: geo.size.width * CGFloat(min(vm.sharedRfOut, 1.0)))
                    }
                    .clipShape(RoundedRectangle(cornerRadius: 2))
                }
                .frame(height: 8)
                Text("\(Int(vm.sharedRfOut * 100))%")
                    .font(.caption2).foregroundStyle(Color(red: 1, green: 0.43, blue: 0))
                    .frame(width: 28, alignment: .trailing)
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 2)

            // ALC meter
            HStack(spacing: 4) {
                Text("ALC")
                    .font(.caption2).foregroundStyle(.secondary)
                    .frame(width: 28, alignment: .leading)
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Rectangle().fill(Color(white: 0.08))
                        Rectangle()
                            .fill(vm.sharedAlc < 0.15 ? Color.green :
                                  vm.sharedAlc < 0.35 ? Color.yellow : Color.red)
                            .frame(width: geo.size.width * CGFloat(min(vm.sharedAlc, 1.0)))
                    }
                    .clipShape(RoundedRectangle(cornerRadius: 2))
                }
                .frame(height: 8)
                Text("\(Int(vm.sharedAlc * 100))%")
                    .font(.caption2).foregroundStyle(.secondary)
                    .frame(width: 28, alignment: .trailing)
            }
            .padding(.horizontal, 8)
            .padding(.vertical, 2)

            // RST preset buttons (their RST)
            HStack(spacing: 0) {
                Text("RST:")
                    .font(.caption2).foregroundStyle(.secondary)
                    .padding(.leading, 8).padding(.trailing, 4)
                ForEach(["519","529","539","549","559","569","579","589","599"], id: \.self) { v in
                    Button(v) { rttyRst = v }
                        .font(.system(size: 11, design: .monospaced))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 4)
                        .background(rttyRst == v ? Color(white: 0.28) : Color(white: 0.10))
                        .foregroundStyle(rttyRst == v ? Color.white : Color.secondary)
                        .buttonStyle(.plain)
                }
                .padding(.trailing, 8)
            }
            .padding(.vertical, 2)

            // CQ / ANS tab + command panels
            let call = vm.ft8MyCall.uppercased().isEmpty ? "MYCALL" : vm.ft8MyCall.uppercased()
            VStack(spacing: 0) {
                // Tab selector
                HStack(spacing: 0) {
                    Button("CQ") { rttyCqTabActive = true }
                        .frame(maxWidth: .infinity).padding(.vertical, 8)
                        .background(rttyCqTabActive
                                    ? Color(red: 0.165, green: 0.125, blue: 0)
                                    : Color(white: 0.08))
                        .foregroundStyle(rttyCqTabActive ? Color.yellow : Color.secondary)
                        .font(.callout.bold()).buttonStyle(.plain)
                    Button("ANS") { rttyCqTabActive = false }
                        .frame(maxWidth: .infinity).padding(.vertical, 8)
                        .background(!rttyCqTabActive
                                    ? Color(red: 0.165, green: 0.125, blue: 0)
                                    : Color(white: 0.08))
                        .foregroundStyle(!rttyCqTabActive ? Color.yellow : Color.secondary)
                        .font(.callout.bold()).buttonStyle(.plain)
                }

                if rttyCqTabActive {
                    // CQ panel
                    // Call repeat count (×1 / ×2 / ×3)
                    HStack(spacing: 3) {
                        ForEach([1, 2, 3], id: \.self) { n in
                            Button("Call×\(n)") { rttyCqCallRepeat = n }
                                .font(.caption2)
                                .frame(minWidth: 44, minHeight: 24)
                                .background(rttyCqCallRepeat == n ? Color(red:0.1,green:0.16,blue:0.1) : Color(white:0.1))
                                .foregroundStyle(rttyCqCallRepeat == n ? Color.white : Color.secondary)
                                .cornerRadius(4)
                                .buttonStyle(.plain)
                        }
                        Spacer()
                    }
                    .padding(.horizontal, 4).padding(.top, 4)
                    let callPart = (1...max(1, rttyCqCallRepeat)).map { _ in call }.joined(separator: " ")
                    let cqFull = "CQ CQ CQ DE \(callPart) K"
                    Button(cqFull) { txText = cqFull }
                        .buttonStyle(RttyMacroButtonStyle())
                        .padding(.horizontal, 4).padding(.top, 3)
                    HStack(spacing: 4) {
                        let dxk = "\(callPart) K"
                        let dxmy = "{dx} DE \(callPart) K"
                        Button(dxk)  { txText = dxk  }.buttonStyle(RttyMacroButtonStyle())
                        Button(dxmy) { txText = dxmy }.buttonStyle(RttyMacroButtonStyle())
                    }
                    .padding(.horizontal, 4).padding(.top, 3)
                    HStack(spacing: 4) {
                        let ur  = "UR \(rttyRst) \(call) K"
                        let tu  = "TU 73 E E"
                        let agn = "PSE AGN"
                        Button(ur)  { txText = ur  }.buttonStyle(RttyMacroButtonStyle())
                        Button(tu)  { txText = tu  }.buttonStyle(RttyMacroButtonStyle())
                        Button(agn) { txText = agn }.buttonStyle(RttyMacroButtonStyle())
                    }
                    .padding(.horizontal, 4).padding(.top, 3)
                    HStack(spacing: 4) {
                        let sign = "73 DE \(call) K"
                        let qrz  = "QRZ? DE \(call) K"
                        Button(sign) { txText = sign }.buttonStyle(RttyMacroButtonStyle())
                        Button(qrz)  { txText = qrz  }.buttonStyle(RttyMacroButtonStyle())
                    }
                    .padding(.horizontal, 4).padding(.top, 3)
                    // CQ Repeat controls
                    HStack(spacing: 3) {
                        Text("Loop:").font(.caption2).foregroundStyle(.secondary)
                        ForEach([3, 5, 10, 0], id: \.self) { n in
                            let label = n == 0 ? "∞" : "\(n)"
                            Button(label) { rttyCqLoopCount = n }
                                .font(.caption2)
                                .frame(minWidth: 28, minHeight: 24)
                                .background(rttyCqLoopCount == n ? Color(red:0.1,green:0.16,blue:0.1) : Color(white:0.1))
                                .foregroundStyle(rttyCqLoopCount == n ? Color.white : Color.secondary)
                                .cornerRadius(4)
                                .buttonStyle(.plain)
                        }
                        Text("Int:").font(.caption2).foregroundStyle(.secondary)
                        ForEach([10, 15, 30, 60], id: \.self) { s in
                            Button("\(s)s") { rttyCqLoopInterval = s }
                                .font(.caption2)
                                .frame(minWidth: 28, minHeight: 24)
                                .background(rttyCqLoopInterval == s ? Color(red:0.1,green:0.16,blue:0.1) : Color(white:0.1))
                                .foregroundStyle(rttyCqLoopInterval == s ? Color.white : Color.secondary)
                                .cornerRadius(4)
                                .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, 4).padding(.top, 3)
                    HStack {
                        if isRepeating && rttyCqTabActive {
                            Text(repeatStatus).font(.caption2).foregroundStyle(.yellow).lineLimit(1)
                            Spacer()
                        }
                        Button(isRepeating && rttyCqTabActive ? "■ STOP CQ" : "CQ REPEAT") {
                            if isRepeating && rttyCqTabActive {
                                stopRepeat()
                            } else {
                                let cp = (1...max(1, rttyCqCallRepeat)).map { _ in call }.joined(separator: " ")
                                startRepeat(text: "CQ CQ CQ DE \(cp) K",
                                            loopCount: rttyCqLoopCount,
                                            intervalSec: rttyCqLoopInterval)
                            }
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(isRepeating && rttyCqTabActive ? .red : Color(red:0.1,green:0.2,blue:0.4))
                        .font(.callout)
                    }
                    .padding(.horizontal, 4).padding(.top, 3).padding(.bottom, 3)
                } else {
                    // ANS panel
                    HStack(spacing: 4) {
                        let callPart = (1...max(1, rttyAnsCallRepeat)).map { _ in call }.joined(separator: " ")
                        let myk  = "\(callPart) K"
                        let dxmy = "{dx} DE \(callPart) K"
                        Button(myk)  { txText = myk  }.buttonStyle(RttyMacroButtonStyle())
                        Button(dxmy) { txText = dxmy }.buttonStyle(RttyMacroButtonStyle())
                    }
                    .padding(.horizontal, 4).padding(.top, 3)
                    HStack(spacing: 4) {
                        let ur  = "UR \(rttyRst) \(call) K"
                        let tu  = "TU 73 E E"
                        let agn = "PSE AGN"
                        Button(ur)  { txText = ur  }.buttonStyle(RttyMacroButtonStyle())
                        Button(tu)  { txText = tu  }.buttonStyle(RttyMacroButtonStyle())
                        Button(agn) { txText = agn }.buttonStyle(RttyMacroButtonStyle())
                    }
                    .padding(.horizontal, 4).padding(.top, 3)
                    HStack(spacing: 4) {
                        let sign = "73 DE \(call) K"
                        let qsl  = "QSL QSL"
                        Button(sign) { txText = sign }.buttonStyle(RttyMacroButtonStyle())
                        Button(qsl)  { txText = qsl  }.buttonStyle(RttyMacroButtonStyle())
                    }
                    .padding(.horizontal, 4).padding(.top, 3)
                    // ANS MyCall repeat count (×1 / ×2 / ×3)
                    HStack(spacing: 3) {
                        Text("Call:").font(.caption2).foregroundStyle(.secondary)
                        ForEach([1, 2, 3], id: \.self) { n in
                            Button("×\(n)") { rttyAnsCallRepeat = n }
                                .font(.caption2)
                                .frame(minWidth: 32, minHeight: 24)
                                .background(rttyAnsCallRepeat == n ? Color(red:0.1,green:0.16,blue:0.1) : Color(white:0.1))
                                .foregroundStyle(rttyAnsCallRepeat == n ? Color.white : Color.secondary)
                                .cornerRadius(4)
                                .buttonStyle(.plain)
                        }
                        Spacer()
                    }
                    .padding(.horizontal, 4).padding(.top, 3).padding(.bottom, 3)
                }
            }

            // TX input
            HStack {
                TextField("TX message", text: $txText)
                    .textFieldStyle(.roundedBorder)
                    .font(.system(.body, design: .monospaced))
                    .submitLabel(.send)
                    .onSubmit { startTx() }

                Button("\(Int((rttyTxAmplitude * 100).rounded()))%") { showAmplitudeSheet = true }
                    .buttonStyle(.bordered)
                    .font(.caption)
                    .frame(width: 46)

                Button(isTxing ? "■ Stop" : "TX") {
                    if isTxing { cancelTx() } else { startTx() }
                }
                .buttonStyle(.borderedProminent)
                .tint(isTxing ? .red : Color(red: 0.1, green: 0.36, blue: 0.165))
            }
            .padding(.horizontal, 8).padding(.bottom, 8)
        }
        .navigationTitle("RTTY")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button("LOG QSO") {
                        vm.pendingLogCallsign = ""
                        showLogQso = true
                    }
                    Button("LOG 一覧") { vm.path.append(.qsoLog) }
                } label: {
                    Image(systemName: "note.text.badge.plus")
                }
            }
        }
        .background(Color.black)
        .onAppear {
            setup()
            // A FIX left on from the previous visit must still hold the auto-tuner off.
            processor.setAutoTune(!tuneFixed)
        }
        .onDisappear { teardown() }
        .confirmationDialog("Power", isPresented: $showPowerSheet, titleVisibility: .visible) {
            let steps: [Double] = [0.05,0.10,0.20,0.30,0.40,0.50,0.60,0.70,0.80,0.90,1.00]
            ForEach(steps, id: \.self) { v in
                Button("\(Int(v * 100))%") { Task { await vm.setPower(v) } }
            }
        }
        .sheet(isPresented: $showFreqInput) { FreqInputView(vm: vm) }
        .sheet(isPresented: $showMemSheet) { MemoryPanelView(vm: vm) }
        .sheet(isPresented: $showLogQso) {
            LogQsoView(vm: vm, initCallsign: vm.pendingLogCallsign, initRstSent: "599")
        }
        .sheet(isPresented: $showAmplitudeSheet) {
            VStack(spacing: 16) {
                Text("TX Gain: \(Int((rttyTxAmplitude * 100).rounded()))%")
                    .font(.headline)
                Slider(value: $rttyTxAmplitude, in: 0.01...1.0, step: 0.01)
                    .padding(.horizontal)
                VStack(spacing: 8) {
                    HStack(spacing: 8) {
                        ForEach([10, 20, 30, 40, 50], id: \.self) { pct in
                            Button("\(pct)%") { rttyTxAmplitude = Double(pct) / 100.0 }
                                .buttonStyle(.bordered)
                                .font(.caption)
                                .frame(maxWidth: .infinity)
                                .tint(Int((rttyTxAmplitude * 100).rounded()) == pct ? .blue : .secondary)
                        }
                    }
                    HStack(spacing: 8) {
                        ForEach([60, 70, 80, 90, 100], id: \.self) { pct in
                            Button("\(pct)%") { rttyTxAmplitude = Double(pct) / 100.0 }
                                .buttonStyle(.bordered)
                                .font(.caption)
                                .frame(maxWidth: .infinity)
                                .tint(Int((rttyTxAmplitude * 100).rounded()) == pct ? .blue : .secondary)
                        }
                    }
                }
                .padding(.horizontal)
                Button("閉じる") { showAmplitudeSheet = false }
                    .buttonStyle(.borderedProminent)
            }
            .padding()
            .presentationDetents([.fraction(0.40)])
        }
        .sheet(isPresented: $showCalibSheet) {
            RttyCalibrationSheet(
                offsetHf:  $rttyDataShiftOffsetHf,
                offset50:  $rttyDataShiftOffset50,
                offset144: $rttyDataShiftOffset144,
                offset430: $rttyDataShiftOffset430
            )
        }
    }

    // MARK: - Setup / teardown

    private func setup() {
        preMode  = vm.sharedMode
        preWidth = vm.sharedWidth
        restartModem()
        Task { await vm.setMode(isRttyR ? "RTTYR" : "RTTY", width: 0) }
        startAudio()
        status = "RX"
    }

    private func teardown() {
        stopAudio()
        stopRepeat()
        cancelTx()
        if pttOn { Task { await vm.setPtt(on: false) } }
        if !preMode.isEmpty { Task { await vm.setMode(preMode, width: preWidth) } }
    }

    private func startRepeat(text: String, loopCount: Int, intervalSec: Int) {
        stopRepeat()
        isRepeating = true
        repeatJob = Task { @MainActor in
            var sent = 0
            while !Task.isCancelled {
                if loopCount > 0 && sent >= loopCount { break }
                sent += 1
                let countStr = loopCount == 0 ? "∞" : "\(sent)/\(loopCount)"
                repeatStatus = "TX \(countStr)…"
                txText = text
                startTx()
                while isTxing && !Task.isCancelled {
                    try? await Task.sleep(nanoseconds: 200_000_000)
                }
                if Task.isCancelled { break }
                if loopCount > 0 && sent >= loopCount { break }
                for remaining in stride(from: intervalSec, through: 1, by: -1) {
                    if Task.isCancelled { break }
                    repeatStatus = "TX \(countStr) — \(remaining)s"
                    try? await Task.sleep(nanoseconds: 1_000_000_000)
                }
            }
            isRepeating = false
            repeatStatus = ""
        }
    }

    private func stopRepeat() {
        repeatJob?.cancel()
        repeatJob = nil
        isRepeating = false
        repeatStatus = ""
    }

    private func formatRigFreq(_ hz: Int64) -> String {
        guard hz > 0 else { return "---.--- MHz" }
        return String(format: "%.3f MHz", Double(hz) / 1_000_000.0)
    }

    private func restartModem() {
        let rate = currentRxRate()
        modemRate = rate
        processor.onChar  = { [self] ch in appendRxToDisplay(ch) }
        processor.onFrame = { [self] frame in applyFrame(frame) }
        processor.restart(sampleRate: rate, markHz: markHz, spaceHz: spaceHz,
                         baud: baud, isRttyR: isRttyR)
        // Log the rate the decoder is actually running at. A decoder built for a different
        // rate than the stream delivers reads the wrong baud, which looks like scattered bit
        // errors rather than an obvious failure, so this is worth having in every log.
        print("[RTTY RX] modem rebuilt rate=\(rate) stream=\(vm.audioRxSampleRate) " +
              "mark=\(Int(markHz)) space=\(Int(spaceHz)) baud=\(baud) rttyR=\(isRttyR)")
        status = "RX (\(rate) Hz)"
    }

    /// Sample rate the demodulator must run at. A running stream is the ground truth, since
    /// its rate is what the samples actually arrive at; the SPK sampling setting is only a
    /// prediction until the stream reports itself.
    private func currentRxRate() -> Int {
        if isCivMode { return 8000 }
        let running = vm.audioRxSampleRate
        if running > 0 { return running }
        let idx = vm.selectedSamplingIndex
        let r   = AppConstants.samplingRates.indices.contains(idx)
                  ? AppConstants.samplingRates[idx] : 8000
        return r > 0 ? r : 8000
    }

    /// Rebuild the modem when the stream's real rate differs from the one it was built at.
    /// A mismatch leaves the Goertzel coefficients on the wrong frequencies, which still
    /// shows the tones in the waterfall but decodes nothing.
    private func syncModemRate(_ rate: Int) {
        guard rate > 0, rate != modemRate else { return }
        restartModem()
    }

    // MARK: - Audio routing

    private func startAudio() {
        setupAsCiv = isCivMode
        rxChunkCount = 0
        // The processor hands the samples straight to its own queue, so this callback stays
        // cheap no matter which thread delivers it.
        vm.rttyAudioHandler = { [processor] samples in
            processor.feed(samples)
        }
        if setupAsCiv {
            vm.civ.rxAudioCallback = { [processor] (data: Data) in
                guard data.count >= 2 else { return }
                let count = data.count / 2
                var samples = [Int16](repeating: 0, count: count)
                data.withUnsafeBytes { ptr in
                    for i in 0..<count {
                        let lo = UInt16(ptr[i * 2])
                        let hi = UInt16(ptr[i * 2 + 1])
                        samples[i] = Int16(bitPattern: lo | (hi << 8))
                    }
                }
                processor.feed(samples)
            }
        } else {
            vm.refreshAudioRxSampleDispatch()
            // Start Pi audio stream for RTTY unless SPK already runs it
            Task {
                switch await vm.ensurePiAudioStarted() {
                case .started(let rate):
                    rttyStartedAudio = true
                    syncModemRate(rate)
                    status = "RX audio started (\(rate) Hz)"
                case .alreadyRunning:
                    rttyStartedAudio = false
                    syncModemRate(vm.audioRxSampleRate)
                    status = "RX audio: using SPK stream"
                case .unavailable(let why):
                    rttyStartedAudio = false
                    status = "RX audio unavailable: \(why)"
                }
            }
        }
    }

    private func stopAudio() {
        vm.rttyAudioHandler = nil
        // Drop the callbacks so a sample still in flight on the DSP queue cannot publish
        // into a view that has already gone away.
        processor.onChar  = nil
        processor.onFrame = nil
        if setupAsCiv {
            vm.civ.rxAudioCallback = nil
        } else {
            vm.refreshAudioRxSampleDispatch()
            if rttyStartedAudio {
                rttyStartedAudio = false
                Task { await vm.stopPiAudioIfNotSpk() }
            }
        }
    }

    // MARK: - Sample processing

    /// Apply one finished spectrum row from the DSP queue. Called about 4–8 times a second
    /// rather than once per audio chunk, so the view redraws at a sane rate.
    private func applyFrame(_ frame: RttyProcessor.Frame) {
        rxChunkCount  = frame.chunks
        rxLevelDb     = frame.levelDb
        noiseEst      = frame.noiseEst
        peakEst       = frame.peakEst
        detectedMark  = frame.detectedMark
        detectedSpace = frame.detectedSpace
        // The processor already retuned the modem; mirror the values so the markers, the
        // status line and the TX dial offset agree with what is being decoded.
        if frame.autoTuned {
            markHz  = frame.detectedMark
            spaceHz = frame.detectedSpace
        }
        // Record where the tones actually land at this rig's audio output whenever a signal
        // is present (about once a second, and immediately on retune). The decisive number
        // for a one-way failure: if the other station's mark arrives at, say, 2250 Hz instead
        // of 2125, its carrier is off by that much and a 500 Hz receive filter will be
        // shaving one of the two tones.
        if frame.detectedMark > 0, frame.levelDb > -40 {
            peakLogCounter += 1
            if frame.autoTuned || peakLogCounter % 8 == 0 {
                print(String(format: "[RTTY RX] peak mark=%.0f space=%.0f shift=%.0f level=%.1fdBFS " +
                             "decodeAt=%.0f/%.0f autoTuned=%@",
                             frame.detectedMark, frame.detectedSpace,
                             frame.detectedSpace - frame.detectedMark, frame.levelDb,
                             markHz, spaceHz, frame.autoTuned ? "yes" : "no"))
            }
        }
        var rows = waterfallRows
        rows.append(frame.powers)
        if rows.count > Self.maxWaterfallRows { rows.removeFirst() }
        waterfallRows = rows
    }

    // MARK: - RX / TX display

    private func appendRxToDisplay(_ ch: Character) {
        if ch == "\r" { return }
        var a = AttributedString(String(ch))
        a.foregroundColor = .green
        rxDisplay += a
        trimDisplay()
    }

    private func appendTxToDisplay(_ text: String) {
        var a = AttributedString("\n" + text + "\n")
        a.foregroundColor = .yellow
        rxDisplay += a
        trimDisplay()
    }

    private func trimDisplay() {
        let count = rxDisplay.characters.count
        guard count > 1000 else { return }
        let drop = count - 800
        let idx = rxDisplay.index(rxDisplay.startIndex, offsetByCharacters: drop)
        rxDisplay = AttributedString(rxDisplay[idx...])
    }

    // MARK: - TX

    private func startTx() {
        // Used to return silently, which is indistinguishable from "the TX button does nothing".
        guard !txText.isEmpty else {
            status = "TX: 送信文がありません — 入力かプリセットを選択"
            return
        }
        guard !isTxing else { return }
        // Refuse to transmit while the dial is unknown. `sharedFreq` is 0 whenever the control
        // link has dropped, and a transmission started then went out with no frequency or mode
        // command at all, on whatever the rig happened to be tuned to. Seen in the log as
        // `txFreq=0 rxFreq=0`.
        guard vm.sharedFreq > 0 else {
            status = "TX: 周波数不明 — 接続が復帰するまで送信しません"
            return
        }
        let mode = resolvedTxMode
        if mode == "civ" && !isCivMode {
            status = "RTTY TX: CI-V未接続 — TX:AUTO または TX:DTR に切替"; return
        }
        cancelTx()
        let text              = txText
        let capturedBaud      = baud
        let capturedIsRttyR   = isRttyR
        let capturedFreq      = vm.sharedFreq
        let capturedCiv       = isCivMode
        let capturedAmplitude = min(1.0, max(0.1, rttyTxAmplitude))
        let civ               = vm.civ

        // AFSK RTTY convention: mark = lower tone, space = higher tone. On-air polarity is
        // set by the sideband, not by swapping tones:
        //   RTTY  (mark 170 Hz above space on air) → LSB-D, TX dial = RX dial + mark tone
        //   RTTYR (mark 170 Hz below space on air) → USB-D, TX dial = RX dial − mark tone
        // Rigs display the mark frequency in RTTY/RTTYR mode, so the transmitted mark lands
        // exactly on the RX dial and the space 170 Hz away on the correct side.
        // (RTTY itself is an FSK mode: audio does not modulate there, hence the data mode.)
        // Fixed standard tones, never the receiver's auto-tuned pair: those follow the
        // incoming signal, so using them here moved the transmitted frequency a little on
        // every transmission.
        let toneLo = RttyModem.txMarkHz
        let toneHi = RttyModem.txSpaceHz
        // CI-V (IC-705 WLAN): data mode, its DATA MOD input is already WLAN for FT8.
        // Pi/hamlib: plain SSB, because that is the audio path voice TX already uses on
        // the connected rig. On the FT-991A the DATA-mode input is a separate setting
        // (menu 070/072) from the SSB one (menu 104/107), so DATA-LSB can be silent
        // even though voice TX works.
        // Both CI-V and Pi paths use DATA mode (PKTLSB/PKTUSB): Pi audio is routed via the
        // rig's USB audio (DATA) port, same as FT8. Plain LSB would use the MIC input instead.
        let txModMode = capturedIsRttyR ? "PKTUSB" : "PKTLSB"
        let rxModMode  = capturedIsRttyR ? "RTTYR"  : "RTTY"
        // Dial = mark (Icom etc.): the SSB dial must sit one mark tone away from the
        // displayed RTTY frequency. Dial = carrier (Yaesu): the RTTY display already is
        // the SSB carrier point, so the same dial reproduces the FSK mark/space exactly.
        let markOffset: Int64 = dialShowsMark ? Int64(toneLo.rounded()) : 0
        // Less whatever the rig's own data-mode dial is shifted by. See `dataShiftHz`.
        let totalOffset = markOffset - dataShiftHz
        let txFreq: Int64 = capturedFreq > 0
            ? (capturedIsRttyR ? capturedFreq - totalOffset : capturedFreq + totalOffset)
            : 0
        // RS-BA1 CI-V audio is fixed at 8 kHz. The Pi path uses 48 kHz, the native rate of the
        // rig's USB codec, so ALSA's plug layer has nothing to resample.
        //
        // At 8 kHz the Pi ran `aplay -r 8000` through `plughw`, whose rate converter is a
        // linear interpolator. That is fine for voice but not for a two-tone FSK signal:
        // interpolating 2125 and 2295 Hz up to the codec rate adds harmonics and images
        // inside the SSB passband, which is what put a dirty, undecodable signal on the air.
        // The app's own buffer was measured clean at every rate (exactly 45.4545 baud, no
        // clipping, phase continuous, decodes back to the original text), so the distortion
        // could only have come from the resampler.
        let txRate = capturedCiv ? 8000 : 48000
        let encoder = RttyModem(sampleRate: txRate, markHz: toneLo, spaceHz: toneHi,
                                baudRate: capturedBaud) { _ in }
        let txBody = "RTRT \(text)\n"
        let pcm = encoder.encode(text: txBody, amplitude: capturedAmplitude).withUnsafeBytes { Data($0) }

        isTxing = true
        pttOn = true
        // Name the path in use, so "nothing came out" can be told apart from "the wrong path
        // was chosen". The duration is the honest expectation: AFSK plays in real time.
        let txSeconds = Double(pcm.count / 2) / Double(txRate)
        status = capturedCiv
            ? "TX: CI-V \(txModMode) — \(String(format: "%.1f", txSeconds))s"
            : "TX: AFSK via Pi \(txModMode) — \(String(format: "%.1f", txSeconds))s"
        appendTxToDisplay(txBody)
        txTask = Task {
            if capturedCiv {
                // Report each CI-V step: the PTT button and this path both end up in
                // civ.setPtt, so when one keys the rig and the other does not, the
                // difference has to be in the frequency/mode calls that run first.
                let setup = await Task.detached(priority: .userInitiated) { () -> (Bool, Bool) in
                    let fOK = txFreq > 0 ? civ.setFrequency(txFreq) : true
                    let mOK = civ.setMode(txModMode, width: 3000)
                    return (fOK, mOK)
                }.value
                let pttOK = await Task.detached(priority: .userInitiated) { civ.setPtt(true) }.value
                print("[RTTY TX] CI-V freq=\(txFreq) setFreq=\(setup.0) " +
                      "mode=\(txModMode) setMode=\(setup.1) setPtt=\(pttOK)")
                if !pttOK {
                    status = "TX: CI-V PTT rejected (mode=\(txModMode))"
                } else if !setup.1 {
                    status = "TX: CI-V mode change failed (\(txModMode))"
                }
                civ.stopTxAudioCapture()
                var offset = 0
                let chunkSize = 320   // 160 samples = 20 ms @ 8 kHz (RS-BA1 packet period)
                var nextMs = Int64(Date().timeIntervalSince1970 * 1000)
                while offset < pcm.count {
                    if Task.isCancelled { break }
                    let end = min(offset + chunkSize, pcm.count)
                    civ.sendTxAudioDirect(pcm.subdata(in: offset..<end))
                    offset = end
                    nextMs += 20
                    let sleepMs = nextMs - Int64(Date().timeIntervalSince1970 * 1000)
                    if sleepMs > 1 { try? await Task.sleep(nanoseconds: UInt64(sleepMs) * 1_000_000) }
                }
                try? await Task.sleep(nanoseconds: 600_000_000)
                _ = await Task.detached(priority: .userInitiated) { _ = civ.setPtt(false) }.value
                _ = await Task.detached(priority: .userInitiated) {
                    if capturedFreq > 0 { _ = civ.setFrequency(capturedFreq) }
                    _ = civ.setMode(rxModMode, width: 0)
                }.value
            } else if mode == "pi_afsk" {
                // AFSK through the Pi's audio output. The bit timing comes from the sound
                // card, so unlike serial FSK keying it does not depend on how loaded the Pi
                // is, and it works on rigs with no FSK shift input at all.
                print("[RTTY TX] AFSK via Pi \(pcm.count / 2) samples @\(txRate)Hz " +
                      "mode=\(txModMode) txFreq=\(txFreq) rxFreq=\(capturedFreq) " +
                      "mark=\(markOffset) dataShift=\(dataShiftHz)")
                // Stand the receiver down for the transmission. See `suspendPiAudioForTx`.
                let wasRunning = await vm.suspendPiAudioForTx()
                let err = await vm.rttyPiAudioTx(pcm: pcm, sampleRate: txRate,
                                                 txMode: txModMode, rxMode: rxModMode,
                                                 txFreq: txFreq, rxFreq: capturedFreq)
                print("[RTTY TX] AFSK result=\(err ?? "ok")")
                if let err { status = "TX: AFSK送信失敗 — \(err)" }
                if wasRunning {
                    if case .started(let rate) = await vm.ensurePiAudioStarted() {
                        syncModemRate(rate)
                    }
                }
            } else {
                // Every resolved mode now has a branch, so reaching here means a new mode was
                // added without one. Report it rather than silently doing nothing, which is
                // indistinguishable from "the TX button does nothing".
                print("[RTTY TX] no transmit path for mode=\(mode) — nothing sent")
                status = "TX: この接続では送信経路がありません (mode=\(mode))"
            }
            Task { @MainActor in restartModem(); isTxing = false; pttOn = false }
        }
    }

    private func cancelTx() {
        txTask?.cancel(); txTask = nil; isTxing = false
    }
}

// MARK: - Button styles

private struct RttyMacroButtonStyle: ButtonStyle {
    var color = Color(red: 0.165, green: 0.1, blue: 0.361)  // #2A1A5C
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.callout.bold())
            .lineLimit(1)
            .minimumScaleFactor(0.7)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 10)
            .background(color, in: RoundedRectangle(cornerRadius: 6))
            .foregroundStyle(.white.opacity(configuration.isPressed ? 0.6 : 1))
    }
}

// MARK: - Carrier calibration sheet (FT-991A per-band dataShift offset)

struct RttyCalibrationSheet: View {
    @Binding var offsetHf:  Int
    @Binding var offset50:  Int
    @Binding var offset144: Int
    @Binding var offset430: Int
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("FT-991A キャリア補正 (dataShift = 865 + オフセット)")) {
                    CalibRow(label: "HF (< 50MHz)", offset: $offsetHf)
                    CalibRow(label: "50 MHz",       offset: $offset50)
                    CalibRow(label: "144 MHz",      offset: $offset144)
                    CalibRow(label: "430 MHz",      offset: $offset430)
                }
                Section {
                    Button("デフォルトに戻す") {
                        offsetHf = 0; offset50 = 0; offset144 = 0; offset430 = 0
                    }
                    .foregroundStyle(.orange)
                }
                Section(footer: Text("±20 Hz ステップ。デフォルト: 全バンド 0")) {
                    EmptyView()
                }
            }
            .navigationTitle("RTTY 補正")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("閉じる") { dismiss() }
                }
            }
        }
    }
}

private struct CalibRow: View {
    let label: String
    @Binding var offset: Int

    var body: some View {
        HStack {
            Text(label).frame(minWidth: 100, alignment: .leading)
            Spacer()
            Button("−20") { offset -= 20 }
                .buttonStyle(.bordered).font(.caption)
            Text("\(offset >= 0 ? "+" : "")\(offset) Hz")
                .font(.system(.body, design: .monospaced))
                .frame(minWidth: 72, alignment: .center)
            Button("+20") { offset += 20 }
                .buttonStyle(.bordered).font(.caption)
        }
    }
}
