import SwiftUI
import Citadel
import NIOCore

struct SshSetupView: View {
    @Bindable var vm: MainViewModel

    @State private var host: String = ""
    @State private var sshUser: String = "pi"
    @State private var sshPassword: String = ""
    @State private var statusText: String = "Pi に SSH で接続してセットアップを実行します"
    @State private var statusColor: Color = .secondary
    @State private var logLines: [String] = []
    @State private var isRunning: Bool = false
    // VNC/デスクトップ選択: none(VNCなし) / xfce / pixel。Android と同じ UserDefaults キー。
    @AppStorage("vncDesktop") private var vncDesktop: String = "xfce"

    var body: some View {
        VStack(spacing: 0) {
            Form {
                Section(header: Label("Pi 接続先", systemImage: "network").foregroundStyle(.indigo)) {
                    LabeledContent("IP / Host") {
                        TextField("192.168.1.100 or raspberrypi.local", text: $host)
                            .multilineTextAlignment(.trailing)
                            .keyboardType(.URL)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                    }
                    LabeledContent("SSH User") {
                        TextField("pi", text: $sshUser)
                            .multilineTextAlignment(.trailing)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                    }
                    LabeledContent("SSH Password") {
                        SecureField("raspberry", text: $sshPassword)
                            .multilineTextAlignment(.trailing)
                    }
                }

                Section(header: Label("VNC デスクトップ", systemImage: "display").foregroundStyle(.indigo)) {
                    Picker("VNC", selection: $vncDesktop) {
                        Text("XFCE").tag("xfce")
                        Text("PIXEL").tag("pixel")
                        Text("なし").tag("none")
                    }
                    .pickerStyle(.segmented)
                }

                Section {
                    Text("⚠ 実行中は画面OFF・他の画面への移動をしないでください（Pi Zero 2W は 1 時間以上。UPDATE まで含めると約 1 時間30分かかります）")
                        .font(.caption)
                        .foregroundStyle(.orange)

                    Button {
                        Task { await runSetup() }
                    } label: {
                        HStack {
                            if isRunning { ProgressView().padding(.trailing, 4) }
                            Text(isRunning ? "セットアップ中..." : "Run Setup")
                                .frame(maxWidth: .infinity)
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.indigo)
                    .disabled(isRunning || host.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
            .frame(maxHeight: 360)

            Text(statusText)
                .font(.callout)
                .foregroundStyle(statusColor)
                .padding(.horizontal)
                .padding(.vertical, 4)

            ScrollViewReader { proxy in
                ScrollView {
                    Text(logLines.joined(separator: "\n"))
                        .font(.system(.caption, design: .monospaced))
                        .foregroundStyle(.green)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(8)
                        .id("logEnd")
                }
                .background(Color(white: 0.05))
                .onChange(of: logLines.count) { _, _ in
                    withAnimation { proxy.scrollTo("logEnd", anchor: .bottom) }
                }
            }
        }
        .navigationTitle("SETUP (SSH)")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            if host.isEmpty { host = vm.hostName }
        }
    }

    // MARK: - SSH setup

    @MainActor
    private func appendLog(_ line: String) {
        logLines.append(line)
    }

    @MainActor
    private func runSetup() async {
        let targetHost = host.trimmingCharacters(in: .whitespaces)
        guard !targetHost.isEmpty else { return }

        logLines = []
        isRunning = true
        statusText = "\(targetHost) に接続中..."
        statusColor = .secondary

        // Load asset files from app bundle
        let assetNames = ["api.py", "create_api.sh", "cw_bridge.py",
                          "setup_fastapi_radio.sh", "set_api_key.sh"]
        var assetFiles: [(name: String, data: Data)] = []
        for name in assetNames {
            let parts = name.split(separator: ".", maxSplits: 1)
            let resName = String(parts[0])
            let resExt  = parts.count > 1 ? String(parts[1]) : ""
            guard let url = Bundle.main.url(forResource: resName, withExtension: resExt),
                  let data = try? Data(contentsOf: url) else {
                appendLog("ERROR: バンドルに \(name) が見つかりません")
                statusText = "Error: バンドルファイルが見つかりません"
                statusColor = .red
                isRunning = false
                return
            }
            assetFiles.append((name: name, data: data))
        }

        do {
            let client = try await SSHClient.connect(
                host: targetHost,
                authenticationMethod: .passwordBased(username: sshUser, password: sshPassword),
                hostKeyValidator: .acceptAnything(),
                reconnect: .never
            )
            defer { Task { try? await client.close() } }

            appendLog("SSH 接続完了")
            statusText = "ファイル転送中 (SFTP)..."

            // Step 1: Upload files via SFTP
            try await client.withSFTP { sftp in
                for (name, data) in assetFiles {
                    let handle = try await sftp.openFile(
                        filePath: name,
                        flags: [.write, .create, .truncate],
                        attributes: .init()
                    )
                    let buf = ByteBuffer(bytes: Array(data))
                    try await handle.write(buf, at: 0)
                    try await handle.close()
                    await MainActor.run { self.appendLog("転送: \(name) (\(data.count / 1024)KB)") }
                }
            }
            appendLog("✓ ファイル転送完了")

            // Step 2: Set execute permissions
            _ = try await client.executeCommand(
                "chmod +x ~/setup_fastapi_radio.sh ~/create_api.sh ~/set_api_key.sh"
            )
            appendLog("✓ 実行権限設定完了")
            appendLog("セットアップスクリプト実行中... (Pi Zero 2W は 1 時間以上かかります)")
            statusText = "セットアップ中... しばらくお待ちください"

            // Concurrent timer — shows elapsed time every 30 s while SSH command runs
            let startTime = Date()
            let timerTask = Task { @MainActor in
                while !Task.isCancelled {
                    try? await Task.sleep(nanoseconds: 30_000_000_000)
                    guard !Task.isCancelled else { break }
                    let elapsed = Int(-startTime.timeIntervalSinceNow)
                    appendLog("⏳ 実行中... \(elapsed)秒経過")
                }
            }

            // Step 3: Run setup script via sudo -S (password fed through printf)
            let escapedPass = sshPassword
                .replacingOccurrences(of: "\\", with: "\\\\")
                .replacingOccurrences(of: "'", with: "'\\''")
            let setupCmd =
                "printf '%s\\n' '\(escapedPass)' | sudo -S bash ~/setup_fastapi_radio.sh \(vncDesktop) 2>&1; true"
            let output = try await client.executeCommand(setupCmd, maxResponseSize: 10 * 1024 * 1024)
            timerTask.cancel()

            // Append output lines to log
            if let text = output.getString(at: output.readerIndex, length: output.readableBytes),
               !text.isEmpty {
                for line in text.components(separatedBy: .newlines) where !line.isEmpty {
                    appendLog(line)
                }
            }

            appendLog("── セットアップ完了 ──")
            appendLog("")
            appendLog("【次の手順】")
            appendLog("  1. アプリの UPDATE 画面を開く")
            appendLog("  2. 「Update Pi」を実行する")
            appendLog("     → mfsk-decode ビルドも自動で開始されます（10〜20分）")
            statusText = "✓ SETUP 完了 — 次に UPDATE 画面で「Update Pi」を実行してください"
            statusColor = .green

        } catch {
            appendLog("ERROR: \(error.localizedDescription)")
            statusText = "Error: \(error.localizedDescription)"
            statusColor = .red
        }

        isRunning = false
    }
}
