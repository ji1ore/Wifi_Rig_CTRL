import SwiftUI
import VisionKit

struct TokenCameraScanView: UIViewControllerRepresentable {
    var onTokenFound: (String) -> Void

    private static let tokenRegex = try! NSRegularExpression(
        pattern: "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
    )

    func makeCoordinator() -> Coordinator { Coordinator(onTokenFound: onTokenFound) }

    func makeUIViewController(context: Context) -> DataScannerViewController {
        let vc = DataScannerViewController(
            recognizedDataTypes: [.text()],
            qualityLevel: .accurate,
            recognizesMultipleItems: false,
            isHighFrameRateTrackingEnabled: false,
            isPinchToZoomEnabled: true,
            isGuidanceEnabled: true,
            isHighlightingEnabled: true
        )
        vc.delegate = context.coordinator
        try? vc.startScanning()
        return vc
    }

    func updateUIViewController(_ uiViewController: DataScannerViewController, context: Context) {}

    class Coordinator: NSObject, DataScannerViewControllerDelegate {
        let onTokenFound: (String) -> Void
        private var found = false

        init(onTokenFound: @escaping (String) -> Void) {
            self.onTokenFound = onTokenFound
        }

        func dataScanner(_ dataScanner: DataScannerViewController,
                         didAdd addedItems: [RecognizedItem],
                         allItems: [RecognizedItem]) {
            guard !found else { return }
            for item in allItems {
                if case .text(let t) = item {
                    let lowered = t.transcript.lowercased()
                    let ns = lowered as NSString
                    let range = NSRange(location: 0, length: ns.length)
                    if let m = TokenCameraScanView.tokenRegex.firstMatch(in: lowered, range: range) {
                        found = true
                        let token = ns.substring(with: m.range)
                        dataScanner.stopScanning()
                        DispatchQueue.main.async { self.onTokenFound(token) }
                        return
                    }
                }
            }
        }
    }
}

struct TokenCameraScanSheet: View {
    @Environment(\.dismiss) private var dismiss
    var onTokenFound: (String) -> Void

    var body: some View {
        NavigationStack {
            Group {
                if DataScannerViewController.isSupported && DataScannerViewController.isAvailable {
                    TokenCameraScanView { token in
                        onTokenFound(token)
                        dismiss()
                    }
                    .ignoresSafeArea()
                    .overlay(alignment: .bottom) {
                        Text("DuckDNS トークンをカメラに向けてください")
                            .font(.callout.weight(.medium))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 8)
                            .background(.black.opacity(0.6), in: Capsule())
                            .padding(.bottom, 40)
                    }
                } else {
                    ContentUnavailableView(
                        "カメラ利用不可",
                        systemImage: "camera.slash",
                        description: Text("このデバイスではテキストスキャンを使用できません")
                    )
                }
            }
            .navigationTitle("トークン読み取り")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("キャンセル") { dismiss() }
                }
            }
        }
    }
}
