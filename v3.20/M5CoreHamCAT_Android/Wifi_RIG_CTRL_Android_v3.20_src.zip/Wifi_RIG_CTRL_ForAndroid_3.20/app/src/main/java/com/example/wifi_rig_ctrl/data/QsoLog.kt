package com.ji1ore.wifi_rig_ctrl.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.TimeZone

data class QsoEntry(
    val dt: String,          // yyyyMMddHHmmss UTC
    val call: String,        // DX callsign
    val freqHz: Long,
    val mode: String,
    val rstSent: String,
    val rstRcvd: String,
    val dxGrid: String,
    val myCall: String,
    val myGrid: String,
    val yourPota: String = "",  // DX station's POTA reference (POTA_REF in ADIF)
    val yourSota: String = "",  // DX station's SOTA summit code (SOTA_REF in ADIF)
    val myPota: String = "",    // My own POTA reference (MY_POTA_REF in ADIF)
    val mySota: String = "",    // My own SOTA summit code (MY_SOTA_REF in ADIF)
    val jcc: String = "",
    val jgc: String = "",
    val comment: String = "",
    val lat: Double = 0.0,
    val lon: Double = 0.0,
    val eqslSent: Boolean = false,  // eQSL.cc へ送信済みか
    val shlSent: Boolean = false,   // Smart HAMLOG へ連携(ADIF書き出し)済みか
    val qsl: String = "",           // QSL状態(空白/JARL/hQSL/No/Card/1-Way)
    val qth: String = "",           // 相手局QTH(HAMLOG QTH欄へ)
    val myLoc: String = ""          // 自局の運用場所(My Parkマルチロケ等。ADIF MY_CITY)
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("dt", dt); put("call", call); put("freq", freqHz); put("mode", mode)
        put("rstS", rstSent); put("rstR", rstRcvd); put("grid", dxGrid)
        put("myCall", myCall); put("myGrid", myGrid)
        if (eqslSent) put("eqslSent", true)
        if (shlSent) put("shlSent", true)
        if (qsl.isNotEmpty()) put("qsl", qsl)
        if (qth.isNotEmpty()) put("qth", qth)
        if (myLoc.isNotEmpty()) put("myLoc", myLoc)
        if (yourPota.isNotEmpty()) put("pota",   yourPota)
        if (yourSota.isNotEmpty()) put("sota",   yourSota)
        if (myPota.isNotEmpty())   put("myPota", myPota)
        if (mySota.isNotEmpty())   put("mySota", mySota)
        if (jcc.isNotEmpty())      put("jcc",    jcc)
        if (jgc.isNotEmpty())      put("jgc",    jgc)
        if (comment.isNotEmpty())  put("comment",comment)
        if (lat != 0.0)            put("lat",    lat)
        if (lon != 0.0)            put("lon",    lon)
    }

    companion object {
        fun fromJson(o: JSONObject) = QsoEntry(
            dt       = o.optString("dt"),
            call     = o.optString("call"),
            freqHz   = o.optLong("freq"),
            mode     = o.optString("mode", "FT8"),
            rstSent  = o.optString("rstS"),
            rstRcvd  = o.optString("rstR"),
            dxGrid   = o.optString("grid"),
            myCall   = o.optString("myCall"),
            myGrid   = o.optString("myGrid"),
            yourPota = o.optString("pota"),
            yourSota = o.optString("sota"),
            myPota   = o.optString("myPota"),
            mySota   = o.optString("mySota"),
            jcc      = o.optString("jcc"),
            jgc      = o.optString("jgc"),
            comment  = o.optString("comment"),
            lat      = o.optDouble("lat", 0.0),
            lon      = o.optDouble("lon", 0.0),
            eqslSent = o.optBoolean("eqslSent", false),
            shlSent  = o.optBoolean("shlSent", false),
            qsl      = o.optString("qsl"),
            qth      = o.optString("qth"),
            myLoc    = o.optString("myLoc")
        )

        fun utcNow(): String {
            val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
            return "%04d%02d%02d%02d%02d%02d".format(
                cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1,
                cal.get(Calendar.DAY_OF_MONTH), cal.get(Calendar.HOUR_OF_DAY),
                cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND))
        }
    }
}

object QsoStore {
    private const val PREFS_KEY = "ft8QsoLog"

    fun load(context: Context): MutableList<QsoEntry> {
        val prefs = context.getSharedPreferences("wifi_rig_ctrl", Context.MODE_PRIVATE)
        return parseJson(prefs.getString(PREFS_KEY, "[]") ?: "[]")
    }

    fun save(context: Context, entries: List<QsoEntry>) {
        val arr = JSONArray()
        entries.forEach { arr.put(it.toJson()) }
        context.getSharedPreferences("wifi_rig_ctrl", Context.MODE_PRIVATE)
            .edit().putString(PREFS_KEY, arr.toString()).apply()
    }

    fun append(context: Context, entry: QsoEntry) {
        val list = load(context)
        list.add(entry)
        save(context, list)
    }

    /** dt+call が一致するエントリ(複数あれば全て)の eqslSent を更新して保存。 */
    @Synchronized
    fun markEqslSent(context: Context, dt: String, call: String, sent: Boolean = true) {
        val list = load(context)
        var changed = false
        for (i in list.indices) {
            if (list[i].dt == dt && list[i].call == call && list[i].eqslSent != sent) {
                list[i] = list[i].copy(eqslSent = sent); changed = true
            }
        }
        if (changed) save(context, list)
    }

    /** dt+call が一致するエントリの shlSent(Smart HAMLOG連携済み) を更新して保存。 */
    @Synchronized
    fun markShlSent(context: Context, keys: List<Pair<String, String>>, sent: Boolean = true) {
        if (keys.isEmpty()) return
        val set = keys.toHashSet()
        val list = load(context)
        var changed = false
        for (i in list.indices) {
            if (set.contains(list[i].dt to list[i].call) && list[i].shlSent != sent) {
                list[i] = list[i].copy(shlSent = sent); changed = true
            }
        }
        if (changed) save(context, list)
    }

    fun clear(context: Context) {
        context.getSharedPreferences("wifi_rig_ctrl", Context.MODE_PRIVATE)
            .edit().putString(PREFS_KEY, "[]").apply()
    }

    private fun parseJson(json: String): MutableList<QsoEntry> = try {
        val arr = JSONArray(json)
        (0 until arr.length()).map { QsoEntry.fromJson(arr.getJSONObject(it)) }.toMutableList()
    } catch (_: Exception) { mutableListOf() }

    // FT8/FT4 の RST は "R-19" のように先頭に Roger の "R" が付くことがある。
    // ログ(ADIF/HAMLOG)の RST としては数値部のみが正しいので先頭の R を除去する。
    private fun normRst(s: String): String = Regex("^R+(?=[+-]?\\d)").replace(s.trim(), "")

    fun buildAdif(entries: List<QsoEntry>): String {
        fun f(tag: String, v: String) = if (v.isNotEmpty()) "<$tag:${v.length}>$v " else ""
        val sb = StringBuilder("ADIF Export from Wifi_RIG_CTRL\n<EOH>\n\n")
        entries.forEach { e ->
            val freq = if (e.freqHz > 0) "%.4f".format(e.freqHz / 1_000_000.0) else ""
            sb.append(f("CALL", e.call))
              .append(f("MODE", e.mode))
              .append(f("BAND", freqToBand(e.freqHz)))
              .append(f("FREQ", freq))
              .append(f("QSO_DATE", e.dt.take(8)))
              .append(f("TIME_ON", e.dt.drop(8).take(6)))
              .append(f("RST_SENT", normRst(e.rstSent)))
              .append(f("RST_RCVD", normRst(e.rstRcvd)))
              .append(f("GRIDSQUARE", e.dxGrid))
              .append(f("QTH", e.qth))
              .append(f("OPERATOR", e.myCall))
              .append(f("MY_GRIDSQUARE", e.myGrid))
              .append(f("MY_LAT", if (e.lat != 0.0) "%.6f".format(e.lat) else ""))
              .append(f("MY_LON", if (e.lon != 0.0) "%.6f".format(e.lon) else ""))
              .append(f("POTA_REF", e.yourPota))
              .append(f("SOTA_REF", e.yourSota))
              .append(f("MY_POTA_REF", e.myPota))
              .append(f("MY_SOTA_REF", e.mySota))
              // Smart Ham Log(Turbo HAMLOG)は POTA_REF/SOTA_REF を専用欄に取り込まず Remarks へ
              // 落としてしまう。POTA/SOTA を相手/自局の該当欄へ入れるため、広く認識される
              // SIG/SIG_INFO(相手)・MY_SIG/MY_SIG_INFO(自局)でも併記する。
              // SIG は1レコードに1つのため POTA 優先・無ければ SOTA(POTA/SOTA同時は稀)。
              .append(when {
                  e.yourPota.isNotEmpty() -> f("SIG", "POTA") + f("SIG_INFO", e.yourPota)
                  e.yourSota.isNotEmpty() -> f("SIG", "SOTA") + f("SIG_INFO", e.yourSota)
                  else -> ""
              })
              .append(when {
                  e.myPota.isNotEmpty() -> f("MY_SIG", "POTA") + f("MY_SIG_INFO", e.myPota)
                  e.mySota.isNotEmpty() -> f("MY_SIG", "SOTA") + f("MY_SIG_INFO", e.mySota)
                  else -> ""
              })
              .append(f("MY_CITY", e.myLoc))
              .append(f("COMMENT", e.comment))
              .append(f("QSL_SENT", e.qsl))
              .append("<EOR>\n")
        }
        return sb.toString()
    }

    fun freqToBand(hz: Long) = when {
        hz in 1_800_000..2_000_000     -> "160M"; hz in 3_500_000..4_000_000   -> "80M"
        hz in 7_000_000..7_300_000     -> "40M";  hz in 10_100_000..10_150_000 -> "30M"
        hz in 14_000_000..14_350_000   -> "20M";  hz in 18_068_000..18_168_000 -> "17M"
        hz in 21_000_000..21_450_000   -> "15M";  hz in 24_890_000..24_990_000 -> "12M"
        hz in 28_000_000..29_700_000   -> "10M";  hz in 50_000_000..54_000_000 -> "6M"
        hz in 144_000_000..148_000_000 -> "2M";   hz in 420_000_000..450_000_000 -> "70CM"
        else -> ""
    }

    // ── SOTA chaser CSV (v3.20) ──────────────────────────────────────────

    /** SOTAData のチェイサー用アップロード画面 */
    const val SOTA_CHASER_UPLOAD_URL = "https://www.sotadata.org.uk/en/upload/chaser/csv"

    data class SotaChaserCsv(
        val csv: String,
        val included: Int,
        val skippedNoRef: Int,      // 相手局の SOTA 番号なし
        val skippedActivator: Int,  // 自局 SOTA 番号あり(アクティベーター交信)
        val skippedInvalid: Int     // 自局コール・日時・周波数の不足
    )

    /**
     * SOTA CSV V2 形式のチェイサーログを作る。
     * 1行 = V2,自局コール,(空欄),dd/MM/yyyy,HHmm,周波数MHz,モード,相手局コール,相手の山岳番号
     */
    fun buildSotaChaserCsv(entries: List<QsoEntry>): SotaChaserCsv {
        val lines = mutableListOf<String>()
        var noRef = 0; var activator = 0; var invalid = 0
        for (e in entries.sortedBy { it.dt }) {
            val ref = e.yourSota.trim().uppercase()
            if (ref.isEmpty()) { noRef++; continue }
            if (e.mySota.isNotBlank()) { activator++; continue }
            val myCall = e.myCall.trim().uppercase()
            val call = e.call.trim().uppercase()
            if (myCall.isEmpty() || call.isEmpty() || e.dt.length < 12 || e.freqHz <= 0) {
                invalid++; continue
            }
            val d = e.dt
            val date = "${d.substring(6, 8)}/${d.substring(4, 6)}/${d.substring(0, 4)}"
            val time = d.substring(8, 12)
            val fields = listOf("V2", myCall, "", date, time, sotaFreq(e.freqHz), sotaMode(e.mode), call, ref)
            lines.add(fields.joinToString(",") { it.replace(",", " ") })
        }
        val csv = if (lines.isEmpty()) "" else lines.joinToString("\r\n") + "\r\n"
        return SotaChaserCsv(csv, lines.size, noRef, activator, invalid)
    }

    /** 14063500 Hz → "14.0635MHz" */
    fun sotaFreq(hz: Long): String =
        "%.4f".format(java.util.Locale.US, hz / 1_000_000.0).trimEnd('0').trimEnd('.') + "MHz"

    /** アプリのモード名を SOTA のモード(CW / SSB / FM / AM / Data / DV / Other)に変換 */
    fun sotaMode(mode: String): String {
        val m = mode.uppercase()
        return when {
            m.startsWith("CW") -> "CW"
            m == "USB" || m == "LSB" || m.startsWith("SSB") -> "SSB"
            m.startsWith("FM") || m == "WFM" -> "FM"
            m.startsWith("AM") -> "AM"
            m in setOf("C4FM", "DV", "D-STAR", "DSTAR", "DMR") -> "DV"
            m in setOf("FT8", "FT4", "PSK31", "JT65", "JS8", "OLIVIA") ||
                m.startsWith("PKT") || m.startsWith("DATA") || m.startsWith("RTTY") -> "Data"
            else -> "Other"
        }
    }
}
