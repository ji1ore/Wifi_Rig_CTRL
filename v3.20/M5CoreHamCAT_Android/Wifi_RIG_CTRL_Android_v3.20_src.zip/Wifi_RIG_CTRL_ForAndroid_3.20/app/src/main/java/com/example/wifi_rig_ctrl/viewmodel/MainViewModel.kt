package com.ji1ore.wifi_rig_ctrl.viewmodel

import android.Manifest
import android.annotation.SuppressLint
import android.app.Application
import android.bluetooth.BluetoothDevice
import android.content.pm.PackageManager
import android.hardware.usb.UsbDevice
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.ji1ore.wifi_rig_ctrl.data.*
import kotlinx.coroutines.*
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.sin
import kotlin.math.PI

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val prefs = AppPrefs(app)
    val hunterStore = HunterStore(app)
    val api = RigApiService(prefs.hostName, prefs.apiPort, prefs.apiKey)
    val civ = CivTcpService()
    val civBt = CivBtService()
    val audio = AudioStreamService()
    val audioTx = AudioTxService(api.client).also { it.gainMultiplier = prefs.micGain }
    val udpPtt = UdpPttService()
    val cwUsb = CwUsbService(app).also { it.sidetoneEnabled = prefs.cwSidetoneEnabled }
    val cwBle = CwBleService(app).also { it.sidetoneEnabled = prefs.cwSidetoneEnabled }

    // True when BT CI-V is active connection type
    private val isCivBt get() = civConnectionType.value == "BT"
    private val isCivConnected get() = if (isCivBt) civBt.isConnected else civ.isConnected
    @Volatile private var civSimplexResetSent = false

    // Connection
    val hostName = MutableLiveData(prefs.hostName)
    val apiPort = MutableLiveData(prefs.apiPort)
    val audioPort = MutableLiveData(prefs.audioPort)
    val useMDNS = MutableLiveData(prefs.useMDNS)
    val apiKey = MutableLiveData(prefs.apiKey)

    // CI-V direct connection
    val useCIV = MutableLiveData(prefs.useCIV)
    val civHost = MutableLiveData(prefs.civHost)
    val civPort = MutableLiveData(prefs.civPort)
    val civPort2 = MutableLiveData(prefs.civPort2)
    val civPort3 = MutableLiveData(prefs.civPort3)
    val civUser = MutableLiveData(prefs.civUser)
    val civPassword = MutableLiveData(prefs.civPassword)
    val civAddress = MutableLiveData(prefs.civAddress)
    val civConnectionType = MutableLiveData(prefs.civConnectionType)  // "WIFI" or "BT"
    val civBtDeviceAddress = MutableLiveData(prefs.civBtDeviceAddress)

    // Saved BluetoothDevice for BT reconnect (not serializable, kept in memory only)
    @Volatile var savedBtDevice: BluetoothDevice? = null

    // Rig lists
    val rigList = MutableLiveData<List<RigInfo>>(emptyList())
    val catList = MutableLiveData<List<String>>(emptyList())
    val soundDeviceList = MutableLiveData<List<SoundDevice>>(emptyList())

    // Selected rig settings
    val selectedRigIndex = MutableLiveData(0)
    val selectedCatIndex = MutableLiveData(0)
    val selectedPttDevice = MutableLiveData(prefs.savedPttDevice)
    val selectedPttType = MutableLiveData(prefs.savedPttType)
    val selectedBaudIndex = MutableLiveData(prefs.savedBaudIndex)
    val selectedSamplingIndex = MutableLiveData(prefs.savedSamplingIndex)
    val selectedTxSamplingIndex = MutableLiveData(prefs.savedTxSamplingIndex)
    val selectedTimeoutIndex = MutableLiveData(prefs.savedTimeoutIndex)
    val selectedAudioDevice = MutableLiveData(prefs.alsaDevice)
    val selectedAudioDeviceFt8 = MutableLiveData(prefs.alsaDeviceFt8)

    // PTT settings
    val useWifiPTT = MutableLiveData(prefs.useWifiPTT)
    val pttHost = MutableLiveData(prefs.pttHost)
    val pttPort = MutableLiveData(prefs.pttPort)

    // Rig status
    val sharedFreq = MutableLiveData(0L)
    val sharedMode = MutableLiveData("")
    val sharedModel = MutableLiveData("")
    val sharedSignal = MutableLiveData(0f)
    val sharedTx = MutableLiveData(false)
    val sharedPower = MutableLiveData(0f)
    val sharedSQL = MutableLiveData(0f)
    val sharedWidth = MutableLiveData(0)
    val sharedVolume = MutableLiveData(prefs.volume)
    val sharedMicGain = MutableLiveData(prefs.micGain)
    val sharedBkIn = MutableLiveData(false)
    val sharedTuner = MutableLiveData(false)

    // 運用セッション(POTA/SOTAアクティベーター運用地)
    val opSessions = MutableLiveData<List<OpSession>>(prefs.getOpSessions())

    /** 追加/編集(同一idは置換)。重複規則違反なら理由文字列、成功ならnull。 */
    fun addOpSession(s: OpSession): String? {
        val list = (opSessions.value ?: emptyList()).toMutableList()
        if (s.isExclusive) {
            val conflict = list.firstOrNull { it.isExclusive && it.id != s.id && it.overlaps(s) }
            if (conflict != null) return "JCC/JGC/SOTAは時間重複不可。既存と重複: ${conflict.type} ${conflict.ref}"
        }
        // 同一エンティティ(種別+ref)の重複登録は不可
        val dup = list.firstOrNull { it.id != s.id && it.type == s.type && it.ref.equals(s.ref, ignoreCase = true) }
        if (dup != null) return "同じ運用地が既に登録されています: ${s.type} ${s.ref}"
        list.removeAll { it.id == s.id }
        list.add(s)
        // 並び順: JCC → JGC → POTA → SOTA、同種別内は新しい開始順
        fun rank(t: String) = when (t) { "JCC" -> 0; "JGC" -> 1; "POTA" -> 2; "SOTA" -> 3; else -> 4 }
        list.sortWith(compareBy({ rank(it.type) }, { -it.startMs }))
        opSessions.value = list
        prefs.saveOpSessions(list)
        return null
    }

    fun deleteOpSession(id: String) {
        val list = (opSessions.value ?: emptyList()).filter { it.id != id }
        opSessions.value = list
        prefs.saveOpSessions(list)
    }

    /** 指定時刻(epoch ms)にアクティブな運用セッション一覧(JCC→JGC→POTA→SOTA順)。 */
    fun activeSessionsAt(t: Long): List<OpSession> {
        fun rank(ty: String) = when (ty) { "JCC" -> 0; "JGC" -> 1; "POTA" -> 2; "SOTA" -> 3; else -> 4 }
        return (opSessions.value ?: emptyList()).filter { it.activeAt(t) }
            .sortedWith(compareBy({ rank(it.type) }, { -it.startMs }))
    }

    // メイン画面で「現時点の有効運用地」をチェック選択する状態。
    // 選択中 = 現在アクティブ かつ ここに含まれない(=除外されていない)。
    // 除外集合で持つことで、新しくアクティブになったセッションは自動で選択扱いになる。
    val opSessionDeselected = MutableLiveData<Set<String>>(emptySet())

    fun setOpSessionSelected(id: String, on: Boolean) {
        val s = (opSessionDeselected.value ?: emptySet()).toMutableSet()
        if (on) s.remove(id) else s.add(id)
        opSessionDeselected.value = s
    }

    /** 指定時刻にアクティブ かつ 未除外の運用セッション(LOG QSOへ引き継ぐ既定選択)。 */
    fun selectedSessionsAt(t: Long): List<OpSession> {
        val de = opSessionDeselected.value ?: emptySet()
        return activeSessionsAt(t).filter { it.id !in de }
    }
    val bkInSupported = MutableLiveData<Boolean?>(null)
    val sharedRfOut = MutableLiveData(0f)
    val sharedAlc = MutableLiveData(0f)

    // SP2ALERT/MEM から FT8 画面へのナビゲーションイベント (Boolean = isFt4)
    val navigateToFt8 = MutableLiveData<Boolean?>()

    // SP2ALERT/Memset/スポットタップ時のログ用プリフィル情報
    var pendingLogCallsign: String = ""
    var pendingLogPota: String = ""
    var pendingLogSota: String = ""

    // POTA アクティベーター・スポット(基底コール→参照符号)。LOG QSO で相手POTAの自動補完に使う。
    // Ft8Fragment.fetchSpots が更新。CW等 pending が無い経路でも相手の公園を引けるようにする。
    var potaActivatorMap: Map<String, List<com.ji1ore.wifi_rig_ctrl.data.PotaSpot>> = emptyMap()

    // リピーター設定
    val repeaterToneMode  = MutableLiveData(prefs.repeaterToneMode)
    val repeaterToneHz    = MutableLiveData(prefs.repeaterToneHz)
    val repeaterOffsetDir = MutableLiveData(prefs.repeaterOffsetDir)
    val repeaterOffsetHz  = MutableLiveData(prefs.repeaterOffsetHz)

    fun setRepeater(toneMode: String, toneHz: Double, offsetDir: String, offsetHz: Long) {
        repeaterToneMode.value  = toneMode;  prefs.repeaterToneMode  = toneMode
        repeaterToneHz.value    = toneHz;    prefs.repeaterToneHz    = toneHz
        repeaterOffsetDir.value = offsetDir; prefs.repeaterOffsetDir = offsetDir
        repeaterOffsetHz.value  = offsetHz;  prefs.repeaterOffsetHz  = offsetHz
        if (useCIV.value == true && isCivConnected) {
            viewModelScope.launch(Dispatchers.IO) {
                if (isCivBt) civBt.sendRepeaterSettings(toneMode, toneHz, offsetDir, offsetHz)
                else civ.sendRepeaterSettings(toneMode, toneHz, offsetDir, offsetHz)
            }
        }
    }

    fun clearRepeater() = setRepeater("", 0.0, "", 0L)

    val cwTxShiftHz = MutableLiveData(prefs.cwTxShiftHz)
    // CWシフト用周波数記憶: cwBaseFreqHz=シフト前VFO, cwShiftedFreqHz=シフト後VFO
    // cw_bridgeがキーON時にVFOを移動するが、移動失敗時のドリフトを防ぐため
    // CWモード離脱時にcwBaseFreqHzへ明示的に復帰させる。
    var cwBaseFreqHz: Long = 0L
    var cwShiftedFreqHz: Long = 0L

    fun setCwTxShift(shiftHz: Long) {
        val rounded = (shiftHz / 10L) * 10L
        cwTxShiftHz.value = rounded
        prefs.cwTxShiftHz = rounded
        if (useCIV.value == true && isCivConnected) {
            viewModelScope.launch(Dispatchers.IO) {
                if (isCivBt) civBt.setTxShift(0L) else civ.setTxShift(0L)
            }
        } else if (useCIV.value != true) {
            if (rounded != 0L) {
                if (cwBaseFreqHz == 0L) cwBaseFreqHz = sharedFreq.value ?: 0L
                cwShiftedFreqHz = cwBaseFreqHz + rounded
                val baseToSend = cwBaseFreqHz
                viewModelScope.launch(Dispatchers.IO) {
                    api.setTxShift(rounded)
                    api.setCwBaseFreq(baseToSend)
                }
            } else {
                cwBaseFreqHz = 0L
                cwShiftedFreqHz = 0L
                viewModelScope.launch(Dispatchers.IO) { api.setTxShift(rounded) }
            }
        }
    }

    fun applySavedCwShift() {
        val saved = prefs.cwTxShiftHz
        if (saved != 0L) setCwTxShift(saved)
    }

    // ノイズリダクション (0=OFF, 1=Light, 2=Medium, 3=Strong)
    val noiseReductionLevel = MutableLiveData(prefs.nrLevel)

    fun cycleNoiseReduction() {
        val next = ((noiseReductionLevel.value ?: 0) + 1) % 6
        noiseReductionLevel.value = next
        prefs.nrLevel = next
        viewModelScope.launch(Dispatchers.IO) {
            api.setNrLevel(next)
            api.setNrLevelOnPort(prefs.audioPort, next)
        }
    }

    fun setNoiseReduction(level: Int) {
        noiseReductionLevel.value = level
        prefs.nrLevel = level
        viewModelScope.launch(Dispatchers.IO) {
            api.setNrLevel(level)
            api.setNrLevelOnPort(prefs.audioPort, level)
        }
    }

    // UI control state
    val txEnabled = MutableLiveData(false)
    val spkEnabled = MutableLiveData(false)
    val selectedMenuItem = MutableLiveData(MenuItem.NONE)
    val selectedStep = MutableLiveData(0)
    val supportedModes = MutableLiveData<List<String>>(emptyList())

    // APRS
    val aprsEnabled = MutableLiveData(prefs.aprsEnabled)
    val aprsActive = MutableLiveData(false)
    val aprsUseGPS = MutableLiveData(prefs.aprsUseGPS)
    val aprsLat = MutableLiveData(prefs.aprsLat)
    val aprsLon = MutableLiveData(prefs.aprsLon)
    val aprsTxFreq = MutableLiveData(prefs.aprsTxFreq)
    val aprsBaud = MutableLiveData(prefs.aprsBaud)
    val aprsCallsign = MutableLiveData(prefs.aprsCallsign)
    val aprsSSID = MutableLiveData(prefs.aprsSSID)
    val aprsIntervalSec = MutableLiveData(prefs.aprsIntervalSec)
    val aprsPath = MutableLiveData(prefs.aprsPath)
    val aprsSymbol = MutableLiveData(prefs.aprsSymbol)
    val aprsComment = MutableLiveData(prefs.aprsComment)
    val aprsDestination = MutableLiveData(prefs.aprsDestination)
    val aprsSoundDevice = MutableLiveData(prefs.aprsSoundDevice)
    val aprsUseRigModem = MutableLiveData(prefs.aprsUseRigModem)
    val aprsModemSel = MutableLiveData(prefs.aprsModemSel)
    val aprsPreset1Freq = MutableLiveData(prefs.aprsPreset1Freq)
    val aprsPreset1Baud = MutableLiveData(prefs.aprsPreset1Baud)
    val aprsPreset2Freq = MutableLiveData(prefs.aprsPreset2Freq)
    val aprsPreset2Baud = MutableLiveData(prefs.aprsPreset2Baud)
    val aprsAtPreset2 = MutableLiveData(false)  // Rigモード: false=AP96, true=AP12
    val aprsTxInProgress = MutableLiveData(false)

    // CW USB
    val cwUsbConnected = MutableLiveData(false)
    val cwUsbEnabled = MutableLiveData(false)
    val cwSidetoneEnabled = MutableLiveData(prefs.cwSidetoneEnabled)
    val cwDelayMs = MutableLiveData(prefs.cwDelayMs)
    val cwFmDelayMs = MutableLiveData(prefs.cwFmDelayMs)
    val cwServerConnected = MutableLiveData(false)
    val cwServerSynced = MutableLiveData(false)
    val cwMeasuredLatencyMs = MutableLiveData(0)  // max_late_ms measured by Pi (= clock diff + OWD - buffer)
    private var cwUsbConnecting = false  // flag to prevent double connection (main thread only)

    // CW BLE (Nordic UART Service: DualKey-BLE / RemoteKeyer-BLE)
    val cwBleConnected  = MutableLiveData(false)
    val cwBleEnabled    = MutableLiveData(false)
    val cwBleAudioReady = MutableLiveData(false)  // GATT接続+音声プライム完了後にtrue
    private var cwBleConnecting = false
    @Volatile var piClockOffsetMs: Long = 0L  // (Pi Unix ms) - (Android Unix ms)
    @Volatile var ft8FragmentActive = false      // FT8 WebView is visible (suppress SPK watchdog)
    @Volatile private var cwFmTxActive = false  // FM CW TX active flag (prevents false external PTT detection)
    @Volatile private var cwTextTxActive = false // CW text TX active flag (prevents false external PTT detection)
    @Volatile private var aprsTxing = false    // APRS TX active flag (prevents false external PTT detection, manages SPK)
    @Volatile private var aprsStoppedAt = 0L  // APRS stop time: silence SPK errors for 120 seconds after stop
    private var lastAudioWatchdogMs = 0L      // last SPK watchdog start time
    private var cwFmTailJob: Job? = null         // VOX tail wait job

    // CW text send (Hamlib)
    val cwWpm = MutableLiveData(prefs.cwWpm)
    val cwPaddleSwap = MutableLiveData(prefs.cwPaddleSwap)
    val cwPttPoll = MutableLiveData(prefs.cwPttPoll)

    fun updateCwPttPoll(enabled: Boolean) {
        prefs.cwPttPoll = enabled
        cwPttPoll.value = enabled
    }
    val cwTxBusy = MutableLiveData(false)
    val cwKeyOn  = MutableLiveData(false)
    val btHybridAudioReady = MutableLiveData(false)
    private var cwTextJob: Job? = null

    val cwCqRepeating = MutableLiveData(false)
    val cwCqRepeatStatus = MutableLiveData("")
    private var cwCqRepeatJob: Job? = null

    fun startCqRepeat(message: String, wpm: Int, intervalSec: Int, loopCount: Int) {
        cwCqRepeatJob?.cancel()
        cwCqRepeating.value = true
        cwCqRepeatJob = viewModelScope.launch {
            var sent = 0
            val countStr = if (loopCount == 0) "∞" else "$loopCount"
            while (isActive && (loopCount == 0 || sent < loopCount)) {
                sent++
                cwCqRepeatStatus.postValue("Sending $sent/$countStr")
                sendCwText(message, wpm)
                delay(400)  // brief settle before busy check
                while (isActive && cwTxBusy.value == true) delay(200)
                if (loopCount > 0 && sent >= loopCount) break
                // Countdown interval
                val endMs = System.currentTimeMillis() + intervalSec * 1000L
                while (isActive && System.currentTimeMillis() < endMs) {
                    val rem = ((endMs - System.currentTimeMillis()) / 1000).toInt() + 1
                    cwCqRepeatStatus.postValue("$sent/$countStr — next in ${rem}s")
                    delay(300)
                }
            }
            cwCqRepeating.postValue(false)
            cwCqRepeatStatus.postValue("")
            cwCqRepeatJob = null
        }
    }

    fun stopCqRepeat() {
        cwCqRepeatJob?.cancel()
        cwCqRepeatJob = null
        cwCqRepeating.value = false
        cwCqRepeatStatus.value = ""
        stopCwText()
    }

    fun updateCwWpm(wpm: Int) {
        prefs.cwWpm = wpm
        cwWpm.value = wpm
        cwUsb.keeyerWpm = wpm
        cwBle.keeyerWpm = wpm
        if (cwUsb.isConnected) viewModelScope.launch(Dispatchers.IO) { cwUsb.sendWpmToM5(wpm) }
        if (cwBle.isConnected) viewModelScope.launch(Dispatchers.IO) { cwBle.sendWpmToM5(wpm) }
    }

    fun updatePaddleSwap(swapped: Boolean) {
        prefs.cwPaddleSwap = swapped
        cwPaddleSwap.value = swapped
        if (cwUsb.isConnected) cwUsb.sendPaddleSwapToM5(swapped)
        if (cwBle.isConnected) cwBle.sendPaddleSwapToM5(swapped)
    }

    // CW Decoder
    val cwDecoding = MutableLiveData(false)
    val cwTxText = MutableLiveData<String>("")
    val cwRxTexts = Array(CwDecoder.N_CHAN) { MutableLiveData<String>("") }
    val cwRxFreqLabels = Array(CwDecoder.N_CHAN) { i -> MutableLiveData(if (i == 0) "RX:" else "---") }
    val cwMultiRx = MutableLiveData(false)
    @Volatile private var cwDecodingActive = false
    private var cwRxDecoder: CwDecoder? = null
    private val cwTxKeyDecoder = CwKeyDecoder()
    private val cwTxBuffer = StringBuilder()
    private val cwRxBuffers = Array(CwDecoder.N_CHAN) { StringBuilder() }
    private val cwDecodedLock = Any()
    @Volatile private var cwTxTimeoutJob: Job? = null
    private val CW_MAX_CHARS = 200
    // Post timeout to main thread via Handler (more reliable than coroutine launch from USB thread)
    private val cwTxTimeoutHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val cwTxTimeoutRunnable = Runnable { cwTxKeyDecoder.checkTimeout() }

    // Status
    val errorMessage = MutableLiveData<String?>(null)
    val audioError = MutableLiveData<String?>(null)
    val isConnectedToRig = MutableLiveData(false)
    val piVersionMismatch = MutableLiveData(false)
    val isDemoMode = MutableLiveData(false)
    private var demoTick = 0

    // User interaction timestamps (protect UI updates from overwriting user input)
    private var lastUserFreqChange = 0L
    private var lastUserModeChange = 0L
    private var lastUserPowerChange = 0L
    private var lastUserSQLChange = 0L
    private var lastUserVolumeChange = 0L
    private var lastUserWidthChange = 0L

    // Track HTTP completion of Hamlib PTT ON command: OFF waits by join()ing this job before sending
    private var pttOnJob: Job? = null
    // Time when Android PTT OFF was pressed: cooldown for external PTT false detection
    private var lastAndroidPttOffTime = 0L
    // Time when connectRig() completed: suppress external PTT detection during rigctld init
    private var lastConnectTime = 0L

    private var statusPollingJob: Job? = null
    private var civWifiLock: android.net.wifi.WifiManager.WifiLock? = null
    private var lastCivReconnectAttemptMs = 0L

    private fun acquireCivWifiLock() {
        val wm = getApplication<Application>().getSystemService(android.net.wifi.WifiManager::class.java)
        // LOW_LATENCY (API 29+): eliminates power-save 100–300ms latency spikes during RX/TX.
        // Requires screen ON + app in foreground; falls back to HIGH_PERF (works screen-off).
        val mode = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            android.net.wifi.WifiManager.WIFI_MODE_FULL_LOW_LATENCY
        } else {
            @Suppress("DEPRECATION")
            android.net.wifi.WifiManager.WIFI_MODE_FULL_HIGH_PERF
        }
        civWifiLock = wm?.createWifiLock(mode, "CivWlan")
        civWifiLock?.setReferenceCounted(false)
        civWifiLock?.acquire()
    }

    private fun releaseCivWifiLock() {
        try { if (civWifiLock?.isHeld == true) civWifiLock?.release() } catch (_: Exception) {}
        civWifiLock = null
    }

    private var cwWifiLock: android.net.wifi.WifiManager.WifiLock? = null

    /** Hold a high-performance Wi-Fi lock while the CW keyer + Pi UDP session is active.
     *  Without it, Android Wi-Fi power-save during idle causes multi-second stalls that drop
     *  status polling (→ linkLost "disconnect") and lose fire-and-forget key-off UDP (→ stuck TX).
     *  Mirrors the CI-V path's acquireCivWifiLock(). */
    private fun acquireCwWifiLock() {
        if (cwWifiLock?.isHeld == true) return
        val wm = getApplication<Application>().getSystemService(android.net.wifi.WifiManager::class.java)
        val mode = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            android.net.wifi.WifiManager.WIFI_MODE_FULL_LOW_LATENCY
        } else {
            @Suppress("DEPRECATION")
            android.net.wifi.WifiManager.WIFI_MODE_FULL_HIGH_PERF
        }
        cwWifiLock = wm?.createWifiLock(mode, "CwWlan")
        cwWifiLock?.setReferenceCounted(false)
        cwWifiLock?.acquire()
    }

    private fun releaseCwWifiLock() {
        try { if (cwWifiLock?.isHeld == true) cwWifiLock?.release() } catch (_: Exception) {}
        cwWifiLock = null
    }

    // mDNS(.local) resolution needs a MulticastLock, otherwise Android's Wi-Fi driver filters the
    // incoming mDNS responses and getByName() throws UnknownHostException. On a slow Pi Zero 2W the
    // response window is tight, so without this lock "Unknown host" happens frequently during polling.
    private var mdnsLock: android.net.wifi.WifiManager.MulticastLock? = null
    private fun acquireMdnsLock() {
        if (mdnsLock?.isHeld == true) return
        val wm = getApplication<Application>().getSystemService(android.net.wifi.WifiManager::class.java)
        mdnsLock = wm?.createMulticastLock("rigctrl_mdns")?.also {
            it.setReferenceCounted(false); it.acquire()
        }
    }
    private fun releaseMdnsLock() {
        try { if (mdnsLock?.isHeld == true) mdnsLock?.release() } catch (_: Exception) {}
        mdnsLock = null
    }

    // VFO A/B vs Main/Sub
    val vfoMode = MutableLiveData("")
    val vfoCurrentSide = MutableLiveData("")

    // APRS received beacons
    val aprsReceivedStations = MutableLiveData<List<com.ji1ore.wifi_rig_ctrl.data.AprsHeardStation>>(emptyList())
    val aprsToastStation = MutableLiveData<com.ji1ore.wifi_rig_ctrl.data.AprsHeardStation?>(null)
    private var aprsReceivedPollingJob: Job? = null

    companion object {
        const val CW_UDP_PORT = 8889
        // UDP is lossy: a dropped CW key packet = a missing element (TX "音切れ").
        // Send each key packet multiple times with small spacing for loss resilience.
        // The server dedups identical (isOn, trxSel, opTimeMs) packets (SAME_MAX),
        // so the extra copies are harmless — at most one real transition is applied.
        const val CW_SEND_REPEAT = 5
        const val CW_SEND_SPACING_MS = 4L
        const val EXPECTED_PI_API_VERSION = "3.20"

        @Volatile
        var instance: MainViewModel? = null
            private set
    }

    init {
        instance = this
    }
    private var cwServerPollingJob: Job? = null
    private var aprsHeartbeatJob: Job? = null
    private var pttHeartbeatJob: Job? = null
    private var audioTxStartJob: Job? = null
    private var pttOffJob: Job? = null
    private var locationManager: LocationManager? = null
    private var locationListener: LocationListener? = null
    private var externalPttActive = false  // M5物理ボタン等の外部PTT検出フラグ
    private var serverWatchdogJob: Job? = null  // WiFi PTT時のサーバーwatchdog更新（UDP heartbeatと独立）
    private var cwFmPttJob: Job? = null  // FMモードCWキー時のPTT制御

    // --- Profile management ---

    fun loadProfile(index: Int) {
        prefs.activeProfileIndex = index
        val profiles = prefs.getProfiles()
        val profile = profiles.getOrElse(index) { ProfileConfig() }
        prefs.applyProfile(profile)

        hostName.value = profile.hostName
        apiPort.value = profile.apiPort
        audioPort.value = profile.audioPort
        useMDNS.value = profile.useMDNS
        apiKey.value = profile.apiKey
        selectedBaudIndex.value = profile.savedBaudIndex
        selectedSamplingIndex.value = profile.savedSamplingIndex
        selectedTxSamplingIndex.value = profile.savedTxSamplingIndex
        selectedTimeoutIndex.value = profile.savedTimeoutIndex
        useWifiPTT.value = profile.useWifiPTT
        pttHost.value = profile.pttHost
        pttPort.value = profile.pttPort
        selectedPttDevice.value = profile.savedPttDevice
        selectedPttType.value = profile.savedPttType
        cwDelayMs.value = profile.cwDelayMs
        cwFmDelayMs.value = profile.cwFmDelayMs
        cwMeasuredLatencyMs.value = 0
        selectedAudioDevice.value = profile.alsaDevice
        selectedAudioDeviceFt8.value = profile.alsaDeviceFt8
        useCIV.value = profile.useCIV
        civHost.value = profile.civHost
        civPort.value = profile.civPort
        civPort2.value = profile.civPort2
        civPort3.value = profile.civPort3
        civUser.value = profile.civUser
        civPassword.value = profile.civPassword
        civAddress.value = profile.civAddress
        civConnectionType.value = profile.civConnectionType
        civBtDeviceAddress.value = profile.civBtDeviceAddress

        api.updateConnection(profile.hostName, profile.apiPort, profile.apiKey)
    }

    fun saveCurrentToProfile() {
        val profiles = prefs.getProfiles()
        val idx = prefs.activeProfileIndex.coerceIn(0, maxOf(0, profiles.size - 1))
        val oldName = profiles.getOrElse(idx) { ProfileConfig() }.name
        val updated = ProfileConfig(
            name = oldName,
            hostName = hostName.value ?: "",
            apiPort = apiPort.value ?: 8000,
            audioPort = audioPort.value ?: 50000,
            useMDNS = useMDNS.value ?: false,
            apiKey = apiKey.value ?: "",
            savedRigId = prefs.savedRigId,
            savedCat = prefs.savedCat,
            savedPttDevice = selectedPttDevice.value ?: "NONE",
            savedPttType = selectedPttType.value ?: "RIG",
            savedBaudIndex = selectedBaudIndex.value ?: 2,
            savedSamplingIndex = selectedSamplingIndex.value ?: 1,
            savedTxSamplingIndex = selectedTxSamplingIndex.value ?: 1,
            savedTimeoutIndex = selectedTimeoutIndex.value ?: 2,
            useWifiPTT = useWifiPTT.value ?: false,
            pttHost = pttHost.value ?: "",
            pttPort = pttPort.value ?: 8888,
            cwDelayMs = prefs.cwDelayMs,
            cwFmDelayMs = prefs.cwFmDelayMs,
            alsaDevice = selectedAudioDevice.value ?: "",
            alsaDeviceFt8 = selectedAudioDeviceFt8.value ?: "",
            useCIV = useCIV.value ?: false,
            civHost = civHost.value ?: "",
            civPort = civPort.value ?: 50001,
            civPort2 = civPort2.value ?: 50002,
            civPort3 = civPort3.value ?: 50003,
            civUser = civUser.value ?: "",
            civPassword = civPassword.value ?: "",
            civAddress = civAddress.value ?: 0xA4,
            civConnectionType = civConnectionType.value ?: "WIFI",
            civBtDeviceAddress = civBtDeviceAddress.value ?: ""
        )
        if (idx < profiles.size) profiles[idx] = updated else profiles.add(updated)
        prefs.saveProfiles(profiles)
    }

    // --- Connection ---

    fun updateConnectionSettings(host: String, port: Int, aPort: Int, mdns: Boolean, key: String = "") {
        hostName.value = host; apiPort.value = port; audioPort.value = aPort
        useMDNS.value = mdns; apiKey.value = key
        prefs.hostName = host; prefs.apiPort = port; prefs.audioPort = aPort
        prefs.useMDNS = mdns; prefs.apiKey = key
        prefs.useCIV = false
        useCIV.value = false
        api.updateConnection(host, port, key)
        saveCurrentToProfile()
    }

    fun updateCivSettings(host: String, port: Int, port2: Int, port3: Int,
                          user: String, password: String, addr: Int) {
        civHost.value = host; civPort.value = port; civPort2.value = port2
        civPort3.value = port3; civUser.value = user; civPassword.value = password
        civAddress.value = addr
        prefs.civHost = host; prefs.civPort = port; prefs.civPort2 = port2
        prefs.civPort3 = port3; prefs.civUser = user; prefs.civPassword = password
        prefs.civAddress = addr; prefs.useCIV = true
        prefs.civConnectionType = "WIFI"
        useCIV.value = true
        civConnectionType.value = "WIFI"
        civ.civAddress = addr
        saveCurrentToProfile()
    }

    fun updateCivBtSettings(btDeviceAddress: String, addr: Int,
                             audioHost: String = "", audioUser: String = "", audioPass: String = "") {
        civBtDeviceAddress.value = btDeviceAddress
        civAddress.value = addr
        prefs.civBtDeviceAddress = btDeviceAddress
        prefs.civAddress = addr
        prefs.civConnectionType = "BT"
        prefs.useCIV = true
        civConnectionType.value = "BT"
        useCIV.value = true
        civBt.civAddress = addr
        // RS-BA1 audio host for BT hybrid mode (stored in civHost/civUser/civPassword)
        if (audioHost.isNotEmpty()) {
            civHost.value = audioHost
            prefs.civHost = audioHost
        }
        if (audioUser.isNotEmpty()) {
            civUser.value = audioUser
            prefs.civUser = audioUser
        }
        if (audioPass.isNotEmpty()) {
            civPassword.value = audioPass
            prefs.civPassword = audioPass
        }
        saveCurrentToProfile()
    }

    suspend fun connectToRasPi(): String? = withContext(Dispatchers.IO) {
        civSimplexResetSent = false
        // CI-V direct connection path
        if (useCIV.value == true) {
            val addr = civAddress.value ?: 0xA4
            if (isCivBt) {
                // Bluetooth CI-V path
                val btAddr = civBtDeviceAddress.value ?: return@withContext "BT device not set"
                val device = savedBtDevice ?: run {
                    // Resolve BluetoothDevice from address using BluetoothAdapter
                    val bm = getApplication<android.app.Application>()
                        .getSystemService(android.content.Context.BLUETOOTH_SERVICE) as? android.bluetooth.BluetoothManager
                    @android.annotation.SuppressLint("MissingPermission")
                    bm?.adapter?.bondedDevices?.firstOrNull { it.address == btAddr }
                } ?: return@withContext "BT device not found: $btAddr"
                savedBtDevice = device
                civBt.civAddress = addr
                if (!civBt.connect(device)) return@withContext "BT CI-V connection failed\n${civBt.lastError}"
                // If RS-BA1 audio host is configured, connect audio session now
                val audioHost = civHost.value ?: ""
                if (audioHost.isNotEmpty()) {
                    val port  = civPort.value  ?: 50001
                    val port2 = civPort2.value ?: 50002
                    val port3 = civPort3.value ?: 50003
                    val user  = civUser.value  ?: ""
                    val pass  = civPassword.value ?: ""
                    val cm = getApplication<android.app.Application>()
                        .getSystemService(android.net.ConnectivityManager::class.java)
                    val wifiNet = cm?.allNetworks?.firstOrNull { net ->
                        cm.getNetworkCapabilities(net)
                            ?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) == true
                    }
                    civ.audioOnly = true
                    val audioOk = civ.connect(audioHost, port, port2, port3, user, pass, wifiNet)
                    if (!audioOk) {
                        civ.audioOnly = false
                        withContext(Dispatchers.Main) {
                            btHybridAudioReady.value = false
                            errorMessage.value = "RS-BA1 Audio connect failed (BT OK): ${civ.lastError}"
                        }
                    } else {
                        withContext(Dispatchers.Main) { btHybridAudioReady.value = true }
                    }
                }
                val modelName = civBt.getModelFromCivAddress()
                withContext(Dispatchers.Main) {
                    rigList.value = listOf(RigInfo(addr, modelName))
                    catList.value = listOf("CI-V (BT)")
                    soundDeviceList.value = emptyList()
                    selectedRigIndex.value = 0
                    selectedCatIndex.value = 0
                }
                return@withContext null
            } else {
                // WiFi/LAN CI-V path
                val host = civHost.value ?: return@withContext "No CI-V host"
                val port = civPort.value ?: 50001
                val port2 = civPort2.value ?: 50002
                val port3 = civPort3.value ?: 50003
                val user = civUser.value ?: ""
                val pass = civPassword.value ?: ""
                civ.civAddress = addr
                // Find the active WiFi network so sockets are routed via WiFi even when
                // IC-705's AP has no internet (Android would otherwise use cellular).
                val cm = getApplication<android.app.Application>()
                    .getSystemService(android.net.ConnectivityManager::class.java)
                val wifiNet = cm?.allNetworks?.firstOrNull { net ->
                    cm.getNetworkCapabilities(net)
                        ?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) == true
                }
                if (!civ.connect(host, port, port2, port3, user, pass, wifiNet)) return@withContext "CI-V connection failed\n${civ.lastError}"
                val modelName = civ.getModelFromCivAddress()
                withContext(Dispatchers.Main) {
                    rigList.value = listOf(RigInfo(addr, modelName))
                    catList.value = listOf("CI-V")
                    soundDeviceList.value = emptyList()
                    selectedRigIndex.value = 0
                    selectedCatIndex.value = 0
                }
                return@withContext null
            }
        }

        val rawHost = hostName.value ?: return@withContext "No host"
        if (rawHost.trim().lowercase() == "demo") {
            withContext(Dispatchers.Main) {
                isDemoMode.value = true
                rigList.value = listOf(RigInfo(3073, "IC-7300"))
                catList.value = listOf("None")
                soundDeviceList.value = emptyList()
                selectedRigIndex.value = 0
                selectedCatIndex.value = 0
            }
            return@withContext null
        }
        try {
            val port = apiPort.value ?: 8000
            val key = apiKey.value ?: ""
            val host = if (useMDNS.value == true) {
                val mdnsName = if (!rawHost.endsWith(".local")) "$rawHost.local" else rawHost
                try {
                    // Resolve to IP address (use .local hostname as-is if resolution fails)
                    java.net.InetAddress.getByName(mdnsName).hostAddress ?: mdnsName
                } catch (e: Exception) {
                    mdnsName  // attempt connection with hostname even on resolution failure
                }
            } else rawHost
            val tempApi = RigApiService(host, port, key)
            val rigs = tempApi.getRigs()
            if (rigs.isEmpty()) return@withContext "No rigs found on server"

            api.updateConnection(host, port, key)
            val (cats, sounds) = tempApi.getDevices()
            val savedCat = prefs.savedCat
            val catDevices = when {
                cats.isNotEmpty() -> cats
                savedCat.isNotEmpty() -> listOf(savedCat)
                else -> listOf("None")
            }

            withContext(Dispatchers.Main) {
                rigList.value = rigs
                catList.value = catDevices
                soundDeviceList.value = sounds
                val savedId = prefs.savedRigId
                val idx = rigs.indexOfFirst { it.id == savedId }.takeIf { it >= 0 } ?: 0
                selectedRigIndex.value = idx
                val catIdx = catDevices.indexOfFirst { it == savedCat }.takeIf { it >= 0 } ?: 0
                selectedCatIndex.value = catIdx
            }
            null
        } catch (e: Exception) {
            val msg = e.message ?: ""
            when {
                msg.contains("Connection refused", ignoreCase = true) ->
                    "FastAPI service not running on Pi.\nRun create_api.sh to reinstall packages."
                msg.contains("timeout", ignoreCase = true) ||
                msg.contains("timed out", ignoreCase = true) ->
                    "Pi unreachable. Check WiFi/network. (${msg})"
                else -> "Connection failed: $msg"
            }
        }
    }

    suspend fun skipConnect(): String? {
        if (prefs.hostName.isEmpty()) return "No host configured"
        if (prefs.savedRigId < 0) return "No rig settings saved"
        val err = connectToRasPi()
        if (err != null) return err
        val result = connectRig()
        if (result == null) isConnectedToRig.value = true
        return result
    }

    suspend fun connectRig(): String? = withContext(Dispatchers.IO) {
        if (isDemoMode.value == true) {
            withContext(Dispatchers.Main) {
                sharedModel.value = "IC-7300 [DEMO]"
                sharedFreq.value = 7_074_000L
                sharedMode.value = "USB"
                sharedPower.value = 1.0f
                sharedWidth.value = 2400
                sharedSQL.value = 0f
                supportedModes.value = listOf("USB", "LSB", "CW", "CWR", "AM", "FM", "RTTY", "RTTYR", "PKTUSB", "PKTLSB")
            }
            return@withContext null
        }

        // CI-V direct connection path
        if (useCIV.value == true) {
            if (!isCivConnected) {
                val err = connectToRasPi()
                if (err != null) return@withContext err
                if (!isCivBt) acquireCivWifiLock()
            }
            val freq = if (isCivBt) civBt.getFrequency() ?: 7_000_000L else civ.getFrequency() ?: 7_000_000L
            // CI-V stream is now confirmed open — reset DUP to Simplex
            if (isCivBt) civBt.setTxShift(0L) else civ.setTxShift(0L)
            val mode = if (isCivBt) civBt.getMode() else civ.getMode()
            val power = if (isCivBt) civBt.getRfPower() ?: 1f else civ.getRfPower() ?: 1f
            val sql = if (isCivBt) civBt.getSql() ?: 0f else civ.getSql() ?: 0f
            val bkIn = if (isCivBt) civBt.getBkIn() ?: false else civ.getBkIn() ?: false
            val modelName = if (isCivBt) civBt.getModelFromCivAddress() else civ.getModelFromCivAddress()
            val modes = if (isCivBt) civBt.getSupportedModes() else civ.getSupportedModes()
            withContext(Dispatchers.Main) {
                sharedModel.value = modelName
                sharedFreq.value = freq
                sharedMode.value = mode?.name ?: "USB"
                sharedWidth.value = mode?.filterWidth ?: 2400
                sharedPower.value = power
                sharedSQL.value = sql
                sharedBkIn.value = bkIn
                supportedModes.value = modes
                lastConnectTime = System.currentTimeMillis()
                selectedStep.value = prefs.getModeStep(mode?.name ?: "USB")
            }
            return@withContext null
        }

        try {
            val rigs = rigList.value ?: return@withContext "No rigs"
            val cats = catList.value ?: return@withContext "No devices"
            if (rigs.isEmpty()) return@withContext "No rigs found"

            val rig = rigs[selectedRigIndex.value ?: 0]
            val cat = cats.getOrElse(selectedCatIndex.value ?: 0) { "None" }
            val baud = BAUD_RATES.getOrElse(selectedBaudIndex.value ?: 2) { 9600 }

            if (useWifiPTT.value == true) {
                val h = pttHost.value
                if (h.isNullOrEmpty()) return@withContext "PTT host not set"
                val pt = pttPort.value ?: 8888
                // M5Atom time sync: send currentTimeMillis() as base time
                udpPtt.syncTime(h, pt)
            }

            val ptt = selectedPttDevice.value ?: "NONE"
            val pttType = selectedPttType.value ?: "RIG"
            prefs.savedRigId = rig.id
            prefs.savedCat = cat
            prefs.savedPttDevice = ptt
            prefs.savedPttType = pttType
            prefs.savedBaudIndex = selectedBaudIndex.value ?: 2
            prefs.savedSamplingIndex = selectedSamplingIndex.value ?: 1
            prefs.savedTxSamplingIndex = selectedTxSamplingIndex.value ?: 1
            prefs.savedTimeoutIndex = selectedTimeoutIndex.value ?: 2
            prefs.useWifiPTT = useWifiPTT.value ?: false
            prefs.pttHost = pttHost.value ?: ""
            prefs.pttPort = pttPort.value ?: 8888
            val alsaDev = selectedAudioDevice.value ?: ""
            prefs.alsaDevice = alsaDev
            val alsaFt8Dev = selectedAudioDeviceFt8.value ?: ""
            prefs.alsaDeviceFt8 = alsaFt8Dev

            saveCurrentToProfile()

            api.openRig(rig.id, cat, baud, ptt, pttType)
            if (alsaDev.isNotEmpty()) api.setAudioDevice(alsaDev)
            if (alsaFt8Dev.isNotEmpty()) api.setAudioDeviceFt8(alsaFt8Dev)
            delay(1000)

            repeat(50) {
                val st = api.getStatus()
                if (st != null) {
                    withContext(Dispatchers.Main) {
                        sharedModel.value = rig.name
                        lastConnectTime = System.currentTimeMillis()  // suppress external PTT detection during rigctld init
                    }
                    // Reset PTT/polling state from previous session
                    api.setPtt(false)
                    api.setPoll(true)
                    // NRレベルをAndroid保存値でサーバーへ同期（サーバー再起動後にNRが0に戻ってもAndroid側の設定を復元）
                    val savedNr = prefs.nrLevel
                    if (savedNr > 0) {
                        api.setNrLevel(savedNr)
                        api.setNrLevelOnPort(prefs.audioPort, savedNr)
                    }
                    // Pi clock sync: correct clock difference for CW timestamps
                    val offset = api.getPiClockOffsetMs()
                    if (offset != null) {
                        piClockOffsetMs = offset
                        cwBle.piClockOffsetMs = offset
                        android.util.Log.i("PiClock", "Pi clock offset: ${offset}ms")
                    } else {
                        android.util.Log.w("PiClock", "Pi clock sync failed")
                    }
                    // Fetch VFO mode (A/B or Main/Sub) after connection
                    val vMode = api.getVfoMode()
                    val vSide = if (vMode != null) api.getVfoCurrent() ?: "" else ""
                    if (vMode != null) {
                        vfoMode.postValue(vMode)
                        vfoCurrentSide.postValue(vSide)
                    }
                    // Restart cw_bridge.py so CW keying works immediately on reconnect
                    // (needed when Pi restarted while BLE keyer was already connected).
                    try { api.cwOpen(prefs.cwPort, 0) } catch (_: Exception) {}
                    return@withContext null
                }
                delay(200)
            }
            "Connect timeout"
        } catch (e: Exception) {
            "Error: ${e.message}"
        }
    }

    fun startStatusPolling() {
        statusPollingJob?.cancel()
        pollFailSinceMs = 0L
        linkLost.postValue(false)
        rigLinkLost.postValue(false)
        acquireMdnsLock()   // keep mDNS(.local) resolvable during the session (Pi Zero 2W UnknownHost fix)
        val interval = if (useCIV.value == true) 200L else 200L
        statusPollingJob = viewModelScope.launch {
            while (isActive) {
                updateStatus()
                delay(interval)
            }
        }
    }

    fun stopStatusPolling() {
        statusPollingJob?.cancel()
        statusPollingJob = null
        releaseMdnsLock()
    }

    private fun updateDemoStatus() {
        demoTick++
        val pattern = floatArrayOf(2f, 3f, 5f, 7f, 9f, 11f, 10f, 8f, 6f, 4f, 3f, 5f, 8f, 11f, 13f, 10f, 7f, 5f, 3f, 2f)
        sharedSignal.value = pattern[demoTick % pattern.size]
        sharedTx.value = txEnabled.value == true
    }

    private suspend fun updateCivStatus() {
        val st = withContext(Dispatchers.IO) {
            if (isCivBt) {
                // BT hybrid: also run audio watchdog on civ so maintenance recovery fires
                if (civ.audioOnly) {
                    if (civ.isConnected) {
                        civ.pollStatus()  // runs pollAudioOnlyStatus() — maintenance detection + watchdogs
                    } else {
                        // civ dropped (audio watchdog triggered disconnect) — reconnect RS-BA1 audio
                        val host = civHost.value ?: ""
                        if (host.isNotEmpty()) {
                            val now = System.currentTimeMillis()
                            if (now - lastCivReconnectAttemptMs >= 30_000L) {
                                lastCivReconnectAttemptMs = now
                                val port  = civPort.value  ?: 50001
                                val port2 = civPort2.value ?: 50002
                                val port3 = civPort3.value ?: 50003
                                val user  = civUser.value  ?: ""
                                val pass  = civPassword.value ?: ""
                                val cm = getApplication<android.app.Application>()
                                    .getSystemService(android.net.ConnectivityManager::class.java)
                                val wifiNet = cm?.allNetworks?.firstOrNull { net ->
                                    cm.getNetworkCapabilities(net)
                                        ?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) == true
                                }
                                civ.audioOnly = true
                                val ok = civ.connect(host, port, port2, port3, user, pass, wifiNet)
                                if (!ok) { civ.audioOnly = false; android.util.Log.w("MainVM", "BT audio reconnect failed: ${civ.lastError}") }
                            }
                        }
                    }
                }
                civBt.pollStatus()
            } else civ.pollStatus()
        } ?: run {
            if (!isCivConnected) {
                // attempt silent reconnect with 30s backoff
                val now = System.currentTimeMillis()
                if (now - lastCivReconnectAttemptMs < 30_000L) return
                lastCivReconnectAttemptMs = now
                if (isCivBt) {
                    val device = savedBtDevice ?: run { errorMessage.postValue("BT CI-V disconnected"); return }
                    val ok = withContext(Dispatchers.IO) { civBt.connect(device) }
                    if (!ok) errorMessage.postValue("BT CI-V reconnect failed: ${civBt.lastError}")
                } else {
                    val host = civHost.value ?: run { errorMessage.postValue("CI-V disconnected"); return }
                    val port  = civPort.value  ?: 50001
                    val port2 = civPort2.value ?: 50002
                    val port3 = civPort3.value ?: 50003
                    val user  = civUser.value  ?: ""
                    val pass  = civPassword.value ?: ""
                    val cm = getApplication<android.app.Application>()
                        .getSystemService(android.net.ConnectivityManager::class.java)
                    val wifiNet = cm?.allNetworks?.firstOrNull { net ->
                        cm.getNetworkCapabilities(net)
                            ?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) == true
                    }
                    val ok = withContext(Dispatchers.IO) { civ.connect(host, port, port2, port3, user, pass, wifiNet) }
                    if (!ok) errorMessage.postValue("CI-V reconnect failed: ${civ.lastError}")
                }
            }
            return
        }
        // On first successful CI-V poll, ensure DUP is Simplex (stream is confirmed open here)
        if (!civSimplexResetSent) {
            civSimplexResetSent = true
            withContext(Dispatchers.IO) {
                if (isCivBt) civBt.setTxShift(0L) else civ.setTxShift(0L)
            }
        }
        val now = System.currentTimeMillis()
        if (now - lastUserFreqChange > 1000) sharedFreq.value = st.freq
        if (st.mode != null && now - lastUserModeChange > 1000) {
            val newMode = st.mode.name
            if (newMode != sharedMode.value && newMode.isNotEmpty()) {
                sharedMode.value = newMode
                selectedStep.value = prefs.getModeStep(newMode)
            }
            sharedWidth.value = st.mode.filterWidth
        }
        // Only update S-meter when IC-705 actually returned a value (null = no response, keep last)
        st.signal?.let { sig ->
            var s = (sig + 54f) / 6f
            s = s.coerceIn(0f, 15f)
            sharedSignal.value = s
        }
        sharedTx.value = st.tx
        st.power?.let { if (now - lastUserPowerChange > 1000) sharedPower.value = it }
        st.sql?.let { if (now - lastUserSQLChange > 1000) sharedSQL.value = it }
        st.bkIn?.let { sharedBkIn.value = it }
        sharedRfOut.value = st.rfOut ?: if (!st.tx) 0f else sharedRfOut.value
        sharedAlc.value  = st.alc   ?: if (!st.tx) 0f else sharedAlc.value
    }

    /** When the Pi started answering with `freq == 0`, or 0 when it is reporting normally. */
    private var zeroFreqSinceMs: Long = 0L

    /** True while status polling is failing but the session is being kept alive (mirrors iOS linkLost). */
    val linkLost = MutableLiveData(false)
    /**
     * True while the Pi answers but reports it cannot reach the rig (`rig_ok == false`).
     * Kept apart from [linkLost] so it does not trigger the re-open done on Pi link recovery:
     * the Pi restarts rigctld by itself in that case.
     */
    val rigLinkLost = MutableLiveData(false)
    /** When the current run of consecutive poll failures started, or 0. */
    private var pollFailSinceMs: Long = 0L
    private val POLL_FAIL_GRACE_MS = 8_000L

    /**
     * Re-issues `/radio/open` with the stored selections, for when the Pi has restarted its
     * services. A restart loses the rig selection, the rigctld process and the background
     * polling threads, so resuming our own polling alone would read zeros forever.
     */
    /** When the last re-open was issued, so the cooldown below can be enforced. */
    private var lastReopenAtMs: Long = 0L

    private suspend fun reopenRigAfterRestart() {
        // Rate-limited, and that limit is not optional. rigctld needs several seconds after a
        // re-open before it reports a frequency, so the zero-frequency check that calls this
        // would see another zero and call it again, and each call restarts rigctld. The result
        // is a self-sustaining loop that knocks the rig's control link over repeatedly.
        val now = System.currentTimeMillis()
        if (now - lastReopenAtMs < 30_000L) return
        lastReopenAtMs = now
        val rig = (rigList.value ?: emptyList()).getOrNull(selectedRigIndex.value ?: 0) ?: return
        val cat = (catList.value ?: emptyList()).getOrNull(selectedCatIndex.value ?: 0) ?: return
        val baud = BAUD_RATES.getOrNull(selectedBaudIndex.value ?: 0) ?: return
        val ptt = selectedPttDevice.value ?: "NONE"
        val pttType = selectedPttType.value ?: "RTS"
        android.util.Log.i("Poll", "rig answers but freq=0 — reopening (model=${rig.id} cat=$cat)")
        withContext(Dispatchers.IO) { api.openRig(rig.id, cat, baud, ptt, pttType) }
    }

    private suspend fun updateStatus() {
        if (isDemoMode.value == true) { updateDemoStatus(); return }
        if (useCIV.value == true) { updateCivStatus(); return }
        val st = withContext(Dispatchers.IO) { api.getStatus() }
        if (st == null) {
            val now = System.currentTimeMillis()
            if (pollFailSinceMs == 0L) pollFailSinceMs = now
            if (linkLost.value != true && now - pollFailSinceMs >= POLL_FAIL_GRACE_MS) {
                linkLost.postValue(true)
            }
            return
        }
        if (linkLost.value == true) {
            linkLost.postValue(false)
            pollFailSinceMs = 0L
        } else {
            pollFailSinceMs = 0L
        }
        val now = System.currentTimeMillis()

        // The Pi answers but reports no frequency: rigctld is not open, so its polling threads
        // have nothing to read. That is the state a service restart leaves behind, and it used
        // to persist forever, with the app showing a healthy connection that could do nothing.
        // Re-open the rig once the zero has lasted a few seconds, long enough that a single
        // stale reading during a normal mode change does not trigger it.
        // Never while transmitting: PTT is on and the rig may legitimately not be reporting a
        // frequency, and re-opening would drop the transmission.
        if (st.freq == 0L && txEnabled.value != true && !st.tx) {
            if (zeroFreqSinceMs == 0L) zeroFreqSinceMs = now
            if (now - zeroFreqSinceMs >= 6_000L) {
                zeroFreqSinceMs = 0L
                reopenRigAfterRestart()
            }
        } else {
            zeroFreqSinceMs = 0L
        }

        // Hamlib STRENGTH: dBm relative to S9=0dBm, 6dB per S-unit
        // S0 ≈ -54dBm, S1=-48, S2=-42, ..., S9=0, S9+6dB=+6, S9+36dB=+36
        var s = (st.signal + 54f) / 6f
        s = s.coerceIn(0f, 15f)

        if (now - lastUserFreqChange > 1000) sharedFreq.value = st.freq
        if (now - lastUserModeChange > 1000) {
            val newMode = st.mode
            if (newMode != sharedMode.value && newMode.isNotEmpty()) {
                sharedMode.value = newMode
                selectedStep.value = prefs.getModeStep(newMode)
                updateCwAudioStreamForMode(newMode)
            }
        }
        if (now - lastUserPowerChange > 1000) sharedPower.value = st.power
        if (now - lastUserSQLChange > 1000) sharedSQL.value = st.sql
        if (now - lastUserWidthChange > 1000) sharedWidth.value = st.width
        sharedBkIn.value = st.bkIn
        if (st.bkInSupported != null) bkInSupported.value = st.bkInSupported
        sharedTuner.value = st.tuner
        sharedSignal.value = s
        sharedTx.value = st.tx
        sharedRfOut.value = st.rfOut ?: if (!st.tx) 0f else sharedRfOut.value
        sharedAlc.value   = st.alc   ?: if (!st.tx) 0f else sharedAlc.value
        aprsTxInProgress.value = st.txInProgress
        if (rigLinkLost.value != !st.rigOk) rigLinkLost.value = !st.rigOk
        if (st.apiVersion.isNotEmpty()) piVersionMismatch.value = st.apiVersion != EXPECTED_PI_API_VERSION

        // APRS TX state management: radio is TX and APRS is enabled → treat as APRS TX
        // Stop SPK on TX start, resume SPK on TX end (also blocks false external PTT detection)
        val nowAprsTxing = aprsActive.value == true && st.tx
        if (nowAprsTxing && !aprsTxing) {
            aprsTxing = true
            audio.stop()  // APRS TX start: stop RX audio
        } else if (!nowAprsTxing && aprsTxing) {
            aprsTxing = false
            if (spkEnabled.value == true && txEnabled.value != true) {
                startAudio()  // APRS TX end: resume RX audio
            }
        }

        // SPK watchdog: auto-reconnect every 15 seconds if SPK is ON but audio stopped or zombie
        // (zombie = AudioTrack.PLAYSTATE_PLAYING but Pi stopped sending data)
        if (spkEnabled.value == true && !audio.isDataFlowing && !audio.isStreamActive
                && txEnabled.value != true && !aprsTxing && !ft8FragmentActive
                && now - lastAudioWatchdogMs > 15_000L) {
            startAudio()
        }

        // External PTT detection: follow audio TX if radiocache becomes TX=true via M5 physical button etc.
        // Only active when useWifiPTT=true (M5Stack WiFi PTT device present).
        // Without a WiFi PTT device, there is no external PTT source; enabling this on plain Hamlib
        // connections causes false triggers (e.g. FT-991 in C4FM mode returns tx=true intermittently).
        // Skip if pttOffJob/audioTxStartJob is running or during cooldown right after Android PTT OFF
        // Block false external PTT detection during cwFmTxActive (CW FM TX in progress)
        // Skip when aprsActive to avoid falsely detecting APRS TX as external PTT
        val pttOffCooldown = System.currentTimeMillis() - lastAndroidPttOffTime < 5000
        val connectCooldown = System.currentTimeMillis() - lastConnectTime < 8000
        // CWキーヤー(USB/BT)がCWモードで有効な場合、無線機のTX状態はCWキーによるもの（外部PTTではない）
        val cwMode = (sharedMode.value ?: "").contains("CW", ignoreCase = true)
        val cwUsbCwActive = cwUsbEnabled.value == true && cwMode
        val cwBtCwActive  = cwBleEnabled.value == true && cwMode
        if (useWifiPTT.value == true && pttOffJob == null && audioTxStartJob == null && !pttOffCooldown && !connectCooldown && !cwFmTxActive && !cwTextTxActive && !cwUsbCwActive && !cwBtCwActive && aprsActive.value != true) {
            if (st.tx && txEnabled.value != true) {
                // External device started TX → start TX audio on Android too
                externalPttActive = true
                txEnabled.value = true
                audioTx.stop()
                viewModelScope.launch(Dispatchers.IO) { api.pttHeartbeat() }  // immediate watchdog reset (no rigctl)
                audioTxStartJob = viewModelScope.launch {
                    delay(300)
                    audioTx.start(api.getAudioTxUrl(txAudioRate()), apiKey.value ?: "")
                }
                startPttHeartbeat()  // 継続的なwatchdog更新
            } else if (!st.tx && txEnabled.value == true && externalPttActive) {
                // External device released PTT → stop TX on Android too
                externalPttActive = false
                txEnabled.value = false
                audioTx.stop()
                stopPttHeartbeat()
                viewModelScope.launch(Dispatchers.IO) { api.setPtt(false) }  // reset server last_ptt_state
                if (spkEnabled.value == true) startAudio()
            }
        }
    }

    fun fetchModeList() = viewModelScope.launch {
        if (isDemoMode.value == true) {
            supportedModes.value = listOf("USB", "LSB", "CW", "CWR", "AM", "FM", "RTTY", "RTTYR", "PKTUSB", "PKTLSB")
            return@launch
        }
        if (useCIV.value == true) {
            supportedModes.value = if (isCivBt) civBt.getSupportedModes() else civ.getSupportedModes()
            return@launch
        }
        val modes = withContext(Dispatchers.IO) { api.getCaps() }
        supportedModes.value = modes
    }

    /** SSBモードをリグが持たない場合、周波数に応じて USB/LSB に変換する */
    fun resolveMode(mode: String, freqHz: Long): String {
        if (mode.equals("SSB", ignoreCase = true) &&
            (supportedModes.value ?: emptyList()).none { it.equals("SSB", ignoreCase = true) }) {
            return if (freqHz >= 10_000_000L) "USB" else "LSB"
        }
        return mode
    }

    fun modeDefaultWidth(mode: String): Int = when {
        mode == "FM" || mode == "PKTFM" -> 12000
        mode == "FMN"                   -> 9000
        mode.startsWith("CW")           -> prefs.defaultCwWidth
        mode == "USB" || mode == "LSB"  -> prefs.defaultSsbWidth
        else                            -> 0
    }

    fun recallMemorySequenced(mem: MemoryEntry) {
        val targetFreq = mem.freqHz
        val mode = resolveMode(mem.mode, targetFreq)
        val width = modeDefaultWidth(mode)
        val stepIdx = if (mem.stepIndex >= 0) mem.stepIndex
                      else prefs.getModeStep(mode.ifEmpty { sharedMode.value ?: "" })
        viewModelScope.launch {
            delay(100L)
            if (mode.isNotEmpty()) {
                repeat(2) {
                    delay(150L)
                    sendMode(mode, width)
                }
                selectedStep.value = stepIdx
            }
            setRepeater(mem.toneMode.orEmpty(), mem.toneHz ?: 0.0, mem.offsetDir.orEmpty(), mem.offsetHz ?: 0L)
            repeat(3) {
                delay(150L)
                if (mode.isNotEmpty()) awaitMode(mode, width)
                awaitFreq(targetFreq)
            }
        }
    }

    fun recallFreqModeSequenced(freqHz: Long, mode: String, width: Int) {
        val stepIdx = prefs.getModeStep(mode.ifEmpty { sharedMode.value ?: "" })
        viewModelScope.launch {
            delay(100L)
            if (mode.isNotEmpty()) {
                repeat(2) {
                    delay(150L)
                    sendMode(mode, width)
                }
                selectedStep.value = stepIdx
            }
            repeat(3) {
                delay(150L)
                if (mode.isNotEmpty()) awaitMode(mode, width)
                awaitFreq(freqHz)
            }
        }
    }

    // モード先行・周波数後送で確実に順序を保証するsuspend版
    private suspend fun awaitMode(mode: String, width: Int) {
        lastUserModeChange = System.currentTimeMillis()
        sharedMode.value = mode
        updateCwAudioStreamForMode(mode)
        if (isDemoMode.value == true) return
        val modeToSend = if (mode.uppercase() == "USB-D") "PKTUSB" else mode
        val usesCIV = useCIV.value == true
        val bt = isCivBt
        withContext(Dispatchers.IO) {
            if (usesCIV) { if (bt) civBt.setMode(modeToSend, width) else civ.setMode(modeToSend, width) }
            else api.setMode(modeToSend, width)
        }
    }

    private suspend fun awaitFreq(freqHz: Long) {
        lastUserFreqChange = System.currentTimeMillis()
        sharedFreq.value = freqHz
        if (isDemoMode.value == true) return
        val usesCIV = useCIV.value == true
        val bt = isCivBt
        withContext(Dispatchers.IO) {
            if (usesCIV) { if (bt) civBt.setFrequency(freqHz) else civ.setFrequency(freqHz) }
            else api.setFreq(freqHz)
        }
    }

    fun sendFreq(freqHz: Long) {
        lastUserFreqChange = System.currentTimeMillis()
        sharedFreq.value = freqHz
        if (isDemoMode.value == true) return
        if (useCIV.value == true) {
            viewModelScope.launch(Dispatchers.IO) {
                if (isCivBt) civBt.setFrequency(freqHz) else civ.setFrequency(freqHz)
            }
        } else {
            viewModelScope.launch(Dispatchers.IO) { api.setFreq(freqHz) }
        }
    }

    fun sendMode(mode: String, width: Int) {
        lastUserModeChange = System.currentTimeMillis()
        sharedMode.value = mode
        updateCwAudioStreamForMode(mode)
        if (isDemoMode.value == true) return
        // "USB-D" is the display label for PKTUSB (IC-7300/IC-705 data mode).
        val modeToSend = if (mode.uppercase() == "USB-D") "PKTUSB" else mode
        // ★ モード変更で無線機側が周波数を変える機種がある(CWオフセット等でVFOがずれる)。
        //   変更前の周波数を記憶し、setMode後に同じ周波数で上書き再送してずれを打ち消す。
        //   再送直後のステータスポーリングが古い(ずれた)周波数で上書きしないよう
        //   lastUserFreqChangeも更新して抑制窓を張る。
        val freqToRestore = sharedFreq.value ?: 0L
        lastUserFreqChange = System.currentTimeMillis()
        if (useCIV.value == true) {
            viewModelScope.launch(Dispatchers.IO) {
                if (isCivBt) civBt.setMode(modeToSend, width) else civ.setMode(modeToSend, width)
                if (freqToRestore > 0L) {
                    if (isCivBt) civBt.setFrequency(freqToRestore) else civ.setFrequency(freqToRestore)
                }
                lastUserFreqChange = System.currentTimeMillis()
            }
        } else {
            viewModelScope.launch(Dispatchers.IO) {
                api.setMode(modeToSend, width)
                if (freqToRestore > 0L) api.setFreq(freqToRestore)
                lastUserFreqChange = System.currentTimeMillis()
            }
        }
    }

    private fun updateCwAudioStreamForMode(mode: String) {
        val isCwMode = mode.contains("CW", ignoreCase = true)
        if (cwUsbEnabled.value == true) {
            if (isCwMode) cwUsb.stopCwAudioStream() else cwUsb.startCwAudioStream(api, apiKey.value ?: "")
        }
        if (cwBleEnabled.value == true) {
            if (isCwMode) cwBle.stopCwAudioStream() else cwBle.startCwAudioStream(api, apiKey.value ?: "")
        }
    }

    fun toggleCwSidetone() {
        val next = !(cwSidetoneEnabled.value ?: true)
        cwSidetoneEnabled.value = next
        cwUsb.sidetoneEnabled = next
        cwBle.sidetoneEnabled = next
        prefs.cwSidetoneEnabled = next
    }

    fun sendPower(value: Float) {
        lastUserPowerChange = System.currentTimeMillis()
        sharedPower.value = value
        if (isDemoMode.value == true) return
        if (useCIV.value == true) {
            viewModelScope.launch(Dispatchers.IO) {
                if (isCivBt) civBt.setRfPower(value) else civ.setRfPower(value)
            }
        } else {
            viewModelScope.launch(Dispatchers.IO) { api.setPower(value) }
        }
    }

    fun sendBkIn(on: Boolean) {
        sharedBkIn.value = on
        if (isDemoMode.value == true) return
        if (useCIV.value == true) {
            viewModelScope.launch(Dispatchers.IO) {
                if (isCivBt) civBt.setBkIn(on) else civ.setBkIn(on)
            }
        } else {
            viewModelScope.launch(Dispatchers.IO) { api.setBkIn(on) }
        }
    }

    // アンテナチューナー(ATU)。state: 0=OFF / 1=ON / 2=TUNE開始。
    fun sendTuner(state: Int) {
        if (state != 2) sharedTuner.value = (state != 0)
        if (isDemoMode.value == true) return
        if (useCIV.value == true) {
            viewModelScope.launch(Dispatchers.IO) {
                if (isCivBt) civBt.setTuner(state) else civ.setTuner(state)
            }
        } else {
            viewModelScope.launch(Dispatchers.IO) { api.setTuner(state) }
        }
    }

    fun sendSQL(value: Float) {
        lastUserSQLChange = System.currentTimeMillis()
        sharedSQL.value = value
        if (isDemoMode.value == true) return
        if (useCIV.value == true) {
            viewModelScope.launch(Dispatchers.IO) {
                if (isCivBt) civBt.setSql(value) else civ.setSql(value)
            }
        } else {
            viewModelScope.launch(Dispatchers.IO) { api.setLevel("SQL", value) }
        }
    }

    fun sendVolume(value: Float) {
        lastUserVolumeChange = System.currentTimeMillis()
        sharedVolume.value = value
        prefs.volume = value
        audio.setVolume(value)
        if (isDemoMode.value != true) viewModelScope.launch(Dispatchers.IO) { api.setLevel("VOL", value) }
    }

    fun setPttEnabled(on: Boolean) {
        if (isDemoMode.value == true) {
            externalPttActive = false
            txEnabled.value = on
            return
        }
        // CI-V mode: software PTT via CI-V
        if (useCIV.value == true) {
            externalPttActive = false
            txEnabled.value = on
            viewModelScope.launch(Dispatchers.IO) {
                if (isCivBt) {
                    // BT CI-V: PTT via RFCOMM, TX audio via RS-BA1 hybrid if connected
                    civBt.setPtt(on)
                    if (civ.audioOnly && civ.isConnected) {
                        if (on) civ.startTxAudioCapture() else civ.stopTxAudioCapture()
                    }
                } else {
                    // WiFi CI-V: civ.setPtt() handles both PTT command and TX audio internally
                    civ.setPtt(on)
                }
            }
            return
        }
        externalPttActive = false  // Android takes over control
        txEnabled.value = on
        if (on) {
            // Stop polling: wait for in-flight Pi polling HTTP to complete, clear CAT bus
            stopStatusPolling()
            // Stop CW audio stream during PTT: prevents contention on audio_tx endpoint
            cwUsb.stopCwAudioStream()
            cwBle.stopCwAudioStream()
            // Cancel pending PTT OFF and force close
            val jobToCancel = pttOffJob
            if (jobToCancel != null) {
                android.util.Log.w("PTT", "cancelling pttOffJob active=${jobToCancel.isActive}")
                jobToCancel.cancel()
            }
            pttOffJob = null
            audioTx.stop()
            // Only stop Pi RX audio if SPK is on — in RTTY mode (SPK off) the stream
            // feeds only the modem/waterfall with no speaker output, so stopping it is
            // unnecessary and disrupts all connected clients (including iOS).
            if (spkEnabled.value == true) audio.stop()
            audioTxStartJob?.cancel()
            audioTxStartJob = null  // started inside pttOnJob after setPtt succeeds
            pttOnJob?.cancel()
            pttOnJob = viewModelScope.launch(Dispatchers.IO) {
                if (useWifiPTT.value == true) {
                    val h = pttHost.value
                    val pt = pttPort.value ?: 8888
                    android.util.Log.d("PTT", "WiFi PTT ON → host=$h port=$pt")
                    if (h.isNullOrEmpty()) {
                        android.util.Log.e("PTT", "pttHost is empty, skipping UDP")
                        return@launch
                    }
                    udpPtt.sendPtt(h, pt, true)
                    api.pttHeartbeat()
                    api.setPoll(false)
                    withContext(Dispatchers.Main) {
                        startPttHeartbeat()
                        audioTxStartJob = viewModelScope.launch {
                            delay(300)
                            audioTx.start(api.getAudioTxUrl(txAudioRate()), apiKey.value ?: "")
                        }
                    }
                } else {
                    android.util.Log.d("PTT", "Hamlib PTT ON")
                    // Send setPoll(false) first: stop Pi background polling
                    api.setPoll(false)
                    // CAT response completion buffer: wait until in-flight poll_rig() command clears the rigctld queue
                    delay(100L)
                    if (txEnabled.value == true) {
                        // FTX-1F等、PTT ONで音声USBが瞬断しPi側のrigctldごと再起動する
                        // ことがあり(USB再列挙+CAT再接続で通常2〜3秒、まれにそれ以上)、
                        // 固定5回×200ms(実質約1秒)では復旧を待ちきれず諦めてしまうこと
                        // があった。固定回数ではなく経過時間ベースで最大5秒間リトライし
                        // 続けることで取りこぼしを防ぐ(M5/ESP32側と同じ方針)。
                        var sent = false
                        val deadline = System.currentTimeMillis() + 5000
                        while (true) {
                            if (api.setPtt(true)) { sent = true; break }
                            if (!isActive || txEnabled.value != true) break
                            if (System.currentTimeMillis() >= deadline) break
                            delay(200)
                        }
                        // Start heartbeat and mic audio only after setPtt succeeds
                        if (sent && txEnabled.value == true) {
                            withContext(Dispatchers.Main) {
                                startPttHeartbeat()
                                audioTxStartJob = viewModelScope.launch {
                                    audioTx.start(api.getAudioTxUrl(txAudioRate()), apiKey.value ?: "")
                                }
                            }
                        }
                    }
                }
            }
            // startPttHeartbeat() and audioTxStartJob are started inside pttOnJob after setPtt(true) succeeds
        } else {
            lastAndroidPttOffTime = System.currentTimeMillis()
            audioTxStartJob?.cancel()
            audioTxStartJob = null
            audioTx.gracefulStop()
            stopPttHeartbeat()
            pttOffJob = viewModelScope.launch {
                withContext(Dispatchers.IO) {
                    audioTx.awaitDrain(500)
                    // drain margin for aplay -B 100000 (100ms) buffer
                    delay(100)
                    // Stop audio before PTT OFF: prevents aplay echo through RX speaker
                    audioTx.stop()
                    // Wait for ON command HTTP completion before sending OFF
                    pttOnJob?.join()
                    if (txEnabled.value != true) {
                        if (useWifiPTT.value == true) {
                            val h = pttHost.value
                            val pt = pttPort.value ?: 8888
                            if (!h.isNullOrEmpty()) udpPtt.sendPtt(h, pt, false)
                            api.setPtt(false)
                            api.setPoll(true)
                        } else {
                            if (!api.setPtt(false)) {
                                delay(200)
                                api.setPtt(false)
                            }
                            api.setPoll(true)
                        }
                    }
                }
                // Abort here if cancelled by re-pressing PTT ON
                android.util.Log.w("PTT", "pttOffJob after withContext: isActive=$isActive txEnabled=${txEnabled.value}")
                if (!isActive) return@launch
                // Start SPK after PTT OFF confirmed: aplay has ended and ffmpeg can start immediately
                if (txEnabled.value != true) {
                    if (spkEnabled.value == true) startAudio()
                    startStatusPolling()
                    // Restore CW audio stream after PTT (non-CW modes only)
                    updateCwAudioStreamForMode(sharedMode.value ?: "")
                }
                pttOffJob = null
            }
        }
    }

    fun suppressExternalPttDetection() {
        lastAndroidPttOffTime = System.currentTimeMillis()
    }

    /** Fragment のライフサイクルに依存せず PTT OFF を Pi に送信する（FT8 画面離脱時用）*/
    fun releasePttBackground() {
        viewModelScope.launch(Dispatchers.IO) {
            try { api.setPtt(false) } catch (_: Exception) {}
        }
    }

    private fun startPttHeartbeat() {
        pttHeartbeatJob?.cancel()
        serverWatchdogJob?.cancel()
        pttHeartbeatJob = viewModelScope.launch {
            while (isActive) {
                delay(500)
                withContext(Dispatchers.IO) {
                    if (useWifiPTT.value == true) {
                        // WiFi PTT mode: send UDP only (fast, non-blocking)
                        val h = pttHost.value
                        val pt = pttPort.value ?: 8888
                        if (!h.isNullOrEmpty()) udpPtt.sendPtt(h, pt, true)
                    } else {
                        // Hamlib mode: update last_heartbeat only
                        // Using setPtt(true) risks a race where in-flight response arrives after setPtt(false),
                        // restarting TX from last_ptt_state=0
                        api.pttHeartbeat()
                    }
                    Unit
                }
            }
        }
        // WiFi PTT mode: run server watchdog update in a separate job
        // Decouple HTTP from UDP heartbeat to eliminate delay impact
        if (useWifiPTT.value == true) {
            serverWatchdogJob = viewModelScope.launch {
                while (isActive) {
                    delay(2000)
                    withContext(Dispatchers.IO) { api.pttHeartbeat() }  // reset watchdog without rigctl
                }
            }
        }
    }

    private fun stopPttHeartbeat() {
        pttHeartbeatJob?.cancel()
        pttHeartbeatJob = null
        serverWatchdogJob?.cancel()
        serverWatchdogJob = null
    }

    fun txAudioRate(): Int {
        val idx = selectedTxSamplingIndex.value ?: 1
        return SAMPLING_RATES.getOrElse(idx) { 8000 }.let { if (it == 0) 8000 else it }
    }

    fun startAudio() {
        if (isDemoMode.value == true) return
        if (useCIV.value == true) return  // CI-V mode has no Pi audio streaming
        if (hostName.value.isNullOrEmpty()) return
        if (txEnabled.value == true) return  // don't start SPK during TX
        if (aprsTxing) return                // don't start SPK during APRS TX
        val aPort = audioPort.value ?: 50000
        val sIdx = selectedSamplingIndex.value ?: 1
        val rate = SAMPLING_RATES.getOrElse(sIdx) { 0 }
        if (rate == 0) return
        lastAudioWatchdogMs = System.currentTimeMillis()
        // onError checks APRS state at error time (not at startAudio() call time):
        // Silence errors for 120 seconds after APRS stop to wait for Pi Zero audio service restart
        audio.start(
            url = api.getAudioStreamUrl(aPort, rate),
            vol = sharedVolume.value ?: 0.5f,
            apiKey = apiKey.value ?: "",
            onError = { msg ->
                val inGrace = aprsStoppedAt > 0 && System.currentTimeMillis() - aprsStoppedAt < 120_000L
                if (aprsActive.value != true && !inGrace) {
                    audioError.postValue(msg)
                }
            }
        )
    }

    fun stopAudio() = audio.stop()

    // CI-V mode SPK control.
    // WiFi CI-V: toggle AudioTrack in CivTcpService (RS-BA1 audio).
    // BT CI-V: connect CivTcpService in audio-only mode via RS-BA1 WiFi, if host is configured.
    fun civSetSpk(on: Boolean) {
        if (!isCivBt) { civ.spkEnabled = on; return }
        // BT CI-V hybrid: RS-BA1 audio session is connected at connect time
        if (on) {
            if (!civ.audioOnly || !civ.isConnected) {
                spkEnabled.value = false  // revert UI state so button doesn't show ON with no audio
                errorMessage.value = "BT CI-V audio: Enter RS-BA1 Audio Host on Connect screen and reconnect"
                return
            }
            civ.spkEnabled = true
        } else {
            civ.spkEnabled = false
        }
    }

    fun toggleAprs() {
        if (isDemoMode.value == true) return
        viewModelScope.launch {
            if (aprsUseRigModem.value == true) {
                // FTX-1内蔵モデム: OFF → AP96(preset1) → AP12(preset2) → OFF
                when {
                    aprsActive.value != true -> {
                        val cfg = buildAprsConfig().copy(
                            freq = aprsPreset1Freq.value ?: 144.660f,
                            baud = aprsPreset1Baud.value ?: 9600
                        )
                        val ok = runCatching {
                            withContext(Dispatchers.IO) {
                                api.setPoll(false)
                                api.sendAprsConfig(cfg)
                                delay(1500)
                                api.startAprs(cfg)
                            }
                        }.isSuccess
                        if (ok) {
                            aprsActive.value = true
                            aprsAtPreset2.value = false
                            startAprsHeartbeat()
                            android.widget.Toast.makeText(getApplication(), "APRS (AP96) started", android.widget.Toast.LENGTH_SHORT).show()
                        } else {
                            runCatching { withContext(Dispatchers.IO) { api.setPoll(true) } }
                            android.widget.Toast.makeText(getApplication(), "APRS start failed (Pi unreachable?)", android.widget.Toast.LENGTH_LONG).show()
                        }
                    }
                    aprsAtPreset2.value != true -> {
                        // AP96稼働中 → AP12に切替(停止せずconfig送信のみ)
                        val cfg = buildAprsConfig().copy(
                            freq = aprsPreset2Freq.value ?: 144.660f,
                            baud = aprsPreset2Baud.value ?: 1200
                        )
                        val ok = runCatching {
                            withContext(Dispatchers.IO) { api.sendAprsConfig(cfg) }
                        }.isSuccess
                        if (ok) {
                            aprsAtPreset2.value = true
                            android.widget.Toast.makeText(getApplication(), "Switched to AP12", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                    else -> {
                        // AP12稼働中 → 停止
                        runCatching { withContext(Dispatchers.IO) { api.stopAprs(); api.setPoll(true) } }
                        aprsTxing = false
                        aprsStoppedAt = System.currentTimeMillis()
                        aprsActive.value = false
                        aprsAtPreset2.value = false
                        stopAprsHeartbeat()
                        stopAprsLocationUpdates()
                        if (spkEnabled.value == true && txEnabled.value != true) startAudio()
                    }
                }
            } else {
                // DireWolfモード: 従来のON/OFFトグル
                if (aprsActive.value != true) {
                    if (cwTxBusy.value == true) stopCwText()
                    fetchLatestGpsForAprs()
                    val cfg = buildAprsConfig()
                    val ok = runCatching {
                        withContext(Dispatchers.IO) {
                            api.setPoll(false)
                            api.sendAprsConfig(cfg)
                            if (cfg.useGps) {
                                val lat = aprsLat.value ?: 0f
                                val lon = aprsLon.value ?: 0f
                                if (lat != 0f || lon != 0f) api.sendGps(lat, lon)
                            }
                            delay(1500)
                            api.startAprs(cfg)
                        }
                    }.isSuccess
                    if (ok) {
                        aprsActive.value = true
                        startAprsLocationUpdates()
                        startAprsHeartbeat()
                        android.widget.Toast.makeText(getApplication(), "APRS started", android.widget.Toast.LENGTH_SHORT).show()
                    } else {
                        runCatching { withContext(Dispatchers.IO) { api.setPoll(true) } }
                        if (spkEnabled.value == true && txEnabled.value != true) startAudio()
                        android.widget.Toast.makeText(getApplication(), "APRS start failed (Pi unreachable?)", android.widget.Toast.LENGTH_LONG).show()
                    }
                } else {
                    runCatching { withContext(Dispatchers.IO) { api.stopAprs(); api.setPoll(true) } }
                    aprsTxing = false
                    aprsStoppedAt = System.currentTimeMillis()
                    aprsActive.value = false
                    stopAprsLocationUpdates()
                    stopAprsHeartbeat()
                    if (spkEnabled.value == true && txEnabled.value != true) startAudio()
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun fetchLatestGpsForAprs() {
        if (aprsUseGPS.value != true) return
        val ctx = getApplication<Application>()
        val hasFine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val hasCoarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!hasFine && !hasCoarse) return
        val lm = ctx.getSystemService(LocationManager::class.java) ?: return
        // Get latest known location from both GPS and Network providers
        val loc = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { lm.isProviderEnabled(it) }
            .firstNotNullOfOrNull { lm.getLastKnownLocation(it) } ?: return
        aprsLat.value = loc.latitude.toFloat()
        aprsLon.value = loc.longitude.toFloat()
    }

    @SuppressLint("MissingPermission")
    fun startAprsLocationUpdates() {
        if (aprsUseGPS.value != true) return
        val ctx = getApplication<Application>()
        val hasFine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val hasCoarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!hasFine && !hasCoarse) return
        val lm = ctx.getSystemService(LocationManager::class.java) ?: return
        locationManager = lm
        val listener = LocationListener { loc ->
            val lat = loc.latitude.toFloat()
            val lon = loc.longitude.toFloat()
            aprsLat.postValue(lat)
            aprsLon.postValue(lon)
            viewModelScope.launch(Dispatchers.IO) { api.sendGps(lat, lon) }
        }
        locationListener = listener
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { lm.isProviderEnabled(it) }
        // Register both GPS and Network providers (30 second interval)
        for (p in providers) {
            lm.requestLocationUpdates(p, 30000L, 10f, listener, Looper.getMainLooper())
        }
        // Immediately initialize with last known location
        providers.firstNotNullOfOrNull { lm.getLastKnownLocation(it) }?.let {
            aprsLat.postValue(it.latitude.toFloat())
            aprsLon.postValue(it.longitude.toFloat())
        }
    }

    fun stopAprsLocationUpdates() {
        locationListener?.let { locationManager?.removeUpdates(it) }
        locationListener = null
        locationManager = null
    }

    private fun startAprsHeartbeat() {
        aprsHeartbeatJob?.cancel()
        var tick = 0
        aprsHeartbeatJob = viewModelScope.launch {
            while (isActive) {
                delay(10000)  // watchdog update every 10 seconds
                tick++
                val isConfigTick = tick % 3 == 0
                // LiveData は Main スレッドで読み取る
                val lat = aprsLat.value ?: 0f
                val lon = aprsLon.value ?: 0f
                val useGps = aprsUseGPS.value == true
                val cfg = if (isConfigTick) {
                    val base = buildAprsConfig()
                    // rig modem mode: use active preset freq/baud (not DireWolf defaults)
                    if (base.useRigModem) {
                        if (aprsAtPreset2.value == true)
                            base.copy(freq = aprsPreset2Freq.value ?: 144.660f, baud = aprsPreset2Baud.value ?: 1200)
                        else
                            base.copy(freq = aprsPreset1Freq.value ?: 144.660f, baud = aprsPreset1Baud.value ?: 9600)
                    } else base
                } else null
                withContext(Dispatchers.IO) {
                    if (isConfigTick && useGps && (lat != 0f || lon != 0f)) api.sendGps(lat, lon)
                    api.sendAprsHeartbeat()
                    // 設定を30秒ごとに再送してサーバーとの不整合を防ぐ
                    if (cfg != null) runCatching { api.sendAprsConfig(cfg) }
                }
            }
        }
    }

    private fun stopAprsHeartbeat() {
        aprsHeartbeatJob?.cancel()
        aprsHeartbeatJob = null
    }

    /** TX Method切替やモード変更前にAPRSを確実に停止する。 */
    suspend fun stopAprsForModeSwitch() {
        withContext(Dispatchers.IO) { runCatching { api.stopAprs(); api.setPoll(true) } }
        aprsActive.value = false
        aprsAtPreset2.value = false
        stopAprsHeartbeat()
        stopAprsLocationUpdates()
    }

    suspend fun saveAprsConfig(cfg: AprsConfig): Boolean {
        val ok = withContext(Dispatchers.IO) { api.sendAprsConfig(cfg) }
        if (ok) {
            aprsEnabled.value = cfg.enabled
            aprsCallsign.value = cfg.callsign
            aprsSSID.value = cfg.ssid
            aprsPath.value = cfg.path
            aprsIntervalSec.value = cfg.interval
            aprsTxFreq.value = cfg.freq
            aprsBaud.value = cfg.baud
            aprsLat.value = cfg.manualLat
            aprsLon.value = cfg.manualLon
            aprsSymbol.value = cfg.symbol
            aprsComment.value = cfg.comment
            aprsDestination.value = cfg.destination
            aprsSoundDevice.value = cfg.soundDevice

            prefs.aprsEnabled = aprsEnabled.value ?: false
            prefs.aprsCallsign = cfg.callsign
            prefs.aprsSSID = cfg.ssid
            prefs.aprsPath = cfg.path
            prefs.aprsIntervalSec = cfg.interval
            prefs.aprsTxFreq = cfg.freq
            prefs.aprsBaud = cfg.baud
            prefs.aprsUseGPS = aprsUseGPS.value ?: false
            prefs.aprsLat = cfg.manualLat
            prefs.aprsLon = cfg.manualLon
            prefs.aprsSymbol = cfg.symbol
            prefs.aprsComment = cfg.comment
            prefs.aprsDestination = cfg.destination
            prefs.aprsSoundDevice = cfg.soundDevice
            prefs.aprsUseRigModem = cfg.useRigModem
            prefs.aprsModemSel = cfg.modemSel
            prefs.aprsPreset1Freq = aprsPreset1Freq.value ?: 144.660f
            prefs.aprsPreset1Baud = aprsPreset1Baud.value ?: 9600
            prefs.aprsPreset2Freq = aprsPreset2Freq.value ?: 144.660f
            prefs.aprsPreset2Baud = aprsPreset2Baud.value ?: 1200
        }
        return ok
    }

    fun buildAprsConfig(): AprsConfig {
        val rig = rigList.value?.getOrNull(selectedRigIndex.value ?: 0)
        val cat = catList.value?.getOrElse(selectedCatIndex.value ?: 0) { "" } ?: ""
        return AprsConfig(
            callsign = aprsCallsign.value ?: "",
            ssid = aprsSSID.value ?: 0,
            path = aprsPath.value ?: "WIDE1-1",
            interval = aprsIntervalSec.value ?: 60,
            freq = aprsTxFreq.value ?: 144.660f,
            baud = aprsBaud.value ?: 1200,
            useGps = aprsUseGPS.value ?: false,
            manualLat = aprsLat.value ?: 0f,
            manualLon = aprsLon.value ?: 0f,
            symbol = aprsSymbol.value ?: ">",
            comment = aprsComment.value ?: "",
            destination = aprsDestination.value ?: "APRS00",
            soundDevice = aprsSoundDevice.value ?: "",
            rigId = rig?.id?.toString() ?: "",
            catDevice = cat,
            useRigModem = aprsUseRigModem.value ?: false,
            modemSel = aprsModemSel.value ?: 2,
            enabled = aprsEnabled.value ?: false
        )
    }

    fun fetchVfoState() {
        if (isDemoMode.value == true || useCIV.value == true) return
        viewModelScope.launch(Dispatchers.IO) {
            val mode = api.getVfoMode() ?: return@launch
            val side = api.getVfoCurrent() ?: ""
            vfoMode.postValue(mode)
            vfoCurrentSide.postValue(side)
        }
    }

    fun toggleVfo() {
        if (isDemoMode.value == true || useCIV.value == true) return
        viewModelScope.launch(Dispatchers.IO) {
            val newSide = api.vfoToggle() ?: return@launch
            vfoCurrentSide.postValue(newSide)
        }
    }

    fun fetchAprsReceived() {
        viewModelScope.launch(Dispatchers.IO) {
            val stations = api.getAprsReceived()
            aprsReceivedStations.postValue(stations)
        }
    }

    fun startAprsReceivedPolling() {
        if (aprsReceivedPollingJob?.isActive == true) return
        aprsReceivedPollingJob = viewModelScope.launch {
            while (isActive) {
                // 受信局リスト更新
                val stations = withContext(Dispatchers.IO) { api.getAprsReceived() }
                aprsReceivedStations.postValue(stations)
                // 新着ビーコン通知(FastAPIが管理するAndroid専用キューを消費)
                val events = withContext(Dispatchers.IO) { api.getAprsNotifyAndroid() }
                if (events.isNotEmpty()) {
                    aprsToastStation.postValue(events.first())
                }
                delay(6000)
            }
        }
    }

    fun stopAprsReceivedPolling() {
        aprsReceivedPollingJob?.cancel()
        aprsReceivedPollingJob = null
    }

    suspend fun getSetupLog(): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        api.getSetupLog()
    }

    suspend fun quickUpdatePiApi(): String? = withContext(Dispatchers.IO) {
        try {
            val apiBytes = getApplication<Application>().assets.open("api.py").readBytes()
            api.sendApiUpdate(apiBytes)
        } catch (e: Exception) { e.message }
    }

    suspend fun updatePiSoftware(): String? = withContext(Dispatchers.IO) {
        try {
            val app = getApplication<Application>()
            val apiBytes = app.assets.open("api.py").readBytes()
            val apiErr = api.sendApiUpdate(apiBytes)
            if (apiErr != null) return@withContext apiErr
            // api.py sent successfully. Wait for Pi restart then send create_api.sh
            // Pi Zero restart can take 20-30s; retry up to 8 times x 5s = 40s
            val scriptBytes = app.assets.open("create_api.sh").readBytes()
            var setupErr: String? = null
            for (attempt in 1..8) {
                Thread.sleep(5000)
                setupErr = api.sendSetupScript(scriptBytes)
                if (setupErr == null) break
            }
            if (setupErr != null) return@withContext "api.py OK / setup: $setupErr"

            // Poll setup_log until create_api.sh finishes ("=== DONE ===").
            // Marker is ASCII to avoid JSON Unicode-escape decode issues in the regex parser.
            // Timeout is 8 min — heredoc writes on Pi Zero SD card can take several minutes.
            // Note: do NOT re-send api.py here — create_api.sh already restores api.py.bak2
            // (the version we just sent). Re-sending triggers _restart() in FastAPI which kills
            // the reboot subprocess (same cgroup), causing the subsequent reboot to fail silently.
            val setupDeadline = System.currentTimeMillis() + 480_000L
            var setupFinished = false
            while (System.currentTimeMillis() < setupDeadline) {
                Thread.sleep(3000)
                val (_, log) = try { api.getSetupLog() } catch (e: Exception) { false to "" }
                if (log.contains("=== DONE ===")) { setupFinished = true; break }
            }

            if (!setupFinished) return@withContext "setup timeout. Restart Pi."

            null
        } catch (e: Exception) { e.message }
    }

    suspend fun installHamlib(): String? = withContext(Dispatchers.IO) {
        try {
            val app = getApplication<Application>()
            val scriptBytes = app.assets.open("install_hamlib.sh").readBytes()
            val err = api.sendHamlibInstall(scriptBytes)
            if (err != null) return@withContext err
            // Poll /admin/hamlib_log until install_hamlib.sh finishes — up to 60 minutes.
            // install_hamlib.sh echoes "=== 完了 ===" (not the ASCII "=== DONE ===" that
            // create_api.sh uses), so match the marker the script actually prints. Matching
            // only "=== DONE ===" made this loop run the full 60 min and report a timeout
            // even though the build had succeeded. iOS polls for the same marker.
            val deadline = System.currentTimeMillis() + 3_600_000L
            while (System.currentTimeMillis() < deadline) {
                Thread.sleep(10_000)
                val (_, log) = try { api.getHamlibLog() } catch (e: Exception) { false to "" }
                if (log.contains("=== 完了 ===") || log.contains("=== DONE ===")) return@withContext null
                val errLine = log.lines().lastOrNull { it.contains("エラー:") }
                if (errLine != null) return@withContext "Build failed: $errLine"
            }
            "Build timeout (60min exceeded)"
        } catch (e: Exception) { e.message }
    }

    suspend fun rebootPiAndWait(): String = withContext(Dispatchers.IO) {
        // api.py 再送直後は FastAPI が再起動中のため、成功するまでリトライ
        val readyDeadline = System.currentTimeMillis() + 30_000L
        var rebooted = false
        while (System.currentTimeMillis() < readyDeadline) {
            if (api.rebootPi()) { rebooted = true; break }
            Thread.sleep(3000)
        }
        if (!rebooted) return@withContext "Reboot failed — Pi unreachable"
        // Pi Zero: reboot cmd runs after 2s sleep; shutdown takes 10-20s total.
        // Wait for Pi to go OFFLINE first, then wait for it to come back up.
        val offlineDeadline = System.currentTimeMillis() + 45_000L
        var wentOffline = false
        while (System.currentTimeMillis() < offlineDeadline) {
            Thread.sleep(3000)
            if (api.getStatus() == null) { wentOffline = true; break }
        }
        val deadline = System.currentTimeMillis() + 150_000L
        while (System.currentTimeMillis() < deadline) {
            if (api.getStatus() != null) return@withContext "Pi reboot complete"
            Thread.sleep(5000)
        }
        "Pi reboot timeout — check connection"
    }

    suspend fun triggerMfskBuildAfterUpdate(): String = withContext(Dispatchers.IO) {
        // Pi Zero の起動は遅い。FastAPI が安定するまで最大60秒待つ。
        for (attempt in 1..20) {
            Thread.sleep(3000)
            val err = try { api.triggerMfskBuild(force = true) } catch (e: Exception) { e.message }
            if (err == null) {
                // ワーカーがログを書き始めるまで最大15秒待つ
                val deadline = System.currentTimeMillis() + 15_000L
                while (System.currentTimeMillis() < deadline) {
                    Thread.sleep(2000)
                    val (running, log) = try { api.getMfskBuildLog() } catch (_: Exception) { false to "" }
                    if (running || log.contains("ビルド開始")) return@withContext "mfsk build started"
                }
                return@withContext "mfsk build started (log pending)"
            }
        }
        "mfsk build trigger failed (Pi unreachable?)"
    }

    suspend fun syncPiTime(): String = withContext(Dispatchers.IO) {
        // 同期前のPi時刻ずれを測定
        val preOffsetMs = try { api.getPiClockOffsetMs() } catch (_: Exception) { null }
        // Android側でも NTP に問い合わせて正確な時刻を取得する
        val ntpMs = com.ji1ore.wifi_rig_ctrl.data.queryNtpMs()
        val nowMs = ntpMs ?: System.currentTimeMillis()
        val androidSource = if (ntpMs != null) "NTP" else "SystemClock"
        val r = try { api.syncTime(nowMs) } catch (e: Exception) { return@withContext "Sync failed: ${e.message}" }
        if (!r.ok) return@withContext "Sync failed"
        val piSource = when {
            r.source.startsWith("ntp_chrony")      -> "NTP(chrony)"
            r.source.startsWith("ntp_ntpdate")     -> "NTP(ntpdate)"
            r.source.startsWith("ntp_timedatectl") -> "NTP(timedatectl)"
            r.source == "android"                  -> "Android[$androidSource]"
            else -> r.source
        }
        val preStr = preOffsetMs?.let {
            val s = if (it > 0) "+${it}" else "$it"
            " (pre-sync offset ${s}ms)"
        } ?: ""
        "Sync OK[$piSource]$preStr"
    }

    suspend fun updateCwBridge(): String? = withContext(Dispatchers.IO) {
        try {
            val app = getApplication<Application>()
            val bytes = app.assets.open("cw_bridge.py").readBytes()
            api.sendCwBridgeUpdate(bytes)
        } catch (e: Exception) { e.message }
    }

    fun setCustomCatDevice(device: String) {
        prefs.savedCat = device
        val current = catList.value?.toMutableList() ?: mutableListOf()
        val noneIdx = current.indexOf("None")
        if (noneIdx >= 0) {
            current[noneIdx] = device
        } else {
            current.add(0, device)
        }
        catList.value = current
        selectedCatIndex.value = current.indexOf(device).coerceAtLeast(0)
    }

    // ───────── CW UDP key send (dedicated send thread) ─────────
    // DNS/network waits on the USB read thread would block all sends after the first,
    // so a LinkedBlockingQueue + dedicated send thread frees the USB thread.

    @Volatile private var cwUdpSocket: java.net.DatagramSocket? = null
    @Volatile private var cwUdpAddr: java.net.InetAddress? = null
    private val cwSendQueue = java.util.concurrent.LinkedBlockingQueue<ByteArray>(64)
    private var cwSendThread: Thread? = null
    private var cwNetworkCallback: android.net.ConnectivityManager.NetworkCallback? = null

    private fun startCwSendThread() {
        cwSendThread?.interrupt()
        cwSendThread = Thread {
            while (!Thread.currentThread().isInterrupted) {
                try {
                    val pkt = cwSendQueue.poll(5, java.util.concurrent.TimeUnit.SECONDS) ?: continue
                    doSendCwUdp(pkt)
                } catch (_: InterruptedException) { break }
            }
        }.also { it.isDaemon = true; it.start() }
        registerCwNetworkCallback()
    }

    private fun stopCwSendThread() {
        unregisterCwNetworkCallback()
        cwSendThread?.interrupt()
        cwSendThread = null
        cwSendQueue.clear()
    }

    private fun resetCwUdpSocket() {
        val old = cwUdpSocket
        cwUdpSocket = null
        cwUdpAddr = null
        try { old?.close() } catch (_: Exception) {}
        android.util.Log.i("CwUdp", "UDP socket reset on network change")
    }

    private fun registerCwNetworkCallback() {
        val cm = getApplication<Application>()
            .getSystemService(android.net.ConnectivityManager::class.java) ?: return
        cwNetworkCallback?.let { try { cm.unregisterNetworkCallback(it) } catch (_: Exception) {} }
        val cb = object : android.net.ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: android.net.Network) = resetCwUdpSocket()
            override fun onLost(network: android.net.Network) = resetCwUdpSocket()
        }
        try { cm.registerDefaultNetworkCallback(cb); cwNetworkCallback = cb } catch (_: Exception) {}
    }

    private fun unregisterCwNetworkCallback() {
        val cb = cwNetworkCallback ?: return
        try {
            getApplication<Application>()
                .getSystemService(android.net.ConnectivityManager::class.java)
                ?.unregisterNetworkCallback(cb)
        } catch (_: Exception) {}
        cwNetworkCallback = null
    }

    private fun doSendCwUdp(packet: ByteArray) {
        val host = prefs.hostName
        if (host.isEmpty()) return
        try {
            if (cwUdpSocket == null || cwUdpSocket!!.isClosed) {
                cwUdpSocket = java.net.DatagramSocket()
                cwUdpAddr = java.net.InetAddress.getByName(host)
            }
            val sock = cwUdpSocket ?: run { android.util.Log.w("CwRelay", "sock=null"); return }
            val addr = cwUdpAddr ?: run { android.util.Log.w("CwRelay", "addr=null"); return }
            android.util.Log.d("CwRelay", "UDP send key=${packet[0].toInt()} x$CW_SEND_REPEAT to ${addr.hostAddress}:$CW_UDP_PORT")
            // Redundant send: survive sporadic/burst UDP loss on a congested WiFi
            // (worse when WiFi_RIG audio stream + CAT polling run concurrently).
            // opTimeMs is identical across copies, so the server collapses them to one event.
            for (r in 0 until CW_SEND_REPEAT) {
                sock.send(java.net.DatagramPacket(packet, packet.size, addr, CW_UDP_PORT))
                if (r < CW_SEND_REPEAT - 1) {
                    try { Thread.sleep(CW_SEND_SPACING_MS) } catch (_: InterruptedException) { break }
                }
            }
        } catch (e: Exception) {
            android.util.Log.w("CwUdp", "send error: ${e.message}")
            cwUdpSocket = null
        }
    }

    // ───────── FM CW VOX session management ─────────
    // Called from USB key or PTT button CW tone mode (callable from USB thread)

    private fun cwFmKeyOn() {
        cwFmTailJob?.cancel()  // cancel tail wait (session continues)
        cwFmTailJob = null
        if (cwFmTxActive) {
            // Race guard: tail job may have stopped heartbeat before being cancelled
            if (pttHeartbeatJob?.isActive != true) startPttHeartbeat()
            return
        }
        cwFmTxActive = true  // volatile: visible from main thread
        txEnabled.postValue(true)
        cwFmPttJob?.cancel()
        cwFmPttJob = viewModelScope.launch(Dispatchers.IO) {
            // ★ RX音声ストリーム(audio)は止めない。送信のたびに停止→再接続すると
            //   復帰に数百ms〜1秒かかるため(iOS版は元々止めていない)。TX中は無線機側AFが
            //   無音になるだけで、ストリーム接続は維持したままにして復帰遅延を排除する。
            api.setPoll(false)
            delay(80L)
            api.setPtt(true)
            withContext(Dispatchers.Main) { startPttHeartbeat() }  // extend watchdog
        }
    }

    private fun cwFmKeyOff() {
        if (!cwFmTxActive) return
        cwFmTailJob?.cancel()
        cwFmTailJob = viewModelScope.launch {
            // VOXテール: 既定500ms。cwFmDelayMs(>0)が設定されていればその値を使用。
            val tailMs = (cwFmDelayMs.value ?: 0).let { if (it <= 0) 500L else it.toLong() }
            delay(tailMs)
            stopPttHeartbeat()
            cwFmPttJob?.cancel()
            cwFmPttJob = null
            lastAndroidPttOffTime = System.currentTimeMillis()
            withContext(Dispatchers.IO) {
                delay(60)  // wait for last tone chunk to drain
                api.setPtt(false)
                api.setPoll(true)
            }
            cwFmTxActive = false
            txEnabled.value = false
            cwFmTailJob = null
            // RXストリームは維持しているので通常は再接続不要。万一切れていれば再開のみ。
            if (spkEnabled.value == true && !audio.isDataFlowing) startAudio()
        }
    }

    // ───────── CW USB relay ─────────

    fun connectCwUsb(device: android.hardware.usb.UsbDevice) {
        // Prevent double connection from onResume() scan and ACTION_USB_PERMISSION firing simultaneously
        if (cwUsb.isConnected || cwUsbConnecting) return
        cwUsbConnecting = true

        cwUsb.onConnectionStateChange = { connected ->
            cwUsbConnected.postValue(connected)
            if (!connected) viewModelScope.launch(Dispatchers.Main) { releaseCwWifiLock() }
        }
        cwUsb.onWpmChange = { wpm ->
            // M5ボタンでWPMが変更された → Android側のWPM設定も同期
            prefs.cwWpm = wpm
            cwWpm.postValue(wpm)
        }
        cwUsb.onAudioStreamNeeded = {
            val mode = sharedMode.value ?: ""
            val pttActive = txEnabled.value == true
            if (!mode.contains("CW", ignoreCase = true) && cwUsbEnabled.value == true && !pttActive) {
                viewModelScope.launch(Dispatchers.Main) {
                    cwUsb.startCwAudioStream(api, apiKey.value ?: "")
                }
            }
        }
        cwUsb.onKeyStateChange = { isOn, rawPacket ->
            cwKeyOn.postValue(isOn)
            cwUsb.currentMode = sharedMode.value ?: ""
            val mode = cwUsb.currentMode
            val isCwMode = mode.contains("CW", ignoreCase = true)
            val isFmMode = mode.contains("FM", ignoreCase = true)
                    || mode.equals("DSTAR", ignoreCase = true) || mode.equals("D-STAR", ignoreCase = true)
            if (cwUsbEnabled.value == true) {
                when {
                    isCwMode -> {
                        val pkt = rawPacket.copyOf()
                        if (prefs.cwDelayMs > 0) {
                            var existingMs = 0L
                            for (i in 0..7) existingMs = (existingMs shl 8) or (pkt[2 + i].toLong() and 0xFF)
                            // opTimeMsはSYNC成功時=Pi時刻基準、SYNC失敗時=Android時刻基準(sendZeroSyncResponseがAndroid時刻を返す)。
                            // どちらもPi/Androidは同一NTP時刻に同期しているためpiClockOffsetMs変換不要 (iOS forwardKeyToPiと同一方式)。
                            val fireMs = if (existingMs in 2L..0xFFFFFFFFL) {
                                existingMs + prefs.cwDelayMs.toLong()
                            } else {
                                System.currentTimeMillis() + prefs.cwDelayMs.toLong()
                            }
                            for (i in 0..7) pkt[2 + i] = ((fireMs ushr (56 - i * 8)) and 0xFF).toByte()
                        }
                        cwSendQueue.offer(pkt)
                    }
                    isFmMode -> {
                        if (isOn) cwFmKeyOn() else cwFmKeyOff()
                    }
                }
            }
            // TX decode: call directly on USB thread (CwKeyDecoder is @Synchronized)
            // Post timeout to main thread via Handler (more reliable than coroutine launch)
            if (cwDecodingActive) {
                cwTxKeyDecoder.keyEvent(isOn)
                cwTxTimeoutHandler.removeCallbacks(cwTxTimeoutRunnable)
                if (!isOn) {
                    val waitMs = (cwTxKeyDecoder.ditMs * 4).coerceAtLeast(200L)
                    cwTxTimeoutHandler.postDelayed(cwTxTimeoutRunnable, waitMs)
                }
            }
        }
        val piSerialPort = prefs.cwPort
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val ok = cwUsb.connect(device)
                withContext(Dispatchers.Main) {
                    android.widget.Toast.makeText(
                        getApplication(),
                        if (ok) "CW USB connected" else "CW USB connect failed (check logcat)",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                }
                if (!ok) {
                    cwUsbConnected.postValue(false)
                    return@launch
                }
                startCwSendThread()
                withContext(Dispatchers.Main) { acquireCwWifiLock() }
                // Send current WPM to M5 keyer (sync completion triggers 0xE2, but also set now)
                cwUsb.keeyerWpm = prefs.cwWpm
                // Enable immediately after USB connects — Pi connection failure must not block this
                withContext(Dispatchers.Main) { setCwUsbEnabled(true) }
                // Send paddle swap setting to M5
                cwUsb.sendPaddleSwapToM5(prefs.cwPaddleSwap)
                // Pre-resolve DNS on connection (prevents 2-3 second block on first keystroke)
                val resolveHost = prefs.hostName
                if (resolveHost.isNotEmpty()) {
                    try {
                        val addr = java.net.InetAddress.getByName(resolveHost)
                        val sock = java.net.DatagramSocket()
                        cwUdpAddr = addr
                        cwUdpSocket = sock
                        cwUsb.piSyncAddress = java.net.InetSocketAddress(addr, CW_UDP_PORT)
                        android.util.Log.i("CwUdp", "pre-resolved: $resolveHost -> ${addr.hostAddress}")
                    } catch (e: Exception) {
                        android.util.Log.w("CwUdp", "pre-resolve failed: ${e.message}")
                    }
                }
                try { api.cwOpen(piSerialPort, 0) } catch (_: Exception) {}
            } finally {
                withContext(Dispatchers.Main) { cwUsbConnecting = false }
            }
        }
    }

    fun refreshCwPiConnection() {
        if (!cwUsb.isConnected) return
        viewModelScope.launch(Dispatchers.IO) {
            val host = prefs.hostName
            if (host.isEmpty()) return@launch
            try {
                val addr = java.net.InetAddress.getByName(host)
                cwUdpSocket?.close()
                cwUdpSocket = java.net.DatagramSocket()
                cwUdpAddr = addr
                cwUsb.piSyncAddress = java.net.InetSocketAddress(addr, CW_UDP_PORT)
                android.util.Log.i("CwRefresh", "Pi address refreshed: $host -> ${addr.hostAddress}")
                api.cwOpen(prefs.cwPort, 0)
            } catch (e: Exception) {
                android.util.Log.w("CwRefresh", "CW Pi refresh failed: ${e.message}")
            }
        }
    }

    fun disconnectCwUsb() {
        cwUsbConnecting = false
        cwFmTailJob?.cancel(); cwFmTailJob = null
        cwFmPttJob?.cancel(); cwFmPttJob = null
        stopPttHeartbeat()
        if (cwFmTxActive) {
            cwFmTxActive = false
            txEnabled.value = false
            viewModelScope.launch(Dispatchers.IO) { api.setPtt(false) }
        }
        stopCwServerPolling()
        stopCwSendThread()
        viewModelScope.launch(Dispatchers.IO) { api.cwClose() }
        cwUsb.piSyncAddress = null
        cwUsb.disconnect()
        cwUdpSocket?.close(); cwUdpSocket = null; cwUdpAddr = null
        releaseCwWifiLock()
        cwUsbConnected.value = false
    }

    // ───────── CW BLE relay (DualKey-BLE / RemoteKeyer-BLE) ─────────

    @SuppressLint("MissingPermission")
    fun connectCwBle(device: BluetoothDevice) {
        if (cwBle.isConnected || cwBleConnecting) return
        cwBleConnecting = true

        cwBle.sidetoneEnabled = prefs.cwSidetoneEnabled
        cwBle.onAudioStreamNeeded = {
            val mode = sharedMode.value ?: ""
            val pttActive = txEnabled.value == true
            if (!mode.contains("CW", ignoreCase = true) && cwBleEnabled.value == true && !pttActive) {
                viewModelScope.launch(Dispatchers.Main) {
                    cwBle.startCwAudioStream(api, apiKey.value ?: "")
                }
            }
        }
        cwBleAudioReady.value = false
        cwBle.onAudioReady = { cwBleAudioReady.postValue(true) }
        cwBle.onConnectionStateChange = { connected ->
            cwBleConnected.postValue(connected)
            if (!connected) {
                cwBleEnabled.postValue(false)
                cwBleAudioReady.postValue(false)
                cwBleConnecting = false
                viewModelScope.launch(Dispatchers.Main) { releaseCwWifiLock() }
                android.util.Log.i("CwBle", "BLE disconnected")
            } else {
                viewModelScope.launch(Dispatchers.IO) {
                    withContext(Dispatchers.Main) {
                        android.widget.Toast.makeText(
                            getApplication(),
                            "CW BLE connected: ${device.name}",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    }
                    if (cwSendThread?.isAlive != true) startCwSendThread()
                    withContext(Dispatchers.Main) { acquireCwWifiLock() }
                    cwBle.keeyerWpm = prefs.cwWpm
                    cwBle.piClockOffsetMs = piClockOffsetMs
                    withContext(Dispatchers.Main) {
                        cwBleEnabled.value = true
                        startCwServerPolling()
                        cwBleConnecting = false
                    }
                    cwBle.sendPaddleSwapToM5(prefs.cwPaddleSwap)
                    val resolveHost = prefs.hostName
                    if (resolveHost.isNotEmpty()) {
                        try {
                            val addr = java.net.InetAddress.getByName(resolveHost)
                            cwBle.piSyncAddress = java.net.InetSocketAddress(addr, CW_UDP_PORT)
                        } catch (e: Exception) {
                            android.util.Log.w("CwBle", "pre-resolve failed: ${e.message}")
                        }
                    }
                    try { api.cwOpen(prefs.cwPort, 0) } catch (_: Exception) {}
                }
            }
        }
        cwBle.onWpmChange = { wpm ->
            prefs.cwWpm = wpm
            cwWpm.postValue(wpm)
        }
        cwBle.onKeyStateChange = { isOn, rawPacket ->
            cwKeyOn.postValue(isOn)
            cwBle.currentMode = sharedMode.value ?: ""
            val mode = cwBle.currentMode
            val isCwMode = mode.contains("CW", ignoreCase = true)
            val isFmMode = mode.contains("FM", ignoreCase = true)
                    || mode.equals("DSTAR", ignoreCase = true) || mode.equals("D-STAR", ignoreCase = true)
            if (cwBleEnabled.value == true) {
                when {
                    isCwMode -> {
                        val pkt = rawPacket.copyOf()
                        if (prefs.cwDelayMs > 0) {
                            var existingMs = 0L
                            for (i in 0..7) existingMs = (existingMs shl 8) or (pkt[2 + i].toLong() and 0xFF)
                            // USB同様: opTimeMsはSYNC済みのPi/Android時刻基準のためpiClockOffsetMs不要
                            val fireMs = if (existingMs in 2L..0xFFFFFFFFL) {
                                existingMs + prefs.cwDelayMs.toLong()
                            } else {
                                System.currentTimeMillis() + prefs.cwDelayMs.toLong()
                            }
                            for (i in 0..7) pkt[2 + i] = ((fireMs ushr (56 - i * 8)) and 0xFF).toByte()
                        }
                        cwSendQueue.offer(pkt)
                    }
                    isFmMode -> { if (isOn) cwFmKeyOn() else cwFmKeyOff() }
                }
            }
            if (cwDecodingActive) {
                cwTxKeyDecoder.keyEvent(isOn)
                cwTxTimeoutHandler.removeCallbacks(cwTxTimeoutRunnable)
                if (!isOn) {
                    val waitMs = (cwTxKeyDecoder.ditMs * 4).coerceAtLeast(200L)
                    cwTxTimeoutHandler.postDelayed(cwTxTimeoutRunnable, waitMs)
                }
            }
        }

        viewModelScope.launch(Dispatchers.IO) {
            val started = cwBle.connect(device)
            if (!started) {
                withContext(Dispatchers.Main) {
                    android.widget.Toast.makeText(
                        getApplication(), "CW BLE connect failed", android.widget.Toast.LENGTH_LONG
                    ).show()
                    cwBleConnected.value = false
                    cwBleConnecting = false
                }
            }
        }
    }

    fun disconnectCwBle() {
        cwBleConnecting = false
        stopCwServerPolling()
        cwBle.piSyncAddress = null
        cwBle.disconnect()
        releaseCwWifiLock()
        cwBleConnected.value = false
        cwBleEnabled.value = false
    }

    fun setCwUsbEnabled(enabled: Boolean) {
        cwUsbEnabled.value = enabled
        if (!enabled) {
            cwUsb.stopCwAudioStream()
            stopCwServerPolling()
        } else {
            val isCwMode = (sharedMode.value ?: "").contains("CW", ignoreCase = true)
            if (!isCwMode) cwUsb.startCwAudioStream(api, apiKey.value ?: "")
            startCwServerPolling()
        }
    }

    private fun startCwServerPolling() {
        cwServerPollingJob?.cancel()
        cwServerPollingJob = viewModelScope.launch {
            while (isActive) {
                val st = withContext(Dispatchers.IO) { api.cwStatus() }
                cwServerConnected.value   = st?.connected  ?: false
                cwServerSynced.value      = st?.synced     ?: false
                if ((st?.maxLateMs ?: 0) > cwMeasuredLatencyMs.value ?: 0)
                    cwMeasuredLatencyMs.value = st!!.maxLateMs
                delay(3000)
            }
        }
    }

    private fun stopCwServerPolling() {
        cwServerPollingJob?.cancel()
        cwServerPollingJob = null
        cwServerConnected.postValue(false)
        cwServerSynced.postValue(false)
    }

    // ───────── CW decode display ─────────

    fun toggleCwDecoding() {
        val next = !(cwDecoding.value ?: false)
        cwDecoding.value = next
        cwDecodingActive = next
        if (next) {
            // CWデコード中はafftdnのトランジェント遅延を避けるため
            // バンドパスフィルター(NR相当)に自動切替をPiに通知
            viewModelScope.launch(Dispatchers.IO) {
                api.setCwDecodeMode(true)
                api.setCwDecodeModeOnPort(prefs.audioPort, true)
            }

            synchronized(cwDecodedLock) {
                cwTxBuffer.clear()
                cwRxBuffers.forEach { it.clear() }
            }
            cwTxText.value = ""
            cwRxTexts.forEach { it.value = "" }
            cwRxFreqLabels.forEachIndexed { i, ld -> ld.value = if (i == 0) "RX:" else "---" }
            cwTxKeyDecoder.reset()

            val sampIdx = selectedSamplingIndex.value ?: 1
            val rate = SAMPLING_RATES.getOrElse(sampIdx) { 8000 }.let { if (it == 0) 8000 else it }
            val decoder = CwDecoder(rate)
            decoder.onCharDecoded = { c, ci -> appendCwRxChar(c, ci) }
            decoder.onChannelFreq = { ci, hz ->
                val label = if (hz == 0) (if (ci == 0) "RX:" else "---") else "${hz}Hz"
                cwRxFreqLabels[ci].postValue(label)
            }
            decoder.onChannelSwap = { a, b ->
                // Swap text buffers per slot
                synchronized(cwDecodedLock) {
                    val tmpBuf = StringBuilder(cwRxBuffers[a])
                    cwRxBuffers[a].clear(); cwRxBuffers[a].append(cwRxBuffers[b])
                    cwRxBuffers[b].clear(); cwRxBuffers[b].append(tmpBuf)
                }
                cwRxTexts[a].postValue(cwRxBuffers[a].toString())
                cwRxTexts[b].postValue(cwRxBuffers[b].toString())
            }
            cwRxDecoder = decoder
            cwTxKeyDecoder.onCharDecoded = { c, _ -> appendCwTxChar(c) }

            // VPNバースト保護: リアルタイムより速くサンプルが届く場合は蓄積超過を追跡し
            // 2秒を超えた分はデコードをスキップして団子化を防ぐ
            val cwBurstState = longArrayOf(0L, 0L)  // [0]=前回壁時計ms, [1]=超過ms
            audio.audioSampleListener = { samples ->
                val now = System.currentTimeMillis()
                val chunkAudioMs = samples.size * 1000L / rate.toLong()
                val elapsed = if (cwBurstState[0] == 0L) chunkAudioMs else now - cwBurstState[0]
                cwBurstState[0] = now
                cwBurstState[1] = maxOf(0L, cwBurstState[1] + chunkAudioMs - elapsed)
                if (cwBurstState[1] <= 2000L) {
                    decoder.processSamples(samples)
                }
            }

            // Auto-start SPK if not already running
            if (spkEnabled.value != true && txEnabled.value != true) {
                val sampRate = SAMPLING_RATES.getOrElse(sampIdx) { 0 }
                if (sampRate != 0) {
                    spkEnabled.value = true
                    startAudio()
                }
            }
        } else {
            audio.audioSampleListener = null
            cwRxDecoder?.onCharDecoded = null
            cwRxDecoder?.onChannelFreq = null
            cwRxDecoder?.onChannelSwap = null
            cwRxDecoder = null
            cwTxKeyDecoder.onCharDecoded = null
            cwTxTimeoutHandler.removeCallbacks(cwTxTimeoutRunnable)
            cwTxTimeoutJob?.cancel(); cwTxTimeoutJob = null
            cwRxFreqLabels.forEachIndexed { i, ld -> ld.value = if (i == 0) "RX:" else "---" }

            // CWデコード終了: afftdn NRに戻す
            viewModelScope.launch(Dispatchers.IO) {
                api.setCwDecodeMode(false)
                api.setCwDecodeModeOnPort(prefs.audioPort, false)
            }
        }
    }

    private fun appendCwTxChar(c: Char) {
        val text: String
        synchronized(cwDecodedLock) {
            cwTxBuffer.append(c)
            if (cwTxBuffer.length > CW_MAX_CHARS) cwTxBuffer.delete(0, cwTxBuffer.length - CW_MAX_CHARS)
            text = cwTxBuffer.toString()
        }
        cwTxText.postValue(text)
    }

    private fun appendCwRxChar(c: Char, ci: Int) {
        if (ci !in 0 until CwDecoder.N_CHAN) return
        val text: String
        synchronized(cwDecodedLock) {
            val buf = cwRxBuffers[ci]
            buf.append(c)
            if (buf.length > CW_MAX_CHARS) buf.delete(0, buf.length - CW_MAX_CHARS)
            text = buf.toString()
        }
        cwRxTexts[ci].postValue(text)
    }

    fun toggleCwMultiRx() {
        cwMultiRx.value = !(cwMultiRx.value ?: false)
    }

    // ───────── CW text send via Hamlib ─────────

    private fun buildCwPcm(text: String, wpm: Int, sampleRate: Int = 44100): ShortArray {
        val ditSamples = (sampleRate * 1200.0 / wpm.coerceIn(5, 60) / 1000.0).toInt().coerceAtLeast(1)
        val buf = ArrayList<Short>(sampleRate * 60)
        fun tone(dits: Int) = repeat(ditSamples * dits) { i ->
            buf.add((32767 * 0.7 * sin(2.0 * PI * 700.0 * i / sampleRate)).toInt().toShort())
        }
        fun silence(dits: Int) = repeat(ditSamples * dits) { buf.add(0) }
        val words = text.uppercase().trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        for ((wi, word) in words.withIndex()) {
            if (wi > 0) silence(7)
            for ((ci, ch) in word.withIndex()) {
                if (ci > 0) silence(3)
                val morse = CwDecoder.CHAR_TO_MORSE[ch] ?: continue
                for ((ei, el) in morse.withIndex()) {
                    if (ei > 0) silence(1)
                    when (el) { '.' -> tone(1); '-' -> tone(3) }
                }
            }
        }
        silence(7)
        return buf.toShortArray()
    }

    private suspend fun playCwSidetone(text: String, wpm: Int) {
        if (cwSidetoneEnabled.value != true) return
        val pcm = buildCwPcm(text, wpm)
        if (pcm.isEmpty()) return
        val sampleRate = 44100
        val minBuf = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build())
            .setAudioFormat(AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build())
            .setBufferSizeInBytes(maxOf(minBuf, 4096))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        val playMs = pcm.size.toLong() * 1000 / sampleRate
        val startMs = System.currentTimeMillis()
        try {
            track.play()
            val chunk = 4410 // 100ms chunks → allows coroutine cancellation check
            var offset = 0
            while (offset < pcm.size && currentCoroutineContext().isActive) {
                val len = minOf(chunk, pcm.size - offset)
                track.write(pcm, offset, len)
                offset += len
            }
            val elapsed = System.currentTimeMillis() - startMs
            val remaining = playMs - elapsed + 100
            if (remaining > 0) delay(remaining)
        } finally {
            try { track.stop() } catch (_: Exception) {}
            try { track.release() } catch (_: Exception) {}
        }
    }

    // CI-V CW text TX: generate element timing on Android, key IC-705 via fire-and-forget PTT
    // Calculate total CW duration of text in dit units (for wait-after-sendCwMessage).
    private fun morseDurationUnits(text: String): Long {
        val words = text.uppercase().trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        var units = 0L
        words.forEachIndexed { wi, word ->
            if (wi > 0) units += 7
            word.forEachIndexed { ci, ch ->
                if (ci > 0) units += 3
                val morse = CwDecoder.CHAR_TO_MORSE[ch] ?: return@forEachIndexed
                morse.forEachIndexed { ei, el ->
                    if (ei > 0) units += 1
                    units += if (el == '-') 3L else 1L
                }
            }
        }
        return units
    }

    private suspend fun sendCwTextCiv(text: String, wpm: Int) {
        val isCwMode = (sharedMode.value ?: "").contains("CW", ignoreCase = true)
        withContext(Dispatchers.Main) {
            cwTxBusy.value = true
            cwTextTxActive = true
            stopStatusPolling()
        }
        try {
            kotlinx.coroutines.coroutineScope {
                launch { playCwSidetone(text, wpm) }
                val ditMs = (1200L / wpm.coerceIn(5, 60))

                if (isCwMode) {
                    if (isCivBt) {
                        // BT CI-V: BT latency makes PTT-per-element unusable.
                        // Force BK-IN ON and use IC-705 internal keyer (CI-V 0x17).
                        withContext(Dispatchers.IO) {
                            val bkIn = civBt.getBkIn()
                            if (bkIn == false) civBt.setBkIn(true)
                            civBt.setKeySpeed(wpm)
                        }
                        delay(50)
                        val chunks = text.chunked(30)
                        for (chunk in chunks) {
                            if (!isActive) break
                            withContext(Dispatchers.IO) { civBt.sendCwMessage(chunk) }
                            val durMs = morseDurationUnits(chunk) * ditMs + 300L
                            delay(durMs)
                        }
                    } else {
                        val bkIn = withContext(Dispatchers.IO) { civ.getBkIn() } ?: false
                        android.util.Log.i("CivWlan", "sendCwTextCiv: BK-IN=$bkIn wpm=$wpm dit=${ditMs}ms")
                        if (bkIn) {
                            withContext(Dispatchers.IO) { civ.setKeySpeed(wpm) }
                            delay(50)
                            val chunks = text.chunked(30)
                            for (chunk in chunks) {
                                if (!isActive) break
                                withContext(Dispatchers.IO) { civ.sendCwMessage(chunk) }
                                val durMs = morseDurationUnits(chunk) * ditMs + 300L
                                delay(durMs)
                            }
                        } else {
                            // BK-IN OFF: PTT-per-element pseudo-CW
                            val words = text.uppercase().trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
                            for ((wi, word) in words.withIndex()) {
                                if (wi > 0) delay(ditMs * 7)
                                for ((ci, ch) in word.withIndex()) {
                                    if (ci > 0) delay(ditMs * 3)
                                    val morse = CwDecoder.CHAR_TO_MORSE[ch] ?: continue
                                    for ((ei, el) in morse.withIndex()) {
                                        if (ei > 0) delay(ditMs)
                                        val elemMs = if (el == '-') ditMs * 3 else ditMs
                                        civ.civPttDown()
                                        delay(elemMs)
                                        civ.civPttUp()
                                    }
                                }
                                if (!isActive) break
                            }
                        }
                    }
                } else {
                    if (isCivBt) {
                        if (civ.audioOnly && civ.isConnected) {
                            // BT CI-V hybrid: CW PCM audio via RS-BA1, PTT via RFCOMM
                            val pcm = buildCwPcm(text, wpm, 8000)
                            val bytes = ByteArray(pcm.size * 2)
                            for (i in pcm.indices) {
                                bytes[i * 2]     = (pcm[i].toInt() and 0xFF).toByte()
                                bytes[i * 2 + 1] = (pcm[i].toInt() ushr 8).toByte()
                            }
                            withContext(Dispatchers.IO) { civBt.setPtt(true) }
                            delay(250) // wait for IC-705 to enter TX before audio
                            var btCwOffset = 0
                            val btCwChunkSize = 320
                            var btCwNextMs = System.currentTimeMillis()
                            while (btCwOffset < bytes.size && isActive) {
                                val len = minOf(btCwChunkSize, bytes.size - btCwOffset)
                                civ.sendTxAudioDirect(bytes, btCwOffset, len)
                                btCwOffset += len
                                btCwNextMs += 20L
                                val sleepMs = btCwNextMs - System.currentTimeMillis()
                                if (sleepMs > 0) delay(sleepMs)
                            }
                            delay(100)
                            withContext(Dispatchers.IO) { civBt.setPtt(false) }
                        } else {
                            withContext(Dispatchers.Main) {
                                errorMessage.value = "BT CI-V: Switch to CW mode or set RS-BA1 Audio Host"
                            }
                        }
                    } else {
                        // WiFi CI-V: stream CW PCM audio through RS-BA1 TX audio path
                        val pcm = buildCwPcm(text, wpm, 8000)
                        val bytes = ByteArray(pcm.size * 2)
                        for (i in pcm.indices) {
                            bytes[i * 2]     = (pcm[i].toInt() and 0xFF).toByte()
                            bytes[i * 2 + 1] = (pcm[i].toInt() ushr 8).toByte()
                        }
                        withContext(Dispatchers.IO) { civ.setPtt(true) }
                        // Stop mic capture so CW tones are the only audio sent (no howling)
                        civ.stopTxAudioCapture()
                        var offset = 0
                        val chunkSize = 320
                        var nextMs = System.currentTimeMillis()
                        while (offset < bytes.size && isActive) {
                            val len = minOf(chunkSize, bytes.size - offset)
                            civ.sendTxAudioDirect(bytes, offset, len)
                            offset += len
                            nextMs += 20L
                            val sleepMs = nextMs - System.currentTimeMillis()
                            if (sleepMs > 0) delay(sleepMs)
                        }
                        delay(100)
                        withContext(Dispatchers.IO) { civ.setPtt(false) }
                    }
                }
            }
        } finally {
            withContext(NonCancellable) {
                if (isCwMode) {
                    if (isCivBt) { civBt.stopCwMessage(); civBt.civPttUp() }
                    else { civ.stopCwMessage(); civ.civPttUp() }
                } else if (isCivBt && civ.audioOnly && civ.isConnected) {
                    civBt.setPtt(false)
                }
            }
            withContext(Dispatchers.Main) {
                cwTxBusy.value = false
                cwTextTxActive = false
                txEnabled.value = false
                startStatusPolling()
            }
        }
    }

    private suspend fun sendCwTextFm(text: String, wpm: Int) {
        val sampleRate = 8000
        val pcm = buildCwPcm(text, wpm, sampleRate)
        val bytes = ByteArray(pcm.size * 2)
        for (i in pcm.indices) {
            bytes[i * 2]     = (pcm[i].toInt() and 0xFF).toByte()
            bytes[i * 2 + 1] = (pcm[i].toInt() ushr 8).toByte()
        }
        cwFmTxActive = true
        val key = apiKey.value ?: ""
        try {
            if (!api.setPtt(true)) {
                withContext(Dispatchers.Main) { errorMessage.postValue("PTT failed — check rigctld") }
                return
            }
            startPttHeartbeat()
            val chunkBytes = (sampleRate / 100) * 2  // 160 bytes = 10ms at 8000 Hz
            val conn = (java.net.URL(api.getAudioTxUrl(sampleRate)).openConnection()
                    as java.net.HttpURLConnection).apply {
                doOutput = true
                requestMethod = "POST"
                if (key.isNotEmpty()) setRequestProperty("X-API-Key", key)
                setChunkedStreamingMode(0)
                connectTimeout = 3000
                readTimeout = 0
            }
            conn.connect()
            val out = conn.outputStream
            try {
                var offset = 0
                var nextMs = System.currentTimeMillis()
                while (offset < bytes.size) {
                    nextMs += 10L
                    val len = minOf(chunkBytes, bytes.size - offset)
                    out.write(bytes, offset, len)
                    out.flush()
                    offset += len
                    val sleepMs = nextMs - System.currentTimeMillis()
                    if (sleepMs > 0) delay(sleepMs)  // キャンセル確認ポイント
                }
            } finally {
                try { out.close() } catch (_: Exception) {}
                try { conn.disconnect() } catch (_: Exception) {}
            }
        } finally {
            withContext(NonCancellable) {
                delay(100)
                try { api.setPtt(false) } catch (_: Exception) {}
                stopPttHeartbeat()
                cwFmTxActive = false
            }
        }
    }

    /**
     * Stream PCM AFSK RTTY audio to the radio's TX path.
     * Pi mode: HTTP POST to /radio/audio_tx with mode switch to LSB/USB.
     * CI-V mode: RS-BA1 direct audio to IC-705 with PKTLSB/PKTUSB.
     * Always uses fixed standard TX tones (TX_MARK_HZ / TX_SPACE_HZ).
     */
    suspend fun streamRttyTx(shorts: ShortArray, txMode: String, rxMode: String,
                              txFreq: Long = 0L, rxFreq: Long = 0L,
                              sampleRate: Int = 8000) {
        if (isDemoMode.value == true) return
        val bytes = ByteArray(shorts.size * 2)
        for (i in shorts.indices) {
            bytes[i * 2]     = (shorts[i].toInt() and 0xFF).toByte()
            bytes[i * 2 + 1] = (shorts[i].toInt() ushr 8).toByte()
        }
        val key = apiKey.value ?: ""
        // The IC-705 reached over CI-V only takes its modulation from the network input
        // when it is in a data mode. In plain LSB/USB it listens to the microphone
        // instead, so the RS-BA1 audio streamed below is ignored and the rig transmits
        // nothing. Map the SSB mode the caller asked for onto the matching packet mode.
        // The Pi/hamlib path is the opposite: it feeds the rig's normal SSB audio input,
        // so it keeps plain LSB/USB.
        val civTxMode = when (txMode.uppercase()) {
            "LSB" -> "PKTLSB"
            "USB" -> "PKTUSB"
            else  -> txMode
        }
        if (useCIV.value == true) {
            if (isCivBt) {
                if (civ.audioOnly && civ.isConnected) {
                    withContext(Dispatchers.IO) { civBt.setPtt(true) }
                    delay(250)
                    civ.stopTxAudioCapture()
                    var offset = 0; var nextMs = System.currentTimeMillis()
                    while (offset < bytes.size) {
                        val len = minOf(320, bytes.size - offset)
                        civ.sendTxAudioDirect(bytes, offset, len)
                        offset += len; nextMs += 20
                        val s = nextMs - System.currentTimeMillis(); if (s > 0) delay(s)
                    }
                    delay(100)
                    withContext(Dispatchers.IO) { civBt.setPtt(false) }
                }
            } else {
                withContext(Dispatchers.IO) { civ.setMode(civTxMode, 3000) }
                // Apply carrier correction so TX mark lands on the received signal's frequency.
                if (txFreq > 0L) withContext(Dispatchers.IO) { civ.setFrequency(txFreq) }
                withContext(Dispatchers.IO) { civ.setPtt(true) }
                civ.stopTxAudioCapture()
                var offset = 0; var nextMs = System.currentTimeMillis()
                while (offset < bytes.size) {
                    val len = minOf(320, bytes.size - offset)
                    civ.sendTxAudioDirect(bytes, offset, len)
                    offset += len; nextMs += 20
                    val s = nextMs - System.currentTimeMillis(); if (s > 0) delay(s)
                }
                delay(600)
                withContext(Dispatchers.IO) { civ.setPtt(false) }
                withContext(Dispatchers.IO) { civ.setMode(rxMode, 0) }
                // Restore the original mark frequency so the RX decoder stays on the signal.
                if (rxFreq > 0L) withContext(Dispatchers.IO) { civ.setFrequency(rxFreq) }
            }
        } else {
            // Pi/hamlib path: switch to SSB, key PTT, stream audio to /radio/audio_tx
            stopStatusPolling()
            // Mode FIRST, then frequency. Leaving RTTY for a data mode moves the FT-991A's
            // VFO, because the two modes do not display the same point: RTTY shows the mark,
            // PKTLSB shows the suppressed carrier. Setting the frequency before the mode had
            // the rig shift it afterwards, landing the signal about 1 kHz off, which is why
            // the transmission only decoded when the dial was moved from 144.600 to 144.601
            // by hand.
            withContext(Dispatchers.Main) { sendMode(txMode, 3000) }
            delay(1200)  // let the mode change land before pinning the frequency
            // Shift carrier frequency so the AFSK mark tone lands at the RTTY dial frequency.
            // Icom/most rigs display mark: in LSB, carrier = mark_dial + mark_tone_Hz.
            if (txFreq > 0L) withContext(Dispatchers.Main) { sendFreq(txFreq) }
            var alcPollJob: Job? = null
            try {
                if (!api.setPtt(true)) {
                    withContext(Dispatchers.Main) { errorMessage.postValue("PTT failed") }
                    return
                }
                delay(300)  // let rig settle into TX before audio arrives (matches iOS)
                startPttHeartbeat()
                alcPollJob = viewModelScope.launch {
                    while (isActive) {
                        delay(500L)
                        val st = withContext(Dispatchers.IO) { runCatching { api.getStatus() }.getOrNull() }
                        st?.alc?.let { sharedAlc.value = it }
                        st?.rfOut?.let { sharedRfOut.value = it }
                    }
                }
                val chunkBytes = 4096
                val audioMs = (shorts.size * 1000L) / sampleRate
                val streamStartMs = System.currentTimeMillis()
                val conn = (java.net.URL(api.getAudioTxUrl(sampleRate)).openConnection()
                        as java.net.HttpURLConnection).apply {
                    doOutput = true; requestMethod = "POST"
                    if (key.isNotEmpty()) setRequestProperty("X-API-Key", key)
                    setChunkedStreamingMode(0); connectTimeout = 3000; readTimeout = 0
                }
                conn.connect()
                val out = conn.outputStream
                // Deliberately NOT paced to real time. Writing 10 ms chunks on a 10 ms clock
                // makes the on-air bit timing depend on network jitter and on how busy the Pi
                // is. Measured on the single-core Pi, handing over 5.57 s of audio that way
                // took between 12.4 s and 119 s, so aplay ran dry repeatedly and the gaps
                // destroyed the signal even though it still sounded like RTTY. Pushing as fast
                // as back-pressure allows leaves the sound card as the only clock, so the bit
                // timing is exact. PTT is then held for whatever is left of the buffer, since
                // playback outlives the last write.
                try {
                    var offset = 0
                    while (offset < bytes.size) {
                        val len = minOf(chunkBytes, bytes.size - offset)
                        out.write(bytes, offset, len); out.flush()
                        offset += len
                    }
                    try { out.close() } catch (_: Exception) {}
                    // Reading the response is what tells us the transmission is over: the Pi
                    // closes aplay's stdin and then waits on the process, so it answers only
                    // once every sample has actually been played. Guessing the remaining time
                    // from the buffer duration was always short, because aplay does not start
                    // until the Pi has killed its capture processes and spawned it, so PTT
                    // dropped before the tail played and the last character was lost.
                    val code = withContext(Dispatchers.IO) {
                        runCatching { conn.responseCode }.getOrNull()
                    }
                    val elapsedMs = System.currentTimeMillis() - streamStartMs
                    android.util.Log.d("RTTY",
                        "AFSK-Pi audio=${audioMs}ms elapsed=${elapsedMs}ms http=$code")
                } finally {
                    try { out.close() } catch (_: Exception) {}
                    try { conn.disconnect() } catch (_: Exception) {}
                }
            } finally {
                withContext(NonCancellable) {
                    alcPollJob?.cancel()
                    delay(400)  // let the tail of the buffer play out before PTT off
                    try { api.setPtt(false) } catch (_: Exception) {}
                    stopPttHeartbeat()
                    withContext(Dispatchers.Main) { sharedAlc.value = 0f }
                    // Same order on the way back: returning to RTTY moves the VFO too, so
                    // restore the mode first and only then put the frequency where the
                    // operator left it.
                    withContext(Dispatchers.Main) { sendMode(rxMode, 0) }
                    delay(1200)
                    if (rxFreq > 0L) withContext(Dispatchers.Main) { sendFreq(rxFreq) }
                    startStatusPolling()
                }
            }
        }
    }

    suspend fun rttyFskTx(port: String, text: String, baud: Double = 45.45, fskPin: String = "DTR"): Boolean {
        if (isDemoMode.value == true) return false
        stopStatusPolling()
        return try {
            withContext(Dispatchers.IO) { api.rttyFskTx(port, text, baud, fskPin) }
        } finally {
            startStatusPolling()
        }
    }

    fun sendCwText(text: String, wpm: Int) {
        // 全角ASCII → 半角に正規化 (日本語キーボード対策: ？→? など)
        val normalized = text.map { c ->
            when {
                c in '！'..'～' -> (c.code - 0xFEE0).toChar()
                c == '　' -> ' '
                else -> c
            }
        }.joinToString("")
        cwTextJob?.cancel()
        cwTextJob = viewModelScope.launch(Dispatchers.IO) {
            if (isDemoMode.value == true) return@launch
            if (useCIV.value == true) {
                if (!isCivConnected) {
                    // Rig not connected — play sidetone locally for practice
                    withContext(Dispatchers.Main) { cwTxBusy.value = true }
                    try { playCwSidetone(normalized, wpm) }
                    finally { withContext(Dispatchers.Main) { cwTxBusy.value = false } }
                    return@launch
                }
                sendCwTextCiv(normalized, wpm)
                return@launch
            }
            // Stop APRS if active — prevents aprs_loop from changing frequency during CW TX
            if (aprsActive.value == true) {
                runCatching {
                    api.stopAprs()
                    api.setPoll(true)
                }
                withContext(Dispatchers.Main) {
                    aprsActive.value = false
                    stopAprsLocationUpdates()
                    stopAprsHeartbeat()
                }
                delay(300)  // let direwolf settle before PTT
            }
            val isCwMode = (sharedMode.value ?: "").contains("CW", ignoreCase = true)
            withContext(Dispatchers.Main) {
                cwTxBusy.value = true
                if (isCwMode) cwTextTxActive = true else txEnabled.value = true
                stopStatusPolling()
                if (!isCwMode) audio.stop()  // CWモード: SPK継続（TX後の復帰遅延を排除）
                if (!isCwMode) cwUsb.stopCwAudioStream()  // audio_tx 競合防止
            }
            try {
                api.setPoll(false)
                launch { playCwSidetone(normalized, wpm) }
                if (isCwMode) {
                    delay(300) // rig_lock 解放待ち (Pi Zero: setPoll後のrigctld残処理考慮)
                    val ok = api.cwSendMorse(normalized, wpm, cwPttPoll.value ?: false)
                    if (!ok) {
                        withContext(Dispatchers.Main) {
                            errorMessage.postValue("CW send failed")
                        }
                        return@launch
                    }
                    while (isActive && api.cwMorseStatus()) {
                        delay(500)
                    }
                } else {
                    // FM-CW: PTT + 700Hz トーンをリアルタイムストリーミング
                    sendCwTextFm(normalized, wpm)
                }
            } finally {
                withContext(NonCancellable) {
                    api.setPoll(true)
                }
                withContext(Dispatchers.Main) {
                    if (cwTxBusy.value == true) {
                        cwTxBusy.value = false
                        cwTextTxActive = false
                        txEnabled.value = false
                        startStatusPolling()
                        if (spkEnabled.value == true && (!isCwMode || !audio.isDataFlowing)) startAudio()  // CWモード: データが流れていなければ再起動
                        updateCwAudioStreamForMode(sharedMode.value ?: "")  // 電鍵ストリーム復元
                    }
                }
            }
        }
    }

    fun stopCwText() {
        cwTextJob?.cancel()
        cwTextJob = null
        viewModelScope.launch(Dispatchers.IO) {
            api.cwStopMorse()
            api.setPtt(false)  // FM-CW パス用
            api.setPoll(true)
        }
        stopPttHeartbeat()
        cwFmTxActive = false
        cwTextTxActive = false
        cwTxBusy.value = false
        txEnabled.value = false
        startStatusPolling()
        val isCwModeNow = (sharedMode.value ?: "").contains("CW", ignoreCase = true)
        if (spkEnabled.value == true && (!isCwModeNow || !audio.isDataFlowing)) startAudio()  // CWモード: データが流れていなければ再起動
    }

    fun disconnectFromRig() {
        civSimplexResetSent = false
        btHybridAudioReady.postValue(false)
        if (useCIV.value == true) {
            if (isCivBt) {
                civBt.disconnect()
                if (civ.audioOnly) { civ.spkEnabled = false; civ.disconnect(); civ.audioOnly = false }
            } else {
                civ.disconnect(); releaseCivWifiLock()
            }
        }
        isDemoMode.postValue(false)
        externalPttActive = false
        cwCqRepeatJob?.cancel(); cwCqRepeatJob = null
        cwCqRepeating.postValue(false); cwCqRepeatStatus.postValue("")
        cwTextJob?.cancel(); cwTextJob = null
        cwTxBusy.postValue(false)
        serverWatchdogJob?.cancel()
        serverWatchdogJob = null
        pttOnJob?.cancel()
        pttOnJob = null
        pttOffJob?.cancel()
        pttOffJob = null
        stopStatusPolling()
        stopAudio()
        audioTx.stop()
        stopAprsHeartbeat()
        stopAprsLocationUpdates()
        stopPttHeartbeat()
        stopCwServerPolling()
        cwUsb.disconnect()
        audio.audioSampleListener = null
        cwRxDecoder = null
        cwTxTimeoutHandler.removeCallbacks(cwTxTimeoutRunnable)
        cwTxTimeoutJob?.cancel(); cwTxTimeoutJob = null
        cwDecodingActive = false
        aprsTxing = false
        aprsStoppedAt = 0L
        lastAudioWatchdogMs = 0L
        isConnectedToRig.postValue(false)
        txEnabled.postValue(false)
        spkEnabled.postValue(false)
        aprsActive.postValue(false)
        cwUsbConnected.postValue(false)
        cwDecoding.postValue(false)
    }

    override fun onCleared() {
        super.onCleared()
        instance = null
        cwTxTimeoutHandler.removeCallbacksAndMessages(null)
        disconnectFromRig()
        udpPtt.close()
    }
}
