# WifiRigCTRL — App Store 掲載情報 下書き

作成日: 2026-09-20 / 更新日: 2026-10-14 / 対象バージョン: 3.20 (build 57)
Android版 (Wifi_Rig_CTRL) を参考に、iOS版の実機能に合わせて作成。
> iOS版の対応: RX音声再生 / マイク送信(PTT) / 直接CI-V接続(IC-705・IC-9700) / BT CI-V Bluetooth接続 / BT音声 / CWデコード・送信 / BLE CWキーヤー / FT8・FT4 / RTTY送受信(Pi経由) / APRSビーコン / 複数プロファイル / APIキー認証。
> ※Android版にある「USB CWリレー」はiOS版では非対応のため記載していません。

---

## 1. 基本情報

| 項目 | 内容 | 文字数上限 |
|---|---|---|
| App名 | WifiRigCTRL | 30 |
| サブタイトル（日本語） | Wi-Fi ハムラジオ リモートコントローラー | 30 |
| サブタイトル（英語） | Wi-Fi remote rig control | 30 |

---

## 2. プロモーション用テキスト（170字以内・後から差し替え可）

```
v3.20: RTTY 受信を連続直交整合フィルタで一新し復調が高精度に。運用地(JCC/JGC・グリッド)管理と eQSL/Smart Ham Log 自動連携を追加。Raspberry Pi や IC-705/IC-9700 を Wi-Fi でリモート操作。CW・FT8・RTTY・APRS 対応。
```

---

## 3. 説明（Description・4000字以内）

```
WifiRigCTRL は、アマチュア無線機をiPhone/iPadからWi-Fi経由でリモート操作するためのコントローラーアプリです。

接続方法は3通り:
1. Raspberry Pi 経由（Hamlib/FastAPI）— 幅広い機種のCAT制御・受信音声・CW・FT8・APRSに対応
2. 直接CI-V接続 — IC-705 / IC-9700 と同じWi-Fiに接続し、Raspberry Pi なしで基本操作
3. BT CI-V Bluetooth接続 — IC-705 / IC-9700 にBluetooth直結（RX音声もiPhoneスピーカーへ）

■ 主な機能

◆ SP2ALART 連携
・POTA/SOTA スポット通知をタップするとアプリが起動し周波数・モードが自動設定

◆ 基本リグ制御
・受信周波数・モード・信号強度(Sメーター)のリアルタイム表示
・周波数、モード、送信出力、スケルチ、フィルタ幅の変更
・受信音声のスピーカー再生（ノイズリダクション対応）
・PTTのON/OFFとマイク音声送信
・CWデコード（複数局同時／最大5局）とCW送信（プリセット・WPM調整）
・BLE CWキーヤー対応（DualKey-BLE / RemoteKeyer-BLE をBluetoothで接続）
・RTTY AFSK 送受信（ソフトウェアモデム・スペクトラム表示・オートチューン）
・FT8/FT4 のデコード・送信
・APRSビーコン送信（スマホGPS対応）
・QSO ログ（ADIF エクスポート・POTA/SOTA 参照符号対応）
・複数プロファイル対応（接続先の切り替え）
・APIキー認証、WireGuard VPN 経由のリモートアクセスに対応

■ 動作に必要なもの（重要）
本アプリ単体では動作しません。次のいずれかのユーザー所有ハードウェアが必要です。
・セットアップ済みの Raspberry Pi Zero 2W（無線機に接続、Hamlib/FastAPI導入済み）、または
・IC-705 / IC-9700（直接CI-V接続の場合）
いずれもiPhoneと同一のWi-Fiネットワークに接続してください。
Raspberry Pi のセットアップ手順・ファームウェアは下記GitHubで公開しています。
https://github.com/ji1ore/M5CoreHamCAT

■ 対象ユーザー
アマチュア無線の免許を持ち、対応する無線機環境をお持ちの方向けのアプリです。

※本アプリは広告・使用状況の追跡を一切含みません。取得した情報は端末内でのみ使用し、外部サーバーへ送信しません。
```

---

## 4. キーワード（100字以内・カンマ区切り・スペースなし推奨）

```
ham radio,amateur radio,rig control,CAT,Hamlib,APRS,CW,morse,FT8,RTTY,CI-V,transceiver
```

---

## 5. URL

- サポートURL: `https://github.com/ji1ore/M5CoreHamCAT`
- プライバシーポリシーURL: `https://github.com/ji1ore/M5CoreHamCAT/blob/main/v3.20/M5CoreHamCAT_iOS/PRIVACY_POLICY_iOS.md`

---

## 6. App Store Connect「Appのプライバシー」入力ガイド

- **データを収集していますか？** → **いいえ**
  - 位置情報・マイク音声・接続設定はすべて端末内でのみ利用。開発者や第三者のサーバーへ送信しないため「収集」に非該当。

---

## 7. 年齢制限・カテゴリ

- カテゴリ: ユーティリティ（主）、仕事効率化（副）
- 年齢制限: 4+

---

## 8. App Review 情報（審査メモ）

### Notes（英語・そのまま貼り付け可）
```
This app is a companion/controller app for licensed amateur (ham) radio operators.
It remotely controls a physical ham radio transceiver over Wi-Fi and therefore
REQUIRES the user's own hardware to function.

Required hardware (one of):
1) A Raspberry Pi Zero 2W connected to a radio, running Hamlib + our FastAPI server
   (setup guide: https://github.com/ji1ore/M5CoreHamCAT), OR
2) An Icom IC-705 or IC-9700 on the same Wi-Fi network (direct CI-V mode).

HOW TO REVIEW WITHOUT HARDWARE:
On the first screen, scroll to the bottom to the "Demo" section and tap
"Skip with mock data" to explore all screens without any radio connected.

Contact: jiro.ueno0213@gmail.com
```

### Sign-in
- ログイン不要 → 「サインインが必要」は **オフ**

---

## 9. リリースノート（What's New）— v3.20 (build 57)

```
v3.20

【RTTY 受信を一新】
・受信復調を連続直交整合フィルタ＋サブサンプルタイミング復元に再設計。ノイズ・規定外ボーレート・端数サンプルレートに強く、より確実にデコード
・RTTY スペクトラム表示をマーク/スペース帯域に自動ズームし、信号が画面幅いっぱいに表示されるように改善

【運用地（運用地管理）】
・JCC/JGC とメイデンヘッド・グリッドを GPS または地図から登録
・現在地マップに POTA（緑）/SOTA（赤）ピンを表示（非アクティブな POTA 公園は非表示）
・UTC/ローカルの開始・終了時刻を持つ運用セッションに対応
・FT8 / RTTY / CW 送信画面に運用地セレクターバーを追加し、記録する各 QSO に運用地を自動反映

【QSO ログ拡張】
・QSL 方法（JARL/hQSL/No/Card/1-Way）、交信相手の GL/QTH、自局 GL、運用地（MY_CITY）の各項目を追加
・入力フォームに UTC/ローカル時刻の切替を追加
・キャンセル/保存ボタンをダイアログのヘッダーに移動（キーボードで隠れないように）

【外部連携】
・My Call アカウントごとに eQSL へ自動アップロード（コメント→eQSL Remarks）
・Smart Ham Log（Cloudlog 互換ブリッジ）への QSO アップロードと接続テストに対応
・PSKReporter 受信レポート送信トグルを追加（FT8）
・QSO LIST に eQSL/SHL 送付状態を表示し、一括送付・公園/サミット単位の ADIF 一括エクスポートに対応

【接続画面】
・My Call 履歴のドロップダウンを追加

【iCloud バックアップ】
・設定と QSO ログを iCloud Drive に自動バックアップ（バックグラウンド移行時に自動保存）。同じ iCloud アカウントで再インストールすると初回起動時に自動復元。接続画面から手動の保存/復元も可能（認証情報はキーチェーン管理のためバックアップには含まれません）

【バグ修正】
・FTX-1 内蔵 APRS ビーコンが開始しない問題を修正（BEACON TYPE が AUTO に切り替わらなかった不具合）
```

---

## 10. 未対応・要準備タスク（チェックリスト v3.20）

- [ ] MARKETING_VERSION = 3.20 / CURRENT_PROJECT_VERSION = 57 設定済みか確認
- [x] AppStore_Listing_Draft.md v3.20 内容に更新済み
- [x] Pi API 更新あり → Update Pi 必要（リリースノートに記載済み）
- [ ] Xcode で Archive → App Store Connect へアップロード（GUI操作必要）
- [ ] App Store Connect で新バージョン 3.20 (build 57) を作成
- [ ] リリースノート（上記セクション9）を App Store Connect に貼り付け
- [ ] スクリーンショット iPhone 6.5型（変更なければ前回使いまわし可）
- [ ] 審査提出
