# WifiRigCTRL — App Store Listing Draft (English)

Created: 2026-09-20 / Updated: 2026-10-14 / Target version: 3.20 (build 57)

---

## 1. Basic Info

| Field | Content | Limit |
|---|---|---|
| App Name | WifiRigCTRL | 30 |
| Subtitle | Wi-Fi remote rig control | 30 |

---

## 2. Promotional Text (170 chars max — can be updated anytime)

```
v3.20: RTTY receive demodulator rebuilt as a continuous quadrature matched filter for more robust decoding. New operating-location (JCC/JGC & grid) management plus eQSL / Smart Ham Log auto-upload. Remote rig control via Wi-Fi — CW, FT8, RTTY and APRS included.
```

---

## 3. Description (4000 chars max)

```
WifiRigCTRL is a controller app that lets you remotely operate an amateur (ham) radio transceiver from your iPhone or iPad over Wi-Fi.

Three ways to connect:
1. Via Raspberry Pi (Hamlib/FastAPI) — CAT control for a wide range of rigs, plus RX audio, CW, FT8 and APRS
2. Direct CI-V — connect to an IC-705 / IC-9700 on the same Wi-Fi, no Raspberry Pi required
3. BT CI-V Bluetooth — connect directly to IC-705 / IC-9700 over Bluetooth (RX audio to iPhone speaker)

Features

SP2ALART Integration
- Tap a POTA/SOTA spot notification from SP2ALART and this app opens with the spot's frequency and mode pre-configured

Rig Control
- Real-time display of RX frequency, mode and signal strength (S-meter)
- Change frequency, mode, TX power, squelch and filter width
- Play received audio through the speaker (with noise reduction)
- PTT ON/OFF and microphone audio transmission
- CW decoding (multi-station, up to 5) and CW transmit (presets, WPM control)
- BLE CW keyer support (connect DualKey-BLE / RemoteKeyer-BLE over Bluetooth)
- RTTY AFSK TX/RX (software modem with spectrum display and auto-tune)
- FT8/FT4 decode and transmit
- APRS beacon transmission (with smartphone GPS)
- QSO log with ADIF export and POTA/SOTA reference fields
- Multiple profiles (switch between connection targets)
- API key authentication and remote access over WireGuard VPN

What you need (important)
This app does not work on its own. You must have one of the following (your own hardware):
- A set-up Raspberry Pi Zero 2W connected to your radio (Hamlib/FastAPI installed), or
- An IC-705 / IC-9700 (for direct CI-V connection)
Connect it to the same Wi-Fi network as your iPhone.
Raspberry Pi setup instructions and firmware are published on GitHub:
https://github.com/ji1ore/M5CoreHamCAT

Who it's for
For licensed amateur radio operators who have a compatible radio setup.

This app contains no ads and no usage tracking. Any information is used only on your device and is never sent to external servers.
```

---

## 4. Keywords (100 chars max, comma-separated, no spaces)

```
ham radio,amateur radio,rig control,CAT,Hamlib,APRS,CW,morse,FT8,RTTY,CI-V,transceiver
```

---

## 5. URLs

- Support URL: `https://github.com/ji1ore/M5CoreHamCAT`
- Privacy Policy URL: `https://github.com/ji1ore/M5CoreHamCAT/blob/main/v3.20/M5CoreHamCAT_iOS/PRIVACY_POLICY_iOS.md`

---

## 6. App Privacy (App Store Connect)

- **Do you collect data from this app?** → **No**
  - Location, microphone audio, and connection settings are used locally on the device only. No data is sent to the developer or third-party servers, so this does not qualify as "collection" under Apple's definition.

---

## 7. Category & Age Rating

- Category: Utilities (primary), Productivity (secondary)
- Age Rating: 4+

---

## 8. App Review Notes

### Notes (paste as-is)
```
This app is a companion/controller app for licensed amateur (ham) radio operators.
It remotely controls a physical ham radio transceiver over Wi-Fi and therefore
REQUIRES the user's own hardware to function.

Required hardware (one of):
1) A Raspberry Pi Zero 2W connected to a radio, running Hamlib + our FastAPI server
   (setup guide: https://github.com/ji1ore/M5CoreHamCAT), OR
2) An Icom IC-705 or IC-9700 on the same Wi-Fi network (direct CI-V mode).

HOW TO REVIEW WITHOUT HARDWARE:
On the first screen, scroll to the bottom to the "Demo" section and tap
"Skip with mock data" to explore all screens without any radio connected.

Contact: jiro.ueno0213@gmail.com
```

### Sign-in
- No sign-in required → set "Sign-in required" to **Off**

---

## 9. What's New — v3.20 (build 57)

```
v3.20

[RTTY receive rebuilt]
- Receive demodulator redesigned as a continuous quadrature matched filter with sub-sample timing recovery — more robust decoding against noise, off-nominal baud rates and fractional sample rates
- RTTY spectrum now zooms to the mark/space band so the signal fills the full screen width

[Operating-location management]
- Register JCC/JGC and Maidenhead grid via GPS or map
- POTA (green) / SOTA (red) pins on the current-location map (inactive POTA parks hidden)
- Operating sessions with UTC/local start and end times
- Operating-location selector bar on the FT8 / RTTY / CW transmit screens, so each logged QSO inherits the location

[QSO log additions]
- New fields: QSL method (JARL/hQSL/No/Card/1-Way), worked-station GL/QTH, My GL, operating place (MY_CITY)
- UTC/local time toggle on the entry form
- Cancel/Save moved to the dialog header (keyboard-safe)

[External integration]
- Automatic eQSL upload per My-Call account (comment maps to eQSL Remarks)
- Smart Ham Log (Cloudlog-compatible bridge) QSO upload with connection test
- PSKReporter reception-report sending toggle (FT8)
- QSO LIST shows eQSL/SHL sent status, with bulk send and per-park/summit bulk ADIF export

[Connect screen]
- My Call history dropdown added

[iCloud backup]
- Settings and QSO log are backed up automatically to iCloud Drive (auto-saved when the app goes to the background), and auto-restored on first launch after a fresh install with the same iCloud account. Manual save/restore is also available from the Connect screen (credentials stay in the Keychain and are not included in the backup)

[Bug fix]
- Fixed FTX-1 built-in APRS beacon not starting (BEACON TYPE was not switching to AUTO)
```

---

## 10. Release Checklist — v3.20

- [ ] MARKETING_VERSION = 3.20 / CURRENT_PROJECT_VERSION = 57 confirmed
- [x] AppStore_Listing_Draft_EN.md updated to v3.20
- [x] Pi API updated — "Update Pi" required (noted in What's New)
- [ ] Archive in Xcode → upload to App Store Connect
- [ ] Create new version 3.20 (build 57) in App Store Connect
- [ ] Paste What's New text (section 9) in App Store Connect
- [ ] Screenshots iPhone 6.5" (can reuse from previous version if unchanged)
- [ ] Submit for review
