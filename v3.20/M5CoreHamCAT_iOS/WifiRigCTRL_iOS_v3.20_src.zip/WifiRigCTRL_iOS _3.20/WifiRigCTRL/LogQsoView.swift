import SwiftUI
import CoreLocation
import Contacts

private let persistKey = "log_qso_persist"

private func loadPersist() -> [String: String] {
    UserDefaults.standard.dictionary(forKey: persistKey) as? [String: String] ?? [:]
}
private func savePersist(_ d: [String: String]) {
    UserDefaults.standard.set(d, forKey: persistKey)
}


struct LogQsoView: View {
    @Environment(\.dismiss) private var dismiss
    let vm: MainViewModel

    // Pre-filled from caller (CW TX screen etc.)
    var initCallsign: String = ""
    var initPota: String = ""
    var initSota: String = ""
    var initRstSent: String = ""
    /// Called after each successful save (caller can clear its own DX call / RST fields)
    var onSaved: (() -> Void)? = nil

    @FocusState private var focused: Bool

    // Transient fields — cleared after each save
    @State private var callsign: String = ""
    @State private var rstSent: String = ""
    @State private var rstRcvd: String = ""
    @State private var yourPota: String = ""
    @State private var yourSota: String = ""
    @State private var dxGl: String = ""      // 相手局グリッド(GRIDSQUARE→HAMLOG GL)
    @State private var dxQth: String = ""     // 相手局QTH(QTH→HAMLOG QTH)
    @State private var qsl: String = ""       // QSL状態コード("",J,H,N,C,1)
    @State private var myGl: String = ""      // 自局GL(運用地GL/ft8MyGrid既定)
    @State private var myLoc: String = ""     // 自局運用場所(My Parkマルチロケ等)
    @State private var dtDate: String = ""
    @State private var dtTime: String = ""
    @State private var dtLocal = false   // true=日時をローカルタイムで入力(保存時UTCへ変換)

    // Persistent fields — survive across sessions
    @State private var myPota: String = ""
    @State private var mySota: String = ""
    @State private var jcc: String = ""
    @State private var jgc: String = ""
    @State private var comment: String = ""

    // 運用地(この交信にアクティブなセッション)のチェック状態
    @State private var opChecked: Set<String> = []
    @State private var opInit = false
    // コメント自動生成
    @State private var autoComment = UserDefaults.standard.bool(forKey: "autoComment")


    private var freqHz: Int64 { Int64(vm.sharedFreq) }
    private var mode: String { vm.sharedMode }
    private var myCall: String { vm.ft8MyCall }
    private var myGrid: String { vm.ft8MyGrid }

    private var defaultRst: String {
        let m = mode.uppercased()
        if m.contains("CW") { return "599" }
        if m.hasPrefix("FT") || m == "RTTY" { return "-00" }
        return "59"
    }

    private var rstPresets: [String] {
        let m = mode.uppercased()
        if m.contains("CW") { return (1...9).map { "5\($0)9" } }
        if m.hasPrefix("FT") || m == "RTTY" { return ["-20", "-15", "-10", "-05", "00", "+05", "+10"] }
        return (1...9).map { "5\($0)" }
    }

    @ViewBuilder
    private func rstChipsView(setter: @escaping (String) -> Void) -> some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 4) {
                ForEach(rstPresets, id: \.self) { v in
                    Button(v) { setter(v) }
                        .font(.system(size: 11, design: .monospaced))
                        .foregroundStyle(.cyan)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 3)
                        .background(Color(white: 0.15), in: RoundedRectangle(cornerRadius: 4))
                        .buttonStyle(.plain)
                }
            }
        }
        .frame(height: 26)
    }

    private let utcTz = TimeZone(identifier: "UTC")!
    private var dtTz: TimeZone { dtLocal ? TimeZone.current : utcTz }

    /// 壁時計文字列(yyyyMMddHHmmss, tz解釈)→epoch ms
    private func wallToMs(_ wall: String, _ tz: TimeZone) -> Int64 {
        let padded = String((wall + "00000000000000").prefix(14))
        let f = DateFormatter(); f.dateFormat = "yyyyMMddHHmmss"; f.timeZone = tz; f.isLenient = true
        return Int64((f.date(from: padded)?.timeIntervalSince1970 ?? Date().timeIntervalSince1970) * 1000)
    }
    private func msToWall(_ ms: Int64, _ tz: TimeZone) -> String {
        let f = DateFormatter(); f.dateFormat = "yyyyMMddHHmmss"; f.timeZone = tz
        return f.string(from: Date(timeIntervalSince1970: Double(ms) / 1000.0))
    }

    /// 入力中の反対タイムゾーンの時刻を表示(入力がローカルならUTC、UTCならローカル)
    private var otherTimeStr: String {
        let ms = wallToMs(dtDate + dtTime, dtTz)
        let other = dtLocal ? utcTz : TimeZone.current
        let f = DateFormatter(); f.dateFormat = "MM/dd HH:mm"; f.timeZone = other
        return (dtLocal ? "UTC: " : "Local: ") + f.string(from: Date(timeIntervalSince1970: Double(ms) / 1000.0))
    }

    var body: some View {
        NavigationStack {
            Form {
                // ── 周波数・自局 ──────────────────────────────────────
                Section("QSO情報") {
                    LabeledContent("周波数") {
                        Text(freqHz > 0
                            ? String(format: "%.3f MHz  %@  %@",
                                     Double(freqHz) / 1_000_000.0,
                                     QsoStore.freqToBand(freqHz), mode)
                            : "---")
                            .font(.system(size: 15, design: .monospaced))
                            .foregroundStyle(.cyan)
                    }
                    LabeledContent("自局") {
                        Text(myCall.isEmpty ? "(未設定)" : myCall)
                            .font(.system(size: 15, design: .monospaced))
                            .foregroundStyle(.cyan)
                    }
                }

                // ── 日時 (UTC / ローカル 入力切替) ─────────────────────
                Section {
                    Toggle("ローカルタイムで入力 (OFFでUTC)", isOn: $dtLocal)
                        .onChange(of: dtLocal) { _, newVal in
                            // 表示中の数字を新しいタイムゾーンの壁時計へ変換
                            let oldTz = newVal ? utcTz : TimeZone.current
                            let newTz = newVal ? TimeZone.current : utcTz
                            let w = msToWall(wallToMs(dtDate + dtTime, oldTz), newTz)
                            dtDate = String(w.prefix(8)); dtTime = String(w.dropFirst(8).prefix(6))
                        }
                    HStack(spacing: 8) {
                        TextField("yyyyMMdd", text: $dtDate)
                            .keyboardType(.numberPad)
                            .font(.system(size: 15, design: .monospaced))
                            .frame(maxWidth: .infinity)
                        TextField("HHmmss", text: $dtTime)
                            .keyboardType(.numberPad)
                            .font(.system(size: 15, design: .monospaced))
                            .frame(maxWidth: .infinity)
                    }
                    Text(otherTimeStr).font(.caption).foregroundStyle(.secondary)
                } header: {
                    Text(dtLocal ? "日時 ローカル  (yyyyMMdd  HHmmss)" : "日時 UTC  (yyyyMMdd  HHmmss)")
                }

                // ── 相手局 ───────────────────────────────────────────
                Section("相手局") {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("DX コールサイン").font(.caption).foregroundStyle(.secondary)
                        TextField("JA2ABC", text: $callsign)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .keyboardType(.asciiCapable)
                            .font(.system(size: 22, weight: .bold, design: .monospaced))
                            .foregroundStyle(.yellow)
                            .focused($focused)
                            .onChange(of: callsign) { _, v in
                                callsign = v.uppercased()
                                    .filter { $0.isLetter && $0.asciiValue != nil || $0.isNumber || $0 == "/" }
                            }
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        HStack {
                            Text("RST 送信").foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
                            TextField(defaultRst, text: $rstSent)
                                .autocorrectionDisabled()
                                .textInputAutocapitalization(.characters)
                                .font(.system(size: 17, design: .monospaced))
                        }
                        rstChipsView { rstSent = $0 }
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        HStack {
                            Text("RST 受信").foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
                            TextField(defaultRst, text: $rstRcvd)
                                .autocorrectionDisabled()
                                .textInputAutocapitalization(.characters)
                                .font(.system(size: 17, design: .monospaced))
                        }
                        rstChipsView { rstRcvd = $0 }
                    }
                }

                // ── Your POTA / SOTA (相手局) ─────────────────────────
                Section("相手局 POTA / SOTA") {
                    HStack {
                        Text("POTA").foregroundStyle(.secondary).frame(width: 60, alignment: .leading)
                        TextField("JP-XXXX", text: $yourPota)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .onChange(of: yourPota) { _, v in yourPota = v.uppercased() }
                    }
                    HStack {
                        Text("SOTA").foregroundStyle(.secondary).frame(width: 60, alignment: .leading)
                        TextField("JA/NN-001", text: $yourSota)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .onChange(of: yourSota) { _, v in yourSota = v.uppercased() }
                    }
                    HStack {
                        Text("GL").foregroundStyle(.secondary).frame(width: 60, alignment: .leading)
                        TextField("PM95", text: $dxGl)
                            .autocorrectionDisabled().textInputAutocapitalization(.characters)
                            .onChange(of: dxGl) { _, v in dxGl = v.uppercased() }
                    }
                    HStack {
                        Text("QTH").foregroundStyle(.secondary).frame(width: 60, alignment: .leading)
                        TextField("相手局QTH", text: $dxQth).autocorrectionDisabled()
                    }
                    Picker("QSL", selection: $qsl) {
                        Text("空白").tag(""); Text("JARL").tag("J"); Text("hQSL").tag("H")
                        Text("No").tag("N"); Text("Card").tag("C"); Text("1-Way").tag("1")
                    }
                }

                // ── My POTA / SOTA (自局) — 永続 ─────────────────────
                Section("自局 POTA / SOTA  (次回も保持)") {
                    HStack {
                        Text("My POTA").foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
                        TextField("JP-XXXX", text: $myPota)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .onChange(of: myPota) { _, v in myPota = v.uppercased() }
                    }
                    HStack {
                        Text("My SOTA").foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
                        TextField("JA/NN-001", text: $mySota)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .onChange(of: mySota) { _, v in mySota = v.uppercased() }
                    }
                    HStack {
                        Text("My GL").foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
                        TextField("PM95", text: $myGl)
                            .autocorrectionDisabled().textInputAutocapitalization(.characters)
                            .onChange(of: myGl) { _, v in myGl = v.uppercased() }
                    }
                    HStack {
                        Text("運用場所").foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
                        TextField("地点名(My Parkマルチロケ等)", text: $myLoc).autocorrectionDisabled()
                    }
                }

                // ── JCC / JGC — 永続 ─────────────────────────────────
                Section("JCC / JGC  (次回も保持)") {
                    HStack {
                        Text("JCC").foregroundStyle(.secondary).frame(width: 40, alignment: .leading)
                        TextField("1234", text: $jcc)
                            .keyboardType(.numberPad)
                        Text("JGC").foregroundStyle(.secondary).frame(width: 40, alignment: .leading)
                        TextField("12345", text: $jgc)
                            .keyboardType(.numberPad)
                    }
                }

                // ── この交信の運用地 (メイン画面の選択を引き継ぎ、ここで取捨選択) ──
                opSessionSection

                // ── コメント — 永続 ───────────────────────────────────
                Section("コメント  (次回も保持)") {
                    Toggle("My POTA/SOTA/JCC/JGCから自動生成", isOn: $autoComment)
                        .onChange(of: autoComment) { _, v in
                            UserDefaults.standard.set(v, forKey: "autoComment")
                            if v { comment = genComment() }
                        }
                    TextField("メモ・コメント", text: $comment)
                }
                .onChange(of: myPota) { _, _ in if autoComment { comment = genComment() } }
                .onChange(of: mySota) { _, _ in if autoComment { comment = genComment() } }
                .onChange(of: jcc) { _, _ in if autoComment { comment = genComment() } }
                .onChange(of: jgc) { _, _ in if autoComment { comment = genComment() } }

                // ── 永続フィールド クリア ─────────────────────────────
                Section {
                    Button(role: .destructive) {
                        myPota = ""; mySota = ""
                        jcc = ""; jgc = ""; comment = ""
                        var d = loadPersist()
                        d.removeValue(forKey: "myPota"); d.removeValue(forKey: "mySota")
                        d.removeValue(forKey: "jcc");    d.removeValue(forKey: "jgc")
                        d.removeValue(forKey: "comment")
                        savePersist(d)
                    } label: {
                        Text("My POTA / SOTA / JCC / コメント をクリア")
                    }
                }
            }
            .navigationTitle("Log QSO")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("閉じる") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") { saveEntry() }
                        .disabled(callsign.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
        }
        .onAppear { initFields() }
    }

    // この交信の時刻でアクティブな運用地をチェック表示(メイン画面の選択を既定に引継ぎ)
    @ViewBuilder private var opSessionSection: some View {
        let qsoMs = wallToMs(dtDate + dtTime, dtTz)
        let activeOps = vm.activeSessionsAt(qsoMs)
        if !activeOps.isEmpty {
            Section("この交信の運用地 (チェックで My POTA/SOTA/JCC に反映・2ferは複数POTA)") {
                ForEach(activeOps) { s in
                    Toggle(isOn: Binding(
                        get: { opChecked.contains(s.id) },
                        set: { v in
                            if v { opChecked.insert(s.id) } else { opChecked.remove(s.id) }
                            applyOpSelection(activeOps)
                        })) { Text("\(s.type)  \(s.ref)") }
                }
            }
            .onAppear {
                if !opInit {
                    opInit = true
                    opChecked = Set(vm.selectedSessionsAt(qsoMs).map { $0.id })
                    applyOpSelection(activeOps)
                }
            }
        }
    }

    private func applyOpSelection(_ active: [OpSession]) {
        let on = active.filter { opChecked.contains($0.id) }
        if active.contains(where: { $0.type == "POTA" }) { myPota = on.filter { $0.type == "POTA" }.map { $0.ref }.joined(separator: ",") }
        if active.contains(where: { $0.type == "SOTA" }) { mySota = on.first { $0.type == "SOTA" }?.ref ?? "" }
        if active.contains(where: { $0.type == "JCC" })  { jcc = on.first { $0.type == "JCC" }?.ref ?? "" }
        if active.contains(where: { $0.type == "JGC" })  { jgc = on.first { $0.type == "JGC" }?.ref ?? "" }
        // 選択中の運用地にGLがあれば My GL へ反映
        if let g = on.compactMap({ $0.gl }).first(where: { !$0.isEmpty }) { myGl = g }
    }

    private func genComment() -> String {
        var parts: [String] = []
        let p = myPota.trimmingCharacters(in: .whitespaces); if !p.isEmpty { parts.append("POTA \(p)") }
        let s = mySota.trimmingCharacters(in: .whitespaces); if !s.isEmpty { parts.append("SOTA \(s)") }
        let c = jcc.trimmingCharacters(in: .whitespaces);    if !c.isEmpty { parts.append("JCC \(c)") }
        let g = jgc.trimmingCharacters(in: .whitespaces);    if !g.isEmpty { parts.append("JGC \(g)") }
        return parts.joined(separator: " ")
    }

    private func parseUtcDtMs(_ dt: String) -> Int64 {
        let padded = String((dt + "00000000000000").prefix(14))
        let f = DateFormatter(); f.dateFormat = "yyyyMMddHHmmss"
        f.timeZone = TimeZone(identifier: "UTC"); f.isLenient = true
        return Int64((f.date(from: padded)?.timeIntervalSince1970 ?? Date().timeIntervalSince1970) * 1000)
    }

    private func initFields() {
        let now = QsoEntry.utcNow()
        dtDate = String(now.prefix(8))
        dtTime = String(now.dropFirst(8))
        callsign = initCallsign.isEmpty ? vm.pendingLogCallsign : initCallsign
        yourPota = initPota.isEmpty     ? vm.pendingLogPota     : initPota
        yourSota = initSota.isEmpty     ? vm.pendingLogSota     : initSota
        // CW TX 等 pendingLogPota が無い経路でも、相手局が POTA スポットで判明していれば
        // 相手POTA を自動補完する(相手の公園情報が入らない不具合を修正)。
        if yourPota.isEmpty {
            let base = callsign.uppercased().components(separatedBy: "/").first ?? callsign.uppercased()
            let refs = (vm.potaActivatorMap[base] ?? []).map { $0.reference }.filter { !$0.isEmpty }
            if !refs.isEmpty { yourPota = Array(Set(refs)).sorted().joined(separator: ",") }
        }
        rstSent  = initRstSent.isEmpty  ? defaultRst            : initRstSent
        rstRcvd  = defaultRst
        myGl     = vm.ft8MyGrid   // 既定は自局グリッド。運用地選択でGLがあれば上書き
        let p = loadPersist()
        myLoc    = p["myLoc"]   ?? ""
        myPota   = p["myPota"]  ?? ""
        mySota   = p["mySota"]  ?? ""
        jcc      = p["jcc"]     ?? ""
        jgc      = p["jgc"]     ?? ""
        comment  = p["comment"] ?? ""
        // 運用地(アクティブな op-session)の初期反映はここ(トップレベル onAppear)で行う。
        // Form 下部の運用地セクションの .onAppear はスクロールされるまで発火しないため、
        // それに頼ると CW 等で運用地が QSO に入らない。確実に適用する。
        if !opInit {
            let qsoMs = wallToMs(dtDate + dtTime, dtTz)
            let activeOps = vm.activeSessionsAt(qsoMs)
            if !activeOps.isEmpty {
                opInit = true
                opChecked = Set(vm.selectedSessionsAt(qsoMs).map { $0.id })
                applyOpSelection(activeOps)
            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { focused = true }
    }

    private func saveEntry() {
        let call = callsign.trimmingCharacters(in: .whitespaces).uppercased()
        guard !call.isEmpty else { return }
        // ローカル入力中はUTCへ変換して保存(dtは常にUTC)
        let raw = (dtDate.trimmingCharacters(in: .whitespaces)
                 + dtTime.trimmingCharacters(in: .whitespaces))
            .padding(toLength: 14, withPad: "0", startingAt: 0)
        let dt = dtLocal ? msToWall(wallToMs(raw, TimeZone.current), utcTz) : raw
        let entry = QsoEntry(
            dt:       dt,
            call:     call,
            freq:     freqHz,
            mode:     mode.isEmpty ? "SSB" : mode,
            rstS:     rstSent.isEmpty  ? defaultRst : rstSent,
            rstR:     rstRcvd.isEmpty  ? defaultRst : rstRcvd,
            grid:     dxGl.trimmingCharacters(in: .whitespaces).uppercased(),
            myCall:   myCall,
            myGrid:   myGl.trimmingCharacters(in: .whitespaces).uppercased().isEmpty ? myGrid : myGl.trimmingCharacters(in: .whitespaces).uppercased(),
            yourPota: yourPota.trimmingCharacters(in: .whitespaces).uppercased(),
            yourSota: yourSota.trimmingCharacters(in: .whitespaces).uppercased(),
            myPota:   myPota.trimmingCharacters(in: .whitespaces).uppercased(),
            mySota:   mySota.trimmingCharacters(in: .whitespaces).uppercased(),
            jcc:      jcc.trimmingCharacters(in: .whitespaces),
            jgc:      jgc.trimmingCharacters(in: .whitespaces),
            comment:  comment.trimmingCharacters(in: .whitespaces),
            lat:      0.0, lon: 0.0,
            qsl:      qsl,
            qth:      dxQth.trimmingCharacters(in: .whitespaces),
            myLoc:    myLoc.trimmingCharacters(in: .whitespaces)
        )
        QsoStore.append(entry)
        vm.ft8QsoLog = QsoStore.jsonString()
        // 外部連携: eQSL 自動送信 / Smart HAMLOG 自動連携(各々ONかつ設定ありのときのみ)。
        // FT8自動QSO(Ft8View)と共通のロジックを使用。
        vm.autoShareQso(entry)

        // 永続フィールドを保存
        var d = loadPersist()
        d["myLoc"]   = entry.myLoc
        d["myPota"]  = entry.myPota
        d["mySota"]  = entry.mySota
        d["jcc"]     = entry.jcc
        d["jgc"]     = entry.jgc
        d["comment"] = entry.comment
        savePersist(d)

        // 一時フィールドをクリアして次のQSOに備える (ダイアログは閉じない)
        callsign = ""
        yourPota = ""
        yourSota = ""
        rstSent  = defaultRst
        rstRcvd  = defaultRst
        let next = dtLocal ? msToWall(Int64(Date().timeIntervalSince1970 * 1000), TimeZone.current) : QsoEntry.utcNow()
        dtDate = String(next.prefix(8))
        dtTime = String(next.dropFirst(8))
        focused = true

        // Logged → clear the prefill info and the CW TX screen's DX call / RST,
        // regardless of which screen opened this sheet.
        vm.pendingLogCallsign = ""
        vm.pendingLogPota = ""
        vm.pendingLogSota = ""
        vm.cwDxCall = ""
        vm.cwRst = ""
        vm.persistCwSettings()
        onSaved?()
    }
}
