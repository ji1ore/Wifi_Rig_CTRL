package com.ji1ore.wifi_rig_ctrl

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.util.Log
import com.ji1ore.wifi_rig_ctrl.data.AppPrefs
import org.json.JSONArray
import org.json.JSONObject

/**
 * 設定(非機密)と QSO ログを、ユーザーが選んだフォルダ(SAFツリー)へ保存し、
 * 再インストール後も同フォルダを選び直せば復元できるようにする。
 *
 * - 対象: SharedPreferences "wifi_rig_ctrl"(平文)の全キー = 接続設定・運用地・連携ON/URL・QSOログ等。
 * - 除外: 認証情報は暗号化ストア "wifi_rig_ctrl_secure" にあり、ここでは一切扱わない(平文流出を避ける)。
 * - SAFの永続権限はアンインストールで失われるため、再インストール後は folder を選び直す→復元する。
 */
object BackupStore {
    private const val TAG = "BackupStore"
    private const val PREFS = "wifi_rig_ctrl"
    private const val FILE = "wifirig_backup.json"

    fun hasFolder(ctx: Context) = AppPrefs(ctx).backupTreeUri.isNotEmpty()

    /** OpenDocumentTree で選んだ URI を永続権限付きで保存。 */
    fun setFolder(ctx: Context, treeUri: Uri) {
        try {
            ctx.contentResolver.takePersistableUriPermission(
                treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        } catch (_: Exception) {}
        AppPrefs(ctx).backupTreeUri = treeUri.toString()
    }

    /** 現在の設定/ログをバックアップフォルダへ書き出す。成功で true。 */
    fun save(ctx: Context): Boolean {
        val tree = treeUri(ctx) ?: return false
        return try {
            val fileUri = findFile(ctx, tree) ?: createFile(ctx, tree) ?: return false
            ctx.contentResolver.openOutputStream(fileUri, "wt")?.use {
                it.write(serializePrefs(ctx).toString().toByteArray(Charsets.UTF_8))
            }
            true
        } catch (e: Exception) { Log.w(TAG, "save failed: ${e.message}"); false }
    }

    /** バックアップから復元(prefsへ適用)。成功で true。 */
    fun restore(ctx: Context): Boolean {
        val tree = treeUri(ctx) ?: return false
        return try {
            val fileUri = findFile(ctx, tree) ?: return false
            val bytes = ctx.contentResolver.openInputStream(fileUri)?.use { it.readBytes() } ?: return false
            applyPrefs(ctx, JSONObject(String(bytes, Charsets.UTF_8)))
            true
        } catch (e: Exception) { Log.w(TAG, "restore failed: ${e.message}"); false }
    }

    /** まっさら(新規/再インストール直後)かつフォルダ設定済みなら自動復元。 */
    fun restoreIfFresh(ctx: Context) {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val fresh = !p.contains("ft8QsoLog") && !p.contains("hostName")
        if (fresh && hasFolder(ctx)) { if (restore(ctx)) Log.i(TAG, "auto-restored from backup") }
    }

    // ---- SAF (DocumentsContract) ----
    private fun treeUri(ctx: Context): Uri? {
        val s = AppPrefs(ctx).backupTreeUri
        return if (s.isEmpty()) null else Uri.parse(s)
    }

    private fun findFile(ctx: Context, tree: Uri): Uri? {
        val docId = DocumentsContract.getTreeDocumentId(tree)
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        ctx.contentResolver.query(children,
            arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME),
            null, null, null)?.use { c ->
            while (c.moveToNext()) {
                if (c.getString(1) == FILE)
                    return DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0))
            }
        }
        return null
    }

    private fun createFile(ctx: Context, tree: Uri): Uri? {
        val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        return DocumentsContract.createDocument(ctx.contentResolver, parent, "application/json", FILE)
    }

    // ---- prefs <-> JSON (型保持) ----
    private fun serializePrefs(ctx: Context): JSONObject {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val root = JSONObject()
        for ((k, v) in p.all) {
            val o = JSONObject()
            when (v) {
                is String  -> { o.put("t", "s"); o.put("v", v) }
                is Int     -> { o.put("t", "i"); o.put("v", v) }
                is Long    -> { o.put("t", "l"); o.put("v", v) }
                is Boolean -> { o.put("t", "b"); o.put("v", v) }
                is Float   -> { o.put("t", "f"); o.put("v", v.toDouble()) }
                is Set<*>  -> { o.put("t", "ss"); o.put("v", JSONArray(v.toList())) }
                else -> continue
            }
            root.put(k, o)
        }
        return root
    }

    private fun applyPrefs(ctx: Context, root: JSONObject) {
        val e = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        val it = root.keys()
        while (it.hasNext()) {
            val k = it.next(); val o = root.getJSONObject(k)
            when (o.getString("t")) {
                "s"  -> e.putString(k, o.getString("v"))
                "i"  -> e.putInt(k, o.getInt("v"))
                "l"  -> e.putLong(k, o.getLong("v"))
                "b"  -> e.putBoolean(k, o.getBoolean("v"))
                "f"  -> e.putFloat(k, o.getDouble("v").toFloat())
                "ss" -> { val a = o.getJSONArray("v"); e.putStringSet(k, (0 until a.length()).map { a.getString(it) }.toSet()) }
            }
        }
        e.apply()
    }
}
