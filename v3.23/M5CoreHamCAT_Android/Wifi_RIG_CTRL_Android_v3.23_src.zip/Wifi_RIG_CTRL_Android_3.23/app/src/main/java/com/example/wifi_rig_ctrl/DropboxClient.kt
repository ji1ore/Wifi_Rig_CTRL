package com.ji1ore.wifi_rig_ctrl

import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Dropbox REST API を アクセストークンで直接叩く最小クライアント(SDK不使用)。
 * Smart Ham Log が同期する .hdb の取得/保存に使う。すべて同期(ブロッキング)なので
 * 呼び出し側はワーカースレッドから使うこと。
 */
object DropboxClient {
    private const val TAG = "DropboxClient"
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .build()

    /** 接続テスト。成功時はアカウント表示名、失敗時は "Error: ..."。 */
    fun checkAccount(token: String): String {
        if (token.isBlank()) return "Error: トークン未設定"
        return try {
            val req = Request.Builder()
                .url("https://api.dropboxapi.com/2/users/get_current_account")
                .header("Authorization", "Bearer $token")
                .post("null".toRequestBody("application/json".toMediaType()))
                .build()
            http.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) return "Error: ${resp.code} ${text.take(160)}"
                val name = try { JSONObject(text).getJSONObject("name").getString("display_name") } catch (_: Exception) { "OK" }
                name
            }
        } catch (e: Exception) { "Error: ${e.message}" }
    }

    /** ファイル取得。存在しない/失敗時は null。 */
    fun download(token: String, path: String): ByteArray? {
        return try {
            val arg = JSONObject().put("path", path).toString()
            val req = Request.Builder()
                .url("https://content.dropboxapi.com/2/files/download")
                .header("Authorization", "Bearer $token")
                .header("Dropbox-API-Arg", arg)
                .post(ByteArray(0).toRequestBody(null))
                .build()
            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) { Log.w(TAG, "download ${resp.code}"); return null }
                resp.body?.bytes()
            }
        } catch (e: Exception) { Log.w(TAG, "download failed: ${e.message}"); null }
    }

    /** ファイル保存(上書き)。成功で true。 */
    fun upload(token: String, path: String, bytes: ByteArray, overwrite: Boolean = true): Boolean {
        return try {
            val arg = JSONObject()
                .put("path", path)
                .put("mode", if (overwrite) "overwrite" else "add")
                .put("mute", true)
                .toString()
            val req = Request.Builder()
                .url("https://content.dropboxapi.com/2/files/upload")
                .header("Authorization", "Bearer $token")
                .header("Dropbox-API-Arg", arg)
                .post(bytes.toRequestBody("application/octet-stream".toMediaType()))
                .build()
            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) Log.w(TAG, "upload ${resp.code} ${resp.body?.string()?.take(160)}")
                resp.isSuccessful
            }
        } catch (e: Exception) { Log.w(TAG, "upload failed: ${e.message}"); false }
    }
}
