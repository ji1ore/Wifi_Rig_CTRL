package com.ji1ore.wifi_rig_ctrl

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.ji1ore.wifi_rig_ctrl.data.AppPrefs
import com.ji1ore.wifi_rig_ctrl.data.QsoEntry
import com.ji1ore.wifi_rig_ctrl.data.QsoStore
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * eQSL.cc への ADIF アップロード。送信済み状態は各 QSO の eqslSent フラグで管理し、
 * QSO LIST で送付済み/未送付を表示、未送付分は一括送付できる。
 * - ログ登録ごとの自動送信: enqueueAndSend (連携ON & 資格情報ありのときのみ)
 * - 未送付の一括送信(手動): bulkSendUnsent
 */
object EqslUploader {
    private const val TAG = "EqslUploader"
    private const val URL = "https://www.eqsl.cc/qslcard/ImportADIF.cfm"
    private val main = Handler(Looper.getMainLooper())
    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    fun hasCredentials(prefs: AppPrefs) = prefs.eqslUser.isNotBlank() && prefs.eqslPassword.isNotBlank()

    /** ログ保存直後の自動送信。成功したら当該QSOを送信済みにする。 */
    fun enqueueAndSend(ctx: Context, entry: QsoEntry) {
        val app = ctx.applicationContext
        val prefs = AppPrefs(app)
        if (!prefs.eqslEnabled || !hasCredentials(prefs)) return
        Thread {
            if (sendOne(prefs, entry)) QsoStore.markEqslSent(app, entry.dt, entry.call, true)
        }.start()
    }

    /** 未送付(eqslSent=false)のQSOをまとめて送信。onDone(sent, failed) はメインスレッドで呼ぶ。 */
    fun bulkSendUnsent(ctx: Context, onProgress: ((Int, Int) -> Unit)? = null, onDone: (Int, Int) -> Unit) {
        val app = ctx.applicationContext
        val prefs = AppPrefs(app)
        if (!hasCredentials(prefs)) { main.post { onDone(0, -1) }; return }   // failed=-1: 資格情報なし
        Thread {
            val unsent = QsoStore.load(app).filter { !it.eqslSent }
            var sent = 0; var failed = 0
            unsent.forEachIndexed { i, e ->
                if (sendOne(prefs, e)) { QsoStore.markEqslSent(app, e.dt, e.call, true); sent++ } else failed++
                onProgress?.let { p -> main.post { p(i + 1, unsent.size) } }
            }
            main.post { onDone(sent, failed) }
        }.start()
    }

    private fun buildSingleAdif(entry: QsoEntry, nickname: String): String {
        var adif = QsoStore.buildAdif(listOf(entry))
        val extra = StringBuilder()
        // コメントを eQSL カードの remarks(QSLMSG)として送る
        if (entry.comment.isNotBlank()) extra.append("<QSLMSG:${entry.comment.toByteArray(Charsets.UTF_8).size}>${entry.comment} ")
        if (nickname.isNotBlank()) extra.append("<APP_EQSL_QTH_NICKNAME:${nickname.length}>$nickname ")
        if (extra.isNotEmpty()) adif = adif.replace("<EOR>", "$extra<EOR>")
        return adif
    }

    /** @return 成功(=追加 or 重複)したら true。 */
    private fun sendOne(prefs: AppPrefs, entry: QsoEntry): Boolean {
        return try {
            val adif = buildSingleAdif(entry, prefs.eqslQthNickname)
            val body = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("EQSL_USER", prefs.eqslUser)
                .addFormDataPart("EQSL_PSWD", prefs.eqslPassword)
                .addFormDataPart("Filename", "log.adi",
                    adif.toByteArray(Charsets.UTF_8).toRequestBody("application/octet-stream".toMediaType()))
                .build()
            val req = Request.Builder().url(URL).post(body).header("User-Agent", "WifiRigCTRL").build()
            http.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                // "Result: X out of Y records added" の X を見る(0 out of 1 は失敗)。Duplicate は成功扱い。
                val added = Regex("(\\d+)\\s+out of").find(text)?.groupValues?.getOrNull(1)?.toIntOrNull()
                val ok = resp.isSuccessful && !text.contains("Error:", true) && (
                    text.contains("Duplicate", true) ||
                    (added != null && added > 0) ||
                    (added == null && text.contains("added", true))
                )
                Log.i(TAG, "eQSL ${entry.call} ok=$ok added=$added code=${resp.code} body=${text.take(160)}")
                ok
            }
        } catch (e: Exception) { Log.w(TAG, "eQSL send failed: ${e.message}"); false }
    }
}
