package com.ji1ore.wifi_rig_ctrl

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import com.ji1ore.wifi_rig_ctrl.viewmodel.MainViewModel

/**
 * 現時点で有効な運用地(POTA/SOTA/JCC/JGC)をチェック式で表示・選択する横並びバーの共通描画。
 * メイン画面・FT8・RTTY・CWTX 画面で共通利用する。チェック状態は vm.opSessionDeselected に反映され、
 * ログ登録時の自動タグ付けに引き継がれる。有効な運用地が無いときは scroll を GONE にする。
 */
object OpLocBar {
    fun populate(ctx: Context, scroll: View, container: ViewGroup, vm: MainViewModel) {
        container.removeAllViews()
        val active = vm.activeSessionsAt(System.currentTimeMillis())
        if (active.isEmpty()) { scroll.visibility = View.GONE; return }
        scroll.visibility = View.VISIBLE
        val de = vm.opSessionDeselected.value ?: emptySet()
        container.addView(TextView(ctx).apply {
            text = "運用地:"; textSize = 12f; setTextColor(0xFFAAAAAA.toInt())
            setPadding(0, 0, 8, 0)
        })
        active.forEach { s ->
            container.addView(CheckBox(ctx).apply {
                text = "${s.type} ${s.ref}"; textSize = 12f; setTextColor(0xFFCCCCCC.toInt())
                isChecked = s.id !in de
                setPadding(0, 0, 16, 0)
                setOnCheckedChangeListener { _, checked -> vm.setOpSessionSelected(s.id, checked) }
            })
        }
    }
}
