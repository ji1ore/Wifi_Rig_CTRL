package com.ji1ore.wifi_rig_ctrl

import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.ji1ore.wifi_rig_ctrl.data.OpSession
import com.ji1ore.wifi_rig_ctrl.data.QsoEntry
import com.ji1ore.wifi_rig_ctrl.data.QsoStore
import com.ji1ore.wifi_rig_ctrl.viewmodel.MainViewModel
import java.io.File
import java.util.Calendar
import java.util.TimeZone

class QsoLogFragment : Fragment() {

    private val vm: MainViewModel by activityViewModels()
    private lateinit var listView: ListView
    private lateinit var tvCount: TextView
    private lateinit var btnSelectAll: Button
    private lateinit var btnPeriodSel: Button
    private lateinit var btnDeleteSel: Button
    private lateinit var btnAdifSel: Button
    private lateinit var btnAdifAll: Button
    private lateinit var btnAddLog: Button
    private lateinit var btnSotaChase: Button
    private lateinit var btnOpLocAdif: Button
    private lateinit var btnEqslSend: Button
    private lateinit var btnShlExport: Button

    private var entries: MutableList<QsoEntry> = mutableListOf()
    private val selected = mutableSetOf<Int>()

    // 運用地別ADIF: フォルダを選んでもらい、公園/サミットごとのADIFを一括書き出し
    private var pendingOpLocFiles: List<Pair<String, String>>? = null
    private val pickOpLocDir = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocumentTree()
    ) { treeUri ->
        val files = pendingOpLocFiles
        pendingOpLocFiles = null
        if (treeUri == null || files == null) return@registerForActivityResult
        val resolver = requireContext().contentResolver
        var ok = 0
        try {
            val dirUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(
                treeUri, android.provider.DocumentsContract.getTreeDocumentId(treeUri))
            files.forEach { (name, content) ->
                val fileUri = android.provider.DocumentsContract.createDocument(
                    resolver, dirUri, "application/octet-stream", name)
                if (fileUri != null) {
                    resolver.openOutputStream(fileUri)?.use { it.write(content.toByteArray()) }
                    ok++
                }
            }
        } catch (e: Exception) {
            toast("書き出しに失敗: ${e.message}"); return@registerForActivityResult
        }
        toast("${ok}個のADIFを保存しました")
    }

    // SOTA チェイスログ: 保存先を選んでもらい、保存できたら SOTAData のアップロード画面を開く
    private var pendingSotaCsv: String? = null
    private val saveSotaCsv = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        val csv = pendingSotaCsv
        pendingSotaCsv = null
        if (uri == null || csv == null) return@registerForActivityResult
        try {
            requireContext().contentResolver.openOutputStream(uri)?.use { it.write(csv.toByteArray()) }
        } catch (e: Exception) {
            toast("保存に失敗しました: ${e.message}")
            return@registerForActivityResult
        }
        toast("保存しました。SOTAData でこのファイルを選んでアップロードしてください")
        try {
            startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW,
                android.net.Uri.parse(QsoStore.SOTA_CHASER_UPLOAD_URL)))
        } catch (_: Exception) {
            toast("ブラウザを開けませんでした: ${QsoStore.SOTA_CHASER_UPLOAD_URL}")
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val ctx = requireContext()
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF000000.toInt())
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        // Top toolbar
        val toolbar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 8, 8, 4)
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val btnBack = Button(ctx).apply {
            text = "← 戻る"; textSize = 12f; setPadding(10, 0, 10, 0)
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF37474F.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.marginEnd = 8 }
        }
        tvCount = TextView(ctx).apply {
            textSize = 13f; setTextColor(0xFFCCCCCC.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        btnAddLog = Button(ctx).apply {
            text = "+LOG"; textSize = 11f; setPadding(8, 0, 8, 0)
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF1B5E20.toInt())
            setTextColor(0xFFFFFFFF.toInt())
        }
        toolbar.addView(btnBack); toolbar.addView(tvCount); toolbar.addView(btnAddLog)
        root.addView(toolbar, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        // Selection toolbar. ボタンは均等幅(weight=1)+autosizeで途切れないように。
        fun selButton(txt: String, tint: Int, txtColor: Int) = Button(ctx).apply {
            text = txt; isAllCaps = false; maxLines = 1
            setPadding(2, 0, 2, 0)
            backgroundTintList = android.content.res.ColorStateList.valueOf(tint)
            setTextColor(txtColor)
            androidx.core.widget.TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(
                this, 7, 11, 1, android.util.TypedValue.COMPLEX_UNIT_SP)
            layoutParams = LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also { it.marginStart = 2 }
        }
        btnSelectAll = selButton("全選択",     0xFF37474F.toInt(), 0xFFAAAAAA.toInt())
        btnPeriodSel = selButton("期間選択",   0xFF455A64.toInt(), 0xFFFFFFFF.toInt())
        btnDeleteSel = selButton("削除",       0xFF7A1A1A.toInt(), 0xFFFFFFFF.toInt())
        btnSotaChase = selButton("SOTA送付",   0xFF4E342E.toInt(), 0xFFFFFFFF.toInt())
        btnOpLocAdif = selButton("運用地ADIF", 0xFF33691E.toInt(), 0xFFFFFFFF.toInt())
        btnAdifSel   = selButton("選択ADIF",   0xFF1565C0.toInt(), 0xFFFFFFFF.toInt())
        btnAdifAll   = selButton("全ADIF",     0xFF006064.toInt(), 0xFFFFFFFF.toInt())
        // 選択バーは2段: 上段=選択操作, 下段=エクスポート
        val selRow1 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        selRow1.addView(btnSelectAll); selRow1.addView(btnPeriodSel); selRow1.addView(btnDeleteSel)
        val selRow2 = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.topMargin = 4 }
        }
        selRow2.addView(btnSotaChase); selRow2.addView(btnOpLocAdif); selRow2.addView(btnAdifSel); selRow2.addView(btnAdifAll)
        // 3段目: eQSL 未送付の一括送付 / Smart HAMLOG 未取込のADIF書き出し
        btnEqslSend  = selButton("未送付eQSL送付",   0xFF4527A0.toInt(), 0xFFFFFFFF.toInt())
        btnShlExport = selButton("未連携SHL送信", 0xFF00695C.toInt(), 0xFFFFFFFF.toInt())
        val selRow3 = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.topMargin = 4 }
        }
        selRow3.addView(btnEqslSend); selRow3.addView(btnShlExport)
        val selWrap = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 0, 8, 4) }
        selWrap.addView(selRow1); selWrap.addView(selRow2); selWrap.addView(selRow3)
        root.addView(selWrap, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        // List
        listView = ListView(ctx).apply {
            setBackgroundColor(0xFF0A0A0A.toInt())
            divider = android.graphics.drawable.ColorDrawable(0xFF222222.toInt())
            dividerHeight = 1
        }
        root.addView(listView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // Back button — find it from the toolbar we built in onCreateView
        (view as ViewGroup).let { root ->
            val toolbar = root.getChildAt(0) as? LinearLayout
            (toolbar?.getChildAt(0) as? Button)?.setOnClickListener {
                findNavController().popBackStack()
            }
        }
        reload()
        setupListeners()
    }

    private fun reload() {
        entries = QsoStore.load(requireContext())
        selected.clear()
        refreshAdapter()
        tvCount.text = "${entries.size} QSO"
    }

    private fun refreshAdapter() {
        val ctx = requireContext()
        listView.adapter = object : BaseAdapter() {
            override fun getCount() = entries.size
            override fun getItem(pos: Int) = entries[pos]
            override fun getItemId(pos: Int) = pos.toLong()

            override fun getView(pos: Int, cv: View?, parent: ViewGroup): View {
                val e = entries[pos]
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(8, 6, 8, 6)
                    setBackgroundColor(if (selected.contains(pos)) 0xFF1A2A3A.toInt() else 0xFF0A0A0A.toInt())
                }
                val txt = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val d = e.dt
                val dtUtc = if (d.length >= 12)
                    "${d.take(4)}-${d.drop(4).take(2)}-${d.drop(6).take(2)} ${d.drop(8).take(2)}:${d.drop(10).take(2)}Z"
                else d
                val dtLocal = utcToLocal(d)
                val dtStr = if (dtLocal.isNotEmpty()) "$dtUtc  [$dtLocal]" else dtUtc
                val band = QsoStore.freqToBand(e.freqHz)
                val freq = if (e.freqHz > 0) "%.3f".format(e.freqHz / 1_000_000.0) else "---"
                val tags = buildString {
                    if (e.yourPota.isNotEmpty()) append("  DX:[${e.yourPota}]")
                    if (e.yourSota.isNotEmpty()) append("  DX:[${e.yourSota}]")
                    if (e.myPota.isNotEmpty())   append("  MY:[${e.myPota}]")
                    if (e.mySota.isNotEmpty())   append("  MY:[${e.mySota}]")
                    if (e.jcc.isNotEmpty())      append("  JCC:${e.jcc}")
                    if (e.jgc.isNotEmpty())      append("  JGC:${e.jgc}")
                }
                // Row 1: date/time + callsign (most important — large)
                txt.addView(TextView(ctx).apply {
                    text = dtStr
                    textSize = 12f; setTextColor(0xFF80CBC4.toInt())
                    typeface = android.graphics.Typeface.MONOSPACE
                })
                txt.addView(TextView(ctx).apply {
                    text = e.call
                    textSize = 16f; setTextColor(0xFFFFEB3B.toInt())
                    typeface = android.graphics.Typeface.MONOSPACE
                    android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD).also { typeface = it }
                })
                // Row 2: RST / band / mode  (+ eQSL / Smart HAMLOG 送付状態)
                txt.addView(TextView(ctx).apply {
                    val eqsl = if (e.eqslSent) "  eQSL✓" else "  eQSL—"
                    val shl  = if (e.shlSent)  " SHL✓"   else " SHL—"
                    text = "S:${e.rstSent}  R:${e.rstRcvd}  $band/${e.mode}  $freq MHz$eqsl$shl"
                    textSize = 12f; setTextColor(0xFFAAAAAA.toInt())
                    typeface = android.graphics.Typeface.MONOSPACE
                })
                // Row 3: awards/tags
                if (tags.isNotEmpty()) {
                    txt.addView(TextView(ctx).apply {
                        text = tags.trim(); textSize = 11f; setTextColor(0xFF76FF03.toInt())
                    })
                }
                // Row 4: comment
                if (e.comment.isNotEmpty()) {
                    txt.addView(TextView(ctx).apply {
                        text = e.comment; textSize = 11f; setTextColor(0xFF888888.toInt())
                    })
                }
                row.addView(txt)
                val cbk = CheckBox(ctx).apply {
                    isChecked = selected.contains(pos)
                    buttonTintList = android.content.res.ColorStateList.valueOf(0xFF4499FF.toInt())
                    isFocusable = false
                    isClickable = false
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT)
                }
                row.addView(cbk)
                return row
            }
        }
        listView.setOnItemClickListener { _, _, pos, _ ->
            if (selected.contains(pos)) selected.remove(pos) else selected.add(pos)
            refreshAdapter()
        }
        listView.setOnItemLongClickListener { _, _, pos, _ ->
            showEditDialog(pos)
            true
        }
    }

    /** 期間でQSOを選択。UTC/ローカル切替可。範囲内のdtを選択状態にする。 */
    private fun showPeriodSelectDialog() {
        val ctx = requireContext()
        fun dp(n: Int) = (n * ctx.resources.displayMetrics.density + 0.5f).toInt()
        val utcTz = java.util.TimeZone.getTimeZone("UTC")
        val localTz = java.util.TimeZone.getDefault()
        // 絶対時刻(epoch ms)で保持し、表示はトグルのtzで整形。既定: 開始=今日0時UTC, 終了=現在。
        val nowMs = System.currentTimeMillis()
        var startMs = java.util.Calendar.getInstance(utcTz).apply {
            timeInMillis = nowMs
            set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
        }.timeInMillis
        var endMs = nowMs

        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        val sw = android.widget.Switch(ctx).apply { text = "UTC 表示 (OFFでローカル)"; isChecked = true; setTextColor(0xFFCCCCCC.toInt()) }
        val startBtn = Button(ctx); val endBtn = Button(ctx)
        fun curTz() = if (sw.isChecked) utcTz else localTz
        fun fmt(ms: Long): String {
            val c = java.util.Calendar.getInstance(curTz()); c.timeInMillis = ms
            return String.format("%04d/%02d/%02d %02d:%02d%s",
                c.get(java.util.Calendar.YEAR), c.get(java.util.Calendar.MONTH) + 1, c.get(java.util.Calendar.DAY_OF_MONTH),
                c.get(java.util.Calendar.HOUR_OF_DAY), c.get(java.util.Calendar.MINUTE), if (sw.isChecked) "Z" else "L")
        }
        fun upd() { startBtn.text = "開始: ${fmt(startMs)}"; endBtn.text = "終了: ${fmt(endMs)}" }
        fun pick(ms: Long, onSet: (Long) -> Unit) {
            val tz = curTz()
            val c = java.util.Calendar.getInstance(tz); c.timeInMillis = ms
            android.app.DatePickerDialog(ctx, { _, y, mo, d ->
                android.app.TimePickerDialog(ctx, { _, h, mi ->
                    val cc = java.util.Calendar.getInstance(tz); cc.clear(); cc.set(y, mo, d, h, mi, 0)
                    onSet(cc.timeInMillis)
                }, c.get(java.util.Calendar.HOUR_OF_DAY), c.get(java.util.Calendar.MINUTE), true).show()
            }, c.get(java.util.Calendar.YEAR), c.get(java.util.Calendar.MONTH), c.get(java.util.Calendar.DAY_OF_MONTH)).show()
        }
        sw.setOnCheckedChangeListener { _, _ -> upd() }   // トグルで表記を切替(同じ絶対時刻をtz変換)
        startBtn.setOnClickListener { pick(startMs) { startMs = it; upd() } }
        endBtn.setOnClickListener { pick(endMs) { endMs = it; upd() } }
        upd()
        box.addView(sw); box.addView(startBtn); box.addView(endBtn)

        android.app.AlertDialog.Builder(ctx)
            .setTitle("期間でQSOを選択")
            .setView(box)
            .setPositiveButton("選択") { _, _ ->
                val lo = minOf(startMs, endMs); val hi = maxOf(startMs, endMs)
                selected.clear()
                entries.forEachIndexed { i, q ->
                    val qms = parseUtcDtMs(q.dt.padEnd(14, '0').take(14))
                    if (qms in lo..hi) selected.add(i)
                }
                refreshAdapter()
                toast("${selected.size}件を選択しました")
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun wallToMs(dt: String, tz: java.util.TimeZone): Long = try {
        java.text.SimpleDateFormat("yyyyMMddHHmmss", java.util.Locale.US).apply { timeZone = tz; isLenient = true }
            .parse(dt.padEnd(14, '0'))?.time ?: System.currentTimeMillis()
    } catch (_: Exception) { System.currentTimeMillis() }

    private fun msToWall(ms: Long, tz: java.util.TimeZone): String =
        java.text.SimpleDateFormat("yyyyMMddHHmmss", java.util.Locale.US).apply { timeZone = tz }.format(java.util.Date(ms))

    /** "yyyyMMddHHmmss"(UTC) を epoch ms に。失敗時は現在時刻。 */
    private fun parseUtcDtMs(dt: String): Long = try {
        val c = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
        c.clear()
        c.set(dt.substring(0, 4).toInt(), dt.substring(4, 6).toInt() - 1, dt.substring(6, 8).toInt(),
              dt.substring(8, 10).toInt(), dt.substring(10, 12).toInt(), dt.substring(12, 14).toInt())
        c.timeInMillis
    } catch (_: Exception) { System.currentTimeMillis() }

    private fun showEditDialog(pos: Int) {
        val ctx = requireContext()
        val e = entries[pos]
        fun dp(n: Int) = (n * ctx.resources.displayMetrics.density + 0.5f).toInt()

        fun field(hint: String, init: String): EditText = EditText(ctx).apply {
            this.hint = hint; setText(init)
            setHintTextColor(0xFF505050.toInt()); setTextColor(0xFFCCCCCC.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF333333.toInt())
            textSize = 16f; setSingleLine(true); setPadding(dp(8), dp(8), dp(8), dp(8))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.topMargin = dp(6) }
        }
        fun lbl(t: String) = TextView(ctx).apply {
            text = t; textSize = 12f; setTextColor(0xFF777777.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.topMargin = dp(10) }
        }

        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        root.addView(lbl("日時 (UTC  yyyyMMdd / HHmmss)"))
        val dtRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val etEditDate = field("yyyyMMdd", e.dt.take(8)).also {
            it.inputType = android.text.InputType.TYPE_CLASS_NUMBER
            it.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also { lp -> lp.topMargin = dp(6) }
        }; dtRow.addView(etEditDate)
        val etEditTime = field("HHmmss", e.dt.drop(8)).also {
            it.inputType = android.text.InputType.TYPE_CLASS_NUMBER
            it.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also { lp -> lp.topMargin = dp(6); lp.marginStart = dp(8) }
        }; dtRow.addView(etEditTime)
        root.addView(dtRow)
        // UTC/ローカル 修正モード切替
        var editDtLocal = false
        val swEditLocal = android.widget.Switch(ctx).apply {
            text = "ローカルで修正 (OFF=UTC)"; isChecked = false
            setTextColor(0xFFAAAAAA.toInt()); textSize = 13f
        }
        root.addView(swEditLocal)
        swEditLocal.setOnCheckedChangeListener { _, checked ->
            val cur = (etEditDate.text.toString() + etEditTime.text.toString()).padEnd(14, '0').take(14)
            val utc = java.util.TimeZone.getTimeZone("UTC"); val loc = java.util.TimeZone.getDefault()
            val ms = wallToMs(cur, if (editDtLocal) loc else utc)
            editDtLocal = checked
            val w = msToWall(ms, if (editDtLocal) loc else utc)
            etEditDate.setText(w.take(8)); etEditTime.setText(w.drop(8))
        }
        root.addView(lbl("DX Callsign"))
        val etCall = field("JA2ABC", e.call).also {
            it.setTextColor(0xFFFFEB3B.toInt())
            it.backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF1A237E.toInt())
            it.filters = arrayOf(android.text.InputFilter { src, _, _, _, _, _ ->
                src.toString().uppercase().filter { c -> c.isLetter() && c.code < 128 || c.isDigit() && c.code < 128 || c == '/' }
            })
        }; root.addView(etCall)
        root.addView(lbl("RST 送信 / 受信"))
        val rstRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val etRstS = field("送信", e.rstSent).also {
            it.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also { lp -> lp.topMargin = dp(6) }
        }; rstRow.addView(etRstS)
        val etRstR = field("受信", e.rstRcvd).also {
            it.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also { lp -> lp.topMargin = dp(6); lp.marginStart = dp(8) }
        }; rstRow.addView(etRstR)
        root.addView(rstRow)
        root.addView(lbl("Your POTA / Your SOTA (相手)"))
        val yourPotaRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val etYourPota = field("JP-XXXX", e.yourPota).also {
            it.setTextColor(0xFF80CBC4.toInt())
            it.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also { lp -> lp.topMargin = dp(6) }
        }; yourPotaRow.addView(etYourPota)
        val etYourSota = field("JA/NN-001", e.yourSota).also {
            it.setTextColor(0xFF80CBC4.toInt())
            it.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also { lp -> lp.topMargin = dp(6); lp.marginStart = dp(8) }
        }; yourPotaRow.addView(etYourSota)
        root.addView(yourPotaRow)
        // 相手局 GL / QTH (HAMLOG GL / QTH 欄へ)
        root.addView(lbl("GL / QTH (相手)"))
        val dxRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val etDxGl = field("PM95", e.dxGrid).also {
            it.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also { lp -> lp.topMargin = dp(6) }
        }; dxRow.addView(etDxGl)
        val etDxQth = field("QTH", e.qth).also {
            it.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also { lp -> lp.topMargin = dp(6); lp.marginStart = dp(8) }
        }; dxRow.addView(etDxQth)
        root.addView(dxRow)
        root.addView(lbl("My POTA / My SOTA (自分)"))
        val myPotaRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val etMyPota = field("JP-XXXX", e.myPota).also {
            it.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also { lp -> lp.topMargin = dp(6) }
        }; myPotaRow.addView(etMyPota)
        val etMySota = field("JA/NN-001", e.mySota).also {
            it.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also { lp -> lp.topMargin = dp(6); lp.marginStart = dp(8) }
        }; myPotaRow.addView(etMySota)
        root.addView(myPotaRow)
        root.addView(lbl("運用場所 Location (My Parkマルチロケ等)"))
        val etMyLoc = field("地点名", e.myLoc); root.addView(etMyLoc)

        // 運用地の選び直し(この交信の時刻でアクティブな運用地をチェックで反映)
        var editJcc = e.jcc
        var editJgc = e.jgc
        run {
            val qsoMs = parseUtcDtMs(e.dt.padEnd(14, '0').take(14))
            val active = vm.activeSessionsAt(qsoMs)
            if (active.isNotEmpty()) {
                val potaSet = e.myPota.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
                val checks = LinkedHashMap<OpSession, android.widget.CheckBox>()
                fun applySessions() {
                    val on = checks.filter { it.value.isChecked }.keys
                    if (active.any { it.type == "POTA" }) etMyPota.setText(on.filter { it.type == "POTA" }.joinToString(",") { it.ref })
                    if (active.any { it.type == "SOTA" }) etMySota.setText(on.firstOrNull { it.type == "SOTA" }?.ref ?: "")
                    if (active.any { it.type == "JCC" }) editJcc = on.firstOrNull { it.type == "JCC" }?.ref ?: ""
                    if (active.any { it.type == "JGC" }) editJgc = on.firstOrNull { it.type == "JGC" }?.ref ?: ""
                }
                root.addView(lbl("運用地 (チェックで My POTA/SOTA/JCC を選び直し・2ferは複数POTA)"))
                active.forEach { s ->
                    val checkedNow = when (s.type) {
                        "POTA" -> s.ref in potaSet
                        "SOTA" -> e.mySota.trim() == s.ref
                        "JCC"  -> e.jcc.trim() == s.ref
                        "JGC"  -> e.jgc.trim() == s.ref
                        else   -> false
                    }
                    val cb = android.widget.CheckBox(ctx).apply {
                        text = "${s.type}  ${s.ref}" + if (s.label.isNotEmpty()) " (${s.label})" else ""
                        setTextColor(0xFFCCCCCC.toInt()); isChecked = checkedNow
                    }
                    checks[s] = cb; root.addView(cb)
                }
                checks.values.forEach { it.setOnCheckedChangeListener { _, _ -> applySessions() } }
            }
        }

        root.addView(lbl("コメント"))
        val etComment = field("", e.comment); root.addView(etComment)

        root.addView(lbl("QSL"))
        val qslLabels = arrayOf("空白", "JARL", "hQSL", "No", "Card", "1-Way")
        val qslCodes  = arrayOf("", "J", "H", "N", "C", "1")
        val qslSpinner = android.widget.Spinner(ctx).apply {
            adapter = android.widget.ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, qslLabels)
            setSelection(qslCodes.indexOf(e.qsl).coerceAtLeast(0))
        }
        root.addView(qslSpinner)

        // 連携状態(チェックを外して保存すると未送信に戻せる)
        root.addView(lbl("連携状態 (チェックを外して保存で未送信に戻す)"))
        val cbEqsl = CheckBox(ctx).apply { text = "eQSL 送信済み"; setTextColor(0xFFFFFFFF.toInt()); isChecked = e.eqslSent }
        val cbShl  = CheckBox(ctx).apply { text = "Smart HAMLOG 連携済み"; setTextColor(0xFFFFFFFF.toInt()); isChecked = e.shlSent }
        root.addView(cbEqsl); root.addView(cbShl)

        fun doEditSave() {
            val updated = e.copy(
                dt       = run {
                    val raw = (etEditDate.text.toString().trim() + etEditTime.text.toString().trim())
                        .padEnd(14, '0').take(14)
                    if (editDtLocal) msToWall(wallToMs(raw, java.util.TimeZone.getDefault()),
                        java.util.TimeZone.getTimeZone("UTC")) else raw
                },
                call     = etCall.text.toString().trim().uppercase().ifEmpty { e.call },
                rstSent  = etRstS.text.toString().trim().ifEmpty { e.rstSent },
                rstRcvd  = etRstR.text.toString().trim().ifEmpty { e.rstRcvd },
                yourPota = etYourPota.text.toString().trim().uppercase(),
                yourSota = etYourSota.text.toString().trim().uppercase(),
                myPota   = etMyPota.text.toString().trim().uppercase(),
                mySota   = etMySota.text.toString().trim().uppercase(),
                jcc      = editJcc,
                jgc      = editJgc,
                comment  = etComment.text.toString().trim(),
                eqslSent = cbEqsl.isChecked,
                shlSent  = cbShl.isChecked,
                qsl      = qslCodes.getOrElse(qslSpinner.selectedItemPosition) { "" },
                dxGrid   = etDxGl.text.toString().trim().uppercase(),
                qth      = etDxQth.text.toString().trim(),
                myLoc    = etMyLoc.text.toString().trim()
            )
            entries[pos] = updated
            QsoStore.save(requireContext(), entries)
            vm.prefs.ft8QsoLog = buildJsonArray(entries)
            refreshAdapter()
            toast("保存しました: ${updated.call}")
        }

        // ヘッダに タイトル + キャンセル/保存(キーボードで隠れないよう上固定)
        val btnEditCancel = Button(ctx).apply { text = "キャンセル"; isAllCaps = false }
        val btnEditSave = Button(ctx).apply { text = "保存"; isAllCaps = false }
        val editHeader = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(6), dp(8), dp(6))
            addView(TextView(ctx).apply {
                text = "QSO 修正: ${e.call}"; setTextColor(0xFFFFFFFF.toInt()); textSize = 16f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(btnEditCancel); addView(btnEditSave)
        }
        val editOuter = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(editHeader, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(ScrollView(ctx).apply { addView(root); isVerticalScrollBarEnabled = false },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        val dlg = android.app.AlertDialog.Builder(ctx, android.R.style.Theme_Material_Dialog_NoActionBar)
            .setView(editOuter)
            .create()
        btnEditSave.setOnClickListener { doEditSave(); dlg.dismiss() }
        btnEditCancel.setOnClickListener { dlg.dismiss() }
        dlg.window?.apply {
            setBackgroundDrawableResource(android.R.color.background_dark)
            setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        dlg.setOnShowListener {
            // ヘッダ固定＋本文スクロールのため高さは MATCH_PARENT(weight配下のScrollViewが潰れないように)
            dlg.window?.setLayout(
                (ctx.resources.displayMetrics.widthPixels * 0.95).toInt(),
                android.view.WindowManager.LayoutParams.MATCH_PARENT
            )
        }
        dlg.show()
    }

    private fun setupListeners() {
        btnAddLog.setOnClickListener {
            LogQsoDialogFragment.newInstance().show(parentFragmentManager, "log_qso")
        }

        parentFragmentManager.setFragmentResultListener("log_qso_done", viewLifecycleOwner) { _, _ ->
            reload()
        }

        btnSelectAll.setOnClickListener {
            if (selected.size == entries.size) {
                selected.clear()
            } else {
                selected.addAll(entries.indices)
            }
            refreshAdapter()
        }

        btnPeriodSel.setOnClickListener { showPeriodSelectDialog() }

        btnDeleteSel.setOnClickListener {
            if (selected.isEmpty()) { toast("削除する項目を選択してください"); return@setOnClickListener }
            android.app.AlertDialog.Builder(requireContext())
                .setMessage("選択した ${selected.size} 件を削除しますか?")
                .setPositiveButton("削除") { _, _ ->
                    val keep = entries.filterIndexed { i, _ -> !selected.contains(i) }
                    QsoStore.save(requireContext(), keep)
                    vm.prefs.ft8QsoLog = buildJsonArray(keep)
                    reload()
                }
                .setNegativeButton("キャンセル", null).show()
        }

        btnAdifSel.setOnClickListener {
            if (selected.isEmpty()) { toast("エクスポートする項目を選択してください"); return@setOnClickListener }
            val sel = selected.sorted().map { entries[it] }
            shareAdif(sel)
        }

        btnAdifAll.setOnClickListener {
            if (entries.isEmpty()) { toast("ログが空です"); return@setOnClickListener }
            shareAdif(entries)
        }

        btnSotaChase.setOnClickListener {
            if (selected.isEmpty()) { toast("送付する項目を選択してください"); return@setOnClickListener }
            sendSotaChaser(selected.sorted().map { entries[it] })
        }
        btnOpLocAdif.setOnClickListener {
            if (selected.isEmpty()) { toast("ADIFを作成する項目を選択してください"); return@setOnClickListener }
            exportOpLocAdif(selected.sorted().map { entries[it] })
        }
        btnEqslSend.setOnClickListener { sendUnsentEqsl() }
        btnShlExport.setOnClickListener { sendUnsentSmartHamLog() }
    }

    /** Smart HAMLOG 未連携(shlSent=false)のQSOを Cloudlog API でまとめて送信。 */
    private fun sendUnsentSmartHamLog() {
        val ctx = requireContext()
        val unsent = entries.count { !it.shlSent }
        if (unsent == 0) { toast("未連携(Smart HAMLOG)のQSOはありません"); return }
        if (!SmartHamLogSync.hasServer(com.ji1ore.wifi_rig_ctrl.data.AppPrefs(ctx))) {
            toast("リグ選択画面の設定で Smart HAMLOG のサーバーアドレス/APIキーを設定してください"); return
        }
        android.app.AlertDialog.Builder(ctx)
            .setTitle("Smart HAMLOG 一括送信")
            .setMessage("未連携 $unsent 件を Smart HAMLOG へ送信します。よろしいですか?")
            .setPositiveButton("送信") { _, _ ->
                btnShlExport.isEnabled = false; btnShlExport.text = "送信中…"
                SmartHamLogSync.bulkSend(ctx,
                    onProgress = { done, total -> btnShlExport.text = "送信中… $done/$total" },
                    onDone = { sent, failed ->
                        btnShlExport.isEnabled = true; btnShlExport.text = "未連携SHL送信"
                        toast(if (failed <= 0) "Smart HAMLOG送信完了: $sent 件" else "送信: 成功 $sent / 失敗 $failed")
                        reload()
                    })
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    /** 未送付(eqslSent=false)のQSOを eQSL へ一括送付する。 */
    private fun sendUnsentEqsl() {
        val ctx = requireContext()
        val unsent = entries.count { !it.eqslSent }
        if (unsent == 0) { toast("未送付のQSOはありません"); return }
        if (!EqslUploader.hasCredentials(com.ji1ore.wifi_rig_ctrl.data.AppPrefs(ctx))) {
            toast("リグ選択画面の『eQSL/Smart Ham Log 設定』でユーザー名/パスワードを設定してください"); return
        }
        android.app.AlertDialog.Builder(ctx)
            .setTitle("eQSL 一括送付")
            .setMessage("未送付 $unsent 件を eQSL へ送付します。よろしいですか?")
            .setPositiveButton("送付") { _, _ ->
                btnEqslSend.isEnabled = false
                btnEqslSend.text = "送付中…"
                EqslUploader.bulkSendUnsent(ctx,
                    onProgress = { done, total -> btnEqslSend.text = "送付中… $done/$total" },
                    onDone = { sent, failed ->
                        btnEqslSend.isEnabled = true
                        btnEqslSend.text = "未送付eQSL送付"
                        toast(if (failed <= 0) "eQSL送付完了: $sent 件" else "eQSL送付: 成功 $sent / 失敗 $failed")
                        reload()
                    })
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    /** 選択交信を My POTA(カンマ分解=公園ごと) / My SOTA(サミットごと) にグループ分けし、
     *  ref ごとに1 ADIF を作ってフォルダへ一括保存する。2ferは各公園ファイルへ重複出力。 */
    private fun exportOpLocAdif(list: List<QsoEntry>) {
        fun sanitize(s: String) = s.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val potaMap = LinkedHashMap<String, MutableList<QsoEntry>>()
        val sotaMap = LinkedHashMap<String, MutableList<QsoEntry>>()
        list.forEach { e ->
            e.myPota.split(",").map { it.trim() }.filter { it.isNotEmpty() }.forEach { p ->
                potaMap.getOrPut(p) { mutableListOf() }.add(e.copy(myPota = p))
            }
            val s = e.mySota.trim()
            if (s.isNotEmpty()) sotaMap.getOrPut(s) { mutableListOf() }.add(e.copy(mySota = s))
        }
        if (potaMap.isEmpty() && sotaMap.isEmpty()) {
            toast("My POTA / My SOTA が付いた交信がありません"); return
        }
        val files = mutableListOf<Pair<String, String>>()
        potaMap.forEach { (ref, es) -> files.add("POTA_${sanitize(ref)}.adi" to QsoStore.buildAdif(es)) }
        sotaMap.forEach { (ref, es) -> files.add("SOTA_${sanitize(ref)}.adi" to QsoStore.buildAdif(es)) }
        pendingOpLocFiles = files
        val summary = buildString {
            append("作成するファイル: ${files.size}個\n")
            if (potaMap.isNotEmpty()) append("POTA: ${potaMap.keys.joinToString(", ")}\n")
            if (sotaMap.isNotEmpty()) append("SOTA: ${sotaMap.keys.joinToString(", ")}\n")
            append("\n保存先フォルダを選んでください。")
        }
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("運用地別ADIF")
            .setMessage(summary)
            .setPositiveButton("フォルダを選ぶ") { _, _ -> pickOpLocDir.launch(null) }
            .setNegativeButton("キャンセル") { _, _ -> pendingOpLocFiles = null }
            .show()
    }

    /** 選択した交信から SOTA チェイスログ(CSV V2)を作り、確認後に保存 → SOTAData を開く */
    private fun sendSotaChaser(list: List<QsoEntry>) {
        val r = QsoStore.buildSotaChaserCsv(list)
        val msg = buildString {
            append("チェイスとして送付: ${r.included}件")
            if (r.skippedNoRef > 0) append("\n除外(相手局のSOTA番号なし): ${r.skippedNoRef}件")
            if (r.skippedActivator > 0) append("\n除外(自局SOTA番号あり=アクティベーター交信): ${r.skippedActivator}件")
            if (r.skippedInvalid > 0) append("\n除外(自局コール・日時・周波数の不足): ${r.skippedInvalid}件")
            if (r.included > 0) append("\n\nCSVファイルを保存したあと、ブラウザでSOTADataのチェイサー用アップロード画面を開きます。画面でそのファイルを選んでアップロードしてください。")
        }
        val b = android.app.AlertDialog.Builder(requireContext())
            .setTitle(if (r.included > 0) "SOTAチェイスログを送付" else "送付できる交信がありません")
            .setMessage(msg)
        if (r.included > 0) {
            b.setPositiveButton("保存してSOTADataを開く") { _, _ ->
                pendingSotaCsv = r.csv
                val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
                saveSotaCsv.launch("sota_chase_%04d%02d%02d_%02d%02d.csv".format(
                    cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH),
                    cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE)))
            }
            b.setNegativeButton("キャンセル", null)
        } else {
            b.setPositiveButton("OK", null)
        }
        b.show()
    }

    private fun shareAdif(list: List<QsoEntry>) {
        val adif = QsoStore.buildAdif(list)
        val cal  = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        val fname = "qso_%04d%02d%02d.adi".format(
            cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
        val file = File(requireContext().cacheDir, fname)
        file.writeText(adif)
        val uri = FileProvider.getUriForFile(requireContext(), "${requireContext().packageName}.provider", file)
        startActivity(android.content.Intent.createChooser(
            android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                putExtra(android.content.Intent.EXTRA_SUBJECT, fname)
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "Share ADIF"))
    }

    private fun buildJsonArray(list: List<QsoEntry>): String {
        val arr = org.json.JSONArray()
        list.forEach { arr.put(it.toJson()) }
        return arr.toString()
    }

    private fun utcToLocal(dt: String): String {
        if (dt.length < 8) return ""
        return try {
            val sdf = java.text.SimpleDateFormat("yyyyMMddHHmmss", java.util.Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            val date = sdf.parse(dt.padEnd(14, '0')) ?: return ""
            val local = java.text.SimpleDateFormat("MM/dd HH:mm", java.util.Locale.getDefault()).apply {
                timeZone = TimeZone.getDefault()
            }
            local.format(date)
        } catch (_: Exception) { "" }
    }

    private fun toast(msg: String) =
        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()

    override fun onResume() {
        super.onResume()
        reload()
    }
}
