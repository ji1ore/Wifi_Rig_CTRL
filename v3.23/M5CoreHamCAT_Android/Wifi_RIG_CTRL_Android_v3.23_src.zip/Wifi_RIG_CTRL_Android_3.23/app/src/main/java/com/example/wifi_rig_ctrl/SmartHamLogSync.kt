package com.ji1ore.wifi_rig_ctrl

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.ji1ore.wifi_rig_ctrl.data.AppPrefs
import com.ji1ore.wifi_rig_ctrl.data.QsoEntry
import com.ji1ore.wifi_rig_ctrl.data.QsoStore
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Smart HAMLOG 連携(FT8アプリ連携 = Cloudlog API 方式)。
 * Smart HAMLOG の [設定]→「FT8TW/Greyline連携」で表示される サーバーアドレス と APIキー を使い、
 * Cloudlog 互換エンドポイント POST <server>/index.php/api/qso に1交信ずつ ADIF を送る。
 * 重複は Smart HAMLOG 側で自動チェック。.hdb 反映は Smart HAMLOG が行うため、アプリは .hdb を触らない。
 * 連携ON かつ サーバー/APIキー設定ありのときのみ動作。
 */
object SmartHamLogSync {
    private const val TAG = "SmartHamLogSync"
    private val main = Handler(Looper.getMainLooper())
    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    fun isConfigured(prefs: AppPrefs) =
        prefs.smartHamLogEnabled && prefs.shlCloudlogUrl.isNotBlank() && prefs.shlApiKey.isNotBlank()

    fun hasServer(prefs: AppPrefs) = prefs.shlCloudlogUrl.isNotBlank() && prefs.shlApiKey.isNotBlank()

    /** ログ保存直後の自動連携。成功で当該QSOを連携済み(shlSent)に。 */
    fun autoUpload(ctx: Context, entry: QsoEntry) {
        val app = ctx.applicationContext
        val prefs = AppPrefs(app)
        if (!isConfigured(prefs)) return
        Thread {
            if (sendOne(prefs, entry)) QsoStore.markShlSent(app, listOf(entry.dt to entry.call), true)
        }.start()
    }

    /** 未連携(shlSent=false)をまとめて送信。onDone(sent, failed) はメインスレッド。failed=-1 は未設定。 */
    fun bulkSend(ctx: Context, onProgress: ((Int, Int) -> Unit)? = null, onDone: (Int, Int) -> Unit) {
        val app = ctx.applicationContext
        val prefs = AppPrefs(app)
        if (!hasServer(prefs)) { main.post { onDone(0, -1) }; return }
        Thread {
            val unsent = QsoStore.load(app).filter { !it.shlSent }
            var sent = 0; var failed = 0
            unsent.forEachIndexed { i, e ->
                if (sendOne(prefs, e)) { QsoStore.markShlSent(app, listOf(e.dt to e.call), true); sent++ } else failed++
                onProgress?.let { p -> main.post { p(i + 1, unsent.size) } }
            }
            main.post { onDone(sent, failed) }
        }.start()
    }

    /** 接続テスト: GET <base>/api/auth/<key> でキーの有効性を確認(Smart HAMLOG bridge仕様)。
     *  有効キーは <auth><message>Key Valid...</message></auth> を返す。 */
    fun checkAuth(url: String, key: String, sid: String = "1"): String {
        if (url.isBlank() || key.isBlank()) return "Error: サーバー/APIキー未設定"
        val endpoint = "${baseUrl(url)}/api/auth/${java.net.URLEncoder.encode(key, "UTF-8")}"
        return try {
            val req = Request.Builder().url(endpoint).get().header("User-Agent", "WifiRigCTRL").build()
            http.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                val msg = Regex("<message>(.*?)</message>", RegexOption.DOT_MATCHES_ALL)
                    .find(text)?.groupValues?.getOrNull(1)?.trim() ?: text.take(120)
                when {
                    resp.code == 404 -> "Error: 404 (エンドポイント不明)\n呼出先: $endpoint"
                    text.contains("Valid", true) && !text.contains("Invalid", true) -> "接続OK: $msg"
                    else -> "Error: $msg"
                }
            }
        } catch (e: Exception) { "Error: ${e.message}\n呼出先: $endpoint" }
    }

    // qso エンドポイント = <base>/api/qso (Smart HAMLOG bridge は /index.php を使わない)
    private fun qsoEndpoint(raw: String): String = "${baseUrl(raw)}/api/qso"

    // 貼られた値が末尾にパスを含んでいても正規化してベースURLを得る
    private fun baseUrl(raw: String): String {
        var u = raw.trim().trimEnd('/')
        for (s in listOf("/index.php/api/qso", "/api/qso", "/api/auth", "/index.php")) u = u.removeSuffix(s).trimEnd('/')
        return u
    }

    private fun recordOnly(adif: String): String {
        val i = adif.indexOf("<EOH>")
        return if (i >= 0) adif.substring(adif.indexOf("\n", i).let { if (it < 0) i + 5 else it + 1 }).trim() else adif.trim()
    }

    private fun sendOne(prefs: AppPrefs, entry: QsoEntry): Boolean {
        return try {
            val adifRec = recordOnly(QsoStore.buildAdif(listOf(entry)))
            val payload = JSONObject()
                .put("key", prefs.shlApiKey)
                .put("station_profile_id", prefs.shlStationId.ifBlank { "1" })
                .put("type", "adif")
                .put("string", adifRec)
                .toString()
            val req = Request.Builder()
                .url(qsoEndpoint(prefs.shlCloudlogUrl))
                .post(payload.toRequestBody("application/json".toMediaType()))
                .header("User-Agent", "WifiRigCTRL")
                .build()
            http.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                // failed / error / too long / invalid / missing を含むと失敗(レコード拒否)とみなす。
                val bad = listOf("failed", "error", "too long", "invalid", "missing", "authentication")
                    .any { text.contains(it, true) }
                val ok = resp.isSuccessful && !bad
                Log.i(TAG, "SHL(Cloudlog) ${entry.call} ok=$ok code=${resp.code} body=${text.take(200)}")
                ok
            }
        } catch (e: Exception) { Log.w(TAG, "SHL send failed: ${e.message}"); false }
    }
}
