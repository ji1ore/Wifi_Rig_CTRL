package com.ji1ore.wifi_rig_ctrl.data

import android.util.Log

/**
 * JNI binding to mfsk-core (the same Rust FT8/FT4 decoder the Pi uses), built via cargo-ndk into
 * libmfsk_jni.so. Used by the CI-V local engine for higher-quality (depth-based) weak-signal
 * decoding than the bundled ft8_lib (Ft8Jni). Encoding still uses Ft8Jni.
 */
object MfskJni {
    private const val TAG = "MfskJni"

    val isAvailable: Boolean = try {
        System.loadLibrary("mfsk_jni")
        true
    } catch (e: Throwable) {
        Log.w(TAG, "libmfsk_jni not available: ${e.message}")
        false
    }

    /** depth: 1=Fast, 2=Normal, 3=Deep (more SIC rounds, better weak-signal yield, more CPU). */
    fun decode(
        samples: ShortArray,
        rate: Int,
        freqMin: Float = 100f,
        freqMax: Float = 3000f,
        isFt4: Boolean = false,
        depth: Int = 2,
    ): List<String> {
        if (!isAvailable) return emptyList()
        return try {
            nativeDecode(samples, rate, freqMin, freqMax, if (isFt4) 1 else 0, depth).toList()
        } catch (e: Throwable) {
            Log.e(TAG, "decode failed: ${e.message}")
            emptyList()
        }
    }

    @JvmStatic
    private external fun nativeDecode(
        samples: ShortArray, rate: Int,
        freqMin: Float, freqMax: Float,
        isFt4: Int, depth: Int,
    ): Array<String>
}
