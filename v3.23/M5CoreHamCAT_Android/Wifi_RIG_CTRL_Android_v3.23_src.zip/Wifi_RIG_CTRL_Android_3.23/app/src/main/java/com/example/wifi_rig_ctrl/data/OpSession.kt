package com.ji1ore.wifi_rig_ctrl.data

/**
 * 運用セッション(アクティベーション運用地)。POTA/SOTAアクティベーター向け。
 * ある時間帯に、ある運用地(JCC/JGC/SOTA/POTA)で運用していたことを表す。
 *
 * 重複規則:
 *  - JCC / JGC / SOTA は時間重複不可(同時に成立しないため)
 *  - POTA は時間重複可(2fer/n-fer: 同時に複数公園を運用できる)
 *
 * QSO時刻が [startMs, endMs] に入るセッションを「その交信の運用地候補」として扱う。
 * endMs==0 は「運用中(終了未確定)」とみなし、startMs 以降すべてを対象にする。
 */
data class OpSession(
    val id: String,
    val type: String,       // "JCC" | "JGC" | "SOTA" | "POTA"
    val ref: String,        // JCCコード / JGCコード / SOTAサミット(JA/XX-000) / POTA番号(JA-0000)
    val startMs: Long,      // epoch millis
    val endMs: Long,        // epoch millis, 0 = 運用中(open-ended)
    val label: String = "", // 任意メモ(地名など)
    val gl: String = ""     // この運用地の自局GL(グリッドロケーター)。ログの MY GL 既定に使う
) {
    fun activeAt(t: Long): Boolean = t >= startMs && (endMs == 0L || t <= endMs)

    /** JCC/JGC/SOTA は相互に時間重複不可。POTA は重複可。 */
    val isExclusive: Boolean get() = type == "JCC" || type == "JGC" || type == "SOTA"

    /** 2つの時間帯が重なるか(endMs==0 は無限大として扱う)。 */
    fun overlaps(other: OpSession): Boolean {
        val aEnd = if (endMs == 0L) Long.MAX_VALUE else endMs
        val bEnd = if (other.endMs == 0L) Long.MAX_VALUE else other.endMs
        return startMs <= bEnd && other.startMs <= aEnd
    }

    companion object {
        val TYPES = listOf("JCC", "JGC", "SOTA", "POTA")
    }
}
