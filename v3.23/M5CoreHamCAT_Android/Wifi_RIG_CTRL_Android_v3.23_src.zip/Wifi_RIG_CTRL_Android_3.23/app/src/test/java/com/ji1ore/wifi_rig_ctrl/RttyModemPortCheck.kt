package com.ji1ore.wifi_rig_ctrl

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.sin

/**
 * Checks the RTTY modem against the published ITA2 assignments and against waveforms built
 * from standard code numbers, so it verifies interoperability with other stations rather
 * than only self-consistency. Mirrors the checks run on the iOS port.
 */
class RttyModemPortCheck {

    private val std = mapOf(
        'E' to 1, 'A' to 3, 'S' to 5, 'I' to 6, 'U' to 7, 'D' to 9, 'R' to 10, 'J' to 11,
        'N' to 12, 'F' to 13, 'C' to 14, 'K' to 15, 'T' to 16, 'Z' to 17, 'L' to 18,
        'W' to 19, 'H' to 20, 'Y' to 21, 'P' to 22, 'Q' to 23, 'O' to 24, 'B' to 25,
        'G' to 26, 'M' to 28, 'X' to 29, 'V' to 30
    )
    private val SP = 4
    private val LTRS = 31
    private val FIGS = 27

    /** Waveform built from explicit code numbers, independent of the modem's own tables. */
    private fun wave(
        codes: List<Int>, rate: Int, baud: Double,
        mark: Double = 2125.0, space: Double = 2295.0,
        noise: Double = 0.0, leadSamples: Int = 0
    ): ShortArray {
        val spb = (rate / baud).toInt()
        val stop = (spb * 1.5).toInt()
        val out = ArrayList<Short>()
        repeat(leadSamples) { out.add(0) }
        var phase = 0.0
        val rnd = java.util.Random(12345)
        fun tone(isMark: Boolean, n: Int) {
            val d = 2.0 * PI * (if (isMark) mark else space) / rate
            repeat(n) {
                var v = sin(phase) * 0.6
                if (noise > 0) v += (rnd.nextDouble() * 2.0 - 1.0) * noise
                out.add((v.coerceIn(-1.0, 1.0) * 32767).toInt().toShort())
                phase += d
            }
        }
        tone(true, spb * 3)
        for (c in codes) {
            tone(false, spb)
            for (b in 0 until 5) tone((c shr b) and 1 == 1, spb)
            tone(true, stop)
        }
        tone(true, spb * 3)
        return out.toShortArray()
    }

    private fun decode(pcm: ShortArray, rate: Int, baud: Double = 45.45): String {
        val sb = StringBuilder()
        val rx = RttyModem(rate, 2125.0, 2295.0, baud) { sb.append(it) }
        rx.feed(pcm)
        return sb.toString()
    }

    private fun codesFor(text: String): List<Int> {
        val out = ArrayList<Int>()
        out.add(LTRS)
        for (ch in text) out.add(if (ch == ' ') SP else std.getValue(ch))
        return out
    }

    @Test
    fun letterTableMatchesPublishedIta2() {
        val expected = charArrayOf(
            ' ', 'E', '\n', 'A', ' ', 'S', 'I', 'U',
            '\r', 'D', 'R', 'J', 'N', 'F', 'C', 'K',
            'T', 'Z', 'L', 'W', 'H', 'Y', 'P', 'Q',
            'O', 'B', 'G', ' ', 'M', 'X', 'V', ' '
        )
        for (i in 0 until 32) {
            assertEquals("letter code $i", expected[i], RttyModem.LTRS[i])
        }
        assertEquals(27, RttyModem.FIGS_SHIFT)
        assertEquals(31, RttyModem.LTRS_SHIFT)
    }

    @Test
    fun decodesWaveformBuiltFromStandardCodes() {
        val text = "CQ CQ DE TOKYO VY FB K"
        for (rate in listOf(8000, 16000, 22050, 44100)) {
            val got = decode(wave(codesFor(text), rate, 45.45), rate)
            assertEquals("rate $rate", text, got)
        }
    }

    @Test
    fun decodesDespiteNoise() {
        val text = "CQ DE TOKYO K"
        for (noise in listOf(0.0, 0.05, 0.15, 0.30)) {
            val got = decode(wave(codesFor(text), 16000, 45.45, noise = noise), 16000)
            assertEquals("noise $noise", text, got)
        }
    }

    /** The old decoder sampled on a free-running half-bit tick, so the result depended on
     *  where the character happened to land in the sample stream. */
    @Test
    fun decodeIsIndependentOfSignalTimingOffset() {
        val text = "CQ DE TOKYO K"
        for (lead in listOf(0, 11, 22, 44, 88, 131, 176, 263)) {
            val got = decode(wave(codesFor(text), 16000, 45.45, leadSamples = lead), 16000)
            assertEquals("offset $lead", text, got)
        }
    }

    /** A figures shift invented by noise must not garble the rest of the transmission. */
    @Test
    fun unshiftsOnSpaceAfterStrayFiguresShift() {
        val codes = ArrayList<Int>()
        codes.add(FIGS)
        for (ch in "ICOM ICOM K") codes.add(if (ch == ' ') SP else std.getValue(ch))
        val got = decode(wave(codes, 16000, 45.45), 16000)
        assertTrue("should recover after the first space, got '$got'",
                   got.endsWith("ICOM K"))
    }

    @Test
    fun decodesFiguresSentAfterASpace() {
        val codes = ArrayList<Int>()
        codes.add(LTRS)
        for (ch in "RST") codes.add(std.getValue(ch))
        codes.addAll(listOf(SP, FIGS, 16, 24, 24, SP, LTRS))   // "599 "
        for (ch in "QTH") codes.add(std.getValue(ch))
        assertEquals("RST 599 QTH", decode(wave(codes, 16000, 45.45), 16000))
    }

    @Test
    fun encoderRoundTripsIncludingSpacesAndFigures() {
        val msg = "RST 599 QTH TOKYO DE JA1ABC K"
        for (rate in listOf(8000, 16000, 44100)) {
            val tx = RttyModem(rate, RttyModem.TX_MARK_HZ, RttyModem.TX_SPACE_HZ, 45.45) { }
            val sb = StringBuilder()
            val rx = RttyModem(rate, RttyModem.TX_MARK_HZ, RttyModem.TX_SPACE_HZ, 45.45) {
                sb.append(it)
            }
            rx.feed(tx.encode(msg))
            assertEquals("rate $rate", msg, sb.toString())
        }
    }

    /**
     * The sender's baud is slightly off nominal (crystal tolerance, soundcard drift). The
     * continuous matched filter schedules bit decisions on the exact fractional bit period, so
     * the sampling instant stays centred across the character even when the signal runs fast or
     * slow relative to the 45.45 the decoder expects.
     */
    @Test
    fun decodesSlightBaudMismatch() {
        val text = "CQ DE TOKYO K"
        for (baud in listOf(44.8, 45.0, 45.45, 45.9, 46.1)) {
            val got = decode(wave(codesFor(text), 16000, baud), 16000, 45.45)
            assertEquals("tx baud $baud", text, got)
        }
    }

    /** Fractional samples-per-bit ratios must not accumulate a timing error across a character. */
    @Test
    fun decodesAtFractionalSamplesPerBit() {
        val text = "CQ DE TOKYO VY FB HR K"   // letters and spaces only (codesFor has no figures)
        // 11025/45.45 = 242.6, 22050/45.45 = 485.1, 32000/45.45 = 704.1 — all non-integer.
        for (rate in listOf(11025, 22050, 32000)) {
            val got = decode(wave(codesFor(text), rate, 45.45), rate)
            assertEquals("rate $rate", text, got)
        }
    }

    /** Sub-sample edge interpolation should decode at every signal offset, not just coarse ones. */
    @Test
    fun decodesAtEverySubSampleOffset() {
        val text = "CQ DE TOKYO K"
        for (lead in 0..32) {
            val got = decode(wave(codesFor(text), 12000, 45.45, leadSamples = lead), 12000)
            assertEquals("offset $lead", text, got)
        }
    }

    /** Matched filter + sub-sample timing should hold up at a noise level that garbles a
     *  coarsely-timed slicer. */
    @Test
    fun decodesAtHigherNoise() {
        val text = "CQ DE TOKYO K"
        for (noise in listOf(0.40, 0.55)) {
            val got = decode(wave(codesFor(text), 16000, 45.45, noise = noise), 16000)
            assertEquals("noise $noise", text, got)
        }
    }

    /** "UR 599 599 BK" (RST×2) — two figures groups separated by a space must both decode. */
    @Test
    fun decodesRepeatedFiguresGroups() {
        for (rate in listOf(8000, 16000)) {
            val tx = RttyModem(rate, RttyModem.TX_MARK_HZ, RttyModem.TX_SPACE_HZ, 45.45) { }
            val sb = StringBuilder()
            val rx = RttyModem(rate, RttyModem.TX_MARK_HZ, RttyModem.TX_SPACE_HZ, 45.45) { sb.append(it) }
            rx.feed(tx.encode("UR 599 599 BK"))
            assertEquals("rate $rate", "UR 599 599 BK", sb.toString())
        }
    }

    /** TX×2: the same message sent twice (two encodes) must both decode in full. */
    @Test
    fun decodesMessageSentTwice() {
        val rate = 16000
        val tx = RttyModem(rate, RttyModem.TX_MARK_HZ, RttyModem.TX_SPACE_HZ, 45.45) { }
        val sb = StringBuilder()
        val rx = RttyModem(rate, RttyModem.TX_MARK_HZ, RttyModem.TX_SPACE_HZ, 45.45) { sb.append(it) }
        val once = tx.encode("UR 599 BK")
        rx.feed(once); rx.feed(once)
        assertEquals("UR 599 BKUR 599 BK", sb.toString())
    }

    /** Transmission must not inherit the receive side's auto-tuned tones. */
    @Test
    fun transmitTonesAreTheFixedStandardPair() {
        assertEquals(2125.0, RttyModem.TX_MARK_HZ, 0.0)
        assertEquals(2295.0, RttyModem.TX_SPACE_HZ, 0.0)

        // RYRY is the classic RTTY tuning pattern — R=01010, Y=10101 alternate mark/space on
        // every bit, so a window inside the data carries both tones in equal measure. Scan there,
        // not in the leading mark idle (which would show mark alone) and not across the whole
        // message (whose disjoint mark/space segments make a single long Goertzel unreliable).
        val tx = RttyModem(8000, RttyModem.TX_MARK_HZ, RttyModem.TX_SPACE_HZ, 45.45) { }
        val pcm = tx.encode("RYRYRYRY")
        val win = pcm.copyOfRange(8000, 12000)      // 0.5–1.5 s in, well inside the RYRY data
        val powers = RttyModem.scanPowers(win, win.size, 8000)
        val top = powers.indices.sortedByDescending { powers[it] }.take(2)
            .map { RttyModem.SCAN_LO + it * RttyModem.SCAN_STEP }.sorted()
        // Within one scan bin (20 Hz) of 2125 / 2295 — a modulated RYRY signal spreads a little
        // into the neighbouring bin, so pin the frequencies to the standard pair, not exact bins.
        assertTrue("mark tone ~2125, got $top",  top[0] in 2100..2140)
        assertTrue("space tone ~2295, got $top", top[1] in 2280..2320)
    }
}
