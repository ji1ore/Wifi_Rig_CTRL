package com.ji1ore.wifi_rig_ctrl

/**
 * Central feature flags.
 *
 * MEMSET_SOTA_ENABLED: MEM SET（メモリ/スポット画面）の SOTA タブを一時的に無効化するためのフラグ。
 *   false にすると MEM SET の SOTA タブ（SOTA スポット一覧）だけを隠す。
 *   ※ ログ機能（LOG QSO の SOTA 欄・ログ編集・SOTA送付・ADIF 等）や FT8 の SOTA、
 *      運用地の SOTA 種別、SP2ALART の SOTA 取り込みは従来どおり有効のまま。
 *   あくまで一時的な措置で、true に戻すだけで MEM SET の SOTA タブを再表示できる。
 */
object FeatureFlags {
    const val MEMSET_SOTA_ENABLED = false
}
