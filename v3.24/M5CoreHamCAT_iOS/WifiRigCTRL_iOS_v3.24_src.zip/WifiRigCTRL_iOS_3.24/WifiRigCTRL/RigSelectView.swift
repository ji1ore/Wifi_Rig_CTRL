import SwiftUI

struct RigSelectView: View {
    @Bindable var vm: MainViewModel
    @State private var localError: String?
    @State private var backupStatus: String?
    // RTTY AUTO 自動追従の最大ずれ(Hz)。RttyView と同じキーを共有。
    @AppStorage("rttyAutoTuneOffsetHz") private var rttyAutoTuneOffsetHz = 500

    private var audioCaptureName: String {
        guard !vm.selectedAudioCapture.isEmpty else { return "Default" }
        return vm.selectedAudioCapture
    }
    private var audioPlaybackName: String {
        guard !vm.selectedAudioPlayback.isEmpty else { return "Same as SPK/TX" }
        return vm.selectedAudioPlayback
    }
    private var sampleRateLabel: String {
        // Guard against an out-of-range index (stale profile) — avoids a crash that
        // would leave this pushed screen blank/black.
        guard AppConstants.samplingRates.indices.contains(vm.selectedSamplingIndex) else { return "Off" }
        let r = AppConstants.samplingRates[vm.selectedSamplingIndex]
        return r == 0 ? "Off" : "\(r) Hz"
    }

    var body: some View {
        Form {
            Section(header: Label("Rig Model", systemImage: "antenna.radiowaves.left.and.right").foregroundStyle(.indigo)) {
                if vm.rigList.isEmpty {
                    Text("No rigs returned by server").foregroundStyle(.secondary)
                } else {
                    Picker("Rig Model", selection: $vm.selectedRigIndex) {
                        ForEach(vm.rigList.indices, id: \.self) { i in
                            Text(vm.rigList[i].name).tag(i)
                        }
                    }
                }
            }

            Section(header: Label("CAT Device", systemImage: "cable.connector").foregroundStyle(.teal)) {
                if vm.catList.isEmpty {
                    Text("No serial devices").foregroundStyle(.secondary)
                } else {
                    Picker("CAT Device", selection: $vm.selectedCatIndex) {
                        ForEach(vm.catList.indices, id: \.self) { i in
                            Text(vm.catList[i]).tag(i)
                        }
                    }
                }
                Picker("Baud Rate", selection: $vm.selectedBaudIndex) {
                    ForEach(AppConstants.baudRates.indices, id: \.self) { i in
                        Text(String(AppConstants.baudRates[i])).tag(i)
                    }
                }
            }

            Section(header: Label("PTT", systemImage: "dot.radiowaves.left.and.right").foregroundStyle(.red)) {
                Picker("PTT Device", selection: $vm.selectedPttDevice) {
                    Text("NONE").tag("NONE")
                    ForEach(vm.catList, id: \.self) { name in
                        Text(name).tag(name)
                    }
                }
                Picker("PTT Type", selection: $vm.selectedPttType) {
                    ForEach(PttType.allCases, id: \.self) { t in
                        Text(t.displayName).tag(t)
                    }
                }
            }

            Section {
                if vm.soundDeviceList.isEmpty {
                    Text("No audio devices").foregroundStyle(.secondary)
                } else {
                    Picker("SPK / TX", selection: $vm.selectedAudioCapture) {
                        Text("Default").tag("")
                        ForEach(vm.soundDeviceList) { d in
                            VStack(alignment: .leading, spacing: 1) {
                                Text(d.id)
                                Text(d.label).font(.caption2).foregroundStyle(.secondary)
                            }.tag(d.id)
                        }
                    }
                    Picker("FT8", selection: $vm.selectedAudioPlayback) {
                        Text("Same as SPK/TX").tag("")
                        ForEach(vm.soundDeviceList) { d in
                            VStack(alignment: .leading, spacing: 1) {
                                Text(d.id)
                                Text(d.label).font(.caption2).foregroundStyle(.secondary)
                            }.tag(d.id)
                        }
                    }
                }
                Picker("Sample Rate", selection: $vm.selectedSamplingIndex) {
                    ForEach(AppConstants.samplingRates.indices, id: \.self) { i in
                        let r = AppConstants.samplingRates[i]
                        Text(r == 0 ? "Off" : "\(r) Hz").tag(i)
                    }
                }
            } header: {
                Label("Audio", systemImage: "waveform").foregroundStyle(.cyan)
            } footer: {
                VStack(alignment: .leading, spacing: 2) {
                    if !vm.soundDeviceList.isEmpty {
                        Label("SPK/TX: \(audioCaptureName)", systemImage: "speaker.wave.2")
                        Label("FT8: \(audioPlaybackName)", systemImage: "waveform.badge.mic")
                    }
                    Label("Rate: \(sampleRateLabel)", systemImage: "metronome")
                }
                .font(.caption)
            }

            Section("自局コール (My Call)") {
                HStack {
                    TextField("JA1XXX", text: $vm.ft8MyCall)
                        .textInputAutocapitalization(.characters).autocorrectionDisabled()
                        .onChange(of: vm.ft8MyCall) { _, v in
                            vm.ft8MyCall = v.uppercased()
                            vm.loadEqslForCurrentCall()   // コールに紐づくeQSLアカウントへ切替
                        }
                        .onSubmit { vm.addMyCall(vm.ft8MyCall); vm.persistFt8Settings() }
                    if !vm.myCallHistory.isEmpty {
                        Menu {
                            ForEach(vm.myCallHistory, id: \.self) { c in
                                Button(c) { vm.ft8MyCall = c; vm.loadEqslForCurrentCall(); vm.persistFt8Settings() }
                            }
                        } label: { Image(systemName: "chevron.down.circle") }
                    }
                }
            }

            Section(header: Label("RTTY AUTO Offset", systemImage: "waveform.path").foregroundStyle(.green)) {
                Stepper(value: $rttyAutoTuneOffsetHz, in: 50...950, step: 50) {
                    Text("±\(rttyAutoTuneOffsetHz) Hz")
                }
                Text("RTTYの自動追従で補正する最大ずれ。大きいほど離れた信号も追うが、近くの別信号を拾いやすい (推奨 500)")
                    .font(.caption).foregroundStyle(.secondary)
            }

            Section("外部連携 (QSL自動送信)") {
                Toggle("eQSL連携 (ログ登録ごとに自動送信)", isOn: $vm.eqslEnabled)
                    .onChange(of: vm.eqslEnabled) { _, _ in vm.persistIntegrationSettings() }
                Toggle("Smart Ham Log連携", isOn: $vm.smartHamLogEnabled)
                    .onChange(of: vm.smartHamLogEnabled) { _, _ in vm.persistIntegrationSettings() }
                Toggle("PSKReporter連携 (FT8受信レポート送信)", isOn: $vm.pskrEnabled)
                    .onChange(of: vm.pskrEnabled) { _, v in vm.setPskReporter(v) }
                Button {
                    vm.path.append(.integrationSettings)
                } label: { Label("eQSL / Smart Ham Log 設定…", systemImage: "gearshape") }
            }

            // QSO Log 一覧(自局コール設定後にここで管理)。コールサイン無しではeQSL/SHL連携の
            // 管理ができないため、接続画面からこの画面へ移設。
            Section(header: Label("QSO Log", systemImage: "note.text").foregroundStyle(.orange)) {
                Button {
                    vm.path.append(.qsoLog)
                } label: {
                    HStack {
                        Label("LOG 一覧", systemImage: "list.bullet.rectangle.portrait")
                            .foregroundStyle(.orange)
                        Spacer()
                        let count = QsoStore.load().count
                        if count > 0 {
                            Text("\(count)件")
                                .font(.caption.monospacedDigit())
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }

            Section {
                if BackupStore.isAvailable {
                    Button {
                        backupStatus = BackupStore.save() ? "iCloud に保存しました" : "保存に失敗しました"
                    } label: { Label("今すぐ iCloud に保存", systemImage: "icloud.and.arrow.up") }
                    Button {
                        backupStatus = BackupStore.restore()
                            ? "復元しました。反映にはアプリを再起動してください"
                            : "復元に失敗しました(バックアップが無い可能性があります)"
                    } label: { Label("iCloud から復元", systemImage: "icloud.and.arrow.down") }
                    if let s = backupStatus {
                        Text(s).font(.caption).foregroundStyle(.secondary)
                    }
                } else {
                    Label("iCloud にサインインすると利用できます", systemImage: "icloud.slash")
                        .foregroundStyle(.secondary)
                }
            } header: {
                Label("バックアップ (iCloud)", systemImage: "icloud").foregroundStyle(.blue)
            } footer: {
                Text("設定と QSO ログを iCloud Drive に保存します。認証情報(パスワード・API キー)は含まれません。再インストール後は自動で復元されます。")
                    .font(.caption)
            }

            Section {
                Button {
                    Task { await open() }
                } label: {
                    HStack {
                        if vm.isBusy { ProgressView().padding(.trailing, 4) }
                        Text(vm.isBusy ? "Connecting…" : "Open Rig")
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(vm.isBusy || vm.rigList.isEmpty)
            }

            if let msg = localError {
                Section { Text(msg).foregroundStyle(.red).font(.callout) }
            }

            if vm.piVersionMismatch {
                Section {
                    Label("Pi API version mismatch — update via UPDATE", systemImage: "exclamationmark.triangle.fill")
                        .foregroundStyle(.red)
                        .font(.callout)
                }
            }
            #if DEBUG
            Section(header: Label("Debug", systemImage: "ladybug.fill").foregroundStyle(.orange)) {
                Button {
                    vm.isConnectedToRig = true
                    vm.path.append(.mainControl)
                } label: {
                    Label("Skip to Main Control", systemImage: "forward.fill")
                }
                .foregroundStyle(.orange)
            }
            #endif
        }
        .navigationTitle(Text("Select Rig"))
        .onAppear {
            // Start polling immediately so version-mismatch warnings are visible on first display.
            // Skip if polling was suppressed by auto-disconnect (Pi unreachable) — will resume
            // when the user explicitly opens a rig (openSelectedRig calls startStatusPolling).
            if !vm.demoMode && !vm.useCivMode && !vm.pollSuppressed {
                vm.startStatusPolling()
            }
        }
        .onChange(of: vm.selectedRigIndex) { _, _ in vm.persistSelections() }
        .onChange(of: vm.selectedCatIndex) { _, _ in vm.persistSelections() }
        .onChange(of: vm.selectedBaudIndex) { _, _ in vm.persistSelections() }
        .onChange(of: vm.selectedSamplingIndex) { _, _ in vm.persistSelections() }
        .onChange(of: vm.selectedPttDevice) { _, _ in vm.persistSelections() }
        .onChange(of: vm.selectedPttType) { _, _ in vm.persistSelections() }
        .onChange(of: vm.selectedAudioCapture) { _, _ in vm.persistSelections() }
        .onChange(of: vm.selectedAudioPlayback) { _, _ in vm.persistSelections() }
    }

    private func open() async {
        localError = nil
        if let err = await vm.openSelectedRig() {
            localError = err
        } else {
            vm.path.append(.mainControl)
        }
    }
}
