package com.ji1ore.wifi_rig_ctrl

import android.Manifest
import android.annotation.SuppressLint
import android.app.Dialog
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.activityViewModels
import com.ji1ore.wifi_rig_ctrl.data.JccTable
import com.ji1ore.wifi_rig_ctrl.data.OpSession
import com.ji1ore.wifi_rig_ctrl.data.QsoEntry
import com.ji1ore.wifi_rig_ctrl.data.QsoStore
import com.ji1ore.wifi_rig_ctrl.viewmodel.MainViewModel
import java.util.Locale

class LogQsoDialogFragment : DialogFragment() {

    private val vm: MainViewModel by activityViewModels()

    /// ダイアログを閉じるとき(Close/戻る/外タップ)に入力を下書き保存するフック。onCreateDialog で設定。
    private var onDismissDraft: (() -> Unit)? = null

    override fun onDismiss(dialog: android.content.DialogInterface) {
        onDismissDraft?.invoke()
        super.onDismiss(dialog)
    }

    companion object {
        private const val ARG_CALLSIGN = "callsign"
        private const val ARG_POTA     = "pota"
        private const val ARG_SOTA     = "sota"
        private const val ARG_RST_S    = "rstS"
        private const val ARG_RST_R    = "rstR"
        private const val ARG_FREQ     = "freqHzOverride"
        private const val ARG_MODE     = "modeOverride"

        fun newInstance(
            callsign: String = "",
            pota: String = "",
            sota: String = "",
            rstSent: String = "",
            rstRcvd: String = "",
            freqHzOverride: Long = 0L,  // >0 なら sharedFreq の代わりにこの周波数で記録(RTTYのAFSK補正用)
            modeOverride: String = ""   // 空でなければ sharedMode(リグのLSB/USB)の代わりにこのモードで記録(RTTYのAFSK補正用)
        ) = LogQsoDialogFragment().apply {
            arguments = Bundle().apply {
                putString(ARG_CALLSIGN, callsign)
                putString(ARG_POTA, pota)
                putString(ARG_SOTA, sota)
                putString(ARG_RST_S, rstSent)
                putString(ARG_RST_R, rstRcvd)
                putLong(ARG_FREQ, freqHzOverride)
                putString(ARG_MODE, modeOverride)
            }
        }
    }

    /** "yyyyMMddHHmmss"(UTC) を epoch ms に変換。失敗時は現在時刻。 */
    private fun parseUtcDtMs(dt: String): Long = try {
        val c = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
        c.clear()
        c.set(dt.substring(0, 4).toInt(), dt.substring(4, 6).toInt() - 1, dt.substring(6, 8).toInt(),
              dt.substring(8, 10).toInt(), dt.substring(10, 12).toInt(), dt.substring(12, 14).toInt())
        c.timeInMillis
    } catch (_: Exception) { System.currentTimeMillis() }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val ctx = requireContext()
        val args = arguments ?: Bundle()
        val initCall = args.getString(ARG_CALLSIGN, "").ifEmpty { vm.pendingLogCallsign }
        // POTA/SOTA は iOS と同様、明示引数が空なら pendingLog(MEMSETスポット/SP2Alert)から補完する。
        // 以前は「明示引数のみ、pendingLogからは使わない」としていたため、MEMSET の POTA スポットから
        // 遷移しても LOG に POTA が入らなかった。callsign と同じフォールバックに統一(保存時にpendingはクリア)。
        var initPota = args.getString(ARG_POTA, "").ifEmpty { vm.pendingLogPota }
        val initSota = args.getString(ARG_SOTA, "").ifEmpty { vm.pendingLogSota }
        // CW TX 等で相手POTAが渡されていなくても、相手局がPOTAスポットで判明していれば自動補完する
        // (相手の公園情報が入らない不具合を修正)。
        if (initPota.isEmpty() && initCall.isNotEmpty()) {
            val base = initCall.uppercase().substringBefore("/")
            val refs = (vm.potaActivatorMap[base] ?: emptyList())
                .map { it.reference }.filter { it.isNotEmpty() }.distinct()
            if (refs.isNotEmpty()) initPota = refs.joinToString(",")
        }
        val initRstS = args.getString(ARG_RST_S, "")
        val initRstR = args.getString(ARG_RST_R, "")

        val freqHz = args.getLong(ARG_FREQ, 0L).takeIf { it > 0L } ?: (vm.sharedFreq.value ?: 0L)
        // RTTY 等、リグが LSB/USB(AFSK) でもログは RTTY で記録したいケースで modeOverride を渡す。
        val mode   = args.getString(ARG_MODE, "").orEmpty().ifEmpty { vm.sharedMode.value ?: "" }
        val myCall = vm.prefs.ft8MyCall
        // My GL(ADIF MY_GRIDSQUARE)は6桁優先(SOTA等)。6桁が無ければ FT8用4桁で代用。
        val myGrid = vm.prefs.myGrid6.ifEmpty { vm.prefs.ft8MyGrid }

        val freqMhz = if (freqHz > 0) "%.4f MHz".format(freqHz / 1_000_000.0) else "---"
        val band    = QsoStore.freqToBand(freqHz)
        val isCw     = mode.startsWith("CW", ignoreCase = true)
        val isRtty   = mode.equals("RTTY", ignoreCase = true) || mode.equals("RTTYR", ignoreCase = true)
        val isFtRtty = mode.startsWith("FT")
        val defaultRst = when { isCw || isRtty -> "599"; isFtRtty -> "-00"; else -> "59" }

        // ─── helpers ──────────────────────────────────────────────────────────

        fun dp(n: Int) = (n * ctx.resources.displayMetrics.density + 0.5f).toInt()

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(16))
        }

        fun label(text: String) = TextView(ctx).apply {
            this.text = text; textSize = 13f
            setTextColor(0xFF777777.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.topMargin = dp(10) }
        }

        fun editText(hint: String, init: String = "", numOnly: Boolean = false): EditText =
            EditText(ctx).apply {
                this.hint = hint; setText(init)
                setHintTextColor(0xFF505050.toInt()); setTextColor(0xFFCCCCCC.toInt())
                backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF333333.toInt())
                textSize = 16f; setSingleLine(true)
                setPadding(dp(8), dp(8), dp(8), dp(8))
                inputType = if (numOnly) InputType.TYPE_CLASS_NUMBER
                else InputType.TYPE_CLASS_TEXT or
                        InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or
                        InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                layoutParams = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

        fun clearBtn(target: EditText) = Button(ctx).apply {
            text = "×"; textSize = 12f; setPadding(0, 0, 0, 0)
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF444444.toInt())
            setTextColor(0xFFAAAAAA.toInt())
            layoutParams = LinearLayout.LayoutParams(dp(28), dp(36)).also { it.marginStart = dp(3) }
            setOnClickListener { target.text.clear(); target.requestFocus() }
        }

        fun hrow(vararg views: View) = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.bottomMargin = dp(2) }
            views.forEach { addView(it) }
        }

        // RST selector rows — returns views to add to root
        fun rstSelectorViews(target: EditText): List<View> {
            val views = mutableListOf<View>()
            val selTint   = 0xFF1B5E20.toInt()
            val unselTint = 0xFF263238.toInt()

            fun presetRow(values: List<String>, height: Int = dp(34)) = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    .also { it.topMargin = dp(3); it.bottomMargin = dp(2) }
                val btns = Array<Button?>(values.size) { null }
                values.forEachIndexed { i, v ->
                    val btn = Button(ctx).apply {
                        text = v; textSize = 12f; setPadding(0, 0, 0, 0)
                        backgroundTintList = android.content.res.ColorStateList.valueOf(unselTint)
                        setTextColor(0xFF80CBC4.toInt())
                        layoutParams = LinearLayout.LayoutParams(0, height, 1f)
                            .also { if (i > 0) it.marginStart = dp(2) }
                        setOnClickListener {
                            btns.forEach { b -> b?.backgroundTintList = android.content.res.ColorStateList.valueOf(unselTint) }
                            backgroundTintList = android.content.res.ColorStateList.valueOf(selTint)
                            target.setText(v)
                        }
                    }
                    btns[i] = btn; addView(btn)
                }
            }

            if (isCw || isRtty) {
                views += presetRow((1..9).map { "5${it}9" })
                return views
            }

            if (isFtRtty) {
                views += presetRow(listOf("-20", "-15", "-10", "-05", "00", "+05", "+10"), dp(32))
                return views
            }

            // SSB: 51〜59
            views += presetRow((1..9).map { "5$it" })
            return views
        }

        // ─── Freq / mode / myCall ────────────────────────────────────────────

        root.addView(TextView(ctx).apply {
            text = "$freqMhz  $band  $mode   MY: ${myCall.ifEmpty { "(not set)" }}"
            textSize = 14f; setTextColor(0xFF00E5FF.toInt()); setPadding(0, 0, 0, dp(4))
        })

        // ─── Date / Time (UTC) ───────────────────────────────────────────────

        val utcTz = java.util.TimeZone.getTimeZone("UTC")
        val localTz = java.util.TimeZone.getDefault()
        var dtLocal = false   // false=UTC入力, true=ローカル入力
        fun wallToMs(dt: String, tz: java.util.TimeZone): Long = try {
            java.text.SimpleDateFormat("yyyyMMddHHmmss", Locale.US).apply { timeZone = tz; isLenient = true }
                .parse(dt.padEnd(14, '0'))?.time ?: System.currentTimeMillis()
        } catch (_: Exception) { System.currentTimeMillis() }
        fun msToWall(ms: Long, tz: java.util.TimeZone): String =
            java.text.SimpleDateFormat("yyyyMMddHHmmss", Locale.US).apply { timeZone = tz }.format(java.util.Date(ms))
        // 入力中の時刻を反対TZで表示(UTC入力中→Local、ローカル入力中→UTC)
        fun otherTzLabel(dt: String): String {
            if (dt.length < 8) return ""
            val ms = wallToMs(dt.padEnd(14, '0').take(14), if (dtLocal) localTz else utcTz)
            val toTz = if (dtLocal) utcTz else localTz
            val lbl = if (dtLocal) "UTC" else "Local"
            return "$lbl: ${java.text.SimpleDateFormat("MM/dd HH:mm", Locale.getDefault()).apply { timeZone = toTz }.format(java.util.Date(ms))}"
        }

        val nowUtc = QsoEntry.utcNow()
        root.addView(label("日時 (yyyyMMdd  HHmmss)"))
        val etDate = EditText(ctx).apply {
            setText(nowUtc.take(8)); hint = "yyyyMMdd"
            setHintTextColor(0xFF505050.toInt()); setTextColor(0xFFFFFFFF.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF333333.toInt())
            textSize = 16f; setSingleLine(true); setPadding(dp(8), dp(8), dp(8), dp(8))
            inputType = InputType.TYPE_CLASS_NUMBER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val etTime = EditText(ctx).apply {
            setText(nowUtc.drop(8)); hint = "HHmmss"
            setHintTextColor(0xFF505050.toInt()); setTextColor(0xFFFFFFFF.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF333333.toInt())
            textSize = 16f; setSingleLine(true); setPadding(dp(8), dp(8), dp(8), dp(8))
            inputType = InputType.TYPE_CLASS_NUMBER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        root.addView(hrow(etDate, clearBtn(etDate), etTime, clearBtn(etTime)))

        val tvLocalTime = TextView(ctx).apply {
            text = otherTzLabel(nowUtc)
            textSize = 12f; setTextColor(0xFF888888.toInt())
            setPadding(dp(4), 0, 0, dp(2))
        }
        val swDtLocal = android.widget.Switch(ctx).apply {
            text = "ローカルで入力/修正 (OFF=UTC)"; isChecked = false
            setTextColor(0xFFAAAAAA.toInt()); textSize = 13f
        }
        root.addView(swDtLocal)
        root.addView(tvLocalTime)
        val dtWatcher = object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                tvLocalTime.text = otherTzLabel(etDate.text.toString() + etTime.text.toString())
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        }
        etDate.addTextChangedListener(dtWatcher)
        etTime.addTextChangedListener(dtWatcher)
        swDtLocal.setOnCheckedChangeListener { _, checked ->
            // 同じ絶対時刻のまま入力TZを切替(表示も入力値も変換)
            val cur = (etDate.text.toString() + etTime.text.toString()).padEnd(14, '0').take(14)
            val ms = wallToMs(cur, if (dtLocal) localTz else utcTz)
            dtLocal = checked
            val w = msToWall(ms, if (dtLocal) localTz else utcTz)
            etDate.setText(w.take(8)); etTime.setText(w.drop(8))
        }

        // ─── DX callsign ─────────────────────────────────────────────────────

        root.addView(label("DX Callsign"))
        val etCall = EditText(ctx).apply {
            hint = "JA2ABC/1"; setText(initCall)
            setHintTextColor(0xFF555555.toInt()); setTextColor(0xFFFFEB3B.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF1A237E.toInt())
            textSize = 18f; setSingleLine(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            inputType = InputType.TYPE_CLASS_TEXT or
                    InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS or
                    InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            imeOptions = EditorInfo.IME_FLAG_FORCE_ASCII or EditorInfo.IME_ACTION_NEXT
            isFocusableInTouchMode = true
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            filters = arrayOf(android.text.InputFilter { source, _, _, _, _, _ ->
                source.toString().uppercase()
                    .filter { it.isLetter() && it.code < 128 || it.isDigit() && it.code < 128 || it == '/' }
            })
        }
        root.addView(hrow(etCall, clearBtn(etCall)))

        // ─── RST Sent ────────────────────────────────────────────────────────

        root.addView(label("RST 送信"))
        val etRstS = EditText(ctx).apply {
            hint = defaultRst; setText(initRstS.ifEmpty { defaultRst })
            setHintTextColor(0xFF505050.toInt()); setTextColor(0xFFFFFFFF.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF333333.toInt())
            textSize = 20f; setSingleLine(true); setPadding(dp(10), dp(8), dp(10), dp(8))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        root.addView(hrow(etRstS, clearBtn(etRstS)))
        rstSelectorViews(etRstS).forEach { root.addView(it) }

        // ─── RST Rcvd ────────────────────────────────────────────────────────

        root.addView(label("RST 受信"))
        val etRstR = EditText(ctx).apply {
            hint = defaultRst; setText(initRstR.ifEmpty { defaultRst })
            setHintTextColor(0xFF505050.toInt()); setTextColor(0xFFFFFFFF.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF333333.toInt())
            textSize = 20f; setSingleLine(true); setPadding(dp(10), dp(8), dp(10), dp(8))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        root.addView(hrow(etRstR, clearBtn(etRstR)))
        rstSelectorViews(etRstR).forEach { root.addView(it) }

        fun potaSotaField(hint: String, init: String, color: Int) = EditText(ctx).apply {
            this.hint = hint; setText(init.uppercase())
            setHintTextColor(0xFF505050.toInt()); setTextColor(color)
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF333333.toInt())
            textSize = 16f; setSingleLine(true); setPadding(dp(8), dp(8), dp(8), dp(8))
            inputType = InputType.TYPE_CLASS_TEXT or
                    InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            filters = arrayOf(android.text.InputFilter { source, _, _, _, _, _ ->
                source.toString().uppercase()
                    .filter { it.isLetter() && it.code < 128 || it.isDigit() || it == '-' || it == '/' }
            })
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }

        // ─── Your POTA / SOTA (DX station's) ────────────────────────────────

        root.addView(label("Your POTA (相手のパーク)"))
        val etYourPota = potaSotaField("例: JP-1234", initPota, 0xFF80CBC4.toInt())
        root.addView(etYourPota)

        root.addView(label("Your SOTA (相手の山)"))
        val etYourSota = potaSotaField("例: JA/KN-001", initSota, 0xFF80CBC4.toInt())
        root.addView(etYourSota)

        // 相手局の GL / QTH (HAMLOG GL / QTH 欄へ)
        root.addView(label("GL (相手局グリッド)"))
        val etDxGl = editText("例: PM95", "")
        root.addView(hrow(etDxGl, clearBtn(etDxGl)))
        root.addView(label("QTH (相手局)"))
        val etDxQth = editText("例: Tokyo", "")
        root.addView(hrow(etDxQth, clearBtn(etDxQth)))
        root.addView(label("名前 (QRA)"))
        val etName = editText("相手局の名前", "")
        root.addView(hrow(etName, clearBtn(etName)))

        // QSL 状態(相手局QTHの下。HAMLOG QSL欄へ)
        root.addView(label("QSL"))
        val qslLabels = arrayOf("空白", "JARL", "hQSL", "No", "Card", "1-Way")
        val qslCodes  = arrayOf("", "J", "H", "N", "C", "1")
        val qslSpinner = android.widget.Spinner(ctx).apply {
            adapter = android.widget.ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, qslLabels)
            setSelection(qslCodes.indexOf(ctx.getSharedPreferences("log_qso_persist", android.content.Context.MODE_PRIVATE).getString("qsl", "") ?: "").coerceAtLeast(0))
        }
        root.addView(qslSpinner)

        // ─── My POTA / SOTA (own) ────────────────────────────────────────────

        val persist = ctx.getSharedPreferences("log_qso_persist", android.content.Context.MODE_PRIVATE)

        root.addView(label("My POTA (自分のパーク)"))
        val etMyPota = potaSotaField("例: JP-1234", persist.getString("myPota", "") ?: "", 0xFFCCCCCC.toInt())
        root.addView(etMyPota)

        root.addView(label("My SOTA (自分の山)"))
        val etMySota = potaSotaField("例: JA/KN-001", persist.getString("mySota", "") ?: "", 0xFFCCCCCC.toInt())
        root.addView(etMySota)

        // My GL(自局グリッド) — 運用地にGLがあれば選択で自動反映。無ければ ft8MyGrid 既定
        root.addView(label("My GL (自局グリッド)"))
        val etMyGl = editText("例: PM95", myGrid)
        root.addView(hrow(etMyGl, clearBtn(etMyGl)))

        // 運用場所(My Park が複数ロケーションにまたがる場合などの地点)。次回も保持
        root.addView(label("運用場所 Location (My Parkマルチロケ等)"))
        val etMyLoc = editText("例: さいたま市/JP-xxxxの地点名", persist.getString("myLoc", "") ?: "")
        root.addView(hrow(etMyLoc, clearBtn(etMyLoc)))

        // ─── JCC / JGC ───────────────────────────────────────────────────────

        root.addView(label("JCC (4桁) / JGC (5桁)"))
        val etJcc = EditText(ctx).apply {
            hint = "例: 2716"; setText(persist.getString("jcc", "") ?: "")
            setHintTextColor(0xFF505050.toInt()); setTextColor(0xFFCCCCCC.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF333333.toInt())
            textSize = 16f; setSingleLine(true); setPadding(dp(8), dp(8), dp(8), dp(8))
            inputType = InputType.TYPE_CLASS_NUMBER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 4f)
        }
        val tvSlash = TextView(ctx).apply {
            text = "  /  "; textSize = 16f; setTextColor(0xFF777777.toInt())
        }
        val etJgc = EditText(ctx).apply {
            hint = "例: 27169"; setText("")
            setHintTextColor(0xFF505050.toInt()); setTextColor(0xFFCCCCCC.toInt())
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF333333.toInt())
            textSize = 16f; setSingleLine(true); setPadding(dp(8), dp(8), dp(8), dp(8))
            inputType = InputType.TYPE_CLASS_NUMBER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 5f)
        }
        root.addView(hrow(etJcc, tvSlash, etJgc))

        // ─── この交信の運用地(メイン画面の選択を引き継ぎ、ここで取捨選択) ───
        run {
            val dtStr = (etDate.text.toString().trim() + etTime.text.toString().trim()).padEnd(14, '0').take(14)
            val qsoMs = parseUtcDtMs(dtStr)
            val active = vm.activeSessionsAt(qsoMs)
            if (active.isNotEmpty()) {
                val preselected = vm.selectedSessionsAt(qsoMs).map { it.id }.toSet()
                val checks = LinkedHashMap<OpSession, android.widget.CheckBox>()
                fun applySessions() {
                    val on = checks.filter { it.value.isChecked }.keys
                    // 選択中の運用地にGLがあれば My GL 欄へ反映
                    on.firstOrNull { it.gl.isNotBlank() }?.let { etMyGl.setText(it.gl) }
                    // 運用地名(label)を 運用場所 Location 欄へ反映
                    on.firstOrNull { it.label.isNotBlank() }?.let { etMyLoc.setText(it.label) }
                    if (active.any { it.type == "POTA" })
                        etMyPota.setText(on.filter { it.type == "POTA" }.joinToString(",") { it.ref })
                    if (active.any { it.type == "SOTA" })
                        etMySota.setText(on.firstOrNull { it.type == "SOTA" }?.ref ?: "")
                    if (active.any { it.type == "JCC" })
                        etJcc.setText(on.firstOrNull { it.type == "JCC" }?.ref ?: "")
                    if (active.any { it.type == "JGC" })
                        etJgc.setText(on.firstOrNull { it.type == "JGC" }?.ref ?: "")
                }
                root.addView(label("この交信の運用地 (チェックで My POTA/SOTA/JCC に反映・2ferは複数POTA可)"))
                active.forEach { s ->
                    val cb = android.widget.CheckBox(ctx).apply {
                        text = "${s.type}  ${s.ref}" + if (s.label.isNotEmpty()) " (${s.label})" else ""
                        setTextColor(0xFFCCCCCC.toInt()); isChecked = s.id in preselected
                    }
                    checks[s] = cb
                    root.addView(cb)
                }
                checks.values.forEach { it.setOnCheckedChangeListener { _, _ -> applySessions() } }
                applySessions()
            }
        }

        // (GPS取得は「運用地」追加画面へ移動した)

        // ─── Comment ─────────────────────────────────────────────────────────

        root.addView(label("コメント"))
        val etComment = editText("", persist.getString("comment", "") ?: "")
        root.addView(hrow(etComment, clearBtn(etComment)))

        // コメント自動生成トグル: ON の間は My POTA/SOTA/JCC/JGC からコメントを自動生成
        fun genComment(): String {
            val parts = mutableListOf<String>()
            etMyPota.text.toString().trim().let { if (it.isNotEmpty()) parts.add("POTA $it") }
            etMySota.text.toString().trim().let { if (it.isNotEmpty()) parts.add("SOTA $it") }
            etJcc.text.toString().trim().let { if (it.isNotEmpty()) parts.add("JCC $it") }
            etJgc.text.toString().trim().let { if (it.isNotEmpty()) parts.add("JGC $it") }
            return parts.joinToString(" ")
        }
        val cbAutoComment = android.widget.CheckBox(ctx).apply {
            text = "My POTA/SOTA/JCC/JGC からコメント自動生成"
            setTextColor(0xFFCCCCCC.toInt())
            isChecked = persist.getBoolean("autoComment", false)
        }
        root.addView(cbAutoComment)
        val autoCommentWatcher = object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                if (cbAutoComment.isChecked) etComment.setText(genComment())
            }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        }
        etMyPota.addTextChangedListener(autoCommentWatcher)
        etMySota.addTextChangedListener(autoCommentWatcher)
        etJcc.addTextChangedListener(autoCommentWatcher)
        etJgc.addTextChangedListener(autoCommentWatcher)
        cbAutoComment.setOnCheckedChangeListener { _, checked ->
            persist.edit().putBoolean("autoComment", checked).apply()
            if (checked) etComment.setText(genComment())
        }
        if (cbAutoComment.isChecked) etComment.setText(genComment())

        // ─── Clear persistent fields button ──────────────────────────────────

        root.addView(Button(ctx).apply {
            text = "My POTA / SOTA / JCC / コメント クリア"
            textSize = 12f
            backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF4A0000.toInt())
            setTextColor(0xFFFF8A80.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.topMargin = dp(12) }
            setOnClickListener {
                etMyPota.text.clear(); etMySota.text.clear()
                etJcc.text.clear(); etJgc.text.clear(); etComment.text.clear()
                persist.edit().remove("myPota").remove("mySota").remove("jcc").remove("comment").apply()
            }
        })

        // Spacer: without this, ScrollView maxScrollY = content_height - sv.height ≈ 0
        // when ADJUST_RESIZE does not shrink sv (Android 11+). The spacer increases content
        // height so the comment field can scroll above the keyboard.
        root.addView(View(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                ctx.resources.displayMetrics.heightPixels / 3
            )
        })

        // ─── dialog ───────────────────────────────────────────────────────────

        val sv = ScrollView(ctx).apply {
            addView(root)
            isVerticalScrollBarEnabled = false
        }

        // ヘッダに Close/Clear/Save を置く(キーボードは下に出るので上固定なら隠れない)。
        // Close は内容を保持して閉じる(再オープンで復元)。Clear は入力を消去。
        val btnCancel = Button(ctx).apply { text = "Close"; isAllCaps = false }
        val btnClear = Button(ctx).apply { text = "Clear"; isAllCaps = false; setTextColor(0xFFFF5252.toInt()) }
        val btnSave = Button(ctx).apply { text = "Save"; isAllCaps = false }
        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(6), dp(8), dp(6))
            addView(TextView(ctx).apply {
                text = "Log QSO"; setTextColor(0xFFFFFFFF.toInt()); textSize = 17f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(btnCancel); addView(btnClear); addView(btnSave)
        }
        val outer = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(header, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }

        val dlg = android.app.AlertDialog.Builder(ctx, android.R.style.Theme_Material_Dialog_NoActionBar)
            .setView(outer)
            .create()

        dlg.window?.apply {
            setBackgroundDrawableResource(android.R.color.background_dark)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }

        // ─── 一時保存(下書き): 画面の入力を保持してメイン画面へ戻り、再オープンで復元 ───
        val draftPrefs = ctx.getSharedPreferences("log_qso_draft", android.content.Context.MODE_PRIVATE)
        fun saveDraft() {
            draftPrefs.edit()
                .putString("call", etCall.text.toString())
                .putString("rstS", etRstS.text.toString()).putString("rstR", etRstR.text.toString())
                .putString("name", etName.text.toString())
                .putString("yourPota", etYourPota.text.toString()).putString("yourSota", etYourSota.text.toString())
                .putString("dxGl", etDxGl.text.toString()).putString("dxQth", etDxQth.text.toString())
                .putString("qsl", qslCodes.getOrElse(qslSpinner.selectedItemPosition) { "" })
                .putString("myGl", etMyGl.text.toString()).putString("myLoc", etMyLoc.text.toString())
                .putString("myPota", etMyPota.text.toString()).putString("mySota", etMySota.text.toString())
                .putString("jcc", etJcc.text.toString()).putString("jgc", etJgc.text.toString())
                .putString("comment", etComment.text.toString())
                .putString("date", etDate.text.toString()).putString("time", etTime.text.toString())
                .putBoolean("has", true)
                .apply()
        }
        fun clearDraft() { draftPrefs.edit().clear().apply() }
        fun restoreDraft() {
            if (!draftPrefs.getBoolean("has", false)) return
            etCall.setText(draftPrefs.getString("call", ""))
            etRstS.setText(draftPrefs.getString("rstS", "")); etRstR.setText(draftPrefs.getString("rstR", ""))
            etName.setText(draftPrefs.getString("name", ""))
            etYourPota.setText(draftPrefs.getString("yourPota", "")); etYourSota.setText(draftPrefs.getString("yourSota", ""))
            etDxGl.setText(draftPrefs.getString("dxGl", "")); etDxQth.setText(draftPrefs.getString("dxQth", ""))
            qslSpinner.setSelection(qslCodes.indexOf(draftPrefs.getString("qsl", "") ?: "").coerceAtLeast(0))
            etMyGl.setText(draftPrefs.getString("myGl", "")); etMyLoc.setText(draftPrefs.getString("myLoc", ""))
            etMyPota.setText(draftPrefs.getString("myPota", "")); etMySota.setText(draftPrefs.getString("mySota", ""))
            etJcc.setText(draftPrefs.getString("jcc", "")); etJgc.setText(draftPrefs.getString("jgc", ""))
            etComment.setText(draftPrefs.getString("comment", ""))
            draftPrefs.getString("date", "")?.takeIf { it.isNotEmpty() }?.let { etDate.setText(it) }
            draftPrefs.getString("time", "")?.takeIf { it.isNotEmpty() }?.let { etTime.setText(it) }
        }
        // Clear: 相手局(DX)側の入力を消去して下書きも破棄(自局の運用地等は永続維持)
        fun clearForm() {
            etCall.setText(""); etRstS.setText(defaultRst); etRstR.setText(defaultRst)
            etName.setText(""); etYourPota.setText(""); etYourSota.setText("")
            etDxGl.setText(""); etDxQth.setText(""); qslSpinner.setSelection(0)
            val next = if (dtLocal) msToWall(System.currentTimeMillis(), localTz) else QsoEntry.utcNow()
            etDate.setText(next.take(8)); etTime.setText(next.drop(8))
            clearDraft(); etCall.requestFocus()
        }

        // Save logic extracted so it can be called from the overridden button listener
        fun doSave() {
            val call = etCall.text.toString().trim().uppercase()
            if (call.isEmpty()) {
                Toast.makeText(ctx, "Callsign required", Toast.LENGTH_SHORT).show()
                return
            }
            val rawDt = (etDate.text.toString().trim() + etTime.text.toString().trim())
                .padEnd(14, '0').take(14)
            // ローカル入力中はUTCへ変換して保存(dtは常にUTC)
            val dt = if (dtLocal) msToWall(wallToMs(rawDt, localTz), utcTz) else rawDt
            val entry = QsoEntry(
                dt       = dt,
                call     = call,
                freqHz   = freqHz,
                mode     = mode.ifEmpty { "SSB" },
                rstSent  = etRstS.text.toString().trim().ifEmpty { defaultRst },
                rstRcvd  = etRstR.text.toString().trim().ifEmpty { defaultRst },
                dxGrid   = etDxGl.text.toString().trim().uppercase(),
                myCall   = myCall,
                myGrid   = etMyGl.text.toString().trim().uppercase().ifEmpty { myGrid },
                yourPota = etYourPota.text.toString().trim().uppercase(),
                yourSota = etYourSota.text.toString().trim().uppercase(),
                myPota   = etMyPota.text.toString().trim().uppercase(),
                mySota   = etMySota.text.toString().trim().uppercase(),
                jcc      = etJcc.text.toString().trim(),
                jgc      = etJgc.text.toString().trim(),
                comment  = etComment.text.toString().trim(),
                lat      = 0.0,
                lon      = 0.0,
                qsl      = qslCodes.getOrElse(qslSpinner.selectedItemPosition) { "" },
                qth      = etDxQth.text.toString().trim(),
                myLoc    = etMyLoc.text.toString().trim(),
                name     = etName.text.toString().trim()
            )
            QsoStore.append(requireContext(), entry)
            clearDraft()   // ログ確定したので下書きは破棄
            // 外部連携: eQSL 自動送信 / Smart HAMLOG 自動連携(各々ONかつ設定ありのときのみ)
            EqslUploader.enqueueAndSend(requireContext(), entry)
            SmartHamLogSync.autoUpload(requireContext(), entry)
            persist.edit()
                .putString("myPota",  entry.myPota)
                .putString("mySota",  entry.mySota)
                .putString("jcc",     entry.jcc)
                .putString("comment", entry.comment)
                .putString("qsl",     entry.qsl)
                .putString("myLoc",   entry.myLoc)
                .apply()
            parentFragmentManager.setFragmentResult("log_qso_done", Bundle())
            Toast.makeText(ctx, "Logged: $call", Toast.LENGTH_SHORT).show()
            // Clear transient fields for next QSO; keep My POTA/SOTA/JCC/JGC/Comment
            etCall.setText(""); etCall.requestFocus()
            etYourPota.setText(""); etYourSota.setText("")
            // スポット由来の保留値は記録済みなのでクリア(次QSOに古いPOTA/SOTA/コールを持ち越さない。iOS と同仕様)
            vm.pendingLogCallsign = ""; vm.pendingLogPota = ""; vm.pendingLogSota = ""
            etRstS.setText(defaultRst); etRstR.setText(defaultRst)
            val next = if (dtLocal) msToWall(System.currentTimeMillis(), localTz) else QsoEntry.utcNow()
            etDate.setText(next.take(8)); etTime.setText(next.drop(8))
        }

        btnSave.setOnClickListener { doSave() }        // ヘッダのSave(保存後もダイアログは開いたまま)
        btnClear.setOnClickListener { clearForm() }    // 入力を消去(下書きも破棄)
        btnCancel.setOnClickListener { dlg.dismiss() } // Close: 内容は保持(onDismissで下書き保存)
        // 画面を閉じても登録状態が戻るよう、どの閉じ方でも内容を下書き保存する。
        // RST だけ入力してコール未入力でも保持する(破棄は Clear ボタン)。クラスレベル onDismiss から。
        onDismissDraft = { saveDraft() }
        // 通常オープンは下書きを復元。コールサイン連携(ハンドオフ)時は古い下書きを破棄。
        if (initCall.isEmpty()) restoreDraft() else clearDraft()

        dlg.setOnShowListener {
            dlg.window?.setLayout(
                (ctx.resources.displayMetrics.widthPixels * 0.95).toInt(),
                WindowManager.LayoutParams.MATCH_PARENT
            )

            // Scroll focused field into view using actual visible height (works even if
            // ADJUST_RESIZE doesn't shrink the dialog window on Android 11+)
            var lastFocused: View? = null
            sv.viewTreeObserver.addOnGlobalFocusChangeListener { _, newFocus ->
                if (newFocus != null && root.findFocus() != null) lastFocused = newFocus
            }
            sv.viewTreeObserver.addOnGlobalLayoutListener {
                val focused = lastFocused ?: return@addOnGlobalLayoutListener
                if (root.findFocus() == null) return@addOnGlobalLayoutListener
                // Measure how much of sv is visible above the keyboard
                val visFrame = android.graphics.Rect()
                sv.getWindowVisibleDisplayFrame(visFrame)
                val loc = IntArray(2)
                sv.getLocationOnScreen(loc)
                val effectiveHeight = (visFrame.bottom - loc[1]).coerceIn(dp(80), sv.height)
                // Get focused view's content position in sv
                val rect = android.graphics.Rect()
                focused.getDrawingRect(rect)
                sv.offsetDescendantRectToMyCoords(focused, rect)
                val target = rect.bottom + dp(20) - effectiveHeight
                if (target > sv.scrollY) sv.smoothScrollTo(0, maxOf(0, target))
            }

            etCall.requestFocus()
            if (initCall.isNotEmpty()) etCall.setSelection(0, etCall.text.length)
        }
        return dlg
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? = null
}
