import Foundation

/// 設定(UserDefaults・非機密)と QSO ログを iCloud Drive(ubiquity container)へ保存し、
/// 再インストール後も同じ iCloud アカウントなら自動復元する。
///
/// Android の `BackupStore`(ユーザーが選んだ SAF フォルダ)に対応する iOS 版。iOS では
/// 保存先をユーザーに選ばせる代わりに、アプリ専用の iCloud Drive フォルダへ自動保存する。
///
/// - 対象: `UserDefaults.standard` のうちアプリ自身のキー(接続設定・運用地・連携 ON/URL・QSO ログ等)。
/// - 除外: 認証情報(API キー・CI-V パスワード・eQSL/SHL 資格情報)は **Keychain** にあり一切扱わない。
///         万一 UserDefaults に残っていても、名前に機密語を含むキーは除外する(平文流出を避ける)。
enum BackupStore {
    private static let fileName = "wifirig_backup.json"

    /// 機密名を含むキーは対象外(通常は Keychain 管理だが保険として名前でも弾く)。
    private static let secretHints = ["password", "pswd", "token", "secret", "apikey"]

    /// iCloud(Drive)が利用可能か。サインインしていなければ false。
    static var isAvailable: Bool { FileManager.default.ubiquityIdentityToken != nil }

    /// ubiquity container 内 Documents のバックアップファイル URL(必要ならフォルダ作成)。
    private static func fileURL() -> URL? {
        guard let base = FileManager.default.url(forUbiquityContainerIdentifier: nil) else { return nil }
        let docs = base.appendingPathComponent("Documents", isDirectory: true)
        try? FileManager.default.createDirectory(at: docs, withIntermediateDirectories: true)
        return docs.appendingPathComponent(fileName)
    }

    /// アプリ自身の UserDefaults キーだけを対象にする。Apple/システムキーは大文字始まり or
    /// `com.apple.*`、アプリのキーはすべて小文字始まり(ft8…/aprs…/cw…/hostName 等)。
    static func isBackupKey(_ k: String) -> Bool {
        guard let first = k.first, first.isLetter, first.isLowercase else { return false }
        if k.hasPrefix("com.apple") { return false }
        let lk = k.lowercased()
        return !secretHints.contains { lk.contains($0) }
    }

    /// 現在の設定/ログを iCloud へ書き出す。成功で true。
    @discardableResult
    static func save() -> Bool {
        guard let url = fileURL() else { return false }
        var dict: [String: Any] = [:]
        for (k, v) in UserDefaults.standard.dictionaryRepresentation() where isBackupKey(k) {
            // JSON 化できる値のみ(Data 等は対象外=機密になり得るバイナリを混ぜない)。
            if JSONSerialization.isValidJSONObject([v]) { dict[k] = v }
        }
        guard let data = try? JSONSerialization.data(withJSONObject: dict, options: [.sortedKeys]) else { return false }
        var ok = false
        var coordErr: NSError?
        NSFileCoordinator().coordinate(writingItemAt: url, options: .forReplacing, error: &coordErr) { u in
            ok = ((try? data.write(to: u, options: .atomic)) != nil)
        }
        return ok && coordErr == nil
    }

    /// iCloud のバックアップを UserDefaults へ適用する。成功で true。
    @discardableResult
    static func restore() -> Bool {
        guard let url = fileURL() else { return false }
        // まだ端末にダウンロードされていない場合に備えてダウンロードを促し、coordinator で待つ。
        try? FileManager.default.startDownloadingUbiquitousItem(at: url)
        var restored = false
        var coordErr: NSError?
        NSFileCoordinator().coordinate(readingItemAt: url, options: [], error: &coordErr) { u in
            guard let data = try? Data(contentsOf: u),
                  let dict = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return }
            let d = UserDefaults.standard
            for (k, v) in dict where isBackupKey(k) { d.set(v, forKey: k) }
            restored = true
        }
        return restored && coordErr == nil
    }

    /// 新規/再インストール直後(主要キーが無い)かつ iCloud 利用可能なら自動復元する。
    /// アプリ起動時、ViewModel が UserDefaults を読む前に呼ぶこと。
    @discardableResult
    static func restoreIfFresh() -> Bool {
        let d = UserDefaults.standard
        let fresh = d.string(forKey: "ft8QsoLog") == nil && d.string(forKey: "hostName") == nil
        guard fresh, isAvailable else { return false }
        return restore()
    }
}
