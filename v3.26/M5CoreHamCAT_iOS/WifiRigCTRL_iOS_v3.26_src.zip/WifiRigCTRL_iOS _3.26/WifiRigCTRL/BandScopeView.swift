import SwiftUI

/// バンドスコープ画面。
/// 現在周波数を中心に、選択した「総スパン幅(周波数)」を `/radio/scope/sweep` で掃引し、
/// 横軸=周波数 / 縦軸=信号強度 のスペクトラム風表示を行う。
/// START/STOP で連続掃引、SPAN で総スパン幅(バンドごとに選択)を切替。
/// 刻み(分解能)はメイン画面のSTEP設定に合わせる。広帯域で点数が多すぎる時だけ
/// 自動的に粗くして掃引時間を抑える(その場合は実効STEPを表示)。
struct BandScopeView: View {
    @Bindable var vm: MainViewModel
    @Environment(\.dismiss) private var dismiss

    // 総スパン幅(Hz)。狭帯域は10kHz/20kHzから、FMのVHF/UHF帯は広いので最大40MHzまで。
    private let spanOptionsHz: [Int64] = [
        10_000, 20_000, 50_000, 100_000, 200_000, 500_000, 1_000_000,
        2_000_000, 5_000_000, 10_000_000, 20_000_000, 40_000_000
    ]
    // ① Icomネイティブスコープ(Center モード)が取れる span 一覧(リグ仕様準拠。最大±250kHz=500kHz)。
    private let icomSpanOptionsHz: [Int64] = [5_000, 10_000, 25_000, 50_000, 100_000, 250_000, 500_000]
    @State private var spanIdx = 6          // 初期表示 1MHz(バンド別の記憶で上書き)
    @State private var scopeRunning = false         // ① 連続スコープ稼働中か
    @State private var nativeModel = NativeScopeModel()
    @State private var currentBand = ""     // バンド別スパン記憶用
    private let settleMs = 50               // 1点ごとのセトリング(遅延を十分小さくしてピーク位置のズレを無くす)
    private let freqDivs = 6                // 周波数縦グリッドの分割数(=ラベル本数 freqDivs+1)
    @State private var freqs: [Int64] = []
    @State private var points: [Double] = []
    @State private var scanning = false
    @State private var sweepTask: Task<Void, Never>? = nil
    @State private var showFreqInput = false   // 右上の周波数タップで周波数入力ボックスを開く
    @State private var showModePicker = false   // MODEボタンのモード選択
    @State private var showLogQso = false       // LOG QSO
    @State private var showOpSessions = false   // 運用地
    @State private var showSpotSettings = false  // スポット重畳設定
    @State private var showMemSheet = false      // MEM SET(メモリーパネル)

    // POTA/SOTA スポット重畳の表示設定(スコープ専用・UserDefaultsに記憶)
    @AppStorage("scopeShowPota")   private var showPota = true
    @AppStorage("scopeShowSota")   private var showSota = true
    @AppStorage("scopePotaProgs")  private var potaProgsCSV = ""   // 空=全プログラム
    @AppStorage("scopeSotaAssocs") private var sotaAssocsCSV = ""  // 空=全アソシエーション

    // スコープに重畳する1スポット(周波数・リファレンス・コール・モード・種別)。
    private struct ScopeSpot {
        let hz: Int64; let ref: String; let call: String; let mode: String; let isPota: Bool
    }

    private func csvSet(_ s: String) -> Set<String> {
        Set(s.split(separator: ",").map { String($0).trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty })
    }

    /// 表示設定を適用した重畳スポット一覧(周波数>0のみ)。
    private var overlaySpots: [ScopeSpot] {
        var out: [ScopeSpot] = []
        if showPota {
            let progs = csvSet(potaProgsCSV)
            for s in vm.scopePotaSpots where s.freqHz > 0 {
                if progs.isEmpty || progs.contains(s.program) {
                    out.append(ScopeSpot(hz: s.freqHz, ref: s.reference, call: s.activator, mode: s.mode, isPota: true))
                }
            }
        }
        if showSota {
            let assocs = csvSet(sotaAssocsCSV)
            for s in vm.scopeSotaSpots where s.freqHz > 0 {
                if assocs.isEmpty || assocs.contains(s.effectiveAssocCode) {
                    out.append(ScopeSpot(hz: s.freqHz, ref: s.codeStr,
                                         call: s.activatorCallsign ?? "", mode: s.mode ?? "", isPota: false))
                }
            }
        }
        return out
    }

    /// 現在の可視周波数レンジ内に入る重畳スポット件数。
    private var visibleSpotCount: Int {
        guard let (lo, hi) = scopeDomainHz(), hi > lo else { return 0 }
        return overlaySpots.filter { Double($0.hz) >= lo && Double($0.hz) <= hi }.count
    }

    // 表示レンジ(dB, hamlib STRENGTH: S9=0基準)
    private let dbFloor: Double = -54   // S0
    private let dbCeil:  Double =  40   // S9+40

    // CI-V直接(Wi-Fi/Icom)は ① ネイティブ連続スコープ(受信音と両立)。Pi は ② CATスイープ。
    private var nativeScope: Bool { vm.useCivMode }
    private var spanArr: [Int64] { nativeScope ? icomSpanOptionsHz : spanOptionsHz }
    private var spanTotalHz: Int64 { spanArr[min(max(spanIdx, 0), spanArr.count - 1)] }

    private func spanLabel(_ hz: Int64) -> String {
        hz >= 1_000_000 ? String(format: "%.1fMHz", Double(hz) / 1_000_000.0) : "\(hz / 1000)kHz"
    }

    /// 分解能(刻み): メイン画面のSTEPをそのまま使う。点数=スパン÷STEPなので、
    /// 棒グラフの本数(=1本の幅)がSPANに追従する。点数が極端に多い場合のみサーバ側で最大256点に調整。
    private func effStepHz() -> Int64 {
        max(1, Int64(AppConstants.stepHz[vm.selectedStepIndex]))
    }

    private func stepLabel(_ hz: Int64) -> String {
        if hz >= 1000 && hz % 1000 == 0 { return "\(hz / 1000)kHz" }
        if hz >= 1000 { return String(format: "%.1fkHz", Double(hz) / 1000.0) }
        return "\(hz)Hz"
    }

    var body: some View {
        VStack(spacing: 6) {
            HStack {
                Text(nativeScope
                     ? "BAND SCOPE (Icom)   Span \(spanLabel(spanTotalHz))"
                     : "BAND SCOPE   Span \(spanLabel(spanTotalHz))   Step \(stepLabel(effStepHz()))")
                    .font(.caption).bold()
                    .foregroundColor(Color(red: 0, green: 0.9, blue: 1))
                Spacer()
                // 選択(現在)周波数を右上に表示。タップで周波数入力ボックス。
                Text(vm.sharedFreq > 0 ? String(format: "%.4f MHz", Double(vm.sharedFreq) / 1_000_000.0) : "----")
                    .font(.callout).bold()
                    .foregroundColor(Color(red: 1, green: 0.87, blue: 0))
                    .onTapGesture { showFreqInput = true }
            }
            .frame(maxWidth: .infinity)

            // スポット読込件数(POTA/SOTA)と可視範囲内の件数。0件なら取得失敗/範囲外の切り分け用。
            HStack(spacing: 10) {
                Text("SPOT").font(.system(size: 10, weight: .bold)).foregroundColor(.gray)
                Text("P:\(vm.scopePotaSpots.count)").font(.system(size: 10)).foregroundColor(Color(red: 0, green: 0.95, blue: 1))
                Text("S:\(vm.scopeSotaSpots.count)").font(.system(size: 10)).foregroundColor(Color(red: 1, green: 0.6, blue: 0.1))
                Text("表示中:\(visibleSpotCount)").font(.system(size: 10)).foregroundColor(.white)
                Spacer()
            }
            .frame(maxWidth: .infinity)

            scope
                .frame(maxWidth: .infinity, maxHeight: .infinity)

            // LOG行(メイン画面に準拠・最上段): LOG QSO / LOG一覧 / 運用地
            HStack(spacing: 8) {
                Button("LOG QSO") { showLogQso = true }
                    .buttonStyle(.borderedProminent).tint(.purple)
                Button("LOG一覧") { vm.path.append(.qsoLog) }
                    .buttonStyle(.borderedProminent).tint(.indigo)
                Button("運用地") { showOpSessions = true }
                    .buttonStyle(.borderedProminent).tint(.brown)
                Button("MEM") { showMemSheet = true }
                    .buttonStyle(.borderedProminent).tint(.gray)
            }

            HStack(spacing: 8) {
                Button("SPAN \(spanLabel(spanTotalHz))") {
                    spanIdx = (spanIdx + 1) % spanArr.count
                    saveSpan(currentBand, spanIdx)   // バンド別に記憶
                    if nativeScope && scopeRunning { applyNativeSpan() }
                }
                    .buttonStyle(.borderedProminent).tint(.blue)
                if nativeScope {
                    // ① 連続スコープ(受信音と両立) → START/STOP
                    Button(scopeRunning ? "STOP" : "START") {
                        if scopeRunning { stopNativeScope() } else { startNativeScope() }
                    }
                        .buttonStyle(.borderedProminent).tint(scopeRunning ? .red : .green)
                } else {
                    // ② CATスイープ → 単発 SCAN
                    Button(scanning ? "SCANNING…" : "SCAN") { doScan() }
                        .buttonStyle(.borderedProminent).tint(.teal)
                        .disabled(scanning)
                }
                Button(vm.sharedMode.isEmpty ? "MODE" : vm.sharedMode) { showModePicker = true }
                    .buttonStyle(.borderedProminent).tint(.indigo)
            }

            // SPK / PTT (メイン画面に準拠 — 下段。戻るはナビバーの戻る矢印)
            HStack(spacing: 8) {
                Button(vm.spkEnabled ? "SPK●" : "SPK") { Task { await vm.setSpk(on: !vm.spkEnabled) } }
                    .buttonStyle(.borderedProminent).tint(vm.spkEnabled ? .green : .gray)
                Button(vm.txEnabled ? "TX" : "PTT") { Task { await vm.setPtt(on: !vm.txEnabled) } }
                    .buttonStyle(.borderedProminent).tint(vm.txEnabled ? .red : .purple)
            }

            Text(nativeScope
                 ? "STARTでリグ内蔵スコープを連続表示(受信音と両立・VFOは動きません)。信号タップでQSY。"
                 : "SCANで1回掃引。スコープ上の信号をタップするとその周波数へQSY。掃引の一瞬だけ受信音が乱れます(SPKはオンのままでOK)。")
                .font(.system(size: 10))
                .foregroundColor(.gray)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(8)
        .background(Color(red: 0, green: 0.04, blue: 0.04))
        .navigationTitle("Band Scope")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showFreqInput) { FreqInputView(vm: vm) }
        .sheet(isPresented: $showLogQso) {
            LogQsoView(vm: vm,
                       initCallsign: vm.pendingLogCallsign,
                       initPota: vm.pendingLogPota,
                       initSota: vm.pendingLogSota)
        }
        .sheet(isPresented: $showOpSessions) { OpSessionView(vm: vm) }
        .sheet(isPresented: $showMemSheet) { MemoryPanelView(vm: vm) }
        .sheet(isPresented: $showSpotSettings) {
            ScopeSpotSettingsView(
                showPota: $showPota, showSota: $showSota,
                potaProgsCSV: $potaProgsCSV, sotaAssocsCSV: $sotaAssocsCSV,
                availablePotaProgs: Array(Set(vm.scopePotaSpots.map { $0.program }.filter { !$0.isEmpty })).sorted(),
                availableSotaAssocs: Array(Set(vm.scopeSotaSpots.map { $0.effectiveAssocCode }.filter { !$0.isEmpty })).sorted(),
                onReload: { Task { await vm.fetchScopeSpots() } }
            )
        }
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button { showSpotSettings = true } label: {
                    Image(systemName: "mappin.and.ellipse")
                }
            }
        }
        .confirmationDialog("Mode", isPresented: $showModePicker) {
            ForEach(vm.supportedModes, id: \.self) { m in
                Button(m) {
                    Task { await vm.setMode(m, width: vm.sharedWidth) }
                    vm.selectedStepIndex = AppConstants.defaultStepIndex(forMode: m)
                    vm.rememberStepForCurrentMode()
                }
            }
            Button("Cancel", role: .cancel) {}
        }
        .onAppear {
            currentBand = freqToBand(vm.sharedFreq)
            spanIdx = loadSpan(currentBand)
            if vm.scopePotaSpots.isEmpty && vm.scopeSotaSpots.isEmpty {
                Task { await vm.fetchScopeSpots() }
            }
            // ① ネイティブ: 波形コールバック登録(civRxThread→メインでモデル更新)。
            if nativeScope {
                vm.civ.icomScope.onSweep = { lv in DispatchQueue.main.async { nativeModel.levels = lv } }
            }
        }
        .onChange(of: vm.sharedFreq) { _, newFreq in
            // バンドが変わったらそのバンドの記憶スパンへ切替
            let b = freqToBand(newFreq)
            if b != currentBand {
                currentBand = b; spanIdx = loadSpan(b)
                if nativeScope && scopeRunning { applyNativeSpan() }
            }
        }
        .onChange(of: nativeModel.levels) { _, lv in renderNativeSweep(lv) }
        .onDisappear { sweepTask?.cancel(); stopNativeScope() }
    }

    // バンドスコープの総スパン選択(index)をバンド別にUserDefaultsへ記憶(無ければ初期値1MHz=6)
    private func spanKey(_ band: String) -> String { "bandscope_span_\(nativeScope ? "ic:" : "")\(band)" }
    private func loadSpan(_ band: String) -> Int {
        let d = UserDefaults.standard
        let key = spanKey(band)
        let def = nativeScope ? (icomSpanOptionsHz.firstIndex(of: 100_000) ?? 0) : 6
        let v = d.object(forKey: key) == nil ? def : d.integer(forKey: key)
        return min(max(v, 0), spanArr.count - 1)
    }
    private func saveSpan(_ band: String, _ idx: Int) {
        UserDefaults.standard.set(idx, forKey: spanKey(band))
    }

    /// 周波数→バンド名(スパンのバンド別記憶キー)。
    private func freqToBand(_ hz: Int64) -> String {
        let mhz = Double(hz) / 1_000_000.0
        switch mhz {
        case 1.8...2.0:       return "160m"
        case 3.5...4.0:       return "80m"
        case 5.3...5.405:     return "60m"
        case 7.0...7.3:       return "40m"
        case 10.1...10.15:    return "30m"
        case 14.0...14.35:    return "20m"
        case 18.068...18.168: return "17m"
        case 21.0...21.45:    return "15m"
        case 24.89...24.99:   return "12m"
        case 28.0...29.7:     return "10m"
        case 50.0...54.0:     return "6m"
        case 144.0...148.0:   return "2m"
        case 430.0...440.0:   return "70cm"
        default:              return "Other"
        }
    }

    private var scope: some View {
        GeometryReader { geo in
            Canvas { ctx, size in draw(ctx, size) }
                .background(Color(red: 0, green: 0.04, blue: 0.04))
                .gesture(DragGesture(minimumDistance: 0).onEnded { v in
                    let w = geo.size.width
                    guard w > 0 else { return }
                    // スポットのティック近傍(±14pt)をタップしたらそのスポットへQSY。
                    if let (lo, hi) = scopeDomainHz(), hi > lo {
                        let hit = overlaySpots
                            .map { (x: CGFloat((Double($0.hz) - lo) / (hi - lo)) * w, spot: $0) }
                            .filter { abs($0.x - v.location.x) <= 14 }
                            .min { abs($0.x - v.location.x) < abs($1.x - v.location.x) }
                        if let hit = hit { qsyToSpot(hit.spot); return }
                    }
                    guard !freqs.isEmpty else { return }
                    let idx = min(max(Int(v.location.x / w * CGFloat(freqs.count)), 0), freqs.count - 1)
                    // 広帯域でサーバが刻みを粗くしてもSTEPに合うよう、「現在周波数基準のSTEP刻み」へ丸める。
                    let step = effStepHz()
                    let center = vm.sharedFreq
                    let steps = (Double(freqs[idx] - center) / Double(step)).rounded()
                    let snapped = center + Int64(steps) * step
                    Task { await vm.setFreq(snapped) }
                })
        }
    }

    private func norm(_ db: Double) -> Double {
        min(max((db - dbFloor) / (dbCeil - dbFloor), 0), 1)
    }

    private func draw(_ ctx: GraphicsContext, _ size: CGSize) {
        let w = size.width, h = size.height
        guard w > 0, h > 0 else { return }

        // S-scale 横グリッド
        for i in 1..<4 {
            let y = h * CGFloat(i) / 4
            var p = Path(); p.move(to: CGPoint(x: 0, y: y)); p.addLine(to: CGPoint(x: w, y: y))
            ctx.stroke(p, with: .color(.white.opacity(0.2)), lineWidth: 0.5)
        }

        let n = points.count
        guard n > 0 else {
            // 未掃引でも、現在周波数±スパンの周波数軸とスポット重畳は表示する。
            drawDomainFreqAxis(ctx, w: w, h: h)
            drawSpots(ctx, w: w, h: h)
            ctx.draw(Text("SCANで掃引").font(.caption).foregroundColor(.gray),
                     at: CGPoint(x: w / 2, y: h / 2), anchor: .center)
            return
        }

        let barW = w / CGFloat(n)

        // 塗りバー
        for b in 0..<n {
            let nv = norm(points[b])
            let barH = CGFloat(nv) * h
            let x = CGFloat(b) * barW
            let rect = CGRect(x: x, y: h - barH, width: barW + 0.5, height: barH)
            ctx.fill(Path(rect), with: .color(scopeColor(nv)))
        }

        // 現在周波数マーカー
        if vm.sharedFreq > 0, !freqs.isEmpty {
            var idx = 0, best = Int64.max
            for b in freqs.indices {
                let d = abs(freqs[b] - vm.sharedFreq)
                if d < best { best = d; idx = b }
            }
            let x = CGFloat(idx) * barW + barW / 2
            var m = Path(); m.move(to: CGPoint(x: x, y: 0)); m.addLine(to: CGPoint(x: x, y: h))
            ctx.stroke(m, with: .color(Color(red: 1, green: 0.87, blue: 0)), lineWidth: 1.5)
        }

        // 周波数 縦グリッド + ラベル。各ビン(=Step周波数)の中心に合わせて配置する
        // (棒・マーカー・タップもビン中心基準なので、ラベルと棒がぴったり一致する)。
        if let first = freqs.first, let last = freqs.last {
            let spanHz = Double(last - first)
            let decimals = spanHz >= 4_000_000 ? 2 : (spanHz >= 400_000 ? 3 : 4)
            let divs = min(freqDivs, max(1, n - 1))
            for i in 0...divs {
                let b = min(max(Int((Double(i) / Double(divs) * Double(n - 1)).rounded()), 0), n - 1)
                let x = CGFloat(b) * barW + barW / 2      // ビン中心
                var p = Path(); p.move(to: CGPoint(x: x, y: 0)); p.addLine(to: CGPoint(x: x, y: h))
                ctx.stroke(p, with: .color(.white.opacity(0.2)), lineWidth: 0.5)
                let anchor: UnitPoint = b == 0 ? .leading : (b == n - 1 ? .trailing : .center)
                let px = min(max(x, 2), w - 2)
                drawLabel(ctx, Double(freqs[b]), decimals: decimals, at: CGPoint(x: px, y: h - 8), anchor: anchor)
            }
        }

        drawSpots(ctx, w: w, h: h)
    }

    /// 可視周波数レンジ[lo,hi](Hz)。掃引済みなら掃引レンジ、未掃引なら現在周波数±スパン/2。
    private func scopeDomainHz() -> (Double, Double)? {
        if let f = freqs.first, let l = freqs.last, l > f { return (Double(f), Double(l)) }
        let c = Double(vm.sharedFreq)
        guard c > 0 else { return nil }
        let half = Double(spanTotalHz) / 2
        return (c - half, c + half)
    }

    /// 未掃引時の周波数軸(現在周波数マーカー + 縦グリッド + 周波数ラベル)をドメイン基準で描画。
    private func drawDomainFreqAxis(_ ctx: GraphicsContext, w: CGFloat, h: CGFloat) {
        guard let (lo, hi) = scopeDomainHz(), hi > lo else { return }
        let spanHz = hi - lo
        let decimals = spanHz >= 4_000_000 ? 2 : (spanHz >= 400_000 ? 3 : 4)
        // 現在周波数マーカー
        if vm.sharedFreq > 0 {
            let x = CGFloat((Double(vm.sharedFreq) - lo) / spanHz) * w
            if x >= 0 && x <= w {
                var m = Path(); m.move(to: CGPoint(x: x, y: 0)); m.addLine(to: CGPoint(x: x, y: h))
                ctx.stroke(m, with: .color(Color(red: 1, green: 0.87, blue: 0)), lineWidth: 1.5)
            }
        }
        for i in 0...freqDivs {
            let frac = Double(i) / Double(freqDivs)
            let x = CGFloat(frac) * w
            var p = Path(); p.move(to: CGPoint(x: x, y: 0)); p.addLine(to: CGPoint(x: x, y: h))
            ctx.stroke(p, with: .color(.white.opacity(0.2)), lineWidth: 0.5)
            let hz = lo + frac * spanHz
            let anchor: UnitPoint = i == 0 ? .leading : (i == freqDivs ? .trailing : .center)
            let px = min(max(x, 2), w - 2)
            drawLabel(ctx, hz, decimals: decimals, at: CGPoint(x: px, y: h - 8), anchor: anchor)
        }
    }

    /// POTA/SOTA スポットを該当周波数の位置に重畳描画する(縦ティック + REF/コール ラベル)。
    /// ラベルが重なる場合は2段に振り分け、それでも近接するものは間引く。
    private func drawSpots(_ ctx: GraphicsContext, w: CGFloat, h: CGFloat) {
        guard let (lo, hi) = scopeDomainHz(), hi > lo else { return }
        let potaColor = Color(red: 0, green: 0.95, blue: 1)      // POTA = シアン
        let sotaColor = Color(red: 1, green: 0.6, blue: 0.1)     // SOTA = オレンジ
        // レンジ内のスポットをx昇順に。
        let visible = overlaySpots
            .map { (x: CGFloat((Double($0.hz) - lo) / (hi - lo)) * w, spot: $0) }
            .filter { $0.x >= 0 && $0.x <= w }
            .sorted { $0.x < $1.x }
        guard !visible.isEmpty else { return }

        let minGap: CGFloat = 46          // ラベルを置く最小間隔
        var laneLastX: [CGFloat] = [-1e9, -1e9]   // 2段
        for (x, spot) in visible {
            let color = spot.isPota ? potaColor : sotaColor
            // 縦ティック(上から短く)
            var tick = Path(); tick.move(to: CGPoint(x: x, y: 0)); tick.addLine(to: CGPoint(x: x, y: h))
            ctx.stroke(tick, with: .color(color.opacity(0.55)), lineWidth: 1)
            // ラベル段を選択(近接しない段へ。両段とも近ければ間引く)
            let lane = (x - laneLastX[0] >= minGap) ? 0 : ((x - laneLastX[1] >= minGap) ? 1 : -1)
            guard lane >= 0 else { continue }
            laneLastX[lane] = x
            let yTop = CGFloat(6 + lane * 38)
            let px = min(max(x, 2), w - 2)
            let anchor: UnitPoint = x < 28 ? .topLeading : (x > w - 28 ? .topTrailing : .top)
            var label = Text(spot.ref).font(.system(size: 9, weight: .bold)).foregroundColor(color)
                + Text("\n\(spot.call)").font(.system(size: 9, weight: .semibold)).foregroundColor(.white)
            // コールサインの下にカッコでモードを表示(空なら省略)。
            if !spot.mode.isEmpty {
                label = label + Text("\n(\(spot.mode))").font(.system(size: 9, weight: .semibold)).foregroundColor(Color(red: 0.3, green: 0.82, blue: 0.88))
            }
            ctx.draw(label, at: CGPoint(x: px, y: yTop), anchor: anchor)
        }
    }

    private func drawLabel(_ ctx: GraphicsContext, _ hz: Double, decimals: Int, at pt: CGPoint, anchor: UnitPoint) {
        ctx.draw(Text(String(format: "%.\(decimals)f", hz / 1_000_000.0))
                    .font(.system(size: 11, weight: .bold)).foregroundColor(Color(red: 1, green: 0.87, blue: 0)),
                 at: pt, anchor: anchor)
    }

    // 濃いめ(高彩度)の配色: 青 → シアン → 緑 → 黄 → 赤。低信号でもはっきり色が出る。
    private func scopeColor(_ v: Double) -> Color {
        let c = min(max(v, 0), 1)
        switch c {
        case ..<0.33:
            let t = c / 0.33
            return Color(red: 0, green: (60 + t * 160) / 255, blue: (200 + t * 55) / 255)
        case ..<0.66:
            let t = (c - 0.33) / 0.33
            return Color(red: t * 230 / 255, green: (220 - t * 10) / 255, blue: (255 - t * 255) / 255)
        default:
            let t = (c - 0.66) / 0.34
            return Color(red: (230 + t * 25) / 255, green: (210 - t * 180) / 255, blue: 0)
        }
    }

    /// 重畳スポットをタップ → その周波数・モードへQSY(メモリ画面のスポット行と同じ挙動)。
    private func qsyToSpot(_ spot: ScopeSpot) {
        let m = normalizeSpotMode(spot.mode, freqHz: spot.hz)
        Task {
            if !m.isEmpty {
                let w = vm.modeDefaultWidth(m)
                let width = w > 0 ? w : vm.sharedWidth
                // モードは1発落ちることがあるので念のため2回送る(Pi経由対策)。
                await vm.setMode(m, width: width)
                try? await Task.sleep(nanoseconds: 200_000_000)
                await vm.setMode(m, width: width)
            }
            await vm.setFreq(spot.hz)
        }
        vm.pendingLogCallsign = spot.call
        vm.pendingLogPota = spot.isPota ? spot.ref : ""
        vm.pendingLogSota = spot.isPota ? "" : spot.ref
    }

    /// 1回だけ掃引して表示する。SPKは操作しない(掃引の一瞬だけ受信音が乱れる)。
    private func doScan() {
        guard !scanning else { return }
        let center = vm.sharedFreq
        guard center > 0 else { return }
        let total = spanTotalHz
        let half = total / 2
        let start = max(1, center - half)
        let stop = center + half
        let effStep = effStepHz()
        scanning = true
        sweepTask = Task { @MainActor in
            if let r = await vm.scopeSweep(start: start, stop: stop, step: effStep, settleMs: settleMs) {
                freqs = r.freqs
                points = sharpenPeaks(r.points)
            }
            scanning = false
        }
    }

    // ───────────────── ① Icom ネイティブスコープ(CI-V 27 00) ─────────────────

    /// 連続スコープ開始。VFOを動かさないので受信音は途切れない。
    private func startNativeScope() {
        guard vm.sharedFreq > 0 else { return }
        scopeRunning = true
        let span = spanTotalHz
        Task { await vm.startNativeScope(spanHz: span) }
    }

    private func stopNativeScope() {
        guard scopeRunning else { return }
        scopeRunning = false
        Task { await vm.stopNativeScope() }
    }

    /// 稼働中に span を変更したときリグへ反映。
    private func applyNativeSpan() {
        let span = spanTotalHz
        Task { await vm.setNativeScopeSpan(span) }
    }

    /// 475点のレベル(0..1)を現在周波数±span/2の軸へ割り当て、既存描画のdBドメインへ写像。
    private func renderNativeSweep(_ levels: [Float]) {
        guard levels.count >= 2, vm.sharedFreq > 0 else { return }
        let n = levels.count
        let span = spanTotalHz
        let lo = vm.sharedFreq - span / 2
        freqs = (0..<n).map { lo + Int64((Double($0) * Double(span) / Double(n - 1)).rounded()) }
        // draw() は points を dB とみなし norm(-54..+40) する。0..1 を同レンジへ線形写像すれば
        // norm で元の 0..1 に戻り、棒の高さ・配色がそのまま反映される。
        points = (0..<n).map { dbFloor + Double(levels[$0]) * (dbCeil - dbFloor) }
    }

    /// ピーク先鋭化: ローカル最大(隣接より高いビン)のみ残し、裾のビンはフロアへ下げて
    /// 「1信号=1本」に近づける。平坦部(整数dBで同値)は右端を採用して二重表示を防ぐ。
    private func sharpenPeaks(_ p: [Double]) -> [Double] {
        let n = p.count
        guard n >= 3 else { return p }
        let floor = dbFloor   // norm=0 → 棒の高さ0
        return (0..<n).map { i in
            let left  = i > 0 ? p[i - 1] : -Double.infinity
            let right = i < n - 1 ? p[i + 1] : -Double.infinity
            return (p[i] >= left && p[i] > right) ? p[i] : floor
        }
    }
}

/// ① Icom ネイティブスコープの最新1掃引ぶんのレベル(0..1)を保持する観測可能モデル。
/// civRxThread から DispatchQueue.main 経由で更新され、BandScopeView が onChange で描画へ反映する。
@Observable final class NativeScopeModel {
    var levels: [Float] = []
}

/// バンドスコープのスポット重畳設定。POTA/SOTA の表示ON/OFFと、
/// 表示するプログラム(POTA)/アソシエーション(SOTA)の複数選択を行う。
/// 選択は CSV 文字列で保持(空=全件表示)。
struct ScopeSpotSettingsView: View {
    @Binding var showPota: Bool
    @Binding var showSota: Bool
    @Binding var potaProgsCSV: String
    @Binding var sotaAssocsCSV: String
    let availablePotaProgs: [String]
    let availableSotaAssocs: [String]
    let onReload: () -> Void
    @Environment(\.dismiss) private var dismiss

    private func selected(_ csv: String) -> Set<String> {
        Set(csv.split(separator: ",").map { String($0).trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty })
    }
    private func toggle(_ item: String, in csv: inout String) {
        var set = selected(csv)
        if set.contains(item) { set.remove(item) } else { set.insert(item) }
        csv = set.sorted().joined(separator: ",")
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("表示") {
                    Toggle("POTA を表示", isOn: $showPota)
                    Toggle("SOTA を表示", isOn: $showSota)
                }
                if showPota {
                    Section {
                        if availablePotaProgs.isEmpty {
                            Text("スポット取得後に選択できます").foregroundStyle(.secondary)
                        } else {
                            let sel = selected(potaProgsCSV)
                            ForEach(availablePotaProgs, id: \.self) { p in
                                Button {
                                    toggle(p, in: &potaProgsCSV)
                                } label: {
                                    HStack {
                                        Text(p)
                                        Spacer()
                                        if sel.contains(p) { Image(systemName: "checkmark").foregroundStyle(.tint) }
                                    }
                                }
                                .foregroundStyle(.primary)
                            }
                        }
                    } header: {
                        Text("POTA プログラム (未選択=全プログラム)")
                    }
                }
                if showSota {
                    Section {
                        if availableSotaAssocs.isEmpty {
                            Text("スポット取得後に選択できます").foregroundStyle(.secondary)
                        } else {
                            let sel = selected(sotaAssocsCSV)
                            ForEach(availableSotaAssocs, id: \.self) { a in
                                Button {
                                    toggle(a, in: &sotaAssocsCSV)
                                } label: {
                                    HStack {
                                        Text(a)
                                        Spacer()
                                        if sel.contains(a) { Image(systemName: "checkmark").foregroundStyle(.tint) }
                                    }
                                }
                                .foregroundStyle(.primary)
                            }
                        }
                    } header: {
                        Text("SOTA アソシエーション (未選択=全アソシエーション)")
                    }
                }
            }
            .navigationTitle("スポット重畳")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("再取得") { onReload() }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("完了") { dismiss() }
                }
            }
        }
    }
}
