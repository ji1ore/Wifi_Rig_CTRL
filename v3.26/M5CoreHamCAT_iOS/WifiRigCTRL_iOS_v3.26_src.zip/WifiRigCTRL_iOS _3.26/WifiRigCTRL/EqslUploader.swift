import Foundation

/// eQSL.cc への ADIF アップロード。送信済み状態は各QSOの eqslSent で管理。
/// ログ登録ごとの自動送信と、未送付の一括送信に対応。
enum EqslUploader {
    private static let endpoint = URL(string: "https://www.eqsl.cc/qslcard/ImportADIF.cfm")!
    private static let session: URLSession = {
        let c = URLSessionConfiguration.default
        c.timeoutIntervalForRequest = 15; c.timeoutIntervalForResource = 40
        return URLSession(configuration: c)
    }()

    static func hasCredentials(user: String, pass: String) -> Bool {
        !user.trimmingCharacters(in: .whitespaces).isEmpty && !pass.isEmpty
    }

    /// 1件送信。成功(=added>0 or Duplicate)で true。
    static func send(entry: QsoEntry, user: String, pass: String, nickname: String) async -> Bool {
        var adif = QsoStore.buildAdif([entry])
        var extra = ""
        if !entry.comment.isEmpty { extra += "<QSLMSG:\(entry.comment.utf8.count)>\(entry.comment) " }
        if !nickname.isEmpty { extra += "<APP_EQSL_QTH_NICKNAME:\(nickname.count)>\(nickname) " }
        if !extra.isEmpty { adif = adif.replacingOccurrences(of: "<EOR>", with: "\(extra)<EOR>") }

        let boundary = "----WifiRigCTRL\(UUID().uuidString)"
        var req = URLRequest(url: endpoint)
        req.httpMethod = "POST"
        req.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        var body = Data()
        func part(_ name: String, _ value: String) {
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"\(name)\"\r\n\r\n".data(using: .utf8)!)
            body.append("\(value)\r\n".data(using: .utf8)!)
        }
        part("EQSL_USER", user); part("EQSL_PSWD", pass)
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"Filename\"; filename=\"log.adi\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: application/octet-stream\r\n\r\n".data(using: .utf8)!)
        body.append(adif.data(using: .utf8)!)
        body.append("\r\n--\(boundary)--\r\n".data(using: .utf8)!)
        req.httpBody = body

        do {
            let (data, resp) = try await session.data(for: req)
            let text = String(data: data, encoding: .utf8) ?? ""
            let http = (resp as? HTTPURLResponse)?.statusCode ?? 0
            if text.lowercased().contains("error:") { return false }
            if text.contains("Duplicate") { return http == 200 }
            // "Result: X out of Y records added" の X>0 を成功とする
            if let m = text.range(of: "\\d+\\s+out of", options: .regularExpression),
               let x = Int(text[m].prefix(while: { $0.isNumber })) {
                return http == 200 && x > 0
            }
            return http == 200 && text.lowercased().contains("added")
        } catch { return false }
    }

    /// 未送付(eqslSent=false)を一括送信。(sent, failed) を返す。
    static func bulkSendUnsent(user: String, pass: String, nickname: String,
                               progress: ((Int, Int) -> Void)? = nil) async -> (Int, Int) {
        let unsent = QsoStore.load().filter { !$0.eqslSent }
        var sent = 0, failed = 0
        for (i, e) in unsent.enumerated() {
            if await send(entry: e, user: user, pass: pass, nickname: nickname) {
                QsoStore.markEqslSent(dt: e.dt, call: e.call, true); sent += 1
            } else { failed += 1 }
            progress?(i + 1, unsent.count)
        }
        return (sent, failed)
    }
}
