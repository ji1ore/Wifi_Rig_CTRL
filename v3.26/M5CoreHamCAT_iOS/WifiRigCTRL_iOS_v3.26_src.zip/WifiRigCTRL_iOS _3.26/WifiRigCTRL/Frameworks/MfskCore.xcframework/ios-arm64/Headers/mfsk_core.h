// C ABI for libmfsk_ios (mfsk-core FT8/FT4 decode + encode). Imported by Swift
// as `import MfskCore` via the MfskCore.xcframework module map.
#ifndef MFSK_CORE_H
#define MFSK_CORE_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

// Decode one slot of mono S16 PCM. `rate` may be 8000 (RS-BA1) or 12000; 8 kHz
// is resampled up internally. is_ft4: 0=FT8, 1=FT4. depth: 1=Fast 2=Normal 3=Deep.
// Returns a malloc'd, NUL-terminated C string of newline-separated JSON rows
// ({"freq":..,"snr":..,"dt":..,"msg":".."}), or NULL on error. Free with
// mfsk_string_free. An empty string means "decoded, zero messages".
char *mfsk_ft8_decode(const int16_t *samples, size_t len, int rate,
                      float fmin, float fmax, int is_ft4, int depth);
void mfsk_string_free(char *p);

// Encode a message to one full S16 slot (FT8 15 s centred / FT4 7.5 s at start)
// at `rate` Hz. Returns a malloc'd buffer of *out_len samples, or NULL. Free
// with mfsk_pcm_free (pass the same length back).
int16_t *mfsk_ft8_encode(const char *msg, float base_hz, int rate,
                         int is_ft4, size_t *out_len);
void mfsk_pcm_free(int16_t *p, size_t len);

#ifdef __cplusplus
}
#endif

#endif // MFSK_CORE_H
