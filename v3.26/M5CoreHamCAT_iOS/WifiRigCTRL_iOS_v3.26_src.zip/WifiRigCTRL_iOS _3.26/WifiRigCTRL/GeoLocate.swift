import Foundation
import CoreLocation
import Contacts

/// 一回限りの現在地取得 + 逆ジオコーディングで JCC/JGC とメモを求める共有ヘルパー。
/// (Android の GeoJcc.fetch / fetchLocation に相当。運用地追加と地図センタリングで使用)
/// コールバックはすべてメインスレッドで呼ばれる。
@MainActor
final class GeoLocate: NSObject, CLLocationManagerDelegate {
    private let manager = CLLocationManager()
    private var onInfo: ((String) -> Void)?
    private var onJcc: ((_ jcc: String, _ jgc: String, _ jccMemo: String, _ jgcMemo: String, _ info: String, _ gl: String) -> Void)?
    private var onLatLon: ((Double, Double) -> Void)?
    private var wantGeocode = false
    // 非同期リクエスト中に自身が解放されないよう保持する
    private static var live: Set<GeoLocate> = []

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
    }

    /// 現在地→逆ジオ→JCC/JGC とメモ(県+市 / 県+市区・郡町村)。
    func fetchJcc(onInfo: @escaping (String) -> Void,
                  onResult: @escaping (String, String, String, String, String, String) -> Void) {
        self.onInfo = onInfo; self.onJcc = onResult; self.wantGeocode = true
        GeoLocate.live.insert(self)
        request()
    }

    /// 現在地の緯度経度のみ(地図センタリング用)。
    func fetchLocation(onInfo: @escaping (String) -> Void,
                       onLatLon: @escaping (Double, Double) -> Void) {
        self.onInfo = onInfo; self.onLatLon = onLatLon; self.wantGeocode = false
        GeoLocate.live.insert(self)
        request()
    }

    private func request() {
        switch manager.authorizationStatus {
        case .notDetermined:
            manager.requestWhenInUseAuthorization()     // 許可ダイアログ → didChangeAuthorization で続行
        case .authorizedWhenInUse, .authorizedAlways:
            onInfo?("位置情報取得中…")
            manager.requestLocation()
        default:
            onInfo?("位置情報の許可が必要です(設定アプリで許可してください)")
            finish()
        }
    }

    nonisolated func locationManagerDidChangeAuthorization(_ m: CLLocationManager) {
        Task { @MainActor in
            switch self.manager.authorizationStatus {
            case .authorizedWhenInUse, .authorizedAlways:
                self.onInfo?("位置情報取得中…")
                self.manager.requestLocation()
            case .denied, .restricted:
                self.onInfo?("位置情報の許可が必要です(設定アプリで許可してください)")
                self.finish()
            default:
                break
            }
        }
    }

    nonisolated func locationManager(_ m: CLLocationManager, didUpdateLocations locs: [CLLocation]) {
        Task { @MainActor in
            guard let loc = locs.last else { self.onInfo?("位置情報が取得できませんでした"); self.finish(); return }
            if !self.wantGeocode {
                self.onLatLon?(loc.coordinate.latitude, loc.coordinate.longitude)
                self.finish()
                return
            }
            self.reverse(loc)
        }
    }

    nonisolated func locationManager(_ m: CLLocationManager, didFailWithError error: Error) {
        Task { @MainActor in
            self.onInfo?("位置情報取得エラー: \(error.localizedDescription)")
            self.finish()
        }
    }

    private func reverse(_ loc: CLLocation) {
        CLGeocoder().reverseGeocodeLocation(loc, preferredLocale: Locale(identifier: "ja_JP")) { pms, _ in
            Task { @MainActor in
                guard let pm = pms?.first else { self.onInfo?("住所が取得できませんでした"); self.finish(); return }
                let admin       = pm.administrativeArea    ?? ""
                let subAdmin    = pm.subAdministrativeArea ?? ""
                let locality    = pm.locality              ?? ""
                let subLocality = pm.subLocality           ?? ""
                var addressLine = ""
                if let pa = pm.postalAddress { addressLine = pa.state + pa.city + pa.subLocality + pa.street }
                if addressLine.isEmpty { addressLine = admin + subAdmin + locality + subLocality }

                let r = JccTable.resolve(admin: admin, subAdmin: subAdmin, locality: locality,
                                         subLocality: subLocality, addressLine: addressLine)
                let info: String
                switch (r.jcc.isEmpty, r.jgc.isEmpty) {
                case (false, false): info = "\(addressLine) → JCC:\(r.jcc) JGC:\(r.jgc)"
                case (false, true):  info = "\(addressLine) → JCC:\(r.jcc)"
                case (true, false):  info = "\(addressLine) → JGC:\(r.jgc)"
                case (true, true):   info = addressLine
                }
                let gl = GeoLocate.maidenhead(loc.coordinate.latitude, loc.coordinate.longitude)
                self.onJcc?(r.jcc, r.jgc, r.jccMemo, r.jgcMemo, info, gl)
                self.finish()
            }
        }
    }

    /// 緯度経度→Maidenhead グリッドロケーター(6桁)。
    static func maidenhead(_ lat: Double, _ lon: Double) -> String {
        let lonv = min(max(lon + 180.0, 0), 359.9999)
        let latv = min(max(lat + 90.0, 0), 179.9999)
        let c1 = Character(UnicodeScalar(65 + Int(lonv / 20))!)
        let c2 = Character(UnicodeScalar(65 + Int(latv / 10))!)
        let d1 = Int(lonv.truncatingRemainder(dividingBy: 20) / 2)
        let d2 = Int(latv.truncatingRemainder(dividingBy: 10))
        let e1 = Character(UnicodeScalar(65 + Int(lonv.truncatingRemainder(dividingBy: 2) / (2.0/24.0)))!)
        let e2 = Character(UnicodeScalar(65 + Int(latv.truncatingRemainder(dividingBy: 1) / (1.0/24.0)))!)
        return "\(c1)\(c2)\(d1)\(d2)\(e1)\(e2)"
    }

    private func finish() {
        onInfo = nil; onJcc = nil; onLatLon = nil
        GeoLocate.live.remove(self)
    }
}
