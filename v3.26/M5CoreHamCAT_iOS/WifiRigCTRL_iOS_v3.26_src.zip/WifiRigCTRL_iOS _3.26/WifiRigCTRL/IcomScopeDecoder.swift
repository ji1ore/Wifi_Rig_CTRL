import Foundation

/// Icom CI-V スコープ波形(コマンド 27 00)デコーダ。Android 版 IcomScopeDecoder.kt の移植。
///
/// 「① ネイティブスコープ」方式(受信音と両立する広帯域スコープ)の中核。リグ内蔵DSPが作った
/// スペクトラム波形を 27 00 で受け取り、1掃引ぶんのレベル配列(0...1)へ組み立てる。
/// VFOを動かさないので受信音は途切れない。
///
/// 27 00 フレーム body(FE FE [dst] [src] を除いた cmd 以降):
///   27 00 q w e r [t...] y [u...]
///     q=Main/Sub, w=分割現在番号(01..0B), e=分割総数(01=LAN一括/0B=USB11分割),
///     r=Center/Fixed, t=波形情報, y=範囲外フラグ, u=波形データ(0..160) 全475点
///
/// LAN(e=01): 1フレームに q..y + u(475点)。USB(e=0B): 分割1=q..y のみ、分割2..11=q w e + u チャンク。
/// 機種差の大きい t をバイト精度で解釈しなくても u は取れる(LANは末尾475、USBはチャンク連結)ため堅牢。
final class IcomScopeDecoder {

    static let wavePoints = 475          // IC-705/IC-7300/IC-9700 の波形点数
    private static let waveMax: Double = 160

    /// 1掃引完成時に呼ばれる。levels は 0...1 に正規化済み・長さ wavePoints。
    var onSweep: (([Float]) -> Void)?

    private var accum: [Int] = []
    private var expectDiv = 1

    /// 27 00 フレーム1件ぶんを渡す。body[0]=dst,[1]=src,[2]=0x27,[3]=0x00,[4]=q ...
    func feed(_ body: [Int]) {
        guard body.count >= 7, body[2] == 0x27, body[3] == 0x00 else { return }
        let cur = body[5]       // w
        let total = body[6]     // e

        if total <= 1 {
            // LAN 一括: u は末尾の wavePoints バイト。r,t,y の長さは機種で変わるので末尾から取る。
            let end = body.count
            if end - 7 < Self.wavePoints { return }   // 波形なし(範囲外等)
            let start = end - Self.wavePoints
            emit(Array(body[start..<end]))
            return
        }

        // USB 分割
        if cur <= 1 {
            accum.removeAll(keepingCapacity: true); expectDiv = 2; return
        }
        if cur != expectDiv {
            accum.removeAll(keepingCapacity: true); expectDiv = 1; return
        }
        if body.count > 7 { accum.append(contentsOf: body[7..<body.count]) }
        expectDiv += 1
        if cur >= total {
            if accum.count >= Self.wavePoints { emit(Array(accum[0..<Self.wavePoints])) }
            accum.removeAll(keepingCapacity: true); expectDiv = 1
        }
    }

    private func emit(_ points: [Int]) {
        let out = points.map { p -> Float in
            let v = min(max(p, 0), 160)
            return Float(Double(v) / Self.waveMax)
        }
        onSweep?(out)
    }

    func reset() { accum.removeAll(keepingCapacity: true); expectDiv = 1 }
}
