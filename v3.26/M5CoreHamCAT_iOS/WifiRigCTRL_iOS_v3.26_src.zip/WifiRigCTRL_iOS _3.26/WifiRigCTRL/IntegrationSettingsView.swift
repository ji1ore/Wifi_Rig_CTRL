import SwiftUI

/// eQSL / Smart HAMLOG(FT8アプリ連携=Cloudlog) の資格情報設定。
struct IntegrationSettingsView: View {
    @Bindable var vm: MainViewModel
    @Environment(\.dismiss) private var dismiss
    @State private var testResult = ""
    @State private var testing = false

    var body: some View {
        Form {
            Section("eQSL") {
                TextField("ユーザー名 (コールサイン)", text: $vm.eqslUser)
                    .textInputAutocapitalization(.characters).autocorrectionDisabled()
                SecureField("パスワード", text: $vm.eqslPassword)
                TextField("QTHニックネーム (任意)", text: $vm.eqslQthNickname)
                    .autocorrectionDisabled()
            }
            Section {
                TextField("サーバーアドレス", text: $vm.shlCloudlogUrl)
                    .textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                SecureField("APIキー", text: $vm.shlApiKey)
                TextField("Station ID (既定1)", text: $vm.shlStationId)
                    .keyboardType(.numberPad)
                Button {
                    testing = true; testResult = "接続中…"
                    let (u, k) = (vm.shlCloudlogUrl, vm.shlApiKey)
                    Task {
                        let r = await SmartHamLogSync.checkAuth(url: u, key: k)
                        await MainActor.run { testResult = r; testing = false }
                    }
                } label: { Label("Smart HAMLOG 接続テスト", systemImage: "antenna.radiowaves.left.and.right") }
                .disabled(testing)
                if !testResult.isEmpty {
                    Text(testResult).font(.caption)
                        .foregroundStyle(testResult.hasPrefix("Error") ? .red : .green)
                }
            } header: {
                Text("Smart HAMLOG (FT8アプリ連携 / Cloudlog)")
            } footer: {
                Text("Smart HAMLOG の [設定]→「FT8TW/Greyline連携」に表示されるサーバーアドレスとAPIキーを入力してください。")
            }
        }
        .navigationTitle("外部連携 設定")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) {
                Button("保存") { vm.persistIntegrationSettings(); dismiss() }
            }
        }
        .onDisappear { vm.persistIntegrationSettings() }
    }
}
