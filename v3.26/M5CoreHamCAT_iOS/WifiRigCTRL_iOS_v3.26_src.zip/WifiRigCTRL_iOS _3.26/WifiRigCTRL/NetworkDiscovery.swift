import Foundation

struct DiscoveredHost: Identifiable {
    let id = UUID()
    let ip: String
    let hostname: String
    let apiPort: Int
    let audioPort: Int
    var label: String { "\(hostname)  (\(ip))" }
}

/// Androidクライアントと同じUDPブロードキャストプロトコルでPiを検索する。
/// "WIFI_RIG_CTRL_DISCOVER" をUDP 5001番ポートにブロードキャストし、
/// "WIFI_RIG_CTRL_HERE:hostname:apiPort:audioPort" レスポンスを収集する。
func discoverWifiRigCtrlHosts() async -> [DiscoveredHost] {
    await withCheckedContinuation { continuation in
        DispatchQueue.global(qos: .userInitiated).async {
            continuation.resume(returning: _runDiscovery())
        }
    }
}

private func _runDiscovery(timeoutSec: Double = 2.5) -> [DiscoveredHost] {
    let udpPort: UInt16 = 5001
    let magic = "WIFI_RIG_CTRL_DISCOVER"
    var found: [DiscoveredHost] = []

    let sockfd = socket(AF_INET, SOCK_DGRAM, 0)
    guard sockfd >= 0 else { return [] }
    defer { close(sockfd) }

    // ブロードキャスト有効化
    var on: Int32 = 1
    setsockopt(sockfd, SOL_SOCKET, SO_BROADCAST, &on, socklen_t(MemoryLayout<Int32>.size))
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR,  &on, socklen_t(MemoryLayout<Int32>.size))

    // INADDR_ANY:0 に明示 bind → 受信用のローカルポートを確定させる
    var local = sockaddr_in()
    local.sin_len    = UInt8(MemoryLayout<sockaddr_in>.size)
    local.sin_family = sa_family_t(AF_INET)
    local.sin_port   = 0   // OS が空きポートを割り当て
    local.sin_addr.s_addr = 0  // INADDR_ANY
    _ = withUnsafePointer(to: &local) {
        $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
            bind(sockfd, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
        }
    }

    // ノンブロッキングモードに設定（SO_RCVTIMEO が iOS で効かない場合の対策）
    let fl = fcntl(sockfd, F_GETFL, 0)
    if fl >= 0 { _ = fcntl(sockfd, F_SETFL, fl | O_NONBLOCK) }

    // 送信先リスト
    // 1. 255.255.255.255（限定ブロードキャスト）
    // 2. 各 NIC のサブネットブロードキャスト（Android と同様）
    // 3. 各 NIC のサブネット内全ホストへのユニキャスト（フォールバック）
    //    iOS では UDP ブロードキャスト送信に com.apple.developer.networking.multicast
    //    エンタイトルメントが必要で、無い場合 sendto が黙って失敗する。ユニキャストは
    //    ローカルネットワーク権限だけで送れるため、CI-V 検索と同じ掃引を併用する。
    var targets: [sockaddr_in] = [_makeSockAddrIn(ip: UInt32.max, port: udpPort)]
    _collectIfBroadcasts(port: udpPort, into: &targets)
    let broadcastCount = targets.count
    _collectSubnetUnicasts(port: udpPort, into: &targets)

    // 全ターゲットへ送信。ブロードキャスト分は失敗理由をログに残す
    // （ユニキャスト分は 254 件あるので失敗は件数だけ集計する）。
    var unicastFailures = 0
    magic.withCString { cstr in
        let len = strlen(cstr)
        for (idx, var dest) in targets.enumerated() {
            let sent = withUnsafePointer(to: &dest) {
                $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                    sendto(sockfd, cstr, len, 0, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
                }
            }
            guard sent < 0 else { continue }
            if idx < broadcastCount {
                let err = errno
                print("[Discovery] broadcast sendto \(_ipString(dest)) failed: errno=\(err) (\(String(cString: strerror(err))))")
            } else {
                unicastFailures += 1
            }
        }
    }
    if unicastFailures > 0 {
        print("[Discovery] unicast sendto failed for \(unicastFailures)/\(targets.count - broadcastCount) hosts")
    }

    // 受信ループ（デッドラインまで 20ms ポーリング）
    var buf    = [UInt8](repeating: 0, count: 512)
    var src    = sockaddr_in()
    var srcLen = socklen_t(MemoryLayout<sockaddr_in>.size)
    let deadline = Date().addingTimeInterval(timeoutSec)

    while Date() < deadline {
        srcLen = socklen_t(MemoryLayout<sockaddr_in>.size)
        let n = buf.withUnsafeMutableBufferPointer { bp in
            withUnsafeMutablePointer(to: &src) { sp in
                sp.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                    recvfrom(sockfd, bp.baseAddress, bp.count - 1, 0, $0, &srcLen)
                }
            }
        }
        if n <= 0 {
            // ノンブロッキングなので EAGAIN は正常（データなし）
            usleep(20_000)  // 20ms 待って再試行
            continue
        }

        let msg = String(bytes: buf[0..<n], encoding: .utf8) ?? ""
        guard msg.hasPrefix("WIFI_RIG_CTRL_HERE:") else { continue }

        let payload = String(msg.dropFirst("WIFI_RIG_CTRL_HERE:".count))
        let parts   = payload.split(separator: ":", omittingEmptySubsequences: false).map(String.init)
        let hostname  = parts.first ?? "unknown"
        let apiPort   = parts.count > 1 ? Int(parts[1]) ?? 8000 : 8000
        let audioPort = parts.count > 2 ? Int(parts[2]) ?? 8000 : 8000

        var ipBuf = [CChar](repeating: 0, count: Int(INET_ADDRSTRLEN))
        let ip: String = withUnsafePointer(to: src.sin_addr) {
            guard inet_ntop(AF_INET, $0, &ipBuf, socklen_t(INET_ADDRSTRLEN)) != nil else { return "" }
            return String(cString: ipBuf)
        }
        guard !ip.isEmpty, !found.contains(where: { $0.ip == ip }) else { continue }
        found.append(DiscoveredHost(ip: ip, hostname: hostname,
                                    apiPort: apiPort, audioPort: audioPort))
    }

    if found.isEmpty {
        print("[Discovery] no WIFI_RIG_CTRL_HERE reply within \(timeoutSec)s (sent to \(targets.count) targets)")
    }
    return found
}

// MARK: - CI-V RS-BA1 Discovery (AreYouThere → IAmHere)

struct DiscoveredCivHost: Identifiable {
    let id = UUID()
    let ip: String
}

/// RS-BA1 AYT (type=0x03) をサブネット全体に送り IAmHere (type=0x04) 応答で IC-705 を探す。
func discoverCivHosts(port: UInt16 = 50001) async -> [DiscoveredCivHost] {
    await withCheckedContinuation { continuation in
        DispatchQueue.global(qos: .userInitiated).async {
            continuation.resume(returning: _runCivDiscovery(port: port))
        }
    }
}

private func _runCivDiscovery(port: UInt16 = 50001, timeoutSec: Double = 3.0) -> [DiscoveredCivHost] {
    var found: [DiscoveredCivHost] = []

    let sockfd = socket(AF_INET, SOCK_DGRAM, 0)
    guard sockfd >= 0 else { return [] }
    defer { Darwin.close(sockfd) }

    var on: Int32 = 1
    setsockopt(sockfd, SOL_SOCKET, SO_BROADCAST, &on, socklen_t(MemoryLayout<Int32>.size))
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR,  &on, socklen_t(MemoryLayout<Int32>.size))

    var local = sockaddr_in()
    local.sin_len    = UInt8(MemoryLayout<sockaddr_in>.size)
    local.sin_family = sa_family_t(AF_INET)
    local.sin_port   = 0; local.sin_addr.s_addr = 0
    _ = withUnsafePointer(to: &local) {
        $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
            bind(sockfd, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
        }
    }
    let fl = fcntl(sockfd, F_GETFL, 0)
    if fl >= 0 { _ = fcntl(sockfd, F_SETFL, fl | O_NONBLOCK) }

    // AYT packet: 16 bytes, type=0x03 (RS-BA1 AreYouThere)
    let myId = UInt32.random(in: 1..<UInt32.max)
    var ayt = [UInt8](repeating: 0, count: 16)
    ayt[0] = 0x10                                   // length LE32 = 16
    ayt[4] = 0x03                                   // type LE16 = AreYouThere
    ayt[8]  = UInt8(myId & 0xFF)
    ayt[9]  = UInt8((myId >> 8) & 0xFF)
    ayt[10] = UInt8((myId >> 16) & 0xFF)
    ayt[11] = UInt8((myId >> 24) & 0xFF)

    // ブロードキャスト + サブネット全ユニキャストへ送信
    var targets: [sockaddr_in] = [_makeSockAddrIn(ip: UInt32.max, port: port)]
    _collectIfBroadcasts(port: port, into: &targets)
    _collectSubnetUnicasts(port: port, into: &targets)
    ayt.withUnsafeBufferPointer { buf in
        for var dest in targets {
            _ = withUnsafePointer(to: &dest) {
                $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                    sendto(sockfd, buf.baseAddress, buf.count, 0, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
                }
            }
        }
    }

    // IAmHere 応答を収集 (type=0x04, 16 bytes)
    var buf = [UInt8](repeating: 0, count: 64)
    var src = sockaddr_in(); var srcLen = socklen_t(MemoryLayout<sockaddr_in>.size)
    let deadline = Date().addingTimeInterval(timeoutSec)
    while Date() < deadline {
        srcLen = socklen_t(MemoryLayout<sockaddr_in>.size)
        let n = buf.withUnsafeMutableBufferPointer { bp in
            withUnsafeMutablePointer(to: &src) { sp in
                sp.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                    recvfrom(sockfd, bp.baseAddress, bp.count, 0, $0, &srcLen)
                }
            }
        }
        if n <= 0 { usleep(20_000); continue }
        guard n == 16, buf[4] == 0x04, buf[5] == 0x00 else { continue }
        var ipBuf = [CChar](repeating: 0, count: Int(INET_ADDRSTRLEN))
        let ip: String = withUnsafePointer(to: src.sin_addr) {
            guard inet_ntop(AF_INET, $0, &ipBuf, socklen_t(INET_ADDRSTRLEN)) != nil else { return "" }
            return String(cString: ipBuf)
        }
        if !ip.isEmpty, !found.contains(where: { $0.ip == ip }) {
            found.append(DiscoveredCivHost(ip: ip))
        }
    }
    return found
}

private func _collectSubnetUnicasts(port: UInt16, into targets: inout [sockaddr_in]) {
    var ifap: UnsafeMutablePointer<ifaddrs>?
    guard getifaddrs(&ifap) == 0, let head = ifap else { return }
    defer { freeifaddrs(head) }
    var cur: UnsafeMutablePointer<ifaddrs>? = head
    while let iface = cur {
        defer { cur = iface.pointee.ifa_next }
        let flags = iface.pointee.ifa_flags
        guard flags & UInt32(IFF_UP) != 0, flags & UInt32(IFF_LOOPBACK) == 0,
              let addrPtr = iface.pointee.ifa_addr,
              addrPtr.pointee.sa_family == sa_family_t(AF_INET) else { continue }
        var ipBuf = [CChar](repeating: 0, count: Int(INET_ADDRSTRLEN))
        let ipStr: String = addrPtr.withMemoryRebound(to: sockaddr_in.self, capacity: 1) { sin in
            guard inet_ntop(AF_INET, &sin.pointee.sin_addr, &ipBuf, socklen_t(INET_ADDRSTRLEN)) != nil else { return "" }
            return String(cString: ipBuf)
        }
        guard !ipStr.isEmpty else { continue }
        let parts = ipStr.split(separator: ".").compactMap { Int($0) }
        guard parts.count == 4 else { continue }
        for i in 1...254 {
            if i == parts[3] { continue }
            let targetIP = "\(parts[0]).\(parts[1]).\(parts[2]).\(i)"
            let inetAddr = inet_addr(targetIP)
            guard inetAddr != INADDR_NONE else { continue }
            var addr = sockaddr_in()
            addr.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
            addr.sin_family = sa_family_t(AF_INET)
            addr.sin_port = port.bigEndian
            addr.sin_addr.s_addr = inetAddr
            targets.append(addr)
        }
    }
}

// MARK: - Helpers

/// sockaddr_in の IPv4 アドレスを "a.b.c.d" 文字列にする（ログ用）。
private func _ipString(_ addr: sockaddr_in) -> String {
    var copy = addr.sin_addr
    var buf = [CChar](repeating: 0, count: Int(INET_ADDRSTRLEN))
    guard inet_ntop(AF_INET, &copy, &buf, socklen_t(INET_ADDRSTRLEN)) != nil else { return "?" }
    return String(cString: buf)
}

private func _makeSockAddrIn(ip: UInt32, port: UInt16) -> sockaddr_in {
    var addr = sockaddr_in()
    addr.sin_len    = UInt8(MemoryLayout<sockaddr_in>.size)
    addr.sin_family = sa_family_t(AF_INET)
    addr.sin_port   = port.bigEndian
    addr.sin_addr.s_addr = ip  // 255.255.255.255 はバイトオーダー不変
    return addr
}

/// getifaddrs で各 NIC のブロードキャストアドレスを収集する（Android の実装と同等）。
/// ifa_broadaddr は Swift から直接アクセスできない場合があるため、
/// IP アドレスとネットマスクからブロードキャストを計算する。
private func _collectIfBroadcasts(port: UInt16, into targets: inout [sockaddr_in]) {
    var ifap: UnsafeMutablePointer<ifaddrs>?
    guard getifaddrs(&ifap) == 0, let head = ifap else { return }
    defer { freeifaddrs(head) }

    var cur: UnsafeMutablePointer<ifaddrs>? = head
    while let iface = cur {
        defer { cur = iface.pointee.ifa_next }
        let flags = iface.pointee.ifa_flags
        // UP かつ ループバックでなく ブロードキャスト対応のインターフェースのみ
        guard flags & UInt32(IFF_UP)        != 0,
              flags & UInt32(IFF_LOOPBACK)  == 0,
              flags & UInt32(IFF_BROADCAST) != 0,
              let addrPtr = iface.pointee.ifa_addr,
              addrPtr.pointee.sa_family == sa_family_t(AF_INET),
              let maskPtr = iface.pointee.ifa_netmask,
              maskPtr.pointee.sa_family == sa_family_t(AF_INET)
        else { continue }

        // sin_addr.s_addr はネットワークバイトオーダーのまま演算して OK
        let ifIP: UInt32 = addrPtr.withMemoryRebound(to: sockaddr_in.self, capacity: 1) {
            $0.pointee.sin_addr.s_addr
        }
        let mask: UInt32 = maskPtr.withMemoryRebound(to: sockaddr_in.self, capacity: 1) {
            $0.pointee.sin_addr.s_addr
        }
        // broadcast = (ip & mask) | ~mask
        let bcastIP = (ifIP & mask) | (~mask)

        var addr = sockaddr_in()
        addr.sin_len    = UInt8(MemoryLayout<sockaddr_in>.size)
        addr.sin_family = sa_family_t(AF_INET)
        addr.sin_port   = port.bigEndian
        addr.sin_addr.s_addr = bcastIP

        if !targets.contains(where: { $0.sin_addr.s_addr == bcastIP }) {
            targets.append(addr)
        }
    }
}
