import SwiftUI

/// 現時点で有効な運用地(POTA/SOTA/JCC/JGC)をチェック式で表示・選択する横並びバー。
/// メイン画面・FT8・RTTY・CWTX 画面で共通利用。チェック状態は vm.opSessionDeselected に反映され、
/// ログ登録時の自動タグ付けに引き継がれる。有効な運用地が無いときは何も表示しない。
struct OpLocBar: View {
    let vm: MainViewModel

    var body: some View {
        let active = vm.activeSessionsAt(Int64(Date().timeIntervalSince1970 * 1000))
        if !active.isEmpty {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    Text("運用地:").font(.caption).foregroundStyle(.secondary)
                    ForEach(active) { s in
                        let on = !vm.opSessionDeselected.contains(s.id)
                        Button {
                            vm.setOpSessionSelected(s.id, !on)
                        } label: {
                            HStack(spacing: 3) {
                                Image(systemName: on ? "checkmark.square.fill" : "square")
                                Text("\(s.type) \(s.ref)").font(.caption)
                            }
                            .foregroundStyle(on ? Color.green : Color.gray)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 6)
            }
        }
    }
}
