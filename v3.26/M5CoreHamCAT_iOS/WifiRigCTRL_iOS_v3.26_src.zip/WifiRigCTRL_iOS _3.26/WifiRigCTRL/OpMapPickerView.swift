import SwiftUI
import MapKit
import CoreLocation

/// 地図上の運用地候補 (POTA公園 / SOTAサミット)。
struct GeoRefItem: Identifiable, Hashable {
    let id = UUID()
    let ref: String
    let name: String
    let lat: Double
    let lon: Double
    var coordinate: CLLocationCoordinate2D { .init(latitude: lat, longitude: lon) }
    static func == (a: GeoRefItem, b: GeoRefItem) -> Bool { a.id == b.id }
    func hash(into hasher: inout Hasher) { hasher.combine(id) }
}

/// POTA/SOTA の公式CSV(全エンティティ, 座標付き)を取得・7日キャッシュし、指定座標周辺を抽出。
/// (Android の GeoJcc.fetchNearby に相当)
enum OpEntityLoader {
    static func fetchNearby(type: String, lat: Double, lon: Double,
                            completion: @escaping ([GeoRefItem], String) -> Void) {
        let urlStr = type == "POTA"
            ? "https://pota.app/all_parks_ext.csv"
            : "https://www.sotadata.org.uk/summitslist.csv"
        guard let url = URL(string: urlStr) else { completion([], "URL不正"); return }
        let fm = FileManager.default
        let cacheDir = fm.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        let cacheFile = cacheDir.appendingPathComponent(type == "POTA" ? "pota_parks.csv" : "sota_summits.csv")

        var fresh = false
        if let attr = try? fm.attributesOfItem(atPath: cacheFile.path),
           let size = attr[.size] as? Int, size > 0,
           let mdate = attr[.modificationDate] as? Date {
            fresh = Date().timeIntervalSince(mdate) < 7 * 24 * 3600
        }

        func parseAndReturn() {
            DispatchQueue.global(qos: .userInitiated).async {
                let list = parseCsvNearby(cacheFile, lat: lat, lon: lon)
                let dbg = list.isEmpty ? "CSV 近傍0件 (\(urlStr))" : ""
                DispatchQueue.main.async { completion(list, dbg) }
            }
        }

        if fresh {
            parseAndReturn()
            return
        }
        var req = URLRequest(url: url)
        req.setValue("WifiRigCTRL", forHTTPHeaderField: "User-Agent")
        req.timeoutInterval = 120
        URLSession.shared.downloadTask(with: req) { tmp, resp, err in
            guard let tmp = tmp,
                  (resp as? HTTPURLResponse).map({ (200..<300).contains($0.statusCode) }) ?? true else {
                DispatchQueue.main.async { completion([], "取得失敗: \(err?.localizedDescription ?? "HTTPエラー")") }
                return
            }
            try? fm.removeItem(at: cacheFile)
            do { try fm.moveItem(at: tmp, to: cacheFile) }
            catch { DispatchQueue.main.async { completion([], "保存失敗: \(error.localizedDescription)") }; return }
            parseAndReturn()
        }.resume()
    }

    private static func splitCsv(_ line: String) -> [String] {
        var res: [String] = []; var sb = ""; var q = false
        for c in line {
            if c == "\"" { q.toggle() }
            else if c == "," && !q { res.append(sb); sb = "" }
            else { sb.append(c) }
        }
        res.append(sb); return res
    }

    private static func parseCsvNearby(_ f: URL, lat: Double, lon: Double) -> [GeoRefItem] {
        guard let content = try? String(contentsOf: f, encoding: .utf8) else { return [] }
        var out: [GeoRefItem] = []
        var ri = -1, ni = -1, lai = -1, loi = -1, ai = -1
        var headerFound = false
        content.enumerateLines { line, stop in
            let cols = splitCsv(line)
            if !headerFound {
                let lower = cols.map { $0.trimmingCharacters(in: .whitespaces).lowercased() }
                if lower.contains(where: { $0.contains("lat") }) &&
                   lower.contains(where: { $0.contains("lon") || $0.contains("lng") }) {
                    ri = lower.firstIndex(where: { $0.contains("reference") || $0 == "summitcode" || $0 == "ref" || $0.contains("code") }) ?? -1
                    ni = lower.firstIndex(where: { $0 == "name" || $0.contains("summitname") || $0.contains("title") }) ?? -1
                    lai = lower.firstIndex(where: { $0.contains("lat") }) ?? -1
                    loi = lower.firstIndex(where: { $0.contains("lon") || $0.contains("lng") }) ?? -1
                    ai  = lower.firstIndex(where: { $0 == "active" }) ?? -1   // POTA: 1=active/0=inactive
                    headerFound = true
                }
                return
            }
            if ri < 0 || lai < 0 || loi < 0 { return }
            if cols.count <= max(ri, max(lai, loi)) { return }
            // POTA の inactive(active=0)公園は除外(SOTA等 active列が無いCSVはそのまま)
            if ai >= 0 && ai < cols.count {
                let act = cols[ai].trimmingCharacters(in: .whitespaces).lowercased()
                if act == "0" || act == "false" || act == "n" { return }
            }
            guard let la = Double(cols[lai].trimmingCharacters(in: .whitespaces)),
                  let lo = Double(cols[loi].trimmingCharacters(in: .whitespaces)) else { return }
            if abs(la - lat) < 0.3 && abs(lo - lon) < 0.35 {
                let ref = cols[ri].trimmingCharacters(in: .whitespaces)
                let name = (ni >= 0 && ni < cols.count) ? cols[ni].trimmingCharacters(in: .whitespaces) : ""
                if !ref.isEmpty {
                    out.append(GeoRefItem(ref: ref, name: name, lat: la, lon: lo))
                    if out.count >= 300 { stop = true }
                }
            }
        }
        return out
    }
}

/// POTA/SOTA を地図から選択。現在地にセンタリング→周辺エンティティをピン表示。
/// ピンをタップで情報表示→「この運用地を選択」。地図を動かして「この範囲で再検索」可。
struct OpMapPickerView: View {
    let type: String                      // "POTA" or "SOTA"
    let onPick: (String, String) -> Void  // (ref, name)
    @Environment(\.dismiss) private var dismiss

    @State private var camera: MapCameraPosition =
        .region(MKCoordinateRegion(center: .init(latitude: 35.68, longitude: 139.76),
                                    span: .init(latitudeDelta: 0.3, longitudeDelta: 0.3)))
    @State private var center = CLLocationCoordinate2D(latitude: 35.68, longitude: 139.76)
    @State private var refs: [GeoRefItem] = []
    @State private var selected: GeoRefItem? = nil
    @State private var info = "現在地を取得中…"
    @State private var loading = false
    @State private var didInit = false

    var body: some View {
        NavigationStack {
            ZStack(alignment: .bottom) {
                Map(position: $camera) {
                    UserAnnotation()
                    ForEach(refs) { r in
                        // タップで選択 → 下部に情報カードを表示。Map の selection バインドは
                        // Marker だとタップが拾えないことがあるため、Annotation + Button で明示的に。
                        Annotation(r.ref, coordinate: r.coordinate) {
                            Button {
                                selected = r
                            } label: {
                                // POTA=緑 / SOTA=赤。選択中は塗りつぶしアイコンで区別。
                                Image(systemName: selected?.id == r.id ? "mappin.circle.fill" : "mappin.circle")
                                    .font(.title)
                                    .foregroundStyle(type == "POTA" ? Color.green : Color.red)
                                    .background(Circle().fill(.white).padding(4))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                .onMapCameraChange { ctx in center = ctx.region.center }
                .ignoresSafeArea(edges: .bottom)

                VStack(spacing: 8) {
                    if !info.isEmpty {
                        Text(info).font(.caption).padding(6)
                            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 8))
                    }
                    Button {
                        loadFor(center)
                    } label: {
                        Label(loading ? "検索中…" : "この地図範囲で再検索", systemImage: "arrow.clockwise")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(loading)

                    if let s = selected {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("\(s.ref)").font(.headline)
                            if !s.name.isEmpty { Text(s.name).font(.subheadline).foregroundStyle(.secondary) }
                            Button {
                                onPick(s.ref, s.name)
                                dismiss()
                            } label: { Label("この運用地を選択", systemImage: "checkmark.circle.fill").frame(maxWidth: .infinity) }
                            .buttonStyle(.borderedProminent)
                            .tint(.green)
                        }
                        .padding(10)
                        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12))
                    }
                }
                .padding()
            }
            .navigationTitle("\(type) を地図から選択")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("閉じる") { dismiss() } } }
            .onAppear {
                guard !didInit else { return }
                didInit = true
                GeoLocate().fetchLocation(onInfo: { info = $0 }) { la, lo in
                    center = .init(latitude: la, longitude: lo)
                    camera = .region(MKCoordinateRegion(center: center,
                                                        span: .init(latitudeDelta: 0.3, longitudeDelta: 0.3)))
                    loadFor(center)
                }
            }
        }
    }

    private func loadFor(_ c: CLLocationCoordinate2D) {
        loading = true
        info = "\(type) エンティティを検索中…（初回はCSV取得に時間がかかります）"
        OpEntityLoader.fetchNearby(type: type, lat: c.latitude, lon: c.longitude) { list, dbg in
            loading = false
            refs = list
            selected = nil
            info = list.isEmpty
                ? "周辺に\(type)が見つかりません。\(dbg)"
                : "\(list.count)件見つかりました。ピンをタップして選択"
        }
    }
}
