import Foundation

/// 運用セッション(POTA/SOTAアクティベーター運用地)。Android版 OpSession と同仕様。
/// JCC/JGC/SOTA は時間重複不可、POTA は重複可。endMs==0 は運用中(終了未確定)。
nonisolated struct OpSession: Codable, Identifiable, Equatable {
    let id: String
    let type: String        // "JCC" | "JGC" | "SOTA" | "POTA"
    let ref: String         // JCC/JGCコード, SOTA(JA/XX-000), POTA(JA-0000)
    let startMs: Int64       // epoch millis
    let endMs: Int64         // epoch millis, 0 = 運用中
    var label: String = ""
    var gl: String? = nil    // この運用地の自局GL(Optionalなので旧データも復号可)

    func activeAt(_ t: Int64) -> Bool { t >= startMs && (endMs == 0 || t <= endMs) }

    /// JCC/JGC/SOTA は相互に時間重複不可。POTA は重複可。
    var isExclusive: Bool { type == "JCC" || type == "JGC" || type == "SOTA" }

    func overlaps(_ o: OpSession) -> Bool {
        let aEnd = endMs == 0 ? Int64.max : endMs
        let bEnd = o.endMs == 0 ? Int64.max : o.endMs
        return startMs <= bEnd && o.startMs <= aEnd
    }

    static let types = ["JCC", "JGC", "SOTA", "POTA"]
    /// 並び順ランク: JCC → JGC → POTA → SOTA
    static func rank(_ t: String) -> Int { ["JCC": 0, "JGC": 1, "POTA": 2, "SOTA": 3][t] ?? 4 }
}

/// UserDefaults への JSON 保存。
enum OpSessionStore {
    private static let key = "opSessions"
    static func load() -> [OpSession] {
        guard let d = UserDefaults.standard.data(forKey: key) else { return [] }
        return (try? JSONDecoder().decode([OpSession].self, from: d)) ?? []
    }
    static func save(_ list: [OpSession]) {
        if let d = try? JSONEncoder().encode(list) { UserDefaults.standard.set(d, forKey: key) }
    }
}
