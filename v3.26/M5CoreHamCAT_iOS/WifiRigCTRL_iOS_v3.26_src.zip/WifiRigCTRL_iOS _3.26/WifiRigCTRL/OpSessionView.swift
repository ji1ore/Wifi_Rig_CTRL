import SwiftUI

/// 運用地(POTA/SOTAアクティベーター運用セッション)の一覧・追加/編集/削除。
struct OpSessionView: View {
    @Bindable var vm: MainViewModel
    @Environment(\.dismiss) private var dismiss
    @State private var editing: OpSession? = nil
    @State private var showEdit = false

    private func fmt(_ ms: Int64) -> String {
        if ms == 0 { return "運用中" }
        let f = DateFormatter(); f.dateFormat = "MM/dd HH:mm"
        return f.string(from: Date(timeIntervalSince1970: Double(ms) / 1000.0))
    }

    var body: some View {
        NavigationStack {
            List {
                if vm.opSessions.isEmpty {
                    Text("運用地が未登録です。右上の + で追加してください。").foregroundStyle(.secondary)
                }
                ForEach(vm.opSessions) { s in
                    Button { editing = s; showEdit = true } label: {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("\(s.type)  \(s.ref)").font(.headline)
                            Text("\(fmt(s.startMs)) 〜 \(fmt(s.endMs))" + (s.label.isEmpty ? "" : "  (\(s.label))"))
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
                .onDelete { idx in idx.map { vm.opSessions[$0].id }.forEach { vm.deleteOpSession($0) } }
            }
            .navigationTitle("運用地 (POTA/SOTA)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("閉じる") { dismiss() } }
                ToolbarItem(placement: .primaryAction) {
                    Button { editing = nil; showEdit = true } label: { Image(systemName: "plus") }
                }
            }
            .sheet(isPresented: $showEdit) { OpSessionEditView(vm: vm, existing: editing) }
        }
    }
}

/// 運用地の追加/編集フォーム。重複/時間重複は vm.addOpSession がエラー文字列で弾く。
struct OpSessionEditView: View {
    @Bindable var vm: MainViewModel
    let existing: OpSession?
    @Environment(\.dismiss) private var dismiss
    @State private var type: String
    @State private var ref: String
    @State private var startMs: Int64        // epoch millis
    @State private var ongoing: Bool
    @State private var endMs: Int64          // epoch millis (ongoing時は未使用)
    @State private var inputLocal = true     // true=ローカル / false=UTC で日時入力
    @State private var label: String
    @State private var gl: String
    @State private var error: String? = nil
    // GPS (JCC/JGC)
    @State private var gpsInfo: String = ""
    @State private var pendingGeo: (jcc: String, jgc: String, jccMemo: String, jgcMemo: String)? = nil
    @State private var showGeoChoice = false
    // 地図選択 (POTA/SOTA)
    @State private var showMap = false

    init(vm: MainViewModel, existing: OpSession?) {
        self.vm = vm; self.existing = existing
        let nowMs = Int64(Date().timeIntervalSince1970 * 1000)
        _type = State(initialValue: existing?.type ?? "POTA")
        _ref = State(initialValue: existing?.ref ?? "")
        _startMs = State(initialValue: existing?.startMs ?? nowMs)
        _ongoing = State(initialValue: (existing?.endMs ?? 0) == 0)
        _endMs = State(initialValue: (existing?.endMs == 0 || existing?.endMs == nil) ? nowMs : existing!.endMs)
        _label = State(initialValue: existing?.label ?? "")
        _gl = State(initialValue: existing?.gl ?? "")
    }

    var body: some View {
        NavigationStack {
            Form {
                Picker("種別", selection: $type) { ForEach(OpSession.types, id: \.self) { Text($0).tag($0) } }
                TextField("ref (POTA: JA-0000 / SOTA: JA/XX-000 / JCC/JGC)", text: $ref)
                    .textInputAutocapitalization(.characters).autocorrectionDisabled()

                if type == "JCC" || type == "JGC" {
                    Button {
                        gpsInfo = "位置情報取得中…"
                        GeoLocate().fetchJcc(onInfo: { gpsInfo = $0 }) { jcc, jgc, jccMemo, jgcMemo, info, gpsGl in
                            gpsInfo = info
                            if !gpsGl.isEmpty { gl = gpsGl }   // JCC/JGCと一緒にGLも取得
                            pendingGeo = (jcc, jgc, jccMemo, jgcMemo)
                            if !jcc.isEmpty && !jgc.isEmpty {
                                showGeoChoice = true            // 両方あれば選ばせる
                            } else if !jcc.isEmpty {
                                applyGeo(isJcc: true)
                            } else if !jgc.isEmpty {
                                applyGeo(isJcc: false)
                            }
                        }
                    } label: { Label("GPSから取得 (JCC/JGC自動判定)", systemImage: "location.fill") }
                }
                if type == "POTA" || type == "SOTA" {
                    Button {
                        showMap = true
                    } label: { Label("地図から選択 (\(type))", systemImage: "map.fill") }
                }
                if !gpsInfo.isEmpty {
                    Text(gpsInfo).font(.caption).foregroundStyle(.green)
                }

                Toggle("ローカルタイムで入力 (OFFでUTC)", isOn: $inputLocal)
                DatePicker("開始", selection: startBinding)
                Toggle("運用中(終了未確定)", isOn: $ongoing)
                if !ongoing { DatePicker("終了", selection: endBinding) }
                TextField("メモ(任意)", text: $label)
                TextField("自局GL (例: PM95) ※ログのMY GLに使用", text: $gl)
                    .textInputAutocapitalization(.characters).autocorrectionDisabled()
                if let e = error { Text(e).foregroundStyle(.red).font(.caption) }
            }
            .navigationTitle(existing == nil ? "運用地を追加" : "運用地を編集")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("キャンセル") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("保存") { save() } }
            }
            .confirmationDialog("JCC と JGC が見つかりました。どちらを登録しますか？",
                                isPresented: $showGeoChoice, titleVisibility: .visible) {
                if let g = pendingGeo {
                    Button("JCC \(g.jcc)  (\(g.jccMemo))") { applyGeo(isJcc: true) }
                    Button("JGC \(g.jgc)  (\(g.jgcMemo))") { applyGeo(isJcc: false) }
                    Button("キャンセル", role: .cancel) { }
                }
            }
            .sheet(isPresented: $showMap) {
                OpMapPickerView(type: type) { pickedRef, pickedName in
                    ref = pickedRef
                    label = pickedName
                    showMap = false
                }
            }
        }
    }

    // DatePicker は端末ローカル時刻でしか編集できないため、UTC入力時は壁時計の数字を
    // そのままUTCとして解釈し直す(JSTなどDSTなしでは一定オフセット)。保存値は常に絶対エポック。
    private var startBinding: Binding<Date> {
        Binding(get: { dateFromMs(startMs) }, set: { startMs = msFromDate($0) })
    }
    private var endBinding: Binding<Date> {
        Binding(get: { dateFromMs(endMs) }, set: { endMs = msFromDate($0) })
    }
    private func dateFromMs(_ ms: Int64) -> Date {
        let base = Double(ms) / 1000.0
        if inputLocal { return Date(timeIntervalSince1970: base) }
        let off = Double(TimeZone.current.secondsFromGMT(for: Date(timeIntervalSince1970: base)))
        return Date(timeIntervalSince1970: base - off)   // ローカル表示がUTC壁時計になるよう補正
    }
    private func msFromDate(_ d: Date) -> Int64 {
        if inputLocal { return Int64(d.timeIntervalSince1970 * 1000) }
        let off = Double(TimeZone.current.secondsFromGMT(for: d))
        return Int64((d.timeIntervalSince1970 + off) * 1000)
    }

    /// GPS結果を種別に合わせて適用: type/ref/メモ(label) をセット。
    private func applyGeo(isJcc: Bool) {
        guard let g = pendingGeo else { return }
        type = isJcc ? "JCC" : "JGC"
        ref = isJcc ? g.jcc : g.jgc
        label = isJcc ? g.jccMemo : g.jgcMemo
    }

    private func save() {
        let r = ref.trimmingCharacters(in: .whitespaces).uppercased()
        if r.isEmpty { error = "refを入力してください"; return }
        let finalEnd = ongoing ? 0 : endMs
        if !ongoing && finalEnd < startMs { error = "終了が開始より前です"; return }
        let glUp = gl.trimmingCharacters(in: .whitespaces).uppercased()
        let s = OpSession(id: existing?.id ?? UUID().uuidString, type: type, ref: r,
                          startMs: startMs, endMs: finalEnd,
                          label: label.trimmingCharacters(in: .whitespaces),
                          gl: glUp)
        if let err = vm.addOpSession(s) { error = err } else {
            // 登録GL: 6桁(フル)は myGrid6(ログMy GL用)へ、先頭4桁は ft8MyGrid(FT8用)へ
            if glUp.count >= 4 {
                vm.myGrid6 = glUp
                vm.ft8MyGrid = String(glUp.prefix(4))
                UserDefaults.standard.set(vm.ft8MyGrid, forKey: "ft8MyGrid")
            }
            dismiss()
        }
    }
}
