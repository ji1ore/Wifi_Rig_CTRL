import Foundation
import CoreLocation

// UTC yyyyMMddHHmmss → ローカルタイム "MM/dd HH:mm"
func utcToLocal(_ dt: String) -> String {
    guard dt.count >= 8 else { return "" }
    let fmt = DateFormatter()
    fmt.dateFormat = "yyyyMMddHHmmss"
    fmt.timeZone = TimeZone(identifier: "UTC")
    let padded = String((dt + "00000000000000").prefix(14))
    guard let date = fmt.date(from: padded) else { return "" }
    let local = DateFormatter()
    local.dateFormat = "MM/dd HH:mm"
    local.timeZone = TimeZone.current
    return local.string(from: date)
}

struct QsoEntry: Identifiable, Codable {
    var id: UUID = UUID()
    var dt: String          // yyyyMMddHHmmss UTC
    var call: String
    var freq: Int64
    var mode: String
    var rstS: String
    var rstR: String
    var grid: String
    var myCall: String
    var myGrid: String
    var yourPota: String = ""
    var yourSota: String = ""
    var myPota: String   = ""
    var mySota: String   = ""
    var jcc: String      = ""
    var jgc: String      = ""
    var comment: String  = ""
    var lat: Double      = 0.0
    var lon: Double      = 0.0
    var eqslSent: Bool   = false   // eQSL.cc へ送信済み
    var shlSent: Bool    = false   // Smart HAMLOG へ連携済み
    var qsl: String      = ""      // QSL状態(空白/JARL=J/hQSL=H/No=N/Card=C/1-Way=1)
    var qth: String      = ""      // 相手局QTH(HAMLOG QTH欄へ)
    var myLoc: String    = ""      // 自局運用場所(My Parkマルチロケ等。ADIF MY_CITY)
    var name: String     = ""      // 相手局オペレーター名(QRA。ADIF NAME)

    static func utcNow() -> String {
        let fmt = DateFormatter()
        fmt.dateFormat = "yyyyMMddHHmmss"
        fmt.timeZone = TimeZone(identifier: "UTC")
        return fmt.string(from: Date())
    }

    func toDict() -> [String: Any] {
        var d: [String: Any] = [
            "dt": dt, "call": call, "freq": freq, "mode": mode,
            "rstS": rstS, "rstR": rstR, "grid": grid,
            "myCall": myCall, "myGrid": myGrid
        ]
        if !yourPota.isEmpty { d["yourPota"] = yourPota }
        if !yourSota.isEmpty { d["yourSota"] = yourSota }
        if !myPota.isEmpty   { d["myPota"]   = myPota }
        if !mySota.isEmpty   { d["mySota"]   = mySota }
        if !jcc.isEmpty      { d["jcc"]      = jcc }
        if !jgc.isEmpty      { d["jgc"]      = jgc }
        if !comment.isEmpty  { d["comment"]  = comment }
        if lat != 0.0        { d["lat"]      = lat }
        if lon != 0.0        { d["lon"]      = lon }
        if eqslSent          { d["eqslSent"] = true }
        if shlSent           { d["shlSent"]  = true }
        if !qsl.isEmpty      { d["qsl"]      = qsl }
        if !qth.isEmpty      { d["qth"]      = qth }
        if !myLoc.isEmpty    { d["myLoc"]    = myLoc }
        if !name.isEmpty     { d["name"]     = name }
        return d
    }

    static func fromDict(_ d: [String: Any]) -> QsoEntry {
        // "pota"/"sota" keys from older data map to yourPota/yourSota
        let legacyPota = d["pota"] as? String ?? ""
        let legacySota = d["sota"] as? String ?? ""
        return QsoEntry(
            dt:       d["dt"]      as? String ?? "",
            call:     d["call"]    as? String ?? "",
            freq:     Int64(d["freq"] as? Int ?? 0),
            mode:     d["mode"]    as? String ?? "FT8",
            rstS:     d["rstS"]    as? String ?? "",
            rstR:     d["rstR"]    as? String ?? "",
            grid:     d["grid"]    as? String ?? "",
            myCall:   d["myCall"]  as? String ?? "",
            myGrid:   d["myGrid"]  as? String ?? "",
            yourPota: (d["yourPota"] as? String ?? legacyPota),
            yourSota: (d["yourSota"] as? String ?? legacySota),
            myPota:   d["myPota"]   as? String ?? "",
            mySota:   d["mySota"]   as? String ?? "",
            jcc:      d["jcc"]      as? String ?? "",
            jgc:      d["jgc"]      as? String ?? "",
            comment:  d["comment"]  as? String ?? "",
            lat:      d["lat"]      as? Double ?? 0.0,
            lon:      d["lon"]      as? Double ?? 0.0,
            eqslSent: d["eqslSent"] as? Bool ?? false,
            shlSent:  d["shlSent"]  as? Bool ?? false,
            qsl:      d["qsl"]      as? String ?? "",
            qth:      d["qth"]      as? String ?? "",
            myLoc:    d["myLoc"]    as? String ?? "",
            name:     d["name"]     as? String ?? ""
        )
    }
}

enum QsoStore {
    private static let key = "ft8QsoLog"

    static func load() -> [QsoEntry] {
        guard let str = UserDefaults.standard.string(forKey: key),
              let arr = try? JSONSerialization.jsonObject(with: Data(str.utf8)) as? [[String: Any]]
        else { return [] }
        return arr.map { QsoEntry.fromDict($0) }
    }

    static func save(_ entries: [QsoEntry]) {
        let arr = entries.map { $0.toDict() }
        if let data = try? JSONSerialization.data(withJSONObject: arr),
           let str = String(data: data, encoding: .utf8) {
            UserDefaults.standard.set(str, forKey: key)
        }
    }

    static func append(_ entry: QsoEntry) {
        var list = load()
        list.append(entry)
        save(list)
    }

    /// dt+call 一致エントリの eqslSent を更新して保存。
    static func markEqslSent(dt: String, call: String, _ sent: Bool = true) {
        var list = load(); var changed = false
        for i in list.indices where list[i].dt == dt && list[i].call == call && list[i].eqslSent != sent {
            list[i].eqslSent = sent; changed = true
        }
        if changed { save(list) }
    }

    /// dt+call 一致エントリの shlSent を更新して保存。
    static func markShlSent(dt: String, call: String, _ sent: Bool = true) {
        var list = load(); var changed = false
        for i in list.indices where list[i].dt == dt && list[i].call == call && list[i].shlSent != sent {
            list[i].shlSent = sent; changed = true
        }
        if changed { save(list) }
    }

    static func jsonString() -> String {
        UserDefaults.standard.string(forKey: key) ?? "[]"
    }

    static func setFromJsonString(_ s: String) {
        UserDefaults.standard.set(s, forKey: key)
    }

    /// FT8/FT4 の RST は "R-19" のように先頭に Roger の "R" が付くことがある。
    /// ログ(ADIF/HAMLOG)の RST としては数値部のみが正しいので先頭の R を除去する。
    static func normRst(_ s: String) -> String {
        let t = s.trimmingCharacters(in: .whitespaces)
        if let r = t.range(of: "^R+(?=[+-]?\\d)", options: .regularExpression) {
            return String(t[r.upperBound...])
        }
        return t
    }

    static func buildAdif(_ entries: [QsoEntry]) -> String {
        func f(_ tag: String, _ v: String) -> String {
            v.isEmpty ? "" : "<\(tag):\(v.utf8.count)>\(v) "
        }
        var adif = "ADIF Export from Wifi_RIG_CTRL\n<EOH>\n\n"
        for e in entries {
            let freq = e.freq > 0 ? String(format: "%.4f", Double(e.freq) / 1_000_000.0) : ""
            adif += f("CALL", e.call) + f("MODE", e.mode) + f("BAND", freqToBand(e.freq))
            adif += f("FREQ", freq)
            adif += f("QSO_DATE", String(e.dt.prefix(8)))
            adif += f("TIME_ON", String(e.dt.dropFirst(8).prefix(6)))
            adif += f("RST_SENT", normRst(e.rstS)) + f("RST_RCVD", normRst(e.rstR))
            adif += f("GRIDSQUARE", e.grid)
            adif += f("NAME", e.name)
            adif += f("QTH", e.qth)
            adif += f("OPERATOR", e.myCall) + f("MY_GRIDSQUARE", e.myGrid)
            if e.lat != 0.0 { adif += f("MY_LAT", String(format: "%.6f", e.lat)) }
            if e.lon != 0.0 { adif += f("MY_LON", String(format: "%.6f", e.lon)) }
            adif += f("POTA_REF", e.yourPota) + f("SOTA_REF", e.yourSota)
            adif += f("MY_POTA_REF", e.myPota) + f("MY_SOTA_REF", e.mySota)
            // Smart Ham Log(Turbo HAMLOG)は POTA_REF/SOTA_REF を専用欄に取り込まず Remarks へ
            // 落としてしまう。POTA/SOTA を相手/自局の該当欄へ入れるため、広く認識される
            // SIG/SIG_INFO(相手)・MY_SIG/MY_SIG_INFO(自局)でも併記する。
            // SIG は1レコードに1つのため POTA 優先・無ければ SOTA(POTA/SOTA同時は稀)。
            if !e.yourPota.isEmpty { adif += f("SIG", "POTA") + f("SIG_INFO", e.yourPota) }
            else if !e.yourSota.isEmpty { adif += f("SIG", "SOTA") + f("SIG_INFO", e.yourSota) }
            if !e.myPota.isEmpty { adif += f("MY_SIG", "POTA") + f("MY_SIG_INFO", e.myPota) }
            else if !e.mySota.isEmpty { adif += f("MY_SIG", "SOTA") + f("MY_SIG_INFO", e.mySota) }
            adif += f("MY_CITY", e.myLoc)
            adif += f("COMMENT", e.comment)
            adif += f("QSL_SENT", e.qsl)
            adif += "<EOR>\n"
        }
        return adif
    }

    static func freqToBand(_ hz: Int64) -> String {
        switch hz {
        case 1_800_000..<2_000_000:   return "160M"
        case 3_500_000..<4_000_000:   return "80M"
        case 7_000_000..<7_300_000:   return "40M"
        case 10_100_000..<10_150_000: return "30M"
        case 14_000_000..<14_350_000: return "20M"
        case 18_068_000..<18_168_000: return "17M"
        case 21_000_000..<21_450_000: return "15M"
        case 24_890_000..<24_990_000: return "12M"
        case 28_000_000..<29_700_000: return "10M"
        case 50_000_000..<54_000_000: return "6M"
        case 144_000_000..<148_000_000: return "2M"
        case 420_000_000..<450_000_000: return "70CM"
        default: return ""
        }
    }

    // MARK: - SOTA chaser CSV (v3.20)

    /// SOTAData のチェイサー用アップロード画面
    static let sotaChaserUploadUrl = URL(string: "https://www.sotadata.org.uk/en/upload/chaser/csv")!

    struct SotaChaserCsv {
        let csv: String
        let included: Int
        let skippedNoRef: Int      // 相手局の SOTA 番号なし
        let skippedActivator: Int  // 自局 SOTA 番号あり(アクティベーター交信)
        let skippedInvalid: Int    // 自局コール・日時・周波数の不足
    }

    /// SOTA CSV V2 形式のチェイサーログを作る。
    /// 1行 = V2,自局コール,(空欄),dd/MM/yyyy,HHmm,周波数MHz,モード,相手局コール,相手の山岳番号
    static func buildSotaChaserCsv(_ entries: [QsoEntry]) -> SotaChaserCsv {
        var lines: [String] = []
        var noRef = 0, activator = 0, invalid = 0
        for e in entries.sorted(by: { $0.dt < $1.dt }) {
            let ref = e.yourSota.trimmingCharacters(in: .whitespaces).uppercased()
            if ref.isEmpty { noRef += 1; continue }
            let myCall = e.myCall.trimmingCharacters(in: .whitespaces).uppercased()
            let call = e.call.trimmingCharacters(in: .whitespaces).uppercased()
            guard !myCall.isEmpty, !call.isEmpty, e.dt.count >= 12, e.freq > 0 else {
                invalid += 1; continue
            }
            // S2S: 自局サミット(mySota)があれば3列目(MySummit)に入れる(除外しない)。純チェイスは空。
            let mySummit = e.mySota.trimmingCharacters(in: .whitespaces).uppercased()
            let d = Array(e.dt)
            let date = "\(String(d[6...7]))/\(String(d[4...5]))/\(String(d[0...3]))"
            let time = String(d[8...11])
            let fields = ["V2", myCall, mySummit, date, time, sotaFreq(e.freq), sotaMode(e.mode), call, ref]
            lines.append(fields.map { $0.replacingOccurrences(of: ",", with: " ") }.joined(separator: ","))
        }
        let csv = lines.isEmpty ? "" : lines.joined(separator: "\r\n") + "\r\n"
        return SotaChaserCsv(csv: csv, included: lines.count, skippedNoRef: noRef,
                             skippedActivator: activator, skippedInvalid: invalid)
    }

    /// 14063500 Hz → "14.0635MHz"
    static func sotaFreq(_ hz: Int64) -> String {
        var s = String(format: "%.4f", Double(hz) / 1_000_000.0)
        while s.hasSuffix("0") { s.removeLast() }
        if s.hasSuffix(".") { s.removeLast() }
        return s + "MHz"
    }

    /// アプリのモード名を SOTA のモード(CW / SSB / FM / AM / Data / DV / Other)に変換
    static func sotaMode(_ mode: String) -> String {
        let m = mode.uppercased()
        if m.hasPrefix("CW") { return "CW" }
        if m == "USB" || m == "LSB" || m.hasPrefix("SSB") { return "SSB" }
        if m.hasPrefix("FM") || m == "WFM" { return "FM" }
        if m.hasPrefix("AM") { return "AM" }
        if ["C4FM", "DV", "D-STAR", "DSTAR", "DMR"].contains(m) { return "DV" }
        if ["FT8", "FT4", "RTTY", "PSK31", "PKT", "JT65", "JS8", "OLIVIA"].contains(m)
            || m.hasPrefix("PKT") || m.hasPrefix("DATA") || m.hasPrefix("RTTY") { return "Data" }
        return "Other"
    }
}
