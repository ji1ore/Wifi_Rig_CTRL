import Foundation
import AVFoundation

/// RTTY 受信音(SSEのaudioイベントで届く base64 PCM, S16LE mono)をスマホで再生する小さなプレーヤ。
/// Pi の共有キャプチャ(_mgr_sub)由来の PCM をそのまま流し込む。モニタ音声(:50000)は RTTY では使わない。
/// 標準的な AVAudioEngine + PlayerNode。Int16 → Float32 に変換してスケジュールする。
final class RttyAudioPlayer {
    private let engine = AVAudioEngine()
    private let player = AVAudioPlayerNode()
    private var fmt: AVAudioFormat?
    private var started = false
    private var rate = 12000

    func start(rate: Int) {
        guard !started else { return }
        self.rate = rate
        // 出力セッションを確保(RTTY中はモニタ音声を使わないので競合しない)
        do {
            let s = AVAudioSession.sharedInstance()
            try s.setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try s.setActive(true)
        } catch {
            print("[RttyAudio] session error: \(error)")
        }
        guard let f = AVAudioFormat(standardFormatWithSampleRate: Double(rate), channels: 1) else { return }
        fmt = f
        engine.attach(player)
        engine.connect(player, to: engine.mainMixerNode, format: f)
        do {
            try engine.start()
            player.play()
            started = true
            print("[RttyAudio] started @\(rate)Hz")
        } catch {
            print("[RttyAudio] engine start error: \(error)")
        }
    }

    /// S16LE mono PCM を再生キューへ。rate が変わったら作り直す。
    func feed(_ data: Data, rate: Int) {
        if !started || rate != self.rate { stop(); start(rate: rate) }
        guard started, let f = fmt, data.count >= 2 else { return }
        let frames = data.count / 2
        guard let buf = AVAudioPCMBuffer(pcmFormat: f, frameCapacity: AVAudioFrameCount(frames)) else { return }
        buf.frameLength = AVAudioFrameCount(frames)
        guard let dst = buf.floatChannelData?[0] else { return }
        data.withUnsafeBytes { raw in
            let src = raw.bindMemory(to: Int16.self)
            let n = min(frames, src.count)
            for i in 0..<n { dst[i] = Float(src[i]) / 32768.0 }
        }
        player.scheduleBuffer(buf, completionHandler: nil)
    }

    func stop() {
        guard started else { return }
        player.stop()
        engine.stop()
        engine.detach(player)
        started = false
    }
}
