import Foundation

/// Smart HAMLOG 連携(FT8アプリ連携 = Cloudlog API)。
/// Smart HAMLOG の[設定]→「FT8TW/Greyline連携」のサーバーアドレス＋APIキーを使い、
/// POST <base>/api/qso に ADIF を送る。重複チェック・.hdb反映は Smart HAMLOG が行う(アプリは.hdbを触らない)。
enum SmartHamLogSync {
    private static let session: URLSession = {
        let c = URLSessionConfiguration.default
        c.timeoutIntervalForRequest = 15; c.timeoutIntervalForResource = 40
        return URLSession(configuration: c)
    }()

    static func hasServer(url: String, key: String) -> Bool {
        !url.trimmingCharacters(in: .whitespaces).isEmpty && !key.trimmingCharacters(in: .whitespaces).isEmpty
    }

    // 貼られた値が末尾にパスを含んでいても正規化してベースURLを得る
    private static func baseUrl(_ raw: String) -> String {
        var u = raw.trimmingCharacters(in: .whitespaces)
        while u.hasSuffix("/") { u.removeLast() }
        for s in ["/index.php/api/qso", "/api/qso", "/api/auth", "/index.php"] where u.hasSuffix(s) {
            u = String(u.dropLast(s.count)); while u.hasSuffix("/") { u.removeLast() }
        }
        return u
    }

    private static func qsoEndpoint(_ raw: String) -> URL? { URL(string: baseUrl(raw) + "/api/qso") }

    private static func recordOnly(_ adif: String) -> String {
        if let r = adif.range(of: "<EOH>") {
            let after = adif[r.upperBound...]
            if let nl = after.firstIndex(of: "\n") {
                return String(after[after.index(after: nl)...]).trimmingCharacters(in: .whitespacesAndNewlines)
            }
        }
        return adif.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    /// 接続テスト: GET <base>/api/auth/<key> で確認。成功時 "接続OK: ..."、失敗 "Error: ..."。
    static func checkAuth(url: String, key: String) async -> String {
        guard !url.isEmpty, !key.isEmpty else { return "Error: サーバー/APIキー未設定" }
        let enc = key.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? key
        guard let u = URL(string: baseUrl(url) + "/api/auth/" + enc) else { return "Error: URL不正" }
        do {
            let (data, resp) = try await session.data(from: u)
            let text = String(data: data, encoding: .utf8) ?? ""
            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            let msg = text.range(of: "<message>(.*?)</message>", options: .regularExpression)
                .map { String(text[$0]).replacingOccurrences(of: "<message>", with: "").replacingOccurrences(of: "</message>", with: "") }
                ?? String(text.prefix(120))
            if code == 404 { return "Error: 404 (エンドポイント不明)\n呼出先: \(u.absoluteString)" }
            if text.contains("Valid") && !text.contains("Invalid") { return "接続OK: \(msg)" }
            return "Error: \(msg)"
        } catch { return "Error: \(error.localizedDescription)" }
    }

    /// 1件送信。成功で true。
    static func send(entry: QsoEntry, url: String, key: String, stationId: String) async -> Bool {
        guard let endpoint = qsoEndpoint(url) else { return false }
        let payload: [String: Any] = [
            "key": key,
            "station_profile_id": stationId.isEmpty ? "1" : stationId,
            "type": "adif",
            "string": recordOnly(QsoStore.buildAdif([entry]))
        ]
        guard let body = try? JSONSerialization.data(withJSONObject: payload) else { return false }
        var req = URLRequest(url: endpoint)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = body
        do {
            let (data, resp) = try await session.data(for: req)
            let text = (String(data: data, encoding: .utf8) ?? "").lowercased()
            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            let bad = ["failed", "error", "too long", "invalid", "missing", "authentication"].contains { text.contains($0) }
            return (200..<300).contains(code) && !bad
        } catch { return false }
    }

    /// 未連携(shlSent=false)を一括送信。(sent, failed)。
    static func bulkSend(url: String, key: String, stationId: String,
                         progress: ((Int, Int) -> Void)? = nil) async -> (Int, Int) {
        let unsent = QsoStore.load().filter { !$0.shlSent }
        var sent = 0, failed = 0
        for (i, e) in unsent.enumerated() {
            if await send(entry: e, url: url, key: key, stationId: stationId) {
                QsoStore.markShlSent(dt: e.dt, call: e.call, true); sent += 1
            } else { failed += 1 }
            progress?(i + 1, unsent.count)
        }
        return (sent, failed)
    }
}
