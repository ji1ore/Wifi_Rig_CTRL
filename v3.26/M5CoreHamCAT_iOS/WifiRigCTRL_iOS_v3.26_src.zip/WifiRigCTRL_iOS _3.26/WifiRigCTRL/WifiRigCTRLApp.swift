//
//  WifiRigCTRLApp.swift
//  WifiRigCTRL
//
//  Created by 上野次郎 on 2026/05/31.
//

import SwiftUI

@main
struct WifiRigCTRLApp: App {
    @Environment(\.scenePhase) private var scenePhase

    init() {
        // 再インストール直後(設定が空)かつ iCloud 利用可能なら、ViewModel が UserDefaults を
        // 読む前にバックアップから復元する。
        _ = BackupStore.restoreIfFresh()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .onChange(of: scenePhase) { _, phase in
            // バックグラウンド遷移時に設定/ログを iCloud へ自動保存。
            if phase == .background { _ = BackupStore.save() }
        }
    }
}
