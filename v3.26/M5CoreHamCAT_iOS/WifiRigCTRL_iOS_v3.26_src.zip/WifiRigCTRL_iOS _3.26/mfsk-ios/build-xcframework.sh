#!/bin/bash
# Build MfskCore.xcframework (libmfsk_ios + C header) for iOS device + simulator.
# Run from the mfsk-ios crate dir. Requires rustup targets:
#   rustup target add aarch64-apple-ios aarch64-apple-ios-sim x86_64-apple-ios
# The simulator slice is a fat lib (arm64 + x86_64) so it links on both Apple
# Silicon and Intel simulators.
set -euo pipefail
cd "$(dirname "$0")"

OUT="../WifiRigCTRL/Frameworks"
mkdir -p "$OUT"
rm -rf "$OUT/MfskCore.xcframework"

cargo build --release --target aarch64-apple-ios
cargo build --release --target aarch64-apple-ios-sim
cargo build --release --target x86_64-apple-ios

# Combine the two simulator architectures into one fat static lib.
mkdir -p target/sim-universal
lipo -create \
  target/aarch64-apple-ios-sim/release/libmfsk_ios.a \
  target/x86_64-apple-ios/release/libmfsk_ios.a \
  -output target/sim-universal/libmfsk_ios.a

xcodebuild -create-xcframework \
  -library target/aarch64-apple-ios/release/libmfsk_ios.a -headers include \
  -library target/sim-universal/libmfsk_ios.a            -headers include \
  -output "$OUT/MfskCore.xcframework"

echo "built: $OUT/MfskCore.xcframework"
