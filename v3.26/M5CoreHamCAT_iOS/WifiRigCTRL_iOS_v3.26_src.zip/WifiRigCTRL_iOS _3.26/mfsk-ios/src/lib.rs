// SPDX-License-Identifier: GPL-3.0-only
//
// C ABI over mfsk-core (github.com/jl1nie/mfsk-core) for the iOS native FT8
// engine. Mirrors the Android mfsk-jni decode contract and adds encode, so the
// Swift side can do CI-V local FT8/FT4 RX+TX without the Pi/WebFT8.
//
//   // decode: newline-separated JSON rows, caller frees with mfsk_string_free.
//   char*    mfsk_ft8_decode(const int16_t* samples, size_t len, int rate,
//                            float fmin, float fmax, int is_ft4, int depth);
//   void     mfsk_string_free(char* p);
//   // encode: S16 PCM for one slot, caller frees with mfsk_pcm_free.
//   int16_t* mfsk_ft8_encode(const char* msg, float base_hz, int rate,
//                            int is_ft4, size_t* out_len);
//   void     mfsk_pcm_free(int16_t* p, size_t len);
//
// Each decode row: {"freq":1234.5,"snr":-5.0,"dt":0.15,"msg":"CQ JF9KKE QN02"}
//
// mfsk-core decodes at 12 kHz only; RS-BA1 audio (8 kHz) is resampled up before
// decode. The synthesiser takes a sample_rate, so encode runs at the caller's
// rate (8 kHz RS-BA1 / 12 kHz) without resampling. depth: 1=Fast 2=Normal 3=Deep.

use std::ffi::CString;
use std::os::raw::{c_char, c_int};
use std::panic::catch_unwind;

use mfsk_core::decoder::{DecodeParams, Decoder, Depth, SlotInput};
use mfsk_core::engine::tx::{message_to_tones, synthesize_i16};
use mfsk_core::ft4::Ft4;
use mfsk_core::ft8::Ft8;
use mfsk_core::msg::decoded::Decoded;
use mfsk_core::msg::wsjt77::{pack77, pack77_free_text};

const MFSK_DECODE_RATE: u32 = 12_000;

// ── decode ──────────────────────────────────────────────────────────────────

#[no_mangle]
pub extern "C" fn mfsk_ft8_decode(
    samples: *const i16,
    len: usize,
    rate: c_int,
    fmin: f32,
    fmax: f32,
    is_ft4: c_int,
    depth: c_int,
) -> *mut c_char {
    // catch_unwind: a panic must never unwind across the C ABI (UB). Return NULL instead.
    catch_unwind(|| {
        if samples.is_null() || len == 0 {
            return empty_cstring();
        }
        let input = unsafe { std::slice::from_raw_parts(samples, len) };
        let audio = if rate == MFSK_DECODE_RATE as c_int {
            input.to_vec()
        } else {
            resample(input, rate.max(1) as u32, MFSK_DECODE_RATE)
        };
        let d = match depth {
            1 => Depth::Fast,
            3 => Depth::Deep,
            _ => Depth::Normal,
        };
        let slot = SlotInput::i16(&audio);
        let band = (fmin, fmax);
        let lines: Vec<String> = if is_ft4 != 0 {
            let mut dec = Decoder::<Ft4>::new(DecodeParams::for_band(band).depth(d));
            dec.decode(&slot).rows.iter().map(|r| row_json(&r.decoded)).collect()
        } else {
            let mut dec = Decoder::<Ft8>::new(DecodeParams::for_band(band).depth(d));
            dec.decode(&slot).rows.iter().map(|r| row_json(&r.decoded)).collect()
        };
        CString::new(lines.join("\n"))
            .map(|c| c.into_raw())
            .unwrap_or(std::ptr::null_mut())
    })
    .unwrap_or(std::ptr::null_mut())
}

#[no_mangle]
pub extern "C" fn mfsk_string_free(p: *mut c_char) {
    if !p.is_null() {
        unsafe { drop(CString::from_raw(p)) };
    }
}

fn row_json(d: &Decoded) -> String {
    let esc = d
        .text
        .replace('\\', "\\\\")
        .replace('"', "\\\"")
        .replace('\n', "\\n")
        .replace('\r', "\\r");
    format!(
        "{{\"freq\":{:.1},\"snr\":{:.1},\"dt\":{:.2},\"msg\":\"{}\"}}",
        d.freq_hz, d.snr_db, d.dt_sec, esc
    )
}

fn empty_cstring() -> *mut c_char {
    CString::new("").map(|c| c.into_raw()).unwrap_or(std::ptr::null_mut())
}

// ── encode ──────────────────────────────────────────────────────────────────

#[no_mangle]
pub extern "C" fn mfsk_ft8_encode(
    msg: *const c_char,
    base_hz: f32,
    rate: c_int,
    is_ft4: c_int,
    out_len: *mut usize,
) -> *mut i16 {
    catch_unwind(|| {
        if msg.is_null() || out_len.is_null() {
            return std::ptr::null_mut();
        }
        let text = match unsafe { std::ffi::CStr::from_ptr(msg) }.to_str() {
            Ok(s) => s,
            Err(_) => return std::ptr::null_mut(),
        };
        let pcm = match encode_slot(text, base_hz, rate.max(1) as u32, is_ft4 != 0) {
            Some(p) => p,
            None => return std::ptr::null_mut(),
        };
        let mut v = pcm;
        v.shrink_to_fit(); // ensure capacity == len so mfsk_pcm_free can reconstruct
        let n = v.len();
        let ptr = v.as_mut_ptr();
        std::mem::forget(v);
        unsafe { *out_len = n };
        ptr
    })
    .unwrap_or(std::ptr::null_mut())
}

#[no_mangle]
pub extern "C" fn mfsk_pcm_free(p: *mut i16, len: usize) {
    if !p.is_null() && len > 0 {
        unsafe { drop(Vec::from_raw_parts(p, len, len)) };
    }
}

fn encode_slot(msg: &str, base_hz: f32, rate: u32, is_ft4: bool) -> Option<Vec<i16>> {
    let parts: Vec<&str> = msg.split_whitespace().collect();
    let msg77 = if parts.len() == 3 {
        pack77(parts[0], parts[1], parts[2]).or_else(|| pack77_free_text(msg))?
    } else {
        pack77_free_text(msg)?
    };
    const AMP: i16 = 32767;
    if is_ft4 {
        let tones = message_to_tones::<Ft4>(&msg77);
        let frame = synthesize_i16::<Ft4>(&tones, rate, base_hz, AMP);
        Some(place_in_slot(&frame, rate, 7.5, false))
    } else {
        let tones = message_to_tones::<Ft8>(&msg77);
        let frame = synthesize_i16::<Ft8>(&tones, rate, base_hz, AMP);
        Some(place_in_slot(&frame, rate, 15.0, true))
    }
}

fn place_in_slot(frame: &[i16], rate: u32, slot_s: f32, center: bool) -> Vec<i16> {
    let total = (slot_s * rate as f32).round() as usize;
    let mut buf = vec![0i16; total.max(frame.len())];
    let start = if center && buf.len() > frame.len() {
        (buf.len() - frame.len()) / 2
    } else {
        0
    };
    for (i, &s) in frame.iter().enumerate() {
        if start + i < buf.len() {
            buf[start + i] = s;
        }
    }
    buf
}

// ── resample (linear, matches Android mfsk-jni) ──────────────────────────────

fn resample(input: &[i16], from_hz: u32, to_hz: u32) -> Vec<i16> {
    if input.is_empty() || from_hz == to_hz {
        return input.to_vec();
    }
    let out_len = (input.len() as u64 * to_hz as u64 / from_hz as u64) as usize;
    let mut out = Vec::with_capacity(out_len);
    let step = from_hz as f64 / to_hz as f64;
    for i in 0..out_len {
        let pos = i as f64 * step;
        let idx = pos.floor() as usize;
        let frac = pos - idx as f64;
        let a = input[idx.min(input.len() - 1)] as f64;
        let b = input[(idx + 1).min(input.len() - 1)] as f64;
        out.push((a + (b - a) * frac).round() as i16);
    }
    out
}
