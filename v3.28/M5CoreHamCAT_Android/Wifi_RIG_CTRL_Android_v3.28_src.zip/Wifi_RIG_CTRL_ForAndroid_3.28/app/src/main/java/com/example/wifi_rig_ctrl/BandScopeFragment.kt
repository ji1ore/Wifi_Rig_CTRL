package com.ji1ore.wifi_rig_ctrl
import com.ji1ore.wifi_rig_ctrl.ui.theme.ThemeApply
import com.ji1ore.wifi_rig_ctrl.ui.theme.UiTheme

import android.Manifest
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.ji1ore.wifi_rig_ctrl.data.SAMPLING_RATES
import com.ji1ore.wifi_rig_ctrl.data.SCREEN_TIMEOUT_OPTIONS
import com.ji1ore.wifi_rig_ctrl.data.STEP_LIST
import com.ji1ore.wifi_rig_ctrl.databinding.FragmentBandScopeBinding
import com.ji1ore.wifi_rig_ctrl.viewmodel.MainViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * バンドスコープ画面(単発スキャン方式)。
 * 現在周波数を中心に、選択した「総スパン幅(周波数)」を api(/radio/scope/sweep) で1回だけ掃引し、
 * [BandScopeView] に表示する。SCAN で1回掃引、SPAN で総スパン幅(バンドごとに選択)を切替。
 * 刻み(分解能)はメイン画面のSTEP設定に合わせる(点数=スパン÷STEP → 棒の幅がSPANに追従)。
 *
 * 単一受信機のため掃引中(≈1秒)はVFOが動いて受信音が乱れるが、連続掃引しないので
 * 普段はSPKオンのまま通常受信でき、SCAN時だけ一瞬乱れる。SPKの自動オン/オフはしない。
 */
class BandScopeFragment : Fragment() {

    private var _binding: FragmentBandScopeBinding? = null
    private val binding get() = _binding!!
    private val vm: MainViewModel by activityViewModels()

    // ② CATスイープ(Piモード)用の総スパン幅(Hz)。狭帯域は10kHz/20kHzから、FMのVHF/UHF帯は広いので最大40MHzまで。
    private val spanOptionsHz = longArrayOf(
        10_000L, 20_000L, 50_000L, 100_000L, 200_000L, 500_000L, 1_000_000L,
        2_000_000L, 5_000_000L, 10_000_000L, 20_000_000L, 40_000_000L
    )
    // ① Icomネイティブスコープ(Center モード)が取れる span 一覧(リグ仕様に準拠。最大±250kHz=500kHz)。
    private val icomSpanOptionsHz = longArrayOf(
        5_000L, 10_000L, 25_000L, 50_000L, 100_000L, 250_000L, 500_000L
    )
    private var spanIdx = 6
    private var currentBand = ""                          // バンド別スパン記憶用
    private val settleMs = 50                             // 1点ごとのセトリング(遅延を十分小さくしてピーク位置のズレを無くす)
    private var scanJob: Job? = null
    private val scanning get() = scanJob?.isActive == true
    private var screenTimeoutJob: Job? = null   // DispOff(画面オフ)設定に従うキープスクリーン制御

    // CI-V直接接続(Wi-Fi/BT いずれも Icom)は ① ネイティブスコープ(受信音と両立する連続表示)を使う。
    // BT(SPP)は帯域が狭いため Wi-Fi より更新が遅くなる。Pi モードは ② CATスイープ(単発SCAN)。
    private val nativeScope: Boolean
        get() = vm.useCIV.value == true
    private var scopeRunning = false                      // ① 連続スコープ稼働中か

    /** 現在モードの span 配列(① Icom / ② Pi)。 */
    private fun spanArr(): LongArray = if (nativeScope) icomSpanOptionsHz else spanOptionsHz
    /** 現在モードの初期 span index(① は 100kHz / ② は 1MHz)。 */
    private fun defaultSpanIdx(): Int =
        if (nativeScope) icomSpanOptionsHz.indexOf(100_000L).coerceAtLeast(0) else 6
    /** バンド別 span 記憶キー(① と ② で別名前空間)。 */
    private fun spanKey(band: String): String = if (nativeScope) "ic:$band" else band

    // POTA/SOTA スポット取得用(MemoryDialogFragment と同じエンドポイント)。
    private val spotHttp = okhttp3.OkHttpClient()
    private val spotGson = com.google.gson.Gson()
    private var spotFetchJob: Job? = null

    private val requestMicPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) vm.setPttEnabled(true) }

    private lateinit var opUi: OpSessionUi   // 運用地パネル(メイン画面と共通)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        opUi = OpSessionUi(this, vm)   // registerForActivityResultはSTARTED前に行う
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?): View {
        _binding = FragmentBandScopeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // ブランド・テーマを画面全体へ適用（中立色のみパレット化・機能色は維持）
        ThemeApply.apply(binding.root, UiTheme.fromIndex(vm.prefs.colorTheme), vm.prefs.dayMode)

        // バンド別に記憶した前回のスパンを復元(無ければモード別の初期値)
        currentBand = freqToBand(vm.sharedFreq.value ?: 0L)
        spanIdx = vm.prefs.bandScopeSpanIndex(spanKey(currentBand), defaultSpanIdx()).coerceIn(0, spanArr().size - 1)

        updateFreqDisplay(vm.sharedFreq.value ?: 0L)
        binding.bandScopeView.setCurrentFreq(vm.sharedFreq.value ?: 0L)
        updateDomain()
        vm.sharedFreq.observe(viewLifecycleOwner) {
            binding.bandScopeView.setCurrentFreq(it)
            updateFreqDisplay(it)   // 選択(現在)周波数を右上に表示
            // バンドが変わったらそのバンドの記憶スパンへ切替
            val b = freqToBand(it)
            if (b != currentBand) {
                currentBand = b
                spanIdx = vm.prefs.bandScopeSpanIndex(spanKey(b), defaultSpanIdx()).coerceIn(0, spanArr().size - 1)
                if (nativeScope && scopeRunning) applyNativeSpan()
            }
            updateDomain()   // 可視レンジを現在周波数に追従
            updateInfo()
        }
        vm.selectedStep.observe(viewLifecycleOwner) { updateInfo() }  // メインのSTEP変更を反映

        // タップ → その周波数へQSY。広帯域でサーバが刻みを粗くしてもSTEPに合うよう、
        // 「現在周波数を基準にSTEP刻み」のグリッドへ丸めてから同調する(メイン画面の◀▶と同じ刻み)。
        binding.bandScopeView.onFreqSelected = { hz ->
            val step = mainStepHz().coerceAtLeast(1L)
            val center = vm.sharedFreq.value ?: hz
            val steps = Math.round((hz - center).toDouble() / step)
            val snapped = center + steps * step
            vm.sharedFreq.value = snapped
            lifecycleScope.launch(Dispatchers.IO) { vm.api.setFreq(snapped) }
        }

        // スコープ上のスポットのティックをタップ → そのスポットへQSY(周波数・モード)。
        binding.bandScopeView.onSpotSelected = { spot -> qsyToSpot(spot) }

        // 右上の周波数タップ → 周波数入力ボックス(MHz)
        binding.tvScopeFreq.setOnClickListener { showFreqInputDialog() }

        // SPOT ボタン → POTA/SOTA 重畳の表示設定
        binding.btnScopeSpots.setOnClickListener { showSpotSettings() }

        binding.btnScopeSpan.setOnClickListener {
            spanIdx = (spanIdx + 1) % spanArr().size
            vm.prefs.setBandScopeSpanIndex(spanKey(currentBand), spanIdx)   // バンド別に記憶
            updateDomain()
            updateInfo()
            if (nativeScope && scopeRunning) applyNativeSpan()
        }
        // ① Icom(CI-V直接): 受信音と両立する連続スコープ → START/STOP。
        // ② Pi: VFOを掃引するCATスイープ → 単発 SCAN。
        binding.btnScopeStartStop.text = if (nativeScope) "START" else "SCAN"
        binding.btnScopeStartStop.setOnClickListener {
            if (nativeScope) { if (scopeRunning) stopNativeScope() else startNativeScope() }
            else doScan()
        }
        binding.btnScopeBack.setOnClickListener {
            scanJob?.cancel(); stopNativeScope(); findNavController().navigateUp()
        }

        // SPK / PTT / MODE (メイン画面に準拠)
        updateSpkButton(); updatePttButton(); updateModeButton()
        vm.spkEnabled.observe(viewLifecycleOwner) { updateSpkButton() }
        vm.txEnabled.observe(viewLifecycleOwner) { updatePttButton() }
        vm.sharedMode.observe(viewLifecycleOwner) { updateModeButton() }

        binding.btnScopeSpk.setOnClickListener {
            if (vm.txEnabled.value == true) return@setOnClickListener
            val on = !(vm.spkEnabled.value ?: false)
            vm.spkEnabled.value = on
            if (vm.useCIV.value == true) {
                vm.civSetSpk(on)
            } else {
                val sampRate = SAMPLING_RATES.getOrElse(vm.selectedSamplingIndex.value ?: 1) { 0 }
                if (sampRate == 0) {
                    Toast.makeText(requireContext(), "Sampling rate=OFF", Toast.LENGTH_SHORT).show()
                    vm.spkEnabled.value = false
                    return@setOnClickListener
                }
                if (on) vm.startAudio() else vm.stopAudio()
            }
        }

        binding.btnScopePtt.setOnClickListener {
            val on = !(vm.txEnabled.value ?: false)
            if (on && ContextCompat.checkSelfPermission(
                    requireContext(), Manifest.permission.RECORD_AUDIO
                ) != PackageManager.PERMISSION_GRANTED) {
                requestMicPermission.launch(Manifest.permission.RECORD_AUDIO)
            } else {
                vm.setPttEnabled(on)
            }
        }

        binding.btnScopeMode.setOnClickListener { showModeDialog() }

        // ログ・運用地 (メイン画面に準拠)
        binding.btnScopeLogQso.setOnClickListener {
            LogQsoDialogFragment.newInstance(
                callsign = vm.pendingLogCallsign,
                pota     = vm.pendingLogPota,
                sota     = vm.pendingLogSota
            ).show(parentFragmentManager, "log_qso")
        }
        binding.btnScopeShowLog.setOnClickListener {
            findNavController().navigate(R.id.action_BandScopeFragment_to_QsoLogFragment)
        }
        binding.btnScopeOpLoc.setOnClickListener { opUi.showPanel() }

        // MEM SET (メイン画面に準拠): タップ=メモリーパネル、長押し=User タブ直開き。
        binding.btnScopeMem.setOnClickListener {
            MemoryDialogFragment.newInstance().show(parentFragmentManager, "memory_dialog")
        }
        binding.btnScopeMem.setOnLongClickListener {
            MemoryDialogFragment.newInstance(startTab = 1).show(parentFragmentManager, "memory_dialog"); true
        }

        // キャッシュがあれば即描画、無ければ取得。
        if (vm.scopePotaSpots.isNotEmpty() || vm.scopeSotaSpots.isNotEmpty()) pushSpotsToView() else fetchSpots()

        updateInfo()
    }

    private fun csvSet(s: String): Set<String> =
        s.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    /** 現在周波数±総スパン/2 を可視レンジとして [BandScopeView] に渡す(未掃引時の軸/重畳用)。 */
    private fun updateDomain() {
        val center = vm.sharedFreq.value ?: 0L
        if (center <= 0) return
        val half = spanArr()[spanIdx] / 2
        binding.bandScopeView.setDomain(center - half, center + half)
    }

    /** POTA/SOTA の全スポットを取得して ViewModel に保存し、描画に反映。 */
    private fun fetchSpots() {
        if (spotFetchJob?.isActive == true) return
        spotFetchJob = lifecycleScope.launch(Dispatchers.IO) {
            try {
                val req = okhttp3.Request.Builder().url("https://api.pota.app/spot/activator").build()
                val body = spotHttp.newCall(req).execute().use { it.body?.string() }
                if (body != null) {
                    val type = object : com.google.gson.reflect.TypeToken<List<com.ji1ore.wifi_rig_ctrl.data.PotaSpot>>() {}.type
                    val spots: List<com.ji1ore.wifi_rig_ctrl.data.PotaSpot> = spotGson.fromJson(body, type) ?: emptyList()
                    vm.scopePotaSpots = spots.filter { !it.invalid }
                }
            } catch (_: Exception) {}
            try {
                val sota = com.ji1ore.wifi_rig_ctrl.data.SotaCluster.fetchSpots(vm.prefs.sotaSpotHours)
                if (sota.isNotEmpty()) vm.scopeSotaSpots = sota
            } catch (_: Exception) {}
            withContext(Dispatchers.Main) { if (_binding != null) pushSpotsToView() }
        }
    }

    /** 表示設定(POTA/SOTA ON/OFF・プログラム/アソシエーション)で絞り込み、[BandScopeView] へ渡す。 */
    private fun pushSpotsToView() {
        if (_binding == null) return
        val showP = vm.prefs.scopeShowPota()
        val showS = vm.prefs.scopeShowSota()
        val progs = csvSet(vm.prefs.scopePotaProgs())
        val assocs = csvSet(vm.prefs.scopeSotaAssocs())
        val list = ArrayList<ScopeSpot>()
        if (showP) for (s in vm.scopePotaSpots) {
            if (s.freqHz <= 0) continue
            val prog = s.reference.substringBefore("-")
            if (progs.isEmpty() || prog in progs)
                list.add(ScopeSpot(s.freqHz, s.reference, s.activator, s.mode, true))
        }
        if (showS) for (s in vm.scopeSotaSpots) {
            if (s.freqHz <= 0) continue
            if (assocs.isEmpty() || s.effectiveAssocCode in assocs) {
                val sc = s.summitCode ?: ""
                val ref = if (sc.contains("/")) sc else "${s.associationCode ?: ""}/$sc"
                val call = s.activatorCallsign ?: s.callsign ?: ""
                list.add(ScopeSpot(s.freqHz, ref, call, s.mode ?: "", false))
            }
        }
        binding.bandScopeView.setSpots(list)
        updateInfo()
    }

    /** POTA/SOTA APIのモード文字列を無線機互換モードに変換(MemoryDialogFragment と同じ)。 */
    private fun normalizeSpotMode(mode: String, freqHz: Long): String = when (mode.uppercase()) {
        "SSB" -> vm.resolveMode("SSB", freqHz)
        "FT8", "FT4", "JS8", "WSPR", "PSK31", "PSK63", "JT65", "JT9" -> "USB"
        else  -> mode.uppercase()
    }

    /** 重畳スポットをタップ → その周波数・モードへQSY。 */
    private fun qsyToSpot(spot: ScopeSpot) {
        vm.pendingLogCallsign = spot.call
        vm.pendingLogPota = if (spot.isPota) spot.ref else ""
        vm.pendingLogSota = if (spot.isPota) "" else spot.ref
        val raw = spot.mode.uppercase()
        val normalized = if (raw.isNotEmpty() && raw != "UNKNOWN" && raw != "OTHER") normalizeSpotMode(raw, spot.hz) else ""
        val width = if (normalized.isNotEmpty()) modeDefaultWidth(normalized) else 0
        if (normalized.isNotEmpty()) {
            vm.recallFreqModeSequenced(spot.hz, normalized, width)
        } else {
            vm.sharedFreq.value = spot.hz
            lifecycleScope.launch(Dispatchers.IO) { vm.api.setFreq(spot.hz) }
        }
    }

    /** 可視レンジ内に入る重畳スポット件数(件数表示用)。 */
    private fun visibleSpotCount(): Int {
        val center = vm.sharedFreq.value ?: 0L
        if (center <= 0) return 0
        val half = spanArr()[spanIdx] / 2
        val lo = center - half; val hi = center + half
        val showP = vm.prefs.scopeShowPota(); val showS = vm.prefs.scopeShowSota()
        val progs = csvSet(vm.prefs.scopePotaProgs()); val assocs = csvSet(vm.prefs.scopeSotaAssocs())
        var c = 0
        if (showP) c += vm.scopePotaSpots.count {
            it.freqHz in lo..hi && (progs.isEmpty() || it.reference.substringBefore("-") in progs)
        }
        if (showS) c += vm.scopeSotaSpots.count {
            it.freqHz in lo..hi && (assocs.isEmpty() || it.effectiveAssocCode in assocs)
        }
        return c
    }

    /** POTA/SOTA 重畳の表示設定ダイアログ。 */
    private fun showSpotSettings() {
        val ctx = requireContext()
        val pad = (12 * resources.displayMetrics.density).toInt()
        val cbP = android.widget.CheckBox(ctx).apply { text = "POTA を表示"; isChecked = vm.prefs.scopeShowPota() }
        val cbS = android.widget.CheckBox(ctx).apply { text = "SOTA を表示"; isChecked = vm.prefs.scopeShowSota() }
        var potaSel = csvSet(vm.prefs.scopePotaProgs())
        var sotaSel = csvSet(vm.prefs.scopeSotaAssocs())
        val btnP = android.widget.Button(ctx).apply {
            text = "POTAプログラム選択"
            setOnClickListener {
                val opts = vm.scopePotaSpots.map { it.reference.substringBefore("-") }.filter { it.isNotEmpty() }.toSortedSet().toList()
                pickMulti("POTAプログラム(未選択=全部)", opts, potaSel) { potaSel = it }
            }
        }
        val btnS = android.widget.Button(ctx).apply {
            text = "SOTAアソシ選択"
            setOnClickListener {
                val opts = vm.scopeSotaSpots.map { it.effectiveAssocCode }.filter { it.isNotEmpty() }.toSortedSet().toList()
                pickMulti("SOTAアソシエーション(未選択=全部)", opts, sotaSel) { sotaSel = it }
            }
        }
        val btnReload = android.widget.Button(ctx).apply { text = "スポット再取得"; setOnClickListener { fetchSpots() } }
        val layout = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            addView(cbP); addView(cbS); addView(btnP); addView(btnS); addView(btnReload)
        }
        android.app.AlertDialog.Builder(ctx)
            .setTitle("スポット重畳設定")
            .setView(layout)
            .setPositiveButton("OK") { _, _ ->
                vm.prefs.setScopeShowPota(cbP.isChecked)
                vm.prefs.setScopeShowSota(cbS.isChecked)
                vm.prefs.setScopePotaProgs(potaSel.sorted().joinToString(","))
                vm.prefs.setScopeSotaAssocs(sotaSel.sorted().joinToString(","))
                pushSpotsToView()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun pickMulti(title: String, options: List<String>, selected: Set<String>, onDone: (Set<String>) -> Unit) {
        if (options.isEmpty()) {
            Toast.makeText(requireContext(), "スポット取得後に選択できます", Toast.LENGTH_SHORT).show(); return
        }
        val arr = options.toTypedArray()
        val checked = BooleanArray(options.size) { options[it] in selected }
        android.app.AlertDialog.Builder(requireContext())
            .setTitle(title)
            .setMultiChoiceItems(arr, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("OK") { _, _ ->
                onDone(options.filterIndexed { i, _ -> checked[i] }.toSet())
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun updateSpkButton() {
        val on = vm.spkEnabled.value == true
        binding.btnScopeSpk.backgroundTintList =
            ColorStateList.valueOf(if (on) 0xFF2E7D32.toInt() else 0xFF37474F.toInt())
    }

    private fun updatePttButton() {
        val tx = vm.txEnabled.value == true
        binding.btnScopePtt.backgroundTintList =
            ColorStateList.valueOf(if (tx) 0xFFD32F2F.toInt() else 0xFF6A1B9A.toInt())
    }

    private fun updateModeButton() {
        binding.btnScopeMode.text = vm.sharedMode.value?.takeIf { it.isNotEmpty() } ?: "MODE"
    }

    private fun showModeDialog() {
        val modes = vm.supportedModes.value?.takeIf { it.isNotEmpty() } ?: run {
            Toast.makeText(requireContext(), "No modes available", Toast.LENGTH_SHORT).show(); return
        }
        val cur = modes.indexOf(vm.sharedMode.value ?: "").coerceAtLeast(0)
        android.app.AlertDialog.Builder(requireContext()).setTitle("Mode")
            .setSingleChoiceItems(modes.toTypedArray(), cur) { dlg, which ->
                val m = modes[which]
                val w = modeDefaultWidth(m)
                vm.sendMode(m, w)
                if (w > 0) vm.sharedWidth.value = w
                vm.selectedStep.value = vm.prefs.getModeStep(m)
                dlg.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun modeDefaultWidth(mode: String): Int = when {
        mode == "FM" || mode == "PKTFM" -> 12000
        mode == "FMN"                   -> 9000
        mode.startsWith("CW")           -> vm.prefs.defaultCwWidth
        mode == "USB" || mode == "LSB"  -> vm.prefs.defaultSsbWidth
        else                            -> 0
    }

    private fun mainStepHz(): Long = STEP_LIST.getOrElse(vm.selectedStep.value ?: 0) { STEP_LIST[0] }.stepHz

    /** 周波数→バンド名(スパンのバンド別記憶キー)。 */
    private fun freqToBand(hz: Long): String {
        val mhz = hz / 1_000_000.0
        return when {
            mhz in 1.8..2.0       -> "160m"
            mhz in 3.5..4.0       -> "80m"
            mhz in 5.3..5.405     -> "60m"
            mhz in 7.0..7.3       -> "40m"
            mhz in 10.1..10.15    -> "30m"
            mhz in 14.0..14.35    -> "20m"
            mhz in 18.068..18.168 -> "17m"
            mhz in 21.0..21.45    -> "15m"
            mhz in 24.89..24.99   -> "12m"
            mhz in 28.0..29.7     -> "10m"
            mhz in 50.0..54.0     -> "6m"
            mhz in 144.0..148.0   -> "2m"
            mhz in 430.0..440.0   -> "70cm"
            else                   -> "Other"
        }
    }

    /** 分解能(刻み): メイン画面のSTEPをそのまま使う。点数=スパン÷STEPなので、
     *  棒グラフの本数(=1本の幅)がSPANに追従する。点数が極端に多い場合のみサーバ側で最大256点に調整。 */
    private fun effStepHz(): Long = mainStepHz().coerceAtLeast(1L)

    private fun spanLabel(hz: Long): String =
        if (hz >= 1_000_000) "%.1fMHz".format(hz / 1_000_000.0) else "%dkHz".format(hz / 1000)

    private fun stepLabel(hz: Long): String = when {
        hz >= 1000 && hz % 1000 == 0L -> "${hz / 1000}kHz"
        hz >= 1000                    -> "%.1fkHz".format(hz / 1000.0)
        else                          -> "${hz}Hz"
    }

    private fun updateInfo() {
        val total = spanArr()[spanIdx]
        binding.btnScopeSpan.text = "SPAN ${spanLabel(total)}"
        val head = if (nativeScope) "BAND SCOPE (Icom)   Span ${spanLabel(total)}"
                   else "BAND SCOPE   Span ${spanLabel(total)}   Step ${stepLabel(effStepHz())}"
        binding.tvScopeInfo.text =
            "$head\n" +
            "SPOT P:${vm.scopePotaSpots.size} S:${vm.scopeSotaSpots.size}  表示:${visibleSpotCount()}"
    }

    /** 選択(現在)周波数を右上にMHz表示。 */
    private fun updateFreqDisplay(hz: Long) {
        binding.tvScopeFreq.text = if (hz > 0) "%.4f MHz".format(hz / 1_000_000.0) else ""
    }

    /** 右上の周波数タップで開く、周波数入力ボックス(MHz)。 */
    private fun showFreqInputDialog() {
        val ctx = requireContext()
        val et = android.widget.EditText(ctx).apply {
            setText("%.5f".format((vm.sharedFreq.value ?: 0L) / 1_000_000.0))
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            selectAll()
        }
        android.app.AlertDialog.Builder(ctx)
            .setTitle("Frequency (MHz)")
            .setView(et)
            .setPositiveButton("OK") { _, _ ->
                val mhz = et.text.toString().toDoubleOrNull() ?: return@setPositiveButton
                vm.sendFreq((mhz * 1_000_000).toLong())
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** 1回だけ掃引して表示する。SPKは操作しない(掃引の一瞬だけ受信音が乱れる)。 */
    private fun doScan() {
        if (scanning) return
        val center = vm.sharedFreq.value ?: 0L
        if (center <= 0) return
        binding.btnScopeStartStop.text = "SCANNING…"
        binding.btnScopeStartStop.isEnabled = false
        val total = spanArr()[spanIdx]
        val half = total / 2
        val start = (center - half).coerceAtLeast(1L)
        val stop = center + half
        val effStep = effStepHz()
        scanJob = lifecycleScope.launch(Dispatchers.IO) {
            val res = vm.api.scopeSweep(start, stop, effStep, settleMs)
            val corrected = res?.let { sharpenPeaks(it.points) }
            withContext(Dispatchers.Main) {
                if (_binding != null) {
                    if (res != null && corrected != null) binding.bandScopeView.setData(res.freqs, corrected)
                    binding.btnScopeStartStop.text = "SCAN"
                    binding.btnScopeStartStop.isEnabled = true
                }
            }
        }
    }

    // ───────────────────────── ① Icom ネイティブスコープ(CI-V 27 00) ─────────────────────────

    /** 連続スコープ開始。VFOを動かさないので受信音は途切れない。 */
    private fun startNativeScope() {
        val center = vm.sharedFreq.value ?: 0L
        if (center <= 0) return
        vm.activeCivScope.onSweep = { levels ->
            // CI-V受信スレッド(Wi-Fi/BT)から呼ばれる → UIスレッドで描画。
            _binding?.bandScopeView?.post { renderNativeSweep(levels) }
        }
        scopeRunning = true
        binding.btnScopeStartStop.text = "STOP"
        lifecycleScope.launch(Dispatchers.IO) { vm.civStartNativeScope(spanArr()[spanIdx]) }
    }

    private fun stopNativeScope() {
        if (!scopeRunning) return
        scopeRunning = false
        vm.activeCivScope.onSweep = null
        if (_binding != null) binding.btnScopeStartStop.text = "START"
        lifecycleScope.launch(Dispatchers.IO) { vm.civStopNativeScope() }
    }

    /** 稼働中に span を変更したときリグへ反映。 */
    private fun applyNativeSpan() {
        lifecycleScope.launch(Dispatchers.IO) { vm.civSetScopeSpan(spanArr()[spanIdx]) }
    }

    /** 475点のレベル(0..1)を現在周波数±span/2の軸へ割り当て、BandScopeViewのdBドメインへ写像して描画。 */
    private fun renderNativeSweep(levels: FloatArray) {
        if (_binding == null) return
        val n = levels.size
        if (n < 2) return
        val center = vm.sharedFreq.value ?: return
        val span = spanArr()[spanIdx]
        val lo = center - span / 2
        val freqs = LongArray(n) { lo + Math.round(it.toDouble() * span / (n - 1)) }
        // BandScopeView は points を dB とみなし norm(-54..+40) する。レベル0..1を同レンジへ線形写像し、
        // norm で元の 0..1 に戻ることで棒の高さ・配色がそのまま反映される。
        val floor = -54f; val ceil = 40f
        val points = FloatArray(n) { floor + levels[it] * (ceil - floor) }
        binding.bandScopeView.setData(freqs, points)
    }

    /** ピーク先鋭化: ローカル最大(隣接より高いビン)のみ残し、裾のビンはフロアへ下げて
     *  「1信号=1本」に近づける。平坦部(整数dBで同値)は右端を採用して二重表示を防ぐ。 */
    private fun sharpenPeaks(p: FloatArray): FloatArray {
        val n = p.size
        if (n < 3) return p
        val floor = -54f  // S0相当(norm=0 → 棒の高さ0)
        return FloatArray(n) { i ->
            val left  = if (i > 0)     p[i - 1] else Float.NEGATIVE_INFINITY
            val right = if (i < n - 1) p[i + 1] else Float.NEGATIVE_INFINITY
            if (p[i] >= left && p[i] > right) p[i] else floor
        }
    }

    override fun onResume() {
        super.onResume()
        applyScreenTimeout()
    }

    override fun onPause() {
        super.onPause()
        screenTimeoutJob?.cancel()
        screenTimeoutJob = null
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    /** DispOff(画面オフ)設定に従って画面を点灯維持する。メイン画面(MainControlFragment)と同一仕様。
     *  index0=0分="Off"→常時点灯、それ以外→指定分だけ点灯後にOSのタイムアウトへ戻す。 */
    private fun applyScreenTimeout() {
        screenTimeoutJob?.cancel()
        val toIdx = vm.selectedTimeoutIndex.value ?: 2
        val timeoutMin = SCREEN_TIMEOUT_OPTIONS.getOrElse(toIdx) { 10 }

        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        if (timeoutMin > 0) {
            screenTimeoutJob = viewLifecycleOwner.lifecycleScope.launch {
                delay(timeoutMin * 60 * 1000L)
                activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
        // timeoutMin == 0 → "Off" → 常時点灯(クリアしない)
    }

    override fun onDestroyView() {
        scanJob?.cancel(); scanJob = null
        screenTimeoutJob?.cancel(); screenTimeoutJob = null
        stopNativeScope()
        spotFetchJob?.cancel(); spotFetchJob = null
        super.onDestroyView()
        _binding = null
    }
}
