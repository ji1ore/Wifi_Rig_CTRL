package com.ji1ore.wifi_rig_ctrl

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/**
 * バンドスコープ表示。
 * api(/radio/scope/sweep) が返す [周波数(Hz), 信号強度(dB)] 配列を、横軸=周波数 /
 * 縦軸=信号強度 の塗りバー＋ピークラインで描画する。中心に現在周波数マーカーを置き、
 * タップでその周波数へQSYするコールバックを呼ぶ。
 *
 * 信号強度はhamlibの 'l STRENGTH'(S9=0 を基準にした dB)。表示レンジは S0 相当(-54dB)〜
 * S9+40 相当(+40dB)。
 */
class BandScopeView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private var freqs: LongArray = LongArray(0)
    private var points: FloatArray = FloatArray(0)
    private var currentFreqHz: Long = 0L

    // POTA/SOTA スポット重畳。未掃引でも表示できるよう、スパン(現在周波数±総スパン/2)を
    // [domainLo,domainHi] として別途受け取る(掃引済みのときは掃引レンジを優先)。
    private var spots: List<ScopeSpot> = emptyList()
    private var domainLo = 0L
    private var domainHi = 0L

    private val FREQ_DIVS = 6   // 周波数縦グリッドの分割数(=ラベル本数 FREQ_DIVS+1)

    // 表示レンジ(dB)
    private val dbFloor = -54f   // S0
    private val dbCeil  =  40f   // S9+40

    private val dp = context.resources.displayMetrics.density
    private val sp = context.resources.displayMetrics.scaledDensity

    private val barPaint  = Paint().apply { isAntiAlias = false }
    private val gridPaint = Paint().apply {
        isAntiAlias = false; strokeWidth = dp * 0.5f; color = 0x33FFFFFF
    }
    private val markPaint = Paint().apply {
        isAntiAlias = true; strokeWidth = dp * 1.5f; color = 0xFFFFDD00.toInt()
    }
    private val txtPaint  = Paint().apply { isAntiAlias = true; textSize = sp * 10f; color = 0xFFFFDD00.toInt(); isFakeBoldText = true }

    // スポット重畳用: POTA=シアン / SOTA=オレンジ の縦ティックとラベル。
    private val potaColor = 0xFF00F2FF.toInt()
    private val sotaColor = 0xFFFF9926.toInt()
    private val spotTickPaint = Paint().apply { isAntiAlias = false; strokeWidth = dp * 1f }
    private val spotTxtPaint  = Paint().apply { isAntiAlias = true; textSize = sp * 9f; isFakeBoldText = true }

    /** タップでその周波数(Hz)へQSYするためのコールバック。 */
    var onFreqSelected: ((hz: Long) -> Unit)? = null

    /** スポットのティック近傍をタップしたとき、そのスポットへQSYするためのコールバック。 */
    var onSpotSelected: ((ScopeSpot) -> Unit)? = null

    fun setData(newFreqs: LongArray, newPoints: FloatArray) {
        freqs = newFreqs; points = newPoints; invalidate()
    }

    fun setCurrentFreq(hz: Long) {
        currentFreqHz = hz; invalidate()
    }

    /** 重畳スポット(表示設定で絞り込み済み)を設定。 */
    fun setSpots(list: List<ScopeSpot>) { spots = list; invalidate() }

    /** 未掃引時の周波数軸レンジ(現在周波数±総スパン/2)。 */
    fun setDomain(loHz: Long, hiHz: Long) { domainLo = loHz; domainHi = hiHz; invalidate() }

    /** 現在の可視周波数レンジ[lo,hi]。掃引済みなら掃引レンジ、未掃引ならドメイン。 */
    private fun visibleRange(): Pair<Double, Double>? {
        if (freqs.size >= 2 && freqs.last() > freqs.first()) return freqs.first().toDouble() to freqs.last().toDouble()
        if (domainHi > domainLo) return domainLo.toDouble() to domainHi.toDouble()
        return null
    }

    private fun norm(db: Float): Float =
        ((db - dbFloor) / (dbCeil - dbFloor)).coerceIn(0f, 1f)

    override fun onDraw(canvas: Canvas) {
        val w = width; val h = height
        if (w <= 0 || h <= 0) return
        canvas.drawColor(0xFF000A0A.toInt())

        // S-scale 横グリッド(S3/S6/S9)
        for (i in 1 until 4) {
            val y = h * i / 4f
            canvas.drawLine(0f, y, w.toFloat(), y, gridPaint)
        }

        val n = points.size
        if (n == 0) {
            // 未掃引でも、現在周波数±スパンの周波数軸とスポット重畳は表示する。
            drawDomainFreqAxis(canvas, w, h)
            drawSpots(canvas, w, h)
            txtPaint.textAlign = Paint.Align.CENTER
            txtPaint.color = 0xFF668888.toInt()
            canvas.drawText("Press SCAN to sweep", w / 2f, h / 2f, txtPaint)
            txtPaint.color = 0xFFFFDD00.toInt()
            txtPaint.textAlign = Paint.Align.LEFT
            return
        }

        val barW = w.toFloat() / n

        // 塗りバー
        for (b in 0 until n) {
            val nv = norm(points[b])
            val barH = nv * h
            val x = b * barW
            barPaint.color = scopeColor(nv)
            canvas.drawRect(x, h - barH, x + barW + 0.5f, h.toFloat(), barPaint)
        }

        // 現在周波数マーカー(最も近いbin)
        if (currentFreqHz > 0 && freqs.isNotEmpty()) {
            var idx = 0; var best = Long.MAX_VALUE
            for (b in freqs.indices) {
                val d = kotlin.math.abs(freqs[b] - currentFreqHz)
                if (d < best) { best = d; idx = b }
            }
            val x = idx * barW + barW / 2f
            canvas.drawLine(x, 0f, x, h.toFloat(), markPaint)
        }

        // 周波数 縦グリッド + ラベル。各ビン(=Step周波数)の中心に合わせて配置する
        // (棒・マーカー・タップもビン中心基準なので、ラベルと棒がぴったり一致する)。
        if (freqs.isNotEmpty()) {
            val spanHz = (freqs.last() - freqs.first()).toDouble()
            val decimals = when {
                spanHz >= 4_000_000 -> 2
                spanHz >=   400_000 -> 3
                else                -> 4
            }
            val divs = FREQ_DIVS.coerceAtMost((n - 1).coerceAtLeast(1))
            for (i in 0..divs) {
                val b = Math.round(i.toDouble() / divs * (n - 1)).toInt().coerceIn(0, n - 1)
                val x = b * barW + barW / 2f      // ビン中心
                canvas.drawLine(x, 0f, x, h.toFloat(), gridPaint)
                val align = when (b) {
                    0     -> Paint.Align.LEFT
                    n - 1 -> Paint.Align.RIGHT
                    else  -> Paint.Align.CENTER
                }
                drawFreqLabel(canvas, freqs[b].toDouble(), x.coerceIn(dp * 2, w - dp * 2), h.toFloat() - dp * 2, align, decimals)
            }
        }

        drawSpots(canvas, w, h)
    }

    /** 未掃引時の周波数軸(現在周波数マーカー + 縦グリッド + 周波数ラベル)をドメイン基準で描画。 */
    private fun drawDomainFreqAxis(canvas: Canvas, w: Int, h: Int) {
        val (lo, hi) = visibleRange() ?: return
        val span = hi - lo
        if (span <= 0) return
        val decimals = when {
            span >= 4_000_000 -> 2
            span >=   400_000 -> 3
            else              -> 4
        }
        if (currentFreqHz > 0) {
            val x = ((currentFreqHz - lo) / span * w).toFloat()
            if (x in 0f..w.toFloat()) canvas.drawLine(x, 0f, x, h.toFloat(), markPaint)
        }
        for (i in 0..FREQ_DIVS) {
            val frac = i.toDouble() / FREQ_DIVS
            val x = (frac * w).toFloat()
            canvas.drawLine(x, 0f, x, h.toFloat(), gridPaint)
            val hz = lo + frac * span
            val align = when (i) {
                0         -> Paint.Align.LEFT
                FREQ_DIVS -> Paint.Align.RIGHT
                else      -> Paint.Align.CENTER
            }
            drawFreqLabel(canvas, hz, x.coerceIn(dp * 2, w - dp * 2), h.toFloat() - dp * 2, align, decimals)
        }
    }

    /** POTA/SOTA スポットを該当周波数の位置に重畳描画(縦ティック + REF/コール ラベル)。
     *  ラベルが重なる場合は2段に振り分け、それでも近接するものは間引く。 */
    private fun drawSpots(canvas: Canvas, w: Int, h: Int) {
        if (spots.isEmpty()) return
        val (lo, hi) = visibleRange() ?: return
        val span = hi - lo
        if (span <= 0) return
        val minGap = dp * 46f
        val laneLastX = floatArrayOf(-1e9f, -1e9f)
        val lineH = spotTxtPaint.textSize + dp * 1f
        // x昇順に並べ、レンジ内のみ描画。
        val inRange = spots
            .map { (((it.hz - lo) / span) * w).toFloat() to it }
            .filter { it.first in 0f..w.toFloat() }
            .sortedBy { it.first }
        for ((x, spot) in inRange) {
            val color = if (spot.isPota) potaColor else sotaColor
            spotTickPaint.color = color and 0x00FFFFFF or 0x8C000000.toInt()  // 約55%不透明
            canvas.drawLine(x, 0f, x, h.toFloat(), spotTickPaint)
            val lane = when {
                x - laneLastX[0] >= minGap -> 0
                x - laneLastX[1] >= minGap -> 1
                else                       -> -1
            }
            if (lane < 0) continue
            laneLastX[lane] = x
            val yTop = dp * 4f + lane * (lineH * 3 + dp * 2)
            val align = when {
                x < dp * 28 -> Paint.Align.LEFT
                x > w - dp * 28 -> Paint.Align.RIGHT
                else -> Paint.Align.CENTER
            }
            spotTxtPaint.textAlign = align
            val lx = x.coerceIn(dp * 2, w - dp * 2)
            spotTxtPaint.color = color
            canvas.drawText(spot.ref, lx, yTop + lineH, spotTxtPaint)
            spotTxtPaint.color = 0xFFFFFFFF.toInt()
            canvas.drawText(spot.call, lx, yTop + lineH * 2, spotTxtPaint)
            // コールサインの下にカッコでモードを表示(空なら省略)。
            if (spot.mode.isNotBlank()) {
                spotTxtPaint.color = 0xFF4DD0E1.toInt()   // モード=ティール
                canvas.drawText("(${spot.mode})", lx, yTop + lineH * 3, spotTxtPaint)
            }
        }
        spotTxtPaint.textAlign = Paint.Align.LEFT
    }

    private fun drawFreqLabel(canvas: Canvas, hzMean: Double, x: Float, y: Float, align: Paint.Align, decimals: Int) {
        txtPaint.textAlign = align
        canvas.drawText("%.${decimals}f".format(hzMean / 1_000_000.0), x, y, txtPaint)
        txtPaint.textAlign = Paint.Align.LEFT
    }

    // 濃いめ(高彩度)の配色: 青 → シアン → 緑 → 黄 → 赤。低信号でもはっきり色が出る。
    private fun scopeColor(v: Float): Int {
        val c = v.coerceIn(0f, 1f)
        return when {
            c < 0.33f -> { val t = c / 0.33f;        android.graphics.Color.rgb(0, (60 + t * 160).toInt(), (200 + t * 55).toInt()) }      // (0,60,200)→(0,220,255)
            c < 0.66f -> { val t = (c - 0.33f) / 0.33f; android.graphics.Color.rgb((t * 230).toInt(), (220 - t * 10).toInt(), (255 - t * 255).toInt()) } // (0,220,255)→(230,210,0)
            else      -> { val t = (c - 0.66f) / 0.34f; android.graphics.Color.rgb((230 + t * 25).toInt(), (210 - t * 180).toInt(), 0) }   // (230,210,0)→(255,30,0)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_DOWN) return false
        if (width <= 0) return false
        // まずスポットのティック近傍(±14dp)を優先的に拾う。
        val range = visibleRange()
        if (range != null && spots.isNotEmpty()) {
            val (lo, hi) = range
            val span = hi - lo
            if (span > 0) {
                val tol = dp * 14f
                var best: ScopeSpot? = null; var bestDx = Float.MAX_VALUE
                for (s in spots) {
                    val x = (((s.hz - lo) / span) * width).toFloat()
                    val dx = kotlin.math.abs(x - e.x)
                    if (dx <= tol && dx < bestDx) { bestDx = dx; best = s }
                }
                if (best != null) { onSpotSelected?.invoke(best); return true }
            }
        }
        val n = freqs.size
        if (n == 0) return false
        val idx = (e.x / width * n).toInt().coerceIn(0, n - 1)
        onFreqSelected?.invoke(freqs[idx])
        return true
    }
}

/** バンドスコープに重畳する1スポット(周波数・リファレンス・コール・モード・種別)。 */
data class ScopeSpot(
    val hz: Long,
    val ref: String,
    val call: String,
    val mode: String,
    val isPota: Boolean
)
