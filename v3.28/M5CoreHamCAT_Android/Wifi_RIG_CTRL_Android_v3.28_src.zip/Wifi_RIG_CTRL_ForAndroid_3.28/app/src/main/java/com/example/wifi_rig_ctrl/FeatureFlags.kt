package com.ji1ore.wifi_rig_ctrl

/**
 * Central feature flags.
 *
 * MEMSET_SOTA_ENABLED: MEM SET（メモリ/スポット画面）の SOTA タブの有効/無効フラグ。
 *   v3.25 で解放（true）。MEM SET の SOTA タブ（SOTA スポット一覧）を表示する。
 *   ※ ログ機能（LOG QSO の SOTA 欄・ログ編集・SOTA送付・ADIF 等）や FT8 の SOTA、
 *      運用地の SOTA 種別、SP2ALART の SOTA 取り込みは従来どおり有効。
 *   再び隠す場合は false に戻すだけでよい。
 */
object FeatureFlags {
    const val MEMSET_SOTA_ENABLED = true
}
