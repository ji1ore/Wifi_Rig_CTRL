package com.ji1ore.wifi_rig_ctrl

import android.app.AlertDialog
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import com.ji1ore.wifi_rig_ctrl.data.OpSession
import com.ji1ore.wifi_rig_ctrl.viewmodel.MainViewModel

/**
 * 運用地(POTA/SOTA/JCC/JGC)管理UI。メイン画面・バンドスコープ画面など複数のFragmentから
 * 同じ挙動で呼べるよう、MainControlFragment の運用地パネル一式をクラスとして切り出したもの。
 * 使い方: Fragmentのフィールドで `private val opUi = OpSessionUi(this, vm)` を生成し、
 * ボタンで `opUi.showPanel()` を呼ぶ。
 */
class OpSessionUi(private val frag: Fragment, private val vm: MainViewModel) {

    private var pendingLocationAction: (() -> Unit)? = null
    private val locationPermLauncher = frag.registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val granted = result[android.Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                      result[android.Manifest.permission.ACCESS_COARSE_LOCATION] == true
        val act = pendingLocationAction; pendingLocationAction = null
        if (granted) act?.invoke()
        else Toast.makeText(frag.requireContext(), "位置情報の許可が必要です", Toast.LENGTH_SHORT).show()
    }

    private fun ensureLocationPermission(onGranted: () -> Unit) {
        val ctx = frag.requireContext()
        val ok = androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED ||
                 androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (ok) onGranted()
        else {
            pendingLocationAction = onGranted
            locationPermLauncher.launch(arrayOf(
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.ACCESS_COARSE_LOCATION))
        }
    }

    private fun fmtOpTime(ms: Long): String {
        if (ms == 0L) return "運用中"
        val c = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC")).apply { timeInMillis = ms }
        return String.format("%02d/%02d %02d:%02dZ",
            c.get(java.util.Calendar.MONTH) + 1, c.get(java.util.Calendar.DAY_OF_MONTH),
            c.get(java.util.Calendar.HOUR_OF_DAY), c.get(java.util.Calendar.MINUTE))
    }

    fun showPanel() {
        val ctx = frag.requireContext()
        val listBox = android.widget.LinearLayout(ctx).apply { orientation = android.widget.LinearLayout.VERTICAL }
        val scroll = android.widget.ScrollView(ctx).apply { addView(listBox) }
        // ヘッダに タイトル + 新規追加 + 閉じる(上固定)
        val btnAdd = android.widget.Button(ctx).apply { text = "新規追加"; isAllCaps = false }
        val btnClose = android.widget.Button(ctx).apply { text = "閉じる"; isAllCaps = false }
        val header = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL; setPadding(24, 8, 12, 4)
            addView(android.widget.TextView(ctx).apply {
                text = "運用地 (POTA/SOTA)"; setTextColor(0xFFFFFFFF.toInt()); textSize = 16f
                layoutParams = android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(btnAdd); addView(btnClose)
        }
        val root = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL; setPadding(24, 0, 24, 0)
            addView(header, android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(scroll, android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, (frag.resources.displayMetrics.density * 360).toInt()))
        }
        val dlg = AlertDialog.Builder(ctx).setView(root).create()
        btnClose.setOnClickListener { dlg.dismiss() }
        fun refresh() {
            listBox.removeAllViews()
            val sessions = vm.opSessions.value ?: emptyList()
            if (sessions.isEmpty()) {
                listBox.addView(android.widget.TextView(ctx).apply {
                    text = "運用地が未登録です。「新規追加」で登録してください。"
                    setTextColor(0xFFAAAAAA.toInt()); setPadding(0, 12, 0, 12)
                })
            }
            sessions.forEach { s ->
                val row = android.widget.LinearLayout(ctx).apply {
                    orientation = android.widget.LinearLayout.HORIZONTAL
                    gravity = android.view.Gravity.CENTER_VERTICAL; setPadding(0, 6, 0, 6)
                }
                row.addView(android.widget.TextView(ctx).apply {
                    text = "${s.type}  ${s.ref}\n${fmtOpTime(s.startMs)} 〜 ${fmtOpTime(s.endMs)}" +
                        if (s.label.isNotEmpty()) "  (${s.label})" else ""
                    textSize = 13f; setTextColor(0xFFFFFFFF.toInt())
                    layoutParams = android.widget.LinearLayout.LayoutParams(
                        0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                })
                row.addView(android.widget.Button(ctx).apply {
                    text = "編集"; textSize = 11f; setOnClickListener { showEdit(s) { refresh() } }
                })
                row.addView(android.widget.Button(ctx).apply {
                    text = "削除"; textSize = 11f; setOnClickListener { vm.deleteOpSession(s.id); refresh() }
                })
                listBox.addView(row)
            }
        }
        refresh()
        btnAdd.setOnClickListener { showEdit(null) { refresh() } }
        dlg.show()
    }

    private fun showEdit(existing: OpSession?, onDone: () -> Unit) {
        val ctx = frag.requireContext()
        val box = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL; setPadding(24, 8, 24, 8)
        }
        val typeSpinner = android.widget.Spinner(ctx).apply {
            adapter = android.widget.ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, OpSession.TYPES)
            setSelection(OpSession.TYPES.indexOf(existing?.type ?: "POTA").coerceAtLeast(0))
        }
        val refEt = android.widget.EditText(ctx).apply {
            hint = "ref (POTA: JA-0000 / SOTA: JA/XX-000 / JCC/JGC: コード)"
            setText(existing?.ref ?: "")
        }
        val labelEt = android.widget.EditText(ctx).apply { hint = "メモ(任意)"; setText(existing?.label ?: "") }
        val glEt = android.widget.EditText(ctx).apply {
            hint = "自局GL (例: PM95) ※ログのMY GL既定に使用"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            setText(existing?.gl ?: "")
        }
        var startMs = existing?.startMs ?: System.currentTimeMillis()
        var endMs = existing?.endMs ?: 0L
        var useLocalTime = false
        // 開始/終了をローカルタイムで入力・表示するトグル(OFF=UTC)
        val swLocal = android.widget.Switch(ctx).apply {
            text = "開始/終了をローカルタイムで入力 (OFF=UTC)"; textSize = 13f; isChecked = false
        }
        // 時刻表示: ローカル時は末尾を"L"、UTC時は"Z"(fmtOpTime)で区別
        fun fmtOp(ms: Long): String {
            if (ms == 0L) return "運用中"
            if (!useLocalTime) return fmtOpTime(ms)
            val c = java.util.Calendar.getInstance(java.util.TimeZone.getDefault()).apply { timeInMillis = ms }
            return String.format("%02d/%02d %02d:%02dL",
                c.get(java.util.Calendar.MONTH) + 1, c.get(java.util.Calendar.DAY_OF_MONTH),
                c.get(java.util.Calendar.HOUR_OF_DAY), c.get(java.util.Calendar.MINUTE))
        }
        val startBtn = android.widget.Button(ctx)
        val endBtn = android.widget.Button(ctx)
        fun updBtns() { startBtn.text = "開始: ${fmtOp(startMs)}"; endBtn.text = "終了: ${fmtOp(endMs)}" }
        updBtns()
        swLocal.setOnCheckedChangeListener { _, checked -> useLocalTime = checked; updBtns() }
        startBtn.setOnClickListener { pickDateTime(startMs, useLocalTime) { startMs = it; updBtns() } }
        endBtn.setOnClickListener {
            AlertDialog.Builder(ctx).setTitle("終了時刻")
                .setItems(arrayOf("日時を指定", "運用中(未確定)")) { _, which ->
                    if (which == 0) pickDateTime(if (endMs == 0L) startMs else endMs, useLocalTime) { endMs = it; updBtns() }
                    else { endMs = 0L; updBtns() }
                }.show()
        }
        // GPSで現在地のJCC/JGCを自動取得(種別も自動でJCC/JGCに切替)
        val gpsBtn = android.widget.Button(ctx).apply { text = "GPSでJCC/JGC取得"; textSize = 13f }
        gpsBtn.setOnClickListener { ensureLocationPermission {
            GeoJcc.fetch(ctx,
                onInfo = { msg -> Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() },
                onResult = { jcc, jgc, jccMemo, jgcMemo, info, gl ->
                    // JCC/JGC と一緒に GL(グリッド)も自動取得して登録
                    if (gl.isNotEmpty()) glEt.setText(gl)
                    // メモはJCC=市/区、JGC=郡+町/村 と行政区分を分ける
                    fun setJcc() { typeSpinner.setSelection(OpSession.TYPES.indexOf("JCC")); refEt.setText(jcc); if (jccMemo.isNotEmpty()) labelEt.setText(jccMemo) }
                    fun setJgc() { typeSpinner.setSelection(OpSession.TYPES.indexOf("JGC")); refEt.setText(jgc); if (jgcMemo.isNotEmpty()) labelEt.setText(jgcMemo) }
                    when {
                        // 両方取れた時(政令市など)は、どちらを登録するか選ばせる(両方同時には入れない)
                        jcc.isNotEmpty() && jgc.isNotEmpty() ->
                            AlertDialog.Builder(ctx).setTitle("どちらを登録しますか?")
                                .setItems(arrayOf("JCC  $jcc", "JGC  $jgc")) { _, w -> if (w == 0) setJcc() else setJgc() }
                                .show()
                        jcc.isNotEmpty() -> setJcc()
                        jgc.isNotEmpty() -> setJgc()
                        else -> Toast.makeText(ctx, "JCC/JGCを特定できませんでした", Toast.LENGTH_SHORT).show()
                    }
                    Toast.makeText(ctx, info, Toast.LENGTH_LONG).show()
                })
        } }
        // SOTA/POTA は現在地周辺の地図から選択
        val mapBtn = android.widget.Button(ctx).apply { text = "地図から選択(SOTA/POTA)"; textSize = 13f }
        mapBtn.setOnClickListener {
            val t = OpSession.TYPES[typeSpinner.selectedItemPosition]
            if (t != "SOTA" && t != "POTA") {
                Toast.makeText(ctx, "種別をSOTAまたはPOTAにしてください", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            ensureLocationPermission { showMapPicker(t) { ref, name ->
                refEt.setText(ref)
                if (name.isNotBlank()) labelEt.setText(name)   // エンティティ名をメモに残す
            } }
        }
        box.addView(android.widget.TextView(ctx).apply { text = "種別"; setTextColor(0xFFAAAAAA.toInt()) })
        box.addView(typeSpinner); box.addView(refEt); box.addView(gpsBtn); box.addView(mapBtn)
        box.addView(swLocal); box.addView(startBtn); box.addView(endBtn); box.addView(labelEt); box.addView(glEt)
        // ヘッダに タイトル + キャンセル/保存(上固定、キーボードで隠れない)
        val btnCancel = android.widget.Button(ctx).apply { text = "キャンセル"; isAllCaps = false }
        val btnSave = android.widget.Button(ctx).apply { text = "保存"; isAllCaps = false }
        val header = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL; setPadding(24, 8, 12, 4)
            addView(android.widget.TextView(ctx).apply {
                text = if (existing == null) "運用地を追加" else "運用地を編集"
                setTextColor(0xFFFFFFFF.toInt()); textSize = 16f
                layoutParams = android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(btnCancel); addView(btnSave)
        }
        val outer = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            addView(header, android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(android.widget.ScrollView(ctx).apply { addView(box) },
                android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        val dlg = AlertDialog.Builder(ctx).setView(outer).create()
        btnCancel.setOnClickListener { dlg.dismiss() }
        btnSave.setOnClickListener {
            val ref = refEt.text.toString().trim().uppercase()
            if (ref.isEmpty()) { Toast.makeText(ctx, "refを入力してください", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            if (endMs != 0L && endMs < startMs) { Toast.makeText(ctx, "終了が開始より前です", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val s = OpSession(
                id = existing?.id ?: java.util.UUID.randomUUID().toString(),
                type = OpSession.TYPES[typeSpinner.selectedItemPosition],
                ref = ref, startMs = startMs, endMs = endMs, label = labelEt.text.toString().trim(),
                gl = glEt.text.toString().trim().uppercase())
            val err = vm.addOpSession(s)
            if (err != null) Toast.makeText(ctx, err, Toast.LENGTH_LONG).show() else {
                // 登録GL: 6桁(フル)は myGrid6(ログMy GL用)へ、先頭4桁は ft8MyGrid(FT8/CW用)へ
                if (s.gl.length >= 4) { vm.prefs.ft8MyGrid = s.gl.take(4); vm.prefs.myGrid6 = s.gl }
                onDone(); dlg.dismiss()
            }
        }
        dlg.window?.apply {
            setBackgroundDrawableResource(android.R.color.background_dark)
            setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        dlg.setOnShowListener {
            dlg.window?.setLayout(
                (ctx.resources.displayMetrics.widthPixels * 0.95).toInt(),
                android.view.WindowManager.LayoutParams.MATCH_PARENT)
        }
        dlg.show()
    }

    private fun showMapPicker(type: String, onPick: (String, String) -> Unit) {
        val ctx = frag.requireContext()
        org.osmdroid.config.Configuration.getInstance().userAgentValue = ctx.packageName
        val density = ctx.resources.displayMetrics.density
        val map = org.osmdroid.views.MapView(ctx).apply {
            setTileSource(org.osmdroid.tileprovider.tilesource.TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(13.0)
        }
        val info = android.widget.TextView(ctx).apply {
            text = "現在地を取得中…"; setPadding(16, 8, 16, 8); setTextColor(0xFFCCCCCC.toInt())
        }
        val reSearchBtn = android.widget.Button(ctx).apply { text = "この地図範囲で再検索"; textSize = 13f }
        val box = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            addView(reSearchBtn)
            addView(info)
            addView(map, android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, (density * 420).toInt()))
        }
        val dlg = AlertDialog.Builder(ctx).setTitle("$type を地図から選択").setView(box)
            .setNegativeButton("閉じる", null).create()

        // 指定座標の周辺エンティティを取得して地図に出す(既存マーカーは消す)
        fun loadFor(lat: Double, lon: Double) {
            map.overlays.removeAll { it is org.osmdroid.views.overlay.Marker }
            map.invalidate()
            info.text = "周辺の${type}を検索中…"
            GeoJcc.fetchNearby(ctx, type, lat, lon) { items, dbg ->
                if (items.isEmpty()) {
                    info.text = "周辺の${type}が見つかりませんでした(地図を動かして再検索/手入力)\n$dbg"
                    return@fetchNearby
                }
                info.text = "${type}をタップして選択 (${items.size}件)"
                // ピンの色: POTA=緑 / SOTA=赤
                val pinColor = if (type == "POTA") 0xFF2E7D32.toInt() else 0xFFC62828.toInt()
                val pinIcon = androidx.core.content.ContextCompat.getDrawable(
                    ctx, org.osmdroid.library.R.drawable.marker_default)?.mutate()?.also {
                    androidx.core.graphics.drawable.DrawableCompat.setTint(it, pinColor)
                }
                items.forEach { g ->
                    val m = org.osmdroid.views.overlay.Marker(map)
                    m.position = org.osmdroid.util.GeoPoint(g.lat, g.lon)
                    m.title = g.ref
                    m.snippet = g.name
                    if (pinIcon != null) m.icon = pinIcon
                    m.setAnchor(org.osmdroid.views.overlay.Marker.ANCHOR_CENTER, org.osmdroid.views.overlay.Marker.ANCHOR_BOTTOM)
                    m.setOnMarkerClickListener { _, _ ->
                        AlertDialog.Builder(ctx)
                            .setTitle(g.ref)
                            .setMessage("${g.name}\n(${"%.4f".format(g.lat)}, ${"%.4f".format(g.lon)})")
                            .setPositiveButton("この運用地を選択") { _, _ -> onPick(g.ref, g.name); dlg.dismiss() }
                            .setNegativeButton("キャンセル", null)
                            .show()
                        true
                    }
                    map.overlays.add(m)
                }
                map.invalidate()
            }
        }
        reSearchBtn.setOnClickListener {
            val c = map.mapCenter   // 現在表示している地図中心で再取得
            loadFor(c.latitude, c.longitude)
        }
        dlg.setOnShowListener {
            map.onResume()
            GeoJcc.fetchLocation(ctx, onInfo = { info.text = it }) { lat, lon ->
                map.controller.setZoom(13.0)
                map.controller.setCenter(org.osmdroid.util.GeoPoint(lat, lon))
                loadFor(lat, lon)
            }
        }
        dlg.setOnDismissListener { map.onPause(); map.onDetach() }
        dlg.show()
    }

    private fun pickDateTime(initial: Long, useLocal: Boolean = false, onSet: (Long) -> Unit) {
        val ctx = frag.requireContext()
        val tz = if (useLocal) java.util.TimeZone.getDefault() else java.util.TimeZone.getTimeZone("UTC")
        val c = java.util.Calendar.getInstance(tz).apply {
            timeInMillis = if (initial == 0L) System.currentTimeMillis() else initial
        }
        android.app.DatePickerDialog(ctx, { _, y, mo, d ->
            android.app.TimePickerDialog(ctx, { _, h, mi ->
                val cc = java.util.Calendar.getInstance(tz)
                cc.set(y, mo, d, h, mi, 0); cc.set(java.util.Calendar.MILLISECOND, 0)
                onSet(cc.timeInMillis)
            }, c.get(java.util.Calendar.HOUR_OF_DAY), c.get(java.util.Calendar.MINUTE), true).show()
        }, c.get(java.util.Calendar.YEAR), c.get(java.util.Calendar.MONTH), c.get(java.util.Calendar.DAY_OF_MONTH)).show()
    }
}
