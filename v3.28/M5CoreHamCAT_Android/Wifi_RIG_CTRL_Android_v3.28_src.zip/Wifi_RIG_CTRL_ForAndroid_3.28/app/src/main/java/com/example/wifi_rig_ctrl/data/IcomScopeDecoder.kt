package com.ji1ore.wifi_rig_ctrl.data

/**
 * Icom CI-V スコープ波形(コマンド 27 00)デコーダ。
 *
 * これは「① ネイティブスコープ」方式(受信音と両立する広帯域スコープ)の中核。
 * リグ内蔵DSPが作ったスペクトラム波形を 27 00 で受け取り、1掃引ぶんの
 * レベル配列(0f..1f)へ組み立てる。VFOを動かさないので受信音は途切れない。
 *
 * ── 27 00 フレームの中身(FE FE [dst] [src] を除いた cmd 以降) ──
 *   27 00 q w e r [t...] y [u...]
 *     q: Main/Sub        (0x00=Main, 0x01=Sub)
 *     w: 分割の現在番号   (0x01..0x0B)
 *     e: 分割総数        (0x01=LAN 一括, 0x0B=USB 11分割)
 *     r: Center/Fixed    (0x00=Center, 0x01=Fixed)   ※分割1 または LAN一括のみ
 *     t: 波形情報        Center:中心周波数(5B BCD LE)+span / Fixed:下端+上端(各5B BCD LE)
 *     y: 範囲外フラグ     (0x00=in range, 0x01=out of range → u 省略)
 *     u: 波形データ       0..160 を 全475点
 *
 * LAN(e=0x01): 1フレームに q..y + u(475点) が全部入る。
 * USB(e=0x0B): 分割1 = q..y のみ(uなし)、分割2..11 = q w e + u チャンク。連結して475点。
 *
 * 周波数軸(開始/終了Hz)は呼び出し側が「コマンドした span と現在の中心周波数」から与える。
 * フレーム内の t をバイト精度で解釈しなくても波形は復元できる(uは末尾/チャンクで取れる)ため、
 * 機種差の大きい t パースには依存しない堅牢設計。中心周波数の best-effort パースだけ補助的に提供。
 */
class IcomScopeDecoder {

    companion object {
        const val WAVE_POINTS = 475        // IC-705/IC-7300/IC-9700 の波形点数
        private const val WAVE_MAX = 160.0 // データレンジ 0..160
    }

    /** 1掃引完成時に呼ばれる。levels は 0f..1f に正規化済み・長さ WAVE_POINTS。 */
    @Volatile var onSweep: ((levels: FloatArray) -> Unit)? = null

    // USB 分割の組み立てバッファ
    private val accum = ArrayList<Int>(WAVE_POINTS + 32)
    private var expectDiv = 1           // 次に来るはずの分割番号(順序崩れ検出用)
    private var lastOutOfRange = false

    /**
     * cacheCivFrames から 27 00 フレーム1件ぶんを渡す。
     * @param body FE FE を除いた本体。body[0]=dst, [1]=src, [2]=0x27, [3]=0x00, [4]=q ...
     */
    fun feed(body: IntArray) {
        if (body.size < 7) return
        if (body[2] != 0x27 || body[3] != 0x00) return
        // val main = body[4]            // q: Main/Sub(今はMainのみ対象)
        val cur   = body[5]              // w
        val total = body[6]              // e

        if (total <= 1) {
            // LAN 一括: q w e r [t] y [u(475)]。u は末尾の WAVE_POINTS バイト。
            // r,t,y の合計長は機種で変わるので、u を「末尾から WAVE_POINTS 個」で取る。
            val payloadEnd = body.size    // FD は呼び出し側で除去済み
            // y(範囲外)判定: u が付かないほど短ければ out-of-range とみなす
            if (payloadEnd - 7 < WAVE_POINTS) { lastOutOfRange = true; return }
            lastOutOfRange = false
            val start = payloadEnd - WAVE_POINTS
            emit(IntArray(WAVE_POINTS) { body[start + it] })
            return
        }

        // USB 分割
        if (cur <= 1) {
            // 分割1 = ヘッダのみ(uなし)。バッファを初期化して以降のチャンクを待つ。
            accum.clear()
            expectDiv = 2
            lastOutOfRange = false
            return
        }
        // 分割2..total = q w e の後ろ(index 7 以降)が波形チャンク
        if (cur != expectDiv) {
            // 順序崩れ/取りこぼし → この掃引は破棄
            accum.clear(); expectDiv = 1; return
        }
        for (k in 7 until body.size) accum.add(body[k])
        expectDiv++
        if (cur >= total) {
            // 最終分割。累積点数を WAVE_POINTS に合わせて確定。
            if (accum.size >= WAVE_POINTS) {
                emit(IntArray(WAVE_POINTS) { accum[it] })
            }
            accum.clear(); expectDiv = 1
        }
    }

    private fun emit(points: IntArray) {
        val out = FloatArray(points.size) { i ->
            val v = points[i].coerceIn(0, 160)
            (v / WAVE_MAX).toFloat().coerceIn(0f, 1f)
        }
        onSweep?.invoke(out)
    }

    /** 状態リセット(スコープ開始/停止時に呼ぶ)。 */
    fun reset() { accum.clear(); expectDiv = 1; lastOutOfRange = false }

    /**
     * best-effort: Center モード分割1/LAN一括フレームから中心周波数(Hz)を取り出す。
     * 5バイト BCD LE(10Hz..1GHz)。失敗時 null。周波数軸は通常これに依存せず
     * 呼び出し側が span と現在周波数から与えるが、検算用に提供する。
     */
    fun tryParseCenterHz(body: IntArray): Long? {
        // body: ..[4]=q [5]=w [6]=e [7]=r [8..12]=freq(5B BCD LE) (Centerモード時)
        if (body.size < 13) return null
        if (body[7] != 0x00) return null           // Center モードのみ
        var hz = 0L
        var mul = 1L
        for (i in 8..12) {
            val b = body[i]
            val lo = b and 0x0F
            val hi = (b shr 4) and 0x0F
            if (lo > 9 || hi > 9) return null
            hz += lo * mul; mul *= 10
            hz += hi * mul; mul *= 10
        }
        return hz
    }
}
