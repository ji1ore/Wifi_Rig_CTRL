package com.ji1ore.wifi_rig_ctrl.ui.theme

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

/**
 * 画面(View ツリー)へブランド・テーマ(ThemePalette)を一括適用するヘルパー。
 *
 * 設計思想:
 *   レイアウトの固定色は全画面で共通の慣習（黒背景 + 白〜グレー文字 + グレーのボタン地）で書かれている。
 *   そこで **ニュートラル色（無彩色に近い色）だけ** をパレットの役割色へ対応付け、
 *   **機能色（青/シアン/緑/赤/橙/紫 などの有彩色）はそのまま通す**。
 *   → 「テーマが地色と中立色を決め、機能アクセント色は一貫」という破綻しにくい方針。
 *   → 昼/夜は ThemePalette 側(day 引数)で吸収されるので、ここは昼夜を意識しなくてよい。
 *
 * 注意: 独自にテーマ描画している画面(MainControlFragment 等)には適用しないこと（二重適用になる）。
 */
object ThemeApply {

    /** 現在のテーマ×昼夜を View ツリー全体へ適用する。 */
    fun apply(root: View, theme: UiTheme, day: Boolean) {
        apply(root, getThemePalette(theme, day))
    }

    fun apply(root: View, pal: ThemePalette) {
        recolor(root, pal)
        if (root is ViewGroup) {
            for (i in 0 until root.childCount) apply(root.getChildAt(i), pal)
        }
    }

    private fun recolor(v: View, pal: ThemePalette) {
        // 背景（単色 ColorDrawable のみ対象。画像/セレクタ等は触らない）
        (v.background as? ColorDrawable)?.let { cd ->
            mapBackground(cd.color, pal)?.let { v.setBackgroundColor(it) }
        }
        // backgroundTint（ボタン地）
        v.backgroundTintList?.let { tl ->
            mapTint(tl.defaultColor, pal)?.let { v.backgroundTintList = android.content.res.ColorStateList.valueOf(it) }
        }
        // テキスト色
        if (v is TextView) {
            mapText(v.currentTextColor, pal)?.let { v.setTextColor(it) }
            // ヒント色も中立なら合わせる
            mapText(v.currentHintTextColor, pal)?.let { v.setHintTextColor(it) }
        }
    }

    // ---- 色分類ユーティリティ ----

    /** 無彩色に近いか（R/G/B の広がりが小さい）。tint は青灰色も拾うため閾値を大きめに。 */
    private fun isNeutral(c: Int, spread: Int): Boolean {
        val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
        val mx = maxOf(r, g, b); val mn = minOf(r, g, b)
        return (mx - mn) <= spread
    }

    private fun lum(c: Int): Float =
        (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f

    private fun withAlpha(c: Int, a: Int): Int =
        Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    // ---- 役割マッピング（null = 変更しない＝機能色はそのまま通す）----

    /** 背景: 黒系→bgDark、暗いグレー/暗色パネル→panelBg。半透明や有彩色は触らない。 */
    private fun mapBackground(c: Int, pal: ThemePalette): Int? {
        if (Color.alpha(c) < 0xFF) return null          // スクリム等の半透明は維持
        val l = lum(c)
        // 非常に暗い色は地色扱い（青みがかった暗色パネル #050B19 等も含めて地に寄せる）
        if (l < 0.10f) return pal.bgDark
        // 暗〜中間のニュートラルはパネル面に
        if (isNeutral(c, 28) && l < 0.42f) return pal.panelBg
        // 明るいニュートラル(#DDDDDD 等)はパネル面(昼は明色)に
        if (isNeutral(c, 16) && l >= 0.80f) return pal.panelBg
        return null
    }

    /** ボタン地: 無彩色〜青灰色→btnIdle。有彩色(青/緑/赤/橙/紫)はそのまま。 */
    private fun mapTint(c: Int, pal: ThemePalette): Int? {
        if (Color.alpha(c) < 0xFF) return null
        // 青灰色(#263238,#37474F,#455A64,#546E7A)も拾うため広めの spread
        if (isNeutral(c, 40) && lum(c) < 0.45f) return pal.btnIdle
        return null
    }

    /** テキスト: 無彩色の白〜グレーのみ役割化。有彩色(機能色)はそのまま。 */
    private fun mapText(c: Int, pal: ThemePalette): Int? {
        if (Color.alpha(c) < 0x40) return null          // ほぼ透明は維持
        if (!isNeutral(c, 20)) return null              // 有彩色テキストは機能色として維持
        val l = lum(c)
        val primary = ThemePalette.contrastTextColor(pal.bgDark)   // 地色に対して可読な主色(白/黒)
        return when {
            l >= 0.60f -> primary                        // #FFFFFF,#DDDDDD 等 → 主テキスト
            l >= 0.33f -> pal.textSecondary              // #AAAAAA,#888888 → 二次テキスト
            else       -> withAlpha(pal.textSecondary, 0xA0) // #666/#555/#444 → 二次を淡く(抑えめ)
        }
    }
}
