package com.ji1ore.wifi_rig_ctrl.ui.theme

import androidx.annotation.ColorInt

/**
 * ブランド共通のカラートークン（デザイン基盤）。
 *
 * これは 3 プラットフォーム（Android / iOS / M5Stack）で共有する「ブランド層」の唯一の出典。
 * 実色は M5Stack ファーム v2.20 の getThemePalette()（main_ctrl.cpp:167-313）と 1:1 で一致させてある。
 * 役割（セマンティック名）も M5 側と同じにしてあるので、iOS へ移植する際も同じ表を写すだけで済む。
 *
 * 運用方針（前回合意の「ブランド層は統一・操作層はネイティブ」）:
 *   - 配色は 4 テーマ × 昼/夜 でこの表が正。画面はこのトークンを参照して描画する。
 *   - テーマ切替はリソース修飾子ではなくランタイム（この Kotlin パレット）で行う。
 *     既存 UI がカスタム View 描画中心のため、resource qualifier より実装整合が高い。
 */

/** 配色テーマ。index / displayName は M5 の uiTheme / uiThemeNames と一致。 */
enum class UiTheme(val index: Int, val displayName: String) {
    OCEAN(0, "OCN"),   // 従来配色（既定）
    AMBER(1, "AMB"),   // 真空管/VFD 風の琥珀色
    MONO(2, "MONO"),   // 無彩色・最大コントラスト
    AQUA(3, "AQUA");   // 青×緑基調

    companion object {
        fun fromIndex(i: Int): UiTheme = entries.firstOrNull { it.index == i } ?: OCEAN
    }
}

/**
 * メイン画面の配色一式。各ロールの意味は M5 の getThemePalette() 引数に対応。
 * 全フィールドは不透明 ARGB（@ColorInt Int）。
 */
data class ThemePalette(
    @ColorInt val bgDark: Int,          // 画面背景
    @ColorInt val panelBg: Int,         // ヘッダー/パネル/カード面
    @ColorInt val border: Int,          // 枠線・区切り
    @ColorInt val accentTeal: Int,      // 主アクセント（テーマ代表色）
    @ColorInt val accentBlue: Int,      // 副アクセント
    @ColorInt val textSecondary: Int,   // 二次テキスト
    @ColorInt val txRed: Int,           // 送信(TX)表示
    @ColorInt val chipBg: Int,          // チップ/カード背景（昼夜・テーマ問わず濃色）
    @ColorInt val btnIdle: Int,         // ボタン非アクティブ背景（濃色固定）
    @ColorInt val btnIdleBorder: Int,   // 同・枠線
    @ColorInt val spkOn: Int,           // スピーカーON状態
    @ColorInt val aprsOn: Int,          // APRS状態
    @ColorInt val navOrange: Int,       // ナビ/ダウン操作
) {
    companion object {
        /** 昼モードを示すチップの固定色（M5 の dnBg 黄色 0xffd500）。 */
        @ColorInt const val DAY_CHIP_YELLOW: Int = 0xFFFFD500.toInt()

        @ColorInt const val WHITE: Int = 0xFFFFFFFF.toInt()
        @ColorInt const val BLACK: Int = 0xFF000000.toInt()

        /** 背景色に対して可読な文字色（黒/白）を返す。M5 contrastTextColor と同判定（輝度>0.55→黒）。 */
        @ColorInt
        fun contrastTextColor(@ColorInt bg: Int): Int {
            val r = ((bg shr 16) and 0xFF) / 255f
            val g = ((bg shr 8) and 0xFF) / 255f
            val b = (bg and 0xFF) / 255f
            val lum = 0.299f * r + 0.587f * g + 0.114f * b
            return if (lum > 0.55f) BLACK else WHITE
        }
    }
}

/** 不透明 ARGB へ。rgb は 0xRRGGBB（24bit）を渡す。 */
@ColorInt
private fun rgb(value: Long): Int = (0xFF000000L or value).toInt()

/**
 * テーマ × 昼/夜 から配色一式を決定する。M5 getThemePalette() の移植。
 */
fun getThemePalette(theme: UiTheme, day: Boolean): ThemePalette = when (theme) {

    UiTheme.AMBER -> if (day) ThemePalette(
        bgDark = rgb(0xF7F0E2), panelBg = rgb(0xECDFC0), border = rgb(0x8A7550),
        accentTeal = rgb(0x8A5A00), accentBlue = rgb(0x6B4C00), textSecondary = rgb(0x5C4A28),
        txRed = rgb(0xC81E14), chipBg = rgb(0x241A0C), btnIdle = rgb(0x2A1E0E),
        btnIdleBorder = rgb(0x6B5530), spkOn = rgb(0x4A7A1A), aprsOn = rgb(0xA06A00),
        navOrange = rgb(0xA05000),
    ) else ThemePalette(
        bgDark = rgb(0x100B02), panelBg = rgb(0x1F150A), border = rgb(0x4A3A1A),
        accentTeal = rgb(0xFFB000), accentBlue = rgb(0xFFCF40), textSecondary = rgb(0xA68A55),
        txRed = rgb(0xFF3B30), chipBg = rgb(0x241A0C), btnIdle = rgb(0x2A1E0E),
        btnIdleBorder = rgb(0x5A4620), spkOn = rgb(0x8FD13F), aprsOn = rgb(0xFFCF40),
        navOrange = rgb(0xFF8A00),
    )

    UiTheme.MONO -> if (day) ThemePalette(
        bgDark = rgb(0xFFFFFF), panelBg = rgb(0xE6E6E6), border = rgb(0x404040),
        accentTeal = rgb(0x000000), accentBlue = rgb(0x202020), textSecondary = rgb(0x202020),
        txRed = rgb(0xC00000), chipBg = rgb(0x1A1A1A), btnIdle = rgb(0x202020),
        btnIdleBorder = rgb(0x707070), spkOn = rgb(0x303030), aprsOn = rgb(0x000000),
        navOrange = rgb(0x606060),
    ) else ThemePalette(
        bgDark = rgb(0x000000), panelBg = rgb(0x141414), border = rgb(0x555555),
        accentTeal = rgb(0xFFFFFF), accentBlue = rgb(0xC0C0C0), textSecondary = rgb(0xAAAAAA),
        txRed = rgb(0xFF2020), chipBg = rgb(0x1A1A1A), btnIdle = rgb(0x202020),
        btnIdleBorder = rgb(0x606060), spkOn = rgb(0xE0E0E0), aprsOn = rgb(0xFFFFFF),
        navOrange = rgb(0xB0B0B0),
    )

    UiTheme.AQUA -> if (day) ThemePalette(
        bgDark = rgb(0xEAF5F0), panelBg = rgb(0xCFE8DA), border = rgb(0x5A8F7A),
        accentTeal = rgb(0x1AA05A), accentBlue = rgb(0x0A6CD9), textSecondary = rgb(0x2E4A3E),
        txRed = rgb(0xD81F16), chipBg = rgb(0x14241E), btnIdle = rgb(0x182A22),
        btnIdleBorder = rgb(0x4A6658), spkOn = rgb(0x22C16B), aprsOn = rgb(0xE09A00),
        navOrange = rgb(0xE07A00),
    ) else ThemePalette(
        bgDark = rgb(0x071412), panelBg = rgb(0x0E1F1A), border = rgb(0x223A30),
        accentTeal = rgb(0x2AE87A), accentBlue = rgb(0x3FA7FF), textSecondary = rgb(0x7A9A8C),
        txRed = rgb(0xFF3B30), chipBg = rgb(0x14241E), btnIdle = rgb(0x182A22),
        btnIdleBorder = rgb(0x304A3E), spkOn = rgb(0x34F09A), aprsOn = rgb(0xFBBF24),
        navOrange = rgb(0xFF9500),
    )

    UiTheme.OCEAN -> if (day) ThemePalette(
        bgDark = rgb(0xF0F2F5), panelBg = rgb(0xD9DDE2), border = rgb(0x8A9199),
        accentTeal = rgb(0x008F80), accentBlue = rgb(0x005BC9), textSecondary = rgb(0x40464E),
        txRed = rgb(0xD81F16), chipBg = rgb(0x1C2128), btnIdle = rgb(0x21262D),
        btnIdleBorder = rgb(0x555C66), spkOn = rgb(0x1FA877), aprsOn = rgb(0xE09A00),
        navOrange = rgb(0xE07A00),
    ) else ThemePalette(
        bgDark = rgb(0x0D1117), panelBg = rgb(0x161B22), border = rgb(0x30363D),
        accentTeal = rgb(0x00D9C0), accentBlue = rgb(0x3FA7FF), textSecondary = rgb(0x8B949E),
        txRed = rgb(0xFF3B30), chipBg = rgb(0x1C2128), btnIdle = rgb(0x21262D),
        btnIdleBorder = rgb(0x3A404A), spkOn = rgb(0x34D399), aprsOn = rgb(0xFBBF24),
        navOrange = rgb(0xFF9500),
    )
}
