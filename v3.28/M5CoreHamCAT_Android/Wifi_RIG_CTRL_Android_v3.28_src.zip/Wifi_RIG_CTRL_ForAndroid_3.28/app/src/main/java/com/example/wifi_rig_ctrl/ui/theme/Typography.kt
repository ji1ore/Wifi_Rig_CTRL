package com.ji1ore.wifi_rig_ctrl.ui.theme

import android.graphics.Typeface

/**
 * タイポグラフィ型スケール（デザイン基盤トークン）。
 *
 * 値は res/values/dimens.xml の text_* と一致させてある。
 * XML レイアウトは @dimen/text_* を、Canvas/Paint 等のプログラム描画はこの object を参照する。
 * 単位は sp（端末のフォントサイズ設定に追従）。
 *
 * iOS 側は SwiftUI の Font（.largeTitle/.title/.body/...）へ同じ役割で対応付ける。
 */
object Typography {
    /** 役割別フォントサイズ（sp）。 */
    const val DISPLAY_SP = 34f    // 周波数など特大表示
    const val HEADLINE_SP = 24f   // 画面見出し
    const val TITLE_SP = 20f      // セクション見出し
    const val SUBTITLE_SP = 18f   // 小見出し
    const val BODY_SP = 16f       // 本文
    const val LABEL_SP = 14f      // ラベル/ボタン文字
    const val CAPTION_SP = 12f    // 補足・注記

    /** 周波数・S メーター等の数値表示は等幅（M5 の monospacedDigit に相当）。 */
    val MONO: Typeface = Typeface.MONOSPACE
    val DEFAULT: Typeface = Typeface.DEFAULT
    val DEFAULT_BOLD: Typeface = Typeface.DEFAULT_BOLD
}
