import SwiftUI

// =============================================================================
//  Theme.swift — ブランド共通カラートークン（iOS / デザイン基盤）
// =============================================================================
//  3プラットフォーム共有の「ブランド層」。実色は Android `ui/theme/ThemePalette.kt`
//  および M5Stack `getThemePalette()`（main_ctrl.cpp）と 1:1 一致。
//  テーマ切替はランタイム（本トークン＋ThemeStore）で行う。
//  ※各SwiftUIビューへの適用(.indigo等の置換)は段階適用（iOS側rollout）で実施。
// =============================================================================

extension Color {
    /// 0xRRGGBB の 24bit から不透明 Color を作る。
    init(hex: UInt32) {
        let r = Double((hex >> 16) & 0xFF) / 255.0
        let g = Double((hex >> 8) & 0xFF) / 255.0
        let b = Double(hex & 0xFF) / 255.0
        self.init(.sRGB, red: r, green: g, blue: b, opacity: 1.0)
    }
}

enum UiTheme: Int, CaseIterable, Identifiable {
    case ocean = 0, amber = 1, mono = 2, aqua = 3
    var id: Int { rawValue }
    var displayName: String {
        switch self {
        case .ocean: return "OCN"; case .amber: return "AMB"
        case .mono:  return "MONO"; case .aqua:  return "AQUA"
        }
    }
    static func from(index: Int) -> UiTheme { UiTheme(rawValue: index) ?? .ocean }
}

struct ThemePalette {
    let bgDark: Color, panelBg: Color, border: Color
    let accentTeal: Color, accentBlue: Color, textSecondary: Color
    let txRed: Color, chipBg: Color, btnIdle: Color, btnIdleBorder: Color
    let spkOn: Color, aprsOn: Color, navOrange: Color

    static func contrastText(on bg: Color) -> Color {
        #if canImport(UIKit)
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        UIColor(bg).getRed(&r, green: &g, blue: &b, alpha: &a)
        return (0.299 * r + 0.587 * g + 0.114 * b) > 0.55 ? .black : .white
        #else
        return .white
        #endif
    }
}

/// テーマ×昼夜 → パレット（Android getThemePalette の移植・実色一致）
func themePalette(_ theme: UiTheme, day: Bool) -> ThemePalette {
    switch theme {
    case .amber:
        return day
        ? ThemePalette(bgDark: Color(hex: 0xF7F0E2), panelBg: Color(hex: 0xECDFC0), border: Color(hex: 0x8A7550),
                       accentTeal: Color(hex: 0x8A5A00), accentBlue: Color(hex: 0x6B4C00), textSecondary: Color(hex: 0x5C4A28),
                       txRed: Color(hex: 0xC81E14), chipBg: Color(hex: 0x241A0C), btnIdle: Color(hex: 0x2A1E0E),
                       btnIdleBorder: Color(hex: 0x6B5530), spkOn: Color(hex: 0x4A7A1A), aprsOn: Color(hex: 0xA06A00), navOrange: Color(hex: 0xA05000))
        : ThemePalette(bgDark: Color(hex: 0x100B02), panelBg: Color(hex: 0x1F150A), border: Color(hex: 0x4A3A1A),
                       accentTeal: Color(hex: 0xFFB000), accentBlue: Color(hex: 0xFFCF40), textSecondary: Color(hex: 0xA68A55),
                       txRed: Color(hex: 0xFF3B30), chipBg: Color(hex: 0x241A0C), btnIdle: Color(hex: 0x2A1E0E),
                       btnIdleBorder: Color(hex: 0x5A4620), spkOn: Color(hex: 0x8FD13F), aprsOn: Color(hex: 0xFFCF40), navOrange: Color(hex: 0xFF8A00))
    case .mono:
        return day
        ? ThemePalette(bgDark: Color(hex: 0xFFFFFF), panelBg: Color(hex: 0xE6E6E6), border: Color(hex: 0x404040),
                       accentTeal: Color(hex: 0x000000), accentBlue: Color(hex: 0x202020), textSecondary: Color(hex: 0x202020),
                       txRed: Color(hex: 0xC00000), chipBg: Color(hex: 0x1A1A1A), btnIdle: Color(hex: 0x202020),
                       btnIdleBorder: Color(hex: 0x707070), spkOn: Color(hex: 0x303030), aprsOn: Color(hex: 0x000000), navOrange: Color(hex: 0x606060))
        : ThemePalette(bgDark: Color(hex: 0x000000), panelBg: Color(hex: 0x141414), border: Color(hex: 0x555555),
                       accentTeal: Color(hex: 0xFFFFFF), accentBlue: Color(hex: 0xC0C0C0), textSecondary: Color(hex: 0xAAAAAA),
                       txRed: Color(hex: 0xFF2020), chipBg: Color(hex: 0x1A1A1A), btnIdle: Color(hex: 0x202020),
                       btnIdleBorder: Color(hex: 0x606060), spkOn: Color(hex: 0xE0E0E0), aprsOn: Color(hex: 0xFFFFFF), navOrange: Color(hex: 0xB0B0B0))
    case .aqua:
        return day
        ? ThemePalette(bgDark: Color(hex: 0xEAF5F0), panelBg: Color(hex: 0xCFE8DA), border: Color(hex: 0x5A8F7A),
                       accentTeal: Color(hex: 0x1AA05A), accentBlue: Color(hex: 0x0A6CD9), textSecondary: Color(hex: 0x2E4A3E),
                       txRed: Color(hex: 0xD81F16), chipBg: Color(hex: 0x14241E), btnIdle: Color(hex: 0x182A22),
                       btnIdleBorder: Color(hex: 0x4A6658), spkOn: Color(hex: 0x22C16B), aprsOn: Color(hex: 0xE09A00), navOrange: Color(hex: 0xE07A00))
        : ThemePalette(bgDark: Color(hex: 0x071412), panelBg: Color(hex: 0x0E1F1A), border: Color(hex: 0x223A30),
                       accentTeal: Color(hex: 0x2AE87A), accentBlue: Color(hex: 0x3FA7FF), textSecondary: Color(hex: 0x7A9A8C),
                       txRed: Color(hex: 0xFF3B30), chipBg: Color(hex: 0x14241E), btnIdle: Color(hex: 0x182A22),
                       btnIdleBorder: Color(hex: 0x304A3E), spkOn: Color(hex: 0x34F09A), aprsOn: Color(hex: 0xFBBF24), navOrange: Color(hex: 0xFF9500))
    case .ocean:
        return day
        ? ThemePalette(bgDark: Color(hex: 0xF0F2F5), panelBg: Color(hex: 0xD9DDE2), border: Color(hex: 0x8A9199),
                       accentTeal: Color(hex: 0x008F80), accentBlue: Color(hex: 0x005BC9), textSecondary: Color(hex: 0x40464E),
                       txRed: Color(hex: 0xD81F16), chipBg: Color(hex: 0x1C2128), btnIdle: Color(hex: 0x21262D),
                       btnIdleBorder: Color(hex: 0x555C66), spkOn: Color(hex: 0x1FA877), aprsOn: Color(hex: 0xE09A00), navOrange: Color(hex: 0xE07A00))
        : ThemePalette(bgDark: Color(hex: 0x0D1117), panelBg: Color(hex: 0x161B22), border: Color(hex: 0x30363D),
                       accentTeal: Color(hex: 0x00D9C0), accentBlue: Color(hex: 0x3FA7FF), textSecondary: Color(hex: 0x8B949E),
                       txRed: Color(hex: 0xFF3B30), chipBg: Color(hex: 0x1C2128), btnIdle: Color(hex: 0x21262D),
                       btnIdleBorder: Color(hex: 0x3A404A), spkOn: Color(hex: 0x34D399), aprsOn: Color(hex: 0xFBBF24), navOrange: Color(hex: 0xFF9500))
    }
}

/// 選択状態の保持（UserDefaults。キー名は Android prefs と揃える）
@Observable
final class ThemeStore {
    var theme: UiTheme { didSet { UserDefaults.standard.set(theme.rawValue, forKey: "colorTheme") } }
    var day: Bool      { didSet { UserDefaults.standard.set(day, forKey: "uiDayMode") } }
    init() {
        self.theme = UiTheme.from(index: UserDefaults.standard.integer(forKey: "colorTheme"))
        self.day = UserDefaults.standard.bool(forKey: "uiDayMode")
    }
    var palette: ThemePalette { themePalette(theme, day: day) }
    func cycleTheme() { theme = UiTheme.from(index: (theme.rawValue + 1) % UiTheme.allCases.count) }
    func toggleDay()  { day.toggle() }
}

private struct ThemePaletteKey: EnvironmentKey {
    static let defaultValue: ThemePalette = themePalette(.ocean, day: false)
}
extension EnvironmentValues {
    var themePalette: ThemePalette {
        get { self[ThemePaletteKey.self] }
        set { self[ThemePaletteKey.self] = newValue }
    }
}
