package com.ji1ore.wifi_rig_ctrl.data

import kotlin.math.*

/**
 * RX CW decoder (multi-channel support)
 *
 * Algorithm:
 *   1. Compute spectrum each frame with 256-point FFT (50% overlap)
 *   2. Detect local maxima in CW band (300-3000Hz), track top N_CHAN
 *   3. Each channel independently processes energy at its fixed frequency bin
 *   4. Determine key state per channel via percentile threshold + hysteresis
 *   5. Decode characters by judging dit/dah/space per frame
 */
class CwDecoder(private val sampleRate: Int = 8000) {

    /** (char, channelIdx 0..N_CHAN-1) */
    /** (char, channelIdx, morseCode) — morseCode is the raw dit/dah string decoded ("" for spaces),
     *  so a downstream corrector can compare by Morse-element similarity rather than by letters. */
    var onCharDecoded: ((Char, Int, String) -> Unit)? = null
    /** (channelIdx, freqHz) — freqHz=0 means channel deactivated */
    var onChannelFreq: ((Int, Int) -> Unit)? = null
    /** Slot swap notification (slotA, slotB) */
    var onChannelSwap: ((Int, Int) -> Unit)? = null

    // ── FFT settings ─────────────────────────────────────────────
    private val FFT_SIZE  = 1024             // 512→1024: 7.8Hz/bin — halves per-bin noise BW (~+3dB weak-signal SNR)
    private val HOP_SIZE  = 64              // 128→64: 8ms time resolution (93.75% overlap) — finer
                                            // element/gap timing to match what the ear resolves
    private val msPerHop  = maxOf(1, HOP_SIZE * 1000 / sampleRate)
    private val binHz     = sampleRate.toFloat() / FFT_SIZE
    private val cwBinMin  = (300f  / binHz).toInt().coerceAtLeast(1)
    private val cwBinMax  = (3000f / binHz).toInt().coerceAtMost(FFT_SIZE / 2 - 1)
    private val FREQ_TOL      = 8     // Frequency match tolerance in bins (±62Hz @7.8Hz/bin)
    private val DRIFT_RADIUS  = 12    // Frequency drift range a channel can track (±94Hz @7.8Hz/bin)
    private val PEAK_SNR_MIN  = 5f   // keep noise-driven false decodes down (clean-copy priority)
    // User-selectable manual key-detect threshold. -1 = automatic (Otsu). Otherwise 0..1: the key-down
    // threshold is placed that many ×-gain above the tracked NOISE FLOOR (a manual squelch on the
    // detected tone). Higher = reject more noise; lower = catch weaker signals.
    @Volatile var manualNoiseLevel = -1f
    private val CAND_PROMOTE  = maxOf(2, 32 / msPerHop)  // promote candidate to channel after ≈32ms continuous signal

    private val hannWin = FloatArray(FFT_SIZE) { i ->
        (0.5 * (1.0 - cos(2.0 * PI * i / (FFT_SIZE - 1)))).toFloat()
    }
    private val ringBuf   = FloatArray(FFT_SIZE)
    private var ringHead  = 0
    private var hopCount  = 0
    private val fftRe     = FloatArray(FFT_SIZE)
    private val fftIm     = FloatArray(FFT_SIZE)
    private val specPow   = FloatArray(FFT_SIZE / 2)
    private val cwBandBuf     = FloatArray(FFT_SIZE / 2)  // scratch buffer for noise floor estimation
    // Channel candidates: bin → consecutive frames exceeding SNR threshold
    private val peakCandidates = LinkedHashMap<Int, Int>()

    // ── dit length parameters ─────────────────────────────────────
    private val ditWinsInit = maxOf(2f, 32f / msPerHop)   // Float: ≈32ms initial value (all speeds)
    private val ditWinsMax  = maxOf(3f, 300f / msPerHop)  // Float: ≈300ms upper limit (~4 WPM)
    private val ditWinsMin  = maxOf(2f, 24f / msPerHop)   // Float: ≈24ms static lower limit

    // ── Channel deactivation threshold (≈4 seconds without key ON) ──
    private val DEACT_THRESH = maxOf(10, 4000 / msPerHop)

    // ── White noise detection: flat spectrum if noisePow/maxPow > threshold ──
    private val NOISE_FLATNESS_THRESH = 0.35f  // 0.5→0.35: avoid falsely detecting weak signals as noise

    // ── Public constants ──────────────────────────────────────────
    companion object {
        const val N_CHAN = 5
        // Mean ON-SNR below which a leading element is treated as a noise blip (near the noise floor).
        const val NOISE_ELEM_SNR = 4f
        // Adaptive ON-threshold margin: the key-down threshold is placed at least this many standard
        // deviations of the NOISE class above the noise mean. Higher = more noise rejection in a hashy
        // band; a quiet band keeps the lower fractional placement. Tunable per RF environment.
        const val NOISE_MARGIN_SD = 1.5f
        val MORSE_TABLE: Map<String, Char> = mapOf(
            ".-"   to 'A', "-..."  to 'B', "-.-." to 'C', "-.."  to 'D',
            "."    to 'E', "..-."  to 'F', "--."  to 'G', "...." to 'H',
            ".."   to 'I', ".---"  to 'J', "-.-"  to 'K', ".-.." to 'L',
            "--"   to 'M', "-."    to 'N', "---"  to 'O', ".--." to 'P',
            "--.-" to 'Q', ".-."   to 'R', "..."  to 'S', "-"    to 'T',
            "..-"  to 'U', "...-"  to 'V', ".--"  to 'W', "-..-" to 'X',
            "-.--" to 'Y', "--.."  to 'Z',
            "-----" to '0', ".----" to '1', "..---" to '2', "...--" to '3',
            "....-" to '4', "....." to '5', "-...." to '6', "--..." to '7',
            "---.." to '8', "----." to '9',
            ".-.-.-"  to '.', "--..--" to ',', "..--.."  to '?',
            "-.--."   to '(', "-.--.-" to ')', "-..-."   to '/',
            ".-.-."   to '+', "-...-"  to '=', ".-..."   to '&',
            "---..."  to ':', "-.-.-"  to ';', ".--.-."  to '@',
            ".----."  to '\''
        )
        val CHAR_TO_MORSE: Map<Char, String> = MORSE_TABLE.entries.associate { (morse, char) -> char to morse }

        // Run-together prosigns sent as ONE element blob (no inter-char gap). Mapped to their component
        // letters so they emit as adjacent chars ("BK", "SK"). Only codes that do NOT collide with a
        // single-char table entry are listed (AR=.-.-. / KN=-.--. / AS=.-... / BT=-...- clash with
        // + ( & = and are left to the table).
        val PROSIGNS: Map<String, List<Pair<Char, String>>> = mapOf(
            "-...-.-" to listOf('B' to "-...", 'K' to "-.-"),   // BK  (break)
            "...-.-"  to listOf('S' to "...",  'K' to "-.-")    // SK  (end of contact)
        )

        /**
         * Recover a near-miss code (one dropped/added/flipped element) to the closest
         * valid character. Only commits when the best match is within edit-distance 1 AND
         * strictly closer than every other candidate, so ambiguous garbage still returns
         * null (→ '?') rather than guessing wrong.
         */
        fun nearestMorse(code: String): Char? {
            if (code.isEmpty() || code.length > 8) return null
            var best: Char? = null
            var bestD = Int.MAX_VALUE
            var secondD = Int.MAX_VALUE
            for ((m, ch) in MORSE_TABLE) {
                if (abs(m.length - code.length) > 1) continue   // can't be within edit-distance 1
                val d = editDistance(code, m)
                when {
                    d < bestD   -> { secondD = bestD; bestD = d; best = ch }
                    d < secondD -> { secondD = d }
                }
            }
            return if (bestD <= 1 && bestD < secondD) best else null
        }

        private fun editDistance(a: String, b: String): Int {
            val prev = IntArray(b.length + 1) { it }
            val cur  = IntArray(b.length + 1)
            for (i in 1..a.length) {
                cur[0] = i
                for (j in 1..b.length) {
                    val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                    cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
                }
                System.arraycopy(cur, 0, prev, 0, cur.size)
            }
            return prev[b.length]
        }

        /** Characters whose Morse code is within [maxDist] element edits of [code], with that distance. */
        fun morseCandidates(code: String, maxDist: Int): List<Pair<Char, Int>> {
            if (code.isEmpty() || code.length > 9) return emptyList()
            val out = ArrayList<Pair<Char, Int>>()
            for ((m, ch) in MORSE_TABLE) {
                if (abs(m.length - code.length) > maxDist) continue
                val d = editDistance(code, m)
                if (d <= maxDist) out.add(ch to d)
            }
            return out
        }
    }

    // ── Internal channel ──────────────────────────────────────────
    private inner class Channel(var freqBin: Int, seedSigE: Float, seedNoiseE: Float) {
        val freqHz: Int get() = (freqBin * binHz).toInt()

        private val HIST_SZ         = maxOf(30, 1200 / msPerHop)   // 1600→1200: track QSB fades faster
        private val SUSPEND_THRESH  = maxOf(5, 2500 / msPerHop)   // sleep after 2500ms of silence (slow-CW word gaps)
        private val ELEM_FLUSH_THRESH = maxOf(3, 500 / msPerHop)  // 500ms: force clear pending elements after gap
        private val hist    = FloatArray(HIST_SZ)
        private var histIdx = 0

        private var threshOn  = Float.MAX_VALUE
        private var threshOff = Float.MAX_VALUE
        private var eFloor = 0f          // slow minimum-envelope of energy = tracked noise floor
        private var floorSeeded = false
        private var elemPeak = 0f         // peak energy of the element currently keyed-ON (for AGC-relative OFF)
        private var suspKeyOnFrames = 0  // consecutive key-ON confirmation frames during suspend

        init {
            // Set thresholds immediately if signal is stronger than noise.
            // Having an initial value without waiting for updateThresh ratio requirement prevents MAX_VALUE loop.
            if (seedSigE > seedNoiseE) {
                threshOn  = seedNoiseE + (seedSigE - seedNoiseE) * 0.50f  // 0.60→0.50: handle weak signals
                threshOff = seedNoiseE + (seedSigE - seedNoiseE) * 0.22f  // 0.28→0.22: maintain hysteresis
            }
            // Seed history to stabilize subsequent updateThresh calls
            val seedN = maxOf(CAND_PROMOTE, 8)
            repeat(seedN) { hist[histIdx++ % HIST_SZ] = seedSigE }
            repeat(seedN) { hist[histIdx++ % HIST_SZ] = seedNoiseE }
        }

        var keyOn      = false
        var keyOnWins  = 0
        var keyOffWins = 0
        var charFlushed  = false
        var wordEmitted  = false
        var ditWins      = ditWinsInit
        private var ditSeeded = false   // true once speed has been locked from the first element
        private var unitConfirmed = false   // true once an intra-char gap has pinned the true dit length
        private val elemDurs = ArrayList<Float>()   // raw element (key-ON) durations of the current char
        private val gapDurs  = ArrayList<Float>()   // raw intra-char (key-OFF) gaps of the current char
        private var ctxP2 = ' '   // previous-previous emitted char (CW trigram context)
        private var ctxP1 = ' '   // previous emitted char

        var framesNoRealElement = 0
        var hadSignal           = false
        var smoothE             = 0f   // Signal strength EMA (for slot promotion)
        var snrLin              = 0f   // peak-hold linear SNR (for weak-signal word correction)
        var frameSnr            = 0f   // this frame's bin-SNR (set by processFrame)
        private var charSnrSum  = 0f   // Σ frameSnr over the current char's ON frames
        private var charSnrCnt  = 0
        var charSnr             = 0f   // mean ON-SNR of the last decoded char (for confidence colouring)
        private var charESum    = 0f   // Σ (threshold-domain) energy over the current char's ON frames
        var charLevel           = 0f   // last char's mean ON energy ÷ threshOn (>1 = above threshold)
        private var elemSnrSum  = 0f   // Σ frameSnr over the CURRENT element's ON frames
        private var elemSnrCnt  = 0
        private val elemSnrs    = ArrayList<Float>()  // mean ON-SNR per element, parallel to elemDurs

        // A: median-3 envelope smoothing state; B: sub-frame edge-timing state
        private var rawPrev1 = 0f
        private var rawPrev2 = 0f
        private var prevE    = 0f      // previous smoothed energy
        private var edgeFrac = 0f      // sub-frame offset [0,1) of the last key transition

        fun process(rawE: Float, ci: Int) {
            // A: median-of-3 envelope smoothing. Rejects single-frame dropouts (which split
            //    one element into two) and single-frame spikes (spurious elements) without
            //    blurring edges — a majority vote acts as a 1-frame debounce.
            val energy = median3(rawE, rawPrev1, rawPrev2)
            rawPrev2 = rawPrev1; rawPrev1 = rawE
            val pE = prevE; prevE = energy   // advance prev-frame energy for sub-frame timing

            smoothE = smoothE * 0.97f + energy * 0.03f  // τ≈530ms
            hist[histIdx % HIST_SZ] = energy
            histIdx++
            val valid = minOf(histIdx, HIST_SZ)

            // Track the noise floor as a slow minimum-envelope: snap DOWN to quiet frames instantly,
            // rise only very slowly. CW's frequent key-up gaps keep this pinned to the true noise floor.
            if (!floorSeeded) { eFloor = energy; floorSeeded = true }
            else eFloor = if (energy < eFloor) energy else eFloor * 0.9997f + energy * 0.0003f

            val manual = manualNoiseLevel
            if (manual >= 0f) {
                // Manual squelch: fixed gain above the tracked noise floor (user-selected). No Otsu.
                val gain = 2f + manual * 13f            // 0..1 → 2×..15× the noise floor
                threshOn  = eFloor * gain
                threshOff = eFloor * gain * 0.75f
            } else if (histIdx % 5 == 0 && valid >= 5) updateThresh(valid)

            if (threshOn == Float.MAX_VALUE) {
                if (keyOn) keyOnWins++ else { keyOffWins++; framesNoRealElement++ }
                return
            }

            // Force clear pending elements after 500ms+ gap — prevents previous buffer contaminating after recovery
            if (framesNoRealElement == ELEM_FLUSH_THRESH && elemDurs.isNotEmpty() && !charFlushed) {
                flushChar(ci); charFlushed = true
                keyOn = false; keyOnWins = 0
            }

            // Sleep if no real elements for a long time (noise spikes below ditWinsMin don't reset sleep counter)
            if (framesNoRealElement > SUSPEND_THRESH) {
                if (energy > threshOn) {
                    if (++suspKeyOnFrames >= CAND_PROMOTE) {
                        // Real signal confirmed → wake up
                        framesNoRealElement = 0; keyOffWins = 0; keyOn = false; keyOnWins = 0
                        elemDurs.clear(); gapDurs.clear(); elemSnrs.clear(); charFlushed = false; wordEmitted = false
                        suspKeyOnFrames = 0; ditSeeded = false; unitConfirmed = false; edgeFrac = 0f
                        ctxP2 = ' '; ctxP1 = ' '
                        // Fall through to normal processing (key ON detection)
                    } else return
                } else {
                    suspKeyOnFrames = 0; framesNoRealElement++; return
                }
            }

            // OFF threshold rides the ELEMENT's own peak (AGC-relative), floored by the global threshOff.
            // At a word/transmission onset the global threshOff is still calibrated to the preceding
            // silence (too low), so a fixed threshOff let the first element's decay tail run on — the
            // leading element measured 2–100× too long (5=..... → 6=-....). Cutting OFF at 40% of the
            // element's peak ends it at the true key-up regardless of the stale global threshold.
            val offTh = maxOf(threshOff, elemPeak * 0.4f)
            val isOn = if (keyOn) energy > offTh else energy > threshOn
            if (isOn && !keyOn) {
                // B: sub-frame rising-edge position — where threshOn is crossed between the
                //    previous and current frame. Segment duration = count + (thisFrac - lastFrac),
                //    so the quantization error shrinks from ±1 frame to a fraction of one.
                val fOn = if (energy > pE) ((threshOn - pE) / (energy - pE)).coerceIn(0f, 1f) else 0.5f
                analyzeGap(keyOffWins + (fOn - edgeFrac), ci)
                edgeFrac = fOn
                keyOffWins = 0; charFlushed = false; wordEmitted = false
                keyOn = true; hadSignal = true
                elemPeak = energy                 // start tracking this element's peak
                elemSnrSum = 0f; elemSnrCnt = 0   // start a fresh per-element SNR accumulation
                // Don't reset framesNoRealElement here — reset after real element confirmed in analyzeElement
            } else if (!isOn && keyOn) {
                val fOff = if (pE > energy) ((pE - offTh) / (pE - energy)).coerceIn(0f, 1f) else 0.5f
                analyzeElement(keyOnWins + (fOff - edgeFrac))
                edgeFrac = fOff
                keyOnWins = 0; keyOn = false
            }
            if (keyOn) {
                keyOnWins++
                if (energy > elemPeak) elemPeak = energy
                charSnrSum += frameSnr; charSnrCnt++
                elemSnrSum += frameSnr; elemSnrCnt++
                charESum += energy
            } else {
                keyOffWins++; framesNoRealElement++
                if (!charFlushed  && keyOffWins.toFloat() >= ditWins * 3f) { flushChar(ci); charFlushed = true }
                if (!wordEmitted && hadSignal && keyOffWins.toFloat() >= ditWins * wordGapMul()) {
                    onCharDecoded?.invoke(' ', ci, ""); ctxP2 = ctxP1; ctxP1 = ' '; wordEmitted = true
                }
            }
        }

        private fun updateThresh(valid: Int) {
            // During a long gap the history fills with noise, so normally we must NOT raise the
            // threshold toward it (that makes noise read as key-ON after recovery). But a QSB fade
            // looks the same at first, so instead of freezing we keep computing and allow the
            // threshold to FOLLOW THE SIGNAL DOWN (never up) while gapped — this re-acquires a
            // fading signal instead of missing it with a stale, too-high threshold.
            val gapped = framesNoRealElement > HIST_SZ / 2

            // Otsu's method: split the energy history into noise/signal classes at the point
            // that maximizes between-class variance. Robust for sparse CW where ON frames are
            // a minority (the old fixed 15/85 percentiles assumed a ~even ON/OFF mix).
            var mn = Float.MAX_VALUE; var mx = 0f
            for (i in 0 until valid) { val v = hist[i]; if (v < mn) mn = v; if (v > mx) mx = v }
            if (mx <= 0f || mx < mn * 2f) return   // too little contrast → keep existing calibration

            val nBins = 32
            val bins  = IntArray(nBins)
            val span  = mx - mn
            val scale = (nBins - 1) / span
            for (i in 0 until valid) {
                val idx = ((hist[i] - mn) * scale).toInt().coerceIn(0, nBins - 1)
                bins[idx]++
            }
            var sumAll = 0f
            for (b in 0 until nBins) sumAll += b * bins[b].toFloat()
            var wB = 0; var sumB = 0f; var maxVar = -1f; var splitBin = 0
            for (b in 0 until nBins) {
                wB += bins[b]
                if (wB == 0) continue
                val wF = valid - wB
                if (wF == 0) break
                sumB += b * bins[b].toFloat()
                val mB = sumB / wB
                val mF = (sumAll - sumB) / wF
                val between = wB.toFloat() * wF.toFloat() * (mB - mF) * (mB - mF)
                if (between > maxVar) { maxVar = between; splitBin = b }
            }

            // Mean energy of each class, then keep the same hysteresis placement as before.
            val splitE = mn + (splitBin + 0.5f) / scale
            var loSum = 0f; var loN = 0; var hiSum = 0f; var hiN = 0
            for (i in 0 until valid) {
                val v = hist[i]
                if (v <= splitE) { loSum += v; loN++ } else { hiSum += v; hiN++ }
            }
            if (loN == 0 || hiN == 0) return
            val lo = loSum / loN
            val hi = hiSum / hiN
            if (hi <= lo * 1.5f) return            // insufficient class separation → keep calibration
            // Proven fixed placement between the Otsu noise/signal means. The Otsu lo/hi already track
            // the band (environment-adaptive); an extra noise-σ term destabilised detection and lost
            // copy, so it was removed.
            val tOn  = lo + (hi - lo) * 0.45f
            val tOff = lo + (hi - lo) * 0.20f      // deeper hysteresis → ride through shallow QSB dips
            if (gapped) {
                // fade-follow: only lower the threshold while gapped, never raise toward noise
                if (tOn < threshOn) { threshOn = tOn; threshOff = tOff }
            } else {
                threshOn = tOn; threshOff = tOff
            }
        }

        private fun analyzeElement(dur: Float) {
            // Noise filter at 0.6×dit once seeded — lower values let noise elements through and
            // degrade clean copy / dit-dah discrimination (a spurious short leading element turned
            // K=-.- into J=.---). Before seeding use only the absolute floor so a leading dit isn't
            // dropped (J=.--- else reads as O=---). A genuinely attack-clipped weak leading dit that
            // still slips below 0.6 is left to the dictionary/N-gram word corrector to recover.
            val effectiveMin = if (ditSeeded) maxOf(ditWinsMin, ditWins * 0.6f) else ditWinsMin
            if (dur < effectiveMin) return
            framesNoRealElement = 0
            // Seed the live unit from the first element so GAP segmentation works immediately.
            // dit/dah LABELS are decided later in flushChar from the whole character.
            if (!ditSeeded) {
                ditWins = dur.coerceIn(ditWinsMin, ditWinsMax)
                ditSeeded = true
            }
            elemDurs.add(dur)
            elemSnrs.add(if (elemSnrCnt > 0) elemSnrSum / elemSnrCnt else 0f)
        }

        // Track the dit unit: lock DOWN fast (catch-up / faster sender), leak UP slowly
        // (sender slowing down). Driven by dits and intra-character gaps, both ≈ 1 dit
        // regardless of how an element was classified, so it converges within one character.
        private fun observeUnit(unit: Float) {
            val u = unit.coerceIn(ditWinsMin, ditWinsMax)
            ditWins = if (u < ditWins) ditWins * 0.5f + u * 0.5f
                      else             ditWins * 0.9f + u * 0.1f
            ditWins = ditWins.coerceIn(ditWinsMin, ditWinsMax)
        }

        // Word-gap threshold in dit units, shifted by how likely a space is after the last two
        // decoded chars per the CW N-gram. Likely space (e.g. after "CQ") → break at a smaller gap;
        // unlikely (mid-callsign, around '/') → require a larger gap, so language, not just timing,
        // decides the phrase break even on strong signals. Clamped so clearly long/short gaps are
        // unaffected.
        private fun wordGapMul(): Float {
            val c = CwNgramModel.cost(ctxP2, ctxP1, ' ')   // -log P(space | ctx); lower = space likely
            // Floor at 6 dits: inter-char gaps (≈3 dits, wider for sloppy senders) must not split a
            // callsign; only a clear word gap (standard ≈7) breaks. Ceiling keeps run-on words apart.
            return (4.4f + c * 1.2f).coerceIn(6f, 9f)
        }

        private fun analyzeGap(dur: Float, ci: Int) {
            if (elemDurs.isEmpty() || charFlushed) return
            val g = dur
            when {
                g >= ditWins * wordGapMul() -> {
                    flushChar(ci); charFlushed = true
                    if (!wordEmitted) { onCharDecoded?.invoke(' ', ci, ""); ctxP2 = ctxP1; ctxP1 = ' '; wordEmitted = true }
                }
                g >= ditWins * 2.5f -> { flushChar(ci); charFlushed = true }
                g >= ditWinsMin -> {
                    gapDurs.add(g)   // intra-char space ≈ 1 dit → anchors speed
                    // The first intra-char gap of a fresh lock IS the ground-truth dit length, so
                    // pin ditWins to it immediately. This corrects a dah-seeded first element before
                    // its too-high effectiveMin can reject the real dits that follow (CQ → '?').
                    if (!unitConfirmed) { ditWins = g.coerceIn(ditWinsMin, ditWinsMax); unitConfirmed = true }
                    else observeUnit(g)
                }
            }
        }

        // Finish the current character: decide its dit unit and BUFFER its candidate characters
        // (chars within a small Morse-element distance). No emission yet — the whole word is decoded
        // together by beam search at the word boundary, so context can resolve ambiguous characters.
        // Decode this character IMMEDIATELY (low latency) by greedy LM-assisted selection in the
        // Morse domain: take the nearest candidates by element distance and let the CW trigram break
        // ties / resolve ambiguity from the context already emitted. (Word-level beam was dropped —
        // it delayed output by a whole word, and its only edge over greedy, revising an earlier char
        // from a later one, is marginal for a trigram.)
        private fun flushChar(ci: Int) {
            if (elemDurs.isEmpty()) return
            // Drop a spurious LEADING element born of noise (a click / QRN burst just before the real
            // character, e.g. turning C=-.-. into +=.-.-.). A noise blip sits just above the noise floor
            // in ON-SNR; a real key-down — even a short dit — is far above it. Note a genuine dit reads a
            // bit weaker than the dahs (its attack/decay ramp is a bigger share of a short element), so a
            // RELATIVE test alone would eat real leading dits (".----" → "----" → O). Require BOTH: the
            // first element is near the noise floor in ABSOLUTE SNR *and* far below the rest.
            // Measured reality (logged): a real DIT reads ~0.37× the char's dah ON-SNR, but leading
            // NOISE reads ~0.07× — a clear gap. So drop a leading element only when its ON-SNR is below
            // 0.2× the strongest real element (relative test; the old absolute "<4" never fired because
            // frameSnr is in the hundreds–thousands, so leading noise was never removed).
            while (elemDurs.size >= 2 && elemSnrs.size == elemDurs.size) {
                var maxRest = 0f
                for (i in 1 until elemSnrs.size) if (elemSnrs[i] > maxRest) maxRest = elemSnrs[i]
                if (maxRest > 0f && elemSnrs[0] < maxRest * 0.2f) {
                    elemDurs.removeAt(0); elemSnrs.removeAt(0)
                    if (gapDurs.isNotEmpty()) gapDurs.removeAt(0)   // drop the gap after the blip too
                } else break
            }
            var unit = ditWins
            if (gapDurs.isNotEmpty()) {
                var s = 0f; for (x in gapDurs) s += x
                unit = s / gapDurs.size
            }
            // Local dit-length reference from THIS character's own intra-element gaps (each ≈ 1 dit),
            // taken UNCAPPED. The running ditWins can drift small; capping the homogeneous threshold to
            // it flipped S=... (3 dits) into O=--- (3 dahs). The char's own gaps are the direct truth.
            val gapUnit = unit.coerceIn(ditWinsMin, ditWinsMax)
            var shortest = Float.MAX_VALUE; var longest = 0f
            for (d in elemDurs) { if (d < shortest) shortest = d; if (d > longest) longest = d }
            if (shortest < unit) unit = (unit + shortest) * 0.5f
            unit = unit.coerceAtMost(ditWins * 1.5f).coerceIn(ditWinsMin, ditWinsMax)

            // dit/dah boundary. When the character contains BOTH short and long elements there is a
            // clear valley; split at the geometric mean of shortest & longest — immune to unit drift
            // and to how many dits vs dahs there are (fixes clean mixed chars like GM=--.--, 5NN).
            // A homogeneous character (all dits: I/S/H, or all dahs: M/O/T) has no valley, so split
            // relative to the local gap unit. Measured reality (logged): the ON of a DIT ≈ 2×gap and a
            // DAH ≈ 3.3–5×gap — the hysteresis (rise@threshOn, fall@threshOff) inflates ON vs gap. So
            // gap×2 sits right ON the dit length and flip-flopped S(...)↔O(---); use ×2.8 (midway
            // between dit≈2× and the slowest dah≈3.3×) for a stable split.
            val thr = if (longest >= shortest * 2.2f) sqrt(shortest * longest) else gapUnit * 2.8f

            val sb = StringBuilder(elemDurs.size)
            for (d in elemDurs) sb.append(if (d < thr) '.' else '-')
            val code = sb.toString()
            // Run-together prosign (BK/SK sent as one blob) → emit its component letters adjacently.
            val prosign = PROSIGNS[code]
            if (prosign != null) {
                charSnr = if (charSnrCnt > 0) charSnrSum / charSnrCnt else 0f
                charLevel = if (charSnrCnt > 0 && threshOn > 0f && threshOn != Float.MAX_VALUE) (charESum / charSnrCnt) / threshOn else 0f
                charSnrSum = 0f; charSnrCnt = 0; charESum = 0f
                for ((pc, pcode) in prosign) {
                    onCharDecoded?.invoke(pc, ci, pcode); ctxP2 = ctxP1; ctxP1 = pc
                }
                ditWins = unit; ditSeeded = true
                elemDurs.clear(); gapDurs.clear(); elemSnrs.clear()
                return
            }
            // Longest codes (digits, '/', punctuation = 5-6 elements) garble most at weak signal and
            // otherwise fall off the candidate list → '?'. Give them a wider tolerance so they snap
            // to the nearest number/sign instead of dropping out.
            // A code that maps EXACTLY to a Morse character is trusted as-is: the N-gram must never
            // override a clean decode (e.g. "1"=".----" was being pulled to a context-likely "Q").
            // The LM-assisted candidate search runs ONLY for garbled codes with no exact table entry.
            val exact = MORSE_TABLE[code]
            val maxDist = if (code.length >= 5) 3 else 1
            var cands = if (exact != null) emptyList() else morseCandidates(code, maxDist)
            // A homogeneous garble (all dits or all dahs, e.g. "----" when J's leading dit is mis-sized)
            // must only snap to a homogeneous character of the SAME element — never to a mixed char.
            // This stops "----" → Q(--.-): it can become O/0 but not a dit-containing letter.
            if (exact == null && code.isNotEmpty() && (code.all { it == '.' } || code.all { it == '-' })) {
                val el = code[0]
                val homo = cands.filter { (ch, _) -> CHAR_TO_MORSE[ch]?.all { it == el } == true }
                if (homo.isNotEmpty()) cands = homo
            }
            val c = exact
                    ?: if (cands.isEmpty()) '?'
                       else cands.minByOrNull { (ch, dist) -> dist * 6f + 1.5f * CwNgramModel.cost(ctxP2, ctxP1, ch) }!!.first
            charSnr = if (charSnrCnt > 0) charSnrSum / charSnrCnt else 0f
            charLevel = if (charSnrCnt > 0 && threshOn > 0f && threshOn != Float.MAX_VALUE) (charESum / charSnrCnt) / threshOn else 0f
            charSnrSum = 0f; charSnrCnt = 0; charESum = 0f
            onCharDecoded?.invoke(c, ci, code)
            ctxP2 = ctxP1; ctxP1 = c

            ditWins = unit; ditSeeded = true
            elemDurs.clear(); gapDurs.clear(); elemSnrs.clear()
        }

        // For white noise periods: advance only keyOffWins without polluting hist/thresholds/ditWins
        fun processQuiet(ci: Int) {
            if (keyOn) { analyzeElement(keyOnWins.toFloat()); keyOnWins = 0; keyOn = false }
            keyOffWins++; framesNoRealElement++
            if (!charFlushed  && keyOffWins.toFloat() >= ditWins * 3f) { flushChar(ci); charFlushed = true }
            if (!wordEmitted && hadSignal && keyOffWins.toFloat() >= ditWins * wordGapMul()) {
                onCharDecoded?.invoke(' ', ci, ""); ctxP2 = ctxP1; ctxP1 = ' '; wordEmitted = true
            }
        }

        // Track frequency to nearest peak. Returns true if bin changed.
        fun trackPeak(spec: FloatArray): Boolean {
            var bestBin = freqBin
            var bestPow = spec[freqBin]
            val lo = (freqBin - DRIFT_RADIUS).coerceAtLeast(cwBinMin)
            val hi = (freqBin + DRIFT_RADIUS).coerceAtMost(cwBinMax)
            for (b in lo..hi) {
                if (spec[b] > bestPow) { bestPow = spec[b]; bestBin = b }
            }
            if (bestBin == freqBin) return false
            freqBin = bestBin
            return true
        }

        val shouldDeactivate: Boolean
            get() = framesNoRealElement > DEACT_THRESH
    }

    private val channels = arrayOfNulls<Channel>(N_CHAN)
    private var promoteCountdown = 0  // counter for promoting strongest channel to slot 0

    // ── Public API ────────────────────────────────────────────────

    fun reset() {
        ringBuf.fill(0f); ringHead = 0; hopCount = 0
        peakCandidates.clear()
        for (i in 0 until N_CHAN) {
            if (channels[i] != null) onChannelFreq?.invoke(i, 0)
            channels[i] = null
        }
    }

    /** Peak-hold linear SNR of a channel (0 if inactive). Used to gate weak-signal text correction. */
    fun channelSnr(ci: Int): Float = channels.getOrNull(ci)?.snrLin ?: 0f
    fun charSnr(ci: Int): Float = channels.getOrNull(ci)?.charSnr ?: 0f
    fun charLevel(ci: Int): Float = channels.getOrNull(ci)?.charLevel ?: 0f

    fun processSamples(samples: ShortArray) {
        for (s in samples) {
            ringBuf[ringHead] = s.toFloat() / 32768f
            ringHead = (ringHead + 1) % FFT_SIZE
            if (++hopCount >= HOP_SIZE) { hopCount = 0; processFrame() }
        }
    }

    // ── Frame processing ──────────────────────────────────────────

    private fun median3(a: Float, b: Float, c: Float): Float =
        maxOf(minOf(a, b), minOf(maxOf(a, b), c))

    // F: narrowband matched-filter energy. A Hann-windowed tone's main lobe is ≈2 bins wide,
    // so the centre bin plus half-weighted neighbours capture it while rejecting out-of-band
    // noise — about half the noise bandwidth of the old flat ±2-bin (≈78Hz) sum.
    private fun binEnergy(b: Int): Float {
        val lo = (b - 1).coerceAtLeast(cwBinMin)
        val hi = (b + 1).coerceAtMost(cwBinMax)
        return sqrt(specPow[b] + 0.5f * specPow[lo] + 0.5f * specPow[hi])
    }

    private fun processFrame() {
        for (i in 0 until FFT_SIZE) {
            fftRe[i] = ringBuf[(ringHead + i) % FFT_SIZE] * hannWin[i]
            fftIm[i] = 0f
        }
        fft(fftRe, fftIm)

        // Compute power spectrum
        for (bin in cwBinMin..cwBinMax) {
            specPow[bin] = fftRe[bin] * fftRe[bin] + fftIm[bin] * fftIm[bin]
        }

        // Noise floor estimation: treat bottom 30th percentile of CW band as noise
        val cwRange = cwBinMax - cwBinMin + 1
        for (i in 0 until cwRange) cwBandBuf[i] = specPow[cwBinMin + i]
        java.util.Arrays.sort(cwBandBuf, 0, cwRange)
        val noisePow = cwBandBuf[(cwRange * 0.20).toInt().coerceIn(0, cwRange - 1)]
        val peakMinPow = noisePow * PEAK_SNR_MIN

        // White noise detection: judge flatness by maximum value of sorted cwBandBuf
        val maxCwPow = cwBandBuf[cwRange - 1]
        val isNoise = maxCwPow <= 0f || noisePow / maxCwPow > NOISE_FLATNESS_THRESH

        // Update existing channels with energy at their respective frequency bins
        for (ci in 0 until N_CHAN) {
            val ch = channels[ci] ?: continue
            // QSB/weak-signal: decide "signal still present" by whether a COHERENT TONE remains on
            // this channel's bin (a local peak clearly above the noise floor) — not by raw energy vs
            // its own ON threshold. A fading signal stays peaky even as it weakens, so it rides the
            // fade; genuine broadband QRN (no local peak) still falls through to quiet. Energy-vs-
            // threshold gating used to drop faded channels into false gaps and shred the copy.
            val b = ch.freqBin
            val tonePresent = specPow[b] > noisePow * 2f &&
                specPow[b] >= specPow[(b - 1).coerceAtLeast(cwBinMin)] &&
                specPow[b] >= specPow[(b + 1).coerceAtMost(cwBinMax)]
            // Peak-hold SNR (slow decay) — a running estimate of how strong this channel is,
            // surfaced so the text layer can apply dictionary correction only to weak copy.
            val noiseRef = sqrt(noisePow * 2f).coerceAtLeast(1e-6f)
            ch.frameSnr = binEnergy(b) / noiseRef
            ch.snrLin = maxOf(ch.snrLin * 0.95f, ch.frameSnr)
            if (isNoise && !tonePresent) {
                // During noise period, protect hist/thresholds/ditWins and advance only keyOffWins
                ch.processQuiet(ci)
            } else {
                if (!isNoise && ch.trackPeak(specPow)) onChannelFreq?.invoke(ci, ch.freqHz)
                ch.process(binEnergy(ch.freqBin), ci)
            }
            if (ch.shouldDeactivate) {
                channels[ci] = null
                onChannelFreq?.invoke(ci, 0)
            }
        }

        // Merge channels that converged to the same frequency after trackPeak (remove weaker one)
        for (i in 0 until N_CHAN - 1) {
            val ci = channels[i] ?: continue
            for (j in i + 1 until N_CHAN) {
                val cj = channels[j] ?: continue
                if (abs(ci.freqBin - cj.freqBin) <= FREQ_TOL) {
                    if (ci.smoothE >= cj.smoothE) {
                        channels[j] = null; onChannelFreq?.invoke(j, 0)
                    } else {
                        channels[i] = null; onChannelFreq?.invoke(i, 0); break
                    }
                }
            }
        }

        // Collect local maxima; find bins exceeding SNR threshold not covered by existing channels
        val strongBins = mutableSetOf<Int>()
        for (bin in (cwBinMin + 1) until cwBinMax) {
            if (specPow[bin] > specPow[bin-1] && specPow[bin] > specPow[bin+1]
                && specPow[bin] >= peakMinPow) {
                val covered = channels.any { it != null && abs(it.freqBin - bin) <= FREQ_TOL }
                if (!covered) strongBins.add(bin)
            }
        }

        // Update candidate map: increment bins still strong this frame, remove gone ones
        val candIter = peakCandidates.iterator()
        while (candIter.hasNext()) { if (candIter.next().key !in strongBins) candIter.remove() }
        for (bin in strongBins) peakCandidates[bin] = (peakCandidates[bin] ?: 0) + 1

        // Promote strongest channel to slot 0 (≈every 2 seconds, if >50% energy difference)
        if (++promoteCountdown >= maxOf(10, 2000 / msPerHop)) {
            promoteCountdown = 0
            var bestSlot = 0
            var bestE = channels[0]?.smoothE ?: -1f
            for (i in 1 until N_CHAN) {
                val e = channels[i]?.smoothE ?: -1f
                if (e > bestE * 1.5f) { bestE = e; bestSlot = i }
            }
            if (bestSlot != 0) {
                val tmp = channels[0]; channels[0] = channels[bestSlot]; channels[bestSlot] = tmp
                onChannelFreq?.invoke(0, channels[0]?.freqHz ?: 0)
                onChannelFreq?.invoke(bestSlot, channels[bestSlot]?.freqHz ?: 0)
                onChannelSwap?.invoke(0, bestSlot)
            }
        }

        // Promote candidates with signal continuing for CAND_PROMOTE+ frames at the same bin to channels
        val noiseE = sqrt(noisePow * 2f)   // ~2-bin equivalent, matched to binEnergy() weighting
        for (bin in strongBins.sortedByDescending { specPow[it] }) {
            if ((peakCandidates[bin] ?: 0) < CAND_PROMOTE) continue
            val slot = channels.indexOfFirst { it == null }
            if (slot < 0) break
            val e = binEnergy(bin)
            val ch = Channel(bin, e, noiseE)
            channels[slot] = ch
            onChannelFreq?.invoke(slot, ch.freqHz)
            peakCandidates.remove(bin)
            ch.process(e, slot)
        }
    }

    // ── Cooley-Tukey FFT ─────────────────────────────────────────
    private fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n ushr 1
            while (j and bit != 0) { j = j xor bit; bit = bit ushr 1 }
            j = j xor bit
            if (i < j) {
                re[i] = re[j].also { re[j] = re[i] }
                im[i] = im[j].also { im[j] = im[i] }
            }
        }
        var len = 2
        while (len <= n) {
            val half = len ushr 1
            val ang  = -PI / half
            val wRe  = cos(ang).toFloat()
            val wIm  = sin(ang).toFloat()
            var i = 0
            while (i < n) {
                var cRe = 1f; var cIm = 0f
                for (k in 0 until half) {
                    val uRe = re[i+k];            val uIm = im[i+k]
                    val vRe = re[i+k+half]*cRe - im[i+k+half]*cIm
                    val vIm = re[i+k+half]*cIm + im[i+k+half]*cRe
                    re[i+k]      = uRe+vRe;       im[i+k]      = uIm+vIm
                    re[i+k+half] = uRe-vRe;       im[i+k+half] = uIm-vIm
                    val nc = cRe*wRe - cIm*wIm;   cIm = cRe*wIm + cIm*wRe;   cRe = nc
                }
                i += len
            }
            len = len shl 1
        }
    }
}
