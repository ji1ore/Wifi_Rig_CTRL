package com.ji1ore.wifi_rig_ctrl.data

import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Weak-signal, word-level correction for decoded CW — matched by MORSE SIMILARITY, not letters.
 *
 * CW copy errors happen at the element level (a dropped/added dit, a dah read as a dit, a character
 * boundary landing one element early/late), so similarity is measured on the raw dit/dah stream.
 * The received word's elements are concatenated into one stream and compared, by element-level edit
 * distance, against each dictionary token's own concatenated Morse. Concatenating ignores character
 * boundaries, so a word split or merged by one element (your "2-window / 3-window" case) still lines
 * up with the right token.
 *
 * Runs only on weak copy (the caller gates on SNR) and never touches callsigns, so clean strong
 * decodes and rare/arbitrary strings are left alone.
 */
class CwWordCorrector {

    // Common CW tokens. Deliberately excludes arbitrary callsigns and name/QTH content.
    private val names: List<String> = listOf(
        // prosigns / flow
        "CQ", "DE", "K", "KN", "AR", "SK", "BK", "AS", "BT", "CL",
        // courtesy / chat
        "TU", "TNX", "TKS", "FB", "HR", "HW", "ES", "GUD", "GD", "HI",
        "PSE", "AGN", "CPY", "CUL", "OM", "YL", "XYL", "DR", "GL", "VY",
        "GM", "GA", "GE", "GN", "73", "72", "88",
        // common 3-letter abbreviations
        "ABT", "ANT", "BUG", "CFM", "CPI", "CUZ", "DWN", "ERE", "FER",
        "HPE", "HRD", "LID", "LTR", "MNI", "MSG", "NIL", "OBS",
        "OPR", "PWR", "RCD", "RIG", "RPT", "SED", "SRI", "STN", "SUM",
        "TMW", "TXT", "UFB", "URS", "WDS", "WID", "WKD", "WKG", "WRK", "WUD",
        "NR", "NW", "UR", "ES", "OP", "WX", "DX",
        // report / info
        "RST", "QTH", "NAME", "WPM", "RPRT", "599", "579", "589", "559",
        "569", "578", "5NN", "DIT", "DAH",
        // Q-codes (3-letter)
        "QRA", "QRG", "QRL", "QRM", "QRN", "QRO", "QRP", "QRQ", "QRS", "QRT",
        "QRU", "QRV", "QRX", "QRZ", "QSB", "QSK", "QSL", "QSO", "QSP", "QSX",
        "QSY", "QST", "QTC", "QTR",
        // question forms (the trailing "?" = ..--.. disambiguates from the plain Q-code)
        "QRZ?", "QRL?", "QSL?", "QRV?", "QTH?", "QRU?",
        "TEST"
    ).distinct()

    // token → its concatenated Morse element stream (e.g. "CQ" → "-.-." + "--.-")
    private val dict: List<Pair<String, String>> = names.mapNotNull { n ->
        val m = n.map { CwDecoder.CHAR_TO_MORSE[it] ?: return@mapNotNull null }.joinToString("")
        n to m
    }

    /**
     * @param codes the per-character Morse strings of the received word, in order (each is dit/dah;
     *              unknown chars still carry the elements that were attempted).
     * @param letters the decoded letters of that word (used only for the callsign/already-valid guard).
     * @return a corrected token, or null to keep the original.
     */
    fun correct(codes: List<String>, letters: String): String? {
        val received = codes.joinToString("")
        if (received.length < 2) return null              // too little to match on
        val w = letters.uppercase()
        if (w in names) return null                       // already a valid token
        if (isCallsignLike(w)) return null                // never touch callsigns

        // Accept only a close AND unambiguous Morse match: budget ≈ 38% of the element count.
        val limit = max(1, (received.length * 0.38f).roundToInt())
        var best: String? = null
        var bestD = Int.MAX_VALUE
        var secondD = Int.MAX_VALUE
        for ((name, morse) in dict) {
            // prune: edit distance ≥ |length difference|, so anything beyond the budget can't win
            if (kotlin.math.abs(morse.length - received.length) > limit) continue
            val d = elemEdit(received, morse)
            when {
                d < bestD   -> { secondD = bestD; bestD = d; best = name }
                d < secondD -> secondD = d
            }
        }
        return if (best != null && bestD <= limit && bestD < secondD) best else null
    }

    // ── QSO-template type inference (Option A): predict the class of the NEXT token from the last ──
    // Returns the small set of tokens expected after [prev], or null when the next token is free
    // (e.g. a callsign) and must not be corrected.
    fun expectedAfter(prev: String): List<String>? = when (prev.uppercase()) {
        ""    -> listOf("CQ", "DE", "UR", "QRZ", "TU", "73", "RST", "DX", "TEST", "QSO",
                        "GM", "GA", "GE", "GN")                                           // start of over (+ greetings)
        "CQ"  -> listOf("DE", "TEST", "CQ", "QRZ")
        "UR"  -> listOf("RST")
        "RST" -> listOf("599", "579", "589", "559", "569", "578", "5NN")
        "73", "72", "88" -> listOf("73", "72", "TU", "SK", "GL")
        "GM", "GA", "GE", "GN" -> listOf("DR", "OM", "UR", "ES")
        else  -> null
    }

    private fun tokenMorse(name: String): String? {
        var m = ""
        for (ch in name) { m += (CwDecoder.CHAR_TO_MORSE[ch] ?: return null) }
        return m
    }

    /** Correct a word toward the nearest token of an EXPECTED class only (tiny candidate set), by
     *  Morse similarity. Scoping to the template slot keeps false corrections low. */
    fun correctInSet(codes: List<String>, letters: String, candidates: List<String>): String? {
        val received = codes.joinToString("")
        if (received.length < 2) return null
        val w = letters.uppercase()
        if (w in candidates) return null
        if (isCallsignLike(w)) return null
        val limit = max(1, (received.length * 0.4f).roundToInt())
        var best: String? = null
        var bestD = Int.MAX_VALUE
        var secondD = Int.MAX_VALUE
        for (name in candidates) {
            val morse = tokenMorse(name) ?: continue
            if (kotlin.math.abs(morse.length - received.length) > limit) continue
            val d = elemEdit(received, morse)
            when {
                d < bestD   -> { secondD = bestD; bestD = d; best = name }
                d < secondD -> secondD = d
            }
        }
        return if (best != null && bestD <= limit && bestD < secondD) best else null
    }

    // A callsign has both letters and digits with real structure (W1AW, JA1ABC, 2E0XYZ). Require
    // length ≥ 4 so RST shorthands like "5NN" stay eligible; pure letters/digits are never callsigns.
    private fun isCallsignLike(w: String): Boolean {
        if (w.length < 4) return false
        val hasLetter = w.any { it in 'A'..'Z' }
        val hasDigit  = w.any { it in '0'..'9' }
        return hasLetter && hasDigit
    }

    // Levenshtein over the dit/dah element sequences.
    private fun elemEdit(a: String, b: String): Int {
        val prev = IntArray(b.length + 1) { it }
        val cur  = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
            }
            System.arraycopy(cur, 0, prev, 0, cur.size)
        }
        return prev[b.length]
    }
}
