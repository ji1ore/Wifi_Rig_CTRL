package com.ji1ore.wifi_rig_ctrl.data

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit

class AudioStreamService {

    private var streamJob: Job? = null
    private var audioTrack: AudioTrack? = null
    private var activeCall: Call? = null
    @Volatile private var currentVolume: Float = 0.5f
    @Volatile private var stopping = false
    @Volatile private var lastDataMs: Long = 0L

    // For CW decode: notify PCM16 samples in real time (called from IO thread)
    @Volatile var audioSampleListener: ((ShortArray) -> Unit)? = null

    // SPK 受信音のソフト増幅(AudioTrack.setVolume は最大1.0で増幅できないため)。約2倍。
    // クリップ防止で ±32767 にクランプ。スペクトラム等のリスナーには増幅前データを渡す。
    private val spkGain = 2.0f
    private fun applyGain(buf: ByteArray, n: Int) {
        if (spkGain == 1.0f) return
        var i = 0
        while (i + 1 < n) {
            val s = (buf[i].toInt() and 0xFF) or (buf[i + 1].toInt() shl 8)  // 16bit LE signed
            var v = (s * spkGain).toInt()
            if (v > 32767) v = 32767 else if (v < -32768) v = -32768
            buf[i] = v.toByte()
            buf[i + 1] = (v shr 8).toByte()
            i += 2
        }
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.SECONDS)
        .build()

    // onError: not on UI thread, so caller should post to main thread
    fun start(url: String, vol: Float, apiKey: String = "", onError: ((String) -> Unit)? = null) {
        stop()
        stopping = false
        currentVolume = vol
        val sampleRate = extractSampleRate(url)
        _currentSampleRate = sampleRate

        streamJob = CoroutineScope(Dispatchers.IO).launch {
            var lastError: String? = null
            // 連続した接続失敗は MAX_RETRY で諦めるが、一度でも正常再生できたら attempt をリセットする
            // (下の streamed ブロック)。これにより「数分ごとに一瞬落ちる」ような定期ドロップでも、
            // 累積で MAX_RETRY に達して 6秒ウォッチドッグ待ちに陥ることなく、常に即(300ms)再接続する。
            var attempt = 0
            while (isActive && !stopping) {
                attempt++
                if (attempt > MAX_RETRY) break
                if (attempt > 1) {
                    Log.d("AudioStream", "retry $attempt/$MAX_RETRY after ${RETRY_DELAY_MS}ms")
                    delay(RETRY_DELAY_MS)
                    if (!isActive || stopping) break
                }
                val t0 = System.currentTimeMillis()
                var streamed = false
                try {
                    val reqBuilder = Request.Builder().url(url)
                    if (apiKey.isNotEmpty()) reqBuilder.addHeader("X-API-Key", apiKey)
                    val call = client.newCall(reqBuilder.build())
                    activeCall = call
                    call.execute().use { response ->
                        if (!response.isSuccessful) {
                            lastError = "Audio stream connect failed (${response.code})"
                            Log.e("AudioStream", "$lastError attempt=$attempt ${System.currentTimeMillis()-t0}ms")
                            return@use  // retry
                        }
                        Log.d("AudioStream", "connected ${System.currentTimeMillis()-t0}ms attempt=$attempt")

                        val minBuf = AudioTrack.getMinBufferSize(
                            sampleRate,
                            AudioFormat.CHANNEL_OUT_MONO,
                            AudioFormat.ENCODING_PCM_16BIT
                        )
                        // 低遅延優先: 小さめバッファ(~200ms相当)。リアルタイム再生・打鍵後ギャップ無し。
                        // クロックのズレによる「数分ごとの途切れ」はPi側(送出レート/リサンプル)で根本対策する。
                        val bufSize = maxOf(minBuf, 1024) * 2

                        val track = AudioTrack.Builder()
                            .setAudioAttributes(
                                AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                    .build()
                            )
                            .setAudioFormat(
                                AudioFormat.Builder()
                                    .setSampleRate(sampleRate)
                                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                    .build()
                            )
                            .setBufferSizeInBytes(bufSize)
                            .setTransferMode(AudioTrack.MODE_STREAM)
                            .build()

                        track.setVolume(currentVolume)
                        audioTrack = track

                        val body = response.body ?: run {
                            lastError = "Audio stream: no response body"
                            track.release()
                            audioTrack = null
                            return@use
                        }
                        val stream = body.byteStream()
                        val readBuf = ByteArray(2048)  // smaller chunks = lower latency

                        var prebuffered = 0
                        val prebufferTarget = minOf(bufSize / 2, 512)  // 低遅延: 最小限だけためて即再生
                        while (prebuffered < prebufferTarget && isActive) {
                            val n = stream.read(readBuf, 0, minOf(readBuf.size, prebufferTarget - prebuffered))
                            if (n <= 0) break
                            if (prebuffered == 0) Log.d("AudioStream", "first data ${System.currentTimeMillis()-t0}ms")
                            notifySamples(readBuf, n)   // 増幅前データをリスナーへ
                            applyGain(readBuf, n)       // 再生用に増幅
                            track.write(readBuf, 0, n)
                            prebuffered += n
                        }

                        if (prebuffered == 0) {
                            lastError = "No audio data (attempt=$attempt, ${System.currentTimeMillis()-t0}ms)"
                            Log.e("AudioStream", lastError!!)
                            track.release()
                            audioTrack = null
                            return@use  // retry
                        }

                        Log.d("AudioStream", "play start ${System.currentTimeMillis()-t0}ms prebuf=${prebuffered}B")
                        track.play()
                        streamed = true
                        lastError = null

                        // Bounded-latency playback. The Pi usually streams a hair faster than the phone
                        // plays (clock drift); with a single blocking read→write loop the surplus backs up
                        // in the TCP buffer and latency grows unbounded (seconds behind after ~10 min).
                        // Fix: a READER thread drains the socket continuously (TCP never backs up) into a
                        // small drop-oldest queue; the playback side consumes at AudioTrack's pace. When the
                        // reader outruns playback the queue drops its OLDEST chunk, so latency is capped near
                        // real-time forever — no periodic reconnect needed. Chunks are kept 16-bit aligned
                        // (odd trailing byte carried over) so dropping whole chunks never desyncs samples.
                        val bytesPerSec = sampleRate * 2
                        val maxBacklogBytes = bytesPerSec / 3            // cap ≈330ms of queued audio
                        val queue = ArrayBlockingQueue<ByteArray>(64)
                        val queuedBytes = java.util.concurrent.atomic.AtomicInteger(0)
                        val reader = Thread {
                            val rb = ByteArray(2048)
                            var carry = -1
                            try {
                                while (isActive && !stopping) {
                                    var off = 0
                                    if (carry >= 0) { rb[0] = carry.toByte(); off = 1; carry = -1 }
                                    val n = stream.read(rb, off, rb.size - off)
                                    if (n <= 0) break
                                    var total = off + n
                                    if (total % 2 == 1) { carry = rb[total - 1].toInt() and 0xFF; total -= 1 }
                                    if (total == 0) continue
                                    lastDataMs = System.currentTimeMillis()
                                    val chunk = rb.copyOf(total)
                                    // drop oldest until this chunk fits under the latency cap
                                    while (queuedBytes.get() + total > maxBacklogBytes) {
                                        val old = queue.poll() ?: break
                                        queuedBytes.addAndGet(-old.size)
                                    }
                                    if (queue.offer(chunk)) queuedBytes.addAndGet(total)
                                }
                            } catch (_: Exception) {}
                            queue.offer(ByteArray(0))   // sentinel → unblock consumer on EOF
                        }
                        reader.isDaemon = true
                        reader.start()
                        try {
                            while (isActive) {
                                val chunk = queue.poll(2, TimeUnit.SECONDS) ?: break
                                if (chunk.isEmpty()) break   // EOF sentinel
                                queuedBytes.addAndGet(-chunk.size)
                                notifySamples(chunk, chunk.size)   // 増幅前データをリスナーへ
                                applyGain(chunk, chunk.size)       // 再生用に増幅
                                track.write(chunk, 0, chunk.size)
                            }
                        } finally {
                            reader.interrupt()
                        }

                        track.stop()
                        track.release()
                        audioTrack = null
                    }
                } catch (e: Exception) {
                    if (!stopping) {
                        lastError = "Audio connect error: ${e.message}"
                        Log.e("AudioStream", "attempt $attempt: ${e.message}")
                    } else {
                        break
                    }
                }
                if (stopping) break
                if (streamed) {
                    // Stream dropped unexpectedly — wait then reconnect.
                    // 一度正常に再生できたので再試行回数をリセット(定期ドロップでも常に即再接続)。
                    lastError = "Audio stream lost"
                    Log.w("AudioStream", "stream dropped attempt=$attempt, reconnecting")
                    attempt = 0
                    delay(RECONNECT_DELAY_MS)
                    if (!isActive || stopping) break
                }
            }
            if (!stopping && lastError != null) {
                onError?.invoke(lastError!!)
            }
        }
    }

    private fun notifySamples(buf: ByteArray, n: Int) {
        val listener = audioSampleListener ?: return
        if (n < 2) return
        val count = n / 2
        val shorts = ShortArray(count) { i ->
            val lo = buf[i * 2].toInt() and 0xFF
            val hi = buf[i * 2 + 1].toInt() and 0xFF
            ((hi shl 8) or lo).toShort()
        }
        listener(shorts)
    }

    fun stop() {
        stopping = true
        streamJob?.cancel()
        streamJob = null
        activeCall?.cancel()
        activeCall = null
        val track = audioTrack
        audioTrack = null
        lastDataMs = 0L
        try { track?.stop() } catch (_: Exception) {}
        try { track?.release() } catch (_: Exception) {}
    }

    fun setVolume(vol: Float) {
        currentVolume = vol
        audioTrack?.setVolume(vol)
    }

    val isPlaying: Boolean get() = audioTrack?.playState == AudioTrack.PLAYSTATE_PLAYING
    val isStreamActive: Boolean get() = streamJob?.isActive == true
    // True only when AudioTrack is playing AND data was received within the last 5 seconds.
    // Detects "zombie" state: AudioTrack.PLAYSTATE_PLAYING but Pi stopped sending data.
    // 無データ3秒で「流れていない」と判定(SPKウォッチドッグの検知待ちを短縮し途切れの空白を縮める)。
    val isDataFlowing: Boolean get() = isPlaying && (System.currentTimeMillis() - lastDataMs < 3000L)

    /** 再生中なのにデータが ms ミリ秒以上届いていない(真のゾンビ判定用)。一瞬のWiFiストールでは
     *  張り直さず、長時間(例:15秒)来ない時だけウォッチドッグが復帰させるために使う。 */
    fun noDataFor(ms: Long): Boolean = isPlaying && (System.currentTimeMillis() - lastDataMs > ms)

    /** Sample rate of the currently running stream (0 if not running). */
    val currentSampleRate: Int get() = if (isStreamActive) _currentSampleRate else 0
    @Volatile private var _currentSampleRate: Int = 0

    private fun extractSampleRate(url: String): Int =
        Regex("rate=(\\d+)").find(url)?.groupValues?.get(1)?.toIntOrNull() ?: 8000

    companion object {
        private const val MAX_RETRY = 10
        private const val RETRY_DELAY_MS = 500L
        private const val RECONNECT_DELAY_MS = 300L
    }
}
