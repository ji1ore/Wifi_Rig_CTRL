package com.ji1ore.wifi_rig_ctrl.data

import kotlin.math.ln

/**
 * CW-domain character TRIGRAM language model for beam-search decoding.
 *
 * `cost(p2, p1, c)` returns -log P(c | p2, p1) (lower = more likely), interpolated tri/bi/unigram
 * with add-k smoothing. It is combined with the Morse-element acoustic cost during beam search so
 * context resolves characters the timing alone can't (e.g. dense Q-codes, near-miss codes).
 *
 * No training corpus exists, so one is SYNTHESISED at startup from the building blocks of on-air CW
 * — ITU-style callsigns, Q-codes, RST reports, abbreviations, numbers and typical QSO flow. Because
 * the corpus is genuine CW content (including callsign letter/digit structure) the model tolerates
 * callsigns, unlike a generic English LM. Generation is deterministic (seeded LCG).
 */
object CwNgramModel {

    private val tri = HashMap<Int, Int>()    // key3(p2,p1,c)
    private val bi  = HashMap<Int, Int>()    // key2(p1,c)
    private val uni = HashMap<Char, Int>()
    private val ctx2 = HashMap<Int, Int>()   // count of (p2,p1)
    private val ctx1 = HashMap<Char, Int>()  // count of p1
    private var totalUni = 0
    private var vocab = 1

    private const val K = 0.1f
    private const val L_TRI = 0.6f
    private const val L_BI = 0.3f
    private const val L_UNI = 0.1f

    private fun key3(p2: Char, p1: Char, c: Char): Int =
        (p2.code and 127) * 16384 + (p1.code and 127) * 128 + (c.code and 127)
    private fun key2(p1: Char, c: Char): Int = (p1.code and 127) * 128 + (c.code and 127)

    /** Touch the object so its one-time corpus build runs here (call off the audio thread). */
    fun warmUp() { /* referencing CwNgramModel has already triggered its init */ }

    /** -log P(c | p2, p1) with tri/bi/unigram interpolation. */
    fun cost(p2: Char, p1: Char, c: Char): Float {
        val pUni = ((uni[c] ?: 0) + K) / (totalUni + K * vocab)
        val pBi = ((bi[key2(p1, c)] ?: 0) + K) / ((ctx1[p1] ?: 0) + K * vocab)
        val pTri = ((tri[key3(p2, p1, c)] ?: 0) + K) / ((ctx2[(p2.code and 127) * 128 + (p1.code and 127)] ?: 0) + K * vocab)
        val p = L_TRI * pTri + L_BI * pBi + L_UNI * pUni
        return -ln(p.coerceAtLeast(1e-9f))
    }

    private fun train(corpus: String) {
        val seen = HashSet<Char>()
        var p2 = ' '; var p1 = ' '
        for (ch in corpus) {
            uni[ch] = (uni[ch] ?: 0) + 1; totalUni++; seen.add(ch)
            bi[key2(p1, ch)] = (bi[key2(p1, ch)] ?: 0) + 1
            ctx1[p1] = (ctx1[p1] ?: 0) + 1
            tri[key3(p2, p1, ch)] = (tri[key3(p2, p1, ch)] ?: 0) + 1
            val c2 = (p2.code and 127) * 128 + (p1.code and 127)
            ctx2[c2] = (ctx2[c2] ?: 0) + 1
            p2 = p1; p1 = ch
        }
        vocab = maxOf(1, seen.size)
    }

    // ── deterministic synthetic CW/QSO corpus ─────────────────────
    private var rng = 0x5DEECE66L
    private fun rnd(n: Int): Int {
        rng = (rng * 0x5DEECE66DL + 0xB) and 0xFFFFFFFFFFFFL
        return ((rng ushr 16).toInt() and 0x7FFFFFFF) % n
    }
    private fun pick(a: Array<String>): String = a[rnd(a.size)]

    private val prefixes = arrayOf(
        "JA","JE","JF","JG","JH","JI","JJ","JK","JL","JR","JS","7K","7L","7M","7N","8J",
        "W","K","N","AA","AB","AC","AD","AE","AF","AG","AK","WA","WB","WD","KA","KB","KC","KD","KE","KK","NN",
        "G","M","2E","GW","GM","GI","GD",
        "DL","DK","DJ","DF","DD","DH","DO","DB",
        "F","I","IK","IZ","IW","EA","EB","EC","CT","PA","PE","PD","ON","OT","OZ","OU","SM","SA","LA","LB","OH","OG",
        "VK","ZL","VE","VA","VO","UA","UB","UR","US","UT","UX","R","RA","RK","RN","RV","RW","RZ",
        "BY","BG","BA","BD","HL","DS","6K","VU","YB","YC","YD","9M","9V","HS","E2","DU","PY","PP","PU","LU","LW",
        "CE","CA","HK","HC","OA","CP","CX","ZP","ZS","ZR","5Z","6W","9A","S5","OK","OL","OM","HA","HG",
        "SP","SQ","SN","YO","YP","LZ","TA","4X","4Z","JY","HB","OE","EI","GU","GJ",
        "VR","BV","7J","8N"
    )
    private val qcodes = arrayOf(
        "QRL","QRM","QRN","QRO","QRP","QRQ","QRS","QRT","QRU","QRV","QRX","QRZ",
        "QSB","QSK","QSL","QSO","QSP","QSX","QSY","QST","QTC","QTH","QTR","QRG","QRA"
    )
    private val abbrevs = arrayOf(
        "CQ","DE","TU","TNX","TKS","FB","HR","HW","ES","GUD","PSE","AGN","CPY","UR","RST",
        "NAME","RIG","ANT","PWR","WX","OM","YL","XYL","DR","GM","GA","GE","GN","GL","VY",
        "K","KN","AR","SK","BK","AS","DX","TEST","NR","NW","WID","WKD","WRK","RPT","SRI","MNI"
    )
    private val rsts = arrayOf("599","579","589","559","569","578","5NN")
    private val names = arrayOf("TOM","BOB","JIM","KEN","JOE","DAVE","MIKE","BILL","JON","AL","RON","DAN","SAM","MAX","TED")
    private val qths = arrayOf("TOKYO","OSAKA","LONDON","PARIS","ROMA","BERLIN","MOSCOW","SEOUL","SYDNEY","DELHI","CAIRO")

    private fun callsign(): String {
        val p = pick(prefixes)
        val hasDigit = p.any { it in '0'..'9' }
        val sb = StringBuilder(p)
        if (!hasDigit) sb.append('0' + rnd(10))
        repeat(1 + rnd(3)) { sb.append('A' + rnd(26)) }
        // ~1/7 portable: /P /M /MM /QRP /<digit> — keeps '/' INSIDE the token so the LM learns it
        // belongs to a callsign and won't break the phrase at the slash.
        if (rnd(7) == 0) {
            sb.append('/')
            when (rnd(5)) {
                0 -> sb.append('P'); 1 -> sb.append('M'); 2 -> sb.append("MM")
                3 -> sb.append("QRP"); else -> sb.append('0' + rnd(10))
            }
        }
        return sb.toString()
    }
    private fun number(): String {
        val sb = StringBuilder()
        repeat(1 + rnd(4)) { sb.append('0' + rnd(10)) }
        return sb.toString()
    }

    private fun buildCorpus(): String {
        val sb = StringBuilder(140_000)
        repeat(3000) {
            when (rnd(6)) {
                0 -> { val c = callsign(); sb.append("CQ CQ CQ DE ").append(c).append(' ').append(c).append(" K ") }
                1 -> {
                    val me = callsign(); val dx = callsign()
                    sb.append(dx).append(" DE ").append(me)
                        .append(" UR RST ").append(pick(rsts)).append(' ').append(pick(rsts))
                        .append(" NAME ").append(pick(names))
                        .append(" QTH ").append(pick(qths)).append(" HW? ")
                        .append(dx).append(" DE ").append(me).append(" KN ")
                }
                2 -> {
                    val me = callsign(); val dx = callsign()
                    sb.append(dx).append(" DE ").append(me)
                        .append(" R FB ").append(pick(names)).append(" UR RST ").append(pick(rsts))
                        .append(" ES ").append(pick(qcodes)).append(' ').append(number())
                        .append(" TU 73 73 ").append(dx).append(" DE ").append(me).append(" SK ")
                }
                3 -> sb.append(callsign()).append(" 5NN ").append(number()).append(" TU ")
                4 -> repeat(4 + rnd(4)) { sb.append(if (rnd(2) == 0) pick(qcodes) else pick(abbrevs)).append(' ') }
                else -> repeat(3 + rnd(5)) {
                    sb.append(when (rnd(4)) { 0 -> callsign(); 1 -> pick(abbrevs); 2 -> pick(rsts); else -> number() }).append(' ')
                }
            }
        }
        return sb.toString()
    }

    // Train LAST: an object's init runs in source order, so this must follow every data property
    // (prefixes/qcodes/…) above — otherwise buildCorpus() reads them while they are still null.
    init { train(buildCorpus()) }
}
