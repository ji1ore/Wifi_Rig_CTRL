package com.ji1ore.wifi_rig_ctrl.data

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Log-mel spectrogram for the neural (CRNN/TCN + CTC) CW decoder — the ON-DEVICE
 * CONTRACT that must match the Python training features (CW_CRNN_CTC/features.py)
 * bit-for-bit, or the TFLite model sees inputs it was never trained on.
 *
 * Validated against CW_CRNN_CTC/feature_ref.json in CwNeuralFeaturesTest.
 * Audio is mono float32 at [SAMPLE_RATE]; output is (frames, N_MELS), per-utterance
 * mean/var normalised exactly as in training.
 */
object CwNeuralFeatures {
    const val SAMPLE_RATE = 8000
    const val N_FFT = 256
    const val HOP = 64
    const val N_MELS = 64
    const val FMIN = 200.0
    const val FMAX = 3800.0
    private const val EPS = 1e-6

    // np.hanning(N_FFT): symmetric Hann, 0.5 - 0.5*cos(2πn/(N-1))
    private val window = DoubleArray(N_FFT) { 0.5 - 0.5 * cos(2.0 * PI * it / (N_FFT - 1)) }

    // triangular mel filterbank (N_MELS, N_FFT/2+1), identical construction to features.py
    private val melFb: Array<DoubleArray> = buildMelFb()

    private fun hzToMel(f: Double) = 2595.0 * log10(1.0 + f / 700.0)
    private fun melToHz(m: Double) = 700.0 * (Math.pow(10.0, m / 2595.0) - 1.0)

    private fun buildMelFb(): Array<DoubleArray> {
        val nBins = N_FFT / 2 + 1
        val mLo = hzToMel(FMIN); val mHi = hzToMel(FMAX)
        val mels = DoubleArray(N_MELS + 2) { mLo + (mHi - mLo) * it / (N_MELS + 1) }
        val hz = DoubleArray(N_MELS + 2) { melToHz(mels[it]) }
        val bins = IntArray(N_MELS + 2) { Math.floor((N_FFT + 1) * hz[it] / SAMPLE_RATE).toInt() }
        val fb = Array(N_MELS) { DoubleArray(nBins) }
        for (m in 1..N_MELS) {
            var l = bins[m - 1]; var c = bins[m]; var r = bins[m + 1]
            if (c == l) c = l + 1
            if (r == c) r = c + 1
            var k = l
            while (k < c) { if (k in 0 until nBins) fb[m - 1][k] = (k - l).toDouble() / maxOf(1, c - l); k++ }
            k = c
            while (k < r) { if (k in 0 until nBins) fb[m - 1][k] = (r - k).toDouble() / maxOf(1, r - c); k++ }
        }
        return fb
    }

    /** audio float [-1,1] -> (frames, N_MELS) log-mel, mean/var normalised. */
    fun logMel(audio: FloatArray): Array<FloatArray> {
        val a = if (audio.size < N_FFT) audio.copyOf(N_FFT) else audio
        val nFrames = 1 + (a.size - N_FFT) / HOP
        val nBins = N_FFT / 2 + 1
        val out = Array(nFrames) { FloatArray(N_MELS) }
        val re = DoubleArray(N_FFT); val im = DoubleArray(N_FFT)
        val power = DoubleArray(nBins)
        var sum = 0.0; var sumSq = 0.0; val total = nFrames * N_MELS
        for (t in 0 until nFrames) {
            val off = t * HOP
            for (i in 0 until N_FFT) { re[i] = a[off + i] * window[i]; im[i] = 0.0 }
            fft(re, im)
            for (b in 0 until nBins) power[b] = re[b] * re[b] + im[b] * im[b]
            for (m in 0 until N_MELS) {
                val fbRow = melFb[m]; var acc = 0.0
                for (b in 0 until nBins) acc += power[b] * fbRow[b]
                val v = ln(acc + EPS)
                out[t][m] = v.toFloat()                 // store log; normalise after
                sum += v; sumSq += v * v
            }
        }
        val mean = sum / total
        val std = sqrt(maxOf(0.0, sumSq / total - mean * mean))
        val inv = 1.0 / (std + 1e-5)
        for (t in 0 until nFrames) for (m in 0 until N_MELS)
            out[t][m] = ((out[t][m] - mean) * inv).toFloat()
        return out
    }

    /** In-place iterative radix-2 Cooley-Tukey FFT (N_FFT is a power of two: 256). */
    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j or bit
            if (i < j) { val tr = re[i]; re[i] = re[j]; re[j] = tr; val ti = im[i]; im[i] = im[j]; im[j] = ti }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wlr = cos(ang); val wli = sin(ang)
            var i = 0
            while (i < n) {
                var wr = 1.0; var wi = 0.0
                for (k in 0 until len / 2) {
                    val ur = re[i + k]; val ui = im[i + k]
                    val vr = re[i + k + len / 2] * wr - im[i + k + len / 2] * wi
                    val vi = re[i + k + len / 2] * wi + im[i + k + len / 2] * wr
                    re[i + k] = ur + vr; im[i + k] = ui + vi
                    re[i + k + len / 2] = ur - vr; im[i + k + len / 2] = ui - vi
                    val nwr = wr * wlr - wi * wli; wi = wr * wli + wi * wlr; wr = nwr
                }
                i += len
            }
            len = len shl 1
        }
    }
}
