package com.ji1ore.wifi_rig_ctrl

import com.ji1ore.wifi_rig_ctrl.data.CwNeuralFeatures
import org.junit.Assert.assertEquals
import kotlin.math.PI
import kotlin.math.sin
import org.junit.Test

/**
 * Verifies the Kotlin log-mel matches the Python training features
 * (CW_CRNN_CTC/feature_ref.json). Same deterministic input: 0.5 s @ 8 kHz,
 * 650 Hz + 1300 Hz tones, first third silenced.
 */
class CwNeuralFeaturesTest {
    @Test fun matchesPythonReference() {
        val sr = CwNeuralFeatures.SAMPLE_RATE
        val n = sr / 2                                   // 4000 samples
        val x = FloatArray(n)
        for (i in 0 until n) {
            val t = i.toDouble() / sr
            x[i] = (0.6 * sin(2 * PI * 650 * t) + 0.2 * sin(2 * PI * 1300 * t)).toFloat()
        }
        for (i in 0 until n / 3) x[i] = 0f               // leading silence

        val f = CwNeuralFeatures.logMel(x)

        // shape (59, 64)
        assertEquals(59, f.size)
        assertEquals(64, f[0].size)

        // frame 0 (silence) -> all ≈ -0.72749
        for (m in 0 until 8) assertEquals(-0.72749, f[0][m].toDouble(), 2e-3)

        // frame 20 (tone) first 8 bins
        val f20 = doubleArrayOf(1.16253, 1.20389, 1.20389, 1.2414, 1.2792, 1.32743, 1.38578, 1.38578)
        for (m in 0 until 8) assertEquals(f20[m], f[20][m].toDouble(), 2e-3)

        // per-utterance normalisation: mean≈0, std≈1
        var sum = 0.0; var sq = 0.0; val tot = f.size * 64
        for (row in f) for (v in row) { sum += v; sq += v.toDouble() * v }
        val mean = sum / tot
        val std = kotlin.math.sqrt(sq / tot - mean * mean)
        assertEquals(0.0, mean, 1e-3)
        assertEquals(1.0, std, 1e-3)
    }
}
