package com.ji1ore.wifi_rig_ctrl.data

import android.content.Context
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

/**
 * Neural CW (Morse) receive decoder: log-mel ([CwNeuralFeatures]) -> TCN+CTC TFLite
 * model -> CTC greedy -> text. Builtin-only model (no Flex). The character alphabet
 * and blank index MUST match CW_CRNN_CTC/config.py.
 *
 * Phase-2 scaffold: [decode] runs one window; [feed] keeps a rolling buffer and
 * decodes the last [windowSec] seconds. The bundled model is a PLACEHOLDER until a
 * trained cw_crnn_ctc.tflite is dropped in — wiring/perf can be verified now, copy
 * quality arrives with the trained weights.
 */
class NeuralCwDecoder(
    context: Context,
    assetName: String = "cw_crnn_ctc.tflite",
    private val windowSec: Double = 4.0,
) {
    private val interpreter: Interpreter

    init {
        val afd = context.assets.openFd(assetName)
        FileInputStream(afd.fileDescriptor).use { fis ->
            val model = fis.channel.map(FileChannel.MapMode.READ_ONLY, afd.startOffset, afd.declaredLength)
            interpreter = Interpreter(model, Interpreter.Options().apply { numThreads = 2 })
        }
    }

    private val sr = CwNeuralFeatures.SAMPLE_RATE
    private val nMels = CwNeuralFeatures.N_MELS
    private val buf = ArrayDeque<Float>()
    private val maxSamples get() = (windowSec * sr).toInt()

    /** Append RX audio (mono float [-1,1] at 8 kHz) to the rolling window. */
    @Synchronized fun feed(samples: FloatArray) {
        for (s in samples) buf.addLast(s)
        while (buf.size > maxSamples) buf.removeFirst()
    }

    /** Decode the current rolling window. */
    @Synchronized fun decodeBuffered(): String {
        if (buf.size < CwNeuralFeatures.N_FFT) return ""
        return decode(buf.toFloatArray())
    }

    /** One-shot decode of a given clip. */
    fun decode(audio: FloatArray): String {
        val feat = CwNeuralFeatures.logMel(audio)      // (T, nMels)
        val t = feat.size
        if (t < 4) return ""

        // Energy gate (DeepFist design rule): a neural CTC model HALLUCINATES characters from pure
        // noise, so without a gate it emits garbage whenever there is no signal — worse than the DSP
        // decoder. Mark each input frame as "signal" only when its peak log-mel rises a margin above
        // the window's own noise floor (a low percentile of the per-frame peaks), then force the CTC
        // output to BLANK over noise-only frames. A noise-only window therefore decodes to "".
        val framePeak = FloatArray(t) { ti ->
            var mx = feat[ti][0]
            for (m in 1 until nMels) if (feat[ti][m] > mx) mx = feat[ti][m]
            mx
        }
        val floor = framePeak.sortedArray()[(t * GATE_FLOOR_PCT).toInt().coerceIn(0, t - 1)]
        val signalFrame = BooleanArray(t) { framePeak[it] > floor + GATE_MARGIN }

        interpreter.resizeInput(0, intArrayOf(1, t, nMels, 1))
        interpreter.allocateTensors()
        val inBuf = ByteBuffer.allocateDirect(t * nMels * 4).order(ByteOrder.nativeOrder())
        for (ti in 0 until t) for (m in 0 until nMels) inBuf.putFloat(feat[ti][m])
        inBuf.rewind()
        val outShape = interpreter.getOutputTensor(0).shape()   // [1, T', C]
        val tp = outShape[1]; val c = outShape[2]
        val out = Array(1) { Array(tp) { FloatArray(c) } }
        interpreter.run(inBuf, out)

        // Map each output frame (time-reduced) to its input frames; gate it off if all are noise.
        val red = t.toFloat() / tp
        val outGate = BooleanArray(tp) { j ->
            val lo = (j * red).toInt().coerceIn(0, t - 1)
            val hi = ((j + 1) * red).toInt().coerceIn(lo + 1, t)
            var sig = false
            for (k in lo until hi) if (signalFrame[k]) { sig = true; break }
            sig
        }
        return ctcGreedy(out[0], outGate)
    }

    fun close() = interpreter.close()

    private fun ctcGreedy(logits: Array<FloatArray>, gate: BooleanArray? = null): String {
        val sb = StringBuilder()
        var prev = -1
        for ((fi, frame) in logits.withIndex()) {
            var best = 0; var bv = frame[0]
            for (i in 1 until frame.size) if (frame[i] > bv) { bv = frame[i]; best = i }
            if (gate != null && !gate[fi]) best = BLANK   // energy gate: no hallucinated char on noise
            if (best != prev && best != BLANK) IDX_TO_CHAR[best]?.let { sb.append(it) }
            prev = best
        }
        return sb.toString()
    }

    companion object {
        const val BLANK = 0
        // Energy-gate tuning (log-mel domain). Final values want a trained model to calibrate against,
        // but these keep a noise-only window silent: floor = 20th-percentile per-frame peak; a signal
        // frame must exceed it by GATE_MARGIN natural-log units (≈ e^1.5 ≈ 4.5× ≈ 6–7 dB).
        private const val GATE_FLOOR_PCT = 0.20f
        private const val GATE_MARGIN = 1.5f
        // Must equal CW_CRNN_CTC/config.py CHARS (index i -> label i+1; 0 = blank).
        private const val CHARS = " ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/?.,=+"
        private val IDX_TO_CHAR: Map<Int, Char> = CHARS.mapIndexed { i, ch -> (i + 1) to ch }.toMap()
    }
}
