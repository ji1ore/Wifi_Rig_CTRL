package com.ji1ore.wifi_rig_ctrl

import android.util.Log
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.ji1ore.wifi_rig_ctrl.data.NeuralCwDecoder
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import kotlin.math.PI
import kotlin.math.sin

@RunWith(AndroidJUnit4::class)
class NeuralCwDecoderInstrumentedTest {
    private val MORSE = mapOf(
        'C' to "-.-.", 'Q' to "--.-", 'D' to "-..", 'E' to ".", 'T' to "-",
        'A' to ".-", 'R' to ".-.", 'S' to "...", 'P' to ".--.", 'I' to "..",
        'U' to "..-", '5' to ".....", '9' to "----.", ' ' to " "
    )
    private fun keyCw(text: String): FloatArray {
        val sr = 8000
        val dit = (1.2 / 20 * sr).toInt()
        val out = ArrayList<Float>()
        fun tone(n: Int) { for (i in 0 until n) out.add((0.8 * sin(2 * PI * 650 * out.size / sr)).toFloat()) }
        fun gap(n: Int) { for (i in 0 until n) out.add(0f) }
        gap(sr / 4)
        for (ch in text.uppercase()) {
            val code = MORSE[ch] ?: continue
            if (ch == ' ') { gap(dit * 7); continue }
            for ((j, el) in code.withIndex()) {
                tone(if (el == '.') dit else dit * 3)
                if (j < code.length - 1) gap(dit)
            }
            gap(dit * 3)
        }
        gap(sr / 4)
        return out.toFloatArray()
    }
    @Test fun runsOnDevice() {
        val ctx = InstrumentationRegistry.getInstrumentation().targetContext
        val dec = NeuralCwDecoder(ctx)
        val audio = keyCw("CQ DE JA")
        val t0 = System.nanoTime()
        val text = dec.decode(audio)
        val ms = (System.nanoTime() - t0) / 1_000_000.0
        Log.i("NeuralCW", "audio=%.2fs infer=%.1fms out=\"%s\" (len=%d)".format(audio.size / 8000.0, ms, text, text.length))
        dec.close()
        assertNotNull(text)
    }
}
