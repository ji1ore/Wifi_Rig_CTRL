Neural CW decoder scaffold (WIP) — moved OUT of the build for v3.31.

Reason: the on-device neural path is not yet wired into the app and the model is an
overfit proof-of-concept (needs GPU training). The TensorFlow Lite 2.16.1 runtime it
pulled in ships a 4 KB-aligned libtensorflowlite_jni.so, which fails Android 15's
16 KB memory-page-size requirement. Rather than ship ~4 MB of unused, non-compliant
native code, the scaffold lives here until training is ready.

To re-enable:
- Move these files back into app/src/... and the .tflite into app/src/main/assets/.
- Add a 16 KB-aligned TFLite/LiteRT runtime, e.g.:
    implementation 'com.google.ai.edge.litert:litert:1.1.0'   (16 KB aligned)
  (or tensorflow-lite 2.17.0+), and re-add noCompress += ["tflite"].
- Verify: unzip the apk, readelf -l lib/arm64-v8a/*.so -> all LOAD align must be 0x4000.
