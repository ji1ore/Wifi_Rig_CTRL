import Foundation

/// CW-domain character TRIGRAM language model for beam-search decoding. Port of CwNgramModel.kt.
///
/// `cost(p2, p1, c)` returns -log P(c | p2, p1) (lower = more likely), interpolated tri/bi/unigram
/// with add-k smoothing, combined with Morse-element acoustic cost during beam search so context
/// resolves characters the timing alone can't.
///
/// No training corpus exists, so one is SYNTHESISED at startup from on-air CW building blocks —
/// ITU-style callsigns, Q-codes, RST reports, abbreviations, numbers, typical QSO flow. Because the
/// corpus is genuine CW content (incl. callsign letter/digit structure) the model tolerates
/// callsigns, unlike a generic English LM. Generation is deterministic (seeded LCG).
final class CwNgramModel {
    static let shared = CwNgramModel()

    private var tri: [Int: Int] = [:]
    private var bi: [Int: Int] = [:]
    private var uni: [Character: Int] = [:]
    private var ctx2: [Int: Int] = [:]
    private var ctx1: [Character: Int] = [:]
    private var totalUni = 0
    private var vocab = 1

    private let K: Float = 0.1
    private let L_TRI: Float = 0.6
    private let L_BI: Float = 0.3
    private let L_UNI: Float = 0.1

    private init() { train(buildCorpus()) }

    /// Touch the singleton so its one-time corpus build runs here (call off the audio thread).
    func warmUp() { /* accessing `shared` has already triggered init */ }

    private func code(_ c: Character) -> Int { Int(c.asciiValue ?? 0) }
    private func key3(_ p2: Character, _ p1: Character, _ c: Character) -> Int {
        (code(p2) & 127) * 16384 + (code(p1) & 127) * 128 + (code(c) & 127)
    }
    private func key2(_ p1: Character, _ c: Character) -> Int {
        (code(p1) & 127) * 128 + (code(c) & 127)
    }

    /// -log P(c | p2, p1) with tri/bi/unigram interpolation.
    func cost(_ p2: Character, _ p1: Character, _ c: Character) -> Float {
        let pUni = (Float(uni[c] ?? 0) + K) / (Float(totalUni) + K * Float(vocab))
        let pBi = (Float(bi[key2(p1, c)] ?? 0) + K) / (Float(ctx1[p1] ?? 0) + K * Float(vocab))
        let c2 = (code(p2) & 127) * 128 + (code(p1) & 127)
        let pTri = (Float(tri[key3(p2, p1, c)] ?? 0) + K) / (Float(ctx2[c2] ?? 0) + K * Float(vocab))
        let p = L_TRI * pTri + L_BI * pBi + L_UNI * pUni
        return -log(max(p, 1e-9))
    }

    private func train(_ corpus: String) {
        var seen = Set<Character>()
        var p2: Character = " "
        var p1: Character = " "
        for ch in corpus {
            uni[ch, default: 0] += 1; totalUni += 1; seen.insert(ch)
            bi[key2(p1, ch), default: 0] += 1
            ctx1[p1, default: 0] += 1
            tri[key3(p2, p1, ch), default: 0] += 1
            let c2 = (code(p2) & 127) * 128 + (code(p1) & 127)
            ctx2[c2, default: 0] += 1
            p2 = p1; p1 = ch
        }
        vocab = max(1, seen.count)
    }

    // MARK: - deterministic synthetic CW/QSO corpus

    private var rng: UInt64 = 0x5DEECE66
    private func rnd(_ n: Int) -> Int {
        rng = (rng &* 0x5DEECE66D &+ 0xB) & 0xFFFFFFFFFFFF
        return Int((rng >> 16) & 0x7FFFFFFF) % n
    }
    private func pick(_ a: [String]) -> String { a[rnd(a.count)] }

    private let prefixes = [
        "JA","JE","JF","JG","JH","JI","JJ","JK","JL","JR","JS","7K","7L","7M","7N","8J",
        "W","K","N","AA","AB","AC","AD","AE","AF","AG","AK","WA","WB","WD","KA","KB","KC","KD","KE","KK","NN",
        "G","M","2E","GW","GM","GI","GD",
        "DL","DK","DJ","DF","DD","DH","DO","DB",
        "F","I","IK","IZ","IW","EA","EB","EC","CT","PA","PE","PD","ON","OT","OZ","OU","SM","SA","LA","LB","OH","OG",
        "VK","ZL","VE","VA","VO","UA","UB","UR","US","UT","UX","R","RA","RK","RN","RV","RW","RZ",
        "BY","BG","BA","BD","HL","DS","6K","VU","YB","YC","YD","9M","9V","HS","E2","DU","PY","PP","PU","LU","LW",
        "CE","CA","HK","HC","OA","CP","CX","ZP","ZS","ZR","5Z","6W","9A","S5","OK","OL","OM","HA","HG",
        "SP","SQ","SN","YO","YP","LZ","TA","4X","4Z","JY","HB","OE","EI","GU","GJ",
        "VR","BV","7J","8N"
    ]
    private let qcodes = [
        "QRL","QRM","QRN","QRO","QRP","QRQ","QRS","QRT","QRU","QRV","QRX","QRZ",
        "QSB","QSK","QSL","QSO","QSP","QSX","QSY","QST","QTC","QTH","QTR","QRG","QRA"
    ]
    private let abbrevs = [
        "CQ","DE","TU","TNX","TKS","FB","HR","HW","ES","GUD","PSE","AGN","CPY","UR","RST",
        "NAME","RIG","ANT","PWR","WX","OM","YL","XYL","DR","GM","GA","GE","GN","GL","VY",
        "K","KN","AR","SK","BK","AS","DX","TEST","NR","NW","WID","WKD","WRK","RPT","SRI","MNI"
    ]
    private let rsts = ["599","579","589","559","569","578","5NN"]
    private let names = ["TOM","BOB","JIM","KEN","JOE","DAVE","MIKE","BILL","JON","AL","RON","DAN","SAM","MAX","TED"]
    private let qths = ["TOKYO","OSAKA","LONDON","PARIS","ROMA","BERLIN","MOSCOW","SEOUL","SYDNEY","DELHI","CAIRO"]

    private func letter() -> Character { Character(UnicodeScalar(UInt8(65 + rnd(26)))) }
    private func digit() -> Character { Character(UnicodeScalar(UInt8(48 + rnd(10)))) }

    private func callsign() -> String {
        let p = pick(prefixes)
        var s = p
        if !p.contains(where: { $0 >= "0" && $0 <= "9" }) { s.append(digit()) }
        for _ in 0..<(1 + rnd(3)) { s.append(letter()) }
        // ~1/7 portable: /P /M /MM /QRP /<digit> — keeps '/' INSIDE the token so the LM learns it
        // belongs to a callsign and won't break the phrase at the slash.
        if rnd(7) == 0 {
            s.append("/")
            switch rnd(5) {
            case 0: s.append("P"); case 1: s.append("M"); case 2: s.append("MM")
            case 3: s.append("QRP"); default: s.append(digit())
            }
        }
        return s
    }
    private func number() -> String {
        var s = ""
        for _ in 0..<(1 + rnd(4)) { s.append(digit()) }
        return s
    }

    private func buildCorpus() -> String {
        var s = ""
        s.reserveCapacity(140_000)
        for _ in 0..<3000 {
            switch rnd(6) {
            case 0:
                let c = callsign()
                s += "CQ CQ CQ DE \(c) \(c) K "
            case 1:
                let me = callsign(); let dx = callsign()
                s += "\(dx) DE \(me) UR RST \(pick(rsts)) \(pick(rsts)) NAME \(pick(names)) QTH \(pick(qths)) HW? \(dx) DE \(me) KN "
            case 2:
                let me = callsign(); let dx = callsign()
                s += "\(dx) DE \(me) R FB \(pick(names)) UR RST \(pick(rsts)) ES \(pick(qcodes)) \(number()) TU 73 73 \(dx) DE \(me) SK "
            case 3:
                s += "\(callsign()) 5NN \(number()) TU "
            case 4:
                for _ in 0..<(4 + rnd(4)) { s += (rnd(2) == 0 ? pick(qcodes) : pick(abbrevs)) + " " }
            default:
                for _ in 0..<(3 + rnd(5)) {
                    switch rnd(4) {
                    case 0: s += callsign() + " "
                    case 1: s += pick(abbrevs) + " "
                    case 2: s += pick(rsts) + " "
                    default: s += number() + " "
                    }
                }
            }
        }
        return s
    }
}
