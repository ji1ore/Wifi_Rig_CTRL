import Foundation

/// Weak-signal, word-level correction for decoded CW — matched by MORSE SIMILARITY, not letters.
///
/// CW copy errors happen at the element level (a dropped/added dit, a dah read as a dit, a boundary
/// landing one element off), so similarity is measured on the raw dit/dah stream. The received
/// word's elements are concatenated into one stream and compared, by element-level edit distance,
/// against each dictionary token's own concatenated Morse. Concatenating ignores character
/// boundaries, so a word split or merged by one element still lines up with the right token.
///
/// Runs only on weak copy (the caller gates on SNR) and never touches callsigns, so clean strong
/// decodes and rare/arbitrary strings are left alone.
final class CwWordCorrector {

    // Common CW tokens. Deliberately excludes arbitrary callsigns and name/QTH content.
    private let names: [String] = Array(Set([
        // prosigns / flow
        "CQ", "DE", "K", "KN", "AR", "SK", "BK", "AS", "BT", "CL",
        // courtesy / chat
        "TU", "TNX", "TKS", "FB", "HR", "HW", "ES", "GUD", "GD", "HI",
        "PSE", "AGN", "CPY", "CUL", "OM", "YL", "XYL", "DR", "GL", "VY",
        "GM", "GA", "GE", "GN", "73", "72", "88",
        // common 3-letter abbreviations
        "ABT", "ANT", "BUG", "CFM", "CPI", "CUZ", "DWN", "ERE", "FER",
        "HPE", "HRD", "LID", "LTR", "MNI", "MSG", "NIL", "OBS",
        "OPR", "PWR", "RCD", "RIG", "RPT", "SED", "SRI", "STN", "SUM",
        "TMW", "TXT", "UFB", "URS", "WDS", "WID", "WKD", "WKG", "WRK", "WUD",
        "NR", "NW", "UR", "OP", "WX", "DX",
        // report / info
        "RST", "QTH", "NAME", "WPM", "RPRT", "599", "579", "589", "559",
        "569", "578", "5NN", "DIT", "DAH",
        // Q-codes (3-letter)
        "QRA", "QRG", "QRL", "QRM", "QRN", "QRO", "QRP", "QRQ", "QRS", "QRT",
        "QRU", "QRV", "QRX", "QRZ", "QSB", "QSK", "QSL", "QSO", "QSP", "QSX",
        "QSY", "QST", "QTC", "QTR",
        // question forms (trailing "?" = ..--.. disambiguates from the plain Q-code)
        "QRZ?", "QRL?", "QSL?", "QRV?", "QTH?", "QRU?",
        // additional frequent abbreviations / ragchew / sign-off
        "BTU", "BCNU", "CUAGN", "CU", "GB", "SIG", "SIGS", "CONDX", "SKED", "SOLID",
        "BAND", "WATTS", "KW", "ENUF", "HRS", "YR", "WK",
        // station / equipment / antenna
        "TRX", "XCVR", "VERT", "DIPOLE", "YAGI", "BEAM", "LOOP", "WIRE", "GP",
        // weather / misc
        "TEMP", "FINE", "NICE", "WARM", "COLD", "RAIN", "SNOW", "SUNNY", "ENJOY", "AGE",
        "TEST"
    ]))

    // token → concatenated Morse element stream (e.g. "CQ" → "-.-." + "--.-")
    private lazy var dict: [(name: String, morse: String)] = names.compactMap { n in
        var m = ""
        for ch in n {
            guard let code = CwDecoder.charToMorse[ch] else { return nil }
            m += code
        }
        return (n, m)
    }

    /// - Parameters:
    ///   - codes: per-character Morse strings of the received word, in order (unknown chars still
    ///            carry the elements that were attempted).
    ///   - letters: decoded letters of that word (used only for the callsign/already-valid guard).
    /// - Returns: a corrected token, or nil to keep the original.
    func correct(codes: [String], letters: String) -> String? {
        let received = codes.joined()
        if received.count < 2 { return nil }
        let w = letters.uppercased()
        if names.contains(w) { return nil }         // already a valid token
        if isCallsignLike(w) { return nil }         // never touch callsigns

        let limit = max(1, Int((Float(received.count) * 0.38).rounded()))
        var best: String? = nil
        var bestD = Int.max
        var secondD = Int.max
        for (name, morse) in dict {
            // prune: edit distance ≥ |length difference|, so anything beyond the budget can't win
            if abs(morse.count - received.count) > limit { continue }
            let d = CwDecoder.editDistance(received, morse)
            if d < bestD { secondD = bestD; bestD = d; best = name }
            else if d < secondD { secondD = d }
        }
        return (best != nil && bestD <= limit && bestD < secondD) ? best : nil
    }

    // ── QSO-template type inference (Option A): predict the class of the NEXT token from the last ──
    func expectedAfter(_ prev: String) -> [String]? {
        switch prev.uppercased() {
        case "":    return ["CQ", "DE", "UR", "QRZ", "TU", "73", "RST", "DX", "TEST", "QSO",
                            "GM", "GA", "GE", "GN"]                                            // start of over (+ greetings)
        case "CQ":  return ["DE", "TEST", "CQ", "QRZ"]
        case "UR":  return ["RST"]
        case "RST": return ["599", "579", "589", "559", "569", "578", "5NN"]
        case "73", "72", "88": return ["73", "72", "TU", "SK", "GL"]
        case "GM", "GA", "GE", "GN": return ["DR", "OM", "UR", "ES"]
        default: return nil
        }
    }

    private func tokenMorse(_ name: String) -> String? {
        var m = ""
        for ch in name {
            guard let c = CwDecoder.charToMorse[ch] else { return nil }
            m += c
        }
        return m
    }

    /// Correct a word toward the nearest token of an EXPECTED class only (tiny candidate set).
    func correctInSet(codes: [String], letters: String, candidates: [String]) -> String? {
        let received = codes.joined()
        if received.count < 2 { return nil }
        let w = letters.uppercased()
        if candidates.contains(w) { return nil }
        if isCallsignLike(w) { return nil }
        let limit = max(1, Int((Float(received.count) * 0.4).rounded()))
        var best: String? = nil
        var bestD = Int.max
        var secondD = Int.max
        for name in candidates {
            guard let morse = tokenMorse(name) else { continue }
            if abs(morse.count - received.count) > limit { continue }
            let d = CwDecoder.editDistance(received, morse)
            if d < bestD { secondD = bestD; bestD = d; best = name }
            else if d < secondD { secondD = d }
        }
        return (best != nil && bestD <= limit && bestD < secondD) ? best : nil
    }

    // A callsign has both letters and digits with real structure (W1AW, JA1ABC, 2E0XYZ). Require
    // length ≥ 4 so RST shorthands like "5NN" stay eligible; pure letters/digits are never callsigns.
    private func isCallsignLike(_ w: String) -> Bool {
        if w.count < 4 { return false }
        let hasLetter = w.contains(where: { $0 >= "A" && $0 <= "Z" })
        let hasDigit = w.contains(where: { $0 >= "0" && $0 <= "9" })
        return hasLetter && hasDigit
    }
}
