// JNI wrapper around mfsk-core (the same FT8/FT4 decoder the Pi uses) so the Android CI-V local
// engine can decode with mfsk-core (depth-based, strong on weak signals) instead of ft8_lib.
//
// Kotlin side (com.ji1ore.wifi_rig_ctrl.data.MfskJni):
//   external fun nativeDecode(samples: ShortArray, rate: Int, freqMin: Float, freqMax: Float,
//                             isFt4: Int, depth: Int): Array<String>
//   external fun nativeEncode(msg: String, baseHz: Float, rate: Int, isFt4: Int): ShortArray?
// Decode returns one JSON string per decode: {"freq":..,"snr":..,"dt":..,"msg":".."}
// Encode returns mono S16_LE PCM (tone 0 at baseHz) for FT8/FT4 TX — replaces ft8_lib so the
// app needs only one native lib (v3.32).

use jni::objects::{JClass, JShortArray, JString};
use jni::sys::{jfloat, jint, jobjectArray, jshortArray};
use jni::JNIEnv;

use mfsk_core::decoder::{DecodeParams, Decoder, Depth, SlotInput};
use mfsk_core::encoder::{encode as mfsk_encode, TxAudio};
use mfsk_core::ft4::Ft4;
use mfsk_core::ft8::Ft8;
use mfsk_core::Mode;

#[no_mangle]
pub extern "system" fn Java_com_ji1ore_wifi_1rig_1ctrl_data_MfskJni_nativeDecode<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    samples: JShortArray<'local>,
    rate: jint,
    freq_min: jfloat,
    freq_max: jfloat,
    is_ft4: jint,
    depth: jint,
) -> jobjectArray {
    let empty = empty_string_array(&mut env);

    let len = env.get_array_length(&samples).unwrap_or(0).max(0) as usize;
    let mut buf = vec![0i16; len];
    if len > 0 && env.get_short_array_region(&samples, 0, &mut buf).is_err() {
        return empty;
    }

    // mfsk-core expects 12 kHz. RS-BA1 audio is 8 kHz → linear-resample up.
    let audio = if rate == 12000 { buf } else { resample(&buf, rate.max(1) as u32, 12000) };

    let d = match depth {
        1 => Depth::Fast,
        3 => Depth::Deep,
        _ => Depth::Normal,
    };
    let slot = SlotInput::i16(&audio);
    let band = (freq_min, freq_max);

    let lines: Vec<String> = if is_ft4 != 0 {
        let mut dec = Decoder::<Ft4>::new(DecodeParams::for_band(band).depth(d));
        dec.decode(&slot)
            .rows
            .iter()
            .map(|r| row_json(r.decoded.freq_hz, r.decoded.snr_db, r.decoded.dt_sec, &r.decoded.text))
            .collect()
    } else {
        let mut dec = Decoder::<Ft8>::new(DecodeParams::for_band(band).depth(d));
        dec.decode(&slot)
            .rows
            .iter()
            .map(|r| row_json(r.decoded.freq_hz, r.decoded.snr_db, r.decoded.dt_sec, &r.decoded.text))
            .collect()
    };

    // Build Java String[]
    let cls = match env.find_class("java/lang/String") {
        Ok(c) => c,
        Err(_) => return empty,
    };
    let blank = env.new_string("").unwrap();
    let arr = match env.new_object_array(lines.len() as i32, &cls, &blank) {
        Ok(a) => a,
        Err(_) => return empty,
    };
    for (i, l) in lines.iter().enumerate() {
        if let Ok(s) = env.new_string(l) {
            let _ = env.set_object_array_element(&arr, i as i32, &s);
        }
    }
    arr.into_raw()
}

/// Encode an FT8/FT4 message to mono S16_LE PCM at `rate` Hz with tone 0 at `base_hz`.
/// Returns a Java short[] (null on error). Replaces ft8_lib's encoder so FT8/FT4 TX also
/// runs on mfsk-core (v3.32).
#[no_mangle]
pub extern "system" fn Java_com_ji1ore_wifi_1rig_1ctrl_data_MfskJni_nativeEncode<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    msg: JString<'local>,
    base_hz: jfloat,
    rate: jint,
    is_ft4: jint,
) -> jshortArray {
    let null: jshortArray = std::ptr::null_mut();

    let text: String = match env.get_string(&msg) {
        Ok(s) => s.into(),
        Err(_) => return null,
    };

    let mode = if is_ft4 != 0 { Mode::Ft4 } else { Mode::Ft8 };
    let enc = match mfsk_encode(mode, &text) {
        Ok(e) => e,
        Err(_) => return null,
    };

    // Synthesize at the canonical 12 kHz (always supported → never panics), then linear-resample
    // to the requested rate (RS-BA1 Wi-Fi CI-V is 8 kHz). Constant-envelope GFSK, so peak ≈ the
    // amplitude we pass; ~0.85 full scale leaves headroom and the Kotlin side then applies txGain.
    let audio = TxAudio::new(12000, base_hz);
    let pcm12 = enc.synthesize_i16(&audio, 28000);
    let pcm: Vec<i16> = if rate == 12000 {
        pcm12
    } else {
        resample(&pcm12, 12000, rate.max(1) as u32)
    };

    let arr = match env.new_short_array(pcm.len() as i32) {
        Ok(a) => a,
        Err(_) => return null,
    };
    if env.set_short_array_region(&arr, 0, &pcm).is_err() {
        return null;
    }
    arr.into_raw()
}

fn row_json(freq_hz: f32, snr_db: f32, dt_sec: f32, text: &str) -> String {
    let esc = text
        .replace('\\', "\\\\")
        .replace('"', "\\\"")
        .replace('\n', "\\n")
        .replace('\r', "\\r");
    format!(
        "{{\"freq\":{:.1},\"snr\":{:.1},\"dt\":{:.2},\"msg\":\"{}\"}}",
        freq_hz, snr_db, dt_sec, esc
    )
}

/// Linear resample i16 PCM from `from_hz` to `to_hz`.
fn resample(input: &[i16], from_hz: u32, to_hz: u32) -> Vec<i16> {
    if input.is_empty() || from_hz == to_hz {
        return input.to_vec();
    }
    let out_len = ((input.len() as u64) * to_hz as u64 / from_hz as u64) as usize;
    let mut out = Vec::with_capacity(out_len);
    let step = from_hz as f64 / to_hz as f64;
    for i in 0..out_len {
        let pos = i as f64 * step;
        let idx = pos.floor() as usize;
        let frac = pos - idx as f64;
        let a = input[idx.min(input.len() - 1)] as f64;
        let b = input[(idx + 1).min(input.len() - 1)] as f64;
        out.push((a + (b - a) * frac).round() as i16);
    }
    out
}

fn empty_string_array(env: &mut JNIEnv) -> jobjectArray {
    match env.find_class("java/lang/String") {
        Ok(cls) => {
            let blank = env.new_string("").unwrap();
            env.new_object_array(0, &cls, &blank)
                .map(|a| a.into_raw())
                .unwrap_or(std::ptr::null_mut())
        }
        Err(_) => std::ptr::null_mut(),
    }
}
