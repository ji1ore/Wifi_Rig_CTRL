import SwiftUI

struct AboutView: View {
    @Bindable var vm: MainViewModel
    @State private var piApiVersion: String = "—"
    @State private var piRigctld: String = "—"
    @State private var piMfskVersion: String = "—"
    @State private var fetchingVersion: Bool = false
    @State private var versionError: String?
    @State private var lastRefreshed: Date?

    /// App short version like "2.12.0" — used to compare with Pi side.
    private var appShortVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "?"
    }
    private var appVersion: String {
        let bundle = Bundle.main
        let short = appShortVersion
        let build = bundle.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "?"
        return "\(short) (\(build))"
    }

    /// True iff Pi API version doesn't match the expected version (from ViewModel's polling result).
    private var versionMismatch: Bool { vm.piVersionMismatch }

    var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                ZStack {
                    Circle()
                        .fill(
                            LinearGradient(
                                colors: [.indigo, .purple, .pink],
                                startPoint: .topLeading, endPoint: .bottomTrailing
                            )
                        )
                        .frame(width: 120, height: 120)
                        .shadow(color: .purple.opacity(0.4), radius: 10)
                    Image(systemName: "antenna.radiowaves.left.and.right")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 64, height: 64)
                        .foregroundStyle(.white)
                }
                .padding(.top, 20)

                VStack(spacing: 4) {
                    Text("Wifi_RIG_CTRL").font(.title.bold())
                    Text("Version \(appVersion)")
                        .font(.callout.monospacedDigit())
                        .foregroundStyle(.secondary)
                    Text("WiFi Ham Radio Controller").font(.subheadline).foregroundStyle(.secondary)
                }

                VStack(alignment: .leading, spacing: 12) {
                    aboutRow(icon: "iphone", color: .indigo,
                             title: "App Version", value: appShortVersion)
                    aboutRow(icon: "server.rack", color: .teal,
                             title: "Pi API Version",
                             value: fetchingVersion ? "Loading…" : piApiVersion)
                    aboutRow(icon: "radio", color: .purple,
                             title: "rigctld",
                             value: fetchingVersion ? "Loading…" : piRigctld)
                    aboutRow(icon: "waveform", color: .green,
                             title: "mfsk-core (Pi)",
                             value: fetchingVersion ? "Loading…" : piMfskVersion)
                    aboutRow(icon: "person.fill", color: .orange,
                             title: "Author", value: "JI1ORE")
                }
                .padding()
                .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
                .padding(.horizontal)

                if versionMismatch {
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            Image(systemName: "exclamationmark.triangle.fill")
                                .foregroundStyle(.orange)
                            Text("Version Mismatch")
                                .font(.headline)
                                .foregroundStyle(.orange)
                        }
                        Text("The Pi API server is on version **\(piApiVersion)** but version **\(MainViewModel.expectedPiApiVersion)** is required. Update the Pi via the UPDATE screen.")
                            .font(.callout)
                            .foregroundStyle(.primary)
                    }
                    .padding()
                    .background(
                        Color.orange.opacity(0.15),
                        in: RoundedRectangle(cornerRadius: 12)
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color.orange.opacity(0.4), lineWidth: 1)
                    )
                    .padding(.horizontal)
                }

                NavigationLink(destination: HelpView()) {
                    Label("Help / Manual", systemImage: "questionmark.circle")
                }
                .buttonStyle(.bordered)
                .tint(.blue)

                NavigationLink(destination: OpenSourceLicensesView()) {
                    Label("Open Source Licenses", systemImage: "doc.text")
                }
                .buttonStyle(.bordered)
                .tint(.green)

                Button {
                    Task { await refreshVersion() }
                } label: {
                    Label("Refresh Pi Version", systemImage: "arrow.clockwise")
                }
                .buttonStyle(.bordered)
                .tint(.indigo)
                .disabled(fetchingVersion)

                if fetchingVersion {
                    HStack(spacing: 8) {
                        ProgressView()
                        Text("Checking Pi version…")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                } else if let t = lastRefreshed {
                    Text("Last checked: \(t.formatted(date: .omitted, time: .shortened))")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }

                if let err = versionError {
                    Text(err)
                        .font(.caption)
                        .foregroundStyle(.red)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                }

                Spacer(minLength: 24)

                Text("© 2025– JI1ORE")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            .padding(.bottom, 24)
        }
        .navigationTitle(Text("About"))
        .navigationBarTitleDisplayMode(.inline)
        .task {
            if piApiVersion == "—" {
                await refreshVersion()
            }
        }
    }

    private func refreshVersion() async {
        fetchingVersion = true
        versionError = nil
        defer { fetchingVersion = false }
        let v = await vm.fetchServerVersion()
        if v.apiVersion == "?" {
            versionError = v.rigctld
        } else {
            piApiVersion = v.apiVersion
            piRigctld = v.rigctld
            piMfskVersion = v.mfskVersion
            versionError = nil
            lastRefreshed = Date()
        }
    }

    private func aboutRow(icon: String, color: Color, title: LocalizedStringKey, value: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(color)
                .frame(width: 24)
            VStack(alignment: .leading, spacing: 1) {
                Text(title).font(.caption).foregroundStyle(.secondary)
                Text(value).font(.body)
            }
            Spacer()
        }
    }
}

/// v3.32: in-app open-source license notices for the libraries COMPILED INTO this app. MIT and
/// BSD-3-Clause require the copyright + licence text to ship with the binary, so they are shown
/// here. mfsk-core (GPL-3.0) is NOT bundled — it was removed in v3.32 and runs only on the Pi.
struct OpenSourceLicensesView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("App-bundled (in this app)")
                    .font(.headline)
                licenseBlock(
                    title: "ft8_lib — FT8/FT4 encode & decode (MIT)",
                    url: "https://github.com/kgoba/ft8_lib",
                    text: Self.ft8libMIT)
                licenseBlock(
                    title: "kissfft — FFT, used inside ft8_lib (BSD-3-Clause)",
                    url: "https://github.com/mborgerding/kissfft",
                    text: Self.kissfftBSD)

                VStack(alignment: .leading, spacing: 6) {
                    Text("Swift Package Manager dependencies").font(.subheadline.bold())
                    Text(Self.spmDeps)
                        .font(.system(.caption2, design: .monospaced))
                        .textSelection(.enabled)
                    Text("MIT full text: see ft8_lib above. Apache-2.0 full text: https://www.apache.org/licenses/LICENSE-2.0")
                        .font(.caption2).foregroundStyle(.secondary).textSelection(.enabled)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 10))

                Divider()

                Text("Raspberry Pi server-side (not in this app)")
                    .font(.headline)
                Text("mfsk-core (GPL-3.0, © JL1NIE), WSJT-X / jt9, Hamlib, Direwolf, FFmpeg and FastAPI run on the Raspberry Pi and are NOT bundled in this app. The app communicates with them over HTTP/SSE only.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
            .padding()
        }
        .navigationTitle(Text("Licenses"))
        .navigationBarTitleDisplayMode(.inline)
    }

    private func licenseBlock(title: String, url: String, text: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.subheadline.bold())
            Text(url).font(.caption).foregroundStyle(.blue).textSelection(.enabled)
            Text(text).font(.system(.caption2, design: .monospaced)).textSelection(.enabled)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 10))
    }

    static let spmDeps = """
    Citadel — SSH client — MIT — github.com/orlandos-nl/Citadel
    BigInt — big integers — MIT — github.com/attaswift/BigInt
    swift-nio — async I/O — Apache-2.0 — github.com/apple/swift-nio
    swift-nio-ssh — SSH (fork) — Apache-2.0 — github.com/Wellz26/swift-nio-ssh
    swift-crypto — crypto — Apache-2.0 — github.com/apple/swift-crypto
    swift-asn1 — ASN.1 — Apache-2.0 — github.com/apple/swift-asn1
    swift-collections — Apache-2.0 — github.com/apple/swift-collections
    swift-atomics — Apache-2.0 — github.com/apple/swift-atomics
    swift-log — Apache-2.0 — github.com/apple/swift-log
    swift-system — Apache-2.0 — github.com/apple/swift-system
    """

    static let ft8libMIT = """
    MIT License

    Copyright (c) 2018 Kārlis Goba

    Permission is hereby granted, free of charge, to any person obtaining a copy \
    of this software and associated documentation files (the "Software"), to deal \
    in the Software without restriction, including without limitation the rights \
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell \
    copies of the Software, and to permit persons to whom the Software is \
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all \
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR \
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, \
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE \
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER \
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, \
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE \
    SOFTWARE.
    """

    static let kissfftBSD = """
    Copyright (c) 2003-2010, Mark Borgerding. All rights reserved.

    Redistribution and use in source and binary forms, with or without \
    modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice, this \
    list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice, \
    this list of conditions and the following disclaimer in the documentation \
    and/or other materials provided with the distribution.
    * Neither the author nor the names of any contributors may be used to endorse \
    or promote products derived from this software without specific prior written \
    permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND \
    ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED \
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE \
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR \
    ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES \
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; \
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON \
    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT \
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS \
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    """
}
