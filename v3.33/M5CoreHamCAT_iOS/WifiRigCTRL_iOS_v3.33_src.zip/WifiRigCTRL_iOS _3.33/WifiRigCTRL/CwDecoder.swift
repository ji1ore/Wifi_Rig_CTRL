import Foundation

/// RX CW decoder (multi-channel support). Port of Android CwDecoder.kt.
///
/// Algorithm:
///   1. Compute spectrum each frame with a 512-point FFT (87.5% overlap)
///   2. Detect local maxima in the CW band (300-3000Hz), track up to N_CHAN
///   3. Each channel processes narrowband energy at its own bin (median-smoothed)
///   4. Key state via Otsu-split adaptive threshold + hysteresis, QSB fade-following
///   5. Per-character dit/dah classification deferred to the char boundary, anchored on
///      intra-character gaps (= exactly 1 dit); sub-frame edge timing for accuracy
final class CwDecoder {
    static let N_CHAN: Int = 5

    static let morseTable: [String: Character] = [
        ".-": "A", "-...": "B", "-.-.": "C", "-..": "D",
        ".": "E", "..-.": "F", "--.": "G", "....": "H",
        "..": "I", ".---": "J", "-.-": "K", ".-..": "L",
        "--": "M", "-.": "N", "---": "O", ".--.": "P",
        "--.-": "Q", ".-.": "R", "...": "S", "-": "T",
        "..-": "U", "...-": "V", ".--": "W", "-..-": "X",
        "-.--": "Y", "--..": "Z",
        "-----": "0", ".----": "1", "..---": "2", "...--": "3",
        "....-": "4", ".....": "5", "-....": "6", "--...": "7",
        "---..": "8", "----.": "9",
        ".-.-.-": ".", "--..--": ",", "..--..": "?",
        "-.--.": "(", "-.--.-": ")", "-..-.": "/",
        ".-.-.": "+", "-...-": "=", ".-...": "&",
        "---...": ":", "-.-.-": ";", ".--.-.": "@",
        ".----.": "'"
    ]

    static let charToMorse: [Character: String] = {
        var m: [Character: String] = [:]
        for (code, ch) in morseTable { m[ch] = code }
        return m
    }()

    /// Run-together prosigns sent as ONE element blob (no inter-char gap). Mapped to their component
    /// letters so they emit as adjacent chars ("BK", "SK"). Only codes that do NOT collide with a
    /// single-char table entry are listed.
    static let prosigns: [String: [(Character, String)]] = [
        "-...-.-": [("B", "-..."), ("K", "-.-")],   // BK  (break)
        "...-.-":  [("S", "..."),  ("K", "-.-")],   // SK  (end of contact)
        "..-.-.":  [("U", "..-"),  ("R", ".-.")]    // UR (very common abbrev, keyed run-together)
    ]

    /// (char, channelIdx, morseCode) — morseCode is the raw dit/dah string ("" for spaces),
    /// so a downstream corrector can compare by Morse-element similarity rather than by letters.
    var onCharDecoded: ((Character, Int, String) -> Void)?
    var onChannelFreq: ((Int, Int) -> Void)?
    var onChannelSwap: ((Int, Int) -> Void)?

    private let sampleRate: Int
    private let fftSize: Int = 512            // v3.33: 1024→512, 15.6Hz/bin, ANALYSIS WINDOW 64ms (was 128ms).
                                              // The 128ms window spanned ~2 elements at 20 WPM (dit≈60ms), so a
                                              // 60ms key-up gap was smeared below detectability — ON/OFF edges
                                              // jittered, splitting/merging elements and dragging the dit estimate
                                              // to ~½. A 64ms window resolves 20 WPM keying. Cost: coarser bins and
                                              // less per-bin processing gain on a weak continuous carrier.
    private let hopSize: Int = 64             // 8ms time resolution (87.5% overlap at 512) — finer element/gap timing
    private let msPerHop: Int
    private let binHz: Float
    private let cwBinMin: Int
    private let cwBinMax: Int
    private let freqTol: Int = 4              // ±62Hz @15.6Hz/bin (kept ≈same Hz as before)
    private let driftRadius: Int = 6          // ±94Hz @15.6Hz/bin (kept ≈same Hz)
    private let peakSnrMin: Float = 4
    /// User-selectable manual key-detect threshold. -1 = automatic (Otsu). Otherwise 0..1: the key-down
    /// threshold is placed that many ×-gain above the tracked NOISE FLOOR (a manual squelch on the
    /// detected tone). Higher = reject more noise; lower = catch weaker signals.
    var manualNoiseLevel: Float = -1
    private let candPromote: Int
    private let deactThresh: Int
    private let noiseFlatnessThresh: Float = 0.35
    private let ditWinsInit: Float
    private let ditWinsMax: Float
    private let ditWinsMin: Float

    private let hannWin: [Float]
    private var ringBuf: [Float]
    private var ringHead: Int = 0
    private var hopCount: Int = 0
    private var fftRe: [Float]
    private var fftIm: [Float]
    private var specPow: [Float]
    private var cwBandBuf: [Float]
    private var peakCandidates: [(bin: Int, count: Int)] = []
    private var channels: [Channel?]
    private var promoteCountdown: Int = 0

    init(sampleRate: Int = 8000) {
        self.sampleRate = sampleRate
        self.msPerHop = max(1, hopSize * 1000 / sampleRate)
        self.binHz = Float(sampleRate) / Float(fftSize)
        self.cwBinMin = max(1, Int(300 / binHz))
        self.cwBinMax = min(fftSize / 2 - 1, Int(3000 / binHz))
        self.candPromote = max(2, 32 / msPerHop)
        self.deactThresh = max(10, 4000 / msPerHop)
        self.ditWinsInit = max(2.0, 32.0 / Float(msPerHop))    // ≈32ms initial (all speeds)
        self.ditWinsMax  = max(3.0, 300.0 / Float(msPerHop))   // ≈300ms upper (~4 WPM)
        self.ditWinsMin  = max(2.0, 24.0 / Float(msPerHop))    // ≈24ms static lower
        let n = fftSize
        self.hannWin = (0..<n).map { i in
            Float(0.5 * (1.0 - cos(2.0 * .pi * Double(i) / Double(n - 1))))
        }
        self.ringBuf = .init(repeating: 0, count: n)
        self.fftRe = .init(repeating: 0, count: n)
        self.fftIm = .init(repeating: 0, count: n)
        self.specPow = .init(repeating: 0, count: n / 2)
        self.cwBandBuf = .init(repeating: 0, count: n / 2)
        self.channels = .init(repeating: nil, count: CwDecoder.N_CHAN)
    }

    // MARK: - Public API

    func reset() {
        for i in 0..<fftSize { ringBuf[i] = 0 }
        ringHead = 0; hopCount = 0
        peakCandidates.removeAll()
        for i in 0..<CwDecoder.N_CHAN {
            if channels[i] != nil { onChannelFreq?(i, 0) }
            channels[i] = nil
        }
    }

    /// Peak-hold linear SNR of a channel (0 if inactive). Gates weak-signal text correction.
    func channelSnr(_ ci: Int) -> Float {
        guard ci >= 0 && ci < CwDecoder.N_CHAN else { return 0 }
        return channels[ci]?.snrLin ?? 0
    }

    /// Mean ON-SNR of the last decoded char on this channel (for confidence colouring).
    func charSnr(_ ci: Int) -> Float {
        guard ci >= 0 && ci < CwDecoder.N_CHAN else { return 0 }
        return channels[ci]?.charSnr ?? 0
    }

    /// Last char's mean ON energy ÷ threshOn (>1 = above threshold).
    func charLevel(_ ci: Int) -> Float {
        guard ci >= 0 && ci < CwDecoder.N_CHAN else { return 0 }
        return channels[ci]?.charLevel ?? 0
    }

    func processSamples(_ samples: [Int16]) {
        for s in samples {
            ringBuf[ringHead] = Float(s) / 32768.0
            ringHead = (ringHead + 1) % fftSize
            hopCount += 1
            if hopCount >= hopSize {
                hopCount = 0
                processFrame()
            }
        }
    }

    // MARK: - Frame processing

    /// Narrowband matched-filter energy: centre bin + half-weighted neighbours (≈2-bin noise BW).
    private func binEnergy(_ b: Int) -> Float {
        let lo = max(cwBinMin, b - 1)
        let hi = min(cwBinMax, b + 1)
        return sqrt(specPow[b] + 0.5 * specPow[lo] + 0.5 * specPow[hi])
    }

    private func processFrame() {
        for i in 0..<fftSize {
            fftRe[i] = ringBuf[(ringHead + i) % fftSize] * hannWin[i]
            fftIm[i] = 0
        }
        fft(&fftRe, &fftIm)
        for bin in cwBinMin...cwBinMax {
            specPow[bin] = fftRe[bin] * fftRe[bin] + fftIm[bin] * fftIm[bin]
        }

        let cwRange = cwBinMax - cwBinMin + 1
        for i in 0..<cwRange { cwBandBuf[i] = specPow[cwBinMin + i] }
        cwBandBuf[0..<cwRange].sort()
        let noiseIdx = min(max(0, Int(Double(cwRange) * 0.20)), cwRange - 1)
        let noisePow = cwBandBuf[noiseIdx]
        let peakMinPow = noisePow * peakSnrMin
        let maxCwPow = cwBandBuf[cwRange - 1]
        let isNoise = maxCwPow <= 0 || noisePow / maxCwPow > noiseFlatnessThresh

        for ci in 0..<CwDecoder.N_CHAN {
            guard let ch = channels[ci] else { continue }
            // QSB/weak-signal: "signal present" = a coherent tone (local peak above noise) still on
            // this channel's bin, not raw energy vs its own threshold. A fade stays peaky, so it
            // rides through; genuine broadband QRN (no local peak) falls through to quiet.
            let b = ch.freqBin
            let tonePresent = specPow[b] > noisePow * 2
                && specPow[b] >= specPow[max(cwBinMin, b - 1)]
                && specPow[b] >= specPow[min(cwBinMax, b + 1)]
            // Peak-hold SNR (slow decay) surfaced for weak-signal word correction.
            let noiseRef = max(1e-6, sqrt(noisePow * 2))
            ch.frameSnr = binEnergy(b) / noiseRef
            ch.snrLin = max(ch.snrLin * 0.95, ch.frameSnr)
            if isNoise && !tonePresent {
                ch.processQuiet(ci: ci, onCharDecoded: onCharDecoded)
            } else {
                if !isNoise && ch.trackPeak(spec: specPow,
                                            cwBinMin: cwBinMin, cwBinMax: cwBinMax,
                                            driftRadius: driftRadius) {
                    onChannelFreq?(ci, ch.freqHz)
                }
                ch.process(rawE: binEnergy(ch.freqBin), ci: ci,
                           manualNoiseLevel: manualNoiseLevel, onCharDecoded: onCharDecoded)
            }
            if ch.shouldDeactivate {
                channels[ci] = nil
                onChannelFreq?(ci, 0)
            }
        }

        // Merge channels that converged onto the same bin (keep the stronger)
        for i in 0..<(CwDecoder.N_CHAN - 1) {
            guard let ci = channels[i] else { continue }
            for j in (i + 1)..<CwDecoder.N_CHAN {
                guard let cj = channels[j] else { continue }
                if abs(ci.freqBin - cj.freqBin) <= freqTol {
                    if ci.smoothE >= cj.smoothE {
                        channels[j] = nil; onChannelFreq?(j, 0)
                    } else {
                        channels[i] = nil; onChannelFreq?(i, 0); break
                    }
                }
            }
        }

        // Strong-bin candidates not covered by an existing channel
        var strongBins: Set<Int> = []
        if cwBinMax > cwBinMin + 1 {
            for bin in (cwBinMin + 1)..<cwBinMax {
                if specPow[bin] > specPow[bin - 1] && specPow[bin] > specPow[bin + 1]
                   && specPow[bin] >= peakMinPow {
                    let covered = channels.contains(where: { ch in
                        ch != nil && abs(ch!.freqBin - bin) <= freqTol
                    })
                    if !covered { strongBins.insert(bin) }
                }
            }
        }
        peakCandidates.removeAll(where: { !strongBins.contains($0.bin) })
        for bin in strongBins {
            if let idx = peakCandidates.firstIndex(where: { $0.bin == bin }) {
                peakCandidates[idx].count += 1
            } else {
                peakCandidates.append((bin: bin, count: 1))
            }
        }

        // Slot-0 promotion (~2s cadence)
        promoteCountdown += 1
        if promoteCountdown >= max(10, 2000 / msPerHop) {
            promoteCountdown = 0
            var bestSlot = 0
            var bestE: Float = channels[0]?.smoothE ?? -1
            for i in 1..<CwDecoder.N_CHAN {
                let e = channels[i]?.smoothE ?? -1
                if e > bestE * 1.5 { bestE = e; bestSlot = i }
            }
            if bestSlot != 0 {
                let tmp = channels[0]; channels[0] = channels[bestSlot]; channels[bestSlot] = tmp
                onChannelFreq?(0, channels[0]?.freqHz ?? 0)
                onChannelFreq?(bestSlot, channels[bestSlot]?.freqHz ?? 0)
                onChannelSwap?(0, bestSlot)
            }
        }

        // Promote sustained candidates
        let noiseE = sqrt(noisePow * 2)   // ~2-bin equivalent, matched to binEnergy() weighting
        let sortedStrong = strongBins.sorted(by: { specPow[$0] > specPow[$1] })
        for bin in sortedStrong {
            guard let cand = peakCandidates.first(where: { $0.bin == bin }) else { continue }
            if cand.count < candPromote { continue }
            guard let slot = channels.firstIndex(where: { $0 == nil }) else { break }
            let e = binEnergy(bin)
            let ch = Channel(
                freqBin: bin, seedSigE: e, seedNoiseE: noiseE,
                msPerHop: msPerHop, binHz: binHz,
                ditWinsInit: ditWinsInit, ditWinsMax: ditWinsMax, ditWinsMin: ditWinsMin,
                candPromote: candPromote, deactThresh: deactThresh
            )
            channels[slot] = ch
            onChannelFreq?(slot, ch.freqHz)
            peakCandidates.removeAll(where: { $0.bin == bin })
            ch.process(rawE: e, ci: slot, manualNoiseLevel: manualNoiseLevel, onCharDecoded: onCharDecoded)
        }
    }

    // MARK: - Morse near-miss recovery (single element off), used only on clean copy

    static func nearestMorse(_ code: String) -> Character? {
        if code.isEmpty || code.count > 8 { return nil }
        var best: Character? = nil
        var bestD = Int.max
        var secondD = Int.max
        for (m, ch) in morseTable {
            if abs(m.count - code.count) > 1 { continue }
            let d = editDistance(code, m)
            if d < bestD { secondD = bestD; bestD = d; best = ch }
            else if d < secondD { secondD = d }
        }
        return (bestD <= 1 && bestD < secondD) ? best : nil
    }

    static func editDistance(_ a: String, _ b: String) -> Int {
        let aa = Array(a), bb = Array(b)
        var prev = Array(0...bb.count)
        var cur = [Int](repeating: 0, count: bb.count + 1)
        if aa.isEmpty { return bb.count }
        for i in 1...aa.count {
            cur[0] = i
            for j in 1...bb.count {
                let cost = aa[i - 1] == bb[j - 1] ? 0 : 1
                cur[j] = min(min(prev[j] + 1, cur[j - 1] + 1), prev[j - 1] + cost)
            }
            prev = cur
        }
        return prev[bb.count]
    }

    /// Characters whose Morse code is within `maxDist` element edits of `code`, with that distance.
    static func morseCandidates(_ code: String, _ maxDist: Int) -> [(Character, Int)] {
        if code.isEmpty || code.count > 9 { return [] }
        var out: [(Character, Int)] = []
        for (m, ch) in morseTable {
            if abs(m.count - code.count) > maxDist { continue }
            let d = editDistance(code, m)
            if d <= maxDist { out.append((ch, d)) }
        }
        return out
    }

    // MARK: - FFT (Cooley-Tukey, in-place, complex)

    private func fft(_ re: inout [Float], _ im: inout [Float]) {
        let n = re.count
        var j = 0
        for i in 1..<n {
            var bit = n >> 1
            while (j & bit) != 0 { j ^= bit; bit >>= 1 }
            j ^= bit
            if i < j {
                re.swapAt(i, j); im.swapAt(i, j)
            }
        }
        var len = 2
        while len <= n {
            let half = len >> 1
            let ang = -Double.pi / Double(half)
            let wRe = Float(cos(ang))
            let wIm = Float(sin(ang))
            var i = 0
            while i < n {
                var cRe: Float = 1
                var cIm: Float = 0
                for k in 0..<half {
                    let uRe = re[i + k]
                    let uIm = im[i + k]
                    let vRe = re[i + k + half] * cRe - im[i + k + half] * cIm
                    let vIm = re[i + k + half] * cIm + im[i + k + half] * cRe
                    re[i + k] = uRe + vRe; im[i + k] = uIm + vIm
                    re[i + k + half] = uRe - vRe; im[i + k + half] = uIm - vIm
                    let nc = cRe * wRe - cIm * wIm
                    cIm = cRe * wIm + cIm * wRe
                    cRe = nc
                }
                i += len
            }
            len <<= 1
        }
    }
}

// MARK: - Channel

private final class Channel {
    var freqBin: Int
    var freqHz: Int { Int(Float(freqBin) * binHz) }

    private let binHz: Float
    private let candPromote: Int
    private let deactThreshLocal: Int
    private let ditWinsMaxLocal: Float
    private let ditWinsMinLocal: Float

    private let histSize: Int
    private let suspendThresh: Int
    private let elemFlushThresh: Int
    private var hist: [Float]
    private var histIdx: Int = 0

    private var threshOn: Float = .greatestFiniteMagnitude
    private var threshOff: Float = .greatestFiniteMagnitude
    private var eFloor: Float = 0             // slow minimum-envelope of energy = tracked noise floor
    private var floorSeeded: Bool = false
    private var elemPeak: Float = 0           // peak energy of the element currently keyed-ON (AGC-relative OFF)
    private var suspKeyOnFrames: Int = 0

    var keyOn: Bool = false
    var keyOnWins: Int = 0
    var keyOffWins: Int = 0
    var charFlushed: Bool = false
    var wordEmitted: Bool = false
    var ditWins: Float
    private var ditSeeded: Bool = false        // speed locked from the first element
    private var unitConfirmed: Bool = false    // an intra-char gap has pinned the true dit length
    private var elemDurs: [Float] = []         // raw element (key-ON) durations of the current char
    private var gapDurs: [Float] = []          // raw intra-char (key-OFF) gaps of the current char
    private var ctxP2: Character = " "         // previous-previous emitted char (CW trigram context)
    private var ctxP1: Character = " "         // previous emitted char

    var framesNoRealElement: Int = 0
    var hadSignal: Bool = false
    var smoothE: Float = 0
    var snrLin: Float = 0                       // peak-hold linear SNR (weak-signal word correction)
    var frameSnr: Float = 0                     // this frame's bin-SNR (set by processFrame)
    private var charSnrSum: Float = 0           // Σ frameSnr over the current char's ON frames
    private var charSnrCnt: Int = 0
    var charSnr: Float = 0                      // mean ON-SNR of the last decoded char (confidence colouring)
    private var charESum: Float = 0             // Σ (threshold-domain) energy over the current char's ON frames
    var charLevel: Float = 0                    // last char's mean ON energy ÷ threshOn (>1 = above threshold)
    private var elemSnrSum: Float = 0           // Σ frameSnr over the CURRENT element's ON frames
    private var elemSnrCnt: Int = 0
    private var elemSnrs: [Float] = []          // mean ON-SNR per element, parallel to elemDurs

    // median-3 envelope smoothing + sub-frame edge timing state
    private var rawPrev1: Float = 0
    private var rawPrev2: Float = 0
    private var prevE: Float = 0
    private var edgeFrac: Float = 0
    private var pendingOnGap: Float = 0  // gap-before-element, committed (resets keyOffWins) only once the ON segment is CONFIRMED a real element — a sub-dit noise blip stays transparent so an inter-word silence keeps accumulating toward a space (opening filter)

    init(freqBin: Int, seedSigE: Float, seedNoiseE: Float,
         msPerHop: Int, binHz: Float,
         ditWinsInit: Float, ditWinsMax: Float, ditWinsMin: Float,
         candPromote: Int, deactThresh: Int) {
        self.freqBin = freqBin
        self.binHz = binHz
        self.candPromote = candPromote
        self.deactThreshLocal = deactThresh
        self.ditWinsMaxLocal = ditWinsMax
        self.ditWinsMinLocal = ditWinsMin
        self.ditWins = ditWinsInit
        self.histSize = max(30, 1200 / msPerHop)      // 1600→1200: track QSB fades faster
        self.suspendThresh = max(5, 2500 / msPerHop)  // slow-CW word gaps
        self.elemFlushThresh = max(3, 500 / msPerHop)
        self.hist = .init(repeating: 0, count: max(30, 1200 / msPerHop))
        if seedSigE > seedNoiseE {
            threshOn = seedNoiseE + (seedSigE - seedNoiseE) * 0.50
            threshOff = seedNoiseE + (seedSigE - seedNoiseE) * 0.22
        }
        let seedN = max(candPromote, 8)
        for _ in 0..<seedN { hist[histIdx % histSize] = seedSigE; histIdx += 1 }
        for _ in 0..<seedN { hist[histIdx % histSize] = seedNoiseE; histIdx += 1 }
    }

    private func clampDit(_ v: Float) -> Float { min(max(v, ditWinsMinLocal), ditWinsMaxLocal) }

    private func median3(_ a: Float, _ b: Float, _ c: Float) -> Float {
        max(min(a, b), min(max(a, b), c))
    }

    func process(rawE: Float, ci: Int, manualNoiseLevel: Float,
                 onCharDecoded: ((Character, Int, String) -> Void)?) {
        // median-of-3 envelope smoothing: rejects single-frame dropouts/spikes (1-frame debounce)
        let energy = median3(rawE, rawPrev1, rawPrev2)
        rawPrev2 = rawPrev1; rawPrev1 = rawE
        let pE = prevE; prevE = energy

        smoothE = smoothE * 0.97 + energy * 0.03
        hist[histIdx % histSize] = energy
        histIdx += 1
        let valid = min(histIdx, histSize)

        // Track the noise floor as a slow minimum-envelope: snap DOWN to quiet frames instantly,
        // rise only very slowly. CW's frequent key-up gaps keep this pinned to the true noise floor.
        if !floorSeeded { eFloor = energy; floorSeeded = true }
        else { eFloor = energy < eFloor ? energy : eFloor * 0.9997 + energy * 0.0003 }

        if manualNoiseLevel >= 0 {
            // Manual squelch: fixed gain above the tracked noise floor (user-selected). No Otsu.
            let gain = 2 + manualNoiseLevel * 13        // 0..1 → 2×..15× the noise floor
            threshOn = eFloor * gain
            threshOff = eFloor * gain * 0.75
        } else if histIdx % 5 == 0 && valid >= 5 {
            updateThresh(valid: valid)
        }

        if threshOn == .greatestFiniteMagnitude {
            if keyOn { keyOnWins += 1 } else { keyOffWins += 1; framesNoRealElement += 1 }
            return
        }

        if framesNoRealElement == elemFlushThresh && !elemDurs.isEmpty && !charFlushed {
            flushChar(ci: ci, onCharDecoded: onCharDecoded); charFlushed = true
            keyOn = false; keyOnWins = 0
        }

        if framesNoRealElement > suspendThresh {
            if energy > threshOn {
                suspKeyOnFrames += 1
                if suspKeyOnFrames >= candPromote {
                    framesNoRealElement = 0; keyOffWins = 0; keyOn = false; keyOnWins = 0
                    elemDurs.removeAll(); gapDurs.removeAll(); elemSnrs.removeAll()
                    charFlushed = false; wordEmitted = false
                    suspKeyOnFrames = 0; ditSeeded = false; unitConfirmed = false; edgeFrac = 0
                    ctxP2 = " "; ctxP1 = " "
                    // fall through
                } else { return }
            } else {
                suspKeyOnFrames = 0; framesNoRealElement += 1; return
            }
        }

        // OFF threshold rides the ELEMENT's own peak (AGC-relative), floored by the global threshOff.
        // At onset the global threshOff is still calibrated to preceding silence (too low), so a fixed
        // threshOff let the first element's decay tail run on. Cutting OFF at 40% of the element's peak
        // ends it at the true key-up regardless of the stale global threshold.
        let offTh = max(threshOff, elemPeak * 0.4)
        let isOn = keyOn ? (energy > offTh) : (energy > threshOn)
        if isOn && !keyOn {
            // sub-frame rising edge: where threshOn is crossed between prev and current frame.
            // DEFER the keyOffWins reset: don't commit the gap until this ON segment is confirmed a real
            // element at the falling edge. A sub-dit noise blip during an inter-word silence must NOT reset
            // the silence counter, or the word space (keyOffWins ≥ wordGapMul·dit) never fires and words
            // merge (ICOM run-on). keyOffWins stays FROZEN through the provisional ON. (opening filter)
            let fOn = energy > pE ? min(max((threshOn - pE) / (energy - pE), 0), 1) : 0.5
            pendingOnGap = Float(keyOffWins) + (fOn - edgeFrac)
            edgeFrac = fOn
            keyOn = true; hadSignal = true
            elemPeak = energy                 // start tracking this element's peak
            elemSnrSum = 0; elemSnrCnt = 0     // start a fresh per-element SNR accumulation
        } else if !isOn && keyOn {
            let fOff = pE > energy ? min(max((pE - offTh) / (pE - energy), 0), 1) : 0.5
            let dur = Float(keyOnWins) + (fOff - edgeFrac)
            // Opening filter: accept the ON segment as an element only at the SAME floor analyzeElement
            // uses (0.6·dit once seeded). If confirmed, NOW commit the deferred gap (resets keyOffWins);
            // if it's a sub-dit blip, discard it and leave keyOffWins untouched so the silence survives.
            let effMin = ditSeeded ? max(ditWinsMinLocal, ditWins * 0.6) : ditWinsMinLocal
            if dur >= effMin {
                analyzeGap(dur: pendingOnGap, ci: ci, onCharDecoded: onCharDecoded)   // finalize gap / prev char FIRST
                keyOffWins = 0; charFlushed = false; wordEmitted = false
                analyzeElement(dur: dur)                                              // then add this confirmed element
            }
            edgeFrac = fOff
            keyOnWins = 0; keyOn = false
        }
        if keyOn {
            keyOnWins += 1
            if energy > elemPeak { elemPeak = energy }
            charSnrSum += frameSnr; charSnrCnt += 1
            elemSnrSum += frameSnr; elemSnrCnt += 1
            charESum += energy
        } else {
            keyOffWins += 1; framesNoRealElement += 1
            if !charFlushed && Float(keyOffWins) >= ditWins * 3 {
                flushChar(ci: ci, onCharDecoded: onCharDecoded); charFlushed = true
            }
            if !wordEmitted && hadSignal && Float(keyOffWins) >= ditWins * wordGapMul() {
                onCharDecoded?(" ", ci, ""); ctxP2 = ctxP1; ctxP1 = " "; wordEmitted = true
            }
        }
    }

    func processQuiet(ci: Int, onCharDecoded: ((Character, Int, String) -> Void)?) {
        if keyOn {
            // Close a provisional ON under the SAME opening-filter gate as process(): commit the deferred
            // gap + reset the silence counter only if this element is confirmed real; a sub-dit blip is
            // discarded with keyOffWins left intact so the inter-word silence keeps accumulating.
            let dur = Float(keyOnWins)
            let effMin = ditSeeded ? max(ditWinsMinLocal, ditWins * 0.6) : ditWinsMinLocal
            if dur >= effMin {
                analyzeGap(dur: pendingOnGap, ci: ci, onCharDecoded: onCharDecoded)
                keyOffWins = 0; charFlushed = false; wordEmitted = false
                analyzeElement(dur: dur)
            }
            keyOnWins = 0; keyOn = false
        }
        keyOffWins += 1; framesNoRealElement += 1
        if !charFlushed && Float(keyOffWins) >= ditWins * 3 {
            flushChar(ci: ci, onCharDecoded: onCharDecoded); charFlushed = true
        }
        if !wordEmitted && hadSignal && Float(keyOffWins) >= ditWins * wordGapMul() {
            onCharDecoded?(" ", ci, ""); ctxP2 = ctxP1; ctxP1 = " "; wordEmitted = true
        }
    }

    private func updateThresh(valid: Int) {
        // During a gap we must not RAISE the threshold toward noise, but a QSB fade looks the same
        // at first — so instead of freezing, keep computing and allow it to FOLLOW THE SIGNAL DOWN
        // (never up) while gapped, re-acquiring a fading signal.
        let gapped = framesNoRealElement > histSize / 2

        // Otsu's method over the energy history (robust for sparse CW where ON frames are a minority)
        var mn = Float.greatestFiniteMagnitude
        var mx: Float = 0
        for i in 0..<valid { let v = hist[i]; if v < mn { mn = v }; if v > mx { mx = v } }
        if mx <= 0 || mx < mn * 2 { return }

        let nBins = 32
        var bins = [Int](repeating: 0, count: nBins)
        let span = mx - mn
        let scale = Float(nBins - 1) / span
        for i in 0..<valid {
            let idx = min(max(0, Int((hist[i] - mn) * scale)), nBins - 1)
            bins[idx] += 1
        }
        var sumAll: Float = 0
        for b in 0..<nBins { sumAll += Float(b) * Float(bins[b]) }
        var wB = 0; var sumB: Float = 0; var maxVar: Float = -1; var splitBin = 0
        for b in 0..<nBins {
            wB += bins[b]
            if wB == 0 { continue }
            let wF = valid - wB
            if wF == 0 { break }
            sumB += Float(b) * Float(bins[b])
            let mB = sumB / Float(wB)
            let mF = (sumAll - sumB) / Float(wF)
            let between = Float(wB) * Float(wF) * (mB - mF) * (mB - mF)
            if between > maxVar { maxVar = between; splitBin = b }
        }

        let splitE = mn + (Float(splitBin) + 0.5) / scale
        var loSum: Float = 0; var loN = 0; var hiSum: Float = 0; var hiN = 0
        for i in 0..<valid {
            let v = hist[i]
            if v <= splitE { loSum += v; loN += 1 } else { hiSum += v; hiN += 1 }
        }
        if loN == 0 || hiN == 0 { return }
        let lo = loSum / Float(loN)
        let hi = hiSum / Float(hiN)
        if hi <= lo * 1.5 { return }
        let tOn = lo + (hi - lo) * 0.45
        let tOff = lo + (hi - lo) * 0.20      // deeper hysteresis → ride through shallow QSB dips
        if gapped {
            if tOn < threshOn { threshOn = tOn; threshOff = tOff }   // fade-follow: lower only
        } else {
            threshOn = tOn; threshOff = tOff
        }
    }

    private func analyzeElement(dur: Float) {
        // Noise filter at 0.6×dit once seeded — lower values let noise elements through and degrade
        // clean copy / dit-dah discrimination. Before seeding use only the absolute floor so a leading
        // dit isn't dropped (J=.--- else reads as O=---). A genuinely attack-clipped weak leading dit
        // below 0.6 is left to the dictionary/N-gram word corrector to recover.
        let effectiveMin = ditSeeded ? max(ditWinsMinLocal, ditWins * 0.6) : ditWinsMinLocal
        if dur < effectiveMin { return }
        framesNoRealElement = 0
        // Seed the live unit from the first element so GAP segmentation works immediately.
        // dit/dah LABELS are decided later in flushChar from the whole character.
        // Robust seed: a lone first element is often a DAH (≈3×dit) or a noise blob, so OVERWRITING the
        // unit with it swings the speed estimate 3–10× (dit 6.7↔75 while true dit ≈17) and wrecks both
        // char segmentation and the dit/dah split → weak-signal garble (EEEEE, 5OM). BLEND the new element
        // with the retained prior unit (last locked speed) so one bad element can't capture the estimate.
        if !ditSeeded {
            let seed = clampDit(dur)
            ditWins = clampDit(clampDit(ditWins) * 0.5 + seed * 0.5)
            ditSeeded = true
        }
        elemDurs.append(dur)
        elemSnrs.append(elemSnrCnt > 0 ? elemSnrSum / Float(elemSnrCnt) : 0)
    }

    // Word-gap threshold shifted by P(space|context) per the CW N-gram (language, not just timing,
    // decides the phrase break). Likely space → smaller gap; unlikely (mid-call, '/') → larger.
    private func wordGapMul() -> Float {
        let c = CwNgramModel.shared.cost(ctxP2, ctxP1, " ")
        // Floor at 6 dits: inter-char gaps (≈3 dits) must not split a callsign; only a clear word gap
        // (standard ≈7) breaks. Ceiling keeps run-on words apart.
        return min(max(4.4 + c * 1.2, 6), 9)
    }

    // dit unit: lock DOWN fast, leak UP slowly — driven by dits and intra-char gaps (both ≈1 dit)
    private func observeUnit(_ unit: Float) {
        let u = clampDit(unit)
        ditWins = u < ditWins ? (ditWins * 0.5 + u * 0.5) : (ditWins * 0.9 + u * 0.1)
        ditWins = clampDit(ditWins)
    }

    private func analyzeGap(dur: Float, ci: Int, onCharDecoded: ((Character, Int, String) -> Void)?) {
        if elemDurs.isEmpty || charFlushed { return }
        let g = dur
        if g >= ditWins * wordGapMul() {
            flushChar(ci: ci, onCharDecoded: onCharDecoded); charFlushed = true
            if !wordEmitted { onCharDecoded?(" ", ci, ""); ctxP2 = ctxP1; ctxP1 = " "; wordEmitted = true }
        } else if g >= ditWins * 2.0 {   // 2.5→2.0 (CW standard dit/inter-char midpoint): separate tight inter-char gaps so a trailing element isn't merged (T→N)
            flushChar(ci: ci, onCharDecoded: onCharDecoded); charFlushed = true
        } else if g >= ditWinsMinLocal {
            gapDurs.append(g)   // intra-char space ≈ 1 dit → anchors speed
            // The first intra-char gap of a fresh lock IS the ground-truth dit length → pin it now,
            // correcting a dah-seeded first element before its high effectiveMin drops real dits.
            // Blend element-seed with the first gap so one short gap can't half-lock the unit.
            if !unitConfirmed { ditWins = ditWins * 0.4 + clampDit(g) * 0.6; unitConfirmed = true }
            // Collapse guard: a real intra-char gap ≈ 1 dit. Once the unit is locked, a gap far BELOW it
            // (< 0.5×ditWins) is a key-bounce / QRN fragment, not a real 1-dit space. Feeding it to the
            // fast-down observeUnit lets one garbage blob (e.g. the irregular tail after a station's "K":
            // elem/gap all ~⅓ dit) cascade-collapse a well-established speed lock to ~½, after which every
            // real dit AND dah exceeds ditWins×2 and reads as a lone dah → endless "TTT / M" run with no
            // recovery. Rejecting sub-½-dit gaps from the unit still tracks any ≤2× speed-up (new dit ≥
            // 0.5×old) but stops the transient collapse. Verified on a real RX capture (JCC1217 K → TTT).
            else if g >= ditWins * 0.5 { observeUnit(g) }
        }
    }

    // Finish the current character: decide its dit unit and BUFFER its candidate characters. No
    // emission yet — the whole word is decoded together by beam search at the word boundary.
    // Decode this character IMMEDIATELY (low latency): nearest candidates by Morse-element distance,
    // with the CW trigram breaking ties / resolving ambiguity from the context already emitted.
    // (Word-level beam was dropped — it delayed output by a whole word, and its only edge over
    // greedy, revising an earlier char from a later one, is marginal for a trigram.)
    private func flushChar(ci: Int, onCharDecoded: ((Character, Int, String) -> Void)?) {
        if elemDurs.isEmpty { return }
        // A real CW character is ≤6 elements (≤7 for run-together prosigns). A much longer "character"
        // means inter-char gaps were missed (unlocked startup / QRN) — discard rather than emit a long
        // garbage blob that shows as '?'.
        if elemDurs.count > 8 { elemDurs.removeAll(); gapDurs.removeAll(); elemSnrs.removeAll(); return }
        // Drop a spurious LEADING element born of noise (a click / QRN burst just before the real
        // character). A noise blip sits near the noise floor in ON-SNR; a real key-down is far above
        // it. Drop a leading element only when its ON-SNR is below 0.2× the strongest real element.
        while elemDurs.count >= 2 && elemSnrs.count == elemDurs.count {
            var maxRest: Float = 0
            for i in 1..<elemSnrs.count { if elemSnrs[i] > maxRest { maxRest = elemSnrs[i] } }
            if maxRest > 0 && elemSnrs[0] < maxRest * 0.2 {
                elemDurs.removeFirst(); elemSnrs.removeFirst()
                if !gapDurs.isEmpty { gapDurs.removeFirst() }   // drop the gap after the blip too
            } else { break }
        }
        var unit = ditWins
        if !gapDurs.isEmpty {
            var s: Float = 0; for x in gapDurs { s += x }
            unit = s / Float(gapDurs.count)
        }
        var shortest = Float.greatestFiniteMagnitude
        var longest: Float = 0
        for d in elemDurs { if d < shortest { shortest = d }; if d > longest { longest = d } }
        if shortest < unit { unit = (unit + shortest) * 0.5 }
        unit = clampDit(min(unit, ditWins * 1.5))

        // dit/dah boundary. With BOTH short and long elements there is a clear valley → split at the
        // geometric mean of shortest & longest. A homogeneous character (all dits or all dahs) has no
        // valley → split on the tracked dit unit (ditWins×2 ≈ midway dit↔dah). The old gapUnit×2.8 ran
        // too high where hysteresis inflates the dit ON toward the gap, so lone/short dahs (≈2.6×gap)
        // fell under it and read as dits (T→E, 5 dahs→"5").
        let thr = longest >= shortest * 2.2 ? sqrt(shortest * longest) : ditWins * 2.0

        var code = ""
        for d in elemDurs { code.append(d < thr ? "." : "-") }

        // Run-together prosign (BK/SK sent as one blob) → emit its component letters adjacently.
        if let prosign = CwDecoder.prosigns[code] {
            charSnr = charSnrCnt > 0 ? charSnrSum / Float(charSnrCnt) : 0
            charLevel = (charSnrCnt > 0 && threshOn > 0 && threshOn != .greatestFiniteMagnitude)
                ? (charESum / Float(charSnrCnt)) / threshOn : 0
            charSnrSum = 0; charSnrCnt = 0; charESum = 0
            for (pc, pcode) in prosign {
                onCharDecoded?(pc, ci, pcode); ctxP2 = ctxP1; ctxP1 = pc
            }
            ditWins = unit; ditSeeded = true
            elemDurs.removeAll(); gapDurs.removeAll(); elemSnrs.removeAll()
            return
        }

        // Run-together of two chars sent with NO inter-char gap (e.g. "CQ" = -.-.--.- as one 8-element
        // blob). If the whole code is not a single char, split it into two ALPHANUMERIC Morse chars at the
        // position whose intra gap is LARGEST (the sender's real inter-char spacing, the cue the ear uses)
        // and emit both — accept a unique split outright, an ambiguous one only when that gap clearly
        // dominates the intra-char gaps, so we don't guess on even spacing.
        if CwDecoder.morseTable[code] == nil && code.count >= 4 && code.count <= 9 {
            let chars = Array(code)
            var splitAt = -1
            var bestGap: Float = -1
            var nSplits = 0
            let medGap: Float = gapDurs.isEmpty ? 0 : gapDurs.sorted()[gapDurs.count / 2]
            for i in 2..<(code.count - 1) {
                let a = CwDecoder.morseTable[String(chars[0..<i])]
                let b = CwDecoder.morseTable[String(chars[i...])]
                if let a, let b, (a.isLetter || a.isNumber), (b.isLetter || b.isNumber) {
                    nSplits += 1
                    let gapHere: Float = (i - 1 < gapDurs.count) ? gapDurs[i - 1] : 0
                    if gapHere > bestGap { bestGap = gapHere; splitAt = i }
                }
            }
            if splitAt > 0 && (nSplits == 1 || bestGap >= medGap * 1.5) {
                let ca = CwDecoder.morseTable[String(chars[0..<splitAt])]!
                let cb = CwDecoder.morseTable[String(chars[splitAt...])]!
                charSnr = charSnrCnt > 0 ? charSnrSum / Float(charSnrCnt) : 0
                charLevel = (charSnrCnt > 0 && threshOn > 0 && threshOn != .greatestFiniteMagnitude)
                    ? (charESum / Float(charSnrCnt)) / threshOn : 0
                charSnrSum = 0; charSnrCnt = 0; charESum = 0
                onCharDecoded?(ca, ci, String(chars[0..<splitAt])); ctxP2 = ctxP1; ctxP1 = ca
                onCharDecoded?(cb, ci, String(chars[splitAt...])); ctxP2 = ctxP1; ctxP1 = cb
                ditWins = unit; ditSeeded = true
                elemDurs.removeAll(); gapDurs.removeAll(); elemSnrs.removeAll()
                return
            }
        }

        // A code that maps EXACTLY to a Morse character is trusted as-is; the LM-assisted candidate
        // search runs ONLY for garbled codes with no exact table entry.
        let exact = CwDecoder.morseTable[code]
        let maxDist = code.count >= 5 ? 3 : 1
        var cands = exact != nil ? [] : CwDecoder.morseCandidates(code, maxDist)
        // A homogeneous garble (all dits or all dahs) must only snap to a homogeneous char of the SAME
        // element — never to a mixed char (stops "----" → Q: it can become O/0 but not a dit-letter).
        if exact == nil && !code.isEmpty
            && (code.allSatisfy { $0 == "." } || code.allSatisfy { $0 == "-" }) {
            let el = code.first!
            let homo = cands.filter { (ch, _) in
                CwDecoder.charToMorse[ch].map { $0.allSatisfy { $0 == el } } ?? false
            }
            if !homo.isEmpty { cands = homo }
        }
        var c: Character
        if let exact { c = exact }
        else if cands.isEmpty { c = "?" }
        else {
            var best = cands[0]
            var bestCost = Float.greatestFiniteMagnitude
            for cand in cands {
                let cost = Float(cand.1) * 6 + 1.5 * CwNgramModel.shared.cost(ctxP2, ctxP1, cand.0)
                if cost < bestCost { bestCost = cost; best = cand }
            }
            c = best.0
        }
        charSnr = charSnrCnt > 0 ? charSnrSum / Float(charSnrCnt) : 0
        charLevel = (charSnrCnt > 0 && threshOn > 0 && threshOn != .greatestFiniteMagnitude)
            ? (charESum / Float(charSnrCnt)) / threshOn : 0
        charSnrSum = 0; charSnrCnt = 0; charESum = 0
        onCharDecoded?(c, ci, code)
        ctxP2 = ctxP1; ctxP1 = c

        ditWins = unit; ditSeeded = true
        elemDurs.removeAll(); gapDurs.removeAll(); elemSnrs.removeAll()
    }

    func trackPeak(spec: [Float], cwBinMin: Int, cwBinMax: Int, driftRadius: Int) -> Bool {
        var bestBin = freqBin
        var bestPow = spec[freqBin]
        let lo = max(freqBin - driftRadius, cwBinMin)
        let hi = min(freqBin + driftRadius, cwBinMax)
        for b in lo...hi {
            if spec[b] > bestPow { bestPow = spec[b]; bestBin = b }
        }
        if bestBin == freqBin { return false }
        freqBin = bestBin
        return true
    }

    var shouldDeactivate: Bool {
        framesNoRealElement > deactThreshLocal
    }
}
