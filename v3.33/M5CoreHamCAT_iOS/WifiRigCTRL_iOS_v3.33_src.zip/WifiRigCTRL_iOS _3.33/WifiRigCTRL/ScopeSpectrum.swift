import Foundation
import Observation

/// Turns the received-audio PCM (Int16 chunks from AudioRxService) into a 256-bin spectrum for the band
/// scope's "WF" histogram — an RTTY-style real-time audio spectrum of the receiver's passband. Entirely
/// client-side (no Pi change). 512-pt radix-2 FFT, 50% overlap, slow noise/peak auto-range, and a
/// zoomable [loHz, hiHz] window so a narrow CW signal fills the display width.
@Observable
final class ScopeSpectrum {
    /// 256 normalized bins (0...255), updated on the main actor. Rendered by the Canvas.
    private(set) var bins: [Int] = Array(repeating: 0, count: 256)

    @ObservationIgnored private let n = 512
    @ObservationIgnored private lazy var buf = [Float](repeating: 0, count: n)
    @ObservationIgnored private var filled = 0
    @ObservationIgnored private lazy var re = [Float](repeating: 0, count: n)
    @ObservationIgnored private lazy var im = [Float](repeating: 0, count: n)
    @ObservationIgnored private lazy var hann: [Float] = (0..<n).map {
        Float(0.5 - 0.5 * cos(2.0 * Double.pi * Double($0) / Double(n - 1)))
    }
    @ObservationIgnored private var sampleRate: Double = 8000
    @ObservationIgnored private var loHz: Double = 0
    @ObservationIgnored private var hiHz: Double = 3000
    @ObservationIgnored private var noiseEst: Double = 1e-6
    @ObservationIgnored private var peakEst: Double = 1e-3
    @ObservationIgnored private var out = [Int](repeating: 0, count: 256)

    func setSampleRate(_ r: Int) { if r > 0 { sampleRate = Double(r) } }

    func setRange(_ lo: Double, _ hi: Double) {
        if hi > lo + 50 { loHz = max(0, lo); hiHz = hi }
    }

    func reset() {
        filled = 0; noiseEst = 1e-6; peakEst = 1e-3
        bins = Array(repeating: 0, count: 256)
    }

    /// Called on the audio thread with each Int16 chunk.
    func feed(_ samples: [Int16]) {
        var i = 0
        let half = n / 2
        while i < samples.count {
            let take = min(n - filled, samples.count - i)
            for k in 0..<take { buf[filled + k] = Float(samples[i + k]) / 32768.0 }
            filled += take; i += take
            if filled >= n {
                computeLine()
                for k in 0..<half { buf[k] = buf[k + half] }   // 50% overlap
                filled = half
            }
        }
    }

    private func computeLine() {
        for k in 0..<n { re[k] = buf[k] * hann[k]; im[k] = 0 }
        fft(&re, &im)
        let half = n / 2
        let nyq = sampleRate / 2.0
        var mags = [Double](repeating: 0, count: 256)
        var sum = 0.0, mx = 0.0
        for k in 0..<256 {
            let hz = loHz + (hiHz - loHz) * Double(k) / 255.0
            let b = min(max(Int(hz / nyq * Double(half)), 0), half - 1)
            let m = sqrt(Double(re[b] * re[b] + im[b] * im[b]))
            mags[k] = m; sum += m; if m > mx { mx = m }
        }
        let avg = sum / 256.0
        noiseEst = noiseEst * 0.98 + avg * 0.02
        peakEst = mx > peakEst ? peakEst * 0.5 + mx * 0.5 : peakEst * 0.997 + mx * 0.003
        let range = max(peakEst - noiseEst, 1e-9)
        for k in 0..<256 {
            let v = min(max((mags[k] - noiseEst) / range, 0), 1)
            out[k] = Int(v * 255.0)
        }
        let snapshot = out
        Task { @MainActor in self.bins = snapshot }
    }

    // In-place iterative radix-2 Cooley-Tukey FFT.
    private func fft(_ re: inout [Float], _ im: inout [Float]) {
        let size = re.count
        var j = 0
        for i in 1..<size {
            var bit = size >> 1
            while (j & bit) != 0 { j ^= bit; bit >>= 1 }
            j ^= bit
            if i < j { re.swapAt(i, j); im.swapAt(i, j) }
        }
        var len = 2
        while len <= size {
            let half = len >> 1
            let ang = -Double.pi / Double(half)
            let wRe = Float(cos(ang)), wIm = Float(sin(ang))
            var i = 0
            while i < size {
                var cRe: Float = 1, cIm: Float = 0
                for k in 0..<half {
                    let uRe = re[i + k], uIm = im[i + k]
                    let vRe = re[i + k + half] * cRe - im[i + k + half] * cIm
                    let vIm = re[i + k + half] * cIm + im[i + k + half] * cRe
                    re[i + k] = uRe + vRe; im[i + k] = uIm + vIm
                    re[i + k + half] = uRe - vRe; im[i + k + half] = uIm - vIm
                    let nc = cRe * wRe - cIm * wIm
                    cIm = cRe * wIm + cIm * wRe; cRe = nc
                }
                i += len
            }
            len <<= 1
        }
    }
}
