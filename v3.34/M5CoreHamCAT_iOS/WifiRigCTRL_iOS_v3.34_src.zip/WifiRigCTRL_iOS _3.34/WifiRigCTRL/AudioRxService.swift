import Foundation
import AVFoundation

/// Streaming PCM-16 LE mono playback over HTTP. Mirrors Android AudioStreamService.
/// URL: GET http://<host>:<audioPort>/radio/audio?rate=<sampleRate>
///
/// Also owns the shared AVAudioEngine so that CwBleService's sidetone source node
/// can be attached here. One shared engine eliminates all hardware output contention
/// between radio RX audio and sidetone that occurs with two separate AVAudioEngine
/// instances.
@MainActor
final class AudioRxService: NSObject {
    private let engine = AVAudioEngine()
    private let player = AVAudioPlayerNode()
    private var format: AVAudioFormat?
    private(set) var sampleRate: Int = 8000
    private var apiKey: String = ""
    private var url: URL?
    private var streamTask: Task<Void, Never>?
    private(set) var isRunning: Bool = false

    // Bounded-latency playback: frames scheduled to the player node but not yet played. The Pi streams
    // a hair faster than the phone plays (clock drift), so scheduled buffers pile up and latency grows
    // unbounded over minutes. When the backlog exceeds ~330 ms we DROP the incoming playback buffer so
    // audio stays near real-time (decoder feed via onSamples is unaffected — it is fed separately).
    private let qLock = NSLock()
    private var queuedFrames: Int = 0

    /// Called on the MainActor with each 1024-sample chunk (Int16 LE) as it arrives.
    var onSamples: (([Int16]) -> Void)?

    /// Called on the MainActor when the engine or stream encounters a non-retryable error.
    var onError: ((String) -> Void)?

    // ── CW decode NR (ローカル, Android AudioStreamService と同方式) ──────────────
    // NR ON時: CWピッチ中心の狭帯域BPF(3×90=実効~55Hz)をデコーダ入力と再生の両方に掛け、混信を除去して
    // 復号率を上げる。中心(cwNrCenterHz)はNRを入れた瞬間のピッチに固定。再生のみゆるいAGCで信号を強調
    // (滑らかゲイン=カリカリ無し)。Pi側はafftdnを使わない広帯域のままなので音切れしない。
    var cwNrEnabled = false
    var cwNrCenterHz = 700
    private let nr = NrFilter(stages: 3, bw: 90.0)
    private var agcEnv: Double = 0
    private var agcGain: Double = 1
    private let agcTarget = 16000.0
    private let agcMaxGain = 18.0
    private let agcRelease = 0.99985
    private let agcGainSlew = 0.02

    func start(host: String, port: Int, sampleRate: Int, apiKey: String) async {
        await stop()
        self.sampleRate = sampleRate
        self.apiKey = apiKey
        guard sampleRate > 0 else { return }
        let urlStr = "http://\(host):\(port)/radio/audio?rate=\(sampleRate)"
        guard let u = URL(string: urlStr) else { return }
        self.url = u
        isRunning = true
        await prepareSession()
        configureEngine()

        let capturedURL = u
        let capturedKey = apiKey
        streamTask = Task.detached(priority: .userInitiated) { [weak self] in
            await self?.runStream(url: capturedURL, apiKey: capturedKey)
        }
    }

    func stop() async {
        isRunning = false
        streamTask?.cancel()
        streamTask = nil
        if let obs = engineConfigObserver {
            NotificationCenter.default.removeObserver(obs)
            engineConfigObserver = nil
        }
        if player.isPlaying { player.stop() }
        if sharedSidetoneNode == nil, engine.isRunning { engine.stop() }
        resetQueuedFrames()   // reset backlog count across restarts
    }

    /// Sync helper (NSLock is unavailable directly from async contexts like stop()).
    private func resetQueuedFrames() {
        qLock.lock(); queuedFrames = 0; qLock.unlock()
    }

    // MARK: - Shared engine (sidetone integration)

    var isEngineRunning: Bool { engine.isRunning }

    private var sharedSidetoneNode: AVAudioSourceNode?
    private var sidetoneFormat: AVAudioFormat?

    /// Attach a sidetone AVAudioSourceNode to this engine's graph.
    /// Called by CwBleService.startSidetone() so both sidetone and radio RX share
    /// one AVAudioEngine, which eliminates hardware output contention on iOS.
    func startSidetoneIn(_ src: AVAudioSourceNode, format: AVAudioFormat) {
        if let old = sharedSidetoneNode { engine.detach(old) }
        sharedSidetoneNode = src
        sidetoneFormat = format

        activateSessionAsync()
        ensurePlayerAttached()
        engine.attach(src)
        engine.connect(src, to: engine.mainMixerNode, format: format)

        if !engine.isRunning {
            do { try engine.start() }
            catch { print("[AudioRx] engine.start (sidetone) failed: \(error)") }
        }
        registerConfigObserver()
    }

    func stopSidetoneIn(_ src: AVAudioSourceNode) {
        engine.detach(src)
        if sharedSidetoneNode === src {
            sharedSidetoneNode = nil
            sidetoneFormat = nil
        }
        if !isRunning, engine.isRunning { engine.stop() }
    }

    private func reconnectSidetoneIfNeeded() {
        guard let node = sharedSidetoneNode, let fmt = sidetoneFormat else { return }
        engine.connect(node, to: engine.mainMixerNode, format: fmt)
    }

    // MARK: - Private helpers

    private var playerAttached: Bool = false
    private var engineConfigObserver: NSObjectProtocol?

    /// Serial queue for AVAudioSession work.
    ///
    /// `AVAudioSession.setActive` can block for a long time, and iOS logs an explicit
    /// "Hang Risk" fault when it is called from the main thread. Doing it inline on the
    /// MainActor froze the entire app for minutes while audio was being restarted: the
    /// console went completely silent between that fault and the next line.
    private static let sessionQueue = DispatchQueue(label: "audiorx.session",
                                                    qos: .userInitiated)

    /// Category plus activation. Must not run on the main thread.
    private nonisolated static func configureSession(skipSetActive: Bool) {
        let sess = AVAudioSession.sharedInstance()
        // Don't downgrade .playAndRecord to .playback — CI-V or AudioTxService may own the mic.
        // .playAndRecord already allows speaker output, so sidetone still works in that mode.
        if sess.category != .playAndRecord {
            try? sess.setCategory(.playback, mode: .default, options: [.mixWithOthers])
        }
        // Skip setActive when the engine is already running: the session is already active.
        guard !skipSetActive else { return }
        try? sess.setActive(true, options: [])
    }

    /// Wait for the session to be ready without blocking the main thread: `await` suspends
    /// this task rather than holding the thread, so the UI keeps running meanwhile.
    private func prepareSession() async {
        let skip = engine.isRunning
        await withCheckedContinuation { (cont: CheckedContinuation<Void, Never>) in
            Self.sessionQueue.async {
                Self.configureSession(skipSetActive: skip)
                cont.resume()
            }
        }
    }

    /// Fire-and-forget variant for the synchronous call sites. The engine is started right
    /// afterwards; if the session is not active yet, starting the engine activates it, and
    /// the configuration-change observer retries on failure.
    private func activateSessionAsync() {
        let skip = engine.isRunning
        Self.sessionQueue.async { Self.configureSession(skipSetActive: skip) }
    }

    private func ensurePlayerAttached() {
        guard !playerAttached else { return }
        engine.attach(player)
        playerAttached = true
    }

    /// Builds the graph and starts the engine. The caller is responsible for having the
    /// audio session ready (see `prepareSession`), so that no session call happens here on
    /// the main thread.
    private func configureEngine() {
        ensurePlayerAttached()

        guard let fmt = AVAudioFormat(commonFormat: .pcmFormatFloat32,
                                     sampleRate: Double(sampleRate),
                                     channels: 1,
                                     interleaved: false) else { return }
        self.format = fmt
        engine.connect(player, to: engine.mainMixerNode, format: fmt)

        do {
            if !engine.isRunning { try engine.start() }
            // NOTE: player.play() is NOT called here.
            // It is deferred until the first audio buffer is queued, which eliminates
            // the 2-3 second window of silence the old approach had (play() was called
            // immediately, then URLSession's ~32 KB internal buffer filled before
            // delivering the first data chunk).
            print("[AudioRx] engine ready @ \(sampleRate) Hz (player not yet playing)")
        } catch {
            let msg = "Audio engine start failed: \(error.localizedDescription)"
            print("[AudioRx] \(msg)")
            onError?(msg)
        }

        registerConfigObserver()
    }

    private func registerConfigObserver() {
        if let obs = engineConfigObserver {
            NotificationCenter.default.removeObserver(obs)
        }
        engineConfigObserver = NotificationCenter.default.addObserver(
            forName: .AVAudioEngineConfigurationChange,
            object: engine,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self else { return }
                try? await Task.sleep(nanoseconds: 150_000_000)
                guard !self.engine.isRunning else { return }
                if self.isRunning {
                    await self.prepareSession()
                    self.configureEngine()
                    // configureEngine() re-connects the player but not the sidetone node.
                    self.reconnectSidetoneIfNeeded()
                } else if self.sharedSidetoneNode != nil {
                    await self.prepareSession()
                    self.reconnectSidetoneIfNeeded()
                    do { try self.engine.start() }
                    catch { print("[AudioRx] engine restart (sidetone) failed: \(error)") }
                }
            }
        }
    }

    private func scheduleSamples(_ data: Data) {
        guard let fmt = format else { return }
        let frameCount = AVAudioFrameCount(data.count / 2)
        guard frameCount > 0,
              let buffer = AVAudioPCMBuffer(pcmFormat: fmt, frameCapacity: frameCount),
              let ch = buffer.floatChannelData else { return }
        buffer.frameLength = frameCount
        // Drop this playback buffer if the player node is already backed up beyond the latency cap
        // (~330 ms). Keeps received audio near real-time instead of drifting seconds behind over time.
        let maxQueued = sampleRate / 3
        qLock.lock(); let backed = queuedFrames; qLock.unlock()
        if backed > maxQueued { return }
        data.withUnsafeBytes { raw in
            guard let src = raw.baseAddress?.assumingMemoryBound(to: Int16.self) else { return }
            let dst = ch[0]
            // SPK 受信音を約2倍に増幅(音が小さい対策)。クリップ防止で ±1.0 にクランプ。
            let gain: Float = 2.0
            for i in 0..<Int(frameCount) {
                var v = Float(src[i]) / 32768.0 * gain
                if v > 1.0 { v = 1.0 } else if v < -1.0 { v = -1.0 }
                dst[i] = v
            }
        }
        let fc = Int(frameCount)
        qLock.lock(); queuedFrames += fc; qLock.unlock()
        player.scheduleBuffer(buffer, completionHandler: { [weak self] in
            guard let self else { return }
            self.qLock.lock(); self.queuedFrames -= fc; self.qLock.unlock()
        })
    }

    /// Apply the CW-decode narrow NR (shared by decoder feed and playback) in place. Fixed centre.
    func applyCwNr(_ s: inout [Int16]) {
        guard cwNrEnabled else { return }
        nr.process(&s, centerHz: cwNrCenterHz, fs: sampleRate)
    }

    /// Schedule already-filtered Int16 samples for playback with a gentle AGC (signal emphasis). The AGC
    /// gain is slewed (smooth) so there are no per-element clicks ("カリカリ"). Playback only (decoder feed
    /// is fed separately with the pre-AGC filtered samples).
    func schedulePlaybackAgc(_ samples: [Int16]) {
        guard let fmt = format else { return }
        let frameCount = AVAudioFrameCount(samples.count)
        guard frameCount > 0,
              let buffer = AVAudioPCMBuffer(pcmFormat: fmt, frameCapacity: frameCount),
              let ch = buffer.floatChannelData else { return }
        buffer.frameLength = frameCount
        let maxQueued = sampleRate / 3
        qLock.lock(); let backed = queuedFrames; qLock.unlock()
        if backed > maxQueued { return }
        let dst = ch[0]
        for i in 0..<Int(frameCount) {
            let s = Double(samples[i])
            let a = abs(s)
            if a > agcEnv { agcEnv = a } else { agcEnv *= agcRelease }
            let tg = agcEnv > 1.0 ? min(agcMaxGain, agcTarget / agcEnv) : agcMaxGain
            agcGain += (tg - agcGain) * agcGainSlew
            var v = Float(s * agcGain) / 32768.0
            if v > 1.0 { v = 1.0 } else if v < -1.0 { v = -1.0 }
            dst[i] = v
        }
        let fc = Int(frameCount)
        qLock.lock(); queuedFrames += fc; qLock.unlock()
        player.scheduleBuffer(buffer, completionHandler: { [weak self] in
            guard let self else { return }
            self.qLock.lock(); self.queuedFrames -= fc; self.qLock.unlock()
        })
    }
}

// MARK: - CW NR biquad bandpass (local, mirrors Android)

/// RBJ bandpass biquad (0 dB peak gain), transposed direct-form II.
private final class Biquad {
    private var b0 = 1.0, b1 = 0.0, b2 = 0.0, a1 = 0.0, a2 = 0.0
    private var z1 = 0.0, z2 = 0.0
    func setBandpass(_ f0: Double, _ bw: Double, _ fs: Double) {
        let w0 = 2.0 * Double.pi * f0 / fs
        let q = f0 / bw
        let alpha = sin(w0) / (2.0 * q)
        let cosw = cos(w0)
        let a0 = 1.0 + alpha
        b0 = alpha / a0; b1 = 0.0; b2 = -alpha / a0
        a1 = (-2.0 * cosw) / a0; a2 = (1.0 - alpha) / a0
    }
    func process(_ x: Double) -> Double {
        let y = b0 * x + z1
        z1 = b1 * x - a1 * y + z2
        z2 = b2 * x - a2 * y
        return y
    }
}

/// Cascaded RBJ-bandpass with lazy coeff recompute on centre/rate change. Keeps its own state.
final class NrFilter {
    private let bqs: [Biquad]
    private let bw: Double
    private var lastC = -1, lastR = -1
    init(stages: Int, bw: Double) { self.bw = bw; bqs = (0..<stages).map { _ in Biquad() } }
    func process(_ s: inout [Int16], centerHz: Int, fs: Int) {
        if fs <= 0 { return }
        let c = max(250, min(1500, centerHz))
        if c != lastC || fs != lastR {
            for b in bqs { b.setBandpass(Double(c), bw, Double(fs)) }
            lastC = c; lastR = fs
        }
        for i in 0..<s.count {
            var y = Double(s[i])
            for b in bqs { y = b.process(y) }
            var v = Int(y)
            if v > 32767 { v = 32767 } else if v < -32768 { v = -32768 }
            s[i] = Int16(v)
        }
    }
}

// MARK: - Async stream loop (runs on background thread via Task.detached)

extension AudioRxService {

    nonisolated private func runStream(url: URL, apiKey: String) async {
        let chunkBytes = 1024 * 2     // 2048 bytes = 1024 samples = 128 ms at 8 kHz
        let prebufTarget = chunkBytes // queue one full chunk before starting player

        var attempt = 0
        // Consecutive attempts that produced no audio. Logged on every failure and
        // surfaced to the UI once after `failureReportThreshold`, so a silent retry
        // loop (HTTP 503 from the Pi, unresolvable host, ...) is visible to the user.
        var consecutiveFailures = 0
        let failureReportThreshold = 3
        // Back off on repeated failure instead of retrying at a fixed fast interval. Every
        // attempt costs the Pi real work — it stops its capture process, kills arecord and
        // respawns ffmpeg — so a steady stream of retries keeps a Pi Zero busy enough that
        // unrelated requests, including /radio/status on the other port, start timing out.
        let minBackoffNs: UInt64 =   500_000_000
        let maxBackoffNs: UInt64 = 8_000_000_000
        var backoffNs = minBackoffNs
        // A stream that was delivering audio and then ended cleanly is almost always a
        // TX-induced drop (CW/SSB keyed the rig, the Pi capture briefly stalled). Reconnect
        // with NO backoff so the ~1 s gap on TX→RX return disappears; the backoff only
        // matters for genuine failures (no data), handled by noteFailure below.
        var reconnectImmediately = false
        func noteFailure(_ detail: String) async {
            consecutiveFailures += 1
            print("[AudioRx] attempt \(attempt) failed: \(detail)")
            guard consecutiveFailures == failureReportThreshold else { return }
            await MainActor.run { [weak self] in
                guard let self, self.isRunning else { return }
                self.onError?("RX audio: \(detail)")
            }
        }

        print("[AudioRx] stream url=\(url.absoluteString)")
        while !Task.isCancelled {
            if attempt > 0 && !reconnectImmediately {
                try? await Task.sleep(nanoseconds: backoffNs)
                backoffNs = min(backoffNs * 2, maxBackoffNs)
            }
            reconnectImmediately = false
            guard !Task.isCancelled else { return }
            attempt += 1

            do {
                let cfg = URLSessionConfiguration.ephemeral
                cfg.timeoutIntervalForRequest = 0
                cfg.timeoutIntervalForResource = 0
                let sess = URLSession(configuration: cfg)
                defer { sess.invalidateAndCancel() }

                var req = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData,
                                     timeoutInterval: 0)
                if !apiKey.isEmpty { req.setValue(apiKey, forHTTPHeaderField: "X-API-Key") }

                // URLSession.bytes() delivers data as it arrives from the network,
                // unlike the old data delegate which buffered ~32 KB (~2 s at 8 kHz)
                // before the first delivery.
                let (bytes, resp) = try await sess.bytes(for: req)
                guard !Task.isCancelled else { return }
                if let http = resp as? HTTPURLResponse, http.statusCode >= 400 {
                    // The Pi puts the ffmpeg/arecord reason in the 503 body — keep it.
                    var body = Data()
                    for try await byte in bytes {
                        body.append(byte)
                        if body.count >= 512 { break }
                    }
                    let text = String(data: body, encoding: .utf8)?
                        .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
                    await noteFailure("HTTP \(http.statusCode) \(text)")
                    continue
                }

                var pending = Data()
                var playerStarted = false
                var receivedAny = false

                for try await byte in bytes {
                    guard !Task.isCancelled else { return }
                    pending.append(byte)

                    guard pending.count >= chunkBytes else { continue }

                    if !receivedAny {
                        receivedAny = true
                        consecutiveFailures = 0
                        backoffNs = minBackoffNs   // the stream works; retry fast again
                        print("[AudioRx] first chunk received (attempt \(attempt))")
                    }

                    let slice = Data(pending.prefix(chunkBytes))
                    pending.removeFirst(chunkBytes)
                    let shouldStart = !playerStarted && pending.count < prebufTarget
                    playerStarted = true

                    await MainActor.run { [weak self] in
                        guard let self, self.isRunning else { return }
                        if self.cwNrEnabled {
                            // NR on: narrow-filter once (fixed centre), feed the SAME filtered samples to the
                            // decoder and to playback (+AGC). Mirrors Android's single shared-filter path.
                            var samples = slice.withUnsafeBytes { raw -> [Int16] in
                                guard let base = raw.baseAddress?
                                    .assumingMemoryBound(to: Int16.self) else { return [] }
                                return Array(UnsafeBufferPointer(start: base, count: slice.count / 2))
                            }
                            self.applyCwNr(&samples)
                            self.onSamples?(samples)
                            self.schedulePlaybackAgc(samples)
                        } else {
                            self.scheduleSamples(slice)
                            if let cb = self.onSamples {
                                let samples = slice.withUnsafeBytes { raw -> [Int16] in
                                    guard let base = raw.baseAddress?
                                        .assumingMemoryBound(to: Int16.self) else { return [] }
                                    return Array(UnsafeBufferPointer(start: base,
                                                                      count: slice.count / 2))
                                }
                                cb(samples)
                            }
                        }
                        if shouldStart, !self.player.isPlaying {
                            self.player.play()
                            print("[AudioRx] player.play() — first audio queued")
                        }
                    }
                }
                // Stream ended cleanly — retry immediately
                if receivedAny {
                    print("[AudioRx] stream ended after data — reconnecting immediately")
                    reconnectImmediately = true   // TX-induced drop: no backoff, close the gap
                } else {
                    await noteFailure("connected but stream ended with no audio")
                }
            } catch is CancellationError {
                return
            } catch {
                // Network/timeout error — retry after delay at top of loop
                await noteFailure(error.localizedDescription)
            }
        }
    }
}
