package com.ji1ore.wifi_rig_ctrl

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/**
 * Real-time audio spectrum "histogram" for the band-scope WF toggle: X = audio frequency 0–3000 Hz,
 * Y = power. Shows only the CURRENT frame as a filled curve (not a scrolling waterfall), with a slowly
 * decaying peak-hold line. Fed normalized 0–255 bins from [AudioWaterfallTap].
 */
class AudioSpectrumView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private val nBins = 256
    private var loHz = 0.0                     // displayed audio-frequency window (zoom to RX passband)
    private var hiHz = 3000.0
    private val disp = FloatArray(nBins)      // smoothed display value 0..1
    private val peak = FloatArray(nBins)      // peak-hold 0..1

    private val dp = context.resources.displayMetrics.density
    private val sp = context.resources.displayMetrics.scaledDensity

    private val fillPaint = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL }
    private val linePaint = Paint().apply {
        isAntiAlias = true; style = Paint.Style.STROKE; strokeWidth = dp * 1.2f; color = 0xFF00E5FF.toInt()
    }
    private val peakPaint = Paint().apply {
        isAntiAlias = true; style = Paint.Style.STROKE; strokeWidth = dp; color = 0xFFFF4081.toInt()
    }
    private val gridPaint = Paint().apply { isAntiAlias = false; strokeWidth = dp * 0.5f; color = 0x33FFFFFF }
    private val txtPaint  = Paint().apply { isAntiAlias = true; textSize = sp * 9f; color = 0x88FFFFFF.toInt() }
    private val refPaint  = Paint().apply { isAntiAlias = true; strokeWidth = dp * 1.5f; color = 0xFFFFD600.toInt() }
    private val path = Path()
    private var grad: LinearGradient? = null

    /** Reference (target) audio pitch line, in Hz. Tapping moves the tapped signal to this line. */
    var referenceHz: Double = 700.0
        set(v) { field = v; invalidate() }

    /** Zoom the X axis to the RX passband so a narrow signal fills the width (easier to tap). */
    fun setRange(lo: Double, hi: Double) {
        if (hi > lo + 50) { loHz = lo.coerceAtLeast(0.0); hiHz = hi; invalidate() }
    }

    /** Tapped audio frequency (Hz). The fragment turns this into an RF QSY. */
    var onFreqSelected: ((Double) -> Unit)? = null

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_DOWN && e.action != MotionEvent.ACTION_UP) return false
        if (e.action == MotionEvent.ACTION_UP && width > 0) {
            val hz = (loHz + e.x / width * (hiHz - loHz)).coerceIn(loHz, hiHz)
            onFreqSelected?.invoke(hz)
        }
        return true
    }

    /** Submit a new 256-bin frame (values 0..255). Call on the UI thread. */
    fun submit(src: IntArray) {
        val n = minOf(nBins, src.size)
        for (i in 0 until n) {
            val v = (src[i] / 255f).coerceIn(0f, 1f)
            disp[i] = disp[i] * 0.4f + v * 0.6f                 // light temporal smoothing
            peak[i] = if (v > peak[i]) v else (peak[i] - 0.012f).coerceAtLeast(0f)  // slow decay
        }
        invalidate()
    }

    fun clear() {
        disp.fill(0f); peak.fill(0f); invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldW: Int, oldH: Int) {
        super.onSizeChanged(w, h, oldW, oldH)
        grad = LinearGradient(0f, h.toFloat(), 0f, 0f,
            intArrayOf(0x3300E5FF, 0xAA00E5FF.toInt(), 0xFF00FF88.toInt()),
            floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
        fillPaint.shader = grad
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        canvas.drawColor(0xFF001015.toInt())

        // frequency gridlines across the current window; step adapts to the span
        val span = hiHz - loHz
        val step = when { span <= 800 -> 100.0; span <= 2000 -> 250.0; else -> 500.0 }
        var f = Math.ceil(loHz / step) * step
        while (f <= hiHz) {
            val x = ((f - loHz) / span * w).toFloat()
            canvas.drawLine(x, 0f, x, h, gridPaint)
            val lbl = if (f >= 1000) "%.1fk".format(f / 1000.0) else "${f.toInt()}"
            canvas.drawText(lbl, x - sp * 8, h - dp * 2, txtPaint)
            f += step
        }

        // filled spectrum curve
        path.reset(); path.moveTo(0f, h)
        for (i in 0 until nBins) {
            val x = i.toFloat() / (nBins - 1) * w
            val y = h - disp[i] * h
            path.lineTo(x, y)
        }
        path.lineTo(w, h); path.close()
        canvas.drawPath(path, fillPaint)

        // outline
        path.reset()
        for (i in 0 until nBins) {
            val x = i.toFloat() / (nBins - 1) * w
            val y = h - disp[i] * h
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        canvas.drawPath(path, linePaint)

        // peak-hold line
        path.reset()
        for (i in 0 until nBins) {
            val x = i.toFloat() / (nBins - 1) * w
            val y = h - peak[i] * h
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        canvas.drawPath(path, peakPaint)

        // reference pitch line (tap moves the signal here)
        val rx = ((referenceHz - loHz) / (hiHz - loHz) * w).toFloat()
        canvas.drawLine(rx, 0f, rx, h, refPaint)
        canvas.drawText("${referenceHz.toInt()}Hz", rx + dp * 2, sp * 10, txtPaint.apply { color = 0xFFFFD600.toInt() })
        txtPaint.color = 0x88FFFFFF.toInt()
    }
}
