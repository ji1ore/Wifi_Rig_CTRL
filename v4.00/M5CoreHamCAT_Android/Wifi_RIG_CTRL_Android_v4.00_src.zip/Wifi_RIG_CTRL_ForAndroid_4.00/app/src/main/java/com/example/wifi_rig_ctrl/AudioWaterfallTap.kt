package com.ji1ore.wifi_rig_ctrl

import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Turns the received-audio PCM stream (ShortArray chunks from AudioStreamService) into 256-bin spectrum
 * lines for a [WaterfallView], so CW/SSB operators get an RTTY-style real-time audio waterfall of the
 * receiver's passband (narrow when the rig's IF filter is narrowed). Entirely client-side — no Pi change.
 *
 * 512-pt radix-2 FFT with 50% overlap → a line every 256 input samples (~32 ms at 8 kHz). Output is
 * auto-ranged (slow noise/peak envelope, like RttyWaterfallView) so contrast is good at any signal level.
 * `onBins` is invoked on the FEEDING thread (the audio stream thread); the caller must marshal to the UI
 * thread before touching the view.
 */
class AudioWaterfallTap(private val onBins: (IntArray) -> Unit) {

    private val n = 512
    private val half = n / 2
    private val buf = FloatArray(n)
    private var filled = 0
    private val re = FloatArray(n)
    private val im = FloatArray(n)
    private val hann = FloatArray(n) { (0.5 - 0.5 * cos(2.0 * Math.PI * it / (n - 1))).toFloat() }
    private val out = IntArray(256)

    @Volatile private var sampleRate = 8000
    @Volatile private var loHz = 0.0
    @Volatile private var hiHz = 3000.0
    private var noiseEst = 1e-6
    private var peakEst = 1e-3

    fun setSampleRate(r: Int) { if (r > 0) sampleRate = r }

    /** Audio frequency window the 256 output bins span (zoom to the RX passband for easier tapping). */
    fun setRange(lo: Double, hi: Double) {
        if (hi > lo + 50) { loHz = lo.coerceAtLeast(0.0); hiHz = hi }
    }

    fun reset() {
        filled = 0; noiseEst = 1e-6; peakEst = 1e-3
    }

    fun feed(samples: ShortArray) {
        var i = 0
        while (i < samples.size) {
            val take = minOf(n - filled, samples.size - i)
            for (k in 0 until take) buf[filled + k] = samples[i + k] / 32768f
            filled += take; i += take
            if (filled >= n) {
                computeLine()
                // 50% overlap: keep the newest half for the next frame
                System.arraycopy(buf, half, buf, 0, half)
                filled = half
            }
        }
    }

    private fun computeLine() {
        for (k in 0 until n) { re[k] = buf[k] * hann[k]; im[k] = 0f }
        fft(re, im)

        val nyq = sampleRate / 2.0
        val mags = DoubleArray(256)
        var sum = 0.0; var mx = 0.0
        for (k in 0 until 256) {
            val hz = loHz + (hiHz - loHz) * k / 255.0        // output bins span [loHz, hiHz]
            val b = (hz / nyq * half).toInt().coerceIn(0, half - 1)
            val m = sqrt((re[b] * re[b] + im[b] * im[b]).toDouble())
            mags[k] = m; sum += m; if (m > mx) mx = m
        }
        // Slow noise/peak envelope for auto-contrast (fast-attack peak, slow decay).
        val avg = sum / 256.0
        noiseEst = noiseEst * 0.98 + avg * 0.02
        peakEst = if (mx > peakEst) peakEst * 0.5 + mx * 0.5 else peakEst * 0.997 + mx * 0.003
        val range = (peakEst - noiseEst).coerceAtLeast(1e-9)
        for (k in 0 until 256) {
            val v = ((mags[k] - noiseEst) / range).coerceIn(0.0, 1.0)
            out[k] = (v * 255.0).toInt()
        }
        onBins(out.copyOf())
    }

    // In-place iterative radix-2 Cooley-Tukey FFT.
    private fun fft(re: FloatArray, im: FloatArray) {
        val size = re.size
        var j = 0
        for (i in 1 until size) {
            var bit = size shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j or bit
            if (i < j) { val tr = re[i]; re[i] = re[j]; re[j] = tr; val ti = im[i]; im[i] = im[j]; im[j] = ti }
        }
        var len = 2
        while (len <= size) {
            val halfLen = len shr 1
            val ang = -Math.PI / halfLen
            val wRe = cos(ang).toFloat(); val wIm = sin(ang).toFloat()
            var i = 0
            while (i < size) {
                var cRe = 1f; var cIm = 0f
                for (k in 0 until halfLen) {
                    val uRe = re[i + k]; val uIm = im[i + k]
                    val vRe = re[i + k + halfLen] * cRe - im[i + k + halfLen] * cIm
                    val vIm = re[i + k + halfLen] * cIm + im[i + k + halfLen] * cRe
                    re[i + k] = uRe + vRe; im[i + k] = uIm + vIm
                    re[i + k + halfLen] = uRe - vRe; im[i + k + halfLen] = uIm - vIm
                    val nc = cRe * wRe - cIm * wIm
                    cIm = cRe * wIm + cIm * wRe
                    cRe = nc
                }
                i += len
            }
            len = len shl 1
        }
    }
}
