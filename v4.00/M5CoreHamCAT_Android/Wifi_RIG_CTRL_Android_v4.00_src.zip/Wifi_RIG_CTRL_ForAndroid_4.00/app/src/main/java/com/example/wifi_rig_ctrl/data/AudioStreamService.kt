package com.ji1ore.wifi_rig_ctrl.data

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit

class AudioStreamService {

    private var streamJob: Job? = null
    private var audioTrack: AudioTrack? = null
    private var activeCall: Call? = null
    @Volatile private var currentVolume: Float = 0.5f
    @Volatile private var stopping = false
    @Volatile private var lastDataMs: Long = 0L

    // For CW decode: notify PCM16 samples in real time (called from IO thread)
    @Volatile var audioSampleListener: ((ShortArray) -> Unit)? = null

    // SPK 受信音のソフト増幅(AudioTrack.setVolume は最大1.0で増幅できないため)。約2倍。
    // クリップ防止で ±32767 にクランプ。スペクトラム等のリスナーには増幅前データを渡す。
    private val spkGain = 2.0f
    private fun applyGain(buf: ByteArray, n: Int) {
        if (spkGain == 1.0f) return
        var i = 0
        while (i + 1 < n) {
            val s = (buf[i].toInt() and 0xFF) or (buf[i + 1].toInt() shl 8)  // 16bit LE signed
            var v = (s * spkGain).toInt()
            if (v > 32767) v = 32767 else if (v < -32768) v = -32768
            buf[i] = v.toByte()
            buf[i + 1] = (v shr 8).toByte()
            i += 2
        }
    }

    // ── CW decode NR (CWピッチ中心の狭帯域BPF) ────────────────────────────────
    // CWデコード中の狭帯域NRをローカル適用する。混信の多いバンドで隣接局(数十Hz差)を除去し、デコーダの
    // FFTビンを綺麗にして復号率を上げる(実測: 生音は崩壊、3×90狭帯域で "CQ TEST DE ICOM" が復号できる)。
    // afftdnと違いCPUほぼゼロ=音切れしない。1系統のフィルタをデコーダ入力と再生の両方で共有する
    // (別系統+チャンク毎コピーは負荷で再生がもたつくため単一に戻した)。中心(cwNrCenterHz)はNRを入れた
    // 瞬間のCWピッチに固定(中心が飛ぶと音が乱れるため追従しない。再センタリングはNRを押し直す)。
    @Volatile var cwNrEnabled = false
    @Volatile var cwNrCenterHz = 700
    private val NR_STAGES = 3
    private val NR_BW = 90.0                // 各段の帯域幅[Hz]。3段カスケードで実効~55Hz
    private val nr = NrFilter(NR_STAGES, NR_BW)

    /** Cascaded RBJ-bandpass filter with lazy coeff recompute on centre/rate change. Keeps its own state. */
    private class NrFilter(stages: Int, private val bw: Double) {
        private val bqs = Array(stages) { Biquad() }
        private var lastC = -1; private var lastR = -1
        fun process(buf: ByteArray, n: Int, centerHz: Int, fs: Int) {
            if (fs <= 0) return
            val c = centerHz.coerceIn(250, 1500)
            if (c != lastC || fs != lastR) {
                for (b in bqs) b.setBandpass(c.toDouble(), bw, fs.toDouble())
                lastC = c; lastR = fs
            }
            var i = 0
            while (i + 1 < n) {
                val s = ((buf[i].toInt() and 0xFF) or (buf[i + 1].toInt() shl 8)).toDouble()
                var y = s
                for (b in bqs) y = b.process(y)
                var v = y.toInt()
                if (v > 32767) v = 32767 else if (v < -32768) v = -32768
                buf[i] = v.toByte()
                buf[i + 1] = (v shr 8).toByte()
                i += 2
            }
        }
    }

    // 再生音のみのAGC(信号強調): 狭帯域NRで浮いた信号を強めに一定レベルへ持ち上げて聞きやすくする。
    // アタック即時(キーダウンで過大を防ぐ)・リリースは遅め(キーアップのギャップでゲインが跳ねて残留ノイズを
    // 持ち上げるポンピングを抑える)。デコーダ入力には掛けない(notifySamplesの後に適用)ので復号は不変。
    private var agcEnv = 0.0
    private var agcGain = 1.0           // 実際に掛ける平滑化済みゲイン
    private val AGC_TARGET = 16000.0    // 目標ピーク振幅(~ -6 dBFS)
    private val AGC_MAXGAIN = 18.0       // 弱い信号の持ち上げ上限
    private val AGC_RELEASE = 0.99985    // 包絡の減衰(16kで時定数~0.4s)。ギャップのポンピング抑制
    private val AGC_GAIN_SLEW = 0.02     // ゲインを目標へ徐々に(時定数~3ms)=急変クリック(カリカリ)を除去
    private fun applyPlaybackAgc(buf: ByteArray, n: Int) {
        var i = 0
        while (i + 1 < n) {
            val s = ((buf[i].toInt() and 0xFF) or (buf[i + 1].toInt() shl 8)).toDouble()
            val a = kotlin.math.abs(s)
            if (a > agcEnv) agcEnv = a else agcEnv *= AGC_RELEASE
            val tg = if (agcEnv > 1.0) kotlin.math.min(AGC_MAXGAIN, AGC_TARGET / agcEnv) else AGC_MAXGAIN
            agcGain += (tg - agcGain) * AGC_GAIN_SLEW   // ゲインを滑らかに追従(段差を作らない)
            var v = (s * agcGain).toInt()
            if (v > 32767) v = 32767 else if (v < -32768) v = -32768
            buf[i] = v.toByte()
            buf[i + 1] = (v shr 8).toByte()
            i += 2
        }
    }

    /** RBJ bandpass biquad (0 dB peak gain), transposed direct-form II. */
    private class Biquad {
        private var b0 = 1.0; private var b1 = 0.0; private var b2 = 0.0
        private var a1 = 0.0; private var a2 = 0.0
        private var z1 = 0.0; private var z2 = 0.0
        fun setBandpass(f0: Double, bw: Double, fs: Double) {
            val w0 = 2.0 * Math.PI * f0 / fs
            val q = f0 / bw
            val alpha = Math.sin(w0) / (2.0 * q)
            val cosw = Math.cos(w0)
            val a0 = 1.0 + alpha
            b0 = alpha / a0; b1 = 0.0; b2 = -alpha / a0
            a1 = (-2.0 * cosw) / a0; a2 = (1.0 - alpha) / a0
        }
        fun process(x: Double): Double {
            val y = b0 * x + z1
            z1 = b1 * x - a1 * y + z2
            z2 = b2 * x - a2 * y
            return y
        }
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.SECONDS)
        .build()

    // onError: not on UI thread, so caller should post to main thread
    fun start(url: String, vol: Float, apiKey: String = "", onError: ((String) -> Unit)? = null) {
        stop()
        stopping = false
        currentVolume = vol
        val sampleRate = extractSampleRate(url)
        _currentSampleRate = sampleRate

        streamJob = CoroutineScope(Dispatchers.IO).launch {
            var lastError: String? = null
            // 連続した接続失敗は MAX_RETRY で諦めるが、一度でも正常再生できたら attempt をリセットする
            // (下の streamed ブロック)。これにより「数分ごとに一瞬落ちる」ような定期ドロップでも、
            // 累積で MAX_RETRY に達して 6秒ウォッチドッグ待ちに陥ることなく、常に即(300ms)再接続する。
            var attempt = 0
            while (isActive && !stopping) {
                attempt++
                if (attempt > MAX_RETRY) break
                if (attempt > 1) {
                    Log.d("AudioStream", "retry $attempt/$MAX_RETRY after ${RETRY_DELAY_MS}ms")
                    delay(RETRY_DELAY_MS)
                    if (!isActive || stopping) break
                }
                val t0 = System.currentTimeMillis()
                var streamed = false
                try {
                    val reqBuilder = Request.Builder().url(url)
                    if (apiKey.isNotEmpty()) reqBuilder.addHeader("X-API-Key", apiKey)
                    val call = client.newCall(reqBuilder.build())
                    activeCall = call
                    call.execute().use { response ->
                        if (!response.isSuccessful) {
                            lastError = "Audio stream connect failed (${response.code})"
                            Log.e("AudioStream", "$lastError attempt=$attempt ${System.currentTimeMillis()-t0}ms")
                            return@use  // retry
                        }
                        Log.d("AudioStream", "connected ${System.currentTimeMillis()-t0}ms attempt=$attempt")

                        val minBuf = AudioTrack.getMinBufferSize(
                            sampleRate,
                            AudioFormat.CHANNEL_OUT_MONO,
                            AudioFormat.ENCODING_PCM_16BIT
                        )
                        // 低遅延優先: 小さめバッファ(~200ms相当)。リアルタイム再生・打鍵後ギャップ無し。
                        // クロックのズレによる「数分ごとの途切れ」はPi側(送出レート/リサンプル)で根本対策する。
                        val bufSize = maxOf(minBuf, 1024) * 2

                        val track = AudioTrack.Builder()
                            .setAudioAttributes(
                                AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                    .build()
                            )
                            .setAudioFormat(
                                AudioFormat.Builder()
                                    .setSampleRate(sampleRate)
                                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                    .build()
                            )
                            .setBufferSizeInBytes(bufSize)
                            .setTransferMode(AudioTrack.MODE_STREAM)
                            .build()

                        track.setVolume(currentVolume)
                        audioTrack = track

                        val body = response.body ?: run {
                            lastError = "Audio stream: no response body"
                            track.release()
                            audioTrack = null
                            return@use
                        }
                        val stream = body.byteStream()
                        val readBuf = ByteArray(2048)  // smaller chunks = lower latency

                        var prebuffered = 0
                        // 起動直後の最初の音がクッション不足でガサつく(HALアンダーラン)のを防ぐため ~100ms ためる。
                        // bufSizeの2/3以内に収める(play前のtrack.write満杯デッドロック回避)。
                        val prebufferTarget = minOf(bufSize * 2 / 3, sampleRate * 2 / 10)  // ~100ms（容量で頭打ち）
                        while (prebuffered < prebufferTarget && isActive) {
                            val n = stream.read(readBuf, 0, minOf(readBuf.size, prebufferTarget - prebuffered))
                            if (n <= 0) break
                            if (prebuffered == 0) Log.d("AudioStream", "first data ${System.currentTimeMillis()-t0}ms")
                            if (cwNrEnabled) {
                                notifySamples(readBuf, n)                                 // デコーダは生音(NR前)。notifySamplesはコピーを渡すので後段の破壊的NRと干渉しない
                                nr.process(readBuf, n, cwNrCenterHz, _currentSampleRate)  // NRは再生音のみ(狭帯域BPFのリンギングがCWエッジを鈍らせデコードを歪めるため)
                                applyPlaybackAgc(readBuf, n)
                            } else {
                                notifySamples(readBuf, n)
                                applyGain(readBuf, n)
                            }
                            track.write(readBuf, 0, n)
                            prebuffered += n
                        }

                        if (prebuffered == 0) {
                            lastError = "No audio data (attempt=$attempt, ${System.currentTimeMillis()-t0}ms)"
                            Log.e("AudioStream", lastError!!)
                            track.release()
                            audioTrack = null
                            return@use  // retry
                        }

                        Log.d("AudioStream", "play start ${System.currentTimeMillis()-t0}ms prebuf=${prebuffered}B")
                        track.play()
                        streamed = true
                        lastError = null

                        // Bounded-latency playback. The Pi usually streams a hair faster than the phone
                        // plays (clock drift); with a single blocking read→write loop the surplus backs up
                        // in the TCP buffer and latency grows unbounded (seconds behind after ~10 min).
                        // Fix: a READER thread drains the socket continuously (TCP never backs up) into a
                        // small drop-oldest queue; the playback side consumes at AudioTrack's pace. When the
                        // reader outruns playback the queue drops its OLDEST chunk, so latency is capped near
                        // real-time forever — no periodic reconnect needed. Chunks are kept 16-bit aligned
                        // (odd trailing byte carried over) so dropping whole chunks never desyncs samples.
                        val bytesPerSec = sampleRate * 2
                        val maxBacklogBytes = bytesPerSec / 3            // cap ≈330ms of queued audio
                        val queue = ArrayBlockingQueue<ByteArray>(64)
                        val queuedBytes = java.util.concurrent.atomic.AtomicInteger(0)
                        val reader = Thread {
                            val rb = ByteArray(2048)
                            var carry = -1
                            try {
                                while (isActive && !stopping) {
                                    var off = 0
                                    if (carry >= 0) { rb[0] = carry.toByte(); off = 1; carry = -1 }
                                    val n = stream.read(rb, off, rb.size - off)
                                    if (n <= 0) break
                                    var total = off + n
                                    if (total % 2 == 1) { carry = rb[total - 1].toInt() and 0xFF; total -= 1 }
                                    if (total == 0) continue
                                    lastDataMs = System.currentTimeMillis()
                                    val chunk = rb.copyOf(total)
                                    // drop oldest until this chunk fits under the latency cap
                                    while (queuedBytes.get() + total > maxBacklogBytes) {
                                        val old = queue.poll() ?: break
                                        queuedBytes.addAndGet(-old.size)
                                    }
                                    if (queue.offer(chunk)) queuedBytes.addAndGet(total)
                                }
                            } catch (_: Exception) {}
                            queue.offer(ByteArray(0))   // sentinel → unblock consumer on EOF
                        }
                        reader.isDaemon = true
                        reader.start()
                        try {
                            // Playback at AUDIO priority (not starved by background decode work).
                            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_AUDIO)
                            // CLOCK-DRIFT / JITTER GUARD: the USB-codec capture clock and the phone's
                            // playback clock differ slightly, so every few minutes the queue momentarily
                            // empties. Letting the AudioTrack underrun gets the track removed → the whole
                            // stream drops → ~2 s reconnect gap. Instead, FEED SILENCE to keep the track
                            // alive; a brief drift empty becomes an inaudible gap, not a 2 s dropout. Only a
                            // truly dead stream (>10 s silent, or reader EOF sentinel) triggers a reconnect.
                            val silence = ByteArray(maxOf(2, sampleRate * 2 / 50))   // ~20 ms, 16-bit mono
                            var stallMs = 0
                            while (isActive) {
                                val chunk = queue.poll(20, TimeUnit.MILLISECONDS)
                                if (chunk == null) {
                                    track.write(silence, 0, silence.size)
                                    stallMs += 20
                                    if (stallMs > 10000) break   // 10 s truly dead → reconnect
                                    continue
                                }
                                stallMs = 0
                                if (chunk.isEmpty()) break   // EOF sentinel
                                queuedBytes.addAndGet(-chunk.size)
                                if (cwNrEnabled) {
                                    notifySamples(chunk, chunk.size)                                 // デコーダは生音(NR前)。notifySamplesはコピーを渡すので後段の破壊的NRと干渉しない
                                    nr.process(chunk, chunk.size, cwNrCenterHz, _currentSampleRate)  // NRは再生音のみ(狭帯域BPFのリンギングがCWエッジを鈍らせデコードを歪めるため)
                                    applyPlaybackAgc(chunk, chunk.size)
                                } else {
                                    notifySamples(chunk, chunk.size)
                                    applyGain(chunk, chunk.size)
                                }
                                track.write(chunk, 0, chunk.size)
                            }
                        } finally {
                            reader.interrupt()
                        }

                        track.stop()
                        track.release()
                        audioTrack = null
                    }
                } catch (e: Exception) {
                    if (!stopping) {
                        lastError = "Audio connect error: ${e.message}"
                        Log.e("AudioStream", "attempt $attempt: ${e.message}")
                    } else {
                        break
                    }
                }
                if (stopping) break
                if (streamed) {
                    // Stream dropped unexpectedly — wait then reconnect.
                    // 一度正常に再生できたので再試行回数をリセット(定期ドロップでも常に即再接続)。
                    lastError = "Audio stream lost"
                    Log.w("AudioStream", "stream dropped attempt=$attempt, reconnecting")
                    attempt = 0
                    delay(RECONNECT_DELAY_MS)
                    if (!isActive || stopping) break
                }
            }
            if (!stopping && lastError != null) {
                onError?.invoke(lastError!!)
            }
        }
    }

    private fun notifySamples(buf: ByteArray, n: Int) {
        val listener = audioSampleListener ?: return
        if (n < 2) return
        val count = n / 2
        val shorts = ShortArray(count) { i ->
            val lo = buf[i * 2].toInt() and 0xFF
            val hi = buf[i * 2 + 1].toInt() and 0xFF
            ((hi shl 8) or lo).toShort()
        }
        listener(shorts)
    }

    fun stop() {
        stopping = true
        streamJob?.cancel()
        streamJob = null
        activeCall?.cancel()
        activeCall = null
        val track = audioTrack
        audioTrack = null
        lastDataMs = 0L
        try { track?.stop() } catch (_: Exception) {}
        try { track?.release() } catch (_: Exception) {}
    }

    fun setVolume(vol: Float) {
        currentVolume = vol
        audioTrack?.setVolume(vol)
    }

    val isPlaying: Boolean get() = audioTrack?.playState == AudioTrack.PLAYSTATE_PLAYING
    val isStreamActive: Boolean get() = streamJob?.isActive == true
    // True only when AudioTrack is playing AND data was received within the last 5 seconds.
    // Detects "zombie" state: AudioTrack.PLAYSTATE_PLAYING but Pi stopped sending data.
    // 無データ3秒で「流れていない」と判定(SPKウォッチドッグの検知待ちを短縮し途切れの空白を縮める)。
    val isDataFlowing: Boolean get() = isPlaying && (System.currentTimeMillis() - lastDataMs < 3000L)

    /** 再生中なのにデータが ms ミリ秒以上届いていない(真のゾンビ判定用)。一瞬のWiFiストールでは
     *  張り直さず、長時間(例:15秒)来ない時だけウォッチドッグが復帰させるために使う。 */
    fun noDataFor(ms: Long): Boolean = isPlaying && (System.currentTimeMillis() - lastDataMs > ms)

    /** Sample rate of the currently running stream (0 if not running). */
    val currentSampleRate: Int get() = if (isStreamActive) _currentSampleRate else 0
    @Volatile private var _currentSampleRate: Int = 0

    private fun extractSampleRate(url: String): Int =
        Regex("rate=(\\d+)").find(url)?.groupValues?.get(1)?.toIntOrNull() ?: 8000

    companion object {
        private const val MAX_RETRY = 10
        private const val RETRY_DELAY_MS = 500L
        private const val RECONNECT_DELAY_MS = 300L
    }
}
