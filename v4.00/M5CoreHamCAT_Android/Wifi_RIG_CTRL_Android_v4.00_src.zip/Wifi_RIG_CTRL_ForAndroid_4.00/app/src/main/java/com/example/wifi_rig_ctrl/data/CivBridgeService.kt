package com.ji1ore.wifi_rig_ctrl.data

import android.util.Log
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.LinkedBlockingDeque
import java.util.concurrent.TimeUnit

/**
 * 生CI-V/TCPブリッジ・クライアント。Pi api.py の /radio/civ_bridge が、D-STAR運用中だけ rigctld を止めて
 * リグのUSBシリアルを生CI-VのTCP(ポート14652)として公開する。本クラスはそこへ直接CI-Vフレームを送受信し、
 * rigctld(hamlib)を介さずに D-STAR 制御(DR/UR/R1/R2)と受信コール(20 00 02)ポーリングを遠隔で行う。
 * フレーム形式・exchange・body形式は CivBtService と同一(body = [dest, src, cmd, ...])。
 */
class CivBridgeService {
    companion object { private const val TAG = "CivBridge"; private const val CTRL_ADDR = 0xE0 }

    /** リグのCI-Vアドレス(IC-705=0xA4 / IC-9700=0xA2)。接続前に設定する。 */
    @Volatile var rigAddr = 0xA4
    @Volatile var isConnected = false
        private set

    private var sock: Socket? = null
    private var outStream: OutputStream? = null
    private var inStream: InputStream? = null
    private val rxQueue = LinkedBlockingDeque<ByteArray>()
    @Volatile private var rxActive = false
    private var rxThread: Thread? = null

    fun connect(host: String, port: Int): Boolean {
        disconnect()
        return try {
            val s = Socket()
            s.tcpNoDelay = true
            s.connect(InetSocketAddress(host, port), 3000)
            sock = s
            outStream = s.getOutputStream()
            inStream = s.getInputStream()
            rxQueue.clear()
            isConnected = true
            startRxThread(s.getInputStream())
            Log.i(TAG, "connected $host:$port rigAddr=0x${rigAddr.toString(16)}")
            true
        } catch (e: Exception) {
            Log.w(TAG, "connect failed: ${e.message}"); disconnect(); false
        }
    }

    fun disconnect() {
        rxActive = false
        try { sock?.close() } catch (_: Exception) {}
        sock = null; outStream = null; inStream = null; isConnected = false
    }

    private fun buildCivFrame(vararg bytes: Int): ByteArray {
        val b = ByteArray(4 + bytes.size + 1)
        b[0] = 0xFE.toByte(); b[1] = 0xFE.toByte()
        b[2] = rigAddr.toByte(); b[3] = CTRL_ADDR.toByte()
        bytes.forEachIndexed { i, v -> b[4 + i] = v.toByte() }
        b[b.size - 1] = 0xFD.toByte()
        return b
    }

    private fun sendCivFrame(frame: ByteArray): Boolean = try {
        outStream?.write(frame); outStream?.flush(); true
    } catch (e: Exception) { Log.e(TAG, "send: ${e.message}"); isConnected = false; false }

    private fun startRxThread(input: InputStream) {
        rxActive = true
        rxThread = Thread {
            val buf = ByteArray(512)
            val acc = ArrayList<Byte>(64)
            while (rxActive) {
                try {
                    val n = input.read(buf)
                    if (n < 0) break
                    for (i in 0 until n) {
                        val b = buf[i]
                        acc.add(b)
                        if ((b.toInt() and 0xFF) == 0xFD) {
                            val frame = acc.toByteArray(); acc.clear()
                            if (frame.size >= 5 && (frame[0].toInt() and 0xFF) == 0xFE &&
                                (frame[1].toInt() and 0xFF) == 0xFE) {
                                rxQueue.offerLast(frame)
                            }
                        }
                        if (acc.size > 4096) acc.clear()   // 暴走防止
                    }
                } catch (e: Exception) {
                    if (rxActive) Log.w(TAG, "rxThread: ${e.message}"); break
                }
            }
            rxActive = false; isConnected = false
        }.also { it.isDaemon = true; it.name = "civBridgeRx"; it.start() }
    }

    @Synchronized
    private fun exchange(frame: ByteArray, cmd: Int, subCmd: Int = -1, timeoutMs: Int = 1200): ByteArray? {
        if (!isConnected) return null
        rxQueue.clear()
        if (!sendCivFrame(frame)) return null
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            val r = rxQueue.pollFirst(50, TimeUnit.MILLISECONDS) ?: continue
            extractCivBody(r, cmd, subCmd)?.let { return it }
            if (cmd == 0xFB) extractCivBody(r, 0xFB, -1)?.let { return it }
        }
        return null
    }

    // body = [dest, src, cmd, ...]（FE FE と末尾 FD を除く）。自分のエコーや transceive は dest/src で弾く。
    private fun extractCivBody(frame: ByteArray, cmd: Int, subCmd: Int): ByteArray? {
        if (frame.size < 5) return null
        if ((frame[0].toInt() and 0xFF) != 0xFE || (frame[1].toInt() and 0xFF) != 0xFE) return null
        val dest = frame[2].toInt() and 0xFF
        val src = frame[3].toInt() and 0xFF
        if (dest != CTRL_ADDR || src != rigAddr) return null
        if ((frame[4].toInt() and 0xFF) != cmd) return null
        if (subCmd >= 0 && (frame.size < 6 || (frame[5].toInt() and 0xFF) != subCmd)) return null
        return frame.copyOfRange(2, frame.size - 1)
    }

    private fun bcd5(hz: Long): IntArray {
        var f = hz
        return IntArray(5) { val lo = (f % 10).toInt(); f /= 10; val hi = (f % 10).toInt(); f /= 10; (hi shl 4) or lo }
    }
    private fun bcd3off(hz: Long): IntArray {
        var v = hz / 100
        return IntArray(3) { val lo = (v % 10).toInt(); v /= 10; val hi = (v % 10).toInt(); v /= 10; (hi shl 4) or lo }
    }

    // ── Frequency / Mode / PTT (rigctld停止中の基本制御) ──
    fun getFrequency(): Long? {
        val r = exchange(buildCivFrame(0x03), 0x03) ?: return null
        if (r.size < 8) return null
        var freq = 0L; var mult = 1L
        for (i in 3..7) { val b = r[i].toInt() and 0xFF; freq += (b and 0xF) * mult; mult *= 10; freq += (b shr 4) * mult; mult *= 10 }
        return freq
    }
    fun setFrequency(hz: Long): Boolean {
        val b = bcd5(hz); return exchange(buildCivFrame(0x05, b[0], b[1], b[2], b[3], b[4]), 0xFB) != null
    }
    fun setPtt(on: Boolean): Boolean = exchange(buildCivFrame(0x1C, 0x00, if (on) 0x01 else 0x00), 0xFB) != null
    fun getSmeterRaw(): Int? {
        val r = exchange(buildCivFrame(0x15, 0x02), 0x15, 0x02) ?: return null
        if (r.size < 6) return null
        return ((r[4].toInt() and 0xF) * 100) + ((r[5].toInt() and 0xF0) shr 4) * 10 + (r[5].toInt() and 0xF)
    }

    // ── D-STAR (CivBtService と同一仕様) ──
    private fun dvCall8(s: String): IntArray {
        val up = s.uppercase()
        return IntArray(8) { i ->
            val c = up.getOrNull(i)?.code ?: 0x20
            if (c in 0x30..0x39 || c in 0x41..0x5A || c == 0x20 || c == 0x2F) c else 0x20
        }
    }
    fun setDvCallSigns(ur: String, r1: String, r2: String): Boolean {
        val data = dvCall8(ur) + dvCall8(r1) + dvCall8(r2)
        return exchange(buildCivFrame(0x1F, 0x01, *data), 0xFB) != null
    }
    fun readDvCallSigns(): Triple<String, String, String>? {
        val body = exchange(buildCivFrame(0x1F, 0x01), 0x1F, 0x01) ?: return null
        if (body.size < 4 + 24) return null
        fun field(off: Int) = (0 until 8).map { (body[4 + off + it].toInt() and 0xFF).toChar() }.joinToString("").trim()
        return Triple(field(0), field(8), field(16))
    }
    /** 受信DVコール(20 00 02): 呼び出し元(caller)と相手局(called/UR)。UR1/UR2表示用。 */
    fun readDvRxCallSigns(): Pair<String, String>? {
        val body = exchange(buildCivFrame(0x20, 0x00, 0x02), 0x20, 0x00) ?: return null
        val d = 5
        if (body.size < d + 2 + 8 + 4 + 8) return null
        fun field(off: Int) = (0 until 8).map { (body[d + off + it].toInt() and 0xFF).toChar() }.joinToString("").trim()
        val caller = field(2)
        val called = field(2 + 8 + 4)
        return Pair(caller, called)
    }
    /** 受信DVメッセージ(20 01 02): 相手局が送る20字メッセージ。FF先頭=未受信→空文字。 */
    fun readDvRxMessage(): String? {
        val body = exchange(buildCivFrame(0x20, 0x01, 0x02), 0x20, 0x01) ?: return null
        val d = 5   // [dest,src,20,01,02,...] の後
        if (body.size < d + 20) return null
        if ((body[d].toInt() and 0xFF) == 0xFF) return ""
        val sb = StringBuilder(20)
        for (i in 0 until 20) {
            val c = body[d + i].toInt() and 0xFF
            if (c in 0x20..0x7E) sb.append(c.toChar())
        }
        return sb.toString().trim()
    }

    private fun ascii(s: String, n: Int): IntArray {
        val up = s.uppercase()
        return IntArray(n) { i -> val c = up.getOrNull(i)?.code ?: 0x20; if (c in 0x20..0x5A || c in 0x30..0x39) c else 0x20 }
    }
    /** 1F 00 MY call(自局 8 + ノート 4)。 */
    fun setMyCall(call: String, note: String): Boolean =
        exchange(buildCivFrame(0x1F, 0x00, *ascii(call, 8), *ascii(note, 4)), 0xFB) != null
    fun readMyCall(): Pair<String, String>? {
        val b = exchange(buildCivFrame(0x1F, 0x00), 0x1F, 0x00) ?: return null
        if (b.size < 4 + 12) return null
        fun f(o: Int, n: Int) = (0 until n).map { (b[4 + o + it].toInt() and 0xFF).toChar() }.joinToString("").trim()
        return Pair(f(0, 8), f(8, 4))
    }
    private fun msgAscii(s: String, n: Int): IntArray =
        IntArray(n) { i -> val c = s.getOrNull(i)?.code ?: 0x20; if (c in 0x20..0x7E) c else 0x20 }
    /** 1F 02 TX message(<=20, 空=FFで消去)。 */
    fun setTxMessage(msg: String): Boolean =
        if (msg.isBlank()) exchange(buildCivFrame(0x1F, 0x02, 0xFF), 0xFB) != null
        else exchange(buildCivFrame(0x1F, 0x02, *msgAscii(msg, 20)), 0xFB) != null

    /** D-STAR DVモードへ(0x06 0x17)。ブリッジ接続中のモード確定用。 */
    fun setDvMode(): Boolean = exchange(buildCivFrame(0x06, 0x17), 0xFB) != null

    /** シンプレックス用: VFO選択(DR抜け)+DVモード+周波数+[オフセット]+DUP+1F 01。DRルーティングは
     *  setDvCallSigns のみ呼ぶ(DRモード維持)。 */
    fun setupDvSimplex(ur: String, freqHz: Long): Boolean {
        exchange(buildCivFrame(0x07, 0x00), 0xFB)
        exchange(buildCivFrame(0x06, 0x17), 0xFB)
        if (freqHz > 0) setFrequency(freqHz)
        exchange(buildCivFrame(0x0F, 0x00), 0xFB)   // DUP OFF
        return setDvCallSigns(ur, "", "")
    }
}
