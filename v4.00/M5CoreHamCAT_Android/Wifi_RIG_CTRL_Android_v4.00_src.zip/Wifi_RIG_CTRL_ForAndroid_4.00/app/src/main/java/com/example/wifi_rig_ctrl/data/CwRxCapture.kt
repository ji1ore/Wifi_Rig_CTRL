package com.example.wifi_rig_ctrl.data

import android.content.Context
import android.util.Log
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * DEBUG ONLY — rolling capture of the exact 16-bit PCM fed to the CW RX decoder, so an INTERMITTENT
 * "T連打 / TTT" event (can't be reproduced on demand) is recorded automatically when it happens.
 *
 * A circular buffer keeps the most recent `windowSec` seconds of audio. When the decoder output trips
 * the symptom detector (a run of consecutive lone-dah 'T' chars — see MainViewModel.appendCwRxChar),
 * `trigger()` dumps the whole window to a numbered WAV — the audio LEADING UP TO the glitch is exactly
 * what we need to replay offline. Several events are kept (cw_rx_ttt_1.wav, _2, …). Pull with:
 *   adb pull /sdcard/Android/data/com.ji1ore.wifi_rig_ctrl/files/
 */
object CwRxCapture {
    @Volatile var enabled = true          // DIAGNOSTIC: capture CI-V RS-BA1 audio to debug TU/GA short-char miss. Release = false.
    // append() runs on the AUDIO PLAYBACK thread, so the ~800KB WAV write must NOT happen there (it
    // stalls playback → underrun → stream drop). We snapshot the ring to a byte array under the lock
    // (fast) and hand the actual file write to a background, low-priority thread (writeExec).

    private val writeExec = java.util.concurrent.Executors.newSingleThreadExecutor { r ->
        Thread(r, "cwrx-write").apply { isDaemon = true; priority = Thread.MIN_PRIORITY }
    }

    private const val WINDOW_SEC = 25
    private var ring: ShortArray = ShortArray(0)
    private var writePos = 0               // next write index
    private var filled = 0                 // valid samples in ring (≤ ring.size)
    private var rate = 8000
    private var ctxRef: Context? = null
    private var eventNo = 0
    private var armedAfterTrigger = 0       // suppress re-trigger for this many samples after a dump
    private var autoSaveCountdown = 0       // samples until the next periodic auto-dump
    var lastPath: String? = null; private set

    @Synchronized
    fun start(ctx: Context, sampleRate: Int) {
        if (!enabled) return
        rate = sampleRate
        ctxRef = ctx.applicationContext
        ring = ShortArray(sampleRate * WINDOW_SEC)
        writePos = 0; filled = 0; eventNo = 0; armedAfterTrigger = 0
        autoSaveCountdown = sampleRate * WINDOW_SEC   // first auto-dump after one full window
        Log.i("CwRxCapture", "rolling ${WINDOW_SEC}s window armed @ ${sampleRate}Hz")
    }

    @Synchronized
    fun append(samples: ShortArray) {
        if (ring.isEmpty()) return
        for (s in samples) {
            ring[writePos] = s
            writePos = (writePos + 1) % ring.size
            if (filled < ring.size) filled++
        }
        if (armedAfterTrigger > 0) armedAfterTrigger -= samples.size
        // Periodic auto-dump: a fresh rolling window every WINDOW_SEC to cw_rx_auto.wav (newest wins),
        // so a capture is always available with NO user gesture (the long-press/decode-off paths kept
        // missing). Only once the ring is full so the dump is a complete window.
        if (filled >= ring.size) {
            autoSaveCountdown -= samples.size
            if (autoSaveCountdown <= 0) { autoSaveCountdown = rate * WINDOW_SEC; saveRing("cw_rx_auto", "auto") }
        }
    }

    /** Called when the symptom (T-run) is detected. Dumps the current window to a WAV. */
    @Synchronized
    fun trigger(reason: String) {
        if (ring.isEmpty() || filled == 0) return
        if (armedAfterTrigger > 0) return          // one dump per event (debounce ~window)
        armedAfterTrigger = ring.size
        eventNo++
        saveRing("cw_rx_ttt_$eventNo", reason)
    }

    /** Manual dump of the current rolling window to cw_rx_manual.wav, regardless of symptom/trigger
     *  state. Reliable "capture now" for tuning — returns the saved path (null if nothing buffered). */
    @Synchronized
    fun dumpNow(): String? {
        if (!enabled || ring.isEmpty() || filled == 0) return null
        armedAfterTrigger = 0
        saveRing("cw_rx_manual", "manual")
        return lastPath
    }

    @Synchronized
    fun stop() {
        // DIAGNOSTIC: dump the last window on decode-off so a live signal (e.g. 7 MHz) can be captured
        // just by toggling CW decode off. Saved as cw_rx_diag.wav (newest wins). armedAfterTrigger is
        // reset so trigger() won't suppress this.
        if (enabled && filled > 0) { armedAfterTrigger = 0; saveRing("cw_rx_diag", "decode-off") }
        ring = ShortArray(0); writePos = 0; filled = 0; ctxRef = null
    }

    /** Snapshot the ring to a little-endian PCM byte array UNDER THE LOCK (fast), then write the WAV on
     *  a background thread (slow file I/O must never block the audio playback thread that calls append). */
    @Synchronized
    private fun saveRing(baseName: String, reason: String) {
        val ctx = ctxRef ?: return
        if (ring.isEmpty() || filled == 0) return
        val n = filled
        val start = if (filled < ring.size) 0 else writePos
        val pcm = ByteArray(n * 2)
        val bb = ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until n) bb.putShort(ring[(start + i) % ring.size])   // copy only (no I/O here)
        val sr = rate
        val dir = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        val f = File(dir, "$baseName.wav")
        lastPath = f.absolutePath
        writeExec.execute {   // ← slow 800KB write off the playback thread
            try {
                val r = RandomAccessFile(f, "rw"); r.setLength(0)
                writeHeader(r, sr, pcm.size)
                r.seek(44); r.write(pcm); r.close()
                Log.i("CwRxCapture", "saved ($reason) -> ${f.absolutePath} ($n samples)")
            } catch (e: Exception) { Log.e("CwRxCapture", "saveRing failed: $e") }
        }
    }

    private fun writeHeader(r: RandomAccessFile, sr: Int, dataLen: Int) {
        r.seek(0)
        val byteRate = sr * 2   // mono, 16-bit
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray(Charsets.US_ASCII)); h.putInt(36 + dataLen)
        h.put("WAVE".toByteArray(Charsets.US_ASCII))
        h.put("fmt ".toByteArray(Charsets.US_ASCII)); h.putInt(16)
        h.putShort(1); h.putShort(1)                    // PCM, 1 channel
        h.putInt(sr); h.putInt(byteRate)
        h.putShort(2); h.putShort(16)                   // block align, bits
        h.put("data".toByteArray(Charsets.US_ASCII)); h.putInt(dataLen)
        r.write(h.array())
    }
}
