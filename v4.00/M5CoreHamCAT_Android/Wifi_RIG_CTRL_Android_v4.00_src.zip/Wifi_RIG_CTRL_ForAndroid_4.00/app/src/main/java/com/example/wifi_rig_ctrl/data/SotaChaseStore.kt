package com.ji1ore.wifi_rig_ctrl.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

/**
 * SOTA チェイス（追跡）ログの保持。
 * SP2Alert の sota_chased.json と同形式（サミットref の JSON 文字列配列）で保存する。
 * refは大文字に正規化して保持。
 */
class SotaChaseStore(context: Context) {

    private val gson = Gson()
    private val storeFile = File(context.filesDir, "sota_chased.json")
    private var cache: Set<String> = emptySet()

    var chasedCount: Int = 0
        private set

    init { load() }

    fun isChased(summitRef: String): Boolean = cache.contains(summitRef.uppercase())

    /** SP2Alert 由来の JSON（サミットref の文字列配列）を取り込む。取り込んだ件数を返す。 */
    fun importFromJson(json: String): Int {
        return try {
            val type = object : TypeToken<List<String>>() {}.type
            val list: List<String> = gson.fromJson(json, type) ?: return 0
            val set = list.map { it.trim().uppercase() }.filter { it.isNotEmpty() }.toHashSet()
            cache = set
            chasedCount = set.size
            save()
            set.size
        } catch (_: Exception) { 0 }
    }

    private fun save() { storeFile.writeText(gson.toJson(cache.toList())) }

    private fun load() {
        if (!storeFile.exists()) return
        try {
            val type = object : TypeToken<List<String>>() {}.type
            val list: List<String> = gson.fromJson(storeFile.readText(), type) ?: emptyList()
            cache = list.map { it.uppercase() }.toHashSet()
            chasedCount = cache.size
        } catch (_: Exception) { cache = emptySet() }
    }
}
