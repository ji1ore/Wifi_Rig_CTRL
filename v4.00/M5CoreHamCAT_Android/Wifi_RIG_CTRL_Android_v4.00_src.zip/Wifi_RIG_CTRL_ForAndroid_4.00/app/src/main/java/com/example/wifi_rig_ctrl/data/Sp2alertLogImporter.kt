package com.ji1ore.wifi_rig_ctrl.data

import android.content.Context
import android.net.Uri

/**
 * SP2Alert アプリ（com.ji1ore.sp2alart）が公開する ContentProvider から
 * POTA ハントログ / SOTA チェイスログを取得し、ローカルストアへ取り込む。
 *
 *   content://com.ji1ore.sp2alart.logs/pota_hunter
 *   content://com.ji1ore.sp2alart.logs/sota_chase
 *
 * SP2Alert が未インストール、または旧バージョンで Provider が無い場合は
 * query が null / SecurityException となるため available=false を返す。
 */
object Sp2alertLogImporter {

    private const val AUTHORITY = "com.ji1ore.sp2alart.logs"
    private const val COL_JSON = "json"

    data class Result(val available: Boolean, val potaCount: Int, val sotaCount: Int)

    fun importAll(
        context: Context,
        hunterStore: HunterStore,
        sotaChaseStore: SotaChaseStore
    ): Result {
        val potaJson = readJson(context, "pota_hunter")
        val sotaJson = readJson(context, "sota_chase")
        if (potaJson == null && sotaJson == null) {
            return Result(available = false, potaCount = 0, sotaCount = 0)
        }
        val pota = potaJson?.let { hunterStore.importFromSp2alertJson(it) } ?: 0
        val sota = sotaJson?.let { sotaChaseStore.importFromJson(it) } ?: 0
        return Result(available = true, potaCount = pota, sotaCount = sota)
    }

    private fun readJson(context: Context, path: String): String? {
        val uri = Uri.parse("content://$AUTHORITY/$path")
        return try {
            context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(COL_JSON)
                    if (idx >= 0) c.getString(idx) else null
                } else null
            }
        } catch (_: Exception) {
            // SecurityException（権限未付与）や Provider 不在など
            null
        }
    }
}
