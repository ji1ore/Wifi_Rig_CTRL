package com.ji1ore.wifi_rig_ctrl

import com.ji1ore.wifi_rig_ctrl.data.CwDecoder
import org.junit.Test
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * OFFLINE CW REPLAY HARNESS (JVM — no Android).
 *
 * Feeds a captured 16-bit PCM mono WAV (produced on-device by CwRxCapture: cw_rx_diag.wav /
 * cw_rx_ttt_N.wav) through the REAL CwDecoder so decode behaviour can be analysed and tuned on the
 * PC, with no radio in the loop. CwDecoder depends only on kotlin.math, so it runs as a plain unit test.
 *
 * Pull a capture from the device first:
 *   adb pull /sdcard/Android/data/com.ji1ore.wifi_rig_ctrl/files/cw_rx_diag.wav
 *
 * Then point the harness at it and run:
 *   ./gradlew :app:testDebugUnitTest --tests "com.ji1ore.wifi_rig_ctrl.CwReplay" -Dcwwav=/abs/path/cw_rx_diag.wav
 *
 * With no -Dcwwav it looks for app/src/test/resources/cw_rx_diag.wav; if absent the test no-ops
 * (so it never breaks a normal test run).
 *
 * The harness SWEEPS manualNoiseLevel (the app's "受信ゲイン/しきい値" squelch: -1=auto Otsu, else
 * 0..1 = gain above the tracked noise floor) and prints the decode for each, so you can see directly
 * which threshold copies the target station best on THIS capture — the real answer to "AGCを上げた
 * 方がいいか?". (A pure linear gain would NOT change the decode: the decoder is SNR/ratio-relative.)
 */
class CwReplay {

    private class Wav(val rate: Int, val samples: ShortArray)

    private var ch0FreqHops: StringBuilder? = null

    /** Parse a canonical PCM WAV (handles mono/stereo, 16-bit, arbitrary chunk order). Downmixes to mono. */
    private fun readWav(f: File): Wav {
        RandomAccessFile(f, "r").use { r ->
            val riff = ByteArray(12); r.readFully(riff)
            require(String(riff, 0, 4) == "RIFF" && String(riff, 8, 4) == "WAVE") { "not a WAVE file" }
            var rate = 8000; var channels = 1; var bits = 16
            var data: ByteArray? = null
            val hdr = ByteArray(8)
            while (r.read(hdr) == 8) {
                val id = String(hdr, 0, 4, Charsets.US_ASCII)
                val sz = ByteBuffer.wrap(hdr, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int
                when (id) {
                    "fmt " -> {
                        val b = ByteArray(sz); r.readFully(b)
                        val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
                        bb.short                         // audioFormat
                        channels = bb.short.toInt()
                        rate = bb.int
                        bb.int; bb.short                 // byteRate, blockAlign
                        bits = bb.short.toInt()
                    }
                    "data" -> { val b = ByteArray(sz); r.readFully(b); data = b }
                    else   -> r.seek(r.filePointer + sz + (sz and 1))  // skip (+pad to even)
                }
            }
            require(bits == 16) { "only 16-bit PCM supported (got $bits)" }
            val d = requireNotNull(data) { "no data chunk" }
            val bb = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
            val frames = d.size / 2 / channels
            val out = ShortArray(frames)
            for (i in 0 until frames) {
                var acc = 0
                for (c in 0 until channels) acc += bb.short.toInt()
                out[i] = (acc / channels).toShort()
            }
            return Wav(rate, out)
        }
    }

    private fun locateWav(): File? {
        System.getProperty("cwwav")?.let { val f = File(it); if (f.isFile) return f }
        val res = File("src/test/resources/cw_rx_diag.wav")
        return if (res.isFile) res else null
    }

    /** Run the decoder once at a given manualNoiseLevel + analysis window; return per-channel text.
     *  If ch0Codes != null, append each ch0 char's raw dit/dah code so the element segmentation /
     *  ditWins-collapse can be read directly (e.g. a run of lone "-"/"." = TE/TTT collapse). */
    private fun decode(wav: Wav, noiseLevel: Float, windowMs: Double,
                       ch0Codes: ArrayList<Pair<Char, String>>? = null,
                       emitGate: Float? = System.getProperty("cwGate")?.toFloatOrNull(),
                       peakSnrMin: Float? = null): Array<StringBuilder> {
        val dec = CwDecoder(wav.rate, windowMs)
        dec.manualNoiseLevel = noiseLevel
        if (emitGate != null) dec.charEmitSnrGate = emitGate   // else keep decoder's production default
        if (peakSnrMin != null) dec.peakSnrMin = peakSnrMin
        val out = Array(CwDecoder.N_CHAN) { StringBuilder() }
        dec.onCharDecoded = { c, ci, code ->
            if (ci in 0 until CwDecoder.N_CHAN) out[ci].append(c)
            if (ci == 0) ch0Codes?.add(c to code)
        }
        if (ch0Codes != null) {
            // Log ch0 frequency hops: if ch0 jumps between two close tones, it is mixing two stations.
            val hops = StringBuilder()
            dec.onChannelFreq = { ci, hz -> if (ci == 0) hops.append(if (hz == 0) " ×" else " ${hz}") }
            ch0FreqHops = hops
        }
        // Feed in ~1024-sample chunks, mimicking the live stream granularity.
        var i = 0
        val chunk = 1024
        while (i < wav.samples.size) {
            val n = minOf(chunk, wav.samples.size - i)
            dec.processSamples(wav.samples.copyOfRange(i, i + n))
            i += n
        }
        return out
    }

    /**
     * Characterize the capture independently of CwDecoder: is there a COHERENT keyed CW tone, or
     * just noise? Goertzel-sweep the CW band per 32 ms frame, take the strongest bin, and report its
     * SNR distribution + how steady the dominant frequency is.
     *   - Steady dominant freq + bimodal SNR (clear ON vs OFF)  → real keyed signal (decoder bug if garbled)
     *   - Wandering freq + unimodal low SNR                      → noise (raise squelch; no threshold helps)
     */
    /** Goertzel power of `freq` over `frame` samples starting at `start`. */
    private fun goertzel(wav: Wav, start: Int, frame: Int, freq: Int): Double {
        val w = 2.0 * Math.PI * freq / wav.rate
        val coeff = 2.0 * Math.cos(w)
        var s1 = 0.0; var s2 = 0.0
        for (n in 0 until frame) {
            val s0 = wav.samples[start + n] / 32768.0 + coeff * s1 - s2
            s2 = s1; s1 = s0
        }
        return s1 * s1 + s2 * s2 - coeff * s1 * s2
    }

    private fun characterize(wav: Wav) {
        val rate = wav.rate
        val frame = (rate * 0.032).toInt()                 // 32 ms frames
        val hop = frame / 2
        val freqs = (300..1500 step 20).toList()           // coarse CW-band sweep
        val domFreq = ArrayList<Int>()
        val domSnr = ArrayList<Double>()
        var i = 0
        while (i + frame <= wav.samples.size) {
            // Goertzel power at each probe frequency over this frame.
            var total = 0.0
            val pw = DoubleArray(freqs.size)
            for ((k, f) in freqs.withIndex()) {
                val w = 2.0 * Math.PI * f / rate
                val coeff = 2.0 * Math.cos(w)
                var s0 = 0.0; var s1 = 0.0; var s2 = 0.0
                for (n in 0 until frame) {
                    s0 = wav.samples[i + n] / 32768.0 + coeff * s1 - s2
                    s2 = s1; s1 = s0
                }
                val p = s1 * s1 + s2 * s2 - coeff * s1 * s2
                pw[k] = p; total += p
            }
            var bi = 0; var bp = 0.0
            for (k in pw.indices) if (pw[k] > bp) { bp = pw[k]; bi = k }
            val noise = (total - bp) / (freqs.size - 1)     // mean power of the other bins
            domFreq.add(freqs[bi])
            domSnr.add(if (noise > 0) bp / noise else 0.0)
            i += hop
        }
        if (domSnr.isEmpty()) { println("  [characterize] too short"); return }
        val sorted = domSnr.sorted()
        fun pct(p: Double) = sorted[(p * (sorted.size - 1)).toInt()]
        val onFrac = domSnr.count { it > 5.0 }.toDouble() / domSnr.size
        // Dominant-frequency stability: mode share among ON frames (SNR>5).
        val onFreqs = domFreq.filterIndexed { idx, _ -> domSnr[idx] > 5.0 }
        val modeShare = if (onFreqs.isEmpty()) 0.0 else
            onFreqs.groupingBy { it / 40 * 40 }.eachCount().values.max().toDouble() / onFreqs.size
        println("  [characterize] frames=${domSnr.size}  domSNR p50=%.1f p90=%.1f  ON(frac SNR>5)=%.0f%%  freqMode=%s  modeShare=%.0f%%"
            .format(pct(0.5), pct(0.9), onFrac * 100, if (onFreqs.isEmpty()) "-" else "${onFreqs.groupingBy { it / 40 * 40 }.eachCount().maxByOrNull { it.value }!!.key}Hz", modeShare * 100))
        // Top ON-frame frequencies (40 Hz buckets) — several strong buckets = QRM (multiple stations).
        val onHist = onFreqs.groupingBy { it / 40 * 40 }.eachCount().entries.sortedByDescending { it.value }
        val topFreqs = onHist.take(5).joinToString("  ") { "${it.key}Hz:${(it.value * 100 / onFreqs.size.coerceAtLeast(1))}%" }
        println("  [characterize] ON-freq histogram: $topFreqs")
        // Are the two dominant tones ONE chirpy/drifting signal, or TWO independent stations?
        // Correlate the per-frame Goertzel envelopes of the top-2 ON-frequency buckets.
        //   high corr (keyed together) → one unstable/chirpy signal (RF filter can't fix; sender's quality)
        //   low corr (keyed separately) → two independent stations (QRM; tune/filter away the other)
        if (onHist.size >= 2) {
            val f1 = onHist[0].key + 20; val f2 = onHist[1].key + 20   // bucket centre ≈ key+20
            val e1 = ArrayList<Double>(); val e2 = ArrayList<Double>()
            var j = 0
            while (j + frame <= wav.samples.size) {
                e1.add(goertzel(wav, j, frame, f1)); e2.add(goertzel(wav, j, frame, f2)); j += hop
            }
            val m1 = e1.average(); val m2 = e2.average()
            var cov = 0.0; var v1 = 0.0; var v2 = 0.0
            for (k in e1.indices) { val a = e1[k]-m1; val b = e2[k]-m2; cov += a*b; v1 += a*a; v2 += b*b }
            val corr = if (v1 > 0 && v2 > 0) cov / Math.sqrt(v1 * v2) else 0.0
            println("  [characterize] ${f1}Hz vs ${f2}Hz envelope correlation = %.2f  → %s"
                .format(corr, if (corr > 0.5) "ONE chirpy/drifting signal (filter can't separate; sender quality)"
                              else "TWO independent signals keyed separately (QRM — tune/filter away the other)"))
        }
        val verdict = when {
            onFrac < 0.03 || pct(0.9) < 6.0 -> "NOISE-DOMINATED (no coherent keyed tone) → raise squelch; no threshold recovers copy"
            modeShare > 0.5 && pct(0.9) > 10.0 -> "REAL KEYED TONE present (steady freq) → garble is a DECODER problem"
            else -> "WEAK/FLUTTERY signal (marginal SNR or wandering freq) → borderline; QSB splits elements"
        }
        println("  [characterize] VERDICT: $verdict")
    }

    /** Synthesize a clean CW transmission of [text] at [wpm], [toneHz], [rate], raised-cosine keying
     *  edges (~5ms) and additive white noise to the given peak-signal-to-noise ratio. Ground truth. */
    private fun synthCw(text: String, wpm: Int, toneHz: Int, rate: Int, snr: Double): ShortArray {
        val u = (rate * 1.2 / wpm).toInt()                 // dit length in samples (PARIS: 1200ms/wpm per dit)
        val ramp = (rate * 0.005).toInt().coerceAtLeast(1) // 5ms raised-cosine edge
        val out = ArrayList<Double>()
        repeat((rate * 0.5).toInt()) { out.add(0.0) }      // 0.5s lead-in silence (noise-floor seeding)
        fun key(on: Boolean, len: Int) {
            for (n in 0 until len) {
                var amp = if (on) 1.0 else 0.0
                if (on && n < ramp) amp = 0.5 * (1 - Math.cos(Math.PI * n / ramp))
                if (on && n >= len - ramp) amp = 0.5 * (1 - Math.cos(Math.PI * (len - n) / ramp))
                out.add(amp * Math.sin(2 * Math.PI * toneHz * (out.size) / rate))
            }
        }
        for ((wi, word) in text.split(" ").withIndex()) {
            if (wi > 0) key(false, u * 7)                  // word gap = 7u
            for ((ci, ch) in word.withIndex()) {
                if (ci > 0) key(false, u * 3)              // inter-char gap = 3u
                val code = CwDecoder.CHAR_TO_MORSE[ch.uppercaseChar()] ?: continue
                for ((ei, el) in code.withIndex()) {
                    if (ei > 0) key(false, u)              // intra-char gap = 1u
                    key(true, if (el == '-') u * 3 else u) // dah=3u, dit=1u
                }
            }
        }
        repeat((rate * 1.0).toInt()) { out.add(0.0) }      // 1s trailing silence (flush last char)
        // additive white noise scaled to peak SNR; deterministic (index-seeded) so runs are repeatable
        val noiseAmp = Math.pow(10.0, -snr / 20.0)
        var seed = 12345L
        return ShortArray(out.size) { i ->
            seed = seed * 6364136223846793005L + 1442695040888963407L
            val noise = ((seed ushr 40) / 16777216.0 - 0.5) * 2 * noiseAmp
            ((out[i] + noise) * 9000).toInt().coerceIn(-32768, 32767).toShort()
        }
    }

    /** Levenshtein edit distance between two strings. */
    private fun lev(a: String, b: String): Int {
        val prev = IntArray(b.length + 1) { it }; val cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) cur[j] = minOf(prev[j] + 1, cur[j-1] + 1, prev[j-1] + if (a[i-1]==b[j-1]) 0 else 1)
            System.arraycopy(cur, 0, prev, 0, cur.size)
        }
        return prev[b.length]
    }

    /** Replica of AudioStreamService's CW-decode NR: 3-stage cascaded RBJ bandpass, 90Hz BW each
     *  (~55Hz effective), centred on centerHz. Returns a filtered copy (does not mutate input). */
    private fun applyNr(src: ShortArray, rate: Int, centerHz: Int): ShortArray {
        val stages = 3; val bw = 90.0; val f0 = centerHz.coerceIn(250, 1500).toDouble()
        val w0 = 2 * Math.PI * f0 / rate; val q = f0 / bw
        val alpha = Math.sin(w0) / (2 * q); val cosw = Math.cos(w0); val a0 = 1 + alpha
        val b0 = alpha / a0; val b2 = -alpha / a0; val a1 = -2 * cosw / a0; val a2 = (1 - alpha) / a0
        val z1 = DoubleArray(stages); val z2 = DoubleArray(stages)
        return ShortArray(src.size) { i ->
            var y = src[i].toDouble()
            for (s in 0 until stages) {
                val x = y; val out = b0 * x + z1[s]
                z1[s] = -a1 * out + z2[s]; z2[s] = b2 * x - a2 * out
                y = out
            }
            y.toInt().coerceIn(-32768, 32767).toShort()
        }
    }

    @Test
    fun nrCompare() {
        val truth = "CQ TEST CQ TEST DE ICOM ICOM ICOM TEST"
        // Real ICOM capture (680Hz target + 720Hz QRM) if present, else synthetic 680+720 two-tone.
        val f = locateWav()
        val cases = ArrayList<Pair<String, Wav>>()
        if (f != null) cases.add(f.name to readWav(f))
        // synthetic: target 680 + independent QRM station 720 (different text), both clean
        val rate = 16000
        val tgt = synthCw(truth, 22, 680, rate, 40.0)
        val qrm = synthCw("DE JA1ZZZ UP UP", 24, 720, rate, 40.0)
        val mix = ShortArray(maxOf(tgt.size, qrm.size)) { i ->
            ((if (i < tgt.size) tgt[i].toInt() else 0) + (if (i < qrm.size) qrm[i].toInt() else 0)).coerceIn(-32768, 32767).toShort()
        }
        cases.add("synth 680+720 QRM" to Wav(rate, mix))
        for ((name, wav) in cases) {
            val raw = decode(wav, -1f, 0.064)[0].toString().trim()
            val nr  = decode(Wav(wav.rate, applyNr(wav.samples, wav.rate, 680)), -1f, 0.064)[0].toString().trim()
            println("[$name]")
            println("  RAW       : $raw")
            println("  NR@680Hz  : $nr")
        }
    }

    @Test
    fun synthDebugTiming() {
        val rate = 16000; val wpm = 20
        val trueDit = rate * 1.2 / wpm / (rate * 0.008)   // true dit in HOPS (msPerHop≈8ms @16k)
        println("[debug] wpm=$wpm  true dit ≈ %.1f hops (dah ≈ %.1f)".format(trueDit, trueDit * 3))
        val wav = Wav(rate, synthCw("CQ TEST CQ TEST DE ICOM ICOM ICOM TEST", wpm, 680, rate, 40.0))
        val dec = CwDecoder(wav.rate, 0.064)
        dec.manualNoiseLevel = -1f
        val sb = StringBuilder()
        dec.onCharDecoded = { c, ci, _ -> if (ci == 0) sb.append(c) }
        var k = 0
        dec.onFlushDebug = { durs, gaps, dw ->
            if (k++ < 14) println("  flush#%2d ditWins=%.1f  elems=[%s]  gaps=[%s]".format(
                k, dw, durs.joinToString(","){ "%.1f".format(it) }, gaps.joinToString(","){ "%.1f".format(it) }))
        }
        var i = 0
        while (i < wav.samples.size) { val n = minOf(1024, wav.samples.size - i); dec.processSamples(wav.samples.copyOfRange(i, i+n)); i += n }
        println("  => ch0: ${sb.toString().trim()}")
    }

    @Test
    fun synthClean() {
        val text = "CQ TEST CQ TEST DE ICOM ICOM ICOM TEST"
        val rate = 16000
        println("[synthClean] ground truth: \"$text\" (len=${text.length})")
        var totScore = 0.0; var n = 0
        for (wpm in intArrayOf(15, 20, 25, 30)) {
            for (snr in doubleArrayOf(40.0, 20.0, 12.0)) {
                val wav = Wav(rate, synthCw(text, wpm, 680, rate, snr))
                val got = decode(wav, -1f, 0.064)[0].toString().trim()
                val acc = (1.0 - lev(got, text).toDouble() / maxOf(text.length, got.length)) * 100
                totScore += acc; n++
                println("  wpm=$wpm snr=${snr.toInt()}dB  acc=%.0f%%  ch0: %s".format(acc, got))
            }
        }
        println("[synthClean] MEAN ACCURACY = %.1f%%  (over $n cases)".format(totScore / n))
    }

    /** Fine SNR sweep to find the weak-signal FLOOR of the current decoder. For each WPM, step the
     *  synthesized peak-SNR down and record accuracy, then report the lowest SNR that still copies
     *  ≥90% (clean) and ≥50% (marginal). This is the direct answer to "how weak can it go". */
    @Test
    fun snrFloor() {
        val text = "CQ TEST DE JA1ABC JA1ABC K"
        val rate = 16000
        val snrs = doubleArrayOf(20.0, 12.0, 6.0, 3.0, 0.0, -2.0, -4.0, -6.0, -8.0, -10.0, -12.0, -14.0, -16.0, -18.0)
        println("[snrFloor] ground truth: \"$text\"  (peak-SNR = synthCw param, additive white noise)")
        for (wpm in intArrayOf(18, 25)) {
            println("  --- wpm=$wpm ---")
            var clean90 = Double.NaN; var marg50 = Double.NaN
            for (snr in snrs) {
                val wav = Wav(rate, synthCw(text, wpm, 680, rate, snr))
                val got = decode(wav, -1f, 0.064)[0].toString().trim()
                val acc = (1.0 - lev(got, text).toDouble() / maxOf(text.length, got.length)) * 100
                if (acc >= 90.0 && clean90.isNaN()) clean90 = snr
                if (acc >= 50.0) marg50 = snr   // keep lowering while still ≥50%
                println("    snr=%4.1fdB  acc=%3.0f%%  ch0: %s".format(snr, acc, got))
            }
            println("    => clean(≥90%%) down to %s dB ; marginal(≥50%%) down to %s dB"
                .format(if (clean90.isNaN()) "none" else "%.0f".format(clean90),
                        if (marg50.isNaN()) "none" else "%.0f".format(marg50)))
        }
    }

    /** SAFETY GATE: pure white noise, NO signal. A correct decoder must emit ~nothing here. Counts the
     *  spurious characters (false decodes) per minute at auto/Otsu — the metric that any weak-signal
     *  sensitivity change must NOT worsen. Run before/after a threshold change. */
    @Test
    fun noiseOnly() {
        val rate = 16000
        val secs = 60
        println("[noiseOnly] ${secs}s pure white noise per case (auto/Otsu). Lower = safer (fewer false decodes).")
        // Deterministic white noise at a few absolute levels (amplitude of uniform noise, ×9000 FS like synthCw).
        for (amp in doubleArrayOf(0.05, 0.15, 0.30)) {
            var seed = 98765L + (amp * 1000).toLong()
            val samples = ShortArray(rate * secs) {
                seed = seed * 6364136223846793005L + 1442695040888963407L
                val n = ((seed ushr 40) / 16777216.0 - 0.5) * 2 * amp
                (n * 9000).toInt().coerceIn(-32768, 32767).toShort()
            }
            val out = decode(Wav(rate, samples), -1f, 0.064)
            var nonSpace = 0; var total = 0
            val sb = StringBuilder()
            for (ci in 0 until CwDecoder.N_CHAN) {
                val s = out[ci].toString()
                for (c in s) { total++; if (c != ' ') nonSpace++ }
                if (s.trim().isNotEmpty()) sb.append(" ch$ci=\"${s.trim()}\"")
            }
            println("  noiseAmp=%.2f  falseChars=%d (non-space=%d) = %.1f/min %s"
                .format(amp, total, nonSpace, nonSpace * 60.0 / secs, sb.toString()))
        }
    }

    /** Tradeoff curve for the confidence squelch (charEmitSnrGate). For each gate value, report signal
     *  copy accuracy (moderate 12dB + weak -4dB) AND noise false-chars/min — in ONE run. The sweet spot
     *  is the gate that slashes noise junk while barely denting signal accuracy. gate=0 = current decoder. */
    @Test
    fun emitGateSweep() {
        val rate = 16000
        val sigText = "CQ TEST DE JA1ABC JA1ABC K"
        val sig12 = Wav(rate, synthCw(sigText, 20, 680, rate, 12.0))
        val sigM4 = Wav(rate, synthCw(sigText, 20, 680, rate, -4.0))
        val noiseSecs = 60
        fun noiseWav(amp: Double): Wav {
            var seed = 98765L + (amp * 1000).toLong()
            return Wav(rate, ShortArray(rate * noiseSecs) {
                seed = seed * 6364136223846793005L + 1442695040888963407L
                (((seed ushr 40) / 16777216.0 - 0.5) * 2 * amp * 9000).toInt().coerceIn(-32768, 32767).toShort()
            })
        }
        val noiseCases = doubleArrayOf(0.05, 0.15, 0.30).map { it to noiseWav(it) }
        fun acc(got: String) = (1.0 - lev(got, sigText).toDouble() / maxOf(sigText.length, got.length)) * 100
        fun falseMin(wav: Wav, g: Float): Double {
            val out = decode(wav, -1f, 0.064, emitGate = g)
            var n = 0; for (ci in 0 until CwDecoder.N_CHAN) for (c in out[ci]) if (c != ' ') n++
            return n * 60.0 / noiseSecs
        }
        println("[emitGateSweep] gate | acc@12dB acc@-4dB | noise false-chars/min (amp .05/.15/.30)")
        for (g in floatArrayOf(0f, 2f, 3f, 4f, 5f, 6f, 8f)) {
            val a12 = acc(decode(sig12, -1f, 0.064, emitGate = g)[0].toString().trim())
            val aM4 = acc(decode(sigM4, -1f, 0.064, emitGate = g)[0].toString().trim())
            val fm = noiseCases.map { (_, w) -> falseMin(w, g) }
            println("  gate=%.0f | %3.0f%%    %3.0f%%   | %5.1f / %5.1f / %5.1f"
                .format(g, a12, aM4, fm[0], fm[1], fm[2]))
        }
    }

    /** FLOOR-LOWERING experiment: with the confidence squelch (gate=5) as safety net, sweep the
     *  acquisition gate peakSnrMin DOWN and measure (a) the weak-signal floor (lowest SNR still ≥50%)
     *  and (b) noise false-chars/min. The win case = floor drops below −6 dB while noise stays ~0. */
    @Test
    fun floorSweep() {
        val rate = 16000
        val text = "CQ TEST DE JA1ABC JA1ABC K"
        val snrs = doubleArrayOf(-4.0, -6.0, -8.0, -10.0, -12.0)
        val noiseSecs = 60
        fun noiseWav(amp: Double): Wav {
            var seed = 98765L + (amp * 1000).toLong()
            return Wav(rate, ShortArray(rate * noiseSecs) {
                seed = seed * 6364136223846793005L + 1442695040888963407L
                (((seed ushr 40) / 16777216.0 - 0.5) * 2 * amp * 9000).toInt().coerceIn(-32768, 32767).toShort()
            })
        }
        val n15 = noiseWav(0.15); val n30 = noiseWav(0.30)
        fun acc(got: String) = (1.0 - lev(got, text).toDouble() / maxOf(text.length, got.length)) * 100
        fun floorFor(wpm: Int, psm: Float): String {
            var floor = Double.NaN
            for (snr in snrs) {
                val got = decode(Wav(rate, synthCw(text, wpm, 680, rate, snr)), -1f, 0.064, peakSnrMin = psm)[0].toString().trim()
                if (acc(got) >= 50.0) floor = snr   // snrs descending → keep lowest passing
            }
            return if (floor.isNaN()) ">-4" else "%.0f".format(floor)
        }
        fun falseMin(wav: Wav, psm: Float): Double {
            val out = decode(wav, -1f, 0.064, peakSnrMin = psm)
            var n = 0; for (ci in 0 until CwDecoder.N_CHAN) for (c in out[ci]) if (c != ' ') n++
            return n * 60.0 / noiseSecs
        }
        println("[floorSweep] gate=5 (default) ON. peakSnrMin | floor@18wpm floor@25wpm | noise/min (.15/.30)")
        for (psm in floatArrayOf(5f, 4f, 3f, 2.5f, 2f)) {
            println("  psm=%.1f | %5s dB   %5s dB | %4.1f / %4.1f"
                .format(psm, floorFor(18, psm), floorFor(25, psm), falseMin(n15, psm), falseMin(n30, psm)))
        }
    }

    /** Sweep the confidence squelch on a REAL capture (-Dcwwav) to pick the on-device gate: shows ch0
     *  copy + total non-space chars across all channels (junk-volume proxy) at each gate. Want: trailing/
     *  leading junk shrinks while the real message stays intact. */
    @Test
    fun gateOnWav() {
        val f = locateWav()
        if (f == null) { println("[gateOnWav] no -Dcwwav — skipping"); return }
        val wav = readWav(f)
        println("[gateOnWav] ${f.name}: ${"%.1f".format(wav.samples.size / wav.rate.toFloat())}s  (ch0 = main display)")
        for (g in floatArrayOf(0f, 5f, 6f, 8f, 10f)) {
            val out = decode(wav, -1f, 0.064, emitGate = g)
            var tot = 0; for (ci in 0 until CwDecoder.N_CHAN) for (c in out[ci]) if (c != ' ') tot++
            println("  gate=%2.0f  totalNonSpace=%-4d  ch0: %s".format(g, tot, out[0].toString().trim()))
        }
    }

    @Test
    fun replay() {
        val f = locateWav()
        if (f == null) {
            println("[CwReplay] no WAV (set -Dcwwav=/path or drop app/src/test/resources/cw_rx_diag.wav) — skipping")
            return
        }
        val wav = readWav(f)
        println("[CwReplay] ${f.name}: ${wav.rate} Hz, ${wav.samples.size} samples (${"%.1f".format(wav.samples.size / wav.rate.toFloat())} s)")
        run {
            // Raw-waveform health: clipping/overdrive or a DC offset upstream corrupts the keying
            // envelope before the decoder ever sees it (ragged envelope on a 'clean' signal = audio path).
            var peak = 0; var clip = 0L; var sumSq = 0.0; var sum = 0.0
            for (s in wav.samples) {
                val a = kotlin.math.abs(s.toInt())
                if (a > peak) peak = a
                if (a >= 32000) clip++
                sumSq += s.toDouble() * s; sum += s
            }
            val rms = Math.sqrt(sumSq / wav.samples.size)
            val dc = sum / wav.samples.size
            println("[CwReplay] raw: peak=$peak (%.0f%% FS)  clip≥32000=%.2f%%  RMS=%.0f  crest=%.1f  DC=%.0f"
                .format(peak * 100.0 / 32768, clip * 100.0 / wav.samples.size, rms, if (rms > 0) peak / rms else 0.0, dc))
        }
        characterize(wav)
        println("=".repeat(72))

        // -1 = auto (Otsu). 0.0..0.5 = manual squelch gain above the noise floor (higher = more
        // noise rejection but drops weaker signals). This is the real "受信しきい値" knob.
        // windowMs: 0.064 = default (fast keying); 0.128 = wide/HF (averages QSB/flutter that over-splits).
        val levels  = floatArrayOf(-1f, 0.0f, 0.15f, 0.20f, 0.25f, 0.30f, 0.35f, 0.50f)
        val windows = doubleArrayOf(0.064, 0.128)
        for (win in windows) {
            println("windowMs=$win  (${if (win <= 0.064) "default/fast" else "wide/HF"})")
            for (lv in levels) {
                val out = decode(wav, lv, win)
                val tag = if (lv < 0) "auto " else "%.2f ".format(lv)
                println("  noiseLevel=$tag ch0: ${out[0].toString().trim()}")
                for (ci in 1 until CwDecoder.N_CHAN) {
                    val s = out[ci].toString().trim()
                    if (s.isNotEmpty()) println("                    ch$ci: $s")
                }
            }
            println("=".repeat(72))
        }

        // ch0 char:code stream at default window / auto — shows WHERE segmentation collapses.
        val codes = ArrayList<Pair<Char, String>>()
        decode(wav, -1f, 0.064, codes)
        println("ch0 char:code stream (windowMs=0.064, auto):")
        println("  " + codes.joinToString(" ") { (c, code) -> if (code.isEmpty()) "/" else "$c:$code" })
        println("ch0 freq hops (Hz; ×=channel dropped):")
        println("  " + (ch0FreqHops?.toString()?.trim() ?: "-"))

        // Keying-envelope view of the dominant tone: clean CW (crisp on/off) vs messy (QSB/flutter).
        // If the envelope is crisp but ch0 garbles, the DECODER has fixable room; if ragged, the
        // signal itself limits the ceiling. Self-contained: find the strongest CW-band tone, then
        // print its Goertzel power per 16ms frame thresholded at its own midpoint.
        for (probeF in intArrayOf(680, 720)) {
            val fr = (wav.rate * 0.016).toInt()
            val env = ArrayList<Double>()
            var pp = 0
            while (pp + fr <= wav.samples.size) { env.add(Math.sqrt(goertzel(wav, pp, fr, probeF))); pp += fr }
            if (env.isNotEmpty()) {
                val mx = env.max(); val loFloor = env.sorted()[(env.size * 0.2).toInt()]
                val thr = loFloor + (mx - loFloor) * 0.4
                println("keying envelope @ ${probeF}Hz (#=key-down +=marginal .=up, 16ms/char):")
                env.map { when { it > thr -> '#'; it > thr * 0.6 -> '+'; else -> '.' } }
                    .joinToString("").chunked(120).take(6).forEach { println("  $it") }
            }
        }
    }
}
