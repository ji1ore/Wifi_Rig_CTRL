import Foundation
import Compression

/// 近傍/全件 D-STARレピータ候補 (Android DstarRepeater のiOS版)。CS-705形式CSV(Icom/RepeaterBook)。
struct DstarRepeater: Identifiable {
    let id = UUID()
    let callsign: String          // 日本語名(CSV Name列) or R1
    let lat: Double
    let lon: Double
    let freqMHz: Double
    var distKm: Double
    let r1Override: String?       // Repeater Call Sign (例 "JP1YIU A")
    let r2Override: String?       // Gateway Call Sign (例 "JP1YIU G")
    let dupDir: String            // "+" / "-" / ""
    let offsetHz: Int64

    var port: String {
        switch freqMHz {
        case 1200.0...1400.0: return "A"
        case 400.0...500.0:   return "B"
        case 140.0...150.0:   return "C"
        default:              return "B"
        }
    }
    var r1: String {
        if let o = r1Override?.trimmingCharacters(in: .whitespaces), !o.isEmpty { return o }
        return String(callsign.prefix(7)).padding(toLength: 7, withPad: " ", startingAt: 0) + port
    }
    var r2: String {
        if let o = r2Override?.trimmingCharacters(in: .whitespaces), !o.isEmpty { return o }
        return String(callsign.prefix(7)).padding(toLength: 7, withPad: " ", startingAt: 0) + "G"
    }
    var label: String { String(format: "%@  %.0fkm  %.4fMHz", callsign.isEmpty ? r1 : callsign, distKm, freqMHz) }
    var listLabel: String { String(format: "%@  %@  %.4fMHz", r1.trimmingCharacters(in: .whitespaces), callsign, freqMHz) }
}

enum DstarCsv {
    /// Icom配布のZIP(PK)からレピータリストの .csv を取り出す。非ZIP/失敗はnil。
    /// Icom配布ZIPには GPSメモリCSV / レピータリストCSV / RepMoni_sample.csv など複数のCSVが同梱されるため、
    /// 「最初の.csv」ではなく、ファイル名に rpt/repeater を含むものを優先し、実際にレピータとして
    /// パースできたエントリを採用する(GPS CSVを誤って取り込むと0件になる)。
    static func extractCsvIfZip(_ data: Data) -> Data? {
        let entries = extractCsvEntriesIfZip(data)
        guard !entries.isEmpty else { return nil }
        // 名前優先(rpt/repeater) → それ以外 の順に試し、レピータ行が1件以上取れた最初のCSVを返す
        func isRptName(_ n: String) -> Bool { n.contains("rpt") || n.contains("repeater") }
        let ordered = entries.filter { isRptName($0.name) } + entries.filter { !isRptName($0.name) }
        if let hit = ordered.first(where: { !parseAll(data: $0.data).isEmpty }) { return hit.data }
        // どれもパースできなければ、名前優先の先頭(従来互換)を返す
        return ordered.first?.data
    }

    /// ZIP内の全 .csv エントリ(名前は小文字)を展開して返す。
    /// 中央ディレクトリ(ファイル末尾)から読む → データ記述子形式(ローカルヘッダのサイズ=0)のzipでも確実。
    /// method 0=stored / 8=deflate(Compressionの生DEFLATE RFC1951)を展開。
    private static func extractCsvEntriesIfZip(_ data: Data) -> [(name: String, data: Data)] {
        var out: [(name: String, data: Data)] = []
        let b = [UInt8](data)
        guard b.count > 22, b[0] == 0x50, b[1] == 0x4B else { return out }   // "PK"
        func u16(_ o: Int) -> Int { Int(b[o]) | (Int(b[o+1]) << 8) }
        func u32(_ o: Int) -> Int { Int(b[o]) | (Int(b[o+1]) << 8) | (Int(b[o+2]) << 16) | (Int(b[o+3]) << 24) }
        // EOCD(PK\x05\x06)を末尾から探す(コメント最大65535)
        var eocd = -1
        var i = b.count - 22
        let minI = max(0, b.count - 22 - 65535)
        while i >= minI { if b[i] == 0x50 && b[i+1] == 0x4B && b[i+2] == 0x05 && b[i+3] == 0x06 { eocd = i; break }; i -= 1 }
        guard eocd >= 0 else { return out }
        let cdCount = u16(eocd + 10)
        var cd = u32(eocd + 16)   // 中央ディレクトリ先頭
        var n = 0
        while n < cdCount, cd + 46 <= b.count, b[cd] == 0x50, b[cd+1] == 0x4B, b[cd+2] == 0x01, b[cd+3] == 0x02 {
            let method = u16(cd + 10)
            let compSize = u32(cd + 20)
            let uncompSize = u32(cd + 24)
            let nameLen = u16(cd + 28)
            let extraLen = u16(cd + 30)
            let commentLen = u16(cd + 32)
            let lho = u32(cd + 42)   // ローカルヘッダのオフセット
            // ファイル名はASCII想定だが、日本語名(UTF-8/CP932)でも拡張子判定だけはできるようisoLatin1で確実に文字列化
            let nameBytes = (cd + 46 + nameLen <= b.count) ? Array(b[(cd+46)..<(cd+46+nameLen)]) : []
            let name = (String(bytes: nameBytes, encoding: .utf8) ?? String(bytes: nameBytes, encoding: .isoLatin1) ?? "").lowercased()
            // ディレクトリ(末尾"/")や Mac のリソースフォーク(__MACOSX/._xxx)は除外
            let isJunk = name.hasPrefix("__macosx/") || (name.split(separator: "/").last?.hasPrefix("._") ?? false)
            if name.hasSuffix(".csv"), !isJunk, lho + 30 <= b.count, b[lho] == 0x50, b[lho+1] == 0x4B {
                let lNameLen = u16(lho + 26)
                let lExtraLen = u16(lho + 28)
                let dataStart = lho + 30 + lNameLen + lExtraLen
                if compSize > 0, dataStart + compSize <= b.count {
                    let comp = Data(b[dataStart..<dataStart+compSize])
                    if method == 0 { out.append((name, comp)) }
                    else if method == 8, let inflated = rawInflate(comp, cap: uncompSize) { out.append((name, inflated)) }
                }
            }
            cd += 46 + nameLen + extraLen + commentLen
            n += 1
        }
        return out
    }
    private static func rawInflate(_ src: Data, cap: Int) -> Data? {
        let dstCap = max(cap, 65536)
        var dst = Data(count: dstCap)
        let n = dst.withUnsafeMutableBytes { (dp: UnsafeMutableRawBufferPointer) -> Int in
            src.withUnsafeBytes { (sp: UnsafeRawBufferPointer) -> Int in
                compression_decode_buffer(dp.bindMemory(to: UInt8.self).baseAddress!, dstCap,
                                          sp.bindMemory(to: UInt8.self).baseAddress!, src.count,
                                          nil, COMPRESSION_ZLIB)   // Apple COMPRESSION_ZLIB = 生DEFLATE(RFC1951)
            }
        }
        guard n > 0 else { return nil }
        return dst.prefix(n)
    }

    static func haversineKm(_ lat1: Double, _ lon1: Double, _ lat2: Double, _ lon2: Double) -> Double {
        let dLat = (lat2 - lat1) * .pi / 180, dLon = (lon2 - lon1) * .pi / 180
        let a = sin(dLat/2)*sin(dLat/2) + cos(lat1 * .pi/180)*cos(lat2 * .pi/180)*sin(dLon/2)*sin(dLon/2)
        return 6371.0 * 2 * atan2(sqrt(a), sqrt(1 - a))
    }
    private static func splitCsvLine(_ line: String) -> [String] {
        var res: [String] = []; var sb = ""; var q = false
        for c in line {
            if c == "\"" { q.toggle() }
            else if c == "," && !q { res.append(sb); sb = "" }
            else { sb.append(c) }
        }
        res.append(sb); return res
    }
    /// UTF-8厳密→失敗ならShift-JIS(CP932)でデコード(Icom CSVは日本語Shift-JIS)。
    private static func decode(_ data: Data) -> String? {
        if let s = String(data: data, encoding: .utf8) { return s }
        if let s = String(data: data, encoding: .shiftJIS) { return s }
        let cp932 = CFStringConvertEncodingToNSStringEncoding(CFStringEncoding(CFStringEncodings.dosJapanese.rawValue))
        return String(data: data, encoding: String.Encoding(rawValue: cp932))
    }

    /// 全レピータをパース(距離は0)。
    static func parseAll(_ url: URL) -> [DstarRepeater] {
        guard let data = try? Data(contentsOf: url) else { return [] }
        return parseAll(data: data)
    }
    /// CSVバイト列から全レピータをパース(距離は0)。英語ヘッダ(CS-705/RepeaterBook)と日本語ヘッダの両方に対応。
    static func parseAll(data: Data) -> [DstarRepeater] {
        guard let text = decode(data) else { return [] }
        var out: [DstarRepeater] = []
        var r1i = -1, r2i = -1, fi = -1, lai = -1, loi = -1, ni = -1, di = -1, oi = -1, header = false
        // 改行は \r\n / \n / \r(単独) のいずれも許容
        let normalized = text.replacingOccurrences(of: "\r\n", with: "\n").replacingOccurrences(of: "\r", with: "\n")
        for raw in normalized.split(separator: "\n", omittingEmptySubsequences: false) {
            let line = String(raw)
            let cols = splitCsvLine(line)
            if !header {
                // BOM(U+FEFF)が先頭セルに付くことがあるので除去してから比較
                let low = cols.map { $0.replacingOccurrences(of: "\u{FEFF}", with: "").trimmingCharacters(in: .whitespaces).lowercased() }
                let hasLat = low.contains { $0.contains("lat") || $0.contains("緯度") }
                let hasLon = low.contains { $0.contains("lon") || $0.contains("lng") || $0.contains("経度") }
                if hasLat && hasLon {
                    func idx(_ pred: (String) -> Bool) -> Int { low.firstIndex(where: pred) ?? -1 }
                    r1i = idx { ($0.contains("repeater") && $0.contains("call")) || $0.contains("レピータコール") || $0.contains("レピーターコール") }
                    r2i = idx { ($0.contains("gateway") && $0.contains("call")) || $0.contains("ゲートウェイ") }
                    fi  = idx { $0.contains("frequency") || $0 == "freq" || $0.contains("周波数") }
                    lai = idx { $0.contains("lat") || $0.contains("緯度") }
                    loi = idx { $0.contains("lon") || $0.contains("lng") || $0.contains("経度") }
                    ni  = idx { $0 == "name" || $0.contains("sub name") || $0 == "名称" || $0 == "レピータネーム" || $0.contains("サブネーム") }
                    di  = idx { $0 == "dup" || $0.contains("duplex") }
                    oi  = idx { $0 == "offset" || $0.contains("offset") || $0.contains("オフセット") }
                    // 緯度経度だけのGPSメモリCSVを誤認しないよう、周波数かレピータコール列のどちらかを必須にする
                    if fi >= 0 || r1i >= 0 { header = true }
                }
                continue
            }
            if lai < 0 || loi < 0 || cols.count <= max(lai, loi) { continue }
            guard let la = Double(cols[lai].trimmingCharacters(in: .whitespaces)),
                  let lo = Double(cols[loi].trimmingCharacters(in: .whitespaces)) else { continue }
            func col(_ i: Int) -> String { (i >= 0 && i < cols.count) ? cols[i].trimmingCharacters(in: .whitespaces) : "" }
            let r1 = col(r1i), r2 = col(r2i), nm = col(ni)
            let fr = Double(col(fi)) ?? 0.0
            let dupRaw = col(di).uppercased()
            let dupDir = dupRaw.contains("+") ? "+" : (dupRaw.contains("-") ? "-" : "")
            let offHz = Int64((Double(col(oi)) ?? 0.0) * 1_000_000.0)
            if r1.isEmpty && nm.isEmpty { continue }
            out.append(DstarRepeater(callsign: nm.isEmpty ? r1 : nm, lat: la, lon: lo, freqMHz: fr,
                                     distKm: 0, r1Override: r1, r2Override: r2, dupDir: dupDir, offsetHz: offHz))
        }
        return out
    }
    /// 近傍(現在地の近い順, 60件)。
    static func loadNearby(_ url: URL, lat: Double, lon: Double) -> [DstarRepeater] {
        parseAll(url).map { var r = $0; r.distKm = haversineKm(lat, lon, r.lat, r.lon); return r }
            .sorted { $0.distKm < $1.distKm }.prefix(60).map { $0 }
    }
    /// 全件(現在地無視, コール順)。繋ぎ先選択用。
    static func loadAll(_ url: URL) -> [DstarRepeater] {
        parseAll(url).sorted { ($0.r1Override ?? $0.callsign) < ($1.r1Override ?? $1.callsign) }
    }
}
