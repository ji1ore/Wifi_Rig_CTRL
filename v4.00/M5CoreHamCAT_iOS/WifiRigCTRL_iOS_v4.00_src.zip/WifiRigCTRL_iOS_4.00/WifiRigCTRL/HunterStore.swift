import Foundation
import Observation

// Per-park hunt record. Mirrors Android's HunterPark (ref + locationDesc + qsos).
struct HunterPark: Codable {
    var reference: String
    var locationDesc: String   // "short" in POTA API  (e.g. "JP-TK")
    var qsos: Int
}

@MainActor
@Observable
final class HunterStore {
    private(set) var parkCount: Int = 0
    private var cache: Set<String> = []
    private let storeURL: URL

    init() {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        storeURL = docs.appendingPathComponent("pota_hunter_parks.json")
        load()
    }

    func isHunted(_ reference: String) -> Bool {
        cache.contains(reference.uppercased())
    }

    // Import from /hunter/{callsign} or /user/logbook JSON.
    // Each element should have "reference" (required), "short" (locationDesc), "qsos".
    // parkCount mirrors Android: number of input entries (not unique refs).
    @discardableResult
    func importFromApiJson(_ json: String) -> Int {
        guard let data = json.data(using: .utf8),
              let arr = (try? JSONSerialization.jsonObject(with: data)) as? [[String: Any]] else { return 0 }

        var parks: [HunterPark] = []
        var newCache = Set<String>()

        for entry in arr {
            guard let ref = (entry["reference"] as? String)?.uppercased(), !ref.isEmpty else { continue }
            let loc  = entry["short"] as? String ?? ""
            let qsos = (entry["qsos"] as? Int) ?? Int((entry["qsos"] as? Double) ?? 0)
            parks.append(HunterPark(reference: ref, locationDesc: loc, qsos: qsos))
            newCache.insert(ref)
            if !loc.isEmpty {
                // Store "JP-0014|JP-TK" so future location-specific checks can work
                newCache.insert("\(ref)|\(loc)")
                // Handle comma-separated multi-location ("JP-TK,JP-KN")
                if loc.contains(",") {
                    for part in loc.split(separator: ",").map({ $0.trimmingCharacters(in: .whitespaces) }) where !part.isEmpty {
                        newCache.insert("\(ref)|\(part)")
                    }
                }
            }
        }

        guard !parks.isEmpty else { return 0 }
        cache = newCache
        parkCount = parks.count     // matches Android: parks.size
        save(parks)
        return parkCount
    }

    // Import from SP2Alert's shared hunter_parks.json (array of its HunterPark).
    // SP2Alert names the location field "hasc"; POTA API uses "short". Accept both.
    @discardableResult
    func importFromSp2alertJson(_ json: String) -> Int {
        guard let data = json.data(using: .utf8),
              let arr = (try? JSONSerialization.jsonObject(with: data)) as? [[String: Any]] else { return 0 }

        var parks: [HunterPark] = []
        var newCache = Set<String>()

        for entry in arr {
            guard let ref = (entry["reference"] as? String)?.uppercased(), !ref.isEmpty else { continue }
            let loc  = (entry["hasc"] as? String) ?? (entry["short"] as? String) ?? ""
            let qsos = (entry["qsos"] as? Int) ?? Int((entry["qsos"] as? Double) ?? 0)
            parks.append(HunterPark(reference: ref, locationDesc: loc, qsos: qsos))
            newCache.insert(ref)
            if !loc.isEmpty {
                newCache.insert("\(ref)|\(loc)")
                if loc.contains(",") {
                    for part in loc.split(separator: ",").map({ $0.trimmingCharacters(in: .whitespaces) }) where !part.isEmpty {
                        newCache.insert("\(ref)|\(part)")
                    }
                }
            }
        }

        guard !parks.isEmpty else { return 0 }
        cache = newCache
        parkCount = parks.count
        save(parks)
        return parkCount
    }

    private func save(_ parks: [HunterPark]) {
        if let data = try? JSONEncoder().encode(parks) {
            try? data.write(to: storeURL)
        }
    }

    private func load() {
        // Try new Codable format first
        if let data = try? Data(contentsOf: storeURL),
           let parks = try? JSONDecoder().decode([HunterPark].self, from: data) {
            cache = buildCache(parks)
            parkCount = parks.count
            return
        }
        // Legacy fallback: old format was [{"reference":"JP-0001"}]
        if let data = try? Data(contentsOf: storeURL),
           let arr = (try? JSONSerialization.jsonObject(with: data)) as? [[String: Any]] {
            let parks = arr.compactMap { entry -> HunterPark? in
                guard let ref = (entry["reference"] as? String)?.uppercased(), !ref.isEmpty else { return nil }
                return HunterPark(reference: ref, locationDesc: entry["short"] as? String ?? "", qsos: 0)
            }
            cache = buildCache(parks)
            parkCount = parks.count
        }
    }

    private func buildCache(_ parks: [HunterPark]) -> Set<String> {
        var set = Set<String>()
        for p in parks {
            set.insert(p.reference)
            if !p.locationDesc.isEmpty {
                set.insert("\(p.reference)|\(p.locationDesc)")
                if p.locationDesc.contains(",") {
                    for part in p.locationDesc.split(separator: ",").map({ $0.trimmingCharacters(in: .whitespaces) }) where !part.isEmpty {
                        set.insert("\(p.reference)|\(part)")
                    }
                }
            }
        }
        return set
    }
}

// MARK: - SOTA chase log

// Mirrors Android's SotaChaseStore. Stores chased summit refs in sota_chased.json
// (JSON string array), same format SP2Alert uses.
@MainActor
@Observable
final class SotaChaseStore {
    private(set) var chasedCount: Int = 0
    private var cache: Set<String> = []
    private let storeURL: URL

    init() {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        storeURL = docs.appendingPathComponent("sota_chased.json")
        load()
    }

    func isChased(_ summitRef: String) -> Bool { cache.contains(summitRef.uppercased()) }

    // Import SP2Alert's sota_chased.json (JSON array of summit-ref strings).
    @discardableResult
    func importFromJson(_ json: String) -> Int {
        guard let data = json.data(using: .utf8),
              let list = (try? JSONDecoder().decode([String].self, from: data)) else { return 0 }
        let set = Set(list.map { $0.trimmingCharacters(in: .whitespaces).uppercased() }.filter { !$0.isEmpty })
        cache = set
        chasedCount = set.count
        save()
        return set.count
    }

    private func save() {
        if let data = try? JSONEncoder().encode(Array(cache)) { try? data.write(to: storeURL) }
    }

    private func load() {
        guard let data = try? Data(contentsOf: storeURL),
              let list = try? JSONDecoder().decode([String].self, from: data) else { return }
        cache = Set(list.map { $0.uppercased() })
        chasedCount = cache.count
    }
}

// MARK: - SP2Alert cross-app log importer (App Group)

// Reads POTA hunt / SOTA chase logs that SP2Alert mirrors into the shared App Group
// container and imports them into the local stores.
enum Sp2alertLogImporter {
    static let groupID = "group.com.ji1ore.sp2alart"

    struct Result { let available: Bool; let pota: Int; let sota: Int }

    @MainActor
    @discardableResult
    static func importAll(hunter: HunterStore, sota: SotaChaseStore) -> Result {
        guard let dir = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: groupID) else {
            return Result(available: false, pota: 0, sota: 0)
        }
        let potaURL = dir.appendingPathComponent("hunter_parks.json")
        let sotaURL = dir.appendingPathComponent("sota_chased.json")
        let fm = FileManager.default
        let hasPota = fm.fileExists(atPath: potaURL.path)
        let hasSota = fm.fileExists(atPath: sotaURL.path)
        guard hasPota || hasSota else { return Result(available: false, pota: 0, sota: 0) }

        var p = 0, s = 0
        if let data = try? Data(contentsOf: potaURL), let json = String(data: data, encoding: .utf8) {
            p = hunter.importFromSp2alertJson(json)
        }
        if let data = try? Data(contentsOf: sotaURL), let json = String(data: data, encoding: .utf8) {
            s = sota.importFromJson(json)
        }
        return Result(available: true, pota: p, sota: s)
    }
}
