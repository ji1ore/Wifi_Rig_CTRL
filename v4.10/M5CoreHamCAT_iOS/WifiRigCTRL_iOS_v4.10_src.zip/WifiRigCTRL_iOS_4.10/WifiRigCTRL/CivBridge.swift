import Foundation
import Network

/// 生CI-V/TCPブリッジ・クライアント (Android CivBridgeService のiOS版)。
/// Pi api.py の /radio/civ_bridge が D-STAR運用中だけ rigctld を止めてリグのUSBシリアルを生CI-VのTCP
/// (ポート14652)として公開する。本クラスはそこへ直接CI-Vフレームを送受信し、rigctld非経由で D-STAR 制御
/// (DR/UR/R1/R2)と受信コール(20 00 02)/メッセージ(20 01 02)のポーリングを行う。
/// フレーム/body形式は CivService と同一(body=[dest,src,cmd,...])。exchange は同期(背景キューから呼ぶ)。
final class CivBridge {
    private static let ctrlAddr = 0xE0
    var rigAddr = 0xA4
    private(set) var isConnected = false

    private var conn: NWConnection?
    private let netQ = DispatchQueue(label: "civbridge.net")
    private let exLock = NSLock()      // exchangeを直列化
    private let rxLock = NSLock()
    private var rxBuf: [UInt8] = []
    private var frames: [[UInt8]] = [] // 完成フレーム(FE FE .. FD)

    // MARK: 接続
    func connect(host: String, port: Int) -> Bool {
        disconnect()
        guard let p = NWEndpoint.Port(rawValue: UInt16(port)) else { return false }
        let c = NWConnection(host: NWEndpoint.Host(host), port: p, using: .tcp)
        let sem = DispatchSemaphore(value: 0)
        var ok = false
        c.stateUpdateHandler = { st in
            switch st {
            case .ready: ok = true; sem.signal()
            case .failed, .cancelled: ok = false; sem.signal()
            default: break
            }
        }
        conn = c
        c.start(queue: netQ)
        _ = sem.wait(timeout: .now() + 3.0)
        if ok { isConnected = true; startReceive() }
        else { disconnect() }
        return ok
    }

    func disconnect() {
        isConnected = false
        conn?.cancel(); conn = nil
        rxLock.lock(); rxBuf.removeAll(); frames.removeAll(); rxLock.unlock()
    }

    private func startReceive() {
        conn?.receive(minimumIncompleteLength: 1, maximumLength: 2048) { [weak self] data, _, isComplete, err in
            guard let self = self else { return }
            if let d = data, !d.isEmpty { self.accumulate([UInt8](d)) }
            if err != nil || isComplete { self.isConnected = false; return }
            self.startReceive()
        }
    }

    private func accumulate(_ bytes: [UInt8]) {
        rxLock.lock(); defer { rxLock.unlock() }
        rxBuf.append(contentsOf: bytes)
        // FE FE .. FD 単位に切り出す
        while let fd = rxBuf.firstIndex(of: 0xFD) {
            let frame = Array(rxBuf[0...fd])
            rxBuf.removeSubrange(0...fd)
            if frame.count >= 5 && frame[0] == 0xFE && frame[1] == 0xFE { frames.append(frame) }
            if rxBuf.count > 4096 { rxBuf.removeAll() }
        }
    }

    // MARK: フレーム/exchange
    private func buildFrame(_ body: [Int]) -> [UInt8] {
        ([0xFE, 0xFE, rigAddr, Self.ctrlAddr] + body + [0xFD]).map { UInt8($0 & 0xFF) }
    }

    /// cmd(とsubCmd)に一致する応答bodyを返す。書込は cmd:0xFB。タイムアウトでnil。同期(背景で呼ぶ)。
    private func exchange(_ body: [Int], cmd: Int, subCmd: Int = -1, timeoutMs: Int = 1200) -> [UInt8]? {
        exLock.lock(); defer { exLock.unlock() }
        guard isConnected, let conn = conn else { return nil }
        rxLock.lock(); frames.removeAll(); rxBuf.removeAll(); rxLock.unlock()
        conn.send(content: Data(buildFrame(body)), completion: .contentProcessed { _ in })
        let deadline = Date().addingTimeInterval(Double(timeoutMs) / 1000.0)
        while Date() < deadline {
            rxLock.lock()
            let f: [UInt8]? = frames.isEmpty ? nil : frames.removeFirst()
            rxLock.unlock()
            if let f = f, let b = extractBody(f, cmd: cmd, subCmd: subCmd) { return b }
            if f == nil { Thread.sleep(forTimeInterval: 0.02) }
        }
        return nil
    }

    // body = [dest,src,cmd,...]。自分のエコー/transceive は dest/src で弾く。
    private func extractBody(_ frame: [UInt8], cmd: Int, subCmd: Int) -> [UInt8]? {
        guard frame.count >= 5, frame[0] == 0xFE, frame[1] == 0xFE else { return nil }
        guard Int(frame[2]) == Self.ctrlAddr, Int(frame[3]) == rigAddr else { return nil }
        guard Int(frame[4]) == cmd else { return nil }
        if subCmd >= 0 { guard frame.count >= 6, Int(frame[5]) == subCmd else { return nil } }
        return Array(frame[2..<(frame.count - 1)])
    }

    // MARK: ヘルパ
    private func ascii(_ s: String, _ n: Int) -> [Int] {
        let up = Array(s.uppercased().utf8)
        return (0..<n).map { i -> Int in
            let c = i < up.count ? Int(up[i]) : 0x20
            return (c >= 0x20 && c <= 0x5A) || (c >= 0x30 && c <= 0x39) ? c : 0x20
        }
    }
    private func msgAscii(_ s: String, _ n: Int) -> [Int] {
        let u = Array(s.utf8)
        return (0..<n).map { i -> Int in let c = i < u.count ? Int(u[i]) : 0x20; return (c >= 0x20 && c <= 0x7E) ? c : 0x20 }
    }
    private func dvCall8(_ s: String) -> [Int] {
        let up = Array(s.uppercased().utf8)
        return (0..<8).map { i -> Int in
            let c = i < up.count ? Int(up[i]) : 0x20
            return (c >= 0x30 && c <= 0x39) || (c >= 0x41 && c <= 0x5A) || c == 0x20 || c == 0x2F ? c : 0x20
        }
    }
    private func bcd5(_ hz: Int64) -> [Int] { var f = hz; return (0..<5).map { _ in let lo = Int(f % 10); f /= 10; let hi = Int(f % 10); f /= 10; return (hi << 4) | lo } }

    // MARK: Freq / PTT / Mode
    func getFrequency() -> Int64? {
        guard let r = exchange([0x03], cmd: 0x03), r.count >= 8 else { return nil }
        var freq: Int64 = 0; var mult: Int64 = 1
        for i in 3..<8 { let b = Int(r[i]); freq += Int64(b & 0xF) * mult; mult *= 10; freq += Int64(b >> 4) * mult; mult *= 10 }
        return freq
    }
    @discardableResult func setFrequency(_ hz: Int64) -> Bool { exchange([0x05] + bcd5(hz), cmd: 0xFB) != nil }
    @discardableResult func setPtt(_ on: Bool) -> Bool { exchange([0x1C, 0x00, on ? 0x01 : 0x00], cmd: 0xFB) != nil }
    @discardableResult func setDvMode() -> Bool { exchange([0x06, 0x17], cmd: 0xFB) != nil }

    // MARK: D-STAR routing
    @discardableResult func setDvCallSigns(ur: String, r1: String, r2: String) -> Bool {
        exchange([0x1F, 0x01] + dvCall8(ur) + dvCall8(r1) + dvCall8(r2), cmd: 0xFB) != nil
    }
    func readDvCallSigns() -> (ur: String, r1: String, r2: String)? {
        guard let b = exchange([0x1F, 0x01], cmd: 0x1F, subCmd: 0x01), b.count >= 4 + 24 else { return nil }
        func f(_ o: Int) -> String { (String(bytes: b[(4 + o)..<(4 + o + 8)], encoding: .ascii) ?? "").trimmingCharacters(in: .whitespaces) }
        return (f(0), f(8), f(16))
    }
    /// シンプレックス一括(VFO→DV→freq→DUP OFF→1F 01 CQCQCQ)
    @discardableResult func setupDvSimplex(ur: String, freqHz: Int64) -> Bool {
        _ = exchange([0x07, 0x00], cmd: 0xFB)
        _ = exchange([0x06, 0x17], cmd: 0xFB)
        if freqHz > 0 { _ = setFrequency(freqHz) }
        _ = exchange([0x0F, 0x00], cmd: 0xFB)
        return setDvCallSigns(ur: ur, r1: "", r2: "")
    }
    // MARK: MyCall / Message / RX
    @discardableResult func setMyCall(call: String, note: String) -> Bool {
        exchange([0x1F, 0x00] + ascii(call, 8) + ascii(note, 4), cmd: 0xFB) != nil
    }
    @discardableResult func setTxMessage(_ msg: String) -> Bool {
        msg.isEmpty ? (exchange([0x1F, 0x02, 0xFF], cmd: 0xFB) != nil)
                    : (exchange([0x1F, 0x02] + msgAscii(msg, 20), cmd: 0xFB) != nil)
    }
    func readDvRxCallSigns() -> (caller: String, called: String)? {
        guard let b = exchange([0x20, 0x00, 0x02], cmd: 0x20, subCmd: 0x00) else { return nil }
        let d = 5; guard b.count >= d + 2 + 8 + 4 + 8 else { return nil }
        func f(_ o: Int) -> String { (String(bytes: b[(d + o)..<(d + o + 8)], encoding: .ascii) ?? "").trimmingCharacters(in: .whitespaces) }
        return (f(2), f(2 + 8 + 4))
    }
    func readDvRxMessage() -> String? {
        guard let b = exchange([0x20, 0x01, 0x02], cmd: 0x20, subCmd: 0x01) else { return nil }
        let d = 5; guard b.count >= d + 20 else { return nil }
        if b[d] == 0xFF { return "" }
        var s = ""; for i in 0..<20 { let c = Int(b[d + i]); if c >= 0x20 && c <= 0x7E { s.append(Character(UnicodeScalar(c)!)) } }
        return s.trimmingCharacters(in: .whitespaces)
    }
    /// Sメーター(CI-V 15 02)。hamlibはDVでSTRENGTHを返さないため、ブリッジ経路ではこれで信号を得る。0..255。
    func getSmeterRaw() -> Int? {
        guard let b = exchange([0x15, 0x02], cmd: 0x15, subCmd: 0x02), b.count >= 6 else { return nil }
        return (Int(b[4] & 0x0F) * 100) + (Int(b[5] & 0xF0) >> 4) * 10 + Int(b[5] & 0x0F)
    }
}
