import SwiftUI
import UniformTypeIdentifiers

/// D-STAR UR/R1/R2 + MyCall/メッセージ + レピータ選択/繋ぎ先 + CI-Vブリッジ 設定シート (Android showDstarSettings 相当)。
struct DstarSettingsView: View {
    @Bindable var vm: MainViewModel
    @Environment(\.dismiss) private var dismiss

    @State private var ur = ""
    @State private var r1 = ""
    @State private var r2 = ""
    @State private var myCall = ""
    @State private var txMsg = ""
    @State private var showImporter = false
    @State private var showNearby = false
    @State private var showAll = false
    @State private var nearby: [DstarRepeater] = []
    @State private var allReps: [DstarRepeater] = []
    @State private var allFilter = ""
    @State private var info = ""
    @State private var geo = GeoLocate()
    @State private var bridgeBusy = false

    private var csvURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("dstar_repeaters.csv")
    }
    private var csvExists: Bool { FileManager.default.fileExists(atPath: csvURL.path) }
    private var dstarSupported: Bool { vm.dstarSupported || vm.civ.getModelName().contains("705") || vm.civ.getModelName().contains("9700") }

    var body: some View {
        NavigationStack {
            Form {
                Section("Routing (UR / R1 / R2)") {
                    LabeledTextField(label: "UR (destination / CQCQCQ=simplex)", text: $ur)
                    LabeledTextField(label: "R1 (access/area repeater)", text: $r1)
                    LabeledTextField(label: "R2 (link/gateway repeater)", text: $r2)
                    if !vm.dstarR1Name.isEmpty || !vm.dstarUrName.isEmpty {
                        Text(vm.dstarUrName.isEmpty ? "Selected: \(vm.dstarR1Name)" : "Selected: \(vm.dstarR1Name) → Link to: \(vm.dstarUrName)")
                            .font(.caption).foregroundColor(.orange)
                    }
                    Menu("Select UR (preset)") {
                        Button("CQCQCQ (local/simplex)") { ur = "CQCQCQ" }
                        Button("Unlink (_______U)") { ur = "       U" }
                        Button("Echoback (_______E)") { ur = "       E" }
                        Button("Info (_______I)") { ur = "       I" }
                    }
                    Button("Set (send UR/R1/R2)") {
                        vm.setDstarCallSigns(ur: ur.trimmingCharacters(in: .whitespaces), r1: r1.trimmingCharacters(in: .whitespaces), r2: r2.trimmingCharacters(in: .whitespaces))
                    }
                }

                Section("Repeater (CSV: \(csvExists ? "loaded" : "not imported"))") {
                    Button("Import CSV") { showImporter = true }
                    Button("Select repeater (nearby / GPS)") { pickNearby() }
                    Button("Link-to repeater (search all / zone call)") { pickAll() }
                    if !info.isEmpty { Text(info).font(.caption).foregroundColor(.secondary) }
                }

                if dstarSupported && !vm.useCivMode {
                    Section("CI-V bridge (remote full CI-V)") {
                        Toggle(isOn: Binding(
                            get: { vm.dstarBridgeActive },
                            set: { on in
                                bridgeBusy = true
                                Task {
                                    if on { vm.dstarCivBridge = true; _ = await vm.startDstarBridge() }
                                    else { vm.stopDstarBridge(); vm.dstarCivBridge = false }
                                    bridgeBusy = false
                                }
                            })) {
                            Text(bridgeBusy ? "Switching… (a few seconds)" : "CI-V bridge: \(vm.dstarBridgeActive ? "ON" : "OFF")")
                        }.disabled(bridgeBusy)
                        Text("Note: while ON, rigctld is stopped so normal operation is unavailable. Only D-STAR routing settings and received call display work. Turn OFF when finished.")
                            .font(.caption2).foregroundColor(.secondary)
                    }
                }

                Section("My call / TX message") {
                    LabeledTextField(label: "TX call sign (MyCall)", text: $myCall)
                    Button("Set MyCall") { vm.setDstarMyCall(myCall.trimmingCharacters(in: .whitespaces), note: "") }
                    LabeledTextField(label: "TX message (20 chars)", text: $txMsg, caps: false)
                    Button("Set message") { vm.setDstarTxMessage(txMsg) }
                }

                if !vm.dstarStatus.isEmpty {
                    Section { Text(vm.dstarStatus).font(.caption) }
                }
            }
            .navigationTitle("D-STAR Settings")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Close") { dismiss() } } }
            .onAppear { ur = vm.dstarUr; r1 = vm.dstarR1; r2 = vm.dstarR2; myCall = vm.dstarMyCall; txMsg = vm.dstarTxMessage }
            .fileImporter(isPresented: $showImporter, allowedContentTypes: [.commaSeparatedText, .plainText, .zip, .data, .item]) { result in
                importCsv(result)
            }
            .sheet(isPresented: $showNearby) { repeaterList(nearby, title: "Nearby repeaters", search: false) { rep in applyAccess(rep) } }
            .sheet(isPresented: $showAll) { repeaterList(allReps, title: "Link-to repeaters (all)", search: true) { rep in applyRouting(rep) } }
        }
    }

    // MARK: 選択ハンドラ
    private func applyAccess(_ rep: DstarRepeater) {
        r1 = rep.r1.trimmingCharacters(in: .whitespaces)
        r2 = rep.r2.trimmingCharacters(in: .whitespaces)
        vm.setDstarRepeaterConfig(freqMHz: rep.freqMHz, dupDir: rep.dupDir, offsetHz: rep.offsetHz, name: rep.callsign)
        if rep.freqMHz > 0 { Task { await vm.setFreq(Int64(rep.freqMHz * 1_000_000.0)) } }
        showNearby = false
    }
    private func applyRouting(_ rep: DstarRepeater) {
        // ゾーンコールUR(8桁): "/" + 基幹コール(6桁左詰) + モジュール(8桁目)
        let base = String(rep.r1.prefix(6)).trimmingCharacters(in: .whitespaces)
        let modCh = rep.r1.count >= 8 ? String(rep.r1[rep.r1.index(rep.r1.startIndex, offsetBy: 7)]).trimmingCharacters(in: .whitespaces) : ""
        ur = String(("/" + base.padding(toLength: 6, withPad: " ", startingAt: 0) + modCh).prefix(8))
        vm.dstarUrName = rep.callsign
        showAll = false
    }

    // MARK: ピッカー
    private func pickNearby() {
        guard csvExists else { info = String(localized: "Please import a CSV first"); return }
        info = String(localized: "Getting current location…")
        geo.fetchLocation(onInfo: { info = $0 }, onLatLon: { lat, lon in
            DispatchQueue.global().async {
                let list = DstarCsv.loadNearby(csvURL, lat: lat, lon: lon)
                DispatchQueue.main.async {
                    if list.isEmpty { info = String(localized: "0 nearby (check CSV format)") } else { nearby = list; info = ""; showNearby = true }
                }
            }
        })
    }
    private func pickAll() {
        guard csvExists else { info = String(localized: "Please import a CSV first"); return }
        DispatchQueue.global().async {
            let list = DstarCsv.loadAll(csvURL)
            DispatchQueue.main.async {
                if list.isEmpty { info = String(localized: "0 repeaters (check CSV format)") } else { allReps = list; showAll = true }
            }
        }
    }

    @ViewBuilder private func repeaterList(_ list: [DstarRepeater], title: String, search: Bool, onPick: @escaping (DstarRepeater) -> Void) -> some View {
        NavigationStack {
            let shown = (search && !allFilter.isEmpty)
                ? list.filter { $0.callsign.localizedCaseInsensitiveContains(allFilter) || $0.r1.localizedCaseInsensitiveContains(allFilter) }
                : list
            List(shown) { rep in
                Button { onPick(rep) } label: {
                    VStack(alignment: .leading) {
                        Text(rep.callsign).font(.body)
                        Text("\(rep.r1.trimmingCharacters(in: .whitespaces))   \(String(format: "%.4f", rep.freqMHz))MHz").font(.caption).foregroundColor(.secondary)
                    }
                }
            }
            .navigationTitle(title)
            .modifier(SearchIf(enabled: search, text: $allFilter))
        }
    }

    private func importCsv(_ result: Result<URL, Error>) {
        switch result {
        case .success(let url):
            let sec = url.startAccessingSecurityScopedResource()
            defer { if sec { url.stopAccessingSecurityScopedResource() } }
            guard let raw = try? Data(contentsOf: url) else { info = String(localized: "Load failed"); return }
            // Icom配布のZIP(PK)は自動展開して最初の .csv を取り出す。非ZIPはそのままCSV扱い。
            var data = raw
            if raw.count >= 2, raw[0] == 0x50, raw[1] == 0x4B {
                guard let csv = DstarCsv.extractCsvIfZip(raw) else { info = String(localized: "ZIP extraction failed (.csv not found / data descriptor format)"); return }
                data = csv
            }
            do {
                try data.write(to: csvURL)
                // 取り込んだCSVがレピータとして解析できるかをこの場で検証して件数を表示
                let count = DstarCsv.parseAll(data: data).count
                info = count > 0 ? String(localized: "Import complete (\(data.count)B, \(count) repeaters)") : String(localized: "Imported, but 0 repeaters (check that this is a repeater list CSV)")
            }
            catch { info = String(localized: "Save failed: \(error.localizedDescription)") }
        case .failure(let e):
            info = String(localized: "Import failed: \(e.localizedDescription)")
        }
    }
}

private struct SearchIf: ViewModifier {
    let enabled: Bool
    @Binding var text: String
    func body(content: Content) -> some View { enabled ? AnyView(content.searchable(text: $text)) : AnyView(content) }
}

private struct LabeledTextField: View {
    let label: String
    @Binding var text: String
    var caps: Bool = true
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label).font(.caption).foregroundColor(.cyan)
            TextField("", text: $text)
                .textInputAutocapitalization(caps ? .characters : .never)
                .autocorrectionDisabled(true)
                .font(.system(.body, design: .monospaced))
        }
    }
}
