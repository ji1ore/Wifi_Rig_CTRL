import SwiftUI

/// eQSL / Smart HAMLOG(FT8アプリ連携=Cloudlog) の資格情報設定。
struct IntegrationSettingsView: View {
    @Bindable var vm: MainViewModel
    @Environment(\.dismiss) private var dismiss
    @State private var testResult = ""
    @State private var testing = false

    var body: some View {
        Form {
            Section("eQSL") {
                TextField("Username (callsign)", text: $vm.eqslUser)
                    .textInputAutocapitalization(.characters).autocorrectionDisabled()
                SecureField("Password", text: $vm.eqslPassword)
                TextField("QTH nickname (optional)", text: $vm.eqslQthNickname)
                    .autocorrectionDisabled()
            }
            Section {
                TextField("Server address", text: $vm.shlCloudlogUrl)
                    .textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                SecureField("API key", text: $vm.shlApiKey)
                TextField("Station ID (default 1)", text: $vm.shlStationId)
                    .keyboardType(.numberPad)
                Button {
                    testing = true; testResult = String(localized: "Connecting…")
                    let (u, k) = (vm.shlCloudlogUrl, vm.shlApiKey)
                    Task {
                        let r = await SmartHamLogSync.checkAuth(url: u, key: k)
                        await MainActor.run { testResult = r; testing = false }
                    }
                } label: { Label("Smart HAMLOG connection test", systemImage: "antenna.radiowaves.left.and.right") }
                .disabled(testing)
                if !testResult.isEmpty {
                    Text(testResult).font(.caption)
                        .foregroundStyle(testResult.hasPrefix("Error") ? .red : .green)
                }
            } header: {
                Text("Smart HAMLOG (FT8 app integration / Cloudlog)")
            } footer: {
                Text("Enter the server address and API key shown in Smart HAMLOG under [Settings] → \"FT8TW/Greyline integration\".")
            }
        }
        .navigationTitle("Integration Settings")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) {
                Button("Save") { vm.persistIntegrationSettings(); dismiss() }
            }
        }
        .onDisappear { vm.persistIntegrationSettings() }
    }
}
