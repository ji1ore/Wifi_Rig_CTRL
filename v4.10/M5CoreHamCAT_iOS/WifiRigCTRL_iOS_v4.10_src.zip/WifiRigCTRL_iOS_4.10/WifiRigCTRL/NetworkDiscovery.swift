import Foundation

struct DiscoveredHost: Identifiable {
    let id = UUID()
    let ip: String
    let hostname: String
    let apiPort: Int
    let audioPort: Int
    var label: String { "\(hostname)  (\(ip))" }
}

/// Androidクライアントと同じUDPブロードキャストプロトコルでPiを検索する。
/// "WIFI_RIG_CTRL_DISCOVER" をUDP 5001番ポートにブロードキャストし、
/// "WIFI_RIG_CTRL_HERE:hostname:apiPort:audioPort" レスポンスを収集する。
func discoverWifiRigCtrlHosts() async -> [DiscoveredHost] {
    await withCheckedContinuation { continuation in
        DispatchQueue.global(qos: .userInitiated).async {
            continuation.resume(returning: _runDiscovery())
        }
    }
}

private func _runDiscovery(timeoutSec: Double = 2.5) -> [DiscoveredHost] {
    let udpPort: UInt16 = 5001
    let magic = "WIFI_RIG_CTRL_DISCOVER"
    var found: [DiscoveredHost] = []

    let sockfd = socket(AF_INET, SOCK_DGRAM, 0)
    guard sockfd >= 0 else { return [] }
    defer { close(sockfd) }

    // ブロードキャスト有効化
    var on: Int32 = 1
    setsockopt(sockfd, SOL_SOCKET, SO_BROADCAST, &on, socklen_t(MemoryLayout<Int32>.size))
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR,  &on, socklen_t(MemoryLayout<Int32>.size))

    // INADDR_ANY:0 に明示 bind → 受信用のローカルポートを確定させる
    var local = sockaddr_in()
    local.sin_len    = UInt8(MemoryLayout<sockaddr_in>.size)
    local.sin_family = sa_family_t(AF_INET)
    local.sin_port   = 0   // OS が空きポートを割り当て
    local.sin_addr.s_addr = 0  // INADDR_ANY
    _ = withUnsafePointer(to: &local) {
        $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
            bind(sockfd, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
        }
    }

    // ノンブロッキングモードに設定（SO_RCVTIMEO が iOS で効かない場合の対策）
    let fl = fcntl(sockfd, F_GETFL, 0)
    if fl >= 0 { _ = fcntl(sockfd, F_SETFL, fl | O_NONBLOCK) }

    // 送信先リスト
    // 1. 255.255.255.255（限定ブロードキャスト）
    // 2. 各 NIC のサブネットブロードキャスト（Android と同様）
    // 3. 各 NIC のサブネット内全ホストへのユニキャスト（フォールバック）
    //    iOS では UDP ブロードキャスト送信に com.apple.developer.networking.multicast
    //    エンタイトルメントが必要で、無い場合 sendto が黙って失敗する。ユニキャストは
    //    ローカルネットワーク権限だけで送れるため、CI-V 検索と同じ掃引を併用する。
    var targets: [sockaddr_in] = [_makeSockAddrIn(ip: UInt32.max, port: udpPort)]
    _collectIfBroadcasts(port: udpPort, into: &targets)
    let broadcastCount = targets.count
    _collectSubnetUnicasts(port: udpPort, into: &targets)

    // 全ターゲットへ送信。ブロードキャスト分は失敗理由をログに残す
    // （ユニキャスト分は 254 件あるので失敗は件数だけ集計する）。
    var unicastFailures = 0
    magic.withCString { cstr in
        let len = strlen(cstr)
        for (idx, var dest) in targets.enumerated() {
            let sent = withUnsafePointer(to: &dest) {
                $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                    sendto(sockfd, cstr, len, 0, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
                }
            }
            guard sent < 0 else { continue }
            if idx < broadcastCount {
                let err = errno
                print("[Discovery] broadcast sendto \(_ipString(dest)) failed: errno=\(err) (\(String(cString: strerror(err))))")
            } else {
                unicastFailures += 1
            }
        }
    }
    if unicastFailures > 0 {
        print("[Discovery] unicast sendto failed for \(unicastFailures)/\(targets.count - broadcastCount) hosts")
    }

    // 受信ループ（デッドラインまで 20ms ポーリング）
    var buf    = [UInt8](repeating: 0, count: 512)
    var src    = sockaddr_in()
    var srcLen = socklen_t(MemoryLayout<sockaddr_in>.size)
    let deadline = Date().addingTimeInterval(timeoutSec)

    while Date() < deadline {
        srcLen = socklen_t(MemoryLayout<sockaddr_in>.size)
        let n = buf.withUnsafeMutableBufferPointer { bp in
            withUnsafeMutablePointer(to: &src) { sp in
                sp.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                    recvfrom(sockfd, bp.baseAddress, bp.count - 1, 0, $0, &srcLen)
                }
            }
        }
        if n <= 0 {
            // ノンブロッキングなので EAGAIN は正常（データなし）
            usleep(20_000)  // 20ms 待って再試行
            continue
        }

        let msg = String(bytes: buf[0..<n], encoding: .utf8) ?? ""
        guard msg.hasPrefix("WIFI_RIG_CTRL_HERE:") else { continue }

        let payload = String(msg.dropFirst("WIFI_RIG_CTRL_HERE:".count))
        let parts   = payload.split(separator: ":", omittingEmptySubsequences: false).map(String.init)
        let hostname  = parts.first ?? "unknown"
        let apiPort   = parts.count > 1 ? Int(parts[1]) ?? 8000 : 8000
        let audioPort = parts.count > 2 ? Int(parts[2]) ?? 8000 : 8000

        var ipBuf = [CChar](repeating: 0, count: Int(INET_ADDRSTRLEN))
        let ip: String = withUnsafePointer(to: src.sin_addr) {
            guard inet_ntop(AF_INET, $0, &ipBuf, socklen_t(INET_ADDRSTRLEN)) != nil else { return "" }
            return String(cString: ipBuf)
        }
        guard !ip.isEmpty, !found.contains(where: { $0.ip == ip }) else { continue }
        found.append(DiscoveredHost(ip: ip, hostname: hostname,
                                    apiPort: apiPort, audioPort: audioPort))
    }

    if found.isEmpty {
        print("[Discovery] no WIFI_RIG_CTRL_HERE reply within \(timeoutSec)s (sent to \(targets.count) targets)")
    }
    return found
}

// MARK: - CI-V RS-BA1 Discovery (AreYouThere → IAmHere)

struct DiscoveredCivHost: Identifiable {
    let id = UUID()
    let ip: String
}

/// RS-BA1 AYT (type=0x03) をサブネット全体に送り IAmHere (type=0x04) 応答で IC-705 を探す。
func discoverCivHosts(port: UInt16 = 50001) async -> [DiscoveredCivHost] {
    await withCheckedContinuation { continuation in
        DispatchQueue.global(qos: .userInitiated).async {
            continuation.resume(returning: _runCivDiscovery(port: port))
        }
    }
}

private func _runCivDiscovery(port: UInt16 = 50001, timeoutSec: Double = 3.0) -> [DiscoveredCivHost] {
    var found: [DiscoveredCivHost] = []

    let sockfd = socket(AF_INET, SOCK_DGRAM, 0)
    guard sockfd >= 0 else { return [] }
    defer { Darwin.close(sockfd) }

    var on: Int32 = 1
    setsockopt(sockfd, SOL_SOCKET, SO_BROADCAST, &on, socklen_t(MemoryLayout<Int32>.size))
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR,  &on, socklen_t(MemoryLayout<Int32>.size))

    var local = sockaddr_in()
    local.sin_len    = UInt8(MemoryLayout<sockaddr_in>.size)
    local.sin_family = sa_family_t(AF_INET)
    local.sin_port   = 0; local.sin_addr.s_addr = 0
    _ = withUnsafePointer(to: &local) {
        $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
            bind(sockfd, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
        }
    }
    let fl = fcntl(sockfd, F_GETFL, 0)
    if fl >= 0 { _ = fcntl(sockfd, F_SETFL, fl | O_NONBLOCK) }

    // AYT packet: 16 bytes, type=0x03 (RS-BA1 AreYouThere)
    let myId = UInt32.random(in: 1..<UInt32.max)
    var ayt = [UInt8](repeating: 0, count: 16)
    ayt[0] = 0x10                                   // length LE32 = 16
    ayt[4] = 0x03                                   // type LE16 = AreYouThere
    ayt[8]  = UInt8(myId & 0xFF)
    ayt[9]  = UInt8((myId >> 8) & 0xFF)
    ayt[10] = UInt8((myId >> 16) & 0xFF)
    ayt[11] = UInt8((myId >> 24) & 0xFF)

    // ブロードキャスト + サブネット全ユニキャストへ送信
    var targets: [sockaddr_in] = [_makeSockAddrIn(ip: UInt32.max, port: port)]
    _collectIfBroadcasts(port: port, into: &targets)
    _collectSubnetUnicasts(port: port, into: &targets)
    ayt.withUnsafeBufferPointer { buf in
        for var dest in targets {
            _ = withUnsafePointer(to: &dest) {
                $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                    sendto(sockfd, buf.baseAddress, buf.count, 0, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
                }
            }
        }
    }

    // IAmHere 応答を収集 (type=0x04, 16 bytes)
    var buf = [UInt8](repeating: 0, count: 64)
    var src = sockaddr_in(); var srcLen = socklen_t(MemoryLayout<sockaddr_in>.size)
    let deadline = Date().addingTimeInterval(timeoutSec)
    while Date() < deadline {
        srcLen = socklen_t(MemoryLayout<sockaddr_in>.size)
        let n = buf.withUnsafeMutableBufferPointer { bp in
            withUnsafeMutablePointer(to: &src) { sp in
                sp.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                    recvfrom(sockfd, bp.baseAddress, bp.count, 0, $0, &srcLen)
                }
            }
        }
        if n <= 0 { usleep(20_000); continue }
        guard n == 16, buf[4] == 0x04, buf[5] == 0x00 else { continue }
        var ipBuf = [CChar](repeating: 0, count: Int(INET_ADDRSTRLEN))
        let ip: String = withUnsafePointer(to: src.sin_addr) {
            guard inet_ntop(AF_INET, $0, &ipBuf, socklen_t(INET_ADDRSTRLEN)) != nil else { return "" }
            return String(cString: ipBuf)
        }
        if !ip.isEmpty, !found.contains(where: { $0.ip == ip }) {
            found.append(DiscoveredCivHost(ip: ip))
        }
    }
    return found
}

private func _collectSubnetUnicasts(port: UInt16, into targets: inout [sockaddr_in]) {
    var ifap: UnsafeMutablePointer<ifaddrs>?
    guard getifaddrs(&ifap) == 0, let head = ifap else { return }
    defer { freeifaddrs(head) }
    var cur: UnsafeMutablePointer<ifaddrs>? = head
    while let iface = cur {
        defer { cur = iface.pointee.ifa_next }
        let flags = iface.pointee.ifa_flags
        guard flags & UInt32(IFF_UP) != 0, flags & UInt32(IFF_LOOPBACK) == 0,
              let addrPtr = iface.pointee.ifa_addr,
              addrPtr.pointee.sa_family == sa_family_t(AF_INET) else { continue }
        var ipBuf = [CChar](repeating: 0, count: Int(INET_ADDRSTRLEN))
        let ipStr: String = addrPtr.withMemoryRebound(to: sockaddr_in.self, capacity: 1) { sin in
            guard inet_ntop(AF_INET, &sin.pointee.sin_addr, &ipBuf, socklen_t(INET_ADDRSTRLEN)) != nil else { return "" }
            return String(cString: ipBuf)
        }
        guard !ipStr.isEmpty else { continue }
        let parts = ipStr.split(separator: ".").compactMap { Int($0) }
        guard parts.count == 4 else { continue }
        for i in 1...254 {
            if i == parts[3] { continue }
            let targetIP = "\(parts[0]).\(parts[1]).\(parts[2]).\(i)"
            let inetAddr = inet_addr(targetIP)
            guard inetAddr != INADDR_NONE else { continue }
            var addr = sockaddr_in()
            addr.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
            addr.sin_family = sa_family_t(AF_INET)
            addr.sin_port = port.bigEndian
            addr.sin_addr.s_addr = inetAddr
            targets.append(addr)
        }
    }
}

// MARK: - Helpers

/// sockaddr_in の IPv4 アドレスを "a.b.c.d" 文字列にする（ログ用）。
private func _ipString(_ addr: sockaddr_in) -> String {
    var copy = addr.sin_addr
    var buf = [CChar](repeating: 0, count: Int(INET_ADDRSTRLEN))
    guard inet_ntop(AF_INET, &copy, &buf, socklen_t(INET_ADDRSTRLEN)) != nil else { return "?" }
    return String(cString: buf)
}

private func _makeSockAddrIn(ip: UInt32, port: UInt16) -> sockaddr_in {
    var addr = sockaddr_in()
    addr.sin_len    = UInt8(MemoryLayout<sockaddr_in>.size)
    addr.sin_family = sa_family_t(AF_INET)
    addr.sin_port   = port.bigEndian
    addr.sin_addr.s_addr = ip  // 255.255.255.255 はバイトオーダー不変
    return addr
}

/// getifaddrs で各 NIC のブロードキャストアドレスを収集する（Android の実装と同等）。
/// ifa_broadaddr は Swift から直接アクセスできない場合があるため、
/// IP アドレスとネットマスクからブロードキャストを計算する。
private func _collectIfBroadcasts(port: UInt16, into targets: inout [sockaddr_in]) {
    var ifap: UnsafeMutablePointer<ifaddrs>?
    guard getifaddrs(&ifap) == 0, let head = ifap else { return }
    defer { freeifaddrs(head) }

    var cur: UnsafeMutablePointer<ifaddrs>? = head
    while let iface = cur {
        defer { cur = iface.pointee.ifa_next }
        let flags = iface.pointee.ifa_flags
        // UP かつ ループバックでなく ブロードキャスト対応のインターフェースのみ
        guard flags & UInt32(IFF_UP)        != 0,
              flags & UInt32(IFF_LOOPBACK)  == 0,
              flags & UInt32(IFF_BROADCAST) != 0,
              let addrPtr = iface.pointee.ifa_addr,
              addrPtr.pointee.sa_family == sa_family_t(AF_INET),
              let maskPtr = iface.pointee.ifa_netmask,
              maskPtr.pointee.sa_family == sa_family_t(AF_INET)
        else { continue }

        // sin_addr.s_addr はネットワークバイトオーダーのまま演算して OK
        let ifIP: UInt32 = addrPtr.withMemoryRebound(to: sockaddr_in.self, capacity: 1) {
            $0.pointee.sin_addr.s_addr
        }
        let mask: UInt32 = maskPtr.withMemoryRebound(to: sockaddr_in.self, capacity: 1) {
            $0.pointee.sin_addr.s_addr
        }
        // broadcast = (ip & mask) | ~mask
        let bcastIP = (ifIP & mask) | (~mask)

        var addr = sockaddr_in()
        addr.sin_len    = UInt8(MemoryLayout<sockaddr_in>.size)
        addr.sin_family = sa_family_t(AF_INET)
        addr.sin_port   = port.bigEndian
        addr.sin_addr.s_addr = bcastIP

        if !targets.contains(where: { $0.sin_addr.s_addr == bcastIP }) {
            targets.append(addr)
        }
    }
}

// MARK: - SSH (port 22) subnet scan
//
// Connect画面のUDP探索は Pi 上で api.py が稼働している前提だが、SETUP 画面は
// 「これからセットアップする素の Pi」が相手なので使えない。SSH さえ有効なら必ず
// 応答する 22番ポートへ /24 を並列 TCP 接続して探す。

struct SshHost: Identifiable {
    let id = UUID()
    let ip: String
    let hostname: String
    var label: String { hostname.isEmpty ? ip : "\(hostname)  (\(ip))" }
}

/// ローカル /24 を SSH(22番)で走査して、開いているホストを返す。
/// nonisolated: このプロジェクトは既定で MainActor 分離のため、明示しないと
/// ブロッキング(select)が UI スレッド上で走り画面が固まる。
nonisolated func scanSshHosts(timeoutMs: Int32 = 400) async -> [SshHost] {
    let targets = _sshScanTargets()
    guard !targets.isEmpty else { return [] }

    var results: [SshHost] = []
    // スレッド枯渇を避けるため同時接続数を制限してバッチ実行する
    let maxInFlight = 48
    var index = 0
    while index < targets.count {
        let batch = Array(targets[index..<min(index + maxInFlight, targets.count)])
        index += maxInFlight
        let hits: [SshHost] = await withTaskGroup(of: SshHost?.self) { group in
            for ip in batch {
                group.addTask {
                    guard _sshTcpProbe(ip: ip, port: 22, timeoutMs: timeoutMs) else { return nil }
                    return SshHost(ip: ip, hostname: _sshReverseDNS(ip))
                }
            }
            var acc: [SshHost] = []
            for await r in group { if let r { acc.append(r) } }
            return acc
        }
        results.append(contentsOf: hits)
    }
    return results.sorted { _sshIpLess($0.ip, $1.ip) }
}

/// getifaddrs から走査対象の IPv4 候補一覧（自分自身を除く /24）を生成する。
private nonisolated func _sshScanTargets() -> [String] {
    var ifap: UnsafeMutablePointer<ifaddrs>?
    guard getifaddrs(&ifap) == 0, let head = ifap else { return [] }
    defer { freeifaddrs(head) }

    var ips: [String] = []
    var seen = Set<UInt32>()
    var cur: UnsafeMutablePointer<ifaddrs>? = head
    while let iface = cur {
        defer { cur = iface.pointee.ifa_next }
        let flags = iface.pointee.ifa_flags
        guard flags & UInt32(IFF_UP)       != 0,
              flags & UInt32(IFF_LOOPBACK) == 0,
              let addrPtr = iface.pointee.ifa_addr,
              addrPtr.pointee.sa_family == sa_family_t(AF_INET),
              let maskPtr = iface.pointee.ifa_netmask,
              maskPtr.pointee.sa_family == sa_family_t(AF_INET)
        else { continue }

        let ifIP = UInt32(bigEndian: addrPtr.withMemoryRebound(to: sockaddr_in.self, capacity: 1) {
            $0.pointee.sin_addr.s_addr
        })
        var mask = UInt32(bigEndian: maskPtr.withMemoryRebound(to: sockaddr_in.self, capacity: 1) {
            $0.pointee.sin_addr.s_addr
        })
        // サブネットが /24 より広い場合は、暴走を避けて /24 に絞る
        if (~mask) > 0xFF { mask = 0xFFFFFF00 }

        let network   = ifIP & mask
        let broadcast = network | (~mask)
        var h = network + 1
        while h < broadcast {
            if h != ifIP, !seen.contains(h) {
                seen.insert(h)
                ips.append(_sshIpv4String(h))
            }
            h += 1
        }
    }
    return ips
}

/// 指定 IP:port へノンブロッキング接続し、timeout 内に繋がれば true。
private nonisolated func _sshTcpProbe(ip: String, port: UInt16, timeoutMs: Int32) -> Bool {
    let fd = socket(AF_INET, SOCK_STREAM, 0)
    guard fd >= 0 else { return false }
    defer { close(fd) }

    let fl = fcntl(fd, F_GETFL, 0)
    _ = fcntl(fd, F_SETFL, fl | O_NONBLOCK)

    var addr = sockaddr_in()
    addr.sin_len    = UInt8(MemoryLayout<sockaddr_in>.size)
    addr.sin_family = sa_family_t(AF_INET)
    addr.sin_port   = port.bigEndian
    guard inet_pton(AF_INET, ip, &addr.sin_addr) == 1 else { return false }

    let rc = withUnsafePointer(to: &addr) {
        $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
            connect(fd, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
        }
    }
    if rc == 0 { return true }                 // 即時接続
    if errno != EINPROGRESS { return false }   // 到達不能等

    var wfds = fd_set()
    _sshFdZero(&wfds); _sshFdSet(fd, &wfds)
    var tv = timeval(tv_sec: Int(timeoutMs / 1000),
                     tv_usec: (timeoutMs % 1000) * 1000)
    guard select(fd + 1, nil, &wfds, nil, &tv) > 0 else { return false }

    var soErr: Int32 = 0
    var len = socklen_t(MemoryLayout<Int32>.size)
    guard getsockopt(fd, SOL_SOCKET, SO_ERROR, &soErr, &len) == 0 else { return false }
    return soErr == 0
}

/// IP の逆引き（ホスト名）。解決できなければ空文字。
private nonisolated func _sshReverseDNS(_ ip: String) -> String {
    var addr = sockaddr_in()
    addr.sin_len    = UInt8(MemoryLayout<sockaddr_in>.size)
    addr.sin_family = sa_family_t(AF_INET)
    guard inet_pton(AF_INET, ip, &addr.sin_addr) == 1 else { return "" }
    var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
    let rc = withUnsafePointer(to: &addr) {
        $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
            getnameinfo($0, socklen_t(MemoryLayout<sockaddr_in>.size),
                        &host, socklen_t(host.count), nil, 0, NI_NAMEREQD)
        }
    }
    guard rc == 0 else { return "" }
    let name = String(cString: host)
    return name == ip ? "" : name   // 逆引きが IP をそのまま返したら名前なし扱い
}

// MARK: fd_set / IP helpers (SSH scan 専用 — 既存ヘルパーと名前衝突を避ける)

private nonisolated func _sshFdZero(_ set: inout fd_set) {
    set.fds_bits = (0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
}

private nonisolated func _sshFdSet(_ fd: Int32, _ set: inout fd_set) {
    let intOffset = Int(fd) / 32
    let bitOffset = Int(fd) % 32
    let mask = Int32(bitPattern: UInt32(1) << UInt32(bitOffset))
    withUnsafeMutablePointer(to: &set.fds_bits) {
        $0.withMemoryRebound(to: Int32.self, capacity: 32) { p in
            p[intOffset] |= mask
        }
    }
}

private nonisolated func _sshIpv4String(_ hostOrder: UInt32) -> String {
    "\((hostOrder >> 24) & 0xFF).\((hostOrder >> 16) & 0xFF).\((hostOrder >> 8) & 0xFF).\(hostOrder & 0xFF)"
}

private nonisolated func _sshIpLess(_ a: String, _ b: String) -> Bool {
    func val(_ s: String) -> UInt32 {
        let p = s.split(separator: ".").compactMap { UInt32($0) }
        guard p.count == 4 else { return 0 }
        return (p[0] << 24) | (p[1] << 16) | (p[2] << 8) | p[3]
    }
    return val(a) < val(b)
}
