import SwiftUI
import UIKit

struct QsoLogView: View {
    let vm: MainViewModel

    @State private var entries: [QsoEntry] = []
    @State private var selected = Set<UUID>()
    @State private var editMode: EditMode = .inactive
    @State private var showLogEntry = false
    @State private var showDeleteConfirm = false
    @State private var showClearConfirm = false
    @State private var searchText = ""
    @State private var editing: QsoEntry? = nil
    @State private var sotaCsv: QsoStore.SotaChaserCsv? = nil
    @State private var showSotaConfirm = false
    @State private var showPeriodSheet = false
    @State private var noOpLocAlert = false
    @State private var bulkMsg: String? = nil

    private var filtered: [QsoEntry] {
        if searchText.isEmpty { return entries }
        let q = searchText.lowercased()
        return entries.filter {
            $0.call.lowercased().contains(q) ||
            $0.yourPota.lowercased().contains(q) ||
            $0.yourSota.lowercased().contains(q) ||
            $0.myPota.lowercased().contains(q) ||
            $0.mode.lowercased().contains(q) ||
            $0.jcc.contains(q)
        }
    }

    var body: some View {
        List(selection: $selected) {
            ForEach(filtered) { e in
                if editMode == .active {
                    // Selection mode: let the List handle taps for multi-select
                    qsoRow(e)
                } else {
                    // Normal mode: tap a row to edit it (Android uses long-press)
                    qsoRow(e)
                        .contentShape(Rectangle())
                        .onTapGesture { editing = e }
                        .swipeActions(edge: .leading) {
                            Button {
                                editing = e
                            } label: {
                                Label("Edit", systemImage: "pencil")
                            }
                            .tint(.blue)
                        }
                }
            }
            .onDelete(perform: deleteRows)
        }
        .environment(\.editMode, $editMode)
        .searchable(text: $searchText, prompt: "Search by callsign, POTA, or Mode")
        .navigationTitle("QSO Log (\(entries.count))")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button {
                    showLogEntry = true
                } label: {
                    Image(systemName: "plus.circle")
                }

                Menu {
                    Button {
                        editMode = editMode == .active ? .inactive : .active
                    } label: {
                        Label(editMode == .active ? "Done Selecting" : "Select Mode",
                              systemImage: "checkmark.circle")
                    }

                    Button {
                        showPeriodSheet = true
                    } label: {
                        Label("Select by Period (UTC/Local)", systemImage: "clock")
                    }
                    .disabled(entries.isEmpty)

                    if !selected.isEmpty {
                        Button("Delete Selected", role: .destructive) {
                            showDeleteConfirm = true
                        }
                        Button {
                            exportAdif(selected)
                        } label: {
                            Label("Export Selected to ADIF", systemImage: "square.and.arrow.up")
                        }
                        Button {
                            exportOpLocAdif(selected)
                        } label: {
                            Label("Export Selected to ADIF by Location", systemImage: "square.and.arrow.up.on.square")
                        }
                        Button {
                            sotaCsv = QsoStore.buildSotaChaserCsv(entries.filter { selected.contains($0.id) })
                            showSotaConfirm = true
                        } label: {
                            Label("Submit SOTA Chase Log", systemImage: "mountain.2")
                        }
                    }

                    Divider()

                    Button {
                        exportAdif(nil)
                    } label: {
                        Label("Export All to ADIF", systemImage: "arrow.up.doc")
                    }
                    .disabled(entries.isEmpty)

                    Button {
                        exportOpLocAdif(nil)
                    } label: {
                        Label("Export All to ADIF by Location", systemImage: "square.and.arrow.up.on.square")
                    }
                    .disabled(entries.isEmpty)

                    Divider()

                    Button {
                        sendUnsentEqsl()
                    } label: {
                        Label("Send Unsent eQSL", systemImage: "envelope.arrow.triangle.branch")
                    }
                    .disabled(entries.allSatisfy { $0.eqslSent })

                    Button {
                        sendUnsentSmartHamLog()
                    } label: {
                        Label("Send Unsynced to Smart HAMLOG", systemImage: "antenna.radiowaves.left.and.right")
                    }
                    .disabled(entries.allSatisfy { $0.shlSent })

                    Button("Delete All", role: .destructive) {
                        showClearConfirm = true
                    }
                    .disabled(entries.isEmpty)
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
            }
        }
        .confirmationDialog(
            "Delete \(selected.count) selected QSOs?",
            isPresented: $showDeleteConfirm,
            titleVisibility: .visible
        ) {
            Button("Delete", role: .destructive) {
                deleteSelected()
            }
            Button("Cancel", role: .cancel) {}
        }
        .confirmationDialog(
            "Delete all \(entries.count) QSOs?",
            isPresented: $showClearConfirm,
            titleVisibility: .visible
        ) {
            Button("Delete All", role: .destructive) {
                QsoStore.save([])
                vm.ft8QsoLog = "[]"
                reload()
            }
            Button("Cancel", role: .cancel) {}
        }
        .alert(
            (sotaCsv?.included ?? 0) > 0 ? "Submit SOTA Chase Log" : "No QSOs available to submit",
            isPresented: $showSotaConfirm,
            presenting: sotaCsv
        ) { r in
            if r.included > 0 {
                Button("Save and Open SOTAData") { sendSotaChaser(r) }
            }
            Button(r.included > 0 ? "Cancel" : "OK", role: .cancel) {}
        } message: { r in
            Text(sotaSummary(r))
        }
        .sheet(isPresented: $showLogEntry, onDismiss: reload) {
            LogQsoView(vm: vm)
        }
        .sheet(item: $editing) { e in
            QsoEditView(vm: vm, entry: e) { updated in
                updateEntry(updated)
            }
        }
        .sheet(isPresented: $showPeriodSheet) {
            PeriodSelectSheet { startMs, endMs in
                selectByPeriod(startMs: startMs, endMs: endMs)
            }
        }
        .alert("No QSOs have operating location info (My POTA/SOTA)", isPresented: $noOpLocAlert) {
            Button("OK", role: .cancel) {}
        }
        .alert("Sync Result", isPresented: Binding(get: { bulkMsg != nil }, set: { if !$0 { bulkMsg = nil } })) {
            Button("OK", role: .cancel) { bulkMsg = nil }
        } message: { Text(bulkMsg ?? "") }
        .onAppear { reload() }
    }

    // MARK: - Row view

    private func qsoRow(_ e: QsoEntry) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack {
                Text(e.call)
                    .font(.system(size: 13, design: .monospaced).bold())
                    .foregroundStyle(.white)
                Spacer()
                Text("\(QsoStore.freqToBand(e.freq))  \(e.mode)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            HStack(spacing: 6) {
                Text(formatDt(e.dt))
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundStyle(.secondary)
                let local = utcToLocal(e.dt)
                if !local.isEmpty {
                    Text("[\(local)]")
                        .font(.system(size: 10, design: .monospaced))
                        .foregroundStyle(Color(white: 0.55))
                }
            }
            HStack(spacing: 8) {
                Text("S:\(e.rstS) R:\(e.rstR)")
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundStyle(.secondary)
                if !e.yourPota.isEmpty { badge(e.yourPota, color: .green) }
                if !e.yourSota.isEmpty { badge(e.yourSota, color: .blue) }
                if !e.myPota.isEmpty   { badge("MY:\(e.myPota)", color: .teal) }
                if !e.mySota.isEmpty   { badge("MY:\(e.mySota)", color: .indigo) }
                if !e.jcc.isEmpty      { badge("JCC:\(e.jcc)", color: .orange) }
                badge(e.eqslSent ? "eQSL✓" : "eQSL—", color: e.eqslSent ? .green : .gray)
                badge(e.shlSent ? "SHL✓" : "SHL—", color: e.shlSent ? .green : .gray)
            }
            if !e.comment.isEmpty {
                Text(e.comment)
                    .font(.caption)
                    .foregroundStyle(.green)
            }
        }
        .padding(.vertical, 2)
        .listRowBackground(Color.black)
    }

    private func badge(_ text: String, color: Color) -> some View {
        Text(text)
            .font(.system(size: 9))
            .padding(.horizontal, 4)
            .padding(.vertical, 1)
            .background(color.opacity(0.25))
            .foregroundStyle(color)
            .cornerRadius(4)
    }

    // MARK: - Helpers

    private func reload() {
        entries = QsoStore.load()
        selected.removeAll()
    }

    private func deleteRows(at offsets: IndexSet) {
        var all = entries
        offsets.map { filtered[$0].id }.forEach { id in
            all.removeAll { $0.id == id }
        }
        QsoStore.save(all)
        vm.ft8QsoLog = QsoStore.jsonString()
        reload()
    }

    private func deleteSelected() {
        var all = entries
        all.removeAll { selected.contains($0.id) }
        QsoStore.save(all)
        vm.ft8QsoLog = QsoStore.jsonString()
        reload()
    }

    /// Replaces the entry with the same id and persists the whole log.
    private func updateEntry(_ updated: QsoEntry) {
        var all = entries
        guard let idx = all.firstIndex(where: { $0.id == updated.id }) else { return }
        all[idx] = updated
        QsoStore.save(all)
        vm.ft8QsoLog = QsoStore.jsonString()
        reload()
    }

    private func sendUnsentEqsl() {
        guard EqslUploader.hasCredentials(user: vm.eqslUser, pass: vm.eqslPassword) else {
            bulkMsg = String(localized: "Please set your eQSL username/password in the rig selection settings."); return
        }
        let (u, p, n) = (vm.eqslUser, vm.eqslPassword, vm.eqslQthNickname)
        Task {
            let (sent, failed) = await EqslUploader.bulkSendUnsent(user: u, pass: p, nickname: n)
            await MainActor.run { reload(); bulkMsg = failed <= 0 ? String(localized: "eQSL send complete: \(sent)") : String(localized: "eQSL send: \(sent) succeeded / \(failed) failed") }
        }
    }

    private func sendUnsentSmartHamLog() {
        guard SmartHamLogSync.hasServer(url: vm.shlCloudlogUrl, key: vm.shlApiKey) else {
            bulkMsg = String(localized: "Please set the Smart HAMLOG server address/API key in the rig selection settings."); return
        }
        let (url, key, sid) = (vm.shlCloudlogUrl, vm.shlApiKey, vm.shlStationId)
        Task {
            let (sent, failed) = await SmartHamLogSync.bulkSend(url: url, key: key, stationId: sid)
            await MainActor.run { reload(); bulkMsg = failed <= 0 ? String(localized: "Smart HAMLOG send complete: \(sent)") : String(localized: "Send: \(sent) succeeded / \(failed) failed") }
        }
    }

    private func exportAdif(_ ids: Set<UUID>?) {
        let toExport: [QsoEntry]
        if let ids = ids {
            toExport = entries.filter { ids.contains($0.id) }
        } else {
            toExport = entries
        }
        guard !toExport.isEmpty else { return }
        let adif = QsoStore.buildAdif(toExport)
        let fmt = DateFormatter()
        fmt.dateFormat = "yyyyMMdd"
        fmt.timeZone = TimeZone(identifier: "UTC")
        let fname = "qso_\(fmt.string(from: Date())).adi"
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(fname)
        try? adif.write(to: url, atomically: true, encoding: .utf8)
        presentShare([url])
    }

    /// 運用地(My POTA / My SOTA)ごとに1つのADIFを生成し、まとめて共有する(2fer=複数公演に重複出力)。
    private func exportOpLocAdif(_ ids: Set<UUID>?) {
        let src: [QsoEntry] = ids != nil ? entries.filter { ids!.contains($0.id) } : entries
        guard !src.isEmpty else { return }
        var groups: [String: [QsoEntry]] = [:]     // key: "POTA_JA-1234" / "SOTA_JA/XX-001"
        for e in src {
            let potas = e.myPota.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
            let sotas = e.mySota.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
            for p in potas { groups["POTA_\(p)", default: []].append(e) }
            for s in sotas { groups["SOTA_\(s)", default: []].append(e) }
        }
        guard !groups.isEmpty else { noOpLocAlert = true; return }
        var urls: [URL] = []
        for (key, es) in groups.sorted(by: { $0.key < $1.key }) {
            let adif = QsoStore.buildAdif(es)
            let safe = key.replacingOccurrences(of: "/", with: "-").replacingOccurrences(of: " ", with: "_")
            let url = FileManager.default.temporaryDirectory.appendingPathComponent("\(safe).adi")
            try? adif.write(to: url, atomically: true, encoding: .utf8)
            urls.append(url)
        }
        presentShare(urls)
    }

    private func presentShare(_ urls: [URL]) {
        guard !urls.isEmpty else { return }
        let av = UIActivityViewController(activityItems: urls, applicationActivities: nil)
        if let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let vc = scene.windows.first?.rootViewController {
            av.popoverPresentationController?.sourceView = vc.view
            vc.present(av, animated: true)
        }
    }

    /// UTC "yyyyMMddHHmmss" → epoch ms。
    private func dtToMs(_ dt: String) -> Int64 {
        let padded = String((dt + "00000000000000").prefix(14))
        let f = DateFormatter(); f.dateFormat = "yyyyMMddHHmmss"
        f.timeZone = TimeZone(identifier: "UTC"); f.isLenient = true
        guard let d = f.date(from: padded) else { return 0 }
        return Int64(d.timeIntervalSince1970 * 1000)
    }

    /// 期間に入る交信を選択状態にし、選択モードへ。
    private func selectByPeriod(startMs: Int64, endMs: Int64) {
        let lo = min(startMs, endMs), hi = max(startMs, endMs)
        let ids = entries.filter { let t = dtToMs($0.dt); return t >= lo && t <= hi }.map { $0.id }
        selected = Set(ids)
        editMode = .active
    }

    // MARK: - SOTA chaser upload (v3.20)

    private func sotaSummary(_ r: QsoStore.SotaChaserCsv) -> String {
        var lines = [String(localized: "Submitting as chase: \(r.included)")]
        if r.skippedNoRef > 0 { lines.append(String(localized: "Excluded (no SOTA reference for the other station): \(r.skippedNoRef)")) }
        if r.skippedActivator > 0 { lines.append(String(localized: "Excluded (own SOTA reference present = activator QSO): \(r.skippedActivator)")) }
        if r.skippedInvalid > 0 { lines.append(String(localized: "Excluded (missing own callsign, date/time, or frequency): \(r.skippedInvalid)")) }
        if r.included > 0 {
            lines.append("")
            lines.append(String(localized: "After saving the CSV file to Files, the SOTAData chaser upload page will open in Safari. Select that file on the page and upload it."))
        }
        return lines.joined(separator: "\n")
    }

    /// CSV をファイルアプリに保存させ、保存できたら SOTAData のアップロード画面を Safari で開く。
    private func sendSotaChaser(_ r: QsoStore.SotaChaserCsv) {
        let fmt = DateFormatter()
        fmt.dateFormat = "yyyyMMdd_HHmm"
        fmt.timeZone = TimeZone(identifier: "UTC")
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("sota_chase_\(fmt.string(from: Date())).csv")
        do {
            try r.csv.write(to: url, atomically: true, encoding: .utf8)
        } catch {
            return
        }
        SotaUploadPresenter.shared.present(fileURL: url, uploadURL: QsoStore.sotaChaserUploadUrl)
    }

    private func formatDt(_ dt: String) -> String {
        guard dt.count >= 12 else { return dt }
        let d = dt.prefix(8)
        let t = dt.dropFirst(8).prefix(4)
        return "\(d.prefix(4))-\(d.dropFirst(4).prefix(2))-\(d.dropFirst(6)) \(t.prefix(2)):\(t.dropFirst(2))Z"
    }
}

// MARK: - Edit sheet

/// Edit an existing QSO entry (equivalent to Android's long-press "QSO 修正" dialog).
private struct QsoEditView: View {
    @Environment(\.dismiss) private var dismiss
    let vm: MainViewModel
    let entry: QsoEntry
    let onSave: (QsoEntry) -> Void

    @State private var dxGl: String = ""
    @State private var dxQth: String = ""
    @State private var qsl: String = ""
    @State private var eqslSentEdit = false
    @State private var shlSentEdit = false
    @State private var opChecked: Set<String> = []
    @State private var opInit = false

    @State private var dtDate: String = ""
    @State private var dtTime: String = ""
    @State private var callsign: String = ""
    @State private var mode: String = ""
    @State private var rstSent: String = ""
    @State private var rstRcvd: String = ""
    @State private var yourPota: String = ""
    @State private var yourSota: String = ""
    @State private var myPota: String = ""
    @State private var mySota: String = ""
    @State private var myLoc: String = ""
    @State private var jcc: String = ""
    @State private var jgc: String = ""
    @State private var comment: String = ""

    private var rstPresets: [String] {
        let m = mode.uppercased()
        if m.contains("CW") { return (1...9).map { "5\($0)9" } }
        if m.hasPrefix("FT") || m == "RTTY" { return ["-20", "-15", "-10", "-05", "00", "+05", "+10"] }
        return (1...9).map { "5\($0)" }
    }

    @ViewBuilder
    private func rstChipsView(setter: @escaping (String) -> Void) -> some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 4) {
                ForEach(rstPresets, id: \.self) { v in
                    Button(v) { setter(v) }
                        .font(.system(size: 11, design: .monospaced))
                        .foregroundStyle(.cyan)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 3)
                        .background(Color(white: 0.15), in: RoundedRectangle(cornerRadius: 4))
                        .buttonStyle(.plain)
                }
            }
        }
        .frame(height: 26)
    }

    private var localTimeStr: String {
        let s = utcToLocal(dtDate + dtTime)
        return s.isEmpty ? "" : "Local: \(s)"
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("QSO Info") {
                    LabeledContent("Freq") {
                        Text(entry.freq > 0
                            ? String(format: "%.3f MHz  %@", Double(entry.freq) / 1_000_000.0,
                                     QsoStore.freqToBand(entry.freq))
                            : "---")
                            .font(.system(size: 15, design: .monospaced))
                            .foregroundStyle(.cyan)
                    }
                    HStack {
                        Text("Mode").foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
                        TextField("CW", text: $mode)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .keyboardType(.asciiCapable)
                            .font(.system(size: 15, design: .monospaced))
                            .onChange(of: mode) { _, v in mode = v.uppercased() }
                    }
                }

                Section {
                    HStack(spacing: 8) {
                        TextField("yyyyMMdd", text: $dtDate)
                            .keyboardType(.numberPad)
                            .font(.system(size: 15, design: .monospaced))
                            .frame(maxWidth: .infinity)
                        TextField("HHmmss", text: $dtTime)
                            .keyboardType(.numberPad)
                            .font(.system(size: 15, design: .monospaced))
                            .frame(maxWidth: .infinity)
                    }
                    if !localTimeStr.isEmpty {
                        Text(localTimeStr)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                } header: {
                    Text("Date/Time UTC  (yyyyMMdd  HHmmss)")
                }

                Section("Other Station") {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("DX Callsign").font(.caption).foregroundStyle(.secondary)
                        TextField("JA2ABC", text: $callsign)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .keyboardType(.asciiCapable)
                            .font(.system(size: 22, weight: .bold, design: .monospaced))
                            .foregroundStyle(.yellow)
                            .onChange(of: callsign) { _, v in
                                callsign = v.uppercased()
                                    .filter { $0.isLetter && $0.asciiValue != nil || $0.isNumber || $0 == "/" }
                            }
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        HStack {
                            Text("RST Sent").foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
                            TextField("599", text: $rstSent)
                                .autocorrectionDisabled()
                                .textInputAutocapitalization(.characters)
                                .font(.system(size: 17, design: .monospaced))
                        }
                        rstChipsView { rstSent = $0 }
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        HStack {
                            Text("RST Rcvd").foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
                            TextField("599", text: $rstRcvd)
                                .autocorrectionDisabled()
                                .textInputAutocapitalization(.characters)
                                .font(.system(size: 17, design: .monospaced))
                        }
                        rstChipsView { rstRcvd = $0 }
                    }
                }

                Section("Other Station POTA / SOTA") {
                    HStack {
                        Text("POTA").foregroundStyle(.secondary).frame(width: 60, alignment: .leading)
                        TextField("JP-XXXX", text: $yourPota)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .onChange(of: yourPota) { _, v in yourPota = v.uppercased() }
                    }
                    HStack {
                        Text("SOTA").foregroundStyle(.secondary).frame(width: 60, alignment: .leading)
                        TextField("JA/NN-001", text: $yourSota)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .onChange(of: yourSota) { _, v in yourSota = v.uppercased() }
                    }
                    HStack {
                        Text("GL").foregroundStyle(.secondary).frame(width: 60, alignment: .leading)
                        TextField("PM95", text: $dxGl)
                            .autocorrectionDisabled().textInputAutocapitalization(.characters)
                            .onChange(of: dxGl) { _, v in dxGl = v.uppercased() }
                    }
                    HStack {
                        Text("QTH").foregroundStyle(.secondary).frame(width: 60, alignment: .leading)
                        TextField("Other Station QTH", text: $dxQth).autocorrectionDisabled()
                    }
                    Picker("QSL", selection: $qsl) {
                        Text("Blank").tag(""); Text("JARL").tag("J"); Text("hQSL").tag("H")
                        Text("No").tag("N"); Text("Card").tag("C"); Text("1-Way").tag("1")
                    }
                }

                Section("My POTA / SOTA") {
                    HStack {
                        Text("My POTA").foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
                        TextField("JP-XXXX", text: $myPota)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .onChange(of: myPota) { _, v in myPota = v.uppercased() }
                    }
                    HStack {
                        Text("My SOTA").foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
                        TextField("JA/NN-001", text: $mySota)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.characters)
                            .onChange(of: mySota) { _, v in mySota = v.uppercased() }
                    }
                    HStack {
                        Text("Location").foregroundStyle(.secondary).frame(width: 70, alignment: .leading)
                        TextField("Location name (My Park multi-location, etc.)", text: $myLoc).autocorrectionDisabled()
                    }
                }

                Section("JCC / JGC") {
                    HStack {
                        Text("JCC").foregroundStyle(.secondary).frame(width: 40, alignment: .leading)
                        TextField("1234", text: $jcc)
                            .keyboardType(.numberPad)
                        Text("JGC").foregroundStyle(.secondary).frame(width: 40, alignment: .leading)
                        TextField("12345", text: $jgc)
                            .keyboardType(.numberPad)
                    }
                }

                opSessionSection

                Section("Comment") {
                    TextField("Notes / comment", text: $comment)
                }
                Section("Sync Status (turn off and save to mark as unsent)") {
                    Toggle("eQSL Sent", isOn: $eqslSentEdit)
                    Toggle("Smart HAMLOG Synced", isOn: $shlSentEdit)
                }
            }
            .navigationTitle("Edit QSO: \(entry.call)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") { save() }
                        .disabled(callsign.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
        }
        .onAppear { load() }
    }

    @ViewBuilder private var opSessionSection: some View {
        let qsoMs = parseUtcDtMs(dtDate + dtTime)
        let activeOps = vm.activeSessionsAt(qsoMs)
        if !activeOps.isEmpty {
            Section("Operating locations for this QSO (check to apply to My POTA/SOTA/JCC/JGC; 2fer = multiple POTA)") {
                ForEach(activeOps) { s in
                    Toggle(isOn: Binding(
                        get: { opChecked.contains(s.id) },
                        set: { on in
                            if on { opChecked.insert(s.id) } else { opChecked.remove(s.id) }
                            applyOpSelection(activeOps)
                        })) {
                        Text("\(s.type)  \(s.ref)" + (s.label.isEmpty ? "" : "  (\(s.label))"))
                    }
                }
            }
            .onAppear {
                guard !opInit else { return }
                opInit = true
                // 既存の My POTA/SOTA/JCC/JGC に一致するアクティブ運用地を初期チェック
                let potas = Set(myPota.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces).uppercased() })
                var pre = Set<String>()
                for s in activeOps {
                    switch s.type {
                    case "POTA": if potas.contains(s.ref.uppercased()) { pre.insert(s.id) }
                    case "SOTA": if mySota.uppercased() == s.ref.uppercased() { pre.insert(s.id) }
                    case "JCC":  if jcc == s.ref { pre.insert(s.id) }
                    case "JGC":  if jgc == s.ref { pre.insert(s.id) }
                    default: break
                    }
                }
                opChecked = pre
            }
        }
    }

    private func applyOpSelection(_ active: [OpSession]) {
        let on = active.filter { opChecked.contains($0.id) }
        if active.contains(where: { $0.type == "POTA" }) { myPota = on.filter { $0.type == "POTA" }.map { $0.ref }.joined(separator: ",") }
        if active.contains(where: { $0.type == "SOTA" }) { mySota = on.first { $0.type == "SOTA" }?.ref ?? "" }
        if active.contains(where: { $0.type == "JCC" })  { jcc = on.first { $0.type == "JCC" }?.ref ?? "" }
        if active.contains(where: { $0.type == "JGC" })  { jgc = on.first { $0.type == "JGC" }?.ref ?? "" }
    }

    private func parseUtcDtMs(_ dt: String) -> Int64 {
        let padded = String((dt + "00000000000000").prefix(14))
        let f = DateFormatter(); f.dateFormat = "yyyyMMddHHmmss"
        f.timeZone = TimeZone(identifier: "UTC"); f.isLenient = true
        return Int64((f.date(from: padded)?.timeIntervalSince1970 ?? Date().timeIntervalSince1970) * 1000)
    }

    private func load() {
        dtDate   = String(entry.dt.prefix(8))
        dtTime   = String(entry.dt.dropFirst(8).prefix(6))
        callsign = entry.call
        mode     = entry.mode
        rstSent  = entry.rstS
        rstRcvd  = entry.rstR
        yourPota = entry.yourPota
        yourSota = entry.yourSota
        dxGl = entry.grid
        dxQth = entry.qth
        qsl = entry.qsl
        myPota   = entry.myPota
        mySota   = entry.mySota
        myLoc    = entry.myLoc
        jcc      = entry.jcc
        jgc      = entry.jgc
        comment  = entry.comment
        eqslSentEdit = entry.eqslSent
        shlSentEdit  = entry.shlSent
    }

    private func save() {
        func t(_ s: String) -> String { s.trimmingCharacters(in: .whitespaces) }
        func orKeep(_ s: String, _ old: String) -> String { s.isEmpty ? old : s }
        var e = entry
        let dt = (t(dtDate) + t(dtTime)).padding(toLength: 14, withPad: "0", startingAt: 0)
        e.dt       = dt
        e.call     = orKeep(t(callsign).uppercased(), entry.call)
        e.mode     = orKeep(t(mode).uppercased(), entry.mode)
        e.rstS     = orKeep(t(rstSent), entry.rstS)
        e.rstR     = orKeep(t(rstRcvd), entry.rstR)
        e.yourPota = t(yourPota).uppercased()
        e.yourSota = t(yourSota).uppercased()
        e.grid     = t(dxGl).uppercased()
        e.qth      = t(dxQth)
        e.qsl      = qsl
        e.myPota   = t(myPota).uppercased()
        e.mySota   = t(mySota).uppercased()
        e.myLoc    = t(myLoc)
        e.jcc      = t(jcc)
        e.jgc      = t(jgc)
        e.comment  = t(comment)
        e.eqslSent = eqslSentEdit
        e.shlSent  = shlSentEdit
        onSave(e)
        dismiss()
    }
}

// MARK: - SOTA upload helper (v3.20)

/// SOTA チェイサー CSV を「ファイル」に保存させ、保存が終わったら SOTAData のアップロード画面を
/// Safari で開く。SOTAData には外部アプリ用のアップロード API がないため、最後のファイル選択と
/// アップロードは利用者が Safari 上で行う。
final class SotaUploadPresenter: NSObject, UIDocumentPickerDelegate {
    static let shared = SotaUploadPresenter()
    private var uploadURL: URL?

    func present(fileURL: URL, uploadURL: URL) {
        self.uploadURL = uploadURL
        let picker = UIDocumentPickerViewController(forExporting: [fileURL], asCopy: true)
        picker.delegate = self
        guard let scene = UIApplication.shared.connectedScenes
                .compactMap({ $0 as? UIWindowScene })
                .first(where: { $0.activationState == .foregroundActive })
                ?? UIApplication.shared.connectedScenes.first as? UIWindowScene,
              var top = scene.windows.first(where: { $0.isKeyWindow })?.rootViewController
                ?? scene.windows.first?.rootViewController
        else { return }
        while let presented = top.presentedViewController { top = presented }
        top.present(picker, animated: true)
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let url = uploadURL else { return }
        uploadURL = nil
        UIApplication.shared.open(url)
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        uploadURL = nil
    }
}

// MARK: - 期間選択シート (UTC / ローカル)

/// 開始・終了を指定して範囲内の交信を選択する。トグルで UTC / ローカル時刻の解釈を切り替える。
/// (Android の showPeriodSelectDialog に相当)
private struct PeriodSelectSheet: View {
    let onApply: (_ startMs: Int64, _ endMs: Int64) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var useLocal = true
    @State private var start = Date().addingTimeInterval(-3 * 3600)
    @State private var end = Date()

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Toggle("Specify in local time", isOn: $useLocal)
                    Text(useLocal
                         ? "The picker time is interpreted as local time."
                         : "The time shown in the picker is interpreted as UTC.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                DatePicker("Start", selection: $start)
                DatePicker("End", selection: $end)
            }
            .navigationTitle("Select by Period")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Select This Period") {
                        onApply(toMs(start, asUtc: !useLocal), toMs(end, asUtc: !useLocal))
                        dismiss()
                    }
                }
            }
        }
    }

    /// ピッカーのローカル壁時計を、UTC指定時はその数字のまま UTC として解釈し直す。
    private func toMs(_ d: Date, asUtc: Bool) -> Int64 {
        if !asUtc { return Int64(d.timeIntervalSince1970 * 1000) }
        var localCal = Calendar(identifier: .gregorian); localCal.timeZone = .current
        let c = localCal.dateComponents([.year, .month, .day, .hour, .minute, .second], from: d)
        var utcCal = Calendar(identifier: .gregorian); utcCal.timeZone = TimeZone(identifier: "UTC")!
        let u = utcCal.date(from: c) ?? d
        return Int64(u.timeIntervalSince1970 * 1000)
    }
}
