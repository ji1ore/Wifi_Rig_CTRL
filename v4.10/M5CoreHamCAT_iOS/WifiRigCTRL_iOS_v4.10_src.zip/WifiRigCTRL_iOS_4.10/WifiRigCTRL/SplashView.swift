import SwiftUI

struct SplashView: View {
    var onContinue: () -> Void
    /// Performs the SP2Alert hunt/chase log import and returns the result. Supplied by ContentView.
    var performImport: (() -> Sp2alertLogImporter.Result)? = nil
    @AppStorage("importSp2alertLog") private var importSp2alertLog = false
    @State private var importMessage: String? = nil
    @State private var showButton: Bool = false
    @State private var glow: Bool = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.12, green: 0.20, blue: 0.55),  // deep blue
                    Color(red: 0.45, green: 0.20, blue: 0.70),  // purple
                    Color(red: 0.85, green: 0.30, blue: 0.55),  // pink
                    Color(red: 0.95, green: 0.55, blue: 0.30)   // warm amber
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 16) {
                Image("AppLogo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
                    .clipShape(RoundedRectangle(cornerRadius: 22))
                    .shadow(color: .white.opacity(glow ? 0.7 : 0.3), radius: glow ? 18 : 8)
                    .animation(.easeInOut(duration: 1.4).repeatForever(autoreverses: true), value: glow)
                Text("Wifi_RIG_CTRL")
                    .font(.largeTitle.bold())
                    .foregroundStyle(.white)
                Text("WiFi Ham Radio Controller")
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.85))

                Toggle(isOn: $importSp2alertLog) {
                    Text("Import SP2Alert POTA/SOTA hunt/chase log on startup")
                        .font(.footnote)
                        .foregroundStyle(.white)
                }
                .tint(.white)
                .padding(.horizontal, 32)
                .onChange(of: importSp2alertLog) { _, newValue in
                    if newValue { runImport() }
                }
                if let importMessage {
                    Text(importMessage)
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.9))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 24)
                }

                Spacer().frame(height: 24)
                if showButton {
                    Button("Start") { onContinue() }
                        .buttonStyle(.borderedProminent)
                        .controlSize(.large)
                        .tint(.white)
                        .foregroundStyle(Color(red: 0.45, green: 0.20, blue: 0.70))
                        .transition(.opacity)
                } else {
                    ProgressView().tint(.white)
                }
            }
        }
        .task {
            glow = true
            // 起動時：既に有効なら SP2Alert ログを自動取得
            if importSp2alertLog { runImport() }
            try? await Task.sleep(nanoseconds: 1_000_000_000)
            withAnimation { showButton = true }
            try? await Task.sleep(nanoseconds: 7_000_000_000)
            onContinue()
        }
    }

    private func runImport() {
        guard let performImport else { return }
        let r = performImport()
        importMessage = r.available
            ? String(localized: "SP2Alert import: POTA \(r.pota) / SOTA \(r.sota)")
            : String(localized: "SP2Alert shared data not found")
    }
}
