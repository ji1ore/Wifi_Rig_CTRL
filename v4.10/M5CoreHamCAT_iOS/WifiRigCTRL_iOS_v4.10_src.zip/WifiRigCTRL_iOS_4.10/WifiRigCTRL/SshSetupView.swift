import SwiftUI
import Citadel
import NIOCore

struct SshSetupView: View {
    @Bindable var vm: MainViewModel

    @State private var host: String = ""
    @State private var sshUser: String = "pi"
    @State private var sshPassword: String = ""
    @State private var statusText: String = String(localized: "Connect to the Pi via SSH and run setup")
    @State private var statusColor: Color = .secondary
    @State private var logLines: [String] = []
    @State private var isRunning: Bool = false
    // VNC/デスクトップ選択: none(VNCなし) / xfce / pixel。Android と同じ UserDefaults キー。
    @AppStorage("vncDesktop") private var vncDesktop: String = "none"

    // SSH(22番)サブネット走査による Pi 自動検索
    @State private var isScanning: Bool = false
    @State private var foundHosts: [SshHost] = []
    @State private var showScanResults: Bool = false
    @State private var showNoHostAlert: Bool = false

    var body: some View {
        VStack(spacing: 0) {
            Form {
                Section(header: Label("Pi Connection", systemImage: "network").foregroundStyle(.indigo)) {
                    LabeledContent("IP / Host") {
                        TextField("192.168.1.100 or raspberrypi.local", text: $host)
                            .multilineTextAlignment(.trailing)
                            .keyboardType(.URL)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                    }
                    Button {
                        Task { await scanForPi() }
                    } label: {
                        HStack {
                            Label(isScanning ? String(localized: "Searching...") : String(localized: "Find Pi on network"),
                                  systemImage: "magnifyingglass")
                                .foregroundStyle(isScanning ? AnyShapeStyle(.secondary) : AnyShapeStyle(.green))
                            Spacer()
                            if isScanning { ProgressView() }
                        }
                    }
                    .disabled(isScanning || isRunning)
                    LabeledContent("SSH User") {
                        TextField("pi", text: $sshUser)
                            .multilineTextAlignment(.trailing)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                    }
                    LabeledContent("SSH Password") {
                        SecureField("raspberry", text: $sshPassword)
                            .multilineTextAlignment(.trailing)
                    }
                }

                Section(header: Label("VNC Desktop", systemImage: "display").foregroundStyle(.indigo)) {
                    Picker("VNC", selection: $vncDesktop) {
                        Text("XFCE").tag("xfce")
                        Text("PIXEL").tag("pixel")
                        Text("None").tag("none")
                    }
                    .pickerStyle(.segmented)
                }

                Section {
                    Text("⚠ While running, do not turn off the screen or switch to another screen (Pi Zero 2W takes over 1 hour; including UPDATE, about 1 hour 30 minutes)")
                        .font(.caption)
                        .foregroundStyle(.orange)

                    Button {
                        Task { await runSetup() }
                    } label: {
                        HStack {
                            if isRunning { ProgressView().padding(.trailing, 4) }
                            Text(isRunning ? String(localized: "Setting up...") : "Run Setup")
                                .frame(maxWidth: .infinity)
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.indigo)
                    .disabled(isRunning || host.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
            .frame(maxHeight: 360)

            Text(statusText)
                .font(.callout)
                .foregroundStyle(statusColor)
                .padding(.horizontal)
                .padding(.vertical, 4)

            ScrollViewReader { proxy in
                ScrollView {
                    Text(logLines.joined(separator: "\n"))
                        .font(.system(.caption, design: .monospaced))
                        .foregroundStyle(.green)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(8)
                        .id("logEnd")
                }
                .background(Color(white: 0.05))
                .onChange(of: logLines.count) { _, _ in
                    withAnimation { proxy.scrollTo("logEnd", anchor: .bottom) }
                }
            }
        }
        .navigationTitle("SETUP (SSH)")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            if host.isEmpty { host = vm.hostName }
        }
        .confirmationDialog(String(localized: "Devices found (SSH)"),
                            isPresented: $showScanResults, titleVisibility: .visible) {
            ForEach(foundHosts) { h in
                Button(h.label) { host = h.ip }
            }
            Button(String(localized: "Cancel"), role: .cancel) {}
        }
        .alert(String(localized: "No device found"), isPresented: $showNoHostAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("No host with SSH (port 22) open was found.\nMake sure the Pi is powered on with SSH enabled, and that this device is on the same Wi-Fi.")
        }
    }

    // MARK: - Pi search (SSH port 22 subnet scan)

    private func scanForPi() async {
        isScanning = true
        let hosts = await scanSshHosts()
        isScanning = false
        if hosts.isEmpty {
            showNoHostAlert = true
        } else {
            foundHosts = hosts
            showScanResults = true
        }
    }

    // MARK: - SSH setup

    @MainActor
    private func appendLog(_ line: String) {
        logLines.append(line)
    }

    @MainActor
    private func runSetup() async {
        let targetHost = host.trimmingCharacters(in: .whitespaces)
        guard !targetHost.isEmpty else { return }

        logLines = []
        isRunning = true
        // Pi セットアップは Pi Zero 2W で1時間以上かかる。実行中は画面を常時ONにして
        // 自動消灯（＝セットアップ中断）を防ぐ。終了・エラー・画面離脱のいずれでも
        // defer でユーザー設定の画面タイムアウトへ確実に戻す。
        UIApplication.shared.isIdleTimerDisabled = true
        defer {
            isRunning = false
            vm.applyWakeLock()
        }
        statusText = String(localized: "Connecting to \(targetHost)...")
        statusColor = .secondary

        // Load asset files from app bundle
        let assetNames = ["api.py", "create_api.sh", "cw_bridge.py",
                          "setup_fastapi_radio.sh", "set_api_key.sh"]
        var assetFiles: [(name: String, data: Data)] = []
        for name in assetNames {
            let parts = name.split(separator: ".", maxSplits: 1)
            let resName = String(parts[0])
            let resExt  = parts.count > 1 ? String(parts[1]) : ""
            guard let url = Bundle.main.url(forResource: resName, withExtension: resExt),
                  let data = try? Data(contentsOf: url) else {
                appendLog(String(localized: "ERROR: \(name) not found in bundle"))
                statusText = String(localized: "Error: bundle file not found")
                statusColor = .red
                return
            }
            assetFiles.append((name: name, data: data))
        }

        do {
            let client = try await SSHClient.connect(
                host: targetHost,
                authenticationMethod: .passwordBased(username: sshUser, password: sshPassword),
                hostKeyValidator: .acceptAnything(),
                reconnect: .never
            )
            defer { Task { try? await client.close() } }

            appendLog(String(localized: "SSH connection established"))
            statusText = String(localized: "Transferring files (SFTP)...")

            // Step 1: Upload files via SFTP
            try await client.withSFTP { sftp in
                for (name, data) in assetFiles {
                    let handle = try await sftp.openFile(
                        filePath: name,
                        flags: [.write, .create, .truncate],
                        attributes: .init()
                    )
                    let buf = ByteBuffer(bytes: Array(data))
                    try await handle.write(buf, at: 0)
                    try await handle.close()
                    await MainActor.run { self.appendLog(String(localized: "Transferred: \(name) (\(data.count / 1024)KB)")) }
                }
            }
            appendLog(String(localized: "✓ File transfer complete"))

            // Step 2: Set execute permissions
            _ = try await client.executeCommand(
                "chmod +x ~/setup_fastapi_radio.sh ~/create_api.sh ~/set_api_key.sh"
            )
            appendLog(String(localized: "✓ Execute permissions set"))
            appendLog(String(localized: "Running setup script... (Pi Zero 2W takes over 1 hour)"))
            statusText = String(localized: "Setting up... please wait")

            // Concurrent timer — shows elapsed time every 30 s while SSH command runs
            let startTime = Date()
            let timerTask = Task { @MainActor in
                while !Task.isCancelled {
                    try? await Task.sleep(nanoseconds: 30_000_000_000)
                    guard !Task.isCancelled else { break }
                    let elapsed = Int(-startTime.timeIntervalSinceNow)
                    appendLog(String(localized: "⏳ Running... \(elapsed)s elapsed"))
                }
            }

            // Step 3: Run setup script via sudo -S (password fed through printf)
            let escapedPass = sshPassword
                .replacingOccurrences(of: "\\", with: "\\\\")
                .replacingOccurrences(of: "'", with: "'\\''")
            let setupCmd =
                "printf '%s\\n' '\(escapedPass)' | sudo -S bash ~/setup_fastapi_radio.sh \(vncDesktop) 2>&1; true"
            let output = try await client.executeCommand(setupCmd, maxResponseSize: 10 * 1024 * 1024)
            timerTask.cancel()

            // Append output lines to log
            if let text = output.getString(at: output.readerIndex, length: output.readableBytes),
               !text.isEmpty {
                for line in text.components(separatedBy: .newlines) where !line.isEmpty {
                    appendLog(line)
                }
            }

            appendLog(String(localized: "── Setup complete ──"))
            appendLog("")
            appendLog(String(localized: "[Next steps]"))
            appendLog(String(localized: "  1. Open the app's UPDATE screen"))
            appendLog(String(localized: "  2. Run \"Update Pi\""))
            appendLog(String(localized: "     → The mfsk-decode build also starts automatically (10–20 min)"))
            statusText = String(localized: "✓ SETUP complete — next, run \"Update Pi\" on the UPDATE screen")
            statusColor = .green

        } catch {
            appendLog("ERROR: \(error.localizedDescription)")
            statusText = "Error: \(error.localizedDescription)"
            statusColor = .red
        }
    }
}
