import SwiftUI

struct WireGuardSetupView: View {
    @Bindable var vm: MainViewModel

    @State private var piHost: String = ""
    @State private var domain: String = ""
    @State private var token: String = ""
    @State private var staticIp: String = ""
    @State private var useStaticIp: Bool = true
    @State private var newApiKey: String = ""
    @State private var sudoPass: String = ""
    @State private var statusText: String = String(localized: "Enter domain and token (run after SSH setup completes)")
    @State private var statusColor: Color = .secondary
    @State private var logLines: [String] = []
    @State private var isRunning: Bool = false
    @State private var pendingConf: String? = nil
    @State private var showTokenScanner: Bool = false

    var body: some View {
        VStack(spacing: 0) {
            Form {
                Section(header: Label("Pi Connection", systemImage: "network").foregroundStyle(.indigo)) {
                    LabeledContent("Pi IP") {
                        TextField("192.168.1.100", text: $piHost)
                            .multilineTextAlignment(.trailing)
                            .keyboardType(.numbersAndPunctuation)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                    }
                    Toggle("Set static IP", isOn: $useStaticIp)
                    if useStaticIp {
                        LabeledContent("Static IP") {
                            TextField("192.168.1.60", text: $staticIp)
                                .multilineTextAlignment(.trailing)
                                .keyboardType(.numbersAndPunctuation)
                                .autocapitalization(.none)
                                .disableAutocorrection(true)
                        }
                    }
                }

                Section(header: Label("DuckDNS", systemImage: "globe").foregroundStyle(.teal)) {
                    LabeledContent("Domain") {
                        TextField("myhome", text: $domain)
                            .multilineTextAlignment(.trailing)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                    }
                    LabeledContent("Token") {
                        HStack(spacing: 6) {
                            TextField("xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx", text: $token)
                                .multilineTextAlignment(.trailing)
                                .autocapitalization(.none)
                                .disableAutocorrection(true)
                            Button {
                                showTokenScanner = true
                            } label: {
                                Image(systemName: "camera.viewfinder")
                                    .foregroundStyle(.teal)
                            }
                            .buttonStyle(.borderless)
                        }
                    }
                }

                Section(header: Label("API key (required)", systemImage: "key.fill").foregroundStyle(.yellow)) {
                    LabeledContent("API key") {
                        TextField("Auto-generated", text: $newApiKey)
                            .multilineTextAlignment(.trailing)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                            .foregroundStyle(.yellow)
                    }
                    Text("Set on the Pi during WireGuard setup and saved automatically in the app. Matches the \"API Key\" on the Connect screen.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section(header: Label("Pi password (for sudo)", systemImage: "lock").foregroundStyle(.orange)) {
                    LabeledContent("Password") {
                        SecureField("Pi login password (for sudo)", text: $sudoPass)
                            .multilineTextAlignment(.trailing)
                    }
                    Text("Enter the Pi login password. Used to install WireGuard and set the API key.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section {
                    Button {
                        Task { await runSetup() }
                    } label: {
                        HStack {
                            if isRunning { ProgressView().padding(.trailing, 4) }
                            Text(isRunning ? String(localized: "Setting up...") : String(localized: "Start WireGuard setup"))
                                .frame(maxWidth: .infinity)
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.blue)
                    .disabled(isRunning || piHost.isEmpty || domain.isEmpty || token.isEmpty || newApiKey.isEmpty)
                }

                if let conf = pendingConf {
                    Section {
                        ShareLink(
                            item: conf,
                            preview: SharePreview(
                                "WG_Raspi.conf",
                                icon: Image(systemName: "doc.fill")
                            )
                        ) {
                            Label("Import into WireGuard app", systemImage: "square.and.arrow.up")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(.green)
                    }
                }
            }
            .frame(maxHeight: 520)

            Text(statusText)
                .font(.callout)
                .foregroundStyle(statusColor)
                .padding(.horizontal)
                .padding(.vertical, 4)

            ScrollViewReader { proxy in
                ScrollView {
                    Text(logLines.joined(separator: "\n"))
                        .font(.system(.caption, design: .monospaced))
                        .foregroundStyle(.green)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(8)
                        .id("logEnd")
                }
                .background(Color(white: 0.05))
                .onChange(of: logLines.count) { _, _ in
                    withAnimation { proxy.scrollTo("logEnd", anchor: .bottom) }
                }
            }
        }
        .sheet(isPresented: $showTokenScanner) {
            TokenCameraScanSheet { found in
                token = found
            }
        }
        .navigationTitle("WireGuard Setup")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            if piHost.isEmpty { piHost = vm.hostName }
            if staticIp.isEmpty { staticIp = vm.hostName }
            // API キー: 既存キーがあれば表示、なければ UUID 自動生成
            if newApiKey.isEmpty {
                newApiKey = vm.apiKey.isEmpty ? UUID().uuidString.lowercased() : vm.apiKey
            }
        }
    }

    // MARK: - Actions

    @MainActor
    private func appendLog(_ line: String) {
        logLines.append(line)
        if logLines.count > 80 { logLines.removeFirst(logLines.count - 80) }
    }

    @MainActor
    private func runSetup() async {
        guard !piHost.isEmpty, !domain.isEmpty, !token.isEmpty, !newApiKey.isEmpty else { return }
        logLines = []
        pendingConf = nil
        isRunning = true
        statusText = String(localized: "Sending api.py to the Pi...")
        statusColor = .secondary

        let port = vm.apiPort
        let apiKey = vm.apiKey

        // Step 1: push api.py
        let pushOk = await pushApiPy(host: piHost, port: port, apiKey: apiKey)
        if pushOk {
            appendLog(String(localized: "[Prep] api.py sent — waiting 5 seconds..."))
            try? await Task.sleep(nanoseconds: 5_000_000_000)
        } else {
            appendLog(String(localized: "[Warning] api.py send failed — continuing anyway"))
        }

        // Step 2: WireGuard setup
        statusText = String(localized: "Setting up WireGuard...")
        await runSseSetup(host: piHost, port: port, apiKey: apiKey)

        // IP 変更時は新しい IP に接続し直す
        let newStaticIp = useStaticIp ? staticIp.trimmingCharacters(in: .whitespaces) : ""
        let effectiveHost = newStaticIp.isEmpty ? piHost : newStaticIp
        if effectiveHost != piHost {
            appendLog(String(localized: "[API Key] Waiting to connect to the Pi after IP change..."))
            try? await Task.sleep(nanoseconds: 10_000_000_000)
        }

        // Step 3: set API key on Pi and save locally（最大6回リトライ）
        statusText = String(localized: "Setting the API key on the Pi...")
        var keyOk = false
        let maxAttempts = effectiveHost != piHost ? 6 : 2
        for attempt in 1...maxAttempts {
            if attempt > 1 {
                appendLog(String(localized: "[API Key] Waiting to connect... (\(attempt)/\(maxAttempts))"))
                try? await Task.sleep(nanoseconds: 5_000_000_000)
            }
            keyOk = await setApiKeyOnPi(host: effectiveHost, port: port, currentApiKey: apiKey, newApiKey: newApiKey)
            if keyOk { break }
        }
        if keyOk {
            vm.apiKey = newApiKey
            KeychainHelper.save(newApiKey, forKey: "apiKey")
            appendLog(String(localized: "[API Key] Set on the Pi and saved in the app"))
            statusText = pendingConf != nil ? String(localized: "Done! Import it into the WireGuard app") : String(localized: "Setup complete")
            statusColor = .green
        } else {
            appendLog(String(localized: "⚠ Failed to set the API key on the Pi. Set it manually on the Connect screen."))
            statusText = String(localized: "WireGuard done (API Key setup failed)")
            statusColor = .orange
        }

        isRunning = false
    }

    private func pushApiPy(host: String, port: Int, apiKey: String) async -> Bool {
        guard let url = Bundle.main.url(forResource: "api", withExtension: "py"),
              let data = try? Data(contentsOf: url) else { return false }
        guard let endpoint = URL(string: "http://\(host):\(port)/admin/update") else { return false }
        var req = URLRequest(url: endpoint)
        req.httpMethod = "POST"
        req.setValue("application/octet-stream", forHTTPHeaderField: "Content-Type")
        if !apiKey.isEmpty { req.setValue(apiKey, forHTTPHeaderField: "X-API-Key") }
        req.timeoutInterval = 30
        req.httpBody = data
        do {
            let (_, resp) = try await URLSession.shared.data(for: req)
            return (resp as? HTTPURLResponse)?.statusCode == 200
        } catch { return false }
    }

    private func setApiKeyOnPi(host: String, port: Int, currentApiKey: String, newApiKey: String) async -> Bool {
        guard let endpoint = URL(string: "http://\(host):\(port)/admin/set_api_key") else { return false }
        guard let body = try? JSONSerialization.data(withJSONObject: ["new_key": newApiKey]) else { return false }
        var req = URLRequest(url: endpoint)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if !currentApiKey.isEmpty { req.setValue(currentApiKey, forHTTPHeaderField: "X-API-Key") }
        req.timeoutInterval = 35
        req.httpBody = body
        do {
            let (_, resp) = try await URLSession.shared.data(for: req)
            return (resp as? HTTPURLResponse)?.statusCode == 200
        } catch { return false }
    }

    @MainActor
    private func runSseSetup(host: String, port: Int, apiKey: String) async {
        guard let url = URL(string: "http://\(host):\(port)/wireguard/setup") else { return }

        var body: [String: Any] = [
            "ddns_domain": domain.trimmingCharacters(in: .whitespaces).lowercased(),
            "ddns_token":  token.trimmingCharacters(in: .whitespaces),
            "static_ip":   useStaticIp ? staticIp.trimmingCharacters(in: .whitespaces) : "",
        ]
        let pass = sudoPass.trimmingCharacters(in: .whitespaces)
        if !pass.isEmpty { body["sudo_pass"] = pass }
        guard let bodyData = try? JSONSerialization.data(withJSONObject: body) else { return }

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("text/event-stream", forHTTPHeaderField: "Accept")
        if !apiKey.isEmpty { req.setValue(apiKey, forHTTPHeaderField: "X-API-Key") }
        req.timeoutInterval = 600
        req.httpBody = bodyData

        do {
            let (asyncBytes, response) = try await URLSession.shared.bytes(for: req)
            guard let http = response as? HTTPURLResponse else { return }
            if http.statusCode != 200 {
                appendLog("ERROR: HTTP \(http.statusCode)")
                statusText = String(localized: "Error: HTTP \(http.statusCode)")
                statusColor = .red
                return
            }

            var lineBuffer = ""
            for try await byte in asyncBytes {
                guard let ch = String(bytes: [byte], encoding: .utf8) else { continue }
                lineBuffer += ch
                guard lineBuffer.hasSuffix("\n") else { continue }
                let line = lineBuffer.trimmingCharacters(in: .newlines)
                lineBuffer = ""
                guard line.hasPrefix("data: ") else { continue }
                let jsonStr = String(line.dropFirst(6))
                guard let jsonData = jsonStr.data(using: .utf8),
                      let obj = try? JSONSerialization.jsonObject(with: jsonData) as? [String: Any]
                else { continue }
                handleEvent(obj)
            }

        } catch {
            appendLog(String(localized: "Connection error: \(error.localizedDescription)"))
            statusText = String(localized: "Error: \(error.localizedDescription)")
            statusColor = .red
        }
    }

    @MainActor
    private func handleEvent(_ obj: [String: Any]) {
        switch obj["type"] as? String {
        case "log":
            if let msg = obj["msg"] as? String { appendLog(msg) }
        case "info":
            if let ip = obj["pi_ip"] as? String, !ip.isEmpty {
                statusText = String(localized: "Pi IP: \(ip) — configuring...")
            }
        case "config":
            if let text = obj["text"] as? String, !text.isEmpty {
                pendingConf = text
                appendLog(String(localized: "=== Client config file generated ==="))
            }
        case "error":
            let msg = obj["msg"] as? String ?? "Unknown error"
            appendLog("ERROR: \(msg)")
            statusText = String(localized: "Error: \(msg)")
            statusColor = .red
        default: break
        }
    }
}
