from contextlib import asynccontextmanager
from fastapi import FastAPI, BackgroundTasks, Depends, HTTPException, Request, Security, Form, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, PlainTextResponse
from fastapi.security import APIKeyHeader
from fastapi.staticfiles import StaticFiles
from starlette.background import BackgroundTask
from pydantic import BaseModel
import array
import glob
import os
from pathlib import Path
import queue as _queue
import select
import signal
import socket
import struct
import subprocess
import threading
import time
import asyncio
import hmac
import re
import datetime
try:
    import serial as _serial
    _HAS_SERIAL = True
except ImportError:
    _HAS_SERIAL = False

# API Key 認証（環境変数 API_KEY が設定されている場合のみ有効）
API_KEY = os.environ.get("API_KEY", "")
API_VERSION = "4.10"

# ALSAデバイス設定 (環境変数 or POST /radio/audio_device で変更可)
_alsa_capture_dev  = os.environ.get("ALSA_CAPTURE",  "plughw:CARD=CODEC,DEV=0")
_alsa_playback_dev = os.environ.get("ALSA_PLAYBACK", "plughw:CARD=CODEC,DEV=0")

def _alsa_card_name(dev: str) -> str:
    import re
    m = re.search(r'CARD=([^,]+)', dev)
    return m.group(1) if m else ""

def _alsa_init_volume():
    card = _alsa_card_name(_alsa_playback_dev)
    if not card:
        return
    for ctrl in ["PCM", "Speaker", "Headphone", "Master"]:
        r = subprocess.run(["amixer", "-c", card, "sset", ctrl, "100%"],
                           capture_output=True)
        if r.returncode == 0:
            print(f"[alsa_init] {card} '{ctrl}' set to 100%")
            break

_alsa_init_volume()
_api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)

async def verify_key(key: str = Security(_api_key_header), api_key: str = Query(default=None)):
    actual = key or api_key or ""
    if API_KEY and not hmac.compare_digest(actual, API_KEY):
        raise HTTPException(status_code=403, detail="Forbidden")

import logging as _logging

class _SuppressConnErrors(_logging.Filter):
    _SKIP = ("Broken pipe", "Connection reset", "EPIPE", "ConnectionResetError")
    def filter(self, record):
        msg = record.getMessage()
        return not any(s in msg for s in self._SKIP)

_logging.getLogger("uvicorn.error").addFilter(_SuppressConnErrors())

@asynccontextmanager
async def lifespan(app: FastAPI):
    threading.Thread(target=watchdog_heartbeat, daemon=True).start()
    threading.Thread(target=_ensure_venv_numpy, daemon=True).start()
    threading.Thread(target=_ensure_minimodem, daemon=True).start()
    threading.Thread(target=_ensure_sstv, daemon=True).start()
    yield

app = FastAPI(dependencies=[Depends(verify_key)], lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# 動的パス（ユーザー名に依存しない）
_HOME_DIR = Path(__file__).resolve().parent.parent  # /home/<user>
_FASTAPI_DIR = Path(__file__).resolve().parent       # /home/<user>/fastapi
_VENV_PY = str(_FASTAPI_DIR / "bin" / "python3")
_CW_BRIDGE_PY = str(_HOME_DIR / "cw_bridge.py")

# ─── FT8 サーバーサイドデコード ────────────────────────────────────────────
import wave
import tempfile
import json as _json

_ft8_rx_clients: list = []
_ft8_rx_clients_lock = threading.Lock()
_ft8_decode_running  = False
_ft8_decode_thread: threading.Thread | None = None
_jt9_decode_done = threading.Event()
_jt9_decode_done.set()  # 初期値: jt9未実行 = "完了" 状態
_mfsk_binary_warning_sent = False  # system_msg を1回だけ送る

FT8_SAMPLE_RATE = 12000
FT8_PERIOD_S    = 15.0
FT8_BYTES       = int(FT8_SAMPLE_RATE * FT8_PERIOD_S) * 2  # 360000

_MFSK_DECODE_BIN = os.environ.get(
    "MFSK_DECODE_BIN",
    os.path.expanduser("~/mfsk-decode/target/release/mfsk-decode")
)
_ft8_last_decode_info: dict = {"stdout": "", "stderr": "", "decoded": 0, "period": -1}
_ft8_decode_depth: int = 1  # 1=fast(sync>=3.0,75cand) 2=normal(sync>=1.0,200cand) 3=deep(sync>=0.5,300cand)
_ft8_decode_filter: list = []  # [(center_hz, range_hz), ...], empty = no filter
_ft8_is_ft4: bool = False   # True=FT4 mode (7.5s period), False=FT8 (15s period)
# 2段デコード: 多局/高depthで前周期の復号が次TX境界までに終わらず返信が1サイクル遅れる対策。
# ON時、各RX周期で (1)早期=周期末より手前で打ち切った音声を depth1・表示なしで復号しQSO SMで
# 返信を前倒し確定、(2)フル=フル長・選択depth・表示のみ(QSO SMなし) の2本を走らせる。
# 表示用はフル長のため、表示される信号数は減らない。OFF=従来(フル1本・QSO SMあり)。
_ft8_two_stage: bool = False
_FT8_EARLY_TAIL_S: float = 1.5  # FT8(15s周期)で早期復号用に末尾からスキップする秒(後方ガード)
_FT4_EARLY_TAIL_S: float = 0.8  # FT4(7.5s周期)用
_ALL_TXT_PATH: str = os.path.expanduser("~/ALL.TXT")

# ─── AutoTX state ───────────────────────────────────────────────────────────
_auto_tx: dict = {
    "active": False,
    "mode": "even",   # "even"=period 0,2 (UTC 0s/30s)  /  "odd"=period 1,3 (15s/45s)
    "msg": "",
    "audio_freq": 1500,
}

# ─── CQ AUTO mode ────────────────────────────────────────────────────────────
_cq_auto: dict = {
    "active": False,
    "msg": "",         # CQ message (e.g. "CQ JH1XYZ PM95")
    "mode": "even",
    "audio_freq": 1500,
    "my_call": "",
    "my_grid": "",
}

# ─── QSO sequence state machine ─────────────────────────────────────────────
# state: 0=send_first 1=wait_report 2=send_rr73 3=wait_73 4=done
_qso: dict = {
    "active": False,
    "dx_call": "",
    "my_call": "",
    "state": 0,
    # state 0=send_step1  1=wait_reply1
    # state 2=send_step2  3=wait_reply2
    # state 4=send_step3  5=wait_step4  6=done
    "tx_mode": "odd",
    "audio_freq": 1500,
    "next_msg": "",
    "step1_msg":   "",    # DX MY GRID
    "step_snr_msg":"",   # DX MY NN   (Rなし SNR。DX指定でstep1→step2として使用、空なら省略)
    "step2_msg":   "",   # DX MY R-NN (空なら skip して step3 へ)
    "step3_msg":   "",   # DX MY RR73
    "step4_msg":   "",   # DX MY 73   (空なら step3 後に done)
    "snr_rcvd": "",      # DX からの SNR レポート
    "snr_sent": "",      # こちらから送った SNR レポート
    "snr_dx_peak": None, # QSO 中に受信した DX の最強 SNR (int)
    "cq_sender": False,  # True=CQ発信側（step2はSNRのみ）、False=DX指定呼び出し側（R-SNR）
}


_ft8_known_calls: set = set()  # セッション中に確認されたコールサイン
_ft8_my_call: str = ""        # 最後に設定された自局コールサイン（QSO外でも参照用）
_last_compound_dx: str = ""   # 最後にデコードされた複合コールサイン（/付き）


def _is_unknown_hash(tok: str) -> bool:
    """<...> <......> など jt9 の未解決ハッシュトークンを判定（ドット数不問）"""
    return (len(tok) >= 4 and tok[0] == '<' and tok[-1] == '>'
            and len(tok[1:-1]) > 0 and all(c in '.?' for c in tok[1:-1]))


def _resolve_unknown_hashes(msgs: list) -> list:
    """jt9 が解決できなかった <...> をQSOコンテキストの既知コールサインで置換。
    Type 4 メッセージで複合コールサインと組み合わさると my_call も <...> になるため。"""
    global _ft8_known_calls, _last_compound_dx

    # 今期のデコード済みコールサインをセッションキャッシュに追加
    for m in msgs:
        for tok in m["msg"].split():
            clean = tok.strip("<>")
            if clean and clean != "..." and not all(c in ".?" for c in clean):
                clean_upper = clean.upper()
                _ft8_known_calls.add(clean_upper)
                # 複合コールサイン（/付き）は最後にデコードされたものを記録
                if "/" in clean_upper:
                    _last_compound_dx = clean_upper

    qso_active = _qso.get("active", False)
    qso_dx = _qso.get("dx_call", "").upper()
    qso_my = _qso.get("my_call", "").upper() or _ft8_my_call.upper()

    # QSO外でも my_call が既知なら、複合コールサイン候補（/を含む）を探す
    compound_candidates = sorted(
        {c for c in _ft8_known_calls if "/" in c}, key=len
    ) if not qso_active else []

    result = []
    for m in msgs:
        parts = m["msg"].split()
        if len(parts) >= 2:
            p0 = parts[0].strip("<>").upper()
            p1 = parts[1].strip("<>").upper()
            uh0 = _is_unknown_hash(parts[0])
            uh1 = _is_unknown_hash(parts[1])
            if uh0 or uh1:
                print(f"[hash_resolve] msg={m['msg']!r} qso_active={qso_active} qso_dx={qso_dx!r} qso_my={qso_my!r} uh0={uh0} uh1={uh1} compound_cands={compound_candidates}")
            if qso_active:
                # position 0 が DX、position 1 が <...> → my_call で置換
                if qso_dx and qso_my and p0 == qso_dx and uh1:
                    m = dict(m); parts[1] = qso_my; m["msg"] = " ".join(parts)
                # position 0 が my_call、position 1 が <...> → dx_call で置換
                elif qso_my and qso_dx and p0 == qso_my and uh1:
                    m = dict(m); parts[1] = qso_dx; m["msg"] = " ".join(parts)
                # position 0 が <...>、position 1 が DX → my_call で置換
                elif qso_dx and qso_my and uh0 and p1 == qso_dx:
                    m = dict(m); parts[0] = qso_my; m["msg"] = " ".join(parts)
                # position 0 が <...>、position 1 が my_call → dx_call で置換
                elif qso_my and qso_dx and uh0 and p1 == qso_my:
                    m = dict(m); parts[0] = qso_dx; m["msg"] = " ".join(parts)
            elif qso_my and uh0 and p1 == qso_my and len(compound_candidates) == 1:
                # QSO外: position 0 が <...>、position 1 が my_call、複合候補が1局のみ
                m = dict(m); parts[0] = compound_candidates[0]; m["msg"] = " ".join(parts)
        result.append(m)
    return result


def _ft8_broadcast(data: dict):
    msg = ("data: " + _json.dumps(data, ensure_ascii=False) + "\n\n").encode()
    with _ft8_rx_clients_lock:
        for q in list(_ft8_rx_clients):
            if q.full():
                try: q.get_nowait()
                except _queue.Empty: pass
            try: q.put_nowait(msg)
            except _queue.Full: pass


def _parse_jt9_output(stdout: str) -> list:
    """jt9 出力をパース。フォーマットはバージョンにより異なる。
    確認済みフォーマット例:
      UTC SNR  DT   FREQ [~] MESSAGE  (Raspberry Pi OS wsjtx)
      UTC  DT FREQ  SNR  [~] MESSAGE  (WSJT-X 標準)
    戦略:
      1. FREQ を先に特定 (整数 100–4000) — SNR 範囲と重複しない
      2. FREQ より前の整数から SNR を取得 (FREQ 前にあれば)
      3. なければ FREQ 直後の整数を SNR として取得 (標準フォーマット)
      4. メッセージは FREQ (+ SNR があれば) の後ろ、旗文字を除外
    """
    msgs = []
    for line in stdout.splitlines():
        parts = line.strip().split()
        if len(parts) < 4:
            continue
        try:
            # Step 1: FREQ を探す (index 1 以降の最初の整数 100–4000)
            freq_idx = -1
            for i in range(1, len(parts)):
                try:
                    iv = int(parts[i])
                    if 100 <= iv <= 4000:
                        freq_idx = i
                        break
                except ValueError:
                    pass
            if freq_idx < 0:
                continue
            freq = int(parts[freq_idx])

            # Step 2: SNR を探す (FREQ より前の整数 -40–+30)
            snr = None
            for i in range(1, freq_idx):
                try:
                    iv = int(parts[i])
                    if -40 <= iv <= 30:
                        snr = iv
                        break
                except ValueError:
                    pass

            # Step 3: FREQ 直後に SNR がある場合 (標準フォーマット)
            msg_start = freq_idx + 1
            if snr is None and msg_start < len(parts):
                try:
                    iv = int(parts[msg_start])
                    if -40 <= iv <= 30:
                        snr = iv
                        msg_start += 1
                except ValueError:
                    pass

            if snr is None:
                continue

            # Step 4: syncスコア (1桁整数) と旗文字 (~, ?, *) をスキップ
            # jt9 出力: "... FREQ  0 ~ MESSAGE" のように syncスコアが ~ の前に来ることがある
            while msg_start < len(parts):
                tok = parts[msg_start]
                if tok in ("~", "?", "*", "OOO"):
                    msg_start += 1
                elif len(tok) == 1 and tok.isdigit():
                    msg_start += 1  # sync score (0-9)
                else:
                    break
            msg = " ".join(parts[msg_start:])
            # jt9 によっては2デコード結果を ";" でつなげて1行出力するため分割
            for sub in msg.split(";"):
                sub = sub.strip()
                if sub:
                    msgs.append({"dt": 0.0, "freq": freq, "snr": snr, "msg": sub})
        except (ValueError, IndexError):
            continue
    return msgs


def _bandpass_wav(src: str, dst: str, flow: int, fhigh: int) -> bool:
    """WAV にバンドパスフィルタを適用して dst に書き込む。sox → numpy の順で試みる。"""
    # --- 方法1: sox (推奨、Pi に標準インストールされていることが多い) ---
    try:
        r = subprocess.run(
            ["sox", src, dst, "sinc", f"{flow}-{fhigh}"],
            capture_output=True, timeout=10.0
        )
        if r.returncode == 0 and os.path.exists(dst):
            return True
    except Exception:
        pass

    # --- 方法2: numpy FFT ---
    try:
        import numpy as np
        with wave.open(src, "rb") as wf:
            nch  = wf.getnchannels()
            rate = wf.getframerate()
            raw  = wf.readframes(wf.getnframes())
        data = np.frombuffer(raw, dtype=np.int16).astype(np.float32)
        if nch > 1:
            data = data[::nch]
        N    = len(data)
        fft  = np.fft.rfft(data)
        bins = np.fft.rfftfreq(N, d=1.0 / rate)
        fft[(bins < flow) | (bins > fhigh)] = 0
        out  = np.clip(np.fft.irfft(fft, n=N), -32767, 32767).astype(np.int16)
        with wave.open(dst, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(rate)
            wf.writeframes(out.tobytes())
        return True
    except Exception as e:
        print(f"[bandpass] numpy failed: {e}")
        return False


def _ft8_pcm_to_wav(pcm_raw: bytes) -> str:
    """12kHz mono s16 PCM をピーク正規化して一時WAVに書き出し、パスを返す（呼び出し側/worker が削除）。"""
    try:
        import numpy as _np
        _smp = _np.frombuffer(pcm_raw, dtype=_np.int16).astype(_np.float32)
        _peak = float(_np.max(_np.abs(_smp))) if _smp.size else 0.0
        if _peak > 16384.0:
            _smp = _smp * (16384.0 / _peak)
        pcm_write = _np.clip(_smp, -32768, 32767).astype(_np.int16).tobytes()
    except Exception:
        pcm_write = pcm_raw
    fd, wav_path = tempfile.mkstemp(suffix=".wav")
    os.close(fd)
    with wave.open(wav_path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(FT8_SAMPLE_RATE)
        wf.writeframes(pcm_write)
    return wav_path


class _PskReporter:
    """PSKReporter へ受信スポット(デコードした相手局)を IPFIX/UDP で送る(オプトイン)。
    report.pskreporter.info:4739。5分に1回・固定送信元ポート。テンプレートは起動時3回＋毎時。"""
    ENT = 30351
    def __init__(self):
        self.enabled = False; self.call = ""; self.grid = ""; self.software = "WifiRigCTRL"
        self.spots = []; self.lock = threading.Lock()
        self.sock = None; self.seq = 0
        self.rid = int.from_bytes(os.urandom(4), "big")
        self.tmpl_sent = 0; self.last_tmpl = 0.0; self.last_send = 0.0; self.thread = None

    def configure(self, enabled, call, grid):
        with self.lock:
            self.call = (call or "").upper().strip()
            self.grid = (grid or "").upper().strip()
            self.enabled = bool(enabled) and bool(self.call)
        if self.enabled and self.thread is None:
            self.thread = threading.Thread(target=self._loop, daemon=True); self.thread.start()

    def add_spot(self, call, grid, freq_hz, snr, mode, t):
        if not self.enabled or not call: return
        with self.lock:
            if len(self.spots) < 300:
                self.spots.append((call.upper(), (grid or "").upper(), int(freq_hz), int(snr), mode, int(t)))

    def _loop(self):
        while True:
            time.sleep(60)
            try:
                if self.enabled: self._maybe_send()
            except Exception as e:
                print(f"[pskr] loop err {e!r}")

    @staticmethod
    def _vstr(s):
        b = s.encode("utf-8")[:254]; return bytes([len(b)]) + b
    @staticmethod
    def _set(set_id, rec):
        pad = (-len(rec)) % 4; rec = rec + b"\x00" * pad
        return struct.pack(">HH", set_id, 4 + len(rec)) + rec

    def _templates(self):
        def ef(fid, length): return struct.pack(">HHI", fid | 0x8000, length, self.ENT)
        rx = struct.pack(">HH", 0x9992, 3) + ef(2, 0xFFFF) + ef(4, 0xFFFF) + ef(8, 0xFFFF)
        sx = (struct.pack(">HH", 0x9993, 7) + ef(1, 0xFFFF) + ef(5, 4) + ef(6, 1)
              + ef(10, 0xFFFF) + ef(3, 0xFFFF) + ef(11, 1) + struct.pack(">HH", 150, 4))
        return self._set(2, rx + sx)

    def _maybe_send(self):
        now = time.time()
        with self.lock:
            if not self.spots or (now - self.last_send) < 300: return
            spots = self.spots; self.spots = []
            send_tmpl = self.tmpl_sent < 3 or (now - self.last_tmpl > 3600)
            rxset = self._set(0x9992, self._vstr(self.call) + self._vstr(self.grid) + self._vstr(self.software))
            sdata = b""
            for (call, grid, freq, snr, mode, t) in spots:
                sdata += (self._vstr(call) + struct.pack(">I", freq & 0xFFFFFFFF)
                          + struct.pack(">b", max(-128, min(127, snr))) + self._vstr(mode)
                          + self._vstr(grid) + bytes([1]) + struct.pack(">I", t))
            sset = self._set(0x9993, sdata)
            body = (self._templates() if send_tmpl else b"") + rxset + sset
            self.seq += len(spots)
            hdr = struct.pack(">HHIII", 0x000A, 16 + len(body), int(now), self.seq & 0xFFFFFFFF, self.rid)
            pkt = hdr + body
        try:
            if self.sock is None:
                self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); self.sock.bind(("", 0))
            self.sock.sendto(pkt, ("report.pskreporter.info", 4739))
            with self.lock:
                self.last_send = now
                if send_tmpl: self.tmpl_sent += 1; self.last_tmpl = now
            print(f"[pskr] sent {len(spots)} spots ({len(pkt)}B)")
        except Exception as e:
            print(f"[pskr] send err {e!r}")

_pskr = _PskReporter()

def _pskr_extract(msg: str):
    """FT8メッセージから送信局(DE局)コールとグリッドを推定。(call, grid) or (None, None)。"""
    toks = msg.strip().split()
    if not toks: return (None, None)
    def is_grid(s): return len(s) == 4 and s[0:2].isalpha() and s[2:4].isdigit()
    def is_call(s): return 3 <= len(s) <= 12 and any(c.isdigit() for c in s) and any(c.isalpha() for c in s)
    grid = next((t for t in toks if is_grid(t)), None)
    if toks[0] in ("CQ", "QRZ"):
        call = next((t for t in toks[1:] if is_call(t)), None)
        return (call, grid)
    if len(toks) >= 2 and is_call(toks[1]):
        return (toks[1], next((t for t in toks[2:] if is_grid(t)), None))
    return (None, None)


def _ft8_jt9_worker(wav_path: str, period_n: int, utc_sec: int,
                    depth_override: "int | None" = None,
                    emit_display: bool = True, run_qso: bool = True,
                    period_epoch: "float | None" = None):
    """mfsk-decode によるFT8/FT4デコードをバックグラウンドで実行し、ストリーミングブロードキャスト。
    デコードが完了し次第 decode_msg を逐次送信 → Androidが徐々にデコード欄を埋める。
    depth_override: 指定時は --depth をこの値で上書き（2段の早期復号で depth=1 高速化用）。
    emit_display=False: decode_msg/decode_done/ALL.TXT を抑止（2段の早期復号=返信専用）。
    run_qso=False:     QSO ステートマシンを実行しない（2段のフル復号=表示専用。SM二重遷移防止）。"""
    global _ft8_last_decode_info, _mfsk_binary_warning_sent
    _jt9_decode_done.clear()
    all_msgs = []
    try:
        if not os.path.isfile(_MFSK_DECODE_BIN):
            if not _mfsk_binary_warning_sent:
                _mfsk_binary_warning_sent = True
                _ft8_broadcast({"type": "system_msg",
                                "msg": "mfsk-decode ビルド未完了。UPDATE画面で「Update Pi」を実行してください（10〜20分）"})
            _ft8_broadcast({"type": "decode_done", "period": period_n, "utc_sec": utc_sec, "count": 0})
            return
        _mfsk_binary_warning_sent = False
        cmd = [_MFSK_DECODE_BIN]
        if _ft8_is_ft4:
            cmd.append("--ft4")

        # 自局・相手局コールサインをmfsk-decodeに渡してハッシュテーブルを事前構築
        my_call = _qso.get("my_call", "").strip() or _ft8_my_call.strip()
        dx_call = _qso.get("dx_call", "").strip() if _qso.get("active") else ""
        if not dx_call:
            dx_call = _last_compound_dx or next(
                (c for c in sorted(_ft8_known_calls) if "/" in c), "")
        if my_call:
            cmd += ["-c", my_call]
        if dx_call:
            cmd += ["-x", dx_call]
        # セッション中に確認された全コンパウンドコールをハッシュテーブルに追加
        for kc in sorted(_ft8_known_calls):
            if "/" in kc and kc != dx_call and kc != my_call:
                cmd += ["-k", kc]

        # SICラウンド数 (depth 1/2/3 → jt9 -d 相当)。depth_override 指定時はそれを優先（2段の早期=1）
        cmd += ["--depth", str(depth_override if depth_override else _ft8_decode_depth)]

        # フィルター帯域を mfsk-decode に直接渡す (jt9 と異なり WAV 前処理が不要)
        if _ft8_decode_filter:
            centers = [c for c, _ in _ft8_decode_filter]
            rngs    = [r for _, r in _ft8_decode_filter]
            flow    = max(100,  min(centers) - max(rngs) * 2)
            fhigh   = min(3000, max(centers) + max(rngs) * 2)
            cmd += ["--freq-min", str(flow), "--freq-max", str(fhigh)]

        cmd.append(wav_path)
        t1 = time.time()
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        try:
            for line in proc.stdout:
                line = line.strip()
                if not line:
                    continue
                try:
                    m = _json.loads(line)
                    # post-filter: フィルター帯域外を除去
                    if _ft8_decode_filter and not any(
                        abs(m.get("freq", 0) - center) <= rng
                        for center, rng in _ft8_decode_filter
                    ):
                        continue
                    # mfsk-decode が ";" で2メッセージを1行出力することがあるため分割
                    raw_msg = m.get("msg", "")
                    sub_msgs = [s.strip() for s in raw_msg.split(";") if s.strip()]
                    if not sub_msgs:
                        sub_msgs = [raw_msg]
                    for sub in sub_msgs:
                        sub_m = dict(m); sub_m["msg"] = sub
                        # <...> ハッシュをQSOコンテキストで解決
                        resolved = _resolve_unknown_hashes([sub_m])
                        sub_m = resolved[0]
                        # 逐次ブロードキャスト: デコード完了した局から順に送信
                        _snr  = int(round(sub_m.get("snr",  0)))
                        _dt   = round(sub_m.get("dt", 0.0), 2)
                        _freq = int(round(sub_m.get("freq", 0)))
                        _msg  = sub_m.get("msg", "")
                        if emit_display:
                            _ft8_broadcast({
                                "type": "decode_msg",
                                "period": period_n,
                                "utc_sec": utc_sec,
                                "freq": _freq,
                                "snr":  _snr,
                                "dt":   _dt,
                                "msg":  _msg,
                            })
                            # PSKReporter へスポット追加(有効時のみ)。RF = ダイヤル周波数 + 音声オフセット(USB)
                            if _pskr.enabled:
                                _scall, _sgrid = _pskr_extract(_msg)
                                if _scall:
                                    _rf = int(radio_cache.get("freq", 0) or 0) + _freq
                                    _mode = "FT4" if _ft8_is_ft4 else "FT8"
                                    _tsec = int(period_epoch) if period_epoch else int(time.time())
                                    _pskr.add_spot(_scall, _sgrid, _rf, _snr, _mode, _tsec)
                        all_msgs.append(sub_m)
                        # ALL.TXT に追記 (WSJT-X 互換フォーマット)。早期(表示なし)復号では追記しない
                        if emit_display:
                            try:
                                # utc_sec は「分内の秒(0-59)」なので、ここでは必ずピリオド開始の
                                # 実エポック(period_epoch)を使う。未指定時のみ現在時刻でフォールバック。
                                _epoch = period_epoch if period_epoch is not None else time.time()
                                _ts  = datetime.datetime.utcfromtimestamp(_epoch).strftime("%y%m%d_%H%M%S")
                                _mod = "FT4" if _ft8_is_ft4 else "FT8"
                                _all_line = f"{_ts}  Rx {_mod}  {_snr:+4d}  {_dt:+5.1f}  {_freq:4d}  {_msg}\n"
                                with open(_ALL_TXT_PATH, "a", encoding="utf-8") as _f:
                                    _f.write(_all_line)
                            except Exception:
                                pass
                except Exception as e:
                    print(f"[mfsk_decode] parse: {e!r} line={line!r}")
            proc.wait(timeout=5.0)
        except subprocess.TimeoutExpired:
            proc.kill()

        msgs = all_msgs
        elapsed = time.time() - t1
        print(f"[mfsk_decode] took {elapsed:.2f}s period={period_n} utc={utc_sec}s decoded={len(msgs)}")
        _ft8_last_decode_info = {"decoded": len(msgs), "period": period_n}
        if emit_display:
            _ft8_broadcast({
                "type": "decode_done",
                "period": period_n,
                "utc_sec": utc_sec,
                "count": len(msgs),
            })
        # QSO state machine: DX 返信を検出して AUTO TX のメッセージを次ステップへ更新
        # FT8 message format: DESTCALL SRCCALL REPORT (first word = recipient)
        # run_qso=False(2段のフル=表示専用)では実行しない → SM二重遷移を防ぐ
        if run_qso and _qso["active"] and msgs:
            dx = _qso["dx_call"]
            me = _qso["my_call"]
            state = _qso["state"]
            # 自分宛の DX メッセージを全部取り出し、SNR 最強のものを使う
            # mfsk-core はハッシュ化コールサインを <CALL> 形式で返すため <> を除去して比較する
            def _sh(s): return s[1:-1] if s.startswith('<') and s.endswith('>') else s
            dx_msgs = [m for m in msgs
                       if len(m["msg"].split()) >= 2
                       and _sh(m["msg"].upper().split()[0]) == me
                       and _sh(m["msg"].upper().split()[1]) == dx]
            dx_best  = max(dx_msgs, key=lambda m: m.get("snr", -99)) if dx_msgs else None
            dx_reply = dx_best["msg"].upper().split() if dx_best else None

            # QSO 中に受信した DX の SNR を step2 メッセージに反映（改善時のみ更新）
            if dx_best is not None:
                cur_snr = dx_best.get("snr", -99)
                peak    = _qso.get("snr_dx_peak")
                if peak is None or cur_snr > peak:
                    _qso["snr_dx_peak"] = cur_snr
                    snr_str = f"+{cur_snr:02d}" if cur_snr >= 0 else f"{cur_snr:03d}"
                    parts = _qso["step2_msg"].split()
                    if len(parts) >= 3:
                        # CQ発信側はRなし、DX指定呼び出し側はR付き
                        parts[2] = snr_str if _qso.get("cq_sender") else f"R{snr_str}"
                        _qso["step2_msg"] = " ".join(parts)
                        _qso["snr_sent"]  = parts[2]
                        # state 3 はすでに step2 を繰り返し送信中 → AUTO TX も即時更新してUIに通知
                        if state == 3:
                            _auto_tx["msg"] = _qso["step2_msg"]
                            _ft8_broadcast({"type": "qso_state", "state": "snr_update",
                                            "msg": _qso["step2_msg"],
                                            "dx_call": dx, "my_call": me, "tx_mode": _qso["tx_mode"]})
                    # step_snr_msg (Rなし SNR ステップ) も同様に更新
                    snr_parts = _qso.get("step_snr_msg", "").split()
                    if len(snr_parts) >= 3:
                        snr_parts[2] = snr_str
                        _qso["step_snr_msg"] = " ".join(snr_parts)
                        if state == 2:
                            _auto_tx["msg"] = _qso["step_snr_msg"]
                            _ft8_broadcast({"type": "qso_state", "state": "snr_update",
                                            "msg": _qso["step_snr_msg"],
                                            "dx_call": dx, "my_call": me, "tx_mode": _qso["tx_mode"]})

            if state == 1 and dx_reply:
                # step1 送信後 → DX の SNR レポート受信でのみ次へ進む
                snr = dx_reply[2] if len(dx_reply) >= 3 else ""
                snr_is_report = snr.lstrip("+-").isdigit()
                if snr_is_report:
                    _qso["snr_rcvd"] = snr
                    # 呼びかけ側: GRID → R-SNR と交互に送信（step_snr_msg はスキップ）
                    # step_snr_msg は initital_state=1 で明示的に開始した場合のみ使用
                    nxt = _qso["step2_msg"] if _qso["step2_msg"] else _qso["step3_msg"]
                    new_state = 3 if _qso["step2_msg"] else 5
                    _qso["next_msg"] = nxt
                    _qso["state"] = new_state
                    _auto_tx["msg"] = nxt
                    _ft8_broadcast({"type": "qso_state", "state": "got_report",
                                    "msg": nxt, "snr": snr,
                                    "dx_call": dx, "my_call": me, "tx_mode": _qso["tx_mode"]})
                elif snr in ("RR73", "73"):
                    # DXがRR73/73を先送り（step2をスキップ）→ 73で即応答
                    step4 = _qso.get("step4_msg", "")
                    nxt = step4 if step4 else f"{dx} {me} 73"
                    _qso["state"] = 6
                    _qso["next_msg"] = nxt
                    _auto_tx["msg"] = nxt
                    _ft8_broadcast({"type": "qso_state", "state": "sending_73", "msg": nxt,
                                    "dx_call": dx, "my_call": me,
                                    "snr_rcvd": _qso.get("snr_rcvd", ""),
                                    "snr_sent": _qso.get("snr_sent", "")})
                # else: グリッド等は無視 → step1 を再送し続ける
            elif state == 2 and dx_reply:
                # step_snr_msg(Rなし SNR)送信後 → DX の応答を処理
                word3 = dx_reply[2] if len(dx_reply) >= 3 else ""
                if word3 in ("RR73", "73"):
                    step4 = _qso.get("step4_msg", "")
                    nxt = step4 if step4 else f"{dx} {me} 73"
                    _qso["state"] = 6
                    _qso["next_msg"] = nxt
                    _auto_tx["msg"] = nxt
                    _ft8_broadcast({"type": "qso_state", "state": "sending_73", "msg": nxt,
                                    "dx_call": dx, "my_call": me,
                                    "snr_rcvd": _qso.get("snr_rcvd", ""),
                                    "snr_sent": _qso.get("snr_sent", "")})
                elif len(word3) >= 2 and word3[0] == "R" and word3[1:].lstrip("+-").isdigit():
                    # R-SNR 受信 → RR73へ進む（Rなし SNR に対してDXがR付き返信 = レポート交換成立）
                    nxt = _qso["step3_msg"]
                    _qso["state"] = 5
                    _qso["next_msg"] = nxt
                    _auto_tx["msg"] = nxt
                    _ft8_broadcast({"type": "qso_state", "state": "got_report",
                                    "msg": nxt, "snr": word3,
                                    "dx_call": dx, "my_call": me, "tx_mode": _qso["tx_mode"]})
                # else: 無視 → step_snr_msg を再送し続ける
            elif state == 3 and dx_reply:
                # step2 送信後の応答を処理
                word3 = dx_reply[2] if len(dx_reply) >= 3 else ""
                if word3 in ("RR73", "73"):
                    # DXがRR73/73送信 → 73で応答（CQ側・DX指定側共通）
                    step4 = _qso.get("step4_msg", "")
                    nxt = step4 if step4 else f"{dx} {me} 73"
                    _qso["next_msg"] = nxt
                    _qso["state"] = 6
                    _auto_tx["msg"] = nxt
                    _ft8_broadcast({"type": "qso_state", "state": "sending_73", "msg": nxt,
                                    "dx_call": dx, "my_call": me,
                                    "snr_rcvd": _qso["snr_rcvd"],
                                    "snr_sent": _qso["snr_sent"]})
                elif (len(word3) >= 2 and word3[0] == "R"
                      and word3[1:].lstrip("+-").isdigit()):
                    # DXからR-SNRが返ってきた → RR73を送信（CQ側・DX指定側共通）
                    nxt = _qso["step3_msg"]
                    _qso["state"] = 5
                    _qso["next_msg"] = nxt
                    _auto_tx["msg"] = nxt
                    _ft8_broadcast({"type": "qso_state", "state": "retry_rr73", "msg": nxt,
                                    "dx_call": dx, "my_call": me,
                                    "snr_rcvd": _qso["snr_rcvd"],
                                    "snr_sent": _qso["snr_sent"]})
                # else: SNR再送・グリッド等は無視 → step2 を再送し続ける
            elif state == 5 and dx_reply:
                # step3(RR73) 送信後 → 73/RR73 で即QSO完了（こちらから73は不要）
                word3 = dx_reply[2] if len(dx_reply) >= 3 else ""
                if word3 in ("73", "RR73"):
                    _qso["active"] = False
                    _qso["state"] = 6
                    _auto_tx["active"] = False
                    _ft8_broadcast({"type": "qso_done", "dx_call": dx, "my_call": me,
                                    "snr_rcvd": _qso["snr_rcvd"],
                                    "snr_sent": _qso["snr_sent"]})
                else:
                    _auto_tx["msg"] = _qso["step3_msg"]  # RR73 再送
                    _ft8_broadcast({"type": "qso_state", "state": "retry_rr73",
                                    "msg": _qso["step3_msg"],
                                    "dx_call": dx, "my_call": me, "tx_mode": _qso["tx_mode"]})
            elif state == 6:
                # step4(73) 送信後 → 次のデコード周期で即QSO完了
                _qso["active"] = False
                _auto_tx["active"] = False
                _ft8_broadcast({"type": "qso_done", "dx_call": dx, "my_call": me,
                                "snr_rcvd": _qso.get("snr_rcvd", ""),
                                "snr_sent": _qso.get("snr_sent", "")})
        # CQ AUTO: QSO未開始のとき、自分宛の返信を検出したら自動QSO開始
        if _cq_auto.get("active") and not _qso.get("active") and msgs:
            me_cq = _cq_auto["my_call"].upper()
            cq_replies = [m for m in msgs
                          if len(m["msg"].split()) >= 2
                          and m["msg"].upper().split()[0] == me_cq]
            if cq_replies:
                # 複数局が同時に呼んできたら、送信開始が一番早い局(dt最小)に応答する。
                # 同点は最初に出てきた順で安定。
                reply  = min(cq_replies, key=lambda m: m.get("dt", 0.0))
                parts  = reply["msg"].upper().split()
                dx_call = parts[1]
                snr    = reply.get("snr", 0)
                snr_str = f"+{snr:02d}" if snr >= 0 else f"{snr:03d}"
                step2  = f"{dx_call} {me_cq} {snr_str}"   # CQ発信側: Rなし
                step3  = f"{dx_call} {me_cq} RR73"
                _qso["active"]     = True
                _qso["dx_call"]    = dx_call
                _qso["my_call"]    = me_cq
                _qso["state"]      = 3   # step2送信待ち
                _qso["tx_mode"]    = _cq_auto["mode"]
                _qso["audio_freq"] = _cq_auto["audio_freq"]
                _qso["step1_msg"]  = ""
                _qso["step2_msg"]  = step2
                _qso["step3_msg"]  = step3
                _qso["step4_msg"]  = ""   # CQ発信側: DXの73受信後は73送らずCQ再開
                _qso["next_msg"]   = step2
                _qso["snr_rcvd"]   = str(snr)
                _qso["snr_sent"]   = snr_str   # CQ発信側: Rなし
                _qso["snr_dx_peak"]= snr
                _qso["cq_sender"]  = True
                _auto_tx["active"]    = True
                _auto_tx["msg"]       = step2
                _auto_tx["mode"]      = _cq_auto["mode"]
                _auto_tx["audio_freq"]= _cq_auto["audio_freq"]
                print(f"[cq_auto] auto QSO: {dx_call} snr={snr} dt={reply.get('dt',0.0)} (earliest of {len(cq_replies)})")
                _ft8_broadcast({"type": "qso_state", "state": "got_report",
                                "dx_call": dx_call, "msg": step2,
                                "tx_mode": _cq_auto["mode"]})
    except Exception as e:
        print(f"[mfsk_decode] worker error: {e}")
    finally:
        _jt9_decode_done.set()
        try: os.unlink(wav_path)
        except Exception: pass


def _ft8_auto_tx_worker(msg: str, audio_freq: int, period_utc: int = -1):
    """AutoTX: FT8メッセージをPCM生成→aplayで送出する。"""
    global _ft8_tx_active, _ft8_tx_aplay_proc
    if _ft8_tx_active:
        return
    # msg はスレッド起動時点（ピリオド境界）の _auto_tx["msg"] が渡される。
    # デコードとTXワーカーは同時に開始するため、jt9完了を待っても
    # 更新されたメッセージは得られない。即座にTXを開始する。
    if not _auto_tx.get("active") or not msg:
        return
    _ft8_tx_active = True
    # period_utc が渡されていればそれを使う（time.time()の再計算でズレない）
    _tx_p = 7.5 if _ft8_is_ft4 else 15.0
    now_f = time.time()
    tx_utc = period_utc if period_utc >= 0 else int(int(now_f / _tx_p) * _tx_p) % 60
    print(f"[auto_tx] TX start: utc={tx_utc}s mode={_auto_tx['mode']} ft4={_ft8_is_ft4} msg={msg!r}")
    _ft8_broadcast({"type": "tx_pending", "msg": msg,
                    "wait_sec": 0, "utc_at_tx": tx_utc})
    mute_sec = 7.0 if _ft8_is_ft4 else 14.0  # FT4=~5s audio, FT8=~12.6s audio
    _mgr_sub.mute(mute_sec)
    try:
        subprocess.run(["pkill", "-9", "aplay"], capture_output=True)
        time.sleep(0.1)
        rigctl_cmd("T 1")
        time.sleep(0.3)
        pcm_data = _ft8_get_pcm(msg, audio_freq, 48000, is_ft4=_ft8_is_ft4)
        pcm_sec = len(pcm_data) / 2 / 48000
        print(f"[auto_tx] PCM samples={len(pcm_data)//2} duration={pcm_sec:.2f}s ft4={_ft8_is_ft4}")
        proc = subprocess.Popen(
            ["aplay", "-D", _alsa_playback_dev, "-f", "S16_LE", "-r", "48000", "-c", "1"],
            stdin=subprocess.PIPE, stderr=subprocess.PIPE
        )
        _ft8_tx_aplay_proc = proc
        try:
            proc.stdin.write(pcm_data)
            proc.stdin.close()
        except BrokenPipeError:
            print("[auto_tx] stdin broken — aplay exited early (TX may be partial)")
        _t0 = time.time()
        proc.wait(timeout=20)
        print(f"[auto_tx] aplay finished in {time.time()-_t0:.2f}s")
        _ft8_broadcast({"type": "auto_tx_sent", "msg": msg, "utc_at_tx": tx_utc})
        # QSO state 6: 73(step4)を実際に送信した場合のみ完了とする
        # TX開始後にデコードでstate=6になったとき73はまだ未送信なので次のTXで送る
        if _qso.get("active") and _qso.get("state") == 6:
            dx_done = _qso["dx_call"]
            me_done = _qso["my_call"]
            snr_r   = _qso.get("snr_rcvd", "")
            snr_s   = _qso.get("snr_sent", "")
            step4   = _qso.get("step4_msg", "")
            done_msg = (step4 if step4 else f"{dx_done} {me_done} 73").upper().strip()
            if msg.upper().strip() == done_msg:
                _qso["active"] = False
                _auto_tx["active"] = False
                _ft8_broadcast({"type": "qso_done",
                                "dx_call": dx_done, "my_call": me_done,
                                "snr_rcvd": snr_r, "snr_sent": snr_s})
            # else: 73以外を送信済み → _auto_tx["msg"]の73を次のTXピリオドで送る
        # Safety: QSOが非アクティブになっていたらauto_txも停止
        # CQ AUTOモード（QSO待機中）は除外 — CQ AUTO は継続して送信し続ける
        if not _qso.get("active") and not _cq_auto.get("active"):
            _auto_tx["active"] = False
    except Exception as e:
        print(f"[auto_tx] error: {e}")
        _ft8_broadcast({"type": "auto_tx_error", "error": str(e)})
        _auto_tx["active"] = False  # エラー後にTXループが続かないよう停止
    finally:
        rigctl_cmd("T 0")
        _ft8_tx_active = False
        _ft8_tx_aplay_proc = None


def _ft8_decode_loop():
    global _ft8_decode_running
    print("[ft8_decode] started")
    while _ft8_decode_running:
        # 次のFT8/FT4ピリオド境界まで待機
        # 注: 録音直後は now がピリオド境界に非常に近い（例: 30.004s）ため
        # (int(now/P)+1)*P だと次の次に飛ばしてしまう。
        # 現在ピリオドの開始から 0.5s 以内なら そのピリオドをそのまま処理する。
        period_s = 7.5 if _ft8_is_ft4 else FT8_PERIOD_S
        now = time.time()
        current_start = int(now / period_s) * period_s
        elapsed = now - current_start
        if elapsed < 0.5:
            next_start = current_start   # このピリオドをすぐ処理
        else:
            next_start = current_start + period_s
        wait = next_start - now
        if wait > 0.05:
            time.sleep(wait - 0.05)
        while time.time() < next_start:
            time.sleep(0.002)

        if not _ft8_decode_running:
            break

        period_s = 7.5 if _ft8_is_ft4 else FT8_PERIOD_S
        period_start = time.time()
        utc_sec  = int(period_start) % 60
        if _ft8_is_ft4:
            period_n = int(period_start / 7.5) % 8
        else:
            period_n = (utc_sec // 15) % 4

        # ピリオド開始を即座に通知（ウォーターフォールの横線タイミング用）
        _ft8_broadcast({"type": "period_start", "period": period_n, "utc_sec": utc_sec})

        # QSO 送信は AUTO TX に委譲（_auto_tx["msg"] を更新して AUTO TX が送信）

        # CQ AUTOモード: QSO完了後/未開始時にCQ送信を再開
        if _cq_auto.get("active") and not _qso.get("active") and not _auto_tx.get("active"):
            _auto_tx["active"]    = True
            _auto_tx["msg"]       = _cq_auto["msg"]
            _auto_tx["mode"]      = _cq_auto["mode"]
            _auto_tx["audio_freq"]= _cq_auto["audio_freq"]
            _ft8_broadcast({"type": "cq_auto_restart", "msg": _cq_auto["msg"]})

        # AutoTX: このピリオドがTX担当なら送信して次ピリオドへ
        if _auto_tx["active"] and not _ft8_tx_active and _auto_tx["msg"]:
            with _ft8_rx_clients_lock:
                has_clients = bool(_ft8_rx_clients)
            if not has_clients:
                print("[ft8_decode] no SSE clients — skipping TX this period")
                _wait = period_start + period_s - time.time()
                if _wait > 0:
                    time.sleep(_wait)
                continue
            is_even = period_n % 2 == 0
            should_tx = (is_even and _auto_tx["mode"] == "even") or                         (not is_even and _auto_tx["mode"] == "odd")
            if should_tx:
                # 直前のRXピリオドのデコード+QSO遷移が _auto_tx["msg"] を次ステップへ更新する
                # のを短時間待ってから送信する。2段デコードOFF(既定)では復号がピリオド末
                # (=このTX境界)に走るため、待たないと返信を受けても応答が1ターン遅れる。
                # FT8/FT4は数秒の送信遅れ(DT)を許容するので、復号完了まで最大2s待つ。
                # 2段ON時は早期復号で境界前に更新済みのため待たない(不要な遅延回避)。
                if _qso.get("active") and not _ft8_two_stage:
                    _jt9_decode_done.wait(timeout=(1.0 if _ft8_is_ft4 else 2.0))
                threading.Thread(
                    target=_ft8_auto_tx_worker,
                    args=(_auto_tx["msg"], _auto_tx["audio_freq"], utc_sec),
                    daemon=True
                ).start()
                # 次のピリオド境界まで待機（continueするとelapsed<0.5でスピンループになりSSEキューが溢れる）
                _wait = period_start + period_s - time.time()
                if _wait > 0:
                    time.sleep(_wait)
                continue

        if _ft8_tx_active:
            print(f"[ft8_decode] skip period={period_n} (TX active)")
            # 次のピリオド境界まで待機（スピンループ防止）
            _wait = period_start + period_s - time.time()
            if _wait > 0:
                time.sleep(_wait)
            continue

        # _mgr_sub を購読してFT8/FT4ピリオド分の12kHz PCMを収集
        period_bytes = int(FT8_SAMPLE_RATE * period_s) * 2
        # 2段: 周期末より手前(信号本体ぶん)で早期復号を起動するためのバイト数
        _early_tail = _FT4_EARLY_TAIL_S if _ft8_is_ft4 else _FT8_EARLY_TAIL_S
        _early_bytes = int(FT8_SAMPLE_RATE * max(0.0, period_s - _early_tail)) * 2
        _early_launched = False
        _mgr_sub.ensure("12000")
        sid, q = _mgr_sub.subscribe(maxsize=512)
        pcm = bytearray()
        deadline = period_start + period_s
        try:
            while len(pcm) < period_bytes and _ft8_decode_running:
                rem = deadline - time.time()
                if rem <= 0:
                    break
                try:
                    chunk = q.get(timeout=min(0.5, rem + 0.1))
                    pcm.extend(chunk)
                    # 2段デコード: 早期(返信用)ぶんが溜まったら depth1・表示なしで先行起動
                    if _ft8_two_stage and not _early_launched and len(pcm) >= _early_bytes:
                        _early_launched = True
                        try:
                            _ewav = _ft8_pcm_to_wav(bytes(pcm[:_early_bytes]))
                            threading.Thread(
                                target=_ft8_jt9_worker,
                                args=(_ewav, period_n, utc_sec, 1, False, True),
                                kwargs={"period_epoch": period_start},
                                daemon=True,
                            ).start()
                        except Exception as _ee:
                            print(f"[ft8_decode] early decode launch error: {_ee}")
                except _queue.Empty:
                    if time.time() >= deadline:
                        break
                    # arecord が USB リセット等で死んだら再起動して録音継続
                    if _mgr_sub.proc and _mgr_sub.proc.poll() is not None:
                        print(f"[ft8_decode] arecord died — restarting capture")
                        _mgr_sub.unsubscribe(sid)
                        _mgr_sub.ensure("12000")
                        sid, q = _mgr_sub.subscribe(maxsize=512)
        finally:
            _mgr_sub.unsubscribe(sid)

        if not _ft8_decode_running or len(pcm) < period_bytes // 4:
            continue

        # WAVに書いてmfsk-decodeをバックグラウンドスレッドで起動（次ピリオドの録音をブロックしない）
        fd, wav_path = -1, ""
        try:
            fd, wav_path = tempfile.mkstemp(suffix=".wav")
            os.close(fd); fd = -1

            pcm_raw = bytes(pcm[:period_bytes])
            try:
                import numpy as _np
                _smp = _np.frombuffer(pcm_raw, dtype=_np.int16).astype(_np.float32)
                _peak = float(_np.max(_np.abs(_smp)))
                _rms  = float(_np.sqrt(_np.mean(_smp ** 2)))
                print(f"[ft8_decode] period={period_n} utc={utc_sec}s pcm={len(pcm)//2}/{period_bytes//2}smp peak={_peak:.0f} rms={_rms:.1f}")
                if _peak > 16384.0:
                    _smp = _smp * (16384.0 / _peak)
                pcm_write = _np.clip(_smp, -32768, 32767).astype(_np.int16).tobytes()
            except Exception:
                pcm_write = pcm_raw

            with wave.open(wav_path, "wb") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(FT8_SAMPLE_RATE)
                wf.writeframes(pcm_write)

            _wav_for_thread = wav_path
            wav_path = ""  # worker がファイル削除担当
            # 2段で早期復号が起動済みなら、フルは表示専用(QSO SMなし=二重遷移防止)。
            # 2段OFF or 早期が未起動(縁ケース)ならフルで QSO SM も実行。
            _full_run_qso = (not _ft8_two_stage) or (not _early_launched)
            # QSO遷移を行うフル復号を起動する前にイベントをクリアしておく。こうすることで
            # 次のTX境界の待機(上記)が、このRX復号+QSO更新の完了を確実に待てる(競合回避)。
            if _full_run_qso:
                _jt9_decode_done.clear()
            threading.Thread(
                target=_ft8_jt9_worker,
                args=(_wav_for_thread, period_n, utc_sec, None, True, _full_run_qso),
                kwargs={"period_epoch": period_start},
                daemon=True
            ).start()
        except Exception as e:
            print(f"[ft8_decode] wav write error: {e}")
        finally:
            if fd >= 0:
                try: os.close(fd)
                except Exception: pass
            if wav_path:
                try: os.unlink(wav_path)
                except Exception: pass

    print("[ft8_decode] stopped")

rig_lock = threading.Lock()
vfo_toggle_lock = threading.Lock()  # /radio/vfo_toggle連打対策の排他ロック(rig_lockとは別)
radio_cache = {
    "freq": 0,
    "mode": "",
    "width": 0,
    "signal": 0.0,
    "tx": False,
    "power": 0.0,
    "sql": 0.0,
    "bk_in": 0,
    "tuner": 0,
    "rig_wpm": 0,
    "rf_out": 0.0,
    "alc": 0.0,
}

# --- バンドスコープ(CATスイープ)用 ---
_scope_lock = threading.Lock()   # 同時スイープの排他(連打・多重呼び出し対策)
_scope_active = False            # スイープ中はpoll_signalのSTRENGTH掃引をスキップさせる

current_model = None
current_cat = None
current_baud = None
current_ptt = ""
current_ptt_type = "RIG"

# ★ rigctld の自動復旧(ptt・poll_rig・audio_tx の4箇所)はすべて
#   "current_model and current_cat" を条件にしている。これらは /radio/open でしか
#   設定されないため、fastapi を再起動すると失われ、rigctld が死んでも誰も再起動
#   できない状態に陥る。症状は「PTT が 500 で電波が出ない」「周波数・モードが変わ
#   らない」「S メーターが 0」で、アプリから手動で再接続するまで永久に直らない。
#   選択内容をファイルに残し、起動時に読み戻して復旧経路を生かしておく。
#   ※ ここでは rigctld を自動起動はしない。api.py は :8000 と :50000 の2プロセスで
#     動いており、両方が起動しようとすると互いの rigctld を kill し合うため。
_RIG_STATE_FILE = _FASTAPI_DIR / "rig_open.json"


def _save_rig_selection():
    try:
        _RIG_STATE_FILE.write_text(_json.dumps({
            "model": current_model, "cat": current_cat, "baud": current_baud,
            "ptt": current_ptt, "ptt_type": current_ptt_type,
        }))
    except Exception as e:
        print(f"[rig_state] save failed: {e}", flush=True)


def _load_rig_selection():
    global current_model, current_cat, current_baud, current_ptt, current_ptt_type
    try:
        if not _RIG_STATE_FILE.exists():
            return
        d = _json.loads(_RIG_STATE_FILE.read_text())
        if not d.get("model") or not d.get("cat"):
            return
        current_model    = int(d["model"])
        current_cat      = d["cat"]
        current_baud     = int(d.get("baud") or 38400)
        current_ptt      = d.get("ptt") or ""
        current_ptt_type = d.get("ptt_type") or "RIG"
        print(f"[rig_state] restored model={current_model} cat={current_cat} "
              f"baud={current_baud}", flush=True)
    except Exception as e:
        print(f"[rig_state] load failed: {e}", flush=True)


_load_rig_selection()

# ★ 音声デバイス選択(アプリの Audio (SPK/TX))も2プロセス間で共有する必要がある。
#   POST /radio/audio_device は :8000 のグローバル変数しか書き換えないため、音声
#   ストリームを配信する :50000 のプロセスには届かず、受信音声だけアプリの選択が
#   無視されて .env の既定デバイスが使われ続けていた。ファイル経由で共有する。
_ALSA_DEV_FILE = _FASTAPI_DIR / "alsa_dev.json"
_alsa_dev_mtime = 0.0


def _save_alsa_devices():
    try:
        _ALSA_DEV_FILE.write_text(_json.dumps({
            "capture": _alsa_capture_dev, "playback": _alsa_playback_dev,
        }))
    except Exception as e:
        print(f"[alsa_dev] save failed: {e}", flush=True)


def _load_alsa_devices():
    """Pick up a selection made by the other process. Cheap: only re-reads on mtime change."""
    global _alsa_capture_dev, _alsa_playback_dev, _alsa_dev_mtime
    try:
        st = _ALSA_DEV_FILE.stat()
    except Exception:
        return
    if st.st_mtime == _alsa_dev_mtime:
        return
    try:
        d = _json.loads(_ALSA_DEV_FILE.read_text())
        cap = (d.get("capture") or "").strip()
        pb  = (d.get("playback") or "").strip()
        if cap: _alsa_capture_dev = cap
        if pb:  _alsa_playback_dev = pb
        _alsa_dev_mtime = st.st_mtime
        print(f"[alsa_dev] loaded capture={_alsa_capture_dev} playback={_alsa_playback_dev}",
              flush=True)
    except Exception as e:
        print(f"[alsa_dev] load failed: {e}", flush=True)


_load_alsa_devices()

poll_started = False
poll_enabled = True
tx_in_progress = False
last_user_freq_change = 0
last_user_mode_change = 0
last_heartbeat = time.time()
last_ptt_state = 0
last_rig_ok = 0.0  # poll_rigがリグから正常応答を得た最終時刻(/radio/statusのrig_ok判定用)
# ★ /radio/open(接続操作)でrigctldを再起動している間は、リグに問い合わせできず rig_ok が
#   false になり、M5/アプリが接続直後に⚠(通信断)を一時表示していた。接続操作の直後は
#   リグから最初の正常応答が得られるまで(最長 _RIG_OPEN_GRACE_SEC 秒)rig_ok を true とみなす。
#   poll_rigのタイムアウト連発による自動再起動(=本当の通信断)はこの猶予の対象外。
_RIG_OPEN_GRACE_SEC = 20.0
_rig_open_started = 0.0  # 直近の /radio/open 開始時刻

rigctld_process = None
_rigctld_restarting = False
_timeout_streak = 0  # poll_rig タイムアウト連続回数（グローバル化してリスタート時にリセット）
_rigctld_restart_lock = threading.Lock()

# ---------------------------------------------------------------------------
# UDP ブロードキャストによるデバイス発見 (ポート 5001)
# Android アプリの「スキャン」ボタンからの検索要求に応答する
# ---------------------------------------------------------------------------
_UDP_DISCOVERY_PORT = 5001

def _udp_discovery_server():
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('', _UDP_DISCOVERY_PORT))
        hostname = socket.gethostname()
        api_port   = int(os.environ.get("API_PORT",   8210))
        audio_port = int(os.environ.get("AUDIO_PORT", 8211))
        resp = f"WIFI_RIG_CTRL_HERE:{hostname}:{api_port}:{audio_port}".encode()
        print(f"[discovery] UDP listening on port {_UDP_DISCOVERY_PORT}", flush=True)
        while True:
            try:
                data, addr = sock.recvfrom(256)
                if data.strip() == b"WIFI_RIG_CTRL_DISCOVER":
                    sock.sendto(resp, addr)
            except Exception:
                pass
    except Exception as e:
        print(f"[discovery] error: {e}", flush=True)

threading.Thread(target=_udp_discovery_server, daemon=True).start()

# ---- VFO A/B or MAIN/SUB 判定(機種選択・接続のたびにrigctld再起動後に自動検出) ----
rig_vfo_mode = None  # "mainsub" | "ab" | None(未検出)

# ---- 機種固有のモード一覧(dump_capsの"Mode list:"から検出。C4FM/DSTAR等はここに含まれる) ----
current_mode_list = None  # 検出できるまではNone → /radio/modes等は静的な汎用リストにフォールバック
_FALLBACK_MODE_LIST = ["LSB", "USB", "CW", "CWR", "AM", "FM", "DIGL", "DIGU", "PKTLSB", "PKTUSB", "PKTFM"]

# Hamlibが理論値として報告するが実際のアマチュア無線機では使用できないモード。
# /radio/caps の mode list から除外してアプリのモード選択を整理する。
_HAMLIB_NOISE_MODES = {
    "ECSSUSB", "ECSSLSB",          # ECSS (Exalted Carrier SS) — 実機非対応
    "FAX",                           # HF FAX — アマチュア機では通常使用しない
    "SAM", "SAL", "SAH",             # Synchronous AM variants — 実機非対応
    "DSB",                           # Double Sideband — 実機非対応
    "AM-D", "AMN", "AMS",            # AM variants — 実機非対応
    "P25", "DPMR", "NXDN-VN", "NXDN-N", "DCR",  # 業務用デジタル規格 — アマチュア機非対応
    "PSK", "PSKR",                   # PSK31等はPKTUSB/PKTLSBで運用するため除外
}


_last_tx_debug: dict = {"status": "none", "aplay_rc": None, "aplay_err": "", "chunks": 0, "dev": ""}

aprs_running = False
aprs_seq = 0  # /aprs_start・/aprs_stop のたびに増分。バックグラウンドのCAT設定ワーカーが
              # 古い(=すでに上書きされた)要求で無線機を再度ONに戻してしまうのを防ぐ。
_rig_tx_latch_until = 0.0  # FTX-1内蔵モデムのAUTO BEACON送信(1秒未満で終わる)をM5側の
                            # ポーリングが確実に拾えるよう、検知後しばらくTX表示を保持する
aprs_thread = None
aprs_last_heartbeat = 0
aprs_freq = None
aprs_interval = None
normal_freq = None
aprs_use_gps = True
aprs_manual_lat = 0.0
aprs_manual_lon = 0.0
aprs_cfg = None
_last_rig_aprs_key: tuple | None = None  # (freq, baud, modem_sel) — 前回適用済みの値

# ---- APRS受信(ビーコン受信表示) ----
# ★ 受信はTX方式(DireWolf/FTX-1内蔵モデム)とは無関係に、常にPiのUSBオーディオを
#   direwolfでデコードして拾う。DireWolf-TX中はTX用direwolfがそのまま受信も兼ねる。
#   FTX-1-TX中/APRS停止中は、PTT設定なしの受信専用direwolfを裏で起動しておく。
aprs_rx_running = False
aprs_rx_thread = None
aprs_heard_lock = threading.Lock()
aprs_heard = []  # [{call, path, lat, lon, symbol, comment, heard_at}, ...] 新しい順
_aprs_direwolf_conf_kind = None  # (kind, baud) kind="tx"|"rx" — 直近に書いたdirewolf.confの種類

# ---- APRS受信通知(無線機のような「ビーコン受信」ポップアップ用) ----
aprs_notify_suppress_sec = 600  # 同一局の通知を再度出すまでの最短間隔。/aprs_configで更新される
_aprs_notify_last = {}  # call -> 直近に通知した時刻(epoch)
aprs_notify_queue = []          # M5用通知キュー(/aprs_notifyで払い出して消費)
aprs_notify_queue_android = []  # Android用通知キュー(/aprs_notify_androidで払い出して消費)

tx_started = False
tx_done = False
tx_watch_thread = None
tx_watch_running = False

_ft8_tx_active = False
_rtty_tx_active = False  # RTTY TX中はaudio_tx(SPK音声)のaplay再起動を抑止し、再生デバイスを明け渡す
_ft8_tx_aplay_proc: "subprocess.Popen | None" = None

latest_gps = {"lat": 0.0, "lon": 0.0}

# ─── CW bridge subprocess 管理 ───
_cw_bridge_proc = None
_cw_bridge_lock = threading.Lock()
_cw_bridge_port = ""

# ─── ファイル原子書き込みヘルパー (電源即切り対策) ───
def _atomic_write(path: str, content: str):
    """temp ファイルへ書き込み → fsync → rename で原子的にファイルを更新する。
    電源突然遮断時のファイル破損を防ぐ。"""
    import tempfile
    dir_path = os.path.dirname(os.path.abspath(path))
    fd, tmp_path = tempfile.mkstemp(dir=dir_path, suffix=".tmp")
    try:
        with os.fdopen(fd, 'w') as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
    except Exception:
        try:
            os.unlink(tmp_path)
        except Exception:
            pass
        raise

# ─── ffmpeg サブスクライバーパターン ───
# メイン(SPK)とFT8が独立したキューを持ち、同一プロセスの出力をファンアウトする。
# 異なるレート/フィルターは別 _FfmpegMgr インスタンスで管理する。

class _FfmpegMgr:
    """1つの ffmpeg プロセスを管理し、複数サブスクライバーへブロードキャストする。
    購読者がゼロになると idle_stop_sec 秒後に ffmpeg を停止し ALSA を解放する。"""
    def __init__(self, af: str = None, kill_direwolf: bool = False, idle_stop_sec: int = 5,
                 low_latency: bool = False, use_arecord: bool = False):
        self._af = af
        self._kill_direwolf = kill_direwolf
        self._low_latency = low_latency
        self._use_arecord = use_arecord
        self.proc = None
        self._rate = None
        self._device = None
        self._lock = threading.Lock()
        self._subs_lock = threading.Lock()
        self._subs: dict = {}
        self._idle_stop_sec = idle_stop_sec
        self._idle_timer = None
        self._mute_until = 0.0
        self.capture_dev_override = ""  # "" = use global _alsa_capture_dev
        # ffmpeg/arecord の stderr 末尾を保持する。専用スレッドで常に読み続けるので、
        # ★ stderr パイプ(64KB)が ALSA xrun 警告などで満杯になり、ffmpeg が書き込みで
        #   ブロックして「生きているが音声を一切出さない」状態になる事故も防ぐ。
        from collections import deque
        self.last_stderr = deque(maxlen=30)

    def subscribe(self, maxsize: int = 32):
        q = _queue.Queue(maxsize=maxsize)
        sid = id(q)
        with self._subs_lock:
            if self._idle_timer:
                self._idle_timer.cancel()
                self._idle_timer = None
            self._subs[sid] = q
        return sid, q

    def unsubscribe(self, sid):
        with self._subs_lock:
            self._subs.pop(sid, None)
            if not self._subs and self._idle_stop_sec > 0:
                t = threading.Timer(self._idle_stop_sec, self._idle_stop)
                t.daemon = True
                self._idle_timer = t
                t.start()

    def _idle_stop(self):
        with self._subs_lock:
            if self._subs:
                return
            self._idle_timer = None
        self.stop()

    def mute(self, sec: float):
        self._mute_until = time.time() + sec

    def stop(self):
        with self._lock:
            p = self.proc
            if p and p.poll() is None:
                try:
                    os.killpg(os.getpgid(p.pid), signal.SIGTERM)
                    try:
                        p.wait(timeout=0.5)
                    except subprocess.TimeoutExpired:
                        os.killpg(os.getpgid(p.pid), signal.SIGKILL)
                        p.wait(timeout=0.5)
                except Exception:
                    pass
            self.proc = None
            self._rate = None
            self._device = None

    def _active_capture_dev(self):
        return self.capture_dev_override if self.capture_dev_override else _alsa_capture_dev

    def ensure(self, rate: str):
        # Pick up a device selection made in the other api.py process (see _load_alsa_devices).
        _load_alsa_devices()
        with self._lock:
            dev = self._active_capture_dev()
            if (self.proc and self.proc.poll() is None
                    and self._rate == rate
                    and self._device == dev):
                return self.proc
            return self._start(rate)

    def _start(self, rate: str):
        dev = self._active_capture_dev()
        self.last_stderr.clear()
        old = self.proc
        if old and old.poll() is None:
            try:
                os.killpg(os.getpgid(old.pid), signal.SIGTERM)
                try:
                    old.wait(timeout=0.5)
                except subprocess.TimeoutExpired:
                    os.killpg(os.getpgid(old.pid), signal.SIGKILL)
                    old.wait(timeout=0.5)
            except Exception:
                pass
        if self._kill_direwolf:
            subprocess.run(["pkill", "-9", "direwolf"], capture_output=True)
            time.sleep(0.05)
        if self._use_arecord:
            # arecord | sox パイプライン
            # ffmpegより起動が速い (Pi Zero: ~0.2s vs ~1s)
            # soxでvolume=8.0相当の音量増幅を維持
            # 要: sudo apt-get install sox
            import re as _re
            if "'" in dev:
                raise ValueError(f"Invalid ALSA device name (contains single quote): {dev!r}")
            m = _re.search(r'volume=(\d+(?:\.\d+)?)', self._af or '')
            vol_f = float(m.group(1)) if m else 1.0
            vol_f = max(0.01, min(vol_f, 32.0))
            vol = f"{vol_f:.4g}"
            cmd_str = (f"arecord -D '{dev}' -f S16_LE -r {rate} -c 1 -t raw | "
                       f"sox -t raw -r {rate} -e signed -b 16 -c 1 - "
                       f"-t raw -r {rate} -e signed -b 16 -c 1 - vol {vol}")
            proc = subprocess.Popen(cmd_str, shell=True, stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE, start_new_session=True)
            self.proc = proc
            self._rate = rate
            self._device = dev
            threading.Thread(target=self._reader, args=(proc,), daemon=True).start()
            threading.Thread(target=self._stderr_reader, args=(proc,), daemon=True).start()
            return proc
        tqs = "64" if self._low_latency else "512"
        cmd = [
            "ffmpeg", "-f", "alsa", "-thread_queue_size", tqs,
            "-ar", rate, "-i", dev, "-ac", "1",
        ]
        if self._af:
            cmd += ["-af", self._af]
        extra = ["-fflags", "+nobuffer"] if self._low_latency else []
        cmd += extra + [
            "-f", "s16le", "-acodec", "pcm_s16le",
            "-nostdin", "-vn", "-sn", "-dn", "-map", "0:a",
            "-flush_packets", "1", "-nostats", "pipe:1"
        ]
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                start_new_session=True)
        self.proc = proc
        self._rate = rate
        self._device = dev
        threading.Thread(target=self._reader, args=(proc,), daemon=True).start()
        threading.Thread(target=self._stderr_reader, args=(proc,), daemon=True).start()
        return proc

    def _stderr_reader(self, proc):
        """stderr を行単位で読み捨てつつ末尾を last_stderr に残す(診断用)。"""
        try:
            for line in iter(proc.stderr.readline, b""):
                s = line.decode(errors="replace").rstrip()
                if s:
                    self.last_stderr.append(s)
        except Exception:
            pass

    def stderr_tail(self, n: int = 5) -> str:
        return " | ".join(list(self.last_stderr)[-n:])

    def _reader(self, proc):
        fd = proc.stdout.fileno() if self._low_latency else None
        chunk = 512 if self._low_latency else 4096
        while proc.poll() is None:
            try:
                r, _, _ = select.select([proc.stdout], [], [], 0.1)
                if r:
                    data = os.read(fd, chunk) if fd is not None else proc.stdout.read(chunk)
                    if not data:
                        break
                    with self._subs_lock:
                        out = bytes(len(data)) if time.time() < self._mute_until else data
                        for q in list(self._subs.values()):
                            while q.full():
                                try:
                                    q.get_nowait()
                                except _queue.Empty:
                                    break
                            try:
                                q.put_nowait(out)
                            except _queue.Full:
                                pass
            except Exception:
                break

# ── ノイズリダクション設定 ──────────────────────────────────
_noise_reduction_level = 0  # 0=OFF, 1=Light, 2=Medium, 3=Strong, 4=Stronger, 5=Max
_cw_decode_active = False    # True時はafftdnをスキップしバンドパスのみ適用（CWタイミング保護）
_cw_nr_narrow = False        # CWデコード中のNR ON。afftdnの代わりにCWピッチ周辺の狭帯域BPFを使う
                             # (biquad2段でCPUほぼゼロ=単コアPiでも音切れしない。v3.34で追加)
_cw_nr_center = 0            # 狭帯域BPFの中心周波数[Hz]。アプリが復号中のトーン(ch0)を送る。0=既定650

def _build_rx_af(level: int) -> str:
    # volume=10.0 (+20 dB) clipped the stream continuously. Measured on the IC-705 at idle:
    # RMS -8 dBFS with full-scale peaks and 100-240 samples per 0.5 s pinned to the rail, in
    # every window of a 30 s capture. The rig's own level is about -28 dBFS, which is normal,
    # so the whole 20 dB was headroom the chain did not have. Clipping turns the RTTY tones
    # into square waves and destroys the mark/space discrimination the decoder depends on,
    # which is why receive was poor while transmit measured clean.
    #
    # +6 dB keeps some boost for listening and measured 11-18 dB of headroom with no clipped
    # samples on either rig. Playback loudness is the phone's job, not this chain's.
    #
    # No limiter. An `alimiter` was tried here and made decoding worse: ffmpeg's alimiter
    # enables automatic level correction by default, so it applies a time-varying gain. Any
    # dynamic gain in front of a modem is harmful, because the decoder compares the mark and
    # space tone powers against each other and against a noise estimate, and a moving gain
    # pumps all three. It also costs CPU the single-core Pi does not have: with the limiter in
    # the chain, 32 kHz capture truncated after a second or two, while 16 kHz stayed solid.
    # Protect the headroom with fixed gain only.
    # lowpass=3400: 8kHzサンプリング時の全二重ハウリング対策。帯域端(3400-4000Hz)を落として
    #   ループ利得を下げる。RTTY(2125/2295)/CW/SSB/FT8 はすべて3400以下なので実用上無害。
    base = "highpass=f=300,lowpass=f=3400,volume=2.0"
    # NR ON時: ノイズ除去後にダイナミック圧縮で弱い信号を持ち上げる
    enhance = ",acompressor=threshold=-20dB:ratio=3:attack=5:release=50"
    # CWデコード中: afftdnはキーON/OFFのトランジェントを遅延させCWタイミングを歪めるので使わない。
    # SPKのNRレベルに依らず常にこの経路(afftdn無し)を通す=単コアPiでも音切れしない。
    #   NR OFF: baseのhighpass300/lowpass3400がバンドパスNRとして機能(従来通りの広帯域)。
    #   NR ON (_cw_nr_narrow): CWピッチ周辺の狭帯域BPF(400-1000Hz)に差し替えてS/Nを上げる。
    #     biquad2段でCPUほぼゼロ、afftdnのような音切れ・タイミング歪みが無い。(v3.34)
    if _cw_decode_active:
        if _cw_nr_narrow:
            # CWピッチ(アプリがch0トーンを送る)を中心に、2段カスケードのバンドパスで鋭く絞る。
            # 単段biquadはスカートが緩い(~12dB/oct)ので2段重ねて帯域外ノイズを強く落とす。
            # volumeは帯域通過の減衰を補償(acompressorが後段で過大を抑える)。中心未指定は650Hz。
            c = _cw_nr_center if _cw_nr_center and _cw_nr_center > 0 else 650
            c = max(250, min(1500, int(c)))
            # 強めのNR: 3段カスケード・幅90Hz(実効~55Hz)でスカートを急峻化し帯域外ノイズを強く除去。
            # リグRX(例:200Hz)の内側をさらに絞る。高速CW(30wpm+)ではキーイングが鈍る場合あり。
            # volumeは帯域制限による音量低下を補償(acompressorが後段で過大を抑える)。
            w = 90
            bp = f"bandpass=f={c}:width_type=h:w={w}"
            narrow = f"{bp},{bp},{bp},volume=3.0"
            return narrow + enhance
        return base + enhance
    if level == 0:
        return base
    nr = {
        1: ",afftdn=nf=-30:nr=15",
        2: ",afftdn=nf=-25:nr=20",
        3: ",afftdn=nf=-20:nr=25:tn=1",
        4: ",afftdn=nf=-20:nr=33:tn=1",
        5: ",afftdn=nf=-20:nr=40:tn=1",
    }
    return base + nr.get(level, "") + enhance

# メイン音声: SPK用フィルター+音量ブースト、direwolf停止あり
_mgr_rx  = _FfmpegMgr(af=_build_rx_af(0), kill_direwolf=True)
# FT8音声: arecord|sox パイプライン（ffmpegより起動が速い: ~0.2s vs ~1.5s）
# 全二重失敗でarecordが死んでも ~200ms で復旧できる
_mgr_sub = _FfmpegMgr(af="volume=8.0", kill_direwolf=False, idle_stop_sec=0, low_latency=True, use_arecord=True)

KISS_HOST = "127.0.0.1"
KISS_PORT = 8001


class GPSData(BaseModel):
    lat: float
    lon: float


class AprsConfig(BaseModel):
    callsign: str
    ssid: int
    path: str
    interval: int
    freq: float
    baud: int
    use_gps: bool
    manual_lat: float
    manual_lon: float
    symbol: str
    comment: str = ""
    destination: str
    sound_device: str
    rig_id: str
    cat_device: str
    use_rig_modem: bool = False  # true: FTX-1内蔵APRSモデム(CAT) / false: DireWolf(Pi)
    modem_sel: int = 2  # 1:AUTO 2:MAIN 3:SUB (use_rig_modem時のみ意味を持つ)
    enabled: bool = True  # APRS機能そのもののON/OFF(M5のAPRS Enabledトグル)。
                           # falseの間は受信デコード用direwolfも止める。
    heard_suppress_sec: int = 600  # 同一局の受信通知を再度出すまでの最短間隔(秒)


class AprsStart(BaseModel):
    freq: float
    interval: int


def _ts() -> str:
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

def _rigctl_log(tag: str, cmd: str, raw: str):
    ts = _ts()
    # PTT変化は目立つよう [PTT] タグを追加
    c = cmd.strip()
    if c in ("T 0", "T 1"):
        state = "ON" if c == "T 1" else "OFF"
        print(f"[{ts}] *** [PTT {state}] {tag} cmd='{c}' -> '{raw[:60]}'", flush=True)
    elif c == "t":
        # PTT問い合わせは詳細ログ抑制（毎秒呼ばれるため）
        pass
    else:
        print(f"[{ts}] [{tag}] '{c}' -> '{raw[:60]}'", flush=True)


def rigctl_cmd(cmd: str) -> str:
    with rig_lock:
        s = None
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(2.0)
            s.connect(("localhost", 4532))
            s.sendall((cmd + "\n").encode())
            data = s.recv(4096)
            raw = data.decode(errors="replace").strip()
            _rigctl_log("rigctl", cmd, raw)
            return raw
        except socket.timeout:
            print(f"[{_ts()}] [rigctl] timeout: '{cmd}'", flush=True)
            return ""
        except Exception as e:
            print(f"[{_ts()}] [rigctl] error '{cmd}': {e}", flush=True)
            return ""
        finally:
            if s:
                try:
                    s.close()
                except Exception:
                    pass


def rigctl_cmd_priority(cmd: str) -> str:
    s = None
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(2.0)
        s.connect(("localhost", 4532))
        s.sendall((cmd + "\n").encode())
        data = s.recv(4096)
        raw = data.decode(errors="replace").strip()
        _rigctl_log("rigctl_prio", cmd, raw)
        return raw
    except socket.timeout:
        print(f"[{_ts()}] [rigctl_prio] timeout: '{cmd}'", flush=True)
        return ""
    except Exception as e:
        print(f"[{_ts()}] [rigctl_prio] error '{cmd}': {e}", flush=True)
        return ""
    finally:
        if s:
            try:
                s.close()
            except Exception:
                pass


def _rig_send_no_reply(cmd: str) -> str:
    """Yaesu新CAT(FTX-1/FT-991等)の応答を返さないSETコマンド専用("w XX;" 形式で渡す)。
    ★ "w XX;" のまま送ると rigctld は無線機の応答を";"までタイムアウト(約2秒)待ち続け、
      その間 rigctld が塞がる。クライアント側で早めに切断しても rigctld 内では処理が続き、
      次のコマンドは別接続(別スレッド)で順番待ちになるため実行順が入れ替わることがあった
      (FR00→VS→FR01 の順序崩れや、poll_rig のタイムアウト連発→rigctld自動再起動)。
      そこで "W XX; 0"(受信0バイト)に変換して送る。Hamlib 4.7.2 の send_cmd は受信バイト数0
      なら読み取りをせず即座に応答するため、1コマンドごとに完了を待ってから次を送れる
      (FTX-1 の APRS 設定で実機確認済み)。"""
    if cmd.startswith("w ") and cmd.rstrip().endswith(";"):
        cmd = "W " + cmd[2:].strip() + " 0"
    s = None
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1.0)
        s.connect(("localhost", 4532))
        s.sendall((cmd + "\n").encode())
        try:
            data = s.recv(4096)
            raw = data.decode(errors="replace").strip()
        except socket.timeout:
            raw = ""
        _rigctl_log("rig_fast", cmd, raw)
        return raw
    except Exception as e:
        print(f"[{_ts()}] [rig_fast] error '{cmd}': {e}", flush=True)
        return ""
    finally:
        if s:
            try:
                s.close()
            except Exception:
                pass


def _rig_get_vfo_freq(vfo_cmd: str):
    """MAIN(FA)/SUB(FB)VFOの周波数を素のCATクエリ(パラメータなし)で直接取得する。
    実機で確認: "w FA;"/"w FB;"(問い合わせ)は"FA432680000;"のように応答が返る
    (パラメータ付きのSET形"w FAnnnnnnnnn;"は無応答なのと対照的、_rig_send_no_reply参照)。
    HamlibのVFO抽象化("f"コマンド)はMain/Sub機でraw VS切替後の実際の動作VFOを
    追従しないため(常にMain側の周波数を返す)、mainsub機種ではこちらを使う。"""
    s = None
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1.0)
        s.connect(("localhost", 4532))
        s.sendall(f"w {vfo_cmd};\n".encode())
        # ★ 実機の応答が複数回のTCP書き込みに分かれて届くことがあり、recv()を1回だけ
        #   呼ぶと最初の空/断片データしか拾えず無反応に見えることがあった。応答の終端
        #   ";"が現れるか1秒のデッドラインまで、受信バッファに読み溜める。
        buf = b""
        deadline = time.time() + 1.0
        while time.time() < deadline:
            try:
                chunk = s.recv(4096)
            except socket.timeout:
                break
            if not chunk:
                break
            buf += chunk
            if b";" in buf:
                break
        raw = buf.decode(errors="replace").strip()
        if raw.startswith(vfo_cmd):
            digits = raw[len(vfo_cmd):].split(";")[0].strip()
            if digits.isdigit():
                return int(digits)
        else:
            print(f"[{_ts()}] [rig_get_freq] unexpected reply for '{vfo_cmd}': '{raw}'", flush=True)
    except Exception as e:
        print(f"[{_ts()}] [rig_get_freq] error '{vfo_cmd}': {e}", flush=True)
    finally:
        if s:
            try:
                s.close()
            except Exception:
                pass
    return None


def rigctl_alive() -> bool:
    try:
        s = socket.socket()
        s.settimeout(0.5)
        s.connect(("localhost", 4532))
        s.close()
        return True
    except Exception:
        return False


def _wait_usb_device(dev: str, timeout: float = 5.0) -> bool:
    """Wait for /dev/{dev} to appear after USB re-enumeration."""
    path = f"/dev/{dev}"
    if os.path.exists(path):
        return True
    subprocess.run(["sudo", "udevadm", "trigger", "--action=add"], capture_output=True)
    deadline = time.time() + timeout
    while time.time() < deadline:
        time.sleep(0.3)
        if os.path.exists(path):
            return True
    return False


# ★ Pi側で機種を見てRTS/DTR→RIGへ自動変換するのはやめた。M5のPTT設定画面で
#   ユーザーが選んだ方式(RTS/DTR/RIG)をそのまま使う(Android版と同じ設計)。
#   IC-705等でRTS/DTRのUSBオーディオリセット問題を避けたい場合は、ユーザー側で
#   明示的に"RIG"を選んでもらう。
def _resolve_ptt_type(model: int, cat: str, ptt_type: str) -> str:
    return (ptt_type or "RTS").upper()


def _trigger_rigctld_restart(*args, **kwargs) -> bool:
    """start_rigctldをバックグラウンドスレッドで起動する。
    poll_rigのタイムアウト検知・PTT ON失敗・音声USBリセット検知など複数箇所から
    ほぼ同時に再起動要求が来ることがある(PTT連打時にrigctld再起動の最中に次の
    PTTが来る等)。呼び出し側の"not _rigctld_restarting"チェックだけではcheck-
    then-actの間に競合し、複数のstart_rigctldが同時に走って共倒れする恐れが
    あるため、ロックで排他し2つ目以降は何もせず即falseを返す(既に走っている
    再起動が完了すれば全員の状況は改善するので無視して問題ない)。"""
    if not _rigctld_restart_lock.acquire(blocking=False):
        return False

    def _run():
        try:
            start_rigctld(*args, **kwargs)
        finally:
            _rigctld_restart_lock.release()

    threading.Thread(target=_run, daemon=True).start()
    return True


# シリアルデバイス名の許可パターン。ttyUSB0 / ttyACM0 / serial0 のような
# 英数字のみを許可し、"../" や絶対パスでの指定(パストラバーサル)を弾く。
# /dev/ プレフィックスは呼び出し側で付与するため、ここでは basename のみ検証する。
_DEV_NAME_RE = re.compile(r'^[A-Za-z0-9_]+$')


def _validate_dev_name(name: str, field: str = "device") -> str:
    """CATやPTTのデバイス名(/dev/ 配下のbasename)を検証して返す。
    NONE/空文字はそのまま通す(PTTなしを許容)。不正ならHTTP 400で拒否する。"""
    n = (name or "").strip()
    if n == "" or n.upper() == "NONE":
        return n
    # 呼び出し側が /dev/ を付けてくるケースも許容しつつ basename だけ検証する
    base = n[len("/dev/"):] if n.startswith("/dev/") else n
    if not _DEV_NAME_RE.match(base):
        raise HTTPException(status_code=400, detail=f"invalid {field} name")
    return base


def start_rigctld(model, cat, baud, ptt="", ptt_type="RTS", release_ptt=True):
    global rigctld_process, _rigctld_restarting, last_rig_ok
    _rigctld_restarting = True
    # 1. 追跡しているプロセス参照を graceful に停止
    if rigctld_process and rigctld_process.poll() is None:
        try:
            rigctld_process.terminate()
            rigctld_process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            rigctld_process.kill()
            rigctld_process.wait(timeout=2)
        except Exception:
            pass
    rigctld_process = None
    # 2. 孤立プロセスを SIGTERM で掃討してから SIGKILL で確実に終了
    subprocess.run(["pkill", "-TERM", "-f", "rigctld"], capture_output=True)
    # 3. ポート 4532 が解放されるまで最大 5 秒待機
    deadline = time.time() + 5.0
    while time.time() < deadline:
        try:
            s = socket.socket()
            s.settimeout(0.2)
            s.connect(("localhost", 4532))
            s.close()
            time.sleep(0.2)  # まだ bind されている — 待機継続
        except Exception:
            break  # 接続拒否 = ポート解放済み
    # 4. 残存プロセスを SIGKILL で強制終了
    subprocess.run(["pkill", "-KILL", "-f", "rigctld"], capture_output=True)
    time.sleep(0.2)
    # 5. CATデバイスが存在するか確認。USB断線後の再列挙を待つ
    if not _wait_usb_device(cat, timeout=5.0):
        print(f"[{_ts()}] [rigctld] WARNING: /dev/{cat} not found after 5s", flush=True)
    # 6. 新しい rigctld を起動（nice +10 で uvicorn より低優先度に設定）
    _local_rigctld = os.path.join(os.path.expanduser("~"), ".local", "bin", "rigctld")
    _rigctld_bin = _local_rigctld if os.path.isfile(_local_rigctld) else "rigctld"
    # -T 127.0.0.1: rigctld のTCP待ち受けをループバックに限定する。
    # 指定しないと 0.0.0.0(全インターフェース)で待ち受け、FastAPIのAPI Key認証を
    # バイパスしてLAN上の誰でもポート4532経由で直接無線機を操作できてしまう。
    # api.py からの接続は常に localhost:4532 のため実害なく制限できる。
    cmd = ["nice", "-n", "10", _rigctld_bin, "-m", str(model), "-r", f"/dev/{cat}", "-s", str(baud), "-T", "127.0.0.1", "-t", "4532"]
    # モデル別 stop_bits: FTX-1(1051) はデフォルト(1)を明示指定
    _stop_bits = {1051: 1}
    if model in _stop_bits:
        cmd += ["-C", f"stop_bits={_stop_bits[model]}"]
    effective_ptt_type = _resolve_ptt_type(model, cat, ptt_type)
    if effective_ptt_type != ptt_type.upper():
        print(f"[rigctld] using -P {effective_ptt_type} instead of -P {ptt_type.upper()}", flush=True)
    if ptt and ptt.upper() != "NONE":
        cmd += ["-p", f"/dev/{ptt}", "-P", effective_ptt_type]
    print(f"starting rigctld: {' '.join(cmd)}")
    rigctld_process = subprocess.Popen(cmd, stderr=subprocess.PIPE)
    # Phase 1: ポート 4532 が TCP 接続を受け付けるまで待つ。
    _alive_deadline = time.time() + 5.0
    _port_ready = False
    while time.time() < _alive_deadline:
        if rigctld_process.poll() is not None:
            err = rigctld_process.stderr.read().decode(errors="replace")
            print(f"rigctld exited early: {err.strip()}", flush=True)
            break
        if rigctl_alive():
            print(f"rigctld port open pid={rigctld_process.pid}", flush=True)
            _port_ready = True
            break
        time.sleep(0.2)
    else:
        print(f"rigctld port-open timeout (5s): pid={rigctld_process.pid if rigctld_process else '?'}", flush=True)
    # Phase 2: rigctld が実際にコマンドに応答するまで待つ。
    # ポートが開いただけでは CAT 接続確立前にクラッシュすることがある。
    # その短い窓で _rigctld_restarting = False にすると poll_rig のストリークが
    # 即座に溜まり再起動ループが発生する。応答確認後にのみ False にする。
    if _port_ready and rigctld_process and rigctld_process.poll() is None:
        _resp_deadline = time.time() + 6.0
        while time.time() < _resp_deadline:
            if rigctld_process.poll() is not None:
                err = rigctld_process.stderr.read().decode(errors="replace")
                print(f"rigctld exited during CAT init: {err.strip()}", flush=True)
                break
            _rs = None
            try:
                _rs = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                _rs.settimeout(2.0)
                _rs.connect(("localhost", 4532))
                _rs.sendall(b"t\n")
                _resp = _rs.recv(4096).decode(errors="replace").strip()
                if _resp:
                    print(f"rigctld running pid={rigctld_process.pid} (t='{_resp}')", flush=True)
                    # 起動確認でリグから正常応答(数値)が取れたら、poll_rigを待たずに通信OKとする
                    if _resp.split()[0].isdigit():
                        last_rig_ok = time.time()
                    break
            except Exception:
                pass
            finally:
                try:
                    if _rs:
                        _rs.close()
                except Exception:
                    pass
            time.sleep(0.3)
        else:
            print(f"rigctld CAT-ready timeout (6s): pid={rigctld_process.pid if rigctld_process else '?'}", flush=True)
    # Hamlib RIG/RTS PTT modes can accidentally assert PTT during rig_open() initialization.
    # Explicitly release PTT and reset TX state after every rigctld start.
    # release_ptt=False skips this during audio TX recovery (IC-705 stays in TX mode after USB reset).
    if release_ptt:
        radio_cache["tx"] = False
        global last_ptt_state
        if last_ptt_state == 0:
            # アクティブなTXなし: T 0 を送って RTS などの誤アサートを解除する。
            # -P RTS 使用時: rig_open() でシリアルポートが開く際に RTS が一瞬
            # HIGH になることがある。即座に T 0 で LOW に戻す。
            # last_ptt_state==1 のとき(Androidがリトライして T 1 を送信中)は
            # T 0 を送ってはいけない — アクティブな送信を中断してしまう。
            time.sleep(0.3)
            try:
                result = rigctl_cmd_priority("T 0")
                print(f"[{_ts()}] [start_rigctld] PTT release: T 0 -> '{result}'", flush=True)
            except Exception as e:
                print(f"[{_ts()}] [start_rigctld] PTT release failed: {e}", flush=True)
        else:
            print(f"[{_ts()}] [start_rigctld] PTT release skipped (TX active, last_ptt_state=1)", flush=True)
        last_ptt_state = 0
    global _timeout_streak
    _timeout_streak = 0  # リスタート中に積み増したカウントをリセット
    _rigctld_restarting = False


def _dump_caps_text(timeout_total: float = 3.0) -> str:
    """rigctldに\\dump_capsを送り、応答が止まる(=送り終わり)まで読み続けて返す。
    通常のコマンドと違い応答が複数行/不定長のため、専用の読み取りループにしている。"""
    s = None
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1.0)
        s.connect(("localhost", 4532))
        s.sendall(b"\\dump_caps\n")
        chunks = []
        deadline = time.time() + timeout_total
        while time.time() < deadline:
            try:
                data = s.recv(4096)
            except socket.timeout:
                break
            if not data:
                break
            chunks.append(data)
        return b"".join(chunks).decode(errors="replace")
    except Exception as e:
        print(f"[{_ts()}] [vfo_mode] dump_caps error: {e}", flush=True)
        return ""
    finally:
        if s:
            try:
                s.close()
            except Exception:
                pass


def _detect_vfo_mode():
    """機種選択で接続したrigのHamlibバックエンドが MAIN/SUB(2波同時受信機) か
    VFO A/B(通常機) かを\\dump_capsの"VFO list:"行から判定する。
    あわせて"Mode list:"行から、その機種がHamlib上で実際にサポートしている
    モード一覧(C4FM/DSTAR等、機種固有のデジタルモードを含む)も検出し、
    current_mode_listに保存する。
    /radio/openのたびにバックグラウンドで呼ばれ、rig_vfo_mode / current_mode_list を更新する。"""
    global rig_vfo_mode, current_mode_list
    # rigctld のポートが開くまで待つ(dump_caps はリグ接続不要でHamlibの内部データを返すため
    # ポートが開けば即実行できる)。
    for _ in range(30):
        if rigctl_alive():
            break
        time.sleep(0.5)
    # dump_caps は独立したソケット接続を開くため rig_lock は不要。
    # rig_lock を保持したまま実行すると poll_rig の周波数/モード取得が最大3秒ブロックされる。
    text = _dump_caps_text()
    if not text:
        rig_vfo_mode = "ab"  # 判定不能時は最も一般的なA/B型として扱う
        current_mode_list = None  # 検出失敗時は/radio/modes等が静的リストにフォールバック
        print("[vfo_mode] dump_caps empty, defaulting to 'ab'", flush=True)
        return
    vfo_line = ""
    mode_line = ""
    for line in text.splitlines():
        low = line.lower()
        if not vfo_line and "vfo list" in low:
            vfo_line = line
        if not mode_line and "mode list" in low:
            mode_line = line
    tokens = vfo_line.upper()
    if "MAIN" in tokens and "SUB" in tokens:
        rig_vfo_mode = "mainsub"
    else:
        rig_vfo_mode = "ab"
    print(f"[vfo_mode] detected: {rig_vfo_mode} (line: '{vfo_line.strip()}')", flush=True)

    if ":" in mode_line:
        raw_modes = [m for m in mode_line.split(":", 1)[1].split() if m]
    else:
        raw_modes = []

    # ノイズモードのフィルタリング
    modes = [m for m in raw_modes if m not in _HAMLIB_NOISE_MODES]

    current_mode_list = modes if modes else None
    print(f"[mode_list] raw={raw_modes}", flush=True)
    print(f"[mode_list] filtered: {current_mode_list}", flush=True)


def poll_rig():
    global poll_enabled, last_user_freq_change, last_user_mode_change, _rig_tx_latch_until, last_rig_ok, _timeout_streak
    print("[poll_rig] waiting for rigctld...")
    for _ in range(30):
        if rigctl_alive():
            break
        time.sleep(0.5)
    last_bkin_rig = 0
    last_tuner_rig = 0
    _m_skip_remaining = 0  # C4FM モード検出時、m クエリを数サイクルスキップ
    print("[poll_rig] rigctld ready, starting poll loop")
    while True:
        # ★ CI-Vブリッジ稼働中は rigctld を一切触らない。ブリッジがシリアルを占有しているので、
        #   ここで "t" を投げるとタイムアウト→誤 rigctld 再起動→ブリッジとシリアルを奪い合って
        #   D-STAR制御が壊れる(接続失敗/応答なし)。ブリッジ停止で自動的に再開する。
        if civ_bridge_running:
            time.sleep(0.3)
            continue
        # ★ APRS送信中は "t" 問い合わせ自体を止める。tx_raw の結果で radio_cache["tx"] を
        #   毎回上書きしてしまうため、tx_in_progress 側で立てた値がすぐ書き戻されていた。
        if tx_in_progress:
            time.sleep(0.5)
            continue
        rig_beacon_active = aprs_running and aprs_cfg is not None and aprs_cfg.use_rig_modem
        try:
            tx_raw = rigctl_cmd("t")
            if tx_raw:
                tx = int(tx_raw.split()[0]) if tx_raw.split()[0].isdigit() else 0
                if tx and rig_beacon_active:
                    # AUTO BEACON送信はごく短時間(1秒未満)で終わるため、検知したら
                    # M5側の/radio/statusポーリングが確実に拾えるよう表示を少し保持する
                    _rig_tx_latch_until = time.time() + 1.5
                radio_cache["tx"] = bool(tx) or time.time() < _rig_tx_latch_until
                if tx_raw.split()[0].isdigit():
                    last_rig_ok = time.time()  # RPRT -x 等のエラー応答は正常扱いしない
                _timeout_streak = 0
            else:
                # timeout: keep last TX state so watchdog can fire if needed
                tx = int(radio_cache.get("tx", False))
                # Don't restart rigctld during TX: DTR reset would cut transmission
                # Don't count timeouts while a restart is in progress (_rigctld_restarting=True);
                # start_rigctld resets _timeout_streak when it finishes.
                if not tx and not _rigctld_restarting:
                    _timeout_streak += 1
                    # rigctld プロセスが終了していれば即再起動。
                    # プロセスは生きているが応答しない場合は 4 回連続失敗してから再起動
                    # (FT-991 C4FM モードでは 'm' がタイムアウトしても 't' は正常に応答するため
                    #  閾値を低くすると誤再起動 → T 0 送信 → brief TX が発生する)。
                    _proc_dead = rigctld_process is not None and rigctld_process.poll() is not None
                    # FT-991 は接続直後(~45秒)に CAT が一時的に詰まるが自己復帰する(CATとUSB音声が
                    # 同一USBのための既知のクセ)。その間は rigctld を再起動しない — 再起動はシリアル
                    # 再オープンを伴い、かえって詰まりを長引かせるため。プロセス死亡時は機種に関わらず即再起動。
                    _ft991_settling = _is_ft991() and (time.time() - _rig_open_started) < 45.0
                    if (_proc_dead or (_timeout_streak >= 4 and not _ft991_settling)) and current_model and current_cat:
                        print(f"[{_ts()}] [poll_rig] {_timeout_streak} consecutive timeouts (proc_dead={_proc_dead}) — restarting rigctld", flush=True)
                        _timeout_streak = 0
                        _trigger_rigctld_restart(current_model, current_cat, current_baud,
                                                  current_ptt, current_ptt_type)
        except Exception:
            tx = 0
            radio_cache["tx"] = False
            _timeout_streak = 0

        if tx and last_ptt_state == 1:
            # サーバーがPTTを命令した場合のみポーリングをスキップ。
            # last_ptt_state=0 のとき(Hamlibの誤検知など)はスキップしない。
            time.sleep(1.0)  # TX中はrigctld負荷を軽減
            continue

        if not poll_enabled:
            time.sleep(0.2)
            continue

        try:
            # ★ Main/Sub機種はHamlibの抽象化コマンド"f"がraw VS切替後の実際の動作VFOに
            #   追従せず、常にMain側の周波数を返してしまう(実機で確認: S/M(Sub動作)中でも
            #   "f"はMain周波数のまま)。そのためmainsub機種はrig_cycle_idxから現在の動作
            #   VFOを判定し、FA(Main)/FB(Sub)を素のCATクエリで直接読む。
            if rig_vfo_mode == "mainsub":
                vfo_cmd = "FB" if rig_cycle_idx == 2 else "FA"
                with rig_lock:
                    freq_val = _rig_get_vfo_freq(vfo_cmd)
                if freq_val is not None and time.time() - last_user_freq_change > 0.5:
                    radio_cache["freq"] = freq_val
            else:
                freq_raw = rigctl_cmd("f")
                val = freq_raw.split()[0] if freq_raw else ""
                if val.lstrip("-").isdigit() and time.time() - last_user_freq_change > 0.5:
                    radio_cache["freq"] = int(val)
        except Exception:
            pass

        try:
            if _m_skip_remaining > 0:
                # C4FM モードでは FT-991 が m クエリに応答しないため 2 秒タイムアウト
                # が発生し、並行する T 1 (PTT) もブロックされてラグが生じる。
                # タイムアウト後は数サイクルスキップして T 1 のブロックを防ぐ。
                _m_skip_remaining -= 1
            else:
                mode_raw = rigctl_cmd("m")
                parts = mode_raw.split() if mode_raw else []
                if parts and time.time() - last_user_mode_change > 0.5:
                    radio_cache["mode"] = parts[0]
                    if len(parts) >= 2 and parts[1].lstrip("-").isdigit():
                        radio_cache["width"] = int(parts[1])
                if not mode_raw:
                    # タイムアウト: 次の 2 サイクルをスキップして T 1 のブロックを防ぐ
                    _m_skip_remaining = 2
        except Exception:
            pass

        if time.time() - last_bkin_rig > 15:
            try:
                if _is_ft991():
                    # FT-991/FT-991A は生CAT("BK;")で BK 状態を読む
                    v = _ft991_read_bkin()
                    if v is not None:
                        radio_cache["bk_in"] = v
                else:
                    for func in ("SBKIN", "FBKIN"):
                        raw = rigctl_cmd(f"u {func}")
                        v = raw.split()[0] if raw else ""
                        if v.lstrip("-").isdigit():
                            radio_cache["bk_in"] = int(v)
                            break
            except Exception:
                pass
            last_bkin_rig = time.time()

        if time.time() - last_tuner_rig > 15:
            try:
                if _is_ftx1():
                    # FTX-1(Yaesu新CAT)は "AC;" で ATU 状態を読む(AC00n; の n)
                    v = _yaesu_read_tuner()
                    if v is not None:
                        radio_cache["tuner"] = 0 if v == 0 else 1
                else:
                    raw = rigctl_cmd("u TUNER")
                    vv = raw.split()[0] if raw else ""
                    if vv.lstrip("-").isdigit():
                        radio_cache["tuner"] = 1 if int(vv) else 0
            except Exception:
                pass
            last_tuner_rig = time.time()

        # ★ FTX-1内蔵モデムでビーコン運用中は"t"問い合わせの間隔を縮めて、
        #   短時間で終わるAUTO BEACON送信の取りこぼしを減らす
        time.sleep(0.2 if rig_beacon_active else 1.0)


def poll_signal():
    global poll_enabled
    for _ in range(30):
        if rigctl_alive():
            break
        time.sleep(0.5)
    last_power = 0
    last_sql = 0
    while True:
        is_tx = tx_in_progress or radio_cache.get("tx", False)
        if is_tx:
            # TX中はRFOUTPUTとALCをポーリング
            try:
                raw = rigctl_cmd("l RFPOWER_METER")
                val = raw.split()[0] if raw else ""
                if val:
                    radio_cache["rf_out"] = float(val)
            except Exception:
                pass
            try:
                raw = rigctl_cmd("l ALC")
                val = raw.split()[0] if raw else ""
                if val:
                    radio_cache["alc"] = float(val)
            except Exception:
                pass
            time.sleep(0.3)
            continue

        # TX終了時にメーターをクリア
        if radio_cache.get("rf_out", 0.0) != 0.0 or radio_cache.get("alc", 0.0) != 0.0:
            radio_cache["rf_out"] = 0.0
            radio_cache["alc"]    = 0.0

        # バンドスコープ掃引中はVFOを高速に動かしているため、通常のSTRENGTH
        # ポーリングは行わない(rig_lock競合でスイープが遅くなるのを防ぐ)。
        if _scope_active:
            time.sleep(0.2)
            continue

        try:
            raw = rigctl_cmd("l STRENGTH")
            val = raw.split()[0] if raw else ""
            if val:
                sig = float(val)
                radio_cache["signal"] = sig
        except Exception:
            pass

        if time.time() - last_power > 5:
            try:
                raw = rigctl_cmd("l RFPOWER")
                val = raw.split()[0] if raw else ""
                if val:
                    radio_cache["power"] = float(val)
            except Exception:
                pass
            last_power = time.time()

        if time.time() - last_sql > 5:
            try:
                raw = rigctl_cmd("l SQL")
                val = raw.split()[0] if raw else ""
                if val:
                    radio_cache["sql"] = float(val)
            except Exception:
                pass
            last_sql = time.time()

        time.sleep(1.0)


def watchdog_heartbeat():
    global last_heartbeat, last_ptt_state
    while True:
        # last_ptt_state=1 のときのみ watchdog を発動する。
        # last_ptt_state=0 のとき(Hamlibの誤検知・外部PTT等)は T 0 を送らない。
        # FT-991 の C4FM モードで rigctl t が誤って 1 を返す場合、
        # watchdog が T 0 を送り続けて断続送信を引き起こすのを防ぐ。
        if radio_cache.get("tx", False) and last_ptt_state == 1:
            # APRS TX 中は direwolf が PTT を管理するので watchdog を抑制
            if not tx_in_progress and time.time() - last_heartbeat > 5.0:
                print(f"[{_ts()}] *** [PTT OFF] watchdog: heartbeat lost -> TX OFF", flush=True)
                try:
                    rigctl_cmd_priority("T 0")
                except Exception:
                    pass
                radio_cache["tx"] = False
                last_ptt_state = 0  # 次のハートビートでTXを再開できるようリセット
        time.sleep(0.1)


def _ensure_venv_numpy():
    """numpy が venv にない場合に自動インストールする。起動時・UpdatePi 後に呼ばれる。"""
    try:
        import numpy  # noqa: F401
        return  # already available
    except ImportError:
        pass
    pip = str(_FASTAPI_DIR / "bin" / "pip")
    if not os.path.exists(pip):
        return
    try:
        print("[startup] numpy not found in venv — installing...", flush=True)
        r = subprocess.run([pip, "install", "--quiet", "numpy"],
                           capture_output=True, timeout=180)
        if r.returncode == 0:
            print("[startup] numpy installed successfully", flush=True)
        else:
            print(f"[startup] numpy install failed: {r.stderr.decode(errors='replace')[:200]}", flush=True)
    except Exception as e:
        print(f"[startup] numpy install error: {e}", flush=True)


def _ensure_sstv():
    """SSTV用のライブラリを venv へ pip 導入(無ければ)。起動時・UpdatePi後に呼ばれる。
    送信=pysstv(エンコード専用, PyPI)。受信デコード=colaclanth/sstv の CLI(VIS自動判定+スラント補正)。
    ※PyPIの "sstv"(0.2.0)は CLI の無い別物なので使わない。GitHub から入れて `bin/sstv` を得る。
      CLI は WAV 読込に soundfile=libsndfile を使う。"""
    pip = str(_FASTAPI_DIR / "bin" / "pip")
    # --- 送信用 pysstv/Pillow ---
    need = []
    try:
        import pysstv  # noqa: F401
        from PIL import Image  # noqa: F401
    except ImportError:
        need += ["pysstv", "Pillow"]
    if need and os.path.exists(pip):
        try:
            print(f"[startup] installing {need} ...", flush=True)
            subprocess.run([pip, "install", "--quiet", *need], capture_output=True, timeout=600)
        except Exception as e:
            print(f"[startup] pysstv install error: {e}", flush=True)

    # --- 受信デコード CLI(colaclanth/sstv, GitHub)。bin/sstv が無ければ入れる ---
    sstv_cli = str(_FASTAPI_DIR / "bin" / "sstv")
    if not os.path.exists(sstv_cli) and os.path.exists(pip):
        # 先に libsndfile を確保(無いと CLI が起動失敗し builtin に落ちる)。sudo -n apt(NOPASSWD)。
        try:
            import ctypes.util
            if ctypes.util.find_library("sndfile") is None:
                print("[startup] installing libsndfile1 via apt...", flush=True)
                subprocess.run(["sudo", "-n", "apt-get", "-o", "DPkg::Lock::Timeout=120",
                                "install", "-y", "libsndfile1"], capture_output=True, timeout=300)
        except Exception as e:
            print(f"[startup] libsndfile1 install skipped: {e}", flush=True)
        try:
            # 誤パッケージ(PyPI sstv)が入っていれば除去してから git 版を入れる。
            subprocess.run([pip, "uninstall", "-y", "sstv"], capture_output=True, timeout=120)
            print("[startup] installing colaclanth/sstv decoder CLI from git...", flush=True)
            r = subprocess.run([pip, "install", "--quiet",
                                "git+https://github.com/colaclanth/sstv.git"],
                               capture_output=True, timeout=600)
            print(f"[startup] sstv CLI install rc={r.returncode}"
                  + ("" if r.returncode == 0 else f" err={r.stderr.decode(errors='replace')[:200]}"),
                  flush=True)
        except Exception as e:
            print(f"[startup] sstv CLI install error: {e}", flush=True)


def _ensure_minimodem():
    """minimodem が無ければ apt で導入。起動時・UpdatePi(api.py更新)後に呼ばれる (RTTY用)。
    sudoers で /usr/bin/apt-get * を NOPASSWD 許可済みなので sudo -n で入る。"""
    import shutil
    if shutil.which("minimodem"):
        return
    try:
        print("[startup] minimodem not found — installing via apt...", flush=True)
        r = subprocess.run(
            ["sudo", "-n", "apt-get", "-o", "DPkg::Lock::Timeout=120", "install", "-y", "minimodem"],
            capture_output=True, timeout=300)
        if r.returncode == 0 and shutil.which("minimodem"):
            print("[startup] minimodem installed", flush=True)
        else:
            print(f"[startup] minimodem install failed: {r.stderr.decode(errors='replace')[:200]}", flush=True)
    except Exception as e:
        print(f"[startup] minimodem install error: {e}", flush=True)


# ── RTTY (minimodem) ─────────────────────────────────────────────────────────
# RTTY は Pi 側の minimodem(GPL-3.0, apt) で送受信する。アプリはテキストだけをやり取りし、
# 変復調は minimodem が担う(FT8 の mfsk-decode と同じ構図)。CI-V 直結では使わず Pi 経由専用。
class RttyTxRequest(BaseModel):
    text: str
    baud: float = 45.45
    mark: int = 2125
    space: int = 2295


@app.post("/radio/rtty/tx")
def rtty_tx(req: RttyTxRequest):
    """RTTY送信: minimodem でテキストを AFSK(Baudot) の WAV ファイルに生成し、PTT(T 1)→aplay→PTT(T 0)。
    ※ minimodem --tx -f -(stdout) はパイプに WAV を書けない(サイズ確定に seek が要る)ため、
    一時 WAV ファイルに書いてから aplay する。送信完了までブロックして返す。"""
    import shutil, tempfile
    global _rtty_tx_active
    text = (req.text or "").strip()
    if not text:
        raise HTTPException(status_code=400, detail="empty text")
    if not shutil.which("minimodem"):
        _ensure_minimodem()
        if not shutil.which("minimodem"):
            raise HTTPException(status_code=503, detail="minimodem not installed")
    _load_alsa_devices()  # Android の FT8 画面で指定した ALSA デバイスを反映
    fd, wav = tempfile.mkstemp(suffix=".wav", prefix="rtty_tx_")
    os.close(fd)
    try:
        # minimodem は STDIN からテキストを読み、-f <file> に AFSK 音声(WAV)を書く
        gen = subprocess.run(
            ["minimodem", "--tx", "--baudot", "--stopbits", "1.5",
             "-M", str(int(req.mark)), "-S", str(int(req.space)), "-f", wav, str(float(req.baud))],
            input=(text + "\n").encode("ascii", "replace"),
            capture_output=True, timeout=60)
        if gen.returncode != 0 or not os.path.getsize(wav):
            raise HTTPException(status_code=500,
                                detail=f"minimodem tx failed: {gen.stderr.decode(errors='replace')[:200]}")
        # SPK音声ストリーム(audio_tx)が再生デバイスを握っているため解放させる。
        # 先にフラグを立ててから kill することで audio_tx 側の aplay 自動再起動を抑止する。
        _rtty_tx_active = True
        subprocess.run(["pkill", "-9", "aplay"], capture_output=True)
        time.sleep(0.3)  # audio_tx が再起動を諦め、再生デバイスが解放されるのを待つ
        rigctl_cmd("T 1")
        time.sleep(0.3)
        try:
            ap = subprocess.run(["aplay", "-D", _alsa_playback_dev, wav],
                                capture_output=True, timeout=120)
            if ap.returncode != 0:
                err = ap.stderr.decode(errors="replace")[:200]
                print(f"[rtty_tx] aplay failed rc={ap.returncode} err={err!r}", flush=True)
                raise HTTPException(status_code=500, detail=f"aplay failed: {err}")
        finally:
            rigctl_cmd("T 0")
    except HTTPException:
        raise
    except Exception as e:
        print(f"[rtty_tx] error: {e}", flush=True)
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        _rtty_tx_active = False  # 送信完了: audio_tx の SPK 再生再開を許可
        try: os.remove(wav)
        except Exception: pass
    return {"status": "ok"}


def _sstv_encoder_cls(mode: str):
    """モード名から pysstv エンコーダクラスを返す(既定 Robot36)。"""
    from pysstv.color import (Robot36, MartinM1, MartinM2,
                              ScottieS1, ScottieS2, ScottieDX)
    return {
        "Robot36": Robot36, "MartinM1": MartinM1, "MartinM2": MartinM2,
        "ScottieS1": ScottieS1, "ScottieS2": ScottieS2, "ScottieDX": ScottieDX,
    }.get(mode, Robot36)


@app.post("/radio/sstv/tx")
def sstv_tx(image_b64: str = Form(...), mode: str = Form("Robot36")):
    """SSTV送信: base64画像を pysstv で音声(WAV)にエンコードし、PTT(T 1)→aplay→PTT(T 0)で送出する。
    RTTY送信と同じ音声経路(aplay + rigctld PTT)。リグは事前にFMまたはSSBにしておくこと。
    ※画像(F3F/J3F)の電波型式が免許に含まれていることが前提。送信完了までブロックして返す。"""
    import base64, io, tempfile
    global _rtty_tx_active
    _ensure_sstv()
    try:
        from PIL import Image
    except ImportError:
        raise HTTPException(status_code=503, detail="pysstv/Pillow not installed (run Update Pi)")
    try:
        raw = base64.b64decode(image_b64)
        img = Image.open(io.BytesIO(raw)).convert("RGB")
    except Exception as e:
        head = image_b64[:24] if isinstance(image_b64, str) else "?"
        print(f"[sstv_tx] bad image: {e} (b64len={len(image_b64) if image_b64 else 0} head={head!r})", flush=True)
        raise HTTPException(status_code=400, detail=f"bad image: {e}")
    enc_cls = _sstv_encoder_cls(mode)
    # エンコーダ本来の解像度にリサイズする。pysstv の MartinM2 は WIDTH=160 なので、320に
    # リサイズすると左160列(画像の左半分)しかエンコードされず右半分が送られない。
    # 各クラスの WIDTH/HEIGHT を使えば全モードで全内容が正しく送られる。
    w = getattr(enc_cls, "WIDTH", 320)
    h = getattr(enc_cls, "HEIGHT", 240 if enc_cls.__name__ == "Robot36" else 256)
    img = img.resize((int(w), int(h)))
    _load_alsa_devices()
    fd, wav = tempfile.mkstemp(suffix=".wav", prefix="sstv_tx_")
    os.close(fd)
    try:
        enc_cls(img, 48000, 16).write_wav(wav)   # samples_per_sec=48000, bits=16
        if not os.path.getsize(wav):
            raise HTTPException(status_code=500, detail="sstv encode produced empty wav")
        # SPK音声ストリーム(audio_tx)の aplay を止めて再生デバイスを解放(RTTY送信と同じ)。
        _rtty_tx_active = True
        subprocess.run(["pkill", "-9", "aplay"], capture_output=True)
        time.sleep(0.3)
        rigctl_cmd("T 1")
        time.sleep(0.3)
        try:
            ap = subprocess.run(["aplay", "-D", _alsa_playback_dev, wav],
                                capture_output=True, timeout=300)
            if ap.returncode != 0:
                err = ap.stderr.decode(errors="replace")[:200]
                print(f"[sstv_tx] aplay failed rc={ap.returncode} err={err!r}", flush=True)
                raise HTTPException(status_code=500, detail=f"aplay failed: {err}")
        finally:
            rigctl_cmd("T 0")
    except HTTPException:
        raise
    except Exception as e:
        print(f"[sstv_tx] error: {e}", flush=True)
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        _rtty_tx_active = False
        try: os.remove(wav)
        except Exception: pass
    return {"status": "ok", "mode": mode}


# ══════════ SSTV 受信(デコード) ════════════════════════════════════════════════
# 共有キャプチャ(_mgr_sub, 12kHz)の音声をデコードして画像を復元する。VISコードでモード自動判別。
# numpy だけで自己完結(外部ビルド不要)。※実電波での検証・調整が必要な best-effort 実装。
_SSTV_RX_DIR = _HOME_DIR / "sstv_rx"
_sstv_rx_running = False
_sstv_rx_thread: "threading.Thread | None" = None
_sstv_rx_status = "stopped"
_sstv_rx_lock = threading.Lock()   # 連打(同時POST)による二重起動を防ぐ
_SSTV_RX_RATE = 12000
# VIS → (name, width, height, kind, pixel_sec)
_SSTV_VIS = {
    0x2C: ("MartinM1",  320, 256, "martin",  0.0004576),
    0x28: ("MartinM2",  320, 256, "martin",  0.0002288),
    0x3C: ("ScottieS1", 320, 256, "scottie", 0.0004320),
    0x38: ("ScottieS2", 320, 256, "scottie", 0.0002752),
    0x08: ("Robot36",   320, 240, "robot36", 0.000275),
}


def _sstv_instfreq(x, sr):
    """解析信号(FFT Hilbert)から瞬時周波数[Hz]を返す。"""
    import numpy as np
    x = x.astype(np.float64)
    x = x - x.mean()
    n = len(x)
    if n < 4:
        return np.zeros(n)
    X = np.fft.fft(x)
    h = np.zeros(n)
    h[0] = 1.0
    if n % 2 == 0:
        h[n // 2] = 1.0; h[1:n // 2] = 2.0
    else:
        h[1:(n + 1) // 2] = 2.0
    a = np.fft.ifft(X * h)
    ph = np.unwrap(np.angle(a))
    f = np.diff(ph) / (2 * np.pi) * sr
    return np.concatenate([f[:1], f])


def _sstv_find_vis(freq, sr):
    """freq 配列内から VIS ヘッダを探す。見つかれば (vis_code, data_start_index) を返す。
    リーダ 1900Hz ~300ms → 1200Hz ~10ms → 1900Hz ~300ms → スタート 1200Hz 30ms →
    7データ+パリティ+ストップ(各30ms, 1300Hz=0 / 1100Hz=1)。"""
    import numpy as np
    bit = int(0.030 * sr)
    lead = int(0.300 * sr)
    i = 0
    n = len(freq)
    end = n - (lead + bit * 12)
    step = max(1, int(0.005 * sr))
    while i < end:
        seg = freq[i:i + lead]
        if seg.size and abs(np.median(seg) - 1900) < 60:   # リーダ(1900Hz)検出
            p = i + lead
            # 1200Hz ブレイク(~10ms)を飛ばして2つ目のリーダ or スタートビットを探す
            # 実装簡略化: リーダ直後 ~320ms のスタートビット(1200Hz,30ms)を探す
            j = p
            found = -1
            jend = min(n - bit * 11, p + int(0.4 * sr))
            while j < jend:
                if abs(np.median(freq[j:j + bit]) - 1200) < 60:
                    found = j; break
                j += step
            if found > 0:
                ds = found + bit   # スタートビット後=データ先頭
                bits = []
                for b in range(8):   # 7データ+パリティ
                    # ビット中央50%だけを median(境界のにじみ/遷移を除外して誤読を減らす)。
                    c = ds + b * bit + bit // 4
                    seg2 = freq[c:c + bit // 2]
                    m = np.median(seg2) if seg2.size else 1200.0
                    bits.append(1 if m < 1200 else 0)   # 1100Hz=1,1300Hz=0
                code = 0
                for b in range(7):
                    code |= (bits[b] << b)
                # 偶数パリティ検証: 7データの1の個数とパリティビットの偶奇が一致すること。
                # これで M2(0x28)↔Robot36(0x08) のような1ビット誤読を弾ける(誤モードで半分化を防ぐ)。
                parity_ok = (sum(bits[0:7]) % 2) == bits[7]
                if parity_ok and code in _SSTV_VIS:
                    return code, ds + 9 * bit   # ストップビット後=画像開始(概算)
            i = p
        i += step
    return None


def _sstv_decode_image(freq, sr, vis):
    """VIS で判明したモードに従い freq から画像(PIL Image)を復元する。
    スラント補正: 1200Hz同期パルスの間隔から実際の行周期(サンプル)を測り、各行を再アンカーする。"""
    import numpy as np
    from PIL import Image
    name, w, h, kind, px = _SSTV_VIS[vis]

    # モードごとのタイミング(秒)と、行頭から同期パルスまでの時間 sync_in_line。
    if kind == "martin":
        sync, porch = 0.004862, 0.000572; scan = px * w
        line = sync + 3 * (porch + scan); sync_in_line = 0.0
    elif kind == "scottie":
        sync, sep = 0.009, 0.0015; scan = px * w
        line = sep + scan + sep + scan + sync + sep + scan
        sync_in_line = sep + scan + sep + scan   # G,Bの後に同期が来る
    else:  # robot36(Y輝度=グレースケール。色は後日)
        sync, porch = 0.009, 0.003; yscan = 0.088
        line = sync + porch + yscan + 0.0075 + 0.044; sync_in_line = 0.0

    # --- スラント/形状補正: 1200Hz同期パルスを検出し、(1)実際の行周期を測り (2)各行を最寄りの
    #     実同期パルスへ吸着(行ごとリシンク)する。外挿だけだと誤差が積もって斜め/形崩れになるため。
    #     同期中心は「パルス中央」なので、行頭=中心 - (行頭→同期までの時間 + 同期半幅)。
    nom = line * sr
    period = nom
    half = sync_in_line * sr + sync * sr / 2.0   # 同期中心から行頭までのサンプル数
    centers = None
    c0 = None
    try:
        idx = np.where(freq < 1350)[0]
        if idx.size > 4:
            groups = np.split(idx, np.where(np.diff(idx) > int(0.004 * sr))[0] + 1)
            cs = [float(g.mean()) for g in groups if g.size >= int(0.003 * sr)]
            if len(cs) >= 5:
                arr = np.array(cs)
                diffs = np.diff(arr)
                good = diffs[(diffs > 0.7 * nom) & (diffs < 1.3 * nom)]
                if good.size:
                    period = float(np.median(good))
                centers = arr
                c0 = float(arr[0])   # 行0の同期中心
    except Exception:
        pass
    if c0 is None:
        c0 = half   # 同期が拾えないときは freq 先頭を行0の同期とみなしフォールバック

    def line_start_for(y):
        """行 y の行頭サンプル。期待位置 c0+y*period に最も近い実同期へ吸着(±0.4周期内)。"""
        expect = c0 + y * period
        anchor = expect
        if centers is not None:
            j = int(np.searchsorted(centers, expect))
            for k in (j - 1, j):
                if 0 <= k < len(centers) and abs(centers[k] - expect) < 0.4 * period:
                    if abs(centers[k] - expect) < abs(anchor - expect) or anchor == expect:
                        anchor = float(centers[k])
        return anchor - half

    def samp(line_start, offset_sec, seg_sec, count):
        """行頭サンプル line_start から offset_sec 後を先頭に、seg_sec を count 分割でサンプル。"""
        out = np.empty(count, dtype=np.float64)
        base = line_start + offset_sec * sr
        step = seg_sec * sr / count
        for k in range(count):
            c = int(base + (k + 0.5) * step)
            c = min(max(c, 0), len(freq) - 1)
            out[k] = freq[c]
        return np.clip((out - 1500.0) / 800.0 * 255.0, 0, 255).astype(np.uint8)

    img = np.zeros((h, w, 3), dtype=np.uint8)
    for y in range(h):
        ls = line_start_for(y)   # この行の先頭サンプル(行ごとリシンク済み)
        if kind == "martin":
            for ci, comp in enumerate((1, 2, 0)):   # G,B,R
                img[y, :, comp] = samp(ls, sync + ci * (porch + scan) + porch, scan, w)
        elif kind == "scottie":
            img[y, :, 1] = samp(ls, sep, scan, w)                                   # G
            img[y, :, 2] = samp(ls, sep + scan + sep, scan, w)                      # B
            img[y, :, 0] = samp(ls, sep + scan + sep + scan + sync + sep, scan, w)  # R
        else:  # robot36
            lum = samp(ls, sync + porch, yscan, w)
            img[y, :, 0] = lum; img[y, :, 1] = lum; img[y, :, 2] = lum
    return Image.fromarray(img, "RGB")


def _sstv_measure_rate(pcm_int16, sr, nominal_line_sec):
    """1200Hz同期パルスの実間隔から、送受クロック差を補正する実効サンプルレートを返す。
    CLIは自動スラント補正を持たないので、WAVのレート表記をこの値にすると時間軸が合い傾きが消える。
    測れない/範囲外は sr をそのまま返す。"""
    try:
        import numpy as np
        nom = nominal_line_sec * sr
        freq = _sstv_instfreq(pcm_int16.astype(np.float64), sr)
        idx = np.where(freq < 1350)[0]
        groups = np.split(idx, np.where(np.diff(idx) > int(0.004 * sr))[0] + 1) if idx.size else []
        centers = [float(g.mean()) for g in groups if g.size >= int(0.003 * sr)]
        diffs = np.diff(np.array(centers)) if len(centers) >= 2 else np.array([])
        good = diffs[(diffs > 0.85 * nom) & (diffs < 1.15 * nom)] if diffs.size else np.array([])
        if good.size < 5:
            return sr
        eff = sr * (float(np.median(good)) / nom)   # 実効レート = sr × (実周期/公称周期)
        if abs(eff - sr) / sr > 0.06:               # ±6%超は誤検出とみなし補正しない
            return sr
        return eff
    except Exception:
        return sr


def _sstv_decode_with_lib(pcm_int16, sr, nominal_line_sec=None):
    """sstv デコーダ(colaclanth/sstv)を *別プロセスのCLI* として呼び、PCM をデコードして PIL Image を返す。
    RTTY(minimodem)/direwolf と同じく「音声WAVを外部プログラムに渡して結果を受け取る」方式。
    import せずサブプロセス起動なので GPL が api.py 側に及ばない。CLI未導入/失敗時は None。
    nominal_line_sec を渡すと同期パルスからクロック差を測り、WAVのレート表記を補正してスラントを除去する。"""
    import wave, tempfile, os as _os, shutil
    from PIL import Image
    sstv_bin = str(_FASTAPI_DIR / "bin" / "sstv")
    if not os.path.exists(sstv_bin):
        sstv_bin = shutil.which("sstv")
    if not sstv_bin:
        print("[sstv_rx] sstv CLI not found", flush=True)
        return None
    # スラント補正: 同期パルス間隔から実効レートを求め、WAVヘッダのレートに使う(音声自体は変えない)。
    wav_rate = sr
    if nominal_line_sec:
        eff = _sstv_measure_rate(pcm_int16, sr, nominal_line_sec)
        if abs(eff - sr) > 0.5:
            wav_rate = eff
            print(f"[sstv_rx] slant-correct: sr {sr} -> {eff:.1f} ({(eff/sr-1)*1e6:.0f}ppm)", flush=True)
    d = tempfile.mkdtemp(prefix="sstv_")
    wav = _os.path.join(d, "in.wav")
    png = _os.path.join(d, "out.png")
    master = slave = None
    try:
        with wave.open(wav, "wb") as wf:
            wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(int(round(wav_rate)))
            wf.writeframes(pcm_int16.astype("<i2").tobytes())
        # sstv CLI は os.get_terminal_size() を使うため、TTYが無い(サービス/サブプロセス)と
        # OSError(Inappropriate ioctl)で落ちる。擬似端末(pty)を stdout/stderr に渡して回避する。
        import pty, threading
        master, slave = pty.openpty()
        try:
            import fcntl, termios, struct
            fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", 24, 80, 0, 0))
        except Exception:
            pass
        def _drain(fd):
            try:
                while _os.read(fd, 4096):
                    pass
            except Exception:
                pass
        th = threading.Thread(target=_drain, args=(master,), daemon=True)
        th.start()
        rc = subprocess.run([sstv_bin, "-d", wav, "-o", png],
                            stdout=slave, stderr=slave, timeout=180).returncode
        _os.close(slave); slave = None   # master 側に EOF を送って drain を終わらせる
        if rc != 0 or not os.path.exists(png):
            print(f"[sstv_rx] sstv CLI failed rc={rc}", flush=True)
            return None
        im = Image.open(png); im.load()   # ファイル削除前に読み切る
        return im
    except Exception as e:
        print(f"[sstv_rx] sstv CLI error: {e}", flush=True)
        return None
    finally:
        for fd in (slave, master):
            if fd is not None:
                try: _os.close(fd)
                except Exception: pass
        try: shutil.rmtree(d, ignore_errors=True)
        except Exception: pass


def _sstv_rx_loop():
    """共有キャプチャ(12kHz)を購読し、VIS検出→必要長の音声を集めてデコード→PNG保存。"""
    global _sstv_rx_running, _sstv_rx_status
    try:
        import numpy as np  # noqa: F401
    except ImportError:
        _sstv_rx_status = "numpy未導入"; _sstv_rx_running = False; return
    _ensure_sstv()
    _SSTV_RX_DIR.mkdir(parents=True, exist_ok=True)
    import numpy as np
    _load_alsa_devices()   # キャプチャのALSAデバイスを反映(FT8/RTTYと同様。未設定だと音が取れない)
    _mgr_sub.ensure(str(_SSTV_RX_RATE))
    sid, q = _mgr_sub.subscribe(maxsize=1024)
    buf = np.zeros(0, dtype=np.int16)
    maxbuf = _SSTV_RX_RATE * 8   # VIS探索用の先読みバッファ(8秒)
    last_scan = 0.0
    chunk_count = 0
    _sstv_rx_status = "listening(音声待ち)"
    err_count = 0
    last_err = ""
    cap_fail = 0
    while _sstv_rx_running:
        try:
            try:
                chunk = q.get(timeout=1.0)
            except Exception:
                # 音声チャンクが来ない=キャプチャ未供給。プロセスの生死を状態に反映。
                alive = bool(_mgr_sub.proc and _mgr_sub.proc.poll() is None)
                if alive:
                    cap_fail = 0
                    _sstv_rx_status = f"listening(音声待ち chunks={chunk_count})"
                else:
                    # proc が None/死亡 = キャプチャ起動できず。連打で残留した arecord/sox が
                    # デバイスを占有している場合があるので、数回失敗したら掃除してから起動し直す。
                    cap_fail += 1
                    _sstv_rx_status = f"listening(キャプチャ再起動 {cap_fail})"
                    try: _mgr_sub.unsubscribe(sid)
                    except Exception: pass
                    if cap_fail >= 3:
                        subprocess.run(["pkill", "-9", "arecord"], capture_output=True)
                        subprocess.run(["pkill", "-9", "sox"], capture_output=True)
                        time.sleep(0.5)
                        cap_fail = 0
                    _load_alsa_devices()
                    try:
                        _mgr_sub.ensure(str(_SSTV_RX_RATE)); sid, q = _mgr_sub.subscribe(maxsize=1024)
                    except Exception:
                        pass
                continue
            chunk_count += 1
            arr = np.frombuffer(chunk, dtype=np.int16)
            buf = np.concatenate([buf, arr])
            # 音声レベル(RMS)。音がPiに届いているかの判別用にステータスへ出す。
            rms = int(np.sqrt(np.mean(arr.astype(np.float64) ** 2))) if arr.size else 0
            if len(buf) <= maxbuf:
                _sstv_rx_status = f"listening lvl={rms}"
                continue
            now = time.time()
            if now - last_scan < 1.5:        # VIS探索(重い)は1.5秒ごとに間引く
                buf = buf[-maxbuf:]; continue
            last_scan = now
            try:
                freq = _sstv_instfreq(buf.astype(np.float64), _SSTV_RX_RATE)
                hit = _sstv_find_vis(freq, _SSTV_RX_RATE)
                # 復調した周波数範囲(診断用): SSTV音(1100-2300Hz)がちゃんと復調できているか
                fin = freq[(freq > 500) & (freq < 3000)]
                if fin.size:
                    f10, f50, f90 = (int(np.percentile(fin, 10)), int(np.percentile(fin, 50)), int(np.percentile(fin, 90)))
                else:
                    f10 = f50 = f90 = 0
            except Exception as e:
                print(f"[sstv_rx] vis scan error: {e}", flush=True)
                _sstv_rx_status = f"listening lvl={rms}"; buf = buf[-maxbuf:]; continue
            if hit:
                vis, ds = hit
                name, w, h, kind, px = _SSTV_VIS[vis]
                # 実際の1行所要時間からモードごとの画像長を算出(固定0.5s/行だとM2等で大きくズレる)。
                if kind == "martin":
                    line_sec = 0.004862 + 3 * (0.000572 + px * w)
                elif kind == "scottie":
                    line_sec = 0.009 + 3 * 0.0015 + 3 * (px * w)
                else:  # robot36
                    line_sec = 0.009 + 0.003 + 0.088 + 0.0075 + 0.044
                img_sec = line_sec * h + 2.0           # 表示%用(検出モードの目安)
                # 収集長を検出モードに依存させない: VIS判定は誤りうる(M2(0x28)を1ビット誤読して
                # Robot36(0x08)にする等)。モードで短く切ると実体が長いモードで画像が半分になる。
                # そこで最長モード(MartinM1 ~114s)分まで確保し、送信が途切れ(無音)たら早期終了する。
                # 真のモード判定と復号は CLI が行うので、多めに集めても問題ない。
                MAX_IMG_SEC = 118.0
                need = ds + int(MAX_IMG_SEC * _SSTV_RX_RATE)
                disp_need = ds + int(img_sec * _SSTV_RX_RATE)   # 進捗%の分母(目安)
                _sstv_rx_status = f"decoding {name} 0%"
                stall = 0; quiet = 0
                while _sstv_rx_running and len(buf) < need:
                    try:
                        arr2 = np.frombuffer(q.get(timeout=2.0), dtype=np.int16)
                        buf = np.concatenate([buf, arr2])
                        stall = 0
                        r2 = np.sqrt(np.mean(arr2.astype(np.float64) ** 2)) if arr2.size else 0.0
                        if r2 < 300:                    # 無信号レベル=送信終了の可能性
                            quiet += int(arr2.size)
                            if quiet > 3 * _SSTV_RX_RATE:   # 3秒連続で無音→送信終了とみなし収集終了
                                break
                        else:
                            quiet = 0
                        pct = int(100 * len(buf) / max(disp_need, 1))
                        _sstv_rx_status = f"decoding {name} {min(pct, 99)}%"
                    except Exception:
                        # 一時的な途切れでは打ち切らない。10秒(=5回)途絶えたらキャプチャ停止とみなす。
                        stall += 1
                        if stall >= 5:
                            break
                try:
                    # sstv ライブラリ(VIS自動判定)で buf 全体をデコード。CLIの行ごと同期補正は
                    # 約1%までしか効かず2%以上のクロック差で傾くため、line_sec を渡して同期パルス
                    # 間隔から実効レートを測りWAVレート表記を補正する(大きなずれのスラントを除去)。
                    im = _sstv_decode_with_lib(buf, _SSTV_RX_RATE, nominal_line_sec=line_sec)
                    how = "lib"
                    if im is None:   # ライブラリ不可/失敗 → 自作デコーダにフォールバック
                        freq = _sstv_instfreq(buf.astype(np.float64), _SSTV_RX_RATE)
                        im = _sstv_decode_image(freq[ds:], _SSTV_RX_RATE, vis)
                        how = "builtin"
                    ts = time.strftime("%Y%m%d_%H%M%S")
                    im.save(str(_SSTV_RX_DIR / f"{ts}_{name}_{how}.png"))
                    print(f"[sstv_rx] decoded {name} ({how}) -> {ts}", flush=True)
                    _sstv_rx_status = f"decoded {name} ({how})"
                except Exception as e:
                    print(f"[sstv_rx] decode error: {e}", flush=True)
                    _sstv_rx_status = f"decode error: {type(e).__name__}"
                buf = np.zeros(0, dtype=np.int16)
            else:
                _sstv_rx_status = f"listening lvl={rms} f={f10}/{f50}/{f90}"
                buf = buf[-maxbuf:]   # VIS未検出 → 直近だけ残す
            err_count = 0
        except Exception as e:
            # 1回の例外ではループを止めず回復。連続多発時のみ停止(理由を状態へ)。
            err_count += 1
            last_err = f"{type(e).__name__}: {e}"
            print(f"[sstv_rx] iter error ({err_count}): {last_err}", flush=True)
            _sstv_rx_status = f"listening(回復{err_count}: {type(e).__name__})"
            try:
                buf = buf[-maxbuf:]
            except Exception:
                buf = np.zeros(0, dtype=np.int16)
            if err_count >= 50:
                _sstv_rx_status = f"stopped(連続エラー: {last_err})"
                break
            time.sleep(0.1)
            continue
    try: _mgr_sub.unsubscribe(sid)
    except Exception: pass
    _sstv_rx_running = False
    if not _sstv_rx_status.startswith("stopped"):
        _sstv_rx_status = "stopped"


@app.post("/radio/sstv/rx/start")
def sstv_rx_start():
    """SSTV受信デコードを開始(共有キャプチャを購読)。リグはFM/SSBにしておくこと。
    連打(同時POST)で複数スレッドが立たないよう lock + スレッド生存チェックで冪等化。"""
    global _sstv_rx_running, _sstv_rx_thread
    with _sstv_rx_lock:
        if _sstv_rx_running and _sstv_rx_thread is not None and _sstv_rx_thread.is_alive():
            return {"status": "ok", "already": True}
        _sstv_rx_running = True
        _sstv_rx_thread = threading.Thread(target=_sstv_rx_loop, daemon=True)
        _sstv_rx_thread.start()
    return {"status": "ok"}


@app.post("/radio/sstv/rx/stop")
def sstv_rx_stop():
    global _sstv_rx_running
    _sstv_rx_running = False
    return {"status": "ok"}


@app.get("/radio/sstv/rx/list")
def sstv_rx_list():
    """受信済み画像の一覧(新しい順)。"""
    _SSTV_RX_DIR.mkdir(parents=True, exist_ok=True)
    items = []
    for p in sorted(_SSTV_RX_DIR.glob("*.png"), key=lambda x: x.stat().st_mtime, reverse=True)[:100]:
        items.append({"name": p.name, "size": p.stat().st_size, "mtime": int(p.stat().st_mtime)})
    return {"status": _sstv_rx_status, "running": _sstv_rx_running, "images": items}


@app.get("/radio/sstv/rx/image")
def sstv_rx_image(name: str):
    """受信画像PNGを返す。"""
    from fastapi.responses import Response
    # パストラバーサル防止: ファイル名のみ許可
    if "/" in name or ".." in name or not name.endswith(".png"):
        raise HTTPException(status_code=400, detail="bad name")
    p = _SSTV_RX_DIR / name
    if not p.exists():
        raise HTTPException(status_code=404, detail="not found")
    return Response(content=p.read_bytes(), media_type="image/png")


@app.get("/radio/rtty/rx")
def rtty_rx(mark: int = 2125, space: int = 2295, baud: float = 45.45, audio: int = 0):
    """RTTY受信: 共有キャプチャ(_mgr_sub)の PCM を minimodem --rx(Baudot) に WAV で供給して復調し、
    復号テキストと、ウォーターフォール用スペクトラム(1200-3200Hz/20Hz刻み=101点)を
    SSE(text/event-stream)で配信する。FT8 と同じ _mgr_sub を使うので ALSA デバイス競合(busy)が起きない。
    audio=1 のときは受信音 PCM も {"type":"audio","pcm":base64,"rate":RATE} で配信(スマホ再生用)。
    イベント: {"type":"text","text":".."} / {"type":"spectrum","pows":[..101..]} / {"type":"audio",..}"""
    import shutil
    if not shutil.which("minimodem"):
        _ensure_minimodem()
    try:
        import numpy as np
    except Exception:
        np = None
    RATE = 12000  # _mgr_sub の既定レート(FT8と共通)

    def gen():
        _mgr_sub.ensure(str(RATE))
        sid, q = _mgr_sub.subscribe(maxsize=256)
        # PCM(raw) → sox で WAV化 → minimodem。手組みWAVヘッダは libsndfile が嫌うことがあるため、
        # 手動テストで実績のある「WAVパイプ→minimodem -f -」を sox で再現する。
        sox = subprocess.Popen(
            ["sox", "-t", "raw", "-r", str(RATE), "-e", "signed", "-b", "16", "-c", "1",
             "-", "-t", "wav", "-"],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        mm = subprocess.Popen(
            ["minimodem", "--rx", "--baudot", "-q",
             "-M", str(int(mark)), "-S", str(int(space)), "-f", "-", str(float(baud))],
            stdin=sox.stdout, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        try: sox.stdout.close()  # minimodem がread端を所有
        except Exception: pass
        out_q = _queue.Queue(maxsize=256)
        stop = threading.Event()

        def read_text():
            try:
                for raw in iter(mm.stdout.readline, b""):
                    if stop.is_set():
                        break
                    t = raw.decode("utf-8", "replace")
                    if t:
                        try: out_q.put(("text", t), timeout=1)
                        except Exception: pass
            except Exception:
                pass

        def pump():
            acc = bytearray()
            WIN = 512; HOP = 256          # 50%オーバーラップ → 12000/256≈47行/秒(密なウォーターフォール)
            win_fn = np.hanning(WIN) if np is not None else None
            while not stop.is_set():
                try:
                    chunk = q.get(timeout=0.5)
                except _queue.Empty:
                    if _mgr_sub.proc and _mgr_sub.proc.poll() is not None:
                        break
                    continue
                try:
                    sox.stdin.write(chunk); sox.stdin.flush()
                except Exception:
                    break
                if audio:
                    try: out_q.put(("audio", bytes(chunk)), timeout=0.05)
                    except Exception: pass
                if np is not None:
                    acc.extend(chunk)
                    while len(acc) >= WIN * 2:
                        frame = np.frombuffer(bytes(acc[:WIN * 2]), dtype="<i2").astype(np.float64)
                        del acc[:HOP * 2]   # オーバーラップ: hop ぶんだけ進める
                        mag = np.abs(np.fft.rfft(frame * win_fn))
                        pows = []
                        for f in range(1200, 3201, 20):
                            idx = int(round(f * WIN / RATE))
                            if idx >= len(mag): idx = len(mag) - 1
                            pows.append(round(float(mag[idx]), 1))
                        try: out_q.put(("spectrum", pows), timeout=0.1)
                        except Exception: pass
            try: out_q.put(("end", None), timeout=0.5)
            except Exception: pass

        threading.Thread(target=read_text, daemon=True).start()
        threading.Thread(target=pump, daemon=True).start()
        try:
            while True:
                typ, val = out_q.get()
                if typ == "end":
                    break
                if typ == "text":
                    yield f"data: {_json.dumps({'type': 'text', 'text': val})}\n\n"
                elif typ == "audio":
                    import base64
                    yield f"data: {_json.dumps({'type': 'audio', 'rate': RATE, 'pcm': base64.b64encode(val).decode('ascii')})}\n\n"
                else:
                    yield f"data: {_json.dumps({'type': 'spectrum', 'pows': val})}\n\n"
        finally:
            stop.set()
            # 確実に後始末する。terminate(SIGTERM)だと死に損ねた sox/minimodem が
            # セッションごとに残留・蓄積していたため、SIGKILL + wait() で刈り取る。
            try: sox.stdin.close()
            except Exception: pass
            for _p in (mm, sox):   # minimodem→sox の順に kill
                try: _p.kill()
                except Exception: pass
                try: _p.wait(timeout=1)
                except Exception: pass
            _mgr_sub.unsubscribe(sid)
    return StreamingResponse(gen(), media_type="text/event-stream")


@app.post("/ft8/start")
async def ft8_start():
    global _ft8_decode_running, _ft8_decode_thread
    # v3.32 fix: clear any leftover TX/CQ/QSO state on every start so opening the FT8 screen
    # never resumes a stale auto-CQ from a previous session. _auto_tx/_cq_auto/_qso are
    # process-global dicts that persist while the Pi keeps running, so a CQ-AUTO left on would
    # otherwise keep transmitting whenever the screen is reopened ("CQ fires by itself").
    _auto_tx["active"] = False
    _cq_auto["active"] = False
    _qso["active"] = False
    if _ft8_decode_running:
        return {"status": "already_running"}
    _ft8_decode_running = True
    _ft8_decode_thread = threading.Thread(target=_ft8_decode_loop, daemon=True)
    _ft8_decode_thread.start()
    return {"status": "started"}


@app.post("/ft8/stop")
async def ft8_stop():
    global _ft8_decode_running
    _ft8_decode_running = False
    return {"status": "stopped"}


@app.post("/ft8/set_depth")
async def ft8_set_depth(depth: int = Query(...), request: Request = None):
    global _ft8_decode_depth
    if depth not in (1, 2, 3):
        raise HTTPException(status_code=400, detail="depth must be 1, 2, or 3")
    _ft8_decode_depth = depth
    return {"depth": depth}


@app.post("/ft8/set_two_stage")
async def ft8_set_two_stage(on: bool = Query(...), request: Request = None):
    """2段デコード(早期=返信用/フル=表示用)の ON/OFF。多局時の返信1サイクル遅延対策。"""
    global _ft8_two_stage
    _ft8_two_stage = on
    print(f"[ft8] two-stage decode = {on}")
    return {"two_stage": on}


@app.post("/ft8/set_ft4")
async def ft8_set_ft4(is_ft4: bool = Query(...), request: Request = None):
    global _ft8_is_ft4
    _ft8_is_ft4 = is_ft4
    print(f"[ft8] FT4 mode = {is_ft4}")
    return {"is_ft4": is_ft4}


@app.post("/ft8/pskreporter")
async def ft8_pskreporter(request: Request):
    """PSKReporter 受信レポート送信の ON/OFF と自局情報(コール/グリッド)設定。"""
    data = await request.json()
    _pskr.configure(bool(data.get("enabled", False)), data.get("call", ""), data.get("grid", ""))
    print(f"[pskr] configure enabled={_pskr.enabled} call={_pskr.call} grid={_pskr.grid}")
    return {"status": "ok", "enabled": _pskr.enabled}


@app.post("/ft8/set_tx_gain")
async def ft8_set_tx_gain(gain: float = Query(...), request: Request = None):
    global _ft8_tx_gain
    _ft8_tx_gain = max(0.1, min(2.0, gain))
    print(f"[ft8] TX gain = {_ft8_tx_gain:.2f}")
    return {"tx_gain": _ft8_tx_gain}


@app.post("/ft8/set_decode_filter")
async def ft8_set_decode_filter(request: Request):
    global _ft8_decode_filter
    data = await request.json()
    freqs = data.get("freqs", [])
    range_hz = int(data.get("range", 60))
    _ft8_decode_filter = [(int(f), range_hz) for f in freqs] if freqs else []
    return {"ok": True, "filter": _ft8_decode_filter}


@app.get("/ft8/all_txt")
async def ft8_all_txt(request: Request, lines: int = Query(default=0, ge=0)):
    """ALL.TXT の内容をプレーンテキストで返す (lines=0: 全件, lines>0: 末尾N行)"""
    qkey = request.query_params.get("api_key", "")
    hkey = request.headers.get("X-API-Key", "")
    if API_KEY and not (hmac.compare_digest(qkey or "", API_KEY) or hmac.compare_digest(hkey or "", API_KEY)):
        raise HTTPException(status_code=403, detail="Forbidden")
    p = Path(_ALL_TXT_PATH)
    if not p.exists():
        return PlainTextResponse("")
    text = p.read_text(encoding="utf-8", errors="replace")
    if lines > 0:
        text = "".join(text.splitlines(keepends=True)[-lines:])
    return PlainTextResponse(text)


@app.delete("/ft8/all_txt")
async def ft8_clear_all_txt(request: Request):
    """ALL.TXT を削除 (クリア)"""
    qkey = request.query_params.get("api_key", "")
    hkey = request.headers.get("X-API-Key", "")
    if API_KEY and not (hmac.compare_digest(qkey or "", API_KEY) or hmac.compare_digest(hkey or "", API_KEY)):
        raise HTTPException(status_code=403, detail="Forbidden")
    Path(_ALL_TXT_PATH).unlink(missing_ok=True)
    return {"status": "ok"}


@app.get("/ft8/decode_debug")
async def ft8_decode_debug(request: Request):
    """最後の jt9 デコード結果（stdout/stderr）を返す。デバッグ用。"""
    qkey = request.query_params.get("api_key", "")
    hkey = request.headers.get("X-API-Key", "")
    if API_KEY and not (hmac.compare_digest(qkey or "", API_KEY) or hmac.compare_digest(hkey or "", API_KEY)):
        raise HTTPException(status_code=403, detail="Forbidden")
    return _ft8_last_decode_info


@app.get("/ft8/rx_msgs", dependencies=[])
async def ft8_rx_msgs(request: Request):
    """FT8デコード結果を SSE ストリームで配信する。"""
    qkey = request.query_params.get("api_key", "")
    hkey = request.headers.get("X-API-Key", "")
    if API_KEY and not (hmac.compare_digest(qkey or "", API_KEY) or hmac.compare_digest(hkey or "", API_KEY)):
        raise HTTPException(status_code=403, detail="Forbidden")

    q: _queue.Queue = _queue.Queue(maxsize=32)
    with _ft8_rx_clients_lock:
        _ft8_rx_clients.append(q)

    async def _stream():
        try:
            yield b"data: {\"type\":\"connected\"}\n\n"
            # 再接続時: 進行中のQSOがあれば即送信してAndroid側のtxStateを復元
            if _qso.get("active"):
                import json as _json
                _state_map = {1: "pending", 3: "got_report", 5: "sending_73"}
                _qs = _state_map.get(_qso.get("state", 0), "pending")
                _qso_evt = _json.dumps({
                    "type": "qso_state", "state": _qs,
                    "dx_call": _qso.get("dx_call", ""),
                    "msg": _qso.get("next_msg", ""),
                    "tx_mode": _qso.get("tx_mode", ""),
                })
                yield f"data: {_qso_evt}\n\n".encode()
            loop = asyncio.get_running_loop()
            while True:
                try:
                    msg = await loop.run_in_executor(None, lambda: q.get(timeout=20.0))
                    yield msg
                except _queue.Empty:
                    yield b": keepalive\n\n"
        except (asyncio.CancelledError, GeneratorExit, BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            print(f"[ft8_rx_msgs] stream error: {e}")
        finally:
            with _ft8_rx_clients_lock:
                try:
                    _ft8_rx_clients.remove(q)
                except ValueError:
                    pass
                if not _ft8_rx_clients and _ft8_tx_active:
                    _auto_tx["active"] = False
                    p = _ft8_tx_aplay_proc
                    if p is not None:
                        try: p.kill()
                        except Exception: pass
                    print("[ft8_rx_msgs] last client disconnected — TX stopped")

    return StreamingResponse(
        _stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ─── FT8 ウォーターフォール用スペクトラム SSE ─────────────────────────────
_spectrum_clients:     list = []
_spectrum_clients_lock = threading.Lock()
_spectrum_running      = False
_spectrum_thread: threading.Thread | None = None

SPECTRUM_FFT   = 2048
SPECTRUM_BINS  = 256          # 出力ビン数 (0〜3 kHz を 256 分割)
SPECTRUM_HZ    = 4            # 毎秒更新回数
SPECTRUM_CHUNK = FT8_SAMPLE_RATE // SPECTRUM_HZ  # 3000 サンプル/フレーム


def _spectrum_broadcast(bins: list, extra: dict | None = None):
    payload: dict = {"bins": bins}
    if extra:
        payload.update(extra)
    msg = ("data: " + _json.dumps(payload) + "\n\n").encode()
    with _spectrum_clients_lock:
        for q in list(_spectrum_clients):
            if q.full():
                try: q.get_nowait()
                except _queue.Empty: pass
            try: q.put_nowait(msg)
            except _queue.Full: pass


def _spectrum_loop():
    global _spectrum_running
    try:
        import numpy as np
    except ImportError:
        print("[spectrum] numpy not available — pip install numpy")
        _spectrum_running = False
        return
    print("[spectrum] started")
    _mgr_sub.ensure("12000")
    sid, q = _mgr_sub.subscribe(maxsize=128)
    buf          = bytearray()
    need         = SPECTRUM_CHUNK * 2  # 16-bit PCM
    hann         = np.hanning(SPECTRUM_FFT).astype(np.float32)
    last_period  = -1
    try:
        while _spectrum_running:
            try:
                chunk = q.get(timeout=0.5)
            except _queue.Empty:
                continue
            buf.extend(chunk)
            while len(buf) >= need:
                frame, buf = buf[:need], buf[need:]
                pcm = np.frombuffer(bytes(frame), dtype=np.int16).astype(np.float32)
                pcm = np.pad(pcm, (0, max(0, SPECTRUM_FFT - len(pcm))))[:SPECTRUM_FFT]
                mag = np.abs(np.fft.rfft(pcm * hann))
                # 12 kHz / 2048 * 512 = 3000 Hz → bins 0..511
                mag = mag[:512]
                # 512 → 256 bins (max pool)
                mag = mag.reshape(SPECTRUM_BINS, 2).max(axis=1)
                # dB 変換・自動ノイズフロア正規化
                # 20%ile をノイズフロア(=黒)、その 30dB 上を赤にすることで
                # 絶対音量レベルに依存しない表示を実現する
                db    = 20.0 * np.log10(mag + 1.0)
                floor = float(np.percentile(db, 20))
                norm  = np.clip((db - floor) / 30.0 * 255.0, 0, 255).astype(np.uint8)
                # FT8/FT4ピリオド境界をスペクトラムフレームに埋め込む（横線同期用）
                # チャンク末尾ではなく開始時刻で判定（1チャンク=0.25秒分を補正）
                audio_t  = time.time() - SPECTRUM_CHUNK / FT8_SAMPLE_RATE
                utc_s    = int(audio_t) % 60
                if _ft8_is_ft4:
                    period_n = int(audio_t / 7.5) % 8
                else:
                    period_n = (utc_s // 15) % 4
                extra    = None
                if period_n != last_period:
                    last_period = period_n
                    extra = {"new_period": True, "period": period_n, "utc_sec": utc_s}
                _spectrum_broadcast(norm.tolist(), extra)
    finally:
        _mgr_sub.unsubscribe(sid)
        print("[spectrum] stopped")


@app.get("/ft8/spectrum")
async def ft8_spectrum(request: Request):
    """ウォーターフォール用 FFT スペクトラムを SSE ストリームで配信する。"""
    global _spectrum_thread, _spectrum_running
    qkey = request.query_params.get("api_key", "")
    hkey = request.headers.get("X-API-Key", "")
    if API_KEY and not (hmac.compare_digest(qkey or "", API_KEY) or hmac.compare_digest(hkey or "", API_KEY)):
        raise HTTPException(status_code=403, detail="Forbidden")

    q: _queue.Queue = _queue.Queue(maxsize=8)
    with _spectrum_clients_lock:
        _spectrum_clients.append(q)

    if not _spectrum_running or _spectrum_thread is None or not _spectrum_thread.is_alive():
        _spectrum_running = True
        _spectrum_thread = threading.Thread(target=_spectrum_loop, daemon=True, name="ft8_spectrum")
        _spectrum_thread.start()

    async def _stream():
        try:
            yield b"data: {\"type\":\"spectrum_start\"}\n\n"
            loop = asyncio.get_running_loop()
            while True:
                try:
                    msg = await loop.run_in_executor(None, lambda: q.get(timeout=2.0))
                    yield msg
                except _queue.Empty:
                    yield b": keepalive\n\n"
        except (asyncio.CancelledError, GeneratorExit, BrokenPipeError, ConnectionResetError):
            pass
        finally:
            with _spectrum_clients_lock:
                try: _spectrum_clients.remove(q)
                except ValueError: pass
            if not _spectrum_clients:
                _spectrum_running = False

    return StreamingResponse(
        _stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.get("/devices")
def list_devices():
    usb = glob.glob("/dev/ttyUSB*")
    acm = glob.glob("/dev/ttyACM*")
    serial = sorted([os.path.basename(d) for d in usb + acm])
    audio = []
    try:
        result = subprocess.run(["arecord", "-L"], capture_output=True, text=True)
        lines = result.stdout.splitlines()
        current_id = None
        for line in lines:
            if not line.strip():
                continue
            if not line.startswith(" "):
                current_id = line.strip()
            else:
                if current_id:
                    audio.append({"id": current_id, "label": f"{line.strip()} ({current_id})"})
                    current_id = None
    except Exception as e:
        print(f"arecord error: {e}")
    return {"serial": serial, "audio": audio}


@app.get("/rigs")
def list_rigs():
    result = subprocess.run(["rigctl", "-l"], capture_output=True, text=True)
    rigs = []
    for line in result.stdout.splitlines():
        parts = line.strip().split()
        if len(parts) >= 3 and parts[0].isdigit():
            rigs.append({"id": int(parts[0]), "name": f"{parts[1]} {parts[2]}"})
    return {"rigs": rigs}


@app.get("/radio/open")
def open_radio(model: int, cat: str, baud: int = 38400, audio: str = "", ptt: str = "", ptt_type: str = "RTS"):
    global current_model, current_cat, current_baud, current_ptt, current_ptt_type, poll_started, rig_cycle_idx, current_mode_list
    global _rig_open_started
    # パストラバーサル対策: /dev/ 配下の正当なデバイス名のみ許可する
    cat = _validate_dev_name(cat, "cat")
    ptt = _validate_dev_name(ptt, "ptt")
    _eff_ptt_type = _resolve_ptt_type(model, cat, ptt_type)
    # ★ 既に同一設定の rigctld が稼働・応答中なら、再起動しない(セッション再利用)。
    #   接続操作のたびに rigctld を再起動するとシリアルポートが再オープン(DTR/RTS トグル)され、
    #   FT-991 等の一部機種は接続直後に CAT が約30〜40秒完全無応答になる(「RigDisconnected」点滅)。
    #   同じリグに繋ぎ直すだけなら、動作中のセッションをそのまま使えば無応答は起きない。
    _same_cfg = (current_model == model and current_cat == cat and current_baud == baud
                 and current_ptt == ptt and current_ptt_type == _eff_ptt_type)
    _rig_alive = (rigctld_process is not None and rigctld_process.poll() is None and rigctl_alive())
    current_model = model
    current_cat = cat
    current_baud = baud
    current_ptt = ptt
    # Store effective PTT type (mirrors start_rigctld's Icom USB-to-RIG conversion)
    current_ptt_type = _eff_ptt_type
    # 再起動後も rigctld の自動復旧が効くように選択内容を残す
    _save_rig_selection()
    # ★ VFO切替サイクルの想定状態は接続のたびにリセット(前回の状態は無効になるため)
    rig_cycle_idx = 0
    # ★ モード一覧も機種が変わるたびにリセット(前回接続機種のリストが一瞬残らないように)
    current_mode_list = None
    _rig_open_started = time.time()  # 再接続でも rig_ok の接続中猶予を起点化(FT-991の接続直後対策)
    if _same_cfg and _rig_alive:
        # 再利用: rigctld を再起動せず、ポーリングだけ確実に有効化する。
        # ★ VFO/モード判定(_detect_vfo_mode=\dump_caps)は再実行しない。同一リグでは既に判定済みで、
        #   再接続のたびに dump_caps を送ると FT-991 等が CAT を一時的に詰まらせ無応答になるため。
        print(f"[{_ts()}] [open_radio] same rig already running — reuse session (no rigctld restart, no re-probe)", flush=True)
        if not poll_started:
            threading.Thread(target=poll_rig, daemon=True).start()
            threading.Thread(target=poll_signal, daemon=True).start()
            poll_started = True
        return {"status": "ok", "reused": True}
    _rig_open_started = time.time()  # rig_ok の接続中猶予の起点(start_rigctldより前に立てる)
    start_rigctld(model, cat, baud, ptt, ptt_type)
    # ★ 機種選択・接続のたびにVFO A/B か MAIN/SUB かを判定し直す
    threading.Thread(target=_detect_vfo_mode, daemon=True).start()
    if not poll_started:
        threading.Thread(target=poll_rig, daemon=True).start()
        threading.Thread(target=poll_signal, daemon=True).start()
        poll_started = True
    return {"status": "ok"}


@app.get("/radio/vfo_mode")
def get_vfo_mode():
    return {"mode": rig_vfo_mode or "unknown"}


def _normalize_vfo_label(raw: str, mode: str) -> str:
    """Hamlibの生VFO文字列("VFOA"/"Main"等)を、M5に表示する短いラベルに正規化する。"""
    up = (raw or "").upper()
    if mode == "mainsub":
        return "Sub" if "SUB" in up else "Main"
    return "B" if ("VFOB" in up or up == "B") else "A"


# ★ MAIN/SUB機(2波同時受信機)向け3状態サイクル。
#   Main(シングル表示) -> M/S(デュアル表示,Main動作) -> S/M(デュアル表示,Sub動作)
#   -> Main(シングル表示) ...
#   実機で確認した制約:
#     ・シングル表示のままVFO切替(VSコマンド)を送っても実際には反映されない
#       (フリーズはしないが無視される)。デュアル表示中に送った時だけ確実に効く。
#     ・「シングル表示でSubのみ動作」という組み合わせ自体は無線機を直接操作すれば
#       可能だが、CAT経由では安定して到達できなかったため、このサイクルには含めない。
#   そのため全ての切替は必ずデュアル表示(FR00)経由で行い、Main側に戻る時だけ
#   最後にシングル表示(FR01)に戻す。
# 0:Main(single) 1:M/S(dual,Main動作) 2:S/M(dual,Sub動作)
_VFO_CYCLE_LABELS = ["Main", "M/S", "S/M"]
rig_cycle_idx = 0


@app.get("/radio/vfo_current")
def get_vfo_current():
    """接続直後などトグルしていない時点での、現在のVFO側をM5が知るためのエンドポイント。
    ★ rigctl_cmd()自体が内部でrig_lockを取得するため、ここで外側からも
      with rig_lock:すると同一スレッドでの二重ロックとなり永久デッドロックする
      (このバグでpoll_rig等の他のrig_lock使用箇所も巻き込んで全て停止していた)。"""
    mode = rig_vfo_mode or "ab"
    if mode == "mainsub":
        return {"mode": mode, "side": _VFO_CYCLE_LABELS[rig_cycle_idx]}
    # ★ FT-991 は Hamlib の get_vfo('v')コマンドを送ると、接続直後に CAT が約30秒間完全に詰まり
    #   「RigDisconnected」が点滅する(実機で確認)。FT-991 では 'v' を送らず既定の A を返す
    #   (リグに一切触れない)。VFO側表示はトグル時に別途更新される。
    #   ※ FTX-1 等の Main/Sub 機は上の mode=="mainsub" 分岐で先に処理されるため、ここには来ない。
    if _is_ft991():
        return {"mode": mode, "side": "A", "raw": ""}
    cur = rigctl_cmd("v").strip()
    return {"mode": mode, "side": _normalize_vfo_label(cur, mode), "raw": cur}


@app.post("/radio/vfo_toggle")
def toggle_vfo():
    global rig_cycle_idx
    mode = rig_vfo_mode or "ab"

    # ★ ボタン連打対策: 前回のトグル要求がCAT送受信を含めて完全に終わる前に次の要求が
    #   来ると、rig_cycle_idxの読み取り→書き込みが複数リクエストにまたがって重なり、
    #   M5の表示と実機の状態がズレる不具合があった。非ブロッキングでロックを試み、
    #   既に処理中なら新しい要求はCATコマンドを一切送らずその場で拒否する
    #   (キューイングして後で処理すると、連打分が後からまとめて発火して余計に混乱するため)。
    if not vfo_toggle_lock.acquire(blocking=False):
        raise HTTPException(status_code=409, detail="VFO toggle already in progress")

    try:
        if mode != "mainsub":
            # A/B機種はシンプルな2状態トグル(フリーズ問題が確認されていないため現状維持)
            cur = rigctl_cmd("v").strip()
            cur_up = cur.upper()
            target = "VFOB" if ("VFOA" in cur_up or cur_up == "A") else "VFOA"
            raw = rigctl_cmd(f"V {target}")
            side = _normalize_vfo_label(target, mode)
            print(f"[vfo_toggle] {cur} -> {target} ('{raw.strip()}')", flush=True)
            return {"mode": mode, "from": cur, "to": target, "side": side}

        # ★ HamlibのVFO抽象化コマンド("V"/"v")はこの機種のバックエンドで正しく動作しない
        #   ことが実機で確認された(M5表示は切り替わるが無線機側は変わらない)。代わりに
        #   CATリファレンスで確認済みの生コマンド"VS"(VFO SELECT: 0=Main動作 1=Sub動作)を
        #   直接送る。EX/FA/FBと同様、応答が返らないコマンドのため_rig_send_no_replyを使う。
        #
        # ★ 実機で確認: VSコマンドはシングル表示のままだと(フリーズはしないが)実際には
        #   反映されない。デュアル表示中に送った時だけ確実に効く。そのため、どの遷移でも
        #   必ず一旦デュアル表示(FR00)にしてから切り替え、目標がシングル表示の状態(Main
        #   単独)ならその後シングル(FR01)に戻す、という手順で統一する。
        #
        # ★ next_idxの計算・CAT送信・rig_cycle_idxへの書き戻しを1回のrig_lockでまとめて
        #   保持する。分割していた頃はコマンド間のtime.sleep(0.3)の間にロックが解放され、
        #   poll_rig/poll_signalのバックグラウンドポーリング(f/m/t/l STRENGTH等、約1秒
        #   ごと)がその隙間に割り込んでCATを送ってしまい、無線機側のFR00→VS→FR01という
        #   状態遷移が想定通りに進まなかった。
        with rig_lock:
            next_idx = (rig_cycle_idx + 1) % 3
            target_main_active = next_idx in (0, 1)   # Main動作: 0=Main(single), 1=M/S(dual)
            target_single = next_idx == 0             # シングル表示に戻す: 0=Main のみ

            _rig_send_no_reply("w FR00;")
            time.sleep(0.3)
            _rig_send_no_reply(f"w VS{0 if target_main_active else 1};")
            if target_single:
                time.sleep(0.3)
                _rig_send_no_reply("w FR01;")

            rig_cycle_idx = next_idx

        label = _VFO_CYCLE_LABELS[rig_cycle_idx]
        print(f"[vfo_toggle] cycle -> {label}", flush=True)
        return {"mode": mode, "side": label}
    finally:
        vfo_toggle_lock.release()


@app.get("/radio/status")
def radio_status():
    # ★ rig_ok: リグ(rigctld経由)と通信できているか。M5側で切断警告(⚠)表示に使う。
    #   APRS送信中はpoll_rigが問い合わせを止めているため正常扱いにする。
    #   接続操作(/radio/open)直後は、リグから最初の正常応答が来るまで(最長20秒)正常扱いにする。
    now = time.time()
    # FT-991 は接続直後(~45秒)に CAT が断続的に詰まり自己復帰する既知のクセがあるため、その間は
    # 応答有無に関わらず「接続中」とみなし「RigDisconnected」を出さない(他機種は従来どおりの判定)。
    if _is_ft991() and (now - _rig_open_started < 45.0):
        connecting = True
    else:
        connecting = (last_rig_ok < _rig_open_started) and (now - _rig_open_started < _RIG_OPEN_GRACE_SEC)
    rig_ok = bool(tx_in_progress) or connecting or (now - last_rig_ok < 9.0)
    return {**radio_cache, "tx_in_progress": tx_in_progress, "rig_ok": rig_ok, "api_version": API_VERSION, "ft8_decode_running": _ft8_decode_running}


@app.get("/radio/caps")
def radio_caps():
    # current_mode_listはopen_radio後にバックグラウンドでdump_capsから検出される、
    # 現在接続中の機種がHamlib上で実際にサポートするモード一覧(C4FM/DSTAR等の
    # 機種固有デジタルモードを含む)。未検出/未接続時は汎用の静的リストにフォールバック。
    modes = current_mode_list if current_mode_list else sorted(_FALLBACK_MODE_LIST)
    return {"modes": modes, "raw": ""}


@app.get("/radio/modes")
def list_modes():
    modes = current_mode_list if current_mode_list else _FALLBACK_MODE_LIST
    return {"modes": modes}


def _setfreq_with_retry(f: int):
    for attempt in range(4):
        result = rigctl_cmd(f"F {f}")
        if result is not None and "RPRT" in result:
            return
        time.sleep(1.0)

@app.post("/radio/setfreq")
def set_freq(f: int = Form(...)):
    global last_user_freq_change
    radio_cache["freq"] = f
    last_user_freq_change = time.time()
    threading.Thread(target=_setfreq_with_retry, args=(f,), daemon=True).start()
    return {"status": "ok", "freq": f}


SCOPE_MAX_POINTS = 256   # 1スイープの最大点数(刻みが細かすぎる/幅が広すぎる場合のクランプ)


@app.post("/radio/scope/sweep")
def scope_sweep(start: int = Form(...), stop: int = Form(...),
                step: int = Form(...), settle_ms: int = Form(40)):
    """バンドスコープ(簡易CATスイープ)。
    start〜stop を step 刻みでVFOを動かし、各点で 'l STRENGTH' を読み、
    [信号強度(dB)] の配列を返す。hamlib経由ではIQスペクトラムが取得できない
    ため、リグ自身を掃引して疑似スペクトラムを作る方式。

    - TX中は掃引しない(安全)。
    - 掃引中は poll_enabled=False + _scope_active=True で通常ポーリングを止め、
      rig_lock競合を避ける。
    - 掃引後は周波数とモードを元に戻す。バンドを跨ぐ掃引でリグが自動的にモードを
      変えても、掃引前のモードへ復元する(モードが勝手に変わらないように)。
    - 掃引中にユーザーがタップでQSY(/radio/setfreq)した場合は、そのQSY先を優先して
      復元する(スコープで選んだ周波数が掃引の復元で打ち消されないように)。
    """
    global poll_enabled, _scope_active, last_user_freq_change, last_user_mode_change

    if tx_in_progress or radio_cache.get("tx", False):
        return {"status": "busy", "reason": "tx"}

    if step <= 0 or stop <= start:
        return {"status": "error", "reason": "bad_range"}

    # 既にスイープ中なら弾く(多重呼び出し対策)
    if not _scope_lock.acquire(blocking=False):
        return {"status": "busy", "reason": "scope"}

    saved_freq = int(radio_cache.get("freq") or start)
    saved_mode = radio_cache.get("mode") or ""
    saved_width = int(radio_cache.get("width") or 0)
    prev_poll = poll_enabled
    settle = max(0.0, min(settle_ms, 500)) / 1000.0

    # 点数をクランプ(刻みが細かすぎ/幅が広すぎる時は step を自動的に粗くする)
    n = (stop - start) // step + 1
    if n > SCOPE_MAX_POINTS:
        step = max(1, (stop - start) // (SCOPE_MAX_POINTS - 1))
        n = (stop - start) // step + 1

    freqs: list = []
    points: list = []
    try:
        poll_enabled = False
        _scope_active = True
        time.sleep(0.05)  # 進行中のポーリングが抜けるのを少し待つ

        f = start
        while f <= stop:
            rigctl_cmd(f"F {f}")
            if settle:
                time.sleep(settle)
            raw = rigctl_cmd("l STRENGTH")
            val = raw.split()[0] if raw else ""
            try:
                sig = float(val)
            except Exception:
                sig = -54.0  # 読めない時はS0相当のフロア
            freqs.append(f)
            points.append(sig)
            f += step
    finally:
        # 周波数とモードを復元してから通常ポーリングを再開。
        try:
            # 掃引中にユーザーがタップでQSYしていれば radio_cache["freq"] がその値に
            # なっている(掃引自体は radio_cache["freq"] を書き換えない)。その場合は
            # 掃引開始時の saved_freq ではなくユーザーのQSY先へ戻す。
            target = int(radio_cache.get("freq") or saved_freq)
            rigctl_cmd(f"F {target}")
            radio_cache["freq"] = target
            last_user_freq_change = time.time()
            # モードを掃引前へ復元(バンド跨ぎでの自動モード変更を打ち消す)。
            if saved_mode:
                w = 0 if saved_mode.upper() in ("FM", "PKTFM") else saved_width
                rigctl_cmd(f"M {saved_mode} {w}")
                radio_cache["mode"] = saved_mode
                radio_cache["width"] = saved_width
                last_user_mode_change = time.time()
        except Exception:
            pass
        _scope_active = False
        poll_enabled = prev_poll
        _scope_lock.release()

    return {"status": "ok", "start": start, "stop": stop, "step": step,
            "count": len(points), "freqs": freqs, "points": points}


_cw_tx_shift_hz: int = 0
_cw_tx_saved_rx_freq: int = 0


@app.post("/radio/set_tx_shift")
def set_tx_shift(shift_hz: int = Form(...)):
    """CW TX SHIFTエンドポイント: シフト値を記録するだけ(リグへの操作なし)。
    実際の周波数移動は /cw/send_morse の送信直前/直後に行う。
    これにより split/XIT 不要でCWキーイングが正常に動作する。"""
    global _cw_tx_shift_hz
    _cw_tx_shift_hz = shift_hz
    try:
        Path("/tmp/cw_tx_shift_hz").write_text(str(shift_hz))
    except Exception:
        pass
    return {"status": "ok", "shift_hz": shift_hz}


def _reassert_freq_after_mode(restore_freq: int):
    """モード変更でVFOがずれる機種(FT-991A等)対策。モード確定後、意図周波数へ留まるまで F を
    再送して読み戻し確認する。CW→SSB のようにリグが切替完了後に遅れてVFOを動かすケースも、
    読み戻しで一致するまで押さえ込むことで打ち消せる。
    ★ ターゲットは毎ループ radio_cache['freq'](=最新の意図周波数)を読む。モード変更直後に
      メモリーリコール等で別周波数が設定されたら即座にそちらへ追従し、古い周波数へ戻さない
      (前の操作から残っている再送ループがメモリー周波数を打ち消すのを防ぐ)。
    各ループで last_user_freq_change を更新し、本体ポーラーがずれた値をキャッシュしないようにする。"""
    global last_user_freq_change
    for _ in range(8):
        try:
            target = int(radio_cache.get("freq") or restore_freq)
        except (TypeError, ValueError):
            target = restore_freq
        if target <= 0:
            return
        last_user_freq_change = time.time()
        rigctl_cmd(f"F {target}")
        time.sleep(0.2)
        last_user_freq_change = time.time()
        try:
            raw = rigctl_cmd("f")
            val = raw.split()[0] if raw else ""
            if val.lstrip("-").isdigit() and abs(int(val) - target) <= 10:
                last_user_freq_change = time.time()
                return
        except Exception:
            pass
    last_user_freq_change = time.time()

@app.post("/radio/civ_raw")
def civ_raw(hex: str = Form(...)):
    # 生CI-Vフレーム(Icom)を無線機へ送る。rigctldの send_cmd('w') はhamlibのCI-Vシリアルを壊す
    # (D-STARモードにできなくなる)ため使わず、rigctldを一時停止してポートを奪い、pyserialで直接
    # 送信→応答を読む→rigctldを再起動する(確実に反映&干渉なし)。D-STAR UR/R1/R2(1F 01)等に使用。
    # hex = "FEFEA4E01F01...FD"。数秒 CAT リンクが切れる(再接続される)。
    global rigctld_process, _rig_open_started
    # ★ rigctld停止〜再起動の間は /radio/status の rig_ok が false になり、アプリ/M5が
    #   D-STAR設定のたびに「リグ切断」を表示していた。/radio/open と同じ接続中猶予を適用する
    #   (再起動後にリグから最初の正常応答が得られるまで、最長 _RIG_OPEN_GRACE_SEC 秒は rig_ok=true)。
    _rig_open_started = time.time()
    try:
        h = (hex or "").strip().replace(" ", "").upper()
        if len(h) < 4 or len(h) % 2 != 0:
            return {"ok": False, "error": "bad hex"}
        if not _HAS_SERIAL:
            return {"ok": False, "error": "pyserial not available"}
        if not current_cat:
            return {"ok": False, "error": "no CAT device (open rig first)"}
        frame = bytes.fromhex(h)
        baud = int(current_baud or 38400)
        dev = current_cat if str(current_cat).startswith("/") else f"/dev/{current_cat}"
        reply_hex = ""
        with rig_lock:
            # 1. rigctld停止 → シリアルポート解放
            try:
                if rigctld_process and rigctld_process.poll() is None:
                    rigctld_process.terminate()
                    try:
                        rigctld_process.wait(timeout=3)
                    except Exception:
                        rigctld_process.kill(); rigctld_process.wait(timeout=2)
            except Exception:
                pass
            rigctld_process = None
            subprocess.run(["pkill", "-TERM", "-f", "rigctld"], capture_output=True)
            time.sleep(0.4)
            subprocess.run(["pkill", "-KILL", "-f", "rigctld"], capture_output=True)
            time.sleep(0.3)
            # 2. 直接シリアルで送信 → 応答を読む(エコー+FB/FA)
            #    hexに複数CI-Vフレーム(各 FE FE..FD)が連結されている場合は1つずつ分割して送る。
            #    一括バーストだとIC-705が後半フレーム(オフセット/DUP/1F 01)を取りこぼすため、
            #    各フレームごとに送信→短時間応答読み→次、とすることで確実に反映させる。
            try:
                with _serial.Serial(dev, baud, timeout=0.2) as ser:
                    # 連結バイト列を FE FE .. FD 単位に分割
                    frames = []
                    i = 0; n = len(frame)
                    while i < n:
                        if frame[i] == 0xFE and i + 1 < n and frame[i + 1] == 0xFE:
                            j = frame.find(0xFD, i)
                            if j == -1:
                                break
                            frames.append(frame[i:j + 1]); i = j + 1
                        else:
                            i += 1
                    if not frames:
                        frames = [frame]
                    buf = b""
                    ser.reset_input_buffer()
                    for fr in frames:
                        ser.write(fr); ser.flush()
                        dl = time.time() + 0.4
                        got = b""
                        while time.time() < dl:
                            chunk = ser.read(128)
                            if chunk:
                                got += chunk
                            elif got:
                                break
                        buf += got
                    reply_hex = buf.hex().upper()
            finally:
                # 3. rigctld 再起動(start_rigctldはrig_lockを取らないのでここで呼んでよい)
                start_rigctld(current_model, current_cat, current_baud, current_ptt, current_ptt_type)
        ok = "FB" in reply_hex   # Icom OK応答=FB、NG=FA
        return {"ok": ok, "reply": reply_hex}
    except Exception as e:
        try:
            start_rigctld(current_model, current_cat, current_baud, current_ptt, current_ptt_type)
        except Exception:
            pass
        return {"ok": False, "error": str(e)}

# ── 生CI-V TCPブリッジ(D-STAR遠隔用) ────────────────────────────────────────────
# rigctld(hamlib)では生CI-V(1F 01 / 20 00 02 等のD-STARコマンド)が扱えないため、D-STAR運用中だけ
# rigctldを止めてリグのUSBシリアルを生CI-VのTCPブリッジとして公開する。アプリ(CivBridgeService)が
# このポートへ直接CI-Vフレームを送受信し、ローカルCI-Vと全く同じD-STAR制御(DR/R1/R2/受信コール
# ポーリング)を遠隔で行える。D-STARを抜けたらブリッジを止めてrigctldを再起動する。
CIV_BRIDGE_PORT = 14652
civ_bridge_running = False
civ_bridge_thread = None

def _civ_bridge_loop(dev, baud):
    global civ_bridge_running, _rig_open_started
    srv = None; ser = None; conn = None
    try:
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind(("0.0.0.0", CIV_BRIDGE_PORT)); srv.listen(1); srv.settimeout(1.0)
        ser = _serial.Serial(dev, baud, timeout=0.05)
        sfd = ser.fileno()
        idle_deadline = time.time() + 180   # 無クライアントが続いたら自動停止(保護)
        while civ_bridge_running:
            if conn is None:
                try: ser.reset_input_buffer()
                except Exception: pass
                try:
                    conn, _ = srv.accept(); idle_deadline = time.time() + 180
                except socket.timeout:
                    if time.time() > idle_deadline: break
                    continue
                except OSError:
                    continue
            try:
                rl, _, _ = select.select([conn, sfd], [], [], 1.0)
            except OSError:
                try: conn.close()
                except Exception: pass
                conn = None; idle_deadline = time.time() + 180; continue
            if conn in rl:
                try: data = conn.recv(512)
                except OSError: data = b""
                if not data:
                    try: conn.close()
                    except Exception: pass
                    conn = None; idle_deadline = time.time() + 180; continue
                try: ser.write(data)
                except Exception: pass
            if sfd in rl:
                try: r = ser.read(512)
                except Exception: r = b""
                if r:
                    try: conn.sendall(r)
                    except OSError:
                        try: conn.close()
                        except Exception: pass
                        conn = None; idle_deadline = time.time() + 180; continue
    except Exception:
        pass
    finally:
        for c in (conn, srv, ser):
            try:
                if c: c.close()
            except Exception: pass
        civ_bridge_running = False
        # ブリッジ終了→rigctld再起動中は rig_ok を接続中猶予で true 扱い(「リグ切断」誤表示防止)
        _rig_open_started = time.time()
        try:
            start_rigctld(current_model, current_cat, current_baud, current_ptt, current_ptt_type)
        except Exception:
            pass

@app.post("/radio/civ_bridge")
def civ_bridge(on: str = Form(...)):
    # on=1: rigctld停止→生CI-V TCPブリッジ開始(ポートCIV_BRIDGE_PORT)。on=0: ブリッジ停止→rigctld再起動。
    global civ_bridge_running, civ_bridge_thread, _rig_open_started
    try:
        enable = str(on).strip().lower() in ("1", "true", "on", "yes")
        # ブリッジ開始(rigctld停止)/停止(rigctld再起動)のどちらも数秒リグ応答が途切れる → 接続中猶予
        _rig_open_started = time.time()
        if enable:
            if civ_bridge_running:
                return {"ok": True, "port": CIV_BRIDGE_PORT, "note": "already running"}
            if not _HAS_SERIAL:
                return {"ok": False, "error": "pyserial not available"}
            if not current_cat:
                return {"ok": False, "error": "no CAT device (open rig first)"}
            dev = current_cat if str(current_cat).startswith("/") else f"/dev/{current_cat}"
            baud = int(current_baud or 38400)
            with rig_lock:
                try:
                    if rigctld_process and rigctld_process.poll() is None:
                        rigctld_process.terminate()
                        try: rigctld_process.wait(timeout=3)
                        except Exception: rigctld_process.kill(); rigctld_process.wait(timeout=2)
                except Exception: pass
                subprocess.run(["pkill", "-TERM", "-f", "rigctld"], capture_output=True); time.sleep(0.4)
                subprocess.run(["pkill", "-KILL", "-f", "rigctld"], capture_output=True); time.sleep(0.3)
            civ_bridge_running = True
            civ_bridge_thread = threading.Thread(target=_civ_bridge_loop, args=(dev, baud), daemon=True)
            civ_bridge_thread.start()
            return {"ok": True, "port": CIV_BRIDGE_PORT}
        else:
            civ_bridge_running = False
            t = civ_bridge_thread
            if t:
                t.join(timeout=4)   # スレッドのfinallyがrigctldを再起動する
            civ_bridge_thread = None
            return {"ok": True}
    except Exception as e:
        civ_bridge_running = False
        try:
            start_rigctld(current_model, current_cat, current_baud, current_ptt, current_ptt_type)
        except Exception: pass
        return {"ok": False, "error": str(e)}

@app.post("/radio/setmode")
def set_mode(mode: str = Form(...), width: int = Form(...), restore_freq: int = Form(0)):
    global last_user_mode_change, last_user_freq_change
    # ★ FTX-1等のYaesu(newcat)では、FMにSSB用の狭い幅(例: 2400)を付けて送ると
    #   Hamlibが「標準より狭い」と判断してFM-Nにしてしまう。FM系は幅固定(FM=16k/FM-N=9k)
    #   のため、幅0(=標準)で送って常にFM(ワイド)にする。FM-Nが欲しい場合はFMNを選ぶ。
    if mode.upper() in ("FM", "PKTFM"):
        width = 0
    # ★ D-STAR(DV)はフィルタ幅の概念が無く、幅を付けて送るとhamlibがDV切替を拒否して
    #   「モードが遷移しない」間欠失敗を起こす。C4FM/FMと同様に幅0(標準)で送る。
    if mode.upper() in ("DSTAR", "D-STAR", "DV"):
        width = 0
    _prev_mode = radio_cache.get("mode")
    _prev_width = radio_cache.get("width", 0)
    radio_cache["mode"] = mode
    radio_cache["width"] = width
    last_user_mode_change = time.time()
    # ★ restore_freq>0: モード変更でVFOがずれる機種(FT-991A等)対策。モードコマンド完了後に
    #   この周波数を再設定してずれを打ち消す。別スレッドの /radio/setfreq に任せると F が M より
    #   先に rig_lock を取って実行され、その後の M でVFOがずれてしまうため、ここで順序保証する。
    #   キャッシュとガードタイマーを先に張り、M 完了前のポーリングがずれた値を拾わないようにする。
    if restore_freq > 0:
        radio_cache["freq"] = restore_freq
        last_user_freq_change = time.time()
    def _set_and_check():
        global last_user_mode_change, last_user_freq_change
        result = None
        for _attempt in range(4):
            result = rigctl_cmd(f"M {mode} {width}")
            if not (result and result.startswith("RPRT") and result != "RPRT 0"):
                break
            if mode == "C4FM" and result == "RPRT -14":
                break
            time.sleep(1.0)
        mode_ok = True
        if result and result.startswith("RPRT") and result != "RPRT 0":
            # C4FM: FT-991A はモード切替中に CAT 応答が遅れ RPRT -14(BUSBUSY) を返すが、
            # リグは実際に C4FM へ切り替わっている(直後の 'm' タイムアウトで確認済み)。
            # BUSBUSY は成功として扱い、キャッシュを C4FM のまま維持する。
            if mode == "C4FM" and result == "RPRT -14":
                last_user_mode_change = time.time()
                print(f"[{_ts()}] [setmode] C4FM BUSBUSY treated as success", flush=True)
            else:
                radio_cache["mode"] = _prev_mode
                radio_cache["width"] = _prev_width
                mode_ok = False
                print(f"[{_ts()}] [setmode] '{mode}' failed ({result}), cache reverted to '{_prev_mode}'", flush=True)
        else:
            # M コマンド完了後にガードタイマーをリセット。
            # リクエスト受信時点(0.5s前)からではなく、コマンド完了後からポーリングを抑制することで、
            # リグの切替完了前に m クエリが古いモードを返してキャッシュを上書きするのを防ぐ。
            last_user_mode_change = time.time()
        # ★ モード確定後に周波数を戻す(順序保証)。モード切替直後はVFOが動くことがあるので
        #   少し落ち着かせてから設定する。モード変更が失敗したときはずれも起きないので戻さない。
        if mode_ok and restore_freq > 0 and mode.upper() != "C4FM":
            _reassert_freq_after_mode(restore_freq)
    threading.Thread(target=_set_and_check, daemon=True).start()
    return {"status": "ok", "mode": mode, "width": width}


def _ptt_off_watchdog():
    """FTX-1F等、出力ランプアップ中や送信時のRF回り込みでUSB/rigctldがリセット
    されることがあるリグ向け。"t"問い合わせでOFFを確認できるまで、一定間隔で
    T 0を送り続ける(最大20秒)。

    rigctld再起動(release_ptt=False、音声USBリセット復旧用)を挟んだ場合、
    再起動直後のrigctldは無線機の実際のTX状態を把握していない可能性があるため、
    "t"の単発の"0"応答を信用せず2回連続で"0"を確認するまで待つ。さらにその
    場合は、確認後・タイムアウト後のいずれでも念のため最後にもう一度無条件で
    T 0を送っておく(既にOFFなら無害、まだONなら最後の保険になる)。

    CW(内蔵キーヤー)・APRS(direwolf)はT 1/last_ptt_stateを経由せず独自にPTTを
    制御するため、それらが動き出したらこのwatchdogは無関係なT 0を送らないよう
    即座に打ち切る。"""
    PTT_OFF_RETRY_INTERVAL = 1.0
    PTT_OFF_WATCHDOG_SEC = 20.0
    deadline = time.time() + PTT_OFF_WATCHDOG_SEC
    _starting_proc = rigctld_process
    saw_restart = False
    consecutive_off = 0

    def _superseded():
        # ★ radio_cache["tx"]はpoll_rigが無線機への実際の"t"問い合わせ結果でも
        #   更新するため、「無線機がまだONのまま」という、このwatchdogがまさに
        #   直そうとしている状態そのものでTrueになりうる。それを"追い越された"
        #   と誤判定して即座に諦めてしまっていたため、ここではlast_ptt_state
        #   (ソフトウェアが明示的にONを命令したか)とtx_in_progress(APRS等の
        #   ソフトウェア駆動の送信中フラグ、poll_rigは触らない)のみを見る。
        return last_ptt_state == 1 or tx_in_progress or _morse_sending or _ft8_tx_active

    while time.time() < deadline:
        time.sleep(PTT_OFF_RETRY_INTERVAL)
        if _superseded():
            return  # 音声PTT ON / APRS TX / CW送信 / FT8送信に追い越された

        if rigctld_process is not _starting_proc:
            saw_restart = True  # rigctldプロセスが入れ替わった = 再起動が発生した

        if _rigctld_restarting:
            # 再起動処理の真っ最中はコマンドを送っても無駄。復旧を待つ。
            saw_restart = True
            consecutive_off = 0
            continue

        required_confirms = 2 if saw_restart else 1
        ptt_raw = rigctl_cmd_priority("t")
        if ptt_raw and ptt_raw.strip().split("\n")[0].strip() == "0":
            consecutive_off += 1
            if consecutive_off >= required_confirms:
                if saw_restart:
                    print(f"[{_ts()}] *** [PTT OFF watchdog] confirmed OFF after rigctld restart, sending final safety T 0", flush=True)
                    rigctl_cmd_priority("T 0")
                return  # OFF確認済み
            continue

        consecutive_off = 0
        if not ptt_raw:
            # "t"問い合わせ自体が無応答 = rigctldが落ちている(USBリセット等)。
            # 通常はaudio_tx側のUSBリセット検知(last_ptt_state==1が条件)が再起動を
            # キックするが、PTT ON→OFFが極端に速いとOFF処理でlast_ptt_stateが先に
            # 0になり、誰も再起動をキックしないまま放置されることがあった。
            # ここでwatchdog自身が再起動をキックして取りこぼしを防ぐ
            # (release_ptt=True: last_ptt_state==0なのでstart_rigctld自身のPTT解除
            #  ロジックにもT 0を送らせ、OFFを二重に確実にする)。
            print(f"[{_ts()}] *** [PTT OFF watchdog] rigctld unresponsive, triggering restart", flush=True)
            saw_restart = True
            if current_model and current_cat:
                _trigger_rigctld_restart(current_model, current_cat, current_baud,
                                          current_ptt, current_ptt_type, release_ptt=True)
            continue

        print(f"[{_ts()}] *** [PTT OFF watchdog] still ON, resending T 0", flush=True)
        rigctl_cmd_priority("T 0")

    if saw_restart:
        print(f"[{_ts()}] *** [PTT OFF watchdog] gave up after {PTT_OFF_WATCHDOG_SEC:.0f}s (rigctld restart occurred) — sending final safety T 0", flush=True)
        rigctl_cmd_priority("T 0")
    else:
        print(f"[{_ts()}] *** [PTT OFF watchdog] gave up after {PTT_OFF_WATCHDOG_SEC:.0f}s — radio may be stuck in TX!", flush=True)


@app.post("/radio/ptt")
def ptt(state: int = Form(...)):
    global last_ptt_state, last_heartbeat, _ft8_tx_active
    if state == 0:
        if last_ptt_state == 1:
            # サーバーが TX を命令していた場合のみ T 0 を送る。
            # last_ptt_state=0 の場合に T 0 を送ると C4FM モードで brief TX が発生する。
            # FTX-1F は ON 直後の出力ランプアップ中(~6秒)は T 0 を CI-V 的には正常応答
            # (RPRT 0)しつつ実際には無視することがあるため、単発リトライでは検知できない。
            # まず即座に1回送り、応答を待たせないようレスポンスは返す。実際に "t" 問い合わせで
            # OFFを確認できるまでは、バックグラウンドで一定間隔で送り続けるwatchdogに任せる。
            rigctl_cmd_priority("T 0")
            threading.Thread(target=_ptt_off_watchdog, daemon=True).start()
        else:
            print(f"[{_ts()}] [PTT OFF] T 0 skipped (last_ptt_state was already 0)", flush=True)
        radio_cache["tx"] = False
        last_ptt_state = 0
        _ft8_tx_active = False
        # direwolf の自動再起動はしない
        # audio RX が再接続すると /radio/audio が direwolf を停止して ffmpeg を起動するため
        # ここで direwolf を再起動すると ffmpeg と ALSA デバイスが競合してしまう
        # APRS 用の direwolf は /aprs_config・/aprs_stop が管理する
        return {"status": "ok", "ptt": 0}
    # ハートビート受信 — 即座に更新 (rigctlタイムアウトで遅延しないよう先頭で実施)
    last_heartbeat = time.time()
    if last_ptt_state == 1:
        # 既にTX中: rigctlを再送せず即リターン (watchdog対策)
        return {"status": "ok", "ptt": 1}
    # TX開始 (初回のみ): direwolfをSIGKILLで停止
    # ffmpegはaudio_tx開始時に停止する（audio RXストリームを早期に切断しない）
    subprocess.run(["pkill", "-9", "direwolf"], capture_output=True)
    result = rigctl_cmd_priority("T 1")
    if not result:
        # rigctld タイムアウト → 即座に再起動してクライアントにリトライを促す
        if current_model and current_cat and not _rigctld_restarting:
            print(f"[{_ts()}] [ptt] T 1 timeout — triggering rigctld restart", flush=True)
            _trigger_rigctld_restart(current_model, current_cat, current_baud,
                                      current_ptt, current_ptt_type)
        raise HTTPException(status_code=500, detail="rigctld timeout")
    radio_cache["tx"] = True
    last_ptt_state = 1
    return {"status": "ok", "ptt": 1}


@app.post("/radio/poll")
def set_poll(state: int = Form(...)):
    global poll_enabled
    poll_enabled = bool(state)
    return {"poll_enabled": poll_enabled}


@app.post("/radio/ptt_heartbeat")
def ptt_heartbeat():
    # WiFi PTTモード専用: last_heartbeatだけ更新、rigctlは呼ばない
    global last_heartbeat
    last_heartbeat = time.time()
    return {"status": "ok"}


@app.post("/radio/setlevel")
def set_level(name: str = Form(...), value: float = Form(...)):
    radio_cache[name.lower()] = value
    threading.Thread(target=lambda: rigctl_cmd(f"L {name.upper()} {value}"), daemon=True).start()
    return {"status": "ok", "level": name, "value": value}


# FT-991 / FT-991A (Hamlib モデル 1035) は Hamlib の SBKIN/FBKIN 抽象化では
# BK-IN が正しく切り替わらない/読めないため、生の CAT コマンドで直接やり取りする。
# ★ FT-991 の BREAK-IN コマンドは公式CATリファレンス上 "BI" (BI0;=OFF / BI1;=ON)。
#   以前使っていた "BK" はFT-991には存在せず無視されていた(OFFにできなかった原因)。
_FT991_MODELS = {1035}
_FTX1_MODELS = {1051}


def _is_ft991() -> bool:
    return current_model in _FT991_MODELS


def _is_ftx1() -> bool:
    return current_model in _FTX1_MODELS


def _rig_query_raw(cmd: str) -> str:
    """Yaesu新CATの問い合わせ(応答あり)。"w CMD;" を送り ';' が来るまで読み溜めて返す。
    (FTX-1 等。_rig_get_vfo_freq と同じ受信方式の汎用版)"""
    s = None
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1.0)
        s.connect(("localhost", 4532))
        s.sendall(f"w {cmd};\n".encode())
        buf = b""
        deadline = time.time() + 1.0
        while time.time() < deadline:
            try:
                chunk = s.recv(4096)
            except socket.timeout:
                break
            if not chunk:
                break
            buf += chunk
            if b";" in buf:
                break
        return buf.decode(errors="replace").strip()
    except Exception:
        return ""
    finally:
        if s:
            try:
                s.close()
            except Exception:
                pass


def _yaesu_read_tuner():
    """Yaesu新CAT "AC;" でATU状態を読む。応答 "AC00n;" の n(0=OFF/1=ON/2=TUNE中)を返す。失敗時 None。"""
    raw = _rig_query_raw("AC")
    if raw:
        m = re.search(r'AC\d*(\d);', raw)
        if m:
            return int(m.group(1))
    return None


def _ft991_read_bkin():
    """FT-991 の BREAK-IN 状態を生CAT("BI;")で問い合わせる。1/0、取得失敗時は None。"""
    raw = rigctl_cmd("w BI;")
    if raw:
        m = re.search(r'BI([01])', raw)
        if m:
            return int(m.group(1))
    return None


@app.post("/radio/setbkin")
def set_bk_in(state: int = Form(...)):
    try:
        # FT-991/FT-991A は Hamlib の SBKIN を使わず、生CAT "BI0;"/"BI1;" で直接設定する
        # (Hamlib 抽象化では BK-IN が正しく切り替わらないため)
        if _is_ft991():
            # SETは無応答のため、rig_lockを2秒握り続けないよう _rig_send_no_reply で送る
            with rig_lock:
                raw = _rig_send_no_reply("w BI" + ("1" if state else "0") + ";")
            radio_cache["bk_in"] = state
            return {"ok": True, "bk_in": state, "raw": str(raw), "mode": "ft991_cat"}
        # 1. Hamlib standard (works on some rigs)
        raw1 = rigctl_cmd("U SBKIN " + str(state))
        if raw1 is not None and "RPRT 0" in raw1:
            radio_cache["bk_in"] = state
            return {"ok": True, "bk_in": state, "raw": raw1}
        # 2. FT-991A raw CAT: BK1; = semi break-in ON, BK0; = OFF
        # B=\x42  K=\x4b  1=\x31 / 0=\x30  ;=\x3b
        val_hex = "31" if state else "30"
        raw2 = rigctl_cmd("w \\x42\\x4b\\x" + val_hex + "\\x3b")
        ok = raw2 is not None
        if ok:
            radio_cache["bk_in"] = state
        return {"ok": ok, "bk_in": state, "raw1": str(raw1), "raw2": str(raw2)}
    except Exception as e:
        return {"ok": False, "error": str(e)}


@app.get("/radio/getbkin")
def get_bk_in():
    # FT-991/FT-991A は生CATで BK 状態を問い合わせる
    if _is_ft991():
        v = _ft991_read_bkin()
        if v is not None:
            radio_cache["bk_in"] = v
        return {"bk_in": radio_cache.get("bk_in", 0)}
    # Try SBKIN first (semi break-in), fall back to FBKIN (full break-in)
    val = 0
    for func in ("SBKIN", "FBKIN"):
        raw = rigctl_cmd(f"u {func}")
        try:
            v = raw.split()[0] if raw else ""
            if v.lstrip("-").isdigit():
                val = int(v)
                break
        except Exception:
            pass
    radio_cache["bk_in"] = val
    return {"bk_in": val}


# アンテナチューナー(ATU) 制御。state: 0=OFF / 1=ON / 2=TUNE開始。
# Hamlib の RIG_FUNC_TUNER を第一候補にし、効かない機種(Yaesu新CAT: FT-991/FTX-1等)は
# 生CAT "AC00n;"(0=OFF/1=ON/2=TUNE開始)にフォールバックする(BK-INの BI コマンドと同方式)。
# ATU非対応機では両方とも失敗し ok=False を返す(アプリ側はトグルが無反応になるだけ)。
@app.post("/radio/settuner")
def set_tuner(state: int = Form(...)):
    try:
        digit = "2" if state == 2 else ("1" if state else "0")
        # FTX-1(Yaesu新CAT): SETは無応答のため _rig_send_no_reply で生CATを直接送る。
        # ★ 実機確認: FTX-1 の AC は P1=1 固定。"w AC;" の応答が "AC100;"(OFF) で、
        #   P1=0 の "AC00n;" は "?;" で拒否された。末尾桁(P3)が 0=OFF/1=ON/2=TUNE開始。
        #   よって書式は "AC10n;"(FT-991 の "AC00n;" とは P1 が異なる)。
        if _is_ftx1():
            _rig_send_no_reply("w AC10" + digit + ";")
            if state != 2:
                radio_cache["tuner"] = 1 if state else 0
            return {"ok": True, "tuner": radio_cache.get("tuner", 0), "mode": "ftx1_ac"}
        # 1. Hamlib 標準 set_func TUNER (TUNE開始=2 も 1 として扱う)
        raw1 = rigctl_cmd("U TUNER " + ("1" if state else "0"))
        if raw1 is not None and "RPRT 0" in raw1:
            radio_cache["tuner"] = 0 if state == 0 else 1
            return {"ok": True, "tuner": radio_cache["tuner"], "raw": raw1}
        # 2. Yaesu new-CAT raw fallback: AC00{0|1|2};
        # SETは無応答のため、rig_lockを2秒握り続けないよう _rig_send_no_reply で送る
        with rig_lock:
            raw2 = _rig_send_no_reply("w AC00" + digit + ";")
        ok = raw2 is not None
        if ok and state != 2:
            radio_cache["tuner"] = 1 if state else 0
        return {"ok": ok, "tuner": radio_cache.get("tuner", 0), "raw1": str(raw1), "raw2": str(raw2)}
    except Exception as e:
        return {"ok": False, "error": str(e)}


@app.get("/radio/gettuner")
def get_tuner():
    # FTX-1 は "AC;" で読む。それ以外は Hamlib get_func TUNER。読めない機種はキャッシュ値を返す。
    if _is_ftx1():
        v = _yaesu_read_tuner()
        if v is not None:
            radio_cache["tuner"] = 0 if v == 0 else 1
        return {"tuner": radio_cache.get("tuner", 0)}
    raw = rigctl_cmd("u TUNER")
    try:
        v = raw.split()[0] if raw else ""
        if v.lstrip("-").isdigit():
            radio_cache["tuner"] = 1 if int(v) else 0
    except Exception:
        pass
    return {"tuner": radio_cache.get("tuner", 0)}


@app.post("/radio/setpower")
def set_power(value: float = Form(...)):
    radio_cache["power"] = value
    threading.Thread(target=lambda: rigctl_cmd(f"L RFPOWER {value}"), daemon=True).start()
    return {"status": "ok", "power": value}


@app.get("/radio/audio")
def audio_stream(request: Request, background_tasks: BackgroundTasks):
    from fastapi.responses import Response
    rate = request.query_params.get("rate", "8000")
    if not rate.isdigit():
        rate = "8000"
    t0 = time.time()
    print(f"[audio_rx] connect rate={rate}")

    # Only tear the FT8 capture down when this capture actually has to be (re)started.
    #
    # This block used to run on every connect, including the very common case where ffmpeg is
    # already streaming at the requested rate. Killing arecord and sleeping 150 ms each time
    # disturbed a perfectly healthy capture, and a client that reconnects mid-message then
    # waited out the restart plus the first-data timeout below. Seconds of audio went missing,
    # which at 45.45 baud is several characters. Losing a shift character that way corrupts
    # every letter after it, seen on the air as JI1ORE arriving as JI143.
    _already = (_mgr_rx.proc is not None and _mgr_rx.proc.poll() is None
                and getattr(_mgr_rx, "_rate", None) == rate)
    if not _already:
        _mgr_sub.stop()  # FT8用arecord|soxを停止してALSAを解放
        # shellのSIGTERM後もarecordが残留することがあるため強制kill
        subprocess.run(["pkill", "-9", "arecord"], capture_output=True)
        time.sleep(0.15)  # ALSAデバイス解放を確実に待機
    proc = _mgr_rx.ensure(rate)

    # ffmpeg即死 = aplayとのALSA競合 or デバイス未解放の場合、待ってから再起動
    if proc.poll() is not None:
        print(f"[audio_rx] ffmpeg dead, waiting for aplay/arecord release...")
        deadline = time.time() + 0.8
        while time.time() < deadline:
            busy = (subprocess.run(["pgrep", "-x", "aplay"],   capture_output=True).returncode == 0 or
                    subprocess.run(["pgrep", "-x", "arecord"], capture_output=True).returncode == 0)
            if not busy:
                break
            time.sleep(0.05)
        proc = _mgr_rx._start(rate)
        time.sleep(0.1)
        if proc.poll() is not None:
            time.sleep(0.05)  # stderr スレッドが最後の行を拾うのを待つ
            err = _mgr_rx.stderr_tail()
            print(f"[audio_rx] ffmpeg dead after aplay-wait: {err}")
            return Response(status_code=503, content=f"ffmpeg error: {err}")

    sid, q = _mgr_rx.subscribe(maxsize=32)

    # ffmpegが実際にデータを出力しているか確認（PipeWire等の遅延死を検出）
    # ★ Pi では ffmpeg のコールドスタート(バイナリ読込+ALSA open+probe)に 1〜2 秒かかる
    #   ことがあり、旧 0.6 秒だと起動直後の接続が毎回タイムアウトしていた。
    first_data = None
    deadline = time.time() + 2.5
    while time.time() < deadline:
        try:
            first_data = q.get(timeout=0.05)
            break
        except _queue.Empty:
            if proc.poll() is not None:
                break

    if first_data is None:
        _mgr_rx.unsubscribe(sid)
        alive = proc.poll() is None
        time.sleep(0.05)
        err = _mgr_rx.stderr_tail()
        state = "alive, silent" if alive else f"exited rc={proc.returncode}"
        print(f"[audio_rx] no data from ffmpeg ({time.time()-t0:.3f}s, {state}): {err}")
        # ★ 生きているのに音声を出さない ffmpeg は使い回しても永久に沈黙したまま
        #   (クライアントが 0.5 秒ごとに再接続するため idle 停止も走らない)。
        #   ここで必ず止めて、次の接続で新しいプロセスから始める。
        _mgr_rx.stop()
        return Response(status_code=503, content=f"ffmpeg no data ({state}): {err}")

    print(f"[audio_rx] ready {time.time()-t0:.3f}s")

    def stream():
        try:
            yield first_data
            while True:
                try:
                    data = q.get(timeout=0.2)
                    yield data
                except _queue.Empty:
                    if _mgr_rx.proc is not proc or proc.poll() is not None:
                        break
        except (GeneratorExit, BrokenPipeError, ConnectionResetError):
            pass

    def cleanup():
        _mgr_rx.unsubscribe(sid)
        print("[audio_rx] client disconnected")

    return StreamingResponse(stream(), media_type="application/octet-stream",
                             background=BackgroundTask(cleanup))


@app.get("/admin/amixer")
def admin_amixer():
    """Read-only dump of the sound card's mixer controls.

    Needed because a dead-flat capture level is the signature of hardware AGC on the USB
    codec, and AGC in front of a modem continuously rewrites the amplitude relationship the
    mark/space detector depends on. Measured on the IC-705's Pi: 49 s of capture sat at
    -22.3 dBFS with a peak near 8000 and never moved, transmission or not.
    """
    out = {}
    for label, dev in (("capture", _alsa_capture_dev), ("playback", _alsa_playback_dev)):
        card = _alsa_card_name(dev)
        if not card:
            out[label] = {"card": "", "error": "no CARD= in device name"}
            continue
        try:
            r = subprocess.run(["amixer", "-c", card, "contents"],
                               capture_output=True, text=True, timeout=5)
            out[label] = {"card": card, "rc": r.returncode,
                          "contents": r.stdout or r.stderr}
        except Exception as e:
            out[label] = {"card": card, "error": repr(e)}
    try:
        r = subprocess.run(["arecord", "-l"], capture_output=True, text=True, timeout=5)
        out["arecord_l"] = r.stdout or r.stderr
    except Exception as e:
        out["arecord_l"] = repr(e)
    return out


@app.get("/radio/audio_device")
def get_audio_device():
    return {"capture": _alsa_capture_dev, "playback": _alsa_playback_dev}

@app.post("/radio/audio_device")
async def set_audio_device(request: Request):
    global _alsa_capture_dev, _alsa_playback_dev
    try:
        data = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON")
    capture = data.get("capture", "").strip()
    playback = data.get("playback", "").strip()
    if capture:
        _alsa_capture_dev = capture
    if playback:
        _alsa_playback_dev = playback
    # ffmpegは次回接続時に _ensure_ffmpeg() がデバイス変更を検知して自動再起動する
    # :50000 の音声プロセスにも伝えるためファイルへ保存する(別プロセスなので変数は共有されない)
    _save_alsa_devices()
    print(f"[audio_device] capture={_alsa_capture_dev} playback={_alsa_playback_dev}")
    return {"capture": _alsa_capture_dev, "playback": _alsa_playback_dev}

@app.post("/radio/audio_device_ft8")
async def set_audio_device_ft8(request: Request):
    try:
        data = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON")
    capture = data.get("capture", "").strip()
    _mgr_sub.capture_dev_override = capture
    _mgr_sub.stop()  # 次回接続時に新デバイスで再起動
    print(f"[audio_device_ft8] capture_override={capture!r}")
    return {"capture_ft8": capture}


@app.get("/radio/noise_reduction")
def get_noise_reduction():
    return {"level": _noise_reduction_level}

@app.post("/radio/noise_reduction")
def set_noise_reduction(level: int = Form(...)):
    global _noise_reduction_level
    level = max(0, min(5, level))
    _noise_reduction_level = level
    _mgr_rx._af = _build_rx_af(level)
    _mgr_rx.stop()  # AudioStreamServiceの自動再接続で新フィルターを適用
    return {"level": level}


@app.post("/radio/cw_decode")
def set_cw_decode(active: int = Form(...)):
    global _cw_decode_active
    _cw_decode_active = bool(active)
    # CWデコードのON/OFFでフィルター経路(afftdn無し/狭帯域)が変わるので常に再適用する
    _mgr_rx._af = _build_rx_af(_noise_reduction_level)
    _mgr_rx.stop()  # AudioStreamServiceの自動再接続で新フィルターを適用
    return {"cw_decode": _cw_decode_active}


@app.post("/radio/cw_nr")
def set_cw_nr(active: int = Form(...), center: int = Form(0)):
    """CWデコード中のNR(CWピッチ中心の狭帯域BPF) ON/OFF。centerは復号中トーンのHz(0=既定650)。
    afftdnを使わないので単コアPiでも音切れしない。(v3.34)"""
    global _cw_nr_narrow, _cw_nr_center
    _cw_nr_narrow = bool(active)
    _cw_nr_center = int(center)
    if _cw_decode_active:
        _mgr_rx._af = _build_rx_af(_noise_reduction_level)
        _mgr_rx.stop()
    return {"cw_nr": _cw_nr_narrow, "center": _cw_nr_center}


@app.post("/radio/audio_tx")
async def audio_tx(request: Request, rate: int = 8000, ptt: int = 0):
    global last_heartbeat, last_ptt_state, _ft8_tx_active
    if (_ft8_tx_active or _rtty_tx_active) and ptt == 0:
        print(f"[audio_tx] rejected (TX active): rate={rate}")
        raise HTTPException(status_code=503, detail="TX in progress")
    print(f"[audio_tx] connected rate={rate} ptt={ptt}")
    loop = asyncio.get_running_loop()
    if ptt:
        # FT8 TX: _mgr_sub(ffmpeg capture)を維持したまま aplay を起動する。
        # USBコーデックが全二重対応なら RX ffmpeg は TX 中も動作し続け、
        # TX完了後に即座に audio_sub へ再接続できる（~130ms）。
        # ffmpeg が ALSA 競合でクラッシュした場合は _ensure_sub_ready() が検出して再起動。
        # 自己CQデコード防止: TX中の capture は _mgr_sub.mute() で無音化。
        def _kill_procs_ft8():
            subprocess.run(["pkill", "-9", "direwolf"], capture_output=True)
            subprocess.run(["pkill", "-9", "aplay"],    capture_output=True)
            # _mgr_sub は kill しない — 全二重スタンバイ維持
            p = _mgr_rx.proc
            _mgr_rx.proc = None
            if p is not None:
                try: p.kill()
                except Exception: pass
                try: p.wait(timeout=0.5)
                except Exception: pass
            time.sleep(0.1)
        await loop.run_in_executor(None, _kill_procs_ft8)
        # TX中の自己CQデコード防止: ffmpegが動作中のため capture 出力を無音化
        _mgr_sub.mute(13.0)
        _ft8_tx_active = True
        result = await loop.run_in_executor(None, lambda: rigctl_cmd_priority("T 1"))
        if not result:
            _ft8_tx_active = False
            raise HTTPException(status_code=500, detail="rigctld timeout")
        radio_cache["tx"] = True
        last_ptt_state = 1
        last_heartbeat = time.time() + 60
        await asyncio.sleep(0.5)
        # aplay + plughw: 音声TXと同じ方式。plughwがレート変換を担当。
        # ffmpegをaplayに変更することでキャプチャffmpegとのALSA競合を解消
        proc = subprocess.Popen(
            ["aplay", "-D", _alsa_playback_dev, "-f", "S16_LE", "-r", str(rate), "-c", "1"],
            stdin=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0
        )
    else:
        # 音声TX: aplayで即時再生 (plughwが8000Hz→32000Hzを内部変換)
        # ffmpegはPi Zero上で起動に2〜3秒かかるためaplayを使う
        # captureプロセスを停止してALSAデバイス競合を防ぐ
        def _kill_voice():
            subprocess.run(["pkill", "-9", "direwolf"], capture_output=True)
            subprocess.run(["pkill", "-9", "aplay"],    capture_output=True)
            subprocess.run(["pkill", "-9", "arecord"],  capture_output=True)
            _mgr_sub.stop()
            p = _mgr_rx.proc
            _mgr_rx.proc = None
            if p is not None:
                try: p.kill()
                except Exception: pass
                try: p.wait(timeout=0.5)
                except Exception: pass
            time.sleep(0.3)
        await loop.run_in_executor(None, _kill_voice)
        _last_tx_debug["dev"] = _alsa_playback_dev
        _last_tx_debug["status"] = "aplay_starting"
        _last_tx_debug["chunks"] = 0
        card_name = _alsa_playback_dev.split("CARD=")[-1].split(",")[0] if "CARD=" in _alsa_playback_dev else "CODEC"
        proc = subprocess.Popen(
            ["aplay", "-D", _alsa_playback_dev, "-f", "S16_LE", "-r", str(rate), "-c", "1"],
            stdin=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0
        )
        await asyncio.sleep(0.05)
        if proc.poll() is not None:
            err = proc.stderr.read(512).decode(errors="replace").strip() if proc.stderr else ""
            print(f"[audio_tx] aplay died immediately rc={proc.returncode} err={err!r}")
            _last_tx_debug["status"] = "aplay_died_immediately"
            # IC-705 USB reset: restart rigctld in background, recovery handled in streaming loop
            if last_ptt_state == 1 and "No such device" in err:
                print(f"[{_ts()}] [audio_tx] USB reset detected — recovering in stream loop", flush=True)
                if current_model and current_cat and not _rigctld_restarting:
                    _trigger_rigctld_restart(
                        current_model, current_cat, current_baud, current_ptt, current_ptt_type,
                        release_ptt=False)
            proc = None
        else:
            _last_tx_debug["status"] = "aplay_running"
    # Streaming loop: keep reading chunks from client regardless of aplay state.
    # This holds the HTTP connection open during IC-705 USB reset recovery.
    # Chunks are written to aplay when running, discarded while CODEC is absent.
    chunk_count = 0
    _skip_check = 0  # rate-limit /proc/asound/cards checks to every N chunks
    try:
        async for chunk in request.stream():
            chunk_count += 1
            if proc is not None and proc.poll() is None:
                # aplay running — write chunk
                await loop.run_in_executor(None, proc.stdin.write, chunk)
            else:
                # RTTY TX 中は再生デバイスを RTTY に明け渡す(aplayを再起動せずチャンクは捨てる)
                if _rtty_tx_active:
                    continue
                # aplay dead or not started — check if CODEC is ready to (re)start
                _skip_check += 1
                if _skip_check < 8:
                    continue  # discard chunk, check CODEC less frequently
                _skip_check = 0
                try:
                    codec_ok = (card_name in open("/proc/asound/cards").read()
                                and bool(glob.glob("/dev/snd/controlC*")))
                except Exception:
                    codec_ok = False
                if codec_ok:
                    if proc is not None:
                        try: proc.stdin.close()
                        except Exception: pass
                        try: proc.wait(timeout=0.2)
                        except Exception: pass
                    proc = subprocess.Popen(
                        ["aplay", "-D", _alsa_playback_dev, "-f", "S16_LE", "-r", str(rate), "-c", "1"],
                        stdin=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0
                    )
                    await asyncio.sleep(0.05)
                    if proc.poll() is None:
                        print(f"[{_ts()}] [audio_tx] aplay restarted at chunk {chunk_count}", flush=True)
                        _last_tx_debug["status"] = "aplay_running"
                    else:
                        err2 = proc.stderr.read(256).decode(errors="replace").strip() if proc.stderr else ""
                        print(f"[{_ts()}] [audio_tx] aplay restart failed: {err2[:40]!r}", flush=True)
                        proc = None
                # discard this chunk regardless (next chunk will write if aplay started)
        if ptt == 0:
            _last_tx_debug["chunks"] = chunk_count
    except Exception as e:
        print(f"[audio_tx] stream: {type(e).__name__}: {e}")
    finally:
        if proc is not None:
            try:
                proc.stdin.close()
            except Exception:
                pass
            await loop.run_in_executor(None, proc.wait)
        if ptt:
            # TX完了後: ffmpegが生きていればmuteを解除して即座に再接続（~0ms）
            # ALSA競合でクラッシュしていた場合のみ再起動（最大1.5s）
            def _post_tx_restore():
                _mgr_sub._mute_until = 0.0  # 即座にunmute
                p = _mgr_sub.proc
                if p is not None and p.poll() is None:
                    print("[audio_tx] ffmpeg survived TX — instant standby")
                    return
                print("[audio_tx] ffmpeg died during TX — restarting")
                for _ in range(10):
                    proc = _mgr_sub.ensure("12000")
                    time.sleep(0.15)
                    if proc.poll() is None:
                        return
            loop.run_in_executor(None, _post_tx_restore)
            await loop.run_in_executor(None, lambda: rigctl_cmd("T 0"))
            radio_cache["tx"] = False
            last_ptt_state = 0
            last_heartbeat = time.time()
            _ft8_tx_active = False
        # APRS が動作中だった場合は direwolf を復旧
        if aprs_running:
            print("[audio_tx] restarting direwolf for APRS")
            await loop.run_in_executor(None, lambda: subprocess.run(
                ["sudo", "systemctl", "start", "direwolf"], capture_output=True))
        ae = ""
        if proc is not None:
            try: ae = proc.stderr.read(512).decode(errors="replace").strip()
            except: pass
            print(f"[audio_tx] done rc={proc.returncode} err={ae!r}")
        else:
            print(f"[audio_tx] done (proc=None, aplay never started)")
    return {"status": "ok"}


@app.get("/radio/audio_sub", dependencies=[])
async def audio_sub(request: Request, background_tasks: BackgroundTasks):
    """FT8/webft8 向け 12kHz PCM ストリーム。メイン音声と独立したプロセス+キューで動作。
    クエリパラメータ api_key も受け付ける（WebView JS fetch 互換）。"""
    from fastapi.responses import Response as FR
    qkey = request.query_params.get("api_key", "")
    hkey = request.headers.get("X-API-Key", "")
    if API_KEY and not (hmac.compare_digest(qkey or "", API_KEY) or hmac.compare_digest(hkey or "", API_KEY)):
        raise HTTPException(status_code=403, detail="Forbidden")

    rate = request.query_params.get("rate", "12000")
    if not rate.isdigit():
        rate = "12000"
    t0 = time.time()
    print(f"[audio_sub] connect rate={rate}")

    _mgr_rx.stop()  # メイン用ffmpegを停止してALSAを解放
    proc = _mgr_sub.ensure(rate)
    if proc.poll() is not None:
        print(f"[audio_sub] ffmpeg dead, restarting...")
        deadline = time.time() + 0.6
        while time.time() < deadline:
            if subprocess.run(["pgrep", "-x", "aplay"], capture_output=True).returncode != 0:
                break
            time.sleep(0.05)
        # ALSAデバイスリセットに最大1.5sかかるため150ms×10回リトライ
        for attempt in range(10):
            proc = _mgr_sub._start(rate)
            time.sleep(0.15)
            if proc.poll() is None:
                break
            print(f"[audio_sub] ffmpeg retry {attempt+1}/10")
        if proc.poll() is not None:
            time.sleep(0.05)  # stderr スレッドが最後の行を拾うのを待つ
            err = _mgr_sub.stderr_tail()
            print(f"[audio_sub] ffmpeg dead after retry: {err}")
            return FR(status_code=503, content=f"ffmpeg error: {err}")

    sid, q = _mgr_sub.subscribe(maxsize=64)
    print(f"[audio_sub] ready {time.time()-t0:.3f}s")

    def stream():
        try:
            while True:
                try:
                    data = q.get(timeout=0.2)
                    yield data
                except _queue.Empty:
                    if _mgr_sub.proc is not proc or proc.poll() is not None:
                        break
        except (GeneratorExit, BrokenPipeError, ConnectionResetError):
            pass

    def cleanup():
        _mgr_sub.unsubscribe(sid)
        print("[audio_sub] client disconnected")

    return StreamingResponse(stream(), media_type="application/octet-stream",
                             background=BackgroundTask(cleanup))


def _ft8_find_encoder(is_ft4: bool = False) -> "str | None":
    """ft8code バイナリを探す。見つからなければ None。"""
    prefix = "ft4code" if is_ft4 else "ft8code"
    candidates = [
        f"/usr/local/bin/{prefix}", f"/usr/bin/{prefix}",
        f"/usr/lib/wsjtx/{prefix}",
        f"/usr/lib/x86_64-linux-gnu/wsjtx/{prefix}",
        f"/usr/lib/aarch64-linux-gnu/wsjtx/{prefix}",
        f"/usr/lib/arm-linux-gnueabihf/wsjtx/{prefix}",
        f"/opt/wsjtx/bin/{prefix}", f"/opt/wsjtx/{prefix}",
    ]
    found = next((p for p in candidates if os.path.isfile(p)), None)
    if found:
        return found
    # which で探す
    r = subprocess.run(["which", prefix], capture_output=True, text=True)
    if r.returncode == 0 and r.stdout.strip():
        return r.stdout.strip()
    # find コマンドで全探索 (最終手段)
    try:
        r = subprocess.run(
            ["find", "/usr", "/opt", "/home", "-name", prefix, "-type", "f"],
            capture_output=True, text=True, timeout=15)
        hits = [l.strip() for l in r.stdout.splitlines() if l.strip()]
        if hits:
            return hits[0]
    except Exception:
        pass
    # ft8 prefix でも探す (ft8code が ft4code を兼ねる場合)
    if is_ft4:
        return _ft8_find_encoder(False)
    return None


def _ft8_parse_symbols(stdout: str, is_ft4: bool = False) -> "list | None":
    """ft8code/ft4code 出力からシンボルリストを取得する。失敗なら None。
    FT8: 79シンボル (0-7), FT4: 105シンボル (0-3)
    """
    max_sym  = 105 if is_ft4 else 79
    min_len  = 50
    lines = stdout.splitlines()

    # 戦略1: "Channel symbols" 行の後のデータ行を探す
    in_symbols_section = False
    for line in lines:
        low = line.lower()
        if "channel symbols" in low:
            in_symbols_section = True
            continue
        if in_symbols_section:
            stripped = line.strip()
            if not stripped:
                continue
            if stripped.startswith("Sync") or stripped.startswith("Data") or stripped.startswith("-"):
                continue
            digits = [c for c in stripped if c.isdigit()]
            if len(digits) >= min_len:
                return [int(d) for d in digits[:max_sym]]

    # 戦略2: スペース除去後に50文字以上の数字のみの行
    for line in lines:
        no_sp = line.strip().replace(" ", "")
        if len(no_sp) >= min_len and all(c.isdigit() for c in no_sp):
            return [int(c) for c in no_sp[:max_sym]]

    # 戦略3: "channel symbols" キーワード行に数字が続く場合
    for line in lines:
        low = line.lower()
        if any(kw in low for kw in ["channel symbols", "encoded message", "symbols:"]):
            after = line.split(":", 1)[-1].strip() if ":" in line else line
            digits = [c for c in after if c.isdigit()]
            if len(digits) >= min_len:
                return [int(d) for d in digits[:max_sym]]

    # 戦略4: スペース区切りトークンを整数として解釈
    max_val = 3 if is_ft4 else 7
    for line in lines:
        syms: list = []
        for tok in line.split():
            try:
                n = int(tok)
                if 0 <= n <= max_val:
                    syms.append(n)
            except ValueError:
                pass
        if len(syms) >= min_len:
            return syms[-max_sym:]

    return None


def _ft8_get_symbols(msg: str, is_ft4: bool = False) -> list:
    """ft8code/ft4code でチャンネルシンボルを取得する。
    FT8: 79シンボル (0-7)、FT4: 103シンボル (0-3)"""
    binary = _ft8_find_encoder(is_ft4)
    if binary is None:
        raise RuntimeError(
            "ft8code/ft4code が見つかりません。\n"
            "インストール: sudo apt install wsjtx\n"
            "場所確認: find /usr /opt -name ft8code 2>/dev/null")

    result = subprocess.run([binary, msg], capture_output=True, text=True, timeout=5)
    stdout = result.stdout
    print(f"[ft8code] binary={binary} rc={result.returncode} stdout={stdout!r}")

    symbols = _ft8_parse_symbols(stdout, is_ft4=is_ft4)
    if symbols is not None:
        return symbols

    raise RuntimeError(
        f"ft8code/ft4code がシンボルを出力しませんでした。\n"
        f"binary: {binary}\n"
        f"returncode: {result.returncode}\n"
        f"stdout: {stdout!r}\n"
        f"stderr: {result.stderr!r}")


def _ft8_symbols_to_pcm(symbols: list, audio_freq: int, rate: int, is_ft4: bool = False) -> bytes:
    """FT8/FT4 シンボル列を位相連続 S16_LE PCM に変換する。
    FT8: 8-FSK, 160ms/sym, 6.25Hz間隔, 79シンボル
    FT4: 4-FSK,  48ms/sym, 20.833Hz間隔, 105シンボル"""
    import numpy as np
    if is_ft4:
        symbol_period = 0.048        # 48ms / symbol (20.833 baud)
        tone_spacing  = 1.0 / 0.048  # 20.833 Hz
    else:
        symbol_period = 0.160        # 160ms / symbol (6.25 baud)
        tone_spacing  = 6.25         # Hz
    n_per_sym = int(round(rate * symbol_period))
    amplitude = int(14000 * _ft8_tx_gain)  # base 43% × gain multiplier
    parts: list = []
    phase = 0.0
    for sym in symbols:
        freq = audio_freq + sym * tone_spacing
        t = np.arange(n_per_sym) / rate
        wave = amplitude * np.sin(2 * np.pi * freq * t + phase)
        phase = (phase + 2 * np.pi * freq * n_per_sym / rate) % (2 * np.pi)
        parts.append(wave.astype(np.int16))
    if not parts:
        raise RuntimeError("symbol list is empty")
    return np.concatenate(parts).tobytes()


_FT8_ENCODE_BIN = next(
    (p for p in ["/usr/local/bin/ft8_encode",
                 str(_HOME_DIR / "fastapi" / "ft8_encode")]
     if os.path.isfile(p)), "")

_FT8_TX_AMPLITUDE = 14000  # ~43% of 32767 — ALC-safe level (settable via /ft8/set_tx_gain)
_ft8_tx_gain: float = 1.0  # multiplier applied to TX PCM (0.1 – 2.0)

# ─── Python FT4 エンコーダ (バイナリ不要) ────────────────────────────────────
_FT4_XOR_SEQ  = bytes([0x4A,0x5E,0x89,0xB4,0xB0,0x8A,0x79,0x55,0xBE,0x28])
_FT4_COSTAS   = [[0,1,3,2],[1,0,2,3],[2,3,1,0],[3,2,0,1]]
_FT4_GRAY     = [0,1,3,2]
_FT8_GRAY_INV = [0,1,3,2,6,4,5,7]  # FT8 tone → 3-bit value (逆 kFT8_Gray_map)
# kFTX_LDPC_generator[83][12] (ft8_lib/ft8/constants.c より)
_LDPC_G = (
    b'\x83\x29\xce\x11\xbf\x31\xea\xf5\x09\xf2\x7f\xc0',
    b'\x76\x1c\x26\x4e\x25\xc2\x59\x33\x54\x93\x13\x20',
    b'\xdc\x26\x59\x02\xfb\x27\x7c\x64\x10\xa1\xbd\xc0',
    b'\x1b\x3f\x41\x78\x58\xcd\x2d\xd3\x3e\xc7\xf6\x20',
    b'\x09\xfd\xa4\xfe\xe0\x41\x95\xfd\x03\x47\x83\xa0',
    b'\x07\x7c\xcc\xc1\x1b\x88\x73\xed\x5c\x3d\x48\xa0',
    b'\x29\xb6\x2a\xfe\x3c\xa0\x36\xf4\xfe\x1a\x9d\xa0',
    b'\x60\x54\xfa\xf5\xf3\x5d\x96\xd3\xb0\xc8\xc3\xe0',
    b'\xe2\x07\x98\xe4\x31\x0e\xed\x27\x88\x4a\xe9\x00',
    b'\x77\x5c\x9c\x08\xe8\x0e\x26\xdd\xae\x56\x31\x80',
    b'\xb0\xb8\x11\x02\x8c\x2b\xf9\x97\x21\x34\x87\xc0',
    b'\x18\xa0\xc9\x23\x1f\xc6\x0a\xdf\x5c\x5e\xa3\x20',
    b'\x76\x47\x1e\x83\x02\xa0\x72\x1e\x01\xb1\x2b\x80',
    b'\xff\xbc\xcb\x80\xca\x83\x41\xfa\xfb\x47\xb2\xe0',
    b'\x66\xa7\x2a\x15\x8f\x93\x25\xa2\xbf\x67\x17\x00',
    b'\xc4\x24\x36\x89\xfe\x85\xb1\xc5\x13\x63\xa1\x80',
    b'\x0d\xff\x73\x94\x14\xd1\xa1\xb3\x4b\x1c\x27\x00',
    b'\x15\xb4\x88\x30\x63\x6c\x8b\x99\x89\x49\x72\xe0',
    b'\x29\xa8\x9c\x0d\x3d\xe8\x1d\x66\x54\x89\xb0\xe0',
    b'\x4f\x12\x6f\x37\xfa\x51\xcb\xe6\x1b\xd6\xb9\x40',
    b'\x99\xc4\x72\x39\xd0\xd9\x7d\x3c\x84\xe0\x94\x00',
    b'\x19\x19\xb7\x51\x19\x76\x56\x21\xbb\x4f\x1e\x80',
    b'\x09\xdb\x12\xd7\x31\xfa\xee\x0b\x86\xdf\x6b\x80',
    b'\x48\x8f\xc3\x3d\xf4\x3f\xbd\xee\xa4\xea\xfb\x40',
    b'\x82\x74\x23\xee\x40\xb6\x75\xf7\x56\xeb\x5f\xe0',
    b'\xab\xe1\x97\xc4\x84\xcb\x74\x75\x71\x44\xa9\xa0',
    b'\x2b\x50\x0e\x4b\xc0\xec\x5a\x6d\x2b\xdb\xdd\x00',
    b'\xc4\x74\xaa\x53\xd7\x02\x18\x76\x16\x69\x36\x00',
    b'\x8e\xba\x1a\x13\xdb\x33\x90\xbd\x67\x18\xce\xc0',
    b'\x75\x38\x44\x67\x3a\x27\x78\x2c\xc4\x20\x12\xe0',
    b'\x06\xff\x83\xa1\x45\xc3\x70\x35\xa5\xc1\x26\x80',
    b'\x3b\x37\x41\x78\x58\xcc\x2d\xd3\x3e\xc3\xf6\x20',
    b'\x9a\x4a\x5a\x28\xee\x17\xca\x9c\x32\x48\x42\xc0',
    b'\xbc\x29\xf4\x65\x30\x9c\x97\x7e\x89\x61\x0a\x40',
    b'\x26\x63\xae\x6d\xdf\x8b\x5c\xe2\xbb\x29\x48\x80',
    b'\x46\xf2\x31\xef\xe4\x57\x03\x4c\x18\x14\x41\x80',
    b'\x3f\xb2\xce\x85\xab\xe9\xb0\xc7\x2e\x06\xfb\xe0',
    b'\xde\x87\x48\x1f\x28\x2c\x15\x39\x71\xa0\xa2\xe0',
    b'\xfc\xd7\xcc\xf2\x3c\x69\xfa\x99\xbb\xa1\x41\x20',
    b'\xf0\x26\x14\x47\xe9\x49\x0c\xa8\xe4\x74\xce\xc0',
    b'\x44\x10\x11\x58\x18\x19\x6f\x95\xcd\xd7\x01\x20',
    b'\x08\x8f\xc3\x1d\xf4\xbf\xbd\xe2\xa4\xea\xfb\x40',
    b'\xb8\xfe\xf1\xb6\x30\x77\x29\xfb\x0a\x07\x8c\x00',
    b'\x5a\xfe\xa7\xac\xcc\xb7\x7b\xbc\x9d\x99\xa9\x00',
    b'\x49\xa7\x01\x6a\xc6\x53\xf6\x5e\xcd\xc9\x07\x60',
    b'\x19\x44\xd0\x85\xbe\x4e\x7d\xa8\xd6\xcc\x7d\x00',
    b'\x25\x1f\x62\xad\xc4\x03\x2f\x0e\xe7\x14\x00\x20',
    b'\x56\x47\x1f\x87\x02\xa0\x72\x1e\x00\xb1\x2b\x80',
    b'\x2b\x8e\x49\x23\xf2\xdd\x51\xe2\xd5\x37\xfa\x00',
    b'\x6b\x55\x0a\x40\xa6\x6f\x47\x55\xde\x95\xc2\x60',
    b'\xa1\x8a\xd2\x8d\x4e\x27\xfe\x92\xa4\xf6\xc8\x40',
    b'\x10\xc2\xe5\x86\x38\x8c\xb8\x2a\x3d\x80\x75\x80',
    b'\xef\x34\xa4\x18\x17\xee\x02\x13\x3d\xb2\xeb\x00',
    b'\x7e\x9c\x0c\x54\x32\x5a\x9c\x15\x83\x6e\x00\x00',
    b'\x36\x93\xe5\x72\xd1\xfd\xe4\xcd\xf0\x79\xe8\x60',
    b'\xbf\xb2\xce\xc5\xab\xe1\xb0\xc7\x2e\x07\xfb\xe0',
    b'\x7e\xe1\x82\x30\xc5\x83\xcc\xcc\x57\xd4\xb0\x80',
    b'\xa0\x66\xcb\x2f\xed\xaf\xc9\xf5\x26\x64\x12\x60',
    b'\xbb\x23\x72\x5a\xbc\x47\xcc\x5f\x4c\xc4\xcd\x20',
    b'\xde\xd9\xdb\xa3\xbe\xe4\x0c\x59\xb5\x60\x9b\x40',
    b'\xd9\xa7\x01\x6a\xc6\x53\xe6\xde\xcd\xc9\x03\x60',
    b'\x9a\xd4\x6a\xed\x5f\x70\x7f\x28\x0a\xb5\xfc\x40',
    b'\xe5\x92\x1c\x77\x82\x25\x87\x31\x6d\x7d\x3c\x20',
    b'\x4f\x14\xda\x82\x42\xa8\xb8\x6d\xca\x73\x35\x20',
    b'\x8b\x8b\x50\x7a\xd4\x67\xd4\x44\x1d\xf7\x70\xe0',
    b'\x22\x83\x1c\x9c\xf1\x16\x94\x67\xad\x04\xb6\x80',
    b'\x21\x3b\x83\x8f\xe2\xae\x54\xc3\x8e\xe7\x18\x00',
    b'\x5d\x92\x6b\x6d\xd7\x1f\x08\x51\x81\xa4\xe1\x20',
    b'\x66\xab\x79\xd4\xb2\x9e\xe6\xe6\x95\x09\xe5\x60',
    b'\x95\x81\x48\x68\x2d\x74\x8a\x38\xdd\x68\xba\xa0',
    b'\xb8\xce\x02\x0c\xf0\x69\xc3\x2a\x72\x3a\xb1\x40',
    b'\xf4\x33\x1d\x6d\x46\x16\x07\xe9\x57\x52\x74\x60',
    b'\x6d\xa2\x3b\xa4\x24\xb9\x59\x61\x33\xcf\x9c\x80',
    b'\xa6\x36\xbc\xbc\x7b\x30\xc5\xfb\xea\xe6\x7f\xe0',
    b'\x5c\xb0\xd8\x6a\x07\xdf\x65\x4a\x90\x89\xa2\x00',
    b'\xf1\x1f\x10\x68\x48\x78\x0f\xc9\xec\xdd\x80\xa0',
    b'\x1f\xbb\x53\x64\xfb\x8d\x2c\x9d\x73\x0d\x5b\xa0',
    b'\xfc\xb8\x6b\xc7\x0a\x50\xc9\xd0\x2a\x5d\x03\x40',
    b'\xa5\x34\x43\x30\x29\xea\xc1\x5f\x32\x2e\x34\xc0',
    b'\xc9\x89\xd9\xc7\xc3\xd3\xb8\xc5\x5d\x75\x13\x00',
    b'\x7b\xb3\x8b\x2f\x01\x86\xd4\x66\x43\xae\x96\x20',
    b'\x26\x44\xeb\xad\xeb\x44\xb9\x46\x7d\x1f\x42\xc0',
    b'\x60\x8c\xc8\x57\x59\x4b\xfb\xb5\x5d\x69\x60\x00',
)


def _ftx_add_crc(p10: bytes) -> bytes:
    """payload 10バイト(77ビット) → a91 12バイト(91ビット、CRC付き)"""
    POLY, W, TOP = 0x2757, 14, 1 << 13
    a = bytearray(12)
    a[:10] = p10
    a[9] &= 0xF8  # ビット77-79 をクリア
    r = 0; ib = 0
    for b in range(82):  # 96 - 14 = 82ビット
        if b % 8 == 0:
            r ^= (a[ib] << (W - 8)); ib += 1
        r = (r << 1) ^ POLY if r & TOP else r << 1
    r &= (TOP << 1) - 1
    a[9] |= (r >> 11) & 7
    a[10] = (r >> 3) & 0xFF
    a[11] = (r << 5) & 0xFF
    return bytes(a)


def _ldpc_enc174(a91: bytes) -> bytes:
    """91ビット a91 → 174ビット LDPC codeword (22バイト)"""
    cw = bytearray(22)
    cw[:12] = a91
    cm = 0x10; ci = 11  # パリティ開始: bit91 = byte11 mask 0x10
    for row in _LDPC_G:
        ns = 0
        for j in range(12):
            x = a91[j] & row[j]
            x ^= x >> 4; x ^= x >> 2; x ^= x >> 1
            ns ^= x
        if ns & 1:
            cw[ci] |= cm
        cm >>= 1
        if not cm:
            cm = 0x80; ci += 1
    return bytes(cw)


def _ft8_pcm_to_syms(pcm_bytes: bytes, audio_freq: float, rate: int = 48000) -> "list | None":
    """FT8 PCM → 79 FT8 シンボル（FFT peak 検波）。
    FT8 の tone spacing = 1/0.160 = 6.25 Hz が FFT bin に完全整合するため精度高。"""
    import numpy as np
    pcm = np.frombuffer(pcm_bytes, dtype=np.int16).astype(np.float32)
    sps = int(0.160 * rate + 0.5)
    if len(pcm) < 79 * sps:
        return None
    segs = pcm[:79 * sps].reshape(79, sps)
    mag = np.abs(np.fft.rfft(segs, axis=1))   # shape (79, sps//2+1)
    tone_space = 1.0 / 0.160
    bins = [int(round((audio_freq + t * tone_space) * sps / rate)) for t in range(8)]
    if any(b >= mag.shape[1] for b in bins):
        return None
    return np.argmax(mag[:, bins], axis=1).tolist()


def _ft4_get_syms_python(msg: str) -> "list | None":
    """FT4 シンボルを取得。
    優先順: mode=3テキスト → mode=2テキスト/ft8code → FT8 PCM デモジュレーション → FT4変換。
    古いバイナリ（PCM のみ出力）でも PCM デモジュレーション経由で動作する。"""
    # ① ft8_encode バイナリ mode=3 (FT4シンボルをテキスト出力、新バイナリのみ)
    if os.path.isfile(_FT8_ENCODE_BIN):
        try:
            r = subprocess.run(
                [_FT8_ENCODE_BIN, msg, "1500", "48000", "3"],
                capture_output=True, timeout=5)
            if r.returncode == 0 and r.stdout:
                try:
                    out = r.stdout.decode("ascii")
                    syms = [int(x) for x in out.split() if x.isdigit()]
                    if len(syms) == 105 and all(0 <= s <= 3 for s in syms):
                        print(f"[ft4_py] OK 105 tones via binary mode=3")
                        return syms
                    print(f"[ft4_py] binary mode=3 unexpected: {out!r}")
                except UnicodeDecodeError:
                    print(f"[ft4_py] binary mode=3: old binary (PCM output) — skip text parse")
            else:
                print(f"[ft4_py] binary mode=3 failed: rc={r.returncode}")
        except Exception as e:
            print(f"[ft4_py] binary mode=3 error: {e}")

    # ② FT8 シンボル取得: mode=2テキスト / ft8code / FT8 PCM デモジュレーション
    s79 = None
    _ft8_pcm_raw = None  # PCM デモジュレーション用バイト列

    # mode=2 テキスト出力試行（新バイナリ）または PCM を保存（旧バイナリ）
    if os.path.isfile(_FT8_ENCODE_BIN):
        try:
            r = subprocess.run(
                [_FT8_ENCODE_BIN, msg, "1500", "48000", "2"],
                capture_output=True, timeout=5)
            if r.returncode == 0 and r.stdout:
                try:
                    out = r.stdout.decode("ascii")
                    tmp = [int(x) for x in out.split() if x.isdigit()]
                    if len(tmp) >= 79 and all(0 <= t <= 7 for t in tmp[:79]):
                        s79 = tmp[:79]
                        print(f"[ft4_py] FT8 symbols from binary mode=2")
                    else:
                        print(f"[ft4_py] binary mode=2 unexpected: {out!r}")
                except UnicodeDecodeError:
                    # 旧バイナリ: FT8 PCM を出力。デモジュレーションに流用
                    print(f"[ft4_py] binary mode=2: old binary PCM → will demodulate")
                    _ft8_pcm_raw = r.stdout
        except Exception as e:
            print(f"[ft4_py] binary mode=2 error: {e}")

    # ft8code
    if s79 is None:
        try:
            binary = _ft8_find_encoder(False)
            if binary:
                r = subprocess.run([binary, msg], capture_output=True, text=True, timeout=5)
                s79 = _ft8_parse_symbols(r.stdout, is_ft4=False)
                if s79:
                    print(f"[ft4_py] FT8 symbols from ft8code")
        except Exception:
            pass

    # ③ FT8 PCM デモジュレーション（旧バイナリ対応の確実フォールバック）
    if s79 is None:
        # PCM がなければ FT8 モード (is_ft4=0) で取得
        if _ft8_pcm_raw is None and os.path.isfile(_FT8_ENCODE_BIN):
            try:
                r = subprocess.run(
                    [_FT8_ENCODE_BIN, msg, "1500", "48000", "0"],
                    capture_output=True, timeout=10)
                n_exp = 79 * int(0.160 * 48000 + 0.5)
                if r.returncode == 0 and abs(len(r.stdout) // 2 - n_exp) < n_exp * 0.1:
                    _ft8_pcm_raw = r.stdout
                    print(f"[ft4_py] FT8 PCM from binary mode=0")
            except Exception as e:
                print(f"[ft4_py] binary mode=0 error: {e}")
        if _ft8_pcm_raw:
            s79 = _ft8_pcm_to_syms(_ft8_pcm_raw, 1500.0, 48000)
            if s79:
                print(f"[ft4_py] FT8 symbols via PCM demodulation → {len(s79)} syms")

    if s79 is None or len(s79) < 79:
        print(f"[ft4_py] FT8 symbols unavailable — FT4 TX not possible")
        return None

    # FT8 シンボル → FT4 シンボル変換
    try:
        data_pos = list(range(7, 36)) + list(range(43, 72))
        bits = [0] * 174; bi = 0
        for p in data_pos:
            v = _FT8_GRAY_INV[s79[p]]
            bits[bi] = (v >> 2) & 1; bits[bi+1] = (v >> 1) & 1; bits[bi+2] = v & 1
            bi += 3
        cw8 = bytearray(22)
        for i, b in enumerate(bits):
            if b:
                cw8[i // 8] |= 0x80 >> (i % 8)
        a91 = bytearray(12)
        for i in range(91):
            if cw8[i // 8] & (0x80 >> (i % 8)):
                a91[i // 8] |= 0x80 >> (i % 8)
        p10 = bytearray(a91[:10]); p10[9] &= 0xF8
        xp = bytes(p10[i] ^ _FT4_XOR_SEQ[i] for i in range(10))
        a91f = _ftx_add_crc(xp)
        cw4 = _ldpc_enc174(a91f)
        tones = [0] * 105; mask = 0x80; ib = 0
        for i in range(105):
            if i == 0 or i == 104:
                tones[i] = 0
            elif 1 <= i < 5:
                tones[i] = _FT4_COSTAS[0][i - 1]
            elif 34 <= i < 38:
                tones[i] = _FT4_COSTAS[1][i - 34]
            elif 67 <= i < 71:
                tones[i] = _FT4_COSTAS[2][i - 67]
            elif 100 <= i < 104:
                tones[i] = _FT4_COSTAS[3][i - 100]
            else:
                b = 0
                if cw4[ib] & mask: b |= 2
                mask >>= 1
                if not mask: mask = 0x80; ib += 1
                if cw4[ib] & mask: b |= 1
                mask >>= 1
                if not mask: mask = 0x80; ib += 1
                tones[i] = _FT4_GRAY[b]
        print(f"[ft4_py] OK 105 FT4 tones via FT8→FT4 conversion")
        return tones
    except Exception as e:
        print(f"[ft4_py] FT8→FT4 conversion error: {e}")
        return None


def _ft8_get_pcm(msg: str, audio_freq: int, rate: int = 12000, is_ft4: bool = False) -> bytes:
    """FT8/FT4 メッセージから S16_LE PCM を生成する。
    ft8_encode (PCM直接出力) が使えればそちらを優先。
    長さが期待値と合わない場合は Python FT4 エンコーダにフォールバック。"""
    import numpy as np
    if os.path.isfile(_FT8_ENCODE_BIN):
        result = subprocess.run(
            [_FT8_ENCODE_BIN, msg, str(float(audio_freq)), str(rate), "1" if is_ft4 else "0"],
            capture_output=True, timeout=10
        )
        if result.returncode == 0 and result.stdout:
            pcm = np.frombuffer(result.stdout, dtype=np.int16).astype(np.float32)
            n_exp = (105 * int(0.048 * rate + 0.5) if is_ft4
                     else 79 * int(0.160 * rate + 0.5))
            if abs(len(pcm) - n_exp) < n_exp * 0.3:
                peak = np.abs(pcm).max()
                if peak > 0:
                    pcm = pcm * (_FT8_TX_AMPLITUDE * _ft8_tx_gain / peak)
                return np.clip(pcm, -32767, 32767).astype(np.int16).tobytes()
            print(f"[ft8_encode] length mismatch: exp≈{n_exp} got {len(pcm)} is_ft4={is_ft4}")
        else:
            print(f"[ft8_encode] rc={result.returncode} stderr={result.stderr!r}")
    if is_ft4:
        syms = _ft4_get_syms_python(msg)
        if syms is not None:
            return _ft8_symbols_to_pcm(syms, audio_freq, rate, is_ft4=True)
        print("[ft8_get_pcm] FT4 Python encoder failed, falling back to legacy")
    return _ft8_symbols_to_pcm(_ft8_get_symbols(msg, is_ft4), audio_freq, rate, is_ft4=is_ft4)


class FT8TxRequest(BaseModel):
    msg: str
    audio_freq: int = 1500
    rate: int = 48000
    is_ft4: bool = False
    tx_mode: str = ""   # "even"/"odd"/""  (空=自動選択なし)


@app.post("/radio/ft8_tx")
async def ft8_tx(req: FT8TxRequest):
    """FT8/FT4 メッセージを送信する。ft8code で PCM 生成 → aplay で送出。"""
    global tx_in_progress, _ft8_tx_active
    if tx_in_progress or _ft8_tx_active:
        raise HTTPException(status_code=409, detail="TX in progress")
    tx_in_progress = True
    _ft8_tx_active = True
    _mgr_sub.mute(14.0)
    loop = asyncio.get_running_loop()
    try:
        # PCM生成: ft8_encode (PCM直接) または ft8code (シンボル経由)
        try:
            pcm_data = await loop.run_in_executor(
                None,
                lambda: _ft8_get_pcm(req.msg, req.audio_freq, req.rate, req.is_ft4)
            )
        except RuntimeError as enc_err:
            raise HTTPException(status_code=500, detail=str(enc_err))

        def _play():
            # 次のFT8ピリオド境界まで精密待機
            # PCM生成に時間がかかるため、ここで再計算する
            period_s = 7.5 if req.is_ft4 else FT8_PERIOD_S
            now = time.time()
            # ピリオド境界から 0.5s 以内なら現在ピリオドをそのまま使う
            # （0.001s 後に呼ばれた場合に +1 で次へ飛ばすバグを防ぐ）
            current_start = int(now / period_s) * period_s
            if now - current_start < 0.5:
                next_start = current_start
            else:
                next_start = current_start + period_s

            # tx_mode 決定優先順: リクエスト > QSO > AUTO TX > なし
            if req.tx_mode in ("even", "odd"):
                tx_mode = req.tx_mode
            elif _qso.get("active"):
                tx_mode = _qso["tx_mode"]
            elif _auto_tx.get("active"):
                tx_mode = _auto_tx["mode"]
            else:
                tx_mode = None
            if tx_mode:
                ft_period  = 7.5 if req.is_ft4 else FT8_PERIOD_S
                max_search = 8   if req.is_ft4 else 4   # FT4:8×7.5s=60s, FT8:4×15s=60s
                for _ in range(max_search):
                    if req.is_ft4:
                        pn = int((next_start % 60) / 7.5)  # 0-7
                    else:
                        pn = (int(next_start) % 60 // 15) % 4  # 0-3
                    is_even = pn % 2 == 0
                    if (tx_mode == "even" and is_even) or (tx_mode == "odd" and not is_even):
                        break
                    next_start += ft_period

            wait_sec = next_start - time.time()
            utc_at_tx = int(next_start) % 60
            print(f"[ft8_tx] waiting {wait_sec:.2f}s → TX at UTC {utc_at_tx}s (tx_mode={tx_mode})")
            # tx_pending を待機前に送信 → Androidのリストにすぐ表示（Auto TXと同じ動作）
            _ft8_broadcast({"type": "tx_pending",
                            "msg": req.msg,
                            "wait_sec": round(wait_sec, 1),
                            "utc_at_tx": utc_at_tx})
            subprocess.run(["pkill", "-9", "direwolf"], capture_output=True)
            subprocess.run(["pkill", "-9", "aplay"], capture_output=True)
            if wait_sec > 0.15:
                time.sleep(wait_sec - 0.10)
            while time.time() < next_start:
                time.sleep(0.002)
            _tx_start = time.time()
            print(f"[ft8_tx] TX START {time.strftime('%H:%M:%S', time.localtime(_tx_start))}.{int(_tx_start*1000)%1000:03d}  UTC={int(_tx_start)%60}s dev={_alsa_playback_dev}")
            rigctl_cmd("T 1")
            time.sleep(0.3)
            proc = subprocess.Popen(
                ["aplay", "-D", _alsa_playback_dev,
                 "-f", "S16_LE", "-r", str(req.rate), "-c", "1"],
                stdin=subprocess.PIPE, stderr=subprocess.PIPE
            )
            time.sleep(0.05)
            if proc.poll() is not None:
                err = proc.stderr.read(512).decode(errors="replace").strip()
                rigctl_cmd("T 0")
                raise RuntimeError(f"aplay died immediately rc={proc.returncode}: {err or 'no stderr'}")
            try:
                proc.stdin.write(pcm_data)
                proc.stdin.close()
            except BrokenPipeError:
                err = proc.stderr.read(512).decode(errors="replace").strip()
                rc = proc.wait(timeout=3)
                rigctl_cmd("T 0")
                raise RuntimeError(f"aplay BrokenPipe rc={rc}: {err or 'no stderr'}")
            proc.wait(timeout=20)
            rigctl_cmd("T 0")

        await loop.run_in_executor(None, _play)
        return {"status": "ok", "msg": req.msg, "is_ft4": req.is_ft4}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        try: rigctl_cmd("T 0")
        except Exception: pass
        tx_in_progress = False
        _ft8_tx_active = False



@app.get("/ft8/debug_encode")
async def ft8_debug_encode(msg: str = Query(default="CQ TEST JA1XXX")):
    """ft8code の生出力とシンボル解析結果を返す（TX診断用）。"""
    binary = _ft8_find_encoder(False)
    if binary is None:
        # find コマンドで全探索して結果を表示
        fr = subprocess.run(["find", "/usr", "/opt", "/home", "-name", "ft8code"],
                            capture_output=True, text=True, timeout=10)
        return {"error": "ft8code not found",
                "find_output": fr.stdout,
                "hint": "sudo apt install wsjtx"}
    try:
        r = subprocess.run([binary, msg], capture_output=True, text=True, timeout=5)
        syms = _ft8_parse_symbols(r.stdout)
        return {
            "binary": binary,
            "stdout": r.stdout,
            "stderr": r.stderr,
            "returncode": r.returncode,
            "parsed_symbols": syms,
            "symbol_count": len(syms) if syms else 0,
        }
    except Exception as e:
        return {"error": str(e)}


class StartQsoRequest(BaseModel):
    first_msg: str           # step1: DX MY GRID
    dx_call: str
    my_call: str
    tx_mode: str = "odd"
    audio_freq: int = 1500
    initial_state: int = 0   # 0=step1, 2=step2, 4=step3, 6=step4(73)
    step_snr_msg: str = ""   # step1後のSNRのみステップ (Rなし。空なら省略してstep2へ直行)
    step2_msg: str = ""      # step2: DX MY R-NN (空なら step1 返信後すぐ step3 へ)
    step3_msg: str = ""      # step3: DX MY RR73 (空なら自動生成)
    step4_msg: str = ""      # step4: DX MY 73   (空なら step3 後に done)


@app.post("/ft8/start_qso")
async def ft8_start_qso(req: StartQsoRequest):
    """QSOシーケンスを開始する。デコード一覧タップ時にAndroidから呼ばれる。"""
    global _qso, _ft8_my_call
    dx = req.dx_call.upper()
    me = req.my_call.upper()
    if me:
        _ft8_my_call = me
    step3 = req.step3_msg.upper() if req.step3_msg else f"{dx} {me} RR73"
    step4 = req.step4_msg.upper() if req.step4_msg else ""
    # initial_state: 0→step1(state=1), 1→step2snr(state=2), 2→step2(state=3), 4→step3(state=5), 6→step4(state=6)
    wait_state = {0: 1, 1: 2, 2: 3, 4: 5, 6: 6}.get(req.initial_state, 1)
    first_tx = {1: req.first_msg.upper(),
                2: req.step_snr_msg.upper() if req.step_snr_msg else (req.step2_msg.upper() if req.step2_msg else step3),
                3: req.step2_msg.upper() if req.step2_msg else step3,
                5: step3,
                6: step4 if step4 else f"{dx} {me} 73"}.get(wait_state, req.first_msg.upper())
    # extract snr_sent from step2_msg (e.g. "JA1XXX JA2YYY R-05" → "R-05")
    step2_parts = (req.step2_msg or "").upper().split()
    snr_sent = step2_parts[2] if len(step2_parts) >= 3 else ""
    _qso["active"]    = True
    _qso["dx_call"]   = dx
    _qso["my_call"]   = me
    _qso["state"]     = wait_state
    _qso["tx_mode"]   = req.tx_mode
    _qso["audio_freq"]= req.audio_freq
    _qso["step1_msg"]   = req.first_msg.upper()
    _qso["step_snr_msg"]= req.step_snr_msg.upper()
    _qso["step2_msg"]   = req.step2_msg.upper()
    _qso["step3_msg"]   = step3
    _qso["step4_msg"]   = step4
    _qso["cq_sender"]   = False   # DX指定呼び出し側: R-SNR使用
    _qso["next_msg"]  = first_tx
    _qso["snr_rcvd"]   = ""
    _qso["snr_sent"]   = snr_sent
    # step2_msg の R±NN から初期ピーク値を設定（以降は改善時のみ更新）
    _initial_peak = None
    if len(step2_parts) >= 3 and step2_parts[2].startswith("R"):
        try: _initial_peak = int(step2_parts[2][1:])
        except ValueError: pass
    _qso["snr_dx_peak"] = _initial_peak
    # AUTO TX を有効化して送信を委譲
    _auto_tx["active"]    = True
    _auto_tx["msg"]       = first_tx
    _auto_tx["mode"]      = req.tx_mode
    _auto_tx["audio_freq"]= req.audio_freq
    _ft8_broadcast({"type": "qso_state", "state": "pending",
                    "dx_call": dx, "msg": first_tx, "tx_mode": req.tx_mode})
    return {"ok": True, **_qso}


@app.post("/ft8/cancel_qso")
async def ft8_cancel_qso():
    """QSOシーケンスをキャンセルする。"""
    global _qso
    _qso["active"]      = False
    _qso["state"]       = 4
    _auto_tx["active"]  = False
    return {"ok": True}


@app.post("/ft8/auto_tx")
async def ft8_set_auto_tx(request: Request):
    """AutoTXの有効/無効とパラメータを設定する。"""
    global _auto_tx
    body = await request.json()
    _auto_tx["active"]     = bool(body.get("active", False))
    _auto_tx["mode"]       = str(body.get("mode", "even"))
    _auto_tx["msg"]        = str(body.get("msg", ""))
    _auto_tx["audio_freq"] = int(body.get("audio_freq", 1500))
    return {**_auto_tx}


@app.get("/ft8/auto_tx")
async def ft8_get_auto_tx():
    """AutoTX現在の状態を返す。"""
    return {**_auto_tx}


@app.post("/ft8/cq_auto")
async def ft8_cq_auto(request: Request):
    """CQ AUTO モード: CQ送信→DX返信で自動QSO→73後にCQ再開。"""
    global _cq_auto, _auto_tx, _qso, _ft8_my_call
    body = await request.json()
    if not body.get("active"):
        _cq_auto["active"] = False
        _auto_tx["active"] = False
        _qso["active"] = False
        return {"ok": True, "active": False}
    _cq_auto["active"]    = True
    _cq_auto["msg"]       = str(body.get("msg", ""))
    _cq_auto["mode"]      = str(body.get("mode", "even"))
    _cq_auto["audio_freq"]= int(body.get("audio_freq", 1500))
    _cq_auto["my_call"]   = str(body.get("my_call", ""))
    _cq_auto["my_grid"]   = str(body.get("my_grid", ""))
    if _cq_auto["my_call"]:
        _ft8_my_call = _cq_auto["my_call"].upper()
    _auto_tx["active"]    = True
    _auto_tx["msg"]       = _cq_auto["msg"]
    _auto_tx["mode"]      = _cq_auto["mode"]
    _auto_tx["audio_freq"]= _cq_auto["audio_freq"]
    print(f"[cq_auto] start: {_cq_auto['msg']} mode={_cq_auto['mode']}")
    return {**_cq_auto}


# ---------- CW send_morse (Hamlib rigctld b コマンド) ----------

_morse_sock: "Optional[socket.socket]" = None  # type: ignore
_morse_lock = threading.Lock()
_morse_sending = False
_morse_stop_event = threading.Event()


def _abort_morse():
    """実行中の send_morse を中断する（待機を即座に解除して PTT OFF）"""
    global _morse_sock, _morse_sending
    _morse_stop_event.set()
    with _morse_lock:
        s = _morse_sock
        _morse_sock = None
    if s:
        try:
            s.close()
        except Exception:
            pass
        # \stop_morse: hamlib が内部キーヤーのバッファをクリアする (FT-991 等の New CAT では KY; を送出)
        # IC-7300はこのコマンドをサポートしないため2秒タイムアウトになる。
        # アクティブなセッション停止時のみ呼ぶ（初回送信時はスキップ）。
        try:
            rigctl_cmd_priority("\\stop_morse")
        except Exception:
            pass
    _morse_sending = False


@app.post("/cw/send_morse")
def cw_send_morse(text: str = Form(...), wpm: int = Form(default=20),
                  ptt_poll: bool = Form(default=False)):
    """テキストを Hamlib send_morse (rigctld b コマンド) で CW 送信する。
    ptt_poll=True: PTT状態をポーリングして終了検出 (FT-991等 CAT PTT対応リグ向け)
    ptt_poll=False: 推定送信時間で待機 (IC-7300/IC-705等 内部キーヤー向け・デフォルト)"""
    global _morse_sock, _morse_sending
    text = text.strip().upper()
    if not text:
        raise HTTPException(status_code=400, detail="empty text")
    _abort_morse()
    _morse_stop_event.clear()
    _morse_sending = True

    # 送信推定時間を計算 (PARIS 標準: dit = 1200/wpm ms)
    # 1文字平均 13 dit (エレメント+符号間) + 語間スペースは +4 dit
    n_chars = sum(1 for c in text if c != ' ')
    n_spaces = text.count(' ')
    est_dits = n_chars * 13 + n_spaces * 4 + 5
    est_sec = est_dits * 1200.0 / max(5, min(60, wpm)) / 1000 + 0.3

    # CW TX は常に RIG(CI-V) PTT を使用: IC-7300 等 RTS では動作しないため
    _cw_orig_ptt = current_ptt_type
    _cw_switch = (
        current_ptt_type.upper() not in ("RIG", "CAT") and
        bool(current_model) and bool(current_cat) and not _rigctld_restarting
    )

    def worker():
        global _morse_sock, _morse_sending
        sock = None
        _shifted_rx_freq = None
        try:
            if _cw_switch:
                print(f"[{_ts()}] [morse] switching to RIG PTT for CW TX (was {_cw_orig_ptt})", flush=True)
                start_rigctld(current_model, current_cat, current_baud, current_ptt, "RIG")
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(30.0)
            sock.connect(("localhost", 4532))
            with _morse_lock:
                _morse_sock = sock
            if _cw_tx_shift_hz != 0:
                _rx = radio_cache.get("freq", 0)
                if _rx:
                    _shifted_rx_freq = _rx
                    _tx_f = _rx + _cw_tx_shift_hz
                    rigctl_cmd(f"F {_tx_f}")
                    print(f"[{_ts()}] [morse] VFO shift {_rx}->{_tx_f} ({_cw_tx_shift_hz:+d}Hz)", flush=True)
            # リグ内蔵キーヤーの速度をアプリの WPM スライダー値に合わせる。
            # Hamlib の b (send_morse) はリグの現在のキーヤー速度で打鍵するため、
            # ここで L KEYSPD を送らないとスライダーを動かしても送信速度が変わらない。
            _wpm = max(5, min(60, int(wpm)))
            _ks = rigctl_cmd(f"L KEYSPD {_wpm}")
            print(f"[{_ts()}] [morse] set KEYSPD {_wpm} -> '{_ks[:40]}'", flush=True)
            radio_cache["rig_wpm"] = _wpm
            sock.sendall(f"b {text}\n".encode())
            try:
                sock.recv(4096)
            except Exception:
                pass
            if ptt_poll:
                # PTTポーリングモード: PTT=1を確認してからPTT=0になるまで待機
                # FT-991等、内部キーヤー中にCAT get_pttが正しく動作するリグ向け
                print(f"[{_ts()}] [morse] ptt_poll mode, waiting TX start (wpm={wpm} chars={n_chars})", flush=True)
                tx_started = False
                for _ in range(30):  # 最大3秒待機
                    if _morse_stop_event.is_set():
                        break
                    ptt_raw = rigctl_cmd_priority("t")
                    if ptt_raw and ptt_raw.strip().split("\n")[0].strip() == "1":
                        tx_started = True
                        break
                    _morse_stop_event.wait(timeout=0.1)
                if tx_started:
                    print(f"[{_ts()}] [morse] TX started, polling until PTT=0, deadline={est_sec+5.0:.1f}s", flush=True)
                    deadline = time.time() + est_sec + 5.0
                    while time.time() < deadline and not _morse_stop_event.is_set():
                        ptt_raw = rigctl_cmd_priority("t")
                        if ptt_raw and ptt_raw.strip().split("\n")[0].strip() == "0":
                            print(f"[{_ts()}] [morse] TX ended (PTT=0)", flush=True)
                            break
                        _morse_stop_event.wait(timeout=0.5)
                    else:
                        print(f"[{_ts()}] [morse] TX stopped by user", flush=True)
                else:
                    print(f"[{_ts()}] [morse] TX never started, falling back to time wait", flush=True)
                    _morse_stop_event.wait(timeout=est_sec)
            else:
                # 時間ベースモード: 推定送信時間だけ待機
                # IC-7300/IC-705等、内部キーヤー中にCAT PTTが0を返すリグ向け
                print(f"[{_ts()}] [morse] time mode, waiting {est_sec:.1f}s (wpm={wpm} chars={n_chars})", flush=True)
                _morse_stop_event.wait(timeout=est_sec)
                if _morse_stop_event.is_set():
                    print(f"[{_ts()}] [morse] TX stopped by user", flush=True)
                else:
                    print(f"[{_ts()}] [morse] TX complete (estimated)", flush=True)
        except Exception as e:
            print(f"[{_ts()}] [morse] error: {e}", flush=True)
        finally:
            with _morse_lock:
                if _morse_sock is sock:
                    _morse_sock = None
            if sock:
                try:
                    sock.close()
                except Exception:
                    pass
            try:
                rigctl_cmd_priority("\\stop_morse")
            except Exception:
                pass
            if _shifted_rx_freq:
                try:
                    rigctl_cmd(f"F {_shifted_rx_freq}")
                    radio_cache["freq"] = _shifted_rx_freq
                    print(f"[{_ts()}] [morse] VFO restored to {_shifted_rx_freq}", flush=True)
                except Exception as e:
                    print(f"[{_ts()}] [morse] VFO restore error: {e}", flush=True)
            # 内部キーヤー使用時は T 1 を送っていないため T 0 不要
            # (IC-705/IC-7300 は内部キーヤー完了後に自動でRXへ戻る)
            _morse_sending = False
            if _cw_switch and current_model and current_cat:
                print(f"[{_ts()}] [morse] restoring PTT to {_cw_orig_ptt}", flush=True)
                start_rigctld(current_model, current_cat, current_baud, current_ptt, _cw_orig_ptt)

    threading.Thread(target=worker, daemon=True).start()
    return {"status": "ok"}


@app.post("/cw/stop_morse")
def cw_stop_morse():
    """CW 送信を中断して PTT を解除する"""
    _abort_morse()   # \stop_morse + socket close 済み
    rigctl_cmd_priority("T 0")
    return {"status": "stopped"}


@app.get("/cw/morse_status")
def cw_morse_status():
    """send_morse が実行中かどうかを返す"""
    return {"sending": _morse_sending}


# ---------- CW USB中継 (cw_bridge.py subprocess 経由) ----------

@app.get("/cw/open")
def cw_open(port: str = "ttyACM0", delay_ms: int = 0):
    """cw_bridge.py を起動。タイムスタンプ変換はcw_bridge側で実施するためdelay_msは無視。"""
    global _cw_bridge_proc, _cw_bridge_port
    # パストラバーサル対策: /dev/ 配下の正当なデバイス名のみ許可する
    port = _validate_dev_name(port, "port")
    dev = f"/dev/{port}"
    with _cw_bridge_lock:
        if _cw_bridge_proc and _cw_bridge_proc.poll() is None:
            _cw_bridge_proc.terminate()
            try:
                _cw_bridge_proc.wait(timeout=2)
            except Exception:
                _cw_bridge_proc.kill()
        # 追跡外の既存プロセス(手動起動・前セッション残留)も kill してポート競合を防ぐ
        try:
            subprocess.run(["pkill", "-f", "cw_bridge.py"], timeout=3)
            time.sleep(0.5)
        except Exception:
            pass
        try:
            _cw_bridge_proc = subprocess.Popen([_VENV_PY, _CW_BRIDGE_PY, dev])
            _cw_bridge_port = dev
            print(f"[cw] bridge started pid={_cw_bridge_proc.pid} dev={dev}")
            return {"status": "ok", "port": dev}
        except Exception as e:
            print(f"[cw] bridge start failed: {e}")
            raise HTTPException(status_code=500, detail=str(e))


@app.post("/cw/close")
def cw_close():
    """cw_bridge.py を停止する"""
    global _cw_bridge_proc, _cw_bridge_port
    with _cw_bridge_lock:
        if _cw_bridge_proc and _cw_bridge_proc.poll() is None:
            _cw_bridge_proc.terminate()
            try:
                _cw_bridge_proc.wait(timeout=2)
            except Exception:
                _cw_bridge_proc.kill()
        try:
            subprocess.run(["pkill", "-f", "cw_bridge.py"], timeout=3)
        except Exception:
            pass
        _cw_bridge_proc = None
        _cw_bridge_port = ""
    return {"status": "ok"}


@app.get("/cw/status")
def cw_status():
    """cw_bridge.py の稼働状況と M5ATOM Server SYNC結果を返す"""
    with _cw_bridge_lock:
        running = bool(_cw_bridge_proc and _cw_bridge_proc.poll() is None)
    synced = False
    offset_ms = 0
    max_late_ms = 0
    if running:
        try:
            import json as _json
            with open("/tmp/cw_bridge_status.json") as _f:
                _st = _json.load(_f)
            if time.time() - _st.get("t", 0) < 15:
                synced = bool(_st.get("synced", False))
                offset_ms = float(_st.get("offset_ms", 0))
                max_late_ms = int(_st.get("max_late_ms", 0))
        except Exception:
            pass
    return {"connected": running, "synced": synced, "offset_ms": offset_ms, "max_late_ms": max_late_ms}


@app.post("/cw/key")
def cw_key(is_on: bool = Form(...)):
    """後方互換スタブ: UDP切替後は使用されない"""
    return {"status": "no_device"}


@app.get("/cw/time")
def cw_time():
    return {"ms": int(time.time() * 1000)}


@app.get("/time")
def get_time():
    """Pi の現在 Unix 時刻 (ms) を返す。Android 側クロックオフセット補正用。"""
    return {"ms": int(time.time() * 1000)}


@app.post("/admin/set_time")
async def admin_set_time(request: Request):
    """時刻を標準時間に同期する。
    1. NTP に接続できる場合: ntpdate / chronyc でインターネット標準時間と同期（最高精度）
    2. NTP 不可の場合: Android が送信した時刻（Android は通信網経由で NTP 同期済み）で代替
    FT8 デコードに必要な ±1 秒以内の精度を確保する。"""
    try:
        data = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON")
    android_ms = data.get("ms", 0)
    pi_ms_before = int(time.time() * 1000)

    # ── 方法 1: chronyc makestep (chrony インストール済みの場合) ──
    r = subprocess.run(["sudo", "-n", "chronyc", "makestep"], capture_output=True, timeout=8)
    if r.returncode == 0:
        drift_ms = pi_ms_before - int(time.time() * 1000)
        print(f"[{_ts()}] [set_time] NTP(chrony) ok drift≈{drift_ms:+d}ms", flush=True)
        return {"ok": True, "source": "ntp_chrony", "drift_ms": drift_ms}

    # ── 方法 2: ntpdate (ntpdate インストール済みの場合) ──
    for srv in ["pool.ntp.org", "ntp.nict.jp"]:
        r = subprocess.run(["sudo", "-n", "ntpdate", "-s", srv], capture_output=True, timeout=8)
        if r.returncode == 0:
            drift_ms = pi_ms_before - int(time.time() * 1000)
            print(f"[{_ts()}] [set_time] NTP(ntpdate/{srv}) ok drift≈{drift_ms:+d}ms", flush=True)
            return {"ok": True, "source": f"ntp_ntpdate/{srv}", "drift_ms": drift_ms}

    # ── 方法 3: timedatectl set-ntp true で即時同期要求 ──
    r = subprocess.run(["sudo", "-n", "timedatectl", "set-ntp", "true"], capture_output=True, timeout=5)
    if r.returncode == 0:
        time.sleep(2)
        drift_ms = pi_ms_before - int(time.time() * 1000)
        print(f"[{_ts()}] [set_time] NTP(timedatectl) requested drift≈{drift_ms:+d}ms", flush=True)
        return {"ok": True, "source": "ntp_timedatectl", "drift_ms": drift_ms}

    # ── 方法 4: フォールバック — Android 端末の時刻で設定 ──
    # date -s "@timestamp" 形式は常に UTC で解釈されるためタイムゾーン問題を回避できる
    if not android_ms:
        return {"ok": False, "source": "none", "drift_ms": 0}
    ts_sec = android_ms // 1000
    drift_ms = android_ms - pi_ms_before
    r = subprocess.run(["sudo", "-n", "date", "-s", f"@{ts_sec}"], capture_output=True, timeout=5)
    ok = r.returncode == 0
    import datetime as _dt
    date_str = _dt.datetime.fromtimestamp(ts_sec, tz=_dt.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    print(f"[{_ts()}] [set_time] Android fallback drift={drift_ms:+d}ms set={date_str} ok={ok}", flush=True)
    return {"ok": ok, "source": "android", "drift_ms": drift_ms}


# ---------- APRS ----------

def encode_ax25_addr(callsign: str, ssid: int, last: bool) -> bytes:
    call = callsign.upper().ljust(6)[:6]
    addr = bytearray()
    for c in call:
        addr.append(ord(c) << 1)
    ssid_byte = 0x60 | ((ssid & 0x0F) << 1)
    if last:
        ssid_byte |= 0x01
    addr.append(ssid_byte)
    return bytes(addr)


def build_ax25_ui_frame(src_call, src_ssid, dest_call, dest_ssid, path, info):
    addrs = bytearray()
    addrs += encode_ax25_addr(dest_call, dest_ssid, last=False)
    last_src = (len(path) == 0)
    addrs += encode_ax25_addr(src_call, src_ssid, last=last_src)
    for i, p in enumerate(path):
        call, ssid = (p.split("-", 1)[0], int(p.split("-", 1)[1])) if "-" in p else (p, 0)
        addrs += encode_ax25_addr(call, ssid, last=(i == len(path) - 1))
    frame = bytearray()
    frame += addrs
    frame.append(0x03)
    frame.append(0xF0)
    frame += info.encode("ascii")
    return bytes(frame)


def kiss_wrap(ax25_frame: bytes) -> bytes:
    FEND, FESC, TFEND, TFESC = 0xC0, 0xDB, 0xDC, 0xDD
    out = bytearray([FEND, 0x00])
    for b in ax25_frame:
        if b == FEND:
            out.extend([FESC, TFEND])
        elif b == FESC:
            out.extend([FESC, TFESC])
        else:
            out.append(b)
    out.append(FEND)
    return bytes(out)


def _kiss_unescape(data: bytes) -> bytes:
    FEND, FESC, TFEND, TFESC = 0xC0, 0xDB, 0xDC, 0xDD
    out = bytearray()
    i = 0
    while i < len(data):
        b = data[i]
        if b == FESC and i + 1 < len(data):
            nxt = data[i + 1]
            if nxt == TFEND:
                out.append(FEND); i += 2; continue
            elif nxt == TFESC:
                out.append(FESC); i += 2; continue
        out.append(b)
        i += 1
    return bytes(out)


def _decode_ax25_addr(b: bytes):
    call = "".join(chr(c >> 1) for c in b[:6]).strip()
    ssid = (b[6] >> 1) & 0x0F
    last = bool(b[6] & 0x01)
    return call, ssid, last


def _decode_ax25_frame(frame: bytes):
    """KISSアンエスケープ済みのAX.25フレームをデコードし、送信元コールサイン/パス/情報部を返す。"""
    pos = 0
    addrs = []
    while True:
        if pos + 7 > len(frame):
            return None
        call, ssid, last = _decode_ax25_addr(frame[pos:pos + 7])
        addrs.append((call, ssid))
        pos += 7
        if last or len(addrs) > 10:
            break
    if len(addrs) < 2 or pos + 2 > len(frame):
        return None
    pos += 2  # control + PID
    info = frame[pos:]
    dest_call, _ = addrs[0]
    src_call, src_ssid = addrs[1]
    path = addrs[2:]
    try:
        info_str = info.decode("ascii", errors="replace")
    except Exception:
        info_str = ""
    return {
        "src": f"{src_call}-{src_ssid}" if src_ssid else src_call,
        "dest": dest_call,
        "path": [f"{c}-{s}" if s else c for c, s in path],
        "info": info_str,
    }


def _parse_mic_e(dest6: str, info: str) -> dict | None:
    """Mic-E形式の位置情報デコード (APRS Protocol Reference §10)。"""
    try:
        if len(dest6) < 6 or len(info) < 9:
            return None

        def _df(ch):
            ch = ch.upper()
            if '0' <= ch <= '9': return int(ch), 0
            if 'A' <= ch <= 'J': return ord(ch) - ord('A'), 1
            if 'P' <= ch <= 'Y': return ord(ch) - ord('P'), 1
            return 0, 0

        d1, _  = _df(dest6[0])
        d2, _  = _df(dest6[1])
        d3, _  = _df(dest6[2])
        d4, ns = _df(dest6[3])   # N/S: 1=North
        d5, lo = _df(dest6[4])   # 経度オフセット: 1=+100°
        d6, ew = _df(dest6[5])   # E/W: 1=East

        # D1=緯度度の十の位, D2=一の位, D3=分の十の位, D4=分の一の位, D5=分の0.1, D6=分の0.01
        lat_deg = d1 * 10 + d2
        lat_min = d3 * 10 + d4 + d5 / 10.0 + d6 / 100.0
        lat = lat_deg + lat_min / 60.0
        if not ns:
            lat = -lat

        lon_d  = ord(info[1]) - 28
        lon_m  = ord(info[2]) - 28
        lon_mh = ord(info[3]) - 28

        if lo:
            lon_d += 100
        if 180 <= lon_d <= 189:
            lon_d -= 80
        elif 190 <= lon_d <= 199:
            lon_d -= 190
        if lon_m >= 60:
            lon_m -= 60

        lon = lon_d + (lon_m + lon_mh / 100.0) / 60.0
        # FTX-1 firmware bug: D6 uses plain digit ('0'-'9') instead of P-Y range for East.
        # When lo=1 and D6 is a plain digit, the East flag is missing — treat as East.
        ch6 = dest6[5].upper()
        if not ew:
            if not (lo and '0' <= ch6 <= '9'):
                lon = -lon

        # Mic-E info layout: [0]=DTI [1-3]=lon deg/min/mh [4-6]=speed/course [7]=sym_code [8]=sym_table
        sym_code  = info[7]
        sym_table = info[8]
        raw_comment = info[9:].strip() if len(info) > 9 else ""
        # 先頭のエンコードバイト(/'_6 等のYaesステータスコード/アルチチュードエンコード)を除去し
        # 最初のアルファベットから後を表示用コメントとする
        idx = next((i for i, c in enumerate(raw_comment) if c.isalpha()), -1)
        comment = raw_comment[idx:].strip() if idx >= 0 else ""

        print(f"[APRS/mic-e] dest6={repr(dest6)} lat={round(lat,4)} lon={round(lon,4)} sym={repr(sym_table+sym_code)}", flush=True)
        return {
            "lat": round(lat, 6),
            "lon": round(lon, 6),
            "symbol": sym_table + sym_code,
            "comment": comment[:40],
        }
    except Exception:
        return None


def _parse_aprs_position(info: str, dest: str = "") -> dict | None:
    """APRS位置情報デコード。非圧縮形式 (!/=/@) および Mic-E に対応。"""
    if not info:
        return None
    dti = info[0]
    # Mic-E (バックティック/アポストロフィDTI)
    if dti in ('`', "'", '\x1c', '\x1d'):
        return _parse_mic_e(dest, info) if dest else None
    body = info[1:]
    if dti in ("/", "@"):
        if len(body) < 7:
            return None
        body = body[7:]  # タイムスタンプ(7文字)を読み飛ばす
    elif dti not in ("!", "="):
        return None
    if len(body) < 19:
        return None
    lat_str, sym_table, lon_str, sym_code = body[0:8], body[8], body[9:18], body[18]
    comment = body[19:]
    try:
        lat = int(lat_str[0:2]) + float(lat_str[2:7]) / 60.0
        if lat_str[7] == "S":
            lat = -lat
        lon = int(lon_str[0:3]) + float(lon_str[3:8]) / 60.0
        if lon_str[8] == "W":
            lon = -lon
    except (ValueError, IndexError):
        return None
    return {"lat": lat, "lon": lon, "symbol": sym_table + sym_code, "comment": comment.strip()}


def _record_heard(ax: dict):
    global aprs_notify_queue
    info = ax["info"]
    pos = _parse_aprs_position(info, dest=ax.get("dest", ""))
    now = time.time()
    entry = {
        "call": ax["src"],
        "path": ax["path"],
        "lat": pos["lat"] if pos else None,
        "lon": pos["lon"] if pos else None,
        "symbol": pos["symbol"] if pos else None,
        "comment": (pos["comment"] if pos else info)[:40],
        "heard_at": now,
    }
    with aprs_heard_lock:
        aprs_heard[:] = [e for e in aprs_heard if e["call"] != entry["call"]]
        aprs_heard.insert(0, entry)
        del aprs_heard[100:]

        # ★ 無線機のようなビーコン受信ポップアップ用。同一局は heard_suppress_sec
        #   経過するまで再通知しない(頻繁なビーコンでポップアップが連発しないように)。
        last = _aprs_notify_last.get(entry["call"], 0)
        if now - last >= aprs_notify_suppress_sec:
            _aprs_notify_last[entry["call"]] = now
            aprs_notify_queue.append(entry)
            del aprs_notify_queue[:-10]
            aprs_notify_queue_android.append(entry)
            del aprs_notify_queue_android[:-10]

    fmt = repr(info[0]) if info else "?"
    sym = pos["symbol"] if pos else "none"
    print(f"[APRS/rx] heard {entry['call']} pos={'yes' if pos else 'no'} dti={fmt} symbol={repr(sym)}", flush=True)


def _handle_kiss_frame(raw: bytes):
    if not raw or (raw[0] & 0x0F) != 0x00:
        return  # ポート/コマンドニブルが0(データフレーム)以外は無視
    frame = _kiss_unescape(raw[1:])
    ax = _decode_ax25_frame(frame)
    if ax is not None:
        _record_heard(ax)


def _aprs_rx_loop():
    """direwolfのKISSポートに接続し続け、受信パケットをデコードしてaprs_heardに記録する。
    TX方式(DireWolf/FTX-1)やTXの有無に関わらず、direwolfが起動していればこれだけで受信を拾える。"""
    global aprs_rx_running
    print("[APRS/rx] monitor thread started", flush=True)
    while aprs_rx_running:
        s = None
        buf = bytearray()
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(2.0)
            s.connect((KISS_HOST, KISS_PORT))
            s.settimeout(1.0)
            print("[APRS/rx] KISS connected", flush=True)
            while aprs_rx_running:
                try:
                    chunk = s.recv(1024)
                except socket.timeout:
                    continue
                if not chunk:
                    break
                buf.extend(chunk)
                FEND = 0xC0
                while True:
                    try:
                        start = buf.index(FEND)
                    except ValueError:
                        buf.clear()
                        break
                    try:
                        end = buf.index(FEND, start + 1)
                    except ValueError:
                        del buf[:start]
                        break
                    frame_bytes = bytes(buf[start + 1:end])
                    del buf[:end]
                    if frame_bytes:
                        try:
                            _handle_kiss_frame(frame_bytes)
                        except Exception as e:
                            print(f"[APRS/rx] decode error: {e}", flush=True)
        except Exception as e:
            print(f"[APRS/rx] connect error: {e}", flush=True)
        finally:
            if s:
                try:
                    s.close()
                except Exception:
                    pass
        if aprs_rx_running:
            time.sleep(2.0)
    print("[APRS/rx] monitor thread stopped", flush=True)


def _write_rx_only_direwolf_conf(baud: int, sound_device: str):
    """PTT/MYCALL無しの受信専用direwolf設定(FTX-1内蔵モデムTX中/APRS停止中でも受信だけは続ける用)。
    ★ ADEVICE は "ADEVICE <入力> <出力>" の順。TX用conf(ADEVICE null {device})は入力=null
      (=受信オーディオを一切読まない)になっていたため、受信専用confでは逆に出力側をnullにする。"""
    modem = 9600 if baud == 9600 else 1200
    conf = f"ADEVICE {sound_device} null\nCHANNEL 0\nMODEM {modem}\n"
    if modem == 9600:
        conf += "ARATE 48000\n"
    conf += "KISSPORT 8001\nAGWPORT 8050\n"
    _atomic_write(str(_HOME_DIR / "direwolf.conf"), conf)


def _ensure_aprs_rx(cfg: "AprsConfig"):
    """受信監視スレッド/direwolfのRX待受状態を、現在のTX状況に合わせて整える。
    バックグラウンドスレッドから呼ぶこと(direwolf再起動を伴う場合があるため)。"""
    global aprs_rx_running, aprs_rx_thread, _aprs_direwolf_conf_kind
    if not cfg.enabled:
        aprs_rx_running = False
        return

    # DireWolf-TXが稼働中はそちらのフル設定(PTT/MYCALL込み)がそのまま受信も兼ねる。
    # それ以外(FTX-1内蔵モデムTX中 or APRS停止中)は受信専用の軽量設定に切り替える。
    need_own_rx_conf = cfg.use_rig_modem or not aprs_running
    if need_own_rx_conf and _aprs_direwolf_conf_kind != ("rx", cfg.baud):
        _write_rx_only_direwolf_conf(cfg.baud, cfg.sound_device)
        subprocess.run(["sudo", "systemctl", "restart", "direwolf"], capture_output=True)
        _aprs_direwolf_conf_kind = ("rx", cfg.baud)
        _wait_direwolf_kiss_ready(15.0)

    _start_aprs_rx_thread_if_needed()


def _start_aprs_rx_thread_if_needed():
    global aprs_rx_running, aprs_rx_thread
    if not (aprs_rx_thread and aprs_rx_thread.is_alive()):
        aprs_rx_running = True
        aprs_rx_thread = threading.Thread(target=_aprs_rx_loop, daemon=True)
        aprs_rx_thread.start()
    else:
        aprs_rx_running = True


def _wait_direwolf_kiss_ready(timeout: float = 15.0) -> bool:
    """KISS ポート (8001) が LISTEN になるまで最大 timeout 秒待つ (Pi Zero は Hamlib 初期化で ~10s かかる)"""
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            s = socket.socket()
            s.settimeout(0.5)
            s.connect((KISS_HOST, KISS_PORT))
            s.close()
            return True
        except OSError:
            time.sleep(0.3)
    return False


def send_kiss(frame: bytes):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    s.connect((KISS_HOST, KISS_PORT))
    s.sendall(frame)
    s.close()


def aprs_lat(lat):
    deg = int(lat)
    return f"{deg:02d}{(lat - deg) * 60:05.2f}N"


def aprs_lon(lon):
    deg = int(lon)
    return f"{deg:03d}{(lon - deg) * 60:05.2f}E"


def wait_tx_complete(timeout=5.0):
    global tx_started, tx_done
    tx_started = False
    tx_done = False
    start = time.time()
    while time.time() - start < timeout:
        if tx_started:
            break
        time.sleep(0.05)
    if not tx_started:
        return False
    while time.time() - start < timeout:
        if tx_done:
            return True
        time.sleep(0.05)
    return False


def watch_direwolf_tx():
    global tx_watch_running, tx_started, tx_done
    tx_watch_running = True
    proc = subprocess.Popen(
        ["journalctl", "-u", "direwolf", "-f", "-n", "0"],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
    )
    for line in proc.stdout:
        if not tx_watch_running:
            break
        lu = line.upper()
        if any(k in lu for k in ("PTT ON", "PTT KEY", "TRANSMIT", "SENDING PACKET", "AUDIO: TRANSMIT", "CHANNEL 0")):
            tx_started = True
        if any(k in lu for k in ("PTT OFF", "TX COMPLETE", "AUDIO: PTT OFF")):
            tx_done = True


def aprs_loop():
    global aprs_running, tx_in_progress, aprs_last_heartbeat, normal_freq, last_user_freq_change
    try:
        while aprs_running:
            if tx_in_progress:
                time.sleep(0.1)
                continue
            # Don't start APRS TX while radio is keyed by CW TX or voice PTT
            if radio_cache.get("tx", False):
                time.sleep(0.5)
                continue
            loop_start = time.time()
            if time.time() - aprs_last_heartbeat > 15:
                aprs_running = False
                break
            cur = rigctl_cmd_priority("f")
            try:
                read_freq = int(cur.split()[0])
                aprs_freq_hz = int(aprs_freq * 1_000_000)
                if abs(read_freq - aprs_freq_hz) > 100:
                    normal_freq = read_freq  # save home freq before switching to APRS
                if normal_freq is None:
                    normal_freq = 0  # already on APRS freq at start: no home freq to restore
            except Exception:
                time.sleep(1)
                continue
            try:
                mode_raw = rigctl_cmd("m")
                mode = mode_raw.split()[0].upper() if mode_raw else ""
            except Exception:
                mode = ""
            if "FM" not in mode:
                time.sleep(1)
                continue
            if aprs_use_gps and (latest_gps["lat"] != 0.0 or latest_gps["lon"] != 0.0):
                lat = latest_gps["lat"]
                lon = latest_gps["lon"]
            else:
                lat = aprs_manual_lat
                lon = aprs_manual_lon
            print(f"[APRS] TX lat={lat:.5f} lon={lon:.5f} (gps={aprs_use_gps} latest={latest_gps})")
            tx_in_progress = True
            # ★ poll_rig/poll_signal は radio_cache["tx"] を見てポーリング負荷を下げる仕組みが
            #   既に音声PTTにはあるが、APRS送信では今まで立てていなかった。そのため送信中も
            #   rigctld へのポーリングが止まらず、direwolfのPTT(同じrigctld経由)と競合して
            #   USBバスリセット(FTX-1のCDCごと瞬断)を誘発していた。ここで明示的に立てる。
            radio_cache["tx"] = True
            aprs_last_heartbeat = time.time()
            rigctl_cmd_priority(f"F {int(aprs_freq * 1_000_000)}")
            time.sleep(0.25)
            sym = (aprs_cfg.symbol or ">") if aprs_cfg else ">"
            comment = (getattr(aprs_cfg, "comment", "") or "").encode("ascii", errors="ignore").decode("ascii")
            info = f"!{aprs_lat(lat)}/{aprs_lon(lon)}{sym}{comment}"
            _path_str = aprs_cfg.path or ""
            _path = _path_str.split(",") if _path_str and _path_str.upper() not in ("NONE", "DIRECT") else []
            ax25 = build_ax25_ui_frame(
                src_call=aprs_cfg.callsign, src_ssid=aprs_cfg.ssid,
                dest_call=aprs_cfg.destination or "APDW18", dest_ssid=0,
                path=_path, info=info
            )
            try:
                send_kiss(kiss_wrap(ax25))
            except Exception as kiss_err:
                print(f"[APRS] KISS send failed (direwolf not running?): {kiss_err}")
                if normal_freq:
                    rigctl_cmd_priority(f"F {normal_freq}")
                    radio_cache["freq"] = normal_freq
                    last_user_freq_change = time.time()
                tx_in_progress = False
                radio_cache["tx"] = False
                # direwolf KISS ポートが応答するまで待つ（再起動が必要なら実施）
                if not _wait_direwolf_kiss_ready(2.0):
                    print("[APRS] restarting direwolf (KISS port not ready)")
                    subprocess.run(["pkill", "-9", "aplay"], capture_output=True)
                    time.sleep(0.5)
                    subprocess.run(["sudo", "systemctl", "restart", "direwolf"],
                                   capture_output=True, timeout=10)
                    _wait_direwolf_kiss_ready(15.0)
                else:
                    time.sleep(2)
                continue
            time.sleep(0.15)
            if wait_tx_complete(timeout=5.0):
                print("[APRS] TX complete")
            else:
                print("[APRS] TX timeout")
            time.sleep(0.15)
            if normal_freq:
                rigctl_cmd_priority(f"F {normal_freq}")
                radio_cache["freq"] = normal_freq
                last_user_freq_change = time.time()
                time.sleep(0.15)
            tx_in_progress = False
            radio_cache["tx"] = False
            elapsed = time.time() - loop_start
            # 細切れ sleep で aprs_running=False に素早く反応する
            wait_end = time.time() + max(0, aprs_interval - elapsed)
            while time.time() < wait_end and aprs_running:
                time.sleep(0.5)
    except Exception as e:
        print(f"[APRS] thread crashed: {e}")
    finally:
        tx_in_progress = False
        radio_cache["tx"] = False
        aprs_running = False


# ---------- APRS: 無線機内蔵モデム(FTX-1 CAT)経由 ----------
# FTX-1 CATオペレーションリファレンスマニュアルの EX コマンド(表3 メニュー一覧表)に基づく。
# EX P1(2桁) P2(2桁) P3(2桁) P4(可変桁) ; 形式。rigctld の send_cmd("w <生CAT>") でそのまま無線機に転送する。
_BCN_INTERVAL_MAP = {30: 0, 60: 1, 120: 2, 180: 3, 300: 4, 600: 5}  # aprsIntervalSec(sec) -> BCN INTERVAL TIME index


# ★ EX設定コマンドは無線機が応答を返さないため、rigctldは1コマンドごとにタイムアウト(約2秒)まで
#   待ち続ける。以前は_rig_send_no_replyで0.3秒で接続を切り次のコマンドを別接続で送っていたが、
#   rigctldは接続ごとに別スレッドで処理しmutexの取得順も保証されないため、
#   BEACON TYPE OFF→AUTO の順序が入れ替わり、最終的にOFFのまま残る(AUTOにならず開始しない)ことがあった。
#   rigctldは1つの接続内のコマンドは必ず受信順に処理するので、EXコマンドは常駐の1接続で送る。
_rig_ex_sock = None
_rig_ex_sock_lock = threading.Lock()


def _rig_ex_drain(s) -> bool:
    """溜まった応答(無応答コマンドのRPRT等)を読み捨てる。接続が切れていればFalse。"""
    s.setblocking(False)
    try:
        while True:
            try:
                chunk = s.recv(4096)
            except (BlockingIOError, InterruptedError):
                return True
            if not chunk:
                return False
    except OSError:
        return False
    finally:
        s.setblocking(True)


def _rig_ex_send_locked(cmd: str, expect_reply: bool = False):
    """_rig_ex_sock_lockを保持した状態で呼ぶこと。
    ★ 設定(SET)コマンドは "W <cmd> 0"(受信0バイト)で送る。"w <cmd>" だと rigctld が
      無線機の応答を";"までタイムアウト(約2秒)待ち続け、その間 rigctld が塞がって
      poll_rig の "t" がタイムアウト連発→rigctld自動再起動→送信待ちの BEACON TYPE=AUTO
      が失われて無線機が APRS OFF のまま残ることがあった。
      Hamlib 4.7.2 の send_cmd は受信バイト数0なら読み取りをせず即座に戻る。
      問い合わせ(expect_reply=True)は応答を読むため従来どおり "w" を使う。"""
    global _rig_ex_sock
    line = f"w {cmd}" if expect_reply else f"W {cmd} 0"
    for _ in range(2):
        try:
            if _rig_ex_sock is None or not _rig_ex_drain(_rig_ex_sock):
                if _rig_ex_sock is not None:
                    try:
                        _rig_ex_sock.close()
                    except Exception:
                        pass
                _rig_ex_sock = socket.create_connection(("localhost", 4532), timeout=1.0)
            _rig_ex_sock.sendall(f"{line}\n".encode())
            _rigctl_log("rig_ex", line, "")
            return
        except Exception as e:
            print(f"[{_ts()}] [rig_ex] error '{cmd}': {e}", flush=True)
            try:
                if _rig_ex_sock is not None:
                    _rig_ex_sock.close()
            except Exception:
                pass
            _rig_ex_sock = None


def _rig_ex_send(cmd: str):
    """常駐接続でrigctldへ生CATを送る(応答は待たない)。rigctld再起動等で切れていたら繋ぎ直す。"""
    with _rig_ex_sock_lock:
        _rig_ex_send_locked(cmd)


def _rig_ex_get(p1: int, p2: int, p3: int, timeout: float = 15.0):
    """EXメニュー項目の現在値を読む。常駐接続で送るので、先に送った設定コマンドが
    すべて無線機に反映された後の値が返る。取得できなければNone。"""
    global _rig_ex_sock
    key = f"EX{p1:02d}{p2:02d}{p3:02d}"
    buf = ""
    # ★ 送信と応答読み取りを同じロック内で行う(間に他スレッドの送信が入ると、
    #   その送信前のdrainで応答が読み捨てられてしまうため)
    with _rig_ex_sock_lock:
        _rig_ex_send_locked(f"{key};", expect_reply=True)
        s = _rig_ex_sock
        if s is None:
            return None
        deadline = time.time() + timeout
        try:
            while time.time() < deadline:
                s.settimeout(max(0.1, deadline - time.time()))
                try:
                    chunk = s.recv(4096)
                except socket.timeout:
                    break
                if not chunk:
                    _rig_ex_sock = None
                    break
                buf += chunk.decode(errors="replace")
                m = re.search(key + r"(\d+);", buf)
                if m:
                    return int(m.group(1))
        except OSError as e:
            print(f"[{_ts()}] [rig_ex] read error '{key}': {e}", flush=True)
        finally:
            s.settimeout(1.0)
    print(f"[APRS/rig] {key}; no reply (buf='{buf.strip()}')", flush=True)
    return None


def _rig_ex_set(p1: int, p2: int, p3: int, p4) -> str:
    """FTX-1 の EX メニュー項目(P1/P2/P3)に値P4を設定する。rigctld経由の生CATコマンド送信。
    常駐の1接続で送るため、送った順に無線機へ反映される(_rig_ex_sock参照)。"""
    cmd = f"EX{p1:02d}{p2:02d}{p3:02d}{p4};"
    _rig_ex_send(cmd)
    print(f"[APRS/rig] {cmd} sent", flush=True)
    return ""


def _rig_beacon_auto_verified(my_seq: int) -> bool:
    """BEACON TYPEがAUTO(1)になったことを読み返して確認し、なっていなければOFF→AUTOで入れ直す。"""
    for attempt in range(3):
        if aprs_seq != my_seq:
            return False
        v = _rig_ex_get(7, 1, 1)
        print(f"[APRS/rig] verify BEACON TYPE = {v} (attempt {attempt + 1})", flush=True)
        if v == 1:
            return True
        if aprs_seq != my_seq:
            return False
        if v not in (None, 0):
            _rig_ex_set(7, 1, 1, 0)
            time.sleep(0.5)
        _rig_ex_set(7, 1, 1, 1)
    print("[APRS/rig] BEACON TYPE did not become AUTO", flush=True)
    return False


def _rig_set_vfo_freq(vfo_cmd: str, freq_hz: int) -> str:
    """MAIN(FA)/SUB(FB) VFOの周波数をCAT直接コマンドで設定する。"""
    cmd = f"{vfo_cmd}{freq_hz:09d};"
    # ★ 直後のMODEM SELECT等と順序が入れ替わらないよう、EXコマンドと同じ常駐接続で送る
    _rig_ex_send(cmd)
    print(f"[APRS/rig] {cmd} sent", flush=True)
    return ""


_rig_aprs_cfg_lock = threading.Lock()  # configure完了前にstartワーカーがBEACON ONしないよう直列化


def _rig_aprs_configure(cfg: "AprsConfig"):
    """無線機内蔵APRSモデムをCAT経由で設定する。direwolf/USBオーディオは一切使わない。"""
    with _rig_aprs_cfg_lock:
        _rig_aprs_configure_locked(cfg)


def _rig_aprs_configure_locked(cfg: "AprsConfig"):
    freq_hz = int(cfg.freq * 1_000_000)
    modem_sel = cfg.modem_sel if cfg.modem_sel in (1, 2, 3) else 2

    # ★ MODEM SELECT=AUTOの場合、明示的にQSYさせると無線機側で意図しない周波数に
    #   変わってしまう問題が確認されたため、AUTO時は周波数を触らない。
    #   MAIN/SUB選択時は、それぞれの側のVFOをAPRS周波数に合わせる。
    if modem_sel == 2:      # MAIN
        _rig_set_vfo_freq("FA", freq_hz)
    elif modem_sel == 3:    # SUB
        _rig_set_vfo_freq("FB", freq_hz)

    # APRS SETTING > GENERAL > MODEM SELECT: 0:OFF 1:AUTO 2:MAIN 3:SUB
    _rig_ex_set(6, 1, 1, modem_sel)
    # APRS SETTING > GENERAL > MODEM TYPE: 0:1200bps 1:9600bps
    _rig_ex_set(6, 1, 2, 1 if cfg.baud == 9600 else 0)
    modem_sel_name = {1: "AUTO", 2: "MAIN", 3: "SUB"}.get(modem_sel, "MAIN")
    print(f"[APRS/rig] configured: modem={modem_sel_name} type={cfg.baud}bps freq={cfg.freq}MHz "
          f"(コールサイン/シンボル/位置情報は無線機側メニューで設定してください)", flush=True)
    # ★ ビーコン稼働中の設定変更(AP96→AP12切替)ではMODEM SELECT/周波数変更でAUTO BEACON
    #   タイマーが止まることがあるため、OFF→AUTOで入れ直して再始動させる。
    if aprs_running:
        my_seq = aprs_seq
        _rig_ex_set(7, 1, 1, 0)
        time.sleep(0.5)
        if aprs_running and aprs_seq == my_seq:
            _rig_ex_set(7, 1, 1, 1)
            _rig_beacon_auto_verified(my_seq)


def _rig_aprs_watch_loop():
    """無線機内蔵モデム使用時、M5からのハートビートが途絶えたらビーコンを止める安全装置。
    実際のビーコン送信タイミングは無線機自身のAUTO BEACON機能が管理するため、ここではKISS送出は行わない。"""
    global aprs_running
    while aprs_running:
        if time.time() - aprs_last_heartbeat > 15:
            print("[APRS/rig] heartbeat lost -> stopping rig beacon", flush=True)
            _rig_ex_set(7, 1, 1, 0)  # APRS BEACON > BEACON SET. > BEACON TYPE = 0:OFF
            radio_cache["tx"] = False
            aprs_running = False
            break
        time.sleep(1.0)


@app.post("/aprs_config")
def update_aprs_config(cfg: AprsConfig):
    global aprs_use_gps, aprs_manual_lat, aprs_manual_lon, aprs_cfg, aprs_notify_suppress_sec
    global _last_rig_aprs_key
    aprs_use_gps = cfg.use_gps
    aprs_manual_lat = cfg.manual_lat
    aprs_manual_lon = cfg.manual_lon
    aprs_cfg = cfg
    aprs_notify_suppress_sec = max(0, cfg.heard_suppress_sec)

    if cfg.use_rig_modem:
        # 無線機内蔵APRSモデムを使う場合、TX(CAT)自体はdirewolf/USBオーディオに一切触れない。
        # ★ CAT設定コマンドはタイムアウト・リトライを挟むと数秒かかることがあり、
        #   同期的に実行するとM5側のHTTPタイムアウトより長引いて失敗と誤判定される。
        #   DireWolf方式(direwolf再起動)と同様にバックグラウンドスレッドで実行する。
        # ★ 定期再送時に同じ設定で繰り返しCATコマンドを送らないよう、変更があった時だけ実行する。
        rig_key = (cfg.freq, cfg.baud, cfg.modem_sel)
        if rig_key != _last_rig_aprs_key:
            _last_rig_aprs_key = rig_key
            threading.Thread(target=_rig_aprs_configure, args=(cfg,), daemon=True).start()
        # ★ TXはCAT制御でもRXは別問題(オーディオデコード)なので、受信専用direwolfは
        #   別スレッドで独立に用意する。
        threading.Thread(target=_ensure_aprs_rx, args=(cfg,), daemon=True).start()
        return {"status": "ok"}

    # パストラバーサル対策: /dev/ 配下の正当なデバイス名のみ許可する
    cat_device = f"/dev/{_validate_dev_name(cfg.cat_device, 'cat_device')}"
    modem = 1200 if cfg.baud == 1200 else 9600
    new_conf = (f"ADEVICE {cfg.sound_device} {cfg.sound_device}\nCHANNEL 0\n"
                f"MYCALL {cfg.callsign}-{cfg.ssid}\nMODEM {modem}\n")
    if modem == 9600:
        new_conf += "ARATE 48000\n"
    new_conf += "KISSPORT 8001\nAGWPORT 8050\nPTT RIG 2 localhost:4532\n"

    conf_path = str(_HOME_DIR / "direwolf.conf")
    try:
        with open(conf_path) as f:
            existing_conf = f.read()
    except Exception:
        existing_conf = ""
    conf_changed = existing_conf.strip() != new_conf.strip()
    _atomic_write(conf_path, new_conf)

    def _restart_and_track_rx():
        global _aprs_direwolf_conf_kind
        if conf_changed:
            print(f"[aprs_config] direwolf.conf changed, restarting direwolf", flush=True)
            subprocess.run(["sudo", "systemctl", "restart", "direwolf"])
        else:
            print(f"[aprs_config] direwolf.conf unchanged, skipping restart", flush=True)
        _aprs_direwolf_conf_kind = ("tx", cfg.baud)
        if cfg.enabled:
            _wait_direwolf_kiss_ready(15.0)
            _start_aprs_rx_thread_if_needed()
        else:
            global aprs_rx_running
            aprs_rx_running = False

    threading.Thread(target=_restart_and_track_rx, daemon=True).start()
    return {"status": "ok"}


@app.post("/aprs_start")
def aprs_start(cfg: AprsStart):
    global aprs_running, aprs_thread, aprs_freq, aprs_interval, aprs_last_heartbeat
    global tx_watch_thread, tx_watch_running, aprs_seq
    if aprs_cfg is None:
        return {"error": "APRS config not set"}
    # 既存ループを停止フラグだけ立てて即座に返す
    aprs_running = False
    tx_watch_running = False
    aprs_freq = cfg.freq
    aprs_interval = cfg.interval
    aprs_last_heartbeat = time.time()
    aprs_seq += 1
    my_seq = aprs_seq

    if aprs_cfg.use_rig_modem:
        # DireWolf TX モードから切り替えた場合に残存する direwolf プロセスを停止する。
        # (direwolf は PTT RIG 経由でリグを制御するため、kill しないとリグ側の PTT が残る)
        subprocess.run(["pkill", "-9", "direwolf"], capture_output=True)
        # 無線機内蔵モデムのAUTOビーコンを開始する。direwolf/aprs_loopのKISS送出は使わない。
        # ★ CAT設定4連続はタイムアウト・リトライを挟むと合計で数秒〜10秒近くかかることがあり、
        #   同期実行するとM5側のHTTPタイムアウトで失敗と誤判定されるため、バックグラウンドで実行する。
        def _rig_start_worker():
            # ★ 直前の/aprs_config(MODEM SELECT/周波数設定)が終わるのを待つ。
            #   BEACON TYPE=AUTOの後にMODEM SELECTやVFO周波数が変わると、無線機側の
            #   AUTO BEACONタイマーが起動しないまま(手動ビーコンを1回出すまで送信されない)になる。
            with _rig_aprs_cfg_lock:
                pass
            # ★ BEACON TYPEが既にAUTOのままだとCATで再度AUTOを書いても状態遷移が起きず、
            #   タイマーが始動しないことがあるため、一旦OFFにしてからAUTOへ遷移させる。
            _rig_ex_set(7, 1, 1, 0)    # APRS BEACON > BEACON SET. > BEACON TYPE = 0:OFF
            idx = _BCN_INTERVAL_MAP.get(cfg.interval, 1)
            _rig_ex_set(7, 2, 1, idx)  # APRS BEACON > AUTO BEACON > INTERVAL TIME
            # ★ PROPORTIONAL/DECAYがONだと静止中(移動なし)は間隔が大きく延びてしまい、
            #   設定したINTERVAL TIME通りに送信されない。固定間隔で送信させるため明示的にOFFにする。
            _rig_ex_set(7, 2, 2, 0)   # APRS BEACON > AUTO BEACON > PROPORTIONAL = 0:OFF
            _rig_ex_set(7, 2, 3, 0)   # APRS BEACON > AUTO BEACON > DECAY = 0:OFF
            # ★ ここまでの間に/aprs_stopや別のAP96/AP12切替(=新しいaprs_start)が来ていたら、
            #   このワーカーは既に古い要求。BEACON TYPE=ONで無線機を上書きせず中断する。
            #   (これが無いと、OFFにしたのにAP12押下時の遅延ワーカーが後からONに戻し
            #   「OFFにしてもビーコンが止まらない」状態になる)
            if aprs_seq != my_seq:
                print(f"[APRS/rig] start worker superseded (seq {my_seq} != {aprs_seq}), aborting before beacon ON", flush=True)
                return
            time.sleep(0.5)  # OFF→AUTOの遷移を無線機に確実に認識させる
            if aprs_seq != my_seq:
                return
            _rig_ex_set(7, 1, 1, 1)    # APRS BEACON > BEACON SET. > BEACON TYPE = 1:AUTO
            radio_cache["tx"] = False
            # ★ 実際にAUTOになったか読み返して確認し、なっていなければ入れ直す
            _rig_beacon_auto_verified(my_seq)

        threading.Thread(target=_rig_start_worker, daemon=True).start()
        # ★ 既にwatchループが生きている場合は再利用する(稼働中のプリセット切替など、
        #   aprs_running=False->True の一瞬の切り替えだけでは古いスレッドが
        #   確実に終了するとは限らないため、二重起動を避けて明示的にチェックする)
        watch_alive = aprs_thread is not None and aprs_thread.is_alive()
        aprs_running = True
        if not watch_alive:
            aprs_thread = threading.Thread(target=_rig_aprs_watch_loop, daemon=True)
            aprs_thread.start()
        return {"status": "starting (rig internal modem)"}

    def _start_worker():
        global aprs_running, aprs_thread, tx_watch_thread, tx_watch_running
        # 古いスレッドが終了するまで最大 3s 待つ（2スレッド起動防止）
        old = aprs_thread
        if old and old.is_alive():
            old.join(timeout=3.0)
        # KISS ポートが開くまで待つ（Pi Zero は Hamlib 初期化で ~10s かかる）
        subprocess.run(["pkill", "-9", "aplay"], capture_output=True)
        time.sleep(0.5)
        if not _wait_direwolf_kiss_ready(20.0):
            if subprocess.run(["pgrep", "-x", "direwolf"], capture_output=True).returncode != 0:
                print("[aprs_start] direwolf not running, starting")
                subprocess.run(["sudo", "systemctl", "start", "direwolf"],
                               capture_output=True, timeout=10)
                _wait_direwolf_kiss_ready(15.0)
            else:
                print("[aprs_start] KISS port not ready after 20s, proceeding anyway")
        aprs_running = True
        aprs_thread = threading.Thread(target=aprs_loop, daemon=True)
        aprs_thread.start()
        tx_watch_running = True
        tx_watch_thread = threading.Thread(target=watch_direwolf_tx, daemon=True)
        tx_watch_thread.start()
        # Start KISS RX monitor thread so received beacons are captured even when
        # /aprs_config was not called first (e.g. panel button tap from iOS).
        _start_aprs_rx_thread_if_needed()

    threading.Thread(target=_start_worker, daemon=True).start()
    return {"status": "starting"}


@app.post("/aprs_stop")
def aprs_stop():
    global aprs_running, poll_enabled, tx_watch_running, last_ptt_state, aprs_seq, aprs_rx_running
    global _last_rig_aprs_key
    poll_enabled = True
    aprs_running = False
    tx_watch_running = False
    aprs_seq += 1  # 実行中/待機中のstartワーカーを無効化(ビーコンONで上書きされるのを防ぐ)
    _last_rig_aprs_key = None  # 次回 start 時に必ずCAT設定を再適用する

    # リグ内蔵APRSモデムのAUTO BEACONを常に無効化する。
    # use_rig_modem/aprs_cfg の状態によらず送信する。サーバー状態の不整合時も確実に止めるため。
    # 非FTX-1機種ではコマンドが失敗するがログ出力のみで副作用なし。
    _rig_ex_set(7, 1, 1, 0)  # APRS BEACON > BEACON SET. > BEACON TYPE = 0:OFF

    if aprs_cfg is not None and aprs_cfg.use_rig_modem:
        # DireWolf TX モードから切り替えた場合に残存する PTT 制御を解除する。
        rigctl_cmd_priority("T 0")
        subprocess.run(["pkill", "-9", "direwolf"], capture_output=True)
        last_ptt_state = 0
        radio_cache["tx"] = False
        # ★ TXは止めるが、APRS機能自体(cfg.enabled)がONならAUTO BEACON以外の局からの
        #   受信は引き続き拾えるよう、受信専用direwolfへ切り替えて維持する。
        threading.Thread(target=_ensure_aprs_rx, args=(aprs_cfg,), daemon=True).start()
        return {"status": "stopped (rig internal modem)"}

    rigctl_cmd_priority("T 0")
    radio_cache["tx"] = False
    last_ptt_state = 0
    if aprs_cfg is not None and aprs_cfg.enabled:
        # ★ TX(PTT/MYCALL込み)設定は不要になったが、APRS機能自体はONのままなので
        #   direwolfをkillせず、受信専用設定に切り替えて受信だけ継続する。
        threading.Thread(target=_ensure_aprs_rx, args=(aprs_cfg,), daemon=True).start()
    else:
        subprocess.run(["pkill", "-9", "direwolf"], capture_output=True)
        aprs_rx_running = False
    return {"status": "stopped"}


@app.get("/aprs_notify")
def aprs_notify():
    """無線機のような「ビーコン受信」ポップアップ用。溜まっている未取得の通知イベントを
    払い出して(=消費して)返す。M5はこれをメイン画面表示中、数秒おきにポーリングする。"""
    global aprs_notify_queue
    with aprs_heard_lock:
        events = list(aprs_notify_queue)
        aprs_notify_queue = []
    return {"events": events}


@app.get("/aprs_notify_android")
def aprs_notify_android():
    """Android用のビーコン受信通知キュー。M5の/aprs_notifyとは独立して管理される。"""
    global aprs_notify_queue_android
    with aprs_heard_lock:
        events = list(aprs_notify_queue_android)
        aprs_notify_queue_android = []
    return {"events": events}


@app.get("/aprs_received")
def aprs_received():
    now = time.time()
    with aprs_heard_lock:
        stations = [
            {**{k: v for k, v in e.items() if k != "heard_at"}, "age_sec": int(now - e["heard_at"])}
            for e in aprs_heard
        ]
    return {"stations": stations}


@app.post("/aprs_heartbeat")
def aprs_heartbeat():
    global aprs_last_heartbeat
    aprs_last_heartbeat = time.time()
    return {"status": "ok"}


@app.post("/gps")
def update_gps(data: GPSData):
    global latest_gps
    latest_gps = {"lat": data.lat, "lon": data.lon}
    return {"status": "ok"}


@app.get("/gps")
def get_gps():
    return latest_gps


@app.post("/admin/update")
async def admin_update(request: Request):
    """api.py をアップデートしてサービスを再起動する"""
    content = await request.body()
    if not content:
        raise HTTPException(status_code=400, detail="Empty body")
    # Python 構文チェック
    try:
        compile(content.decode("utf-8"), "<api.py>", "exec")
    except SyntaxError as e:
        raise HTTPException(status_code=422, detail=f"Syntax error: {e}")
    # 書き込み先パスを決定（_HOME_DIR 経由でユーザー名に依存しない）
    api_path = _HOME_DIR / "fastapi" / "api.py"
    if not api_path.parent.exists():
        api_path = Path(__file__).resolve()
    bak_path = api_path.with_suffix(".py.bak_update")
    try:
        if api_path.exists():
            import shutil
            shutil.copy2(api_path, bak_path)
        api_path.write_bytes(content)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Write failed: {e}")
    def _restart():
        import time as _time
        _time.sleep(0.5)
        _ensure_venv_numpy()
        # 方法1: sudo -n systemctl (NOPASSWD 設定済みの場合) — 各サービスを個別に試行
        # ★ 必ず fastapi-audio(別プロセス, :50000)を先に再起動する。fastapi(:8000)は
        #   このスレッドが動いている自プロセスなので、`systemctl restart fastapi` を先に
        #   呼ぶとその呼び出し中に自分が SIGTERM で終了し、後続の fastapi-audio 再起動が
        #   一度も実行されない。その結果、音声ストリーム側だけ旧 api.py のまま残っていた。
        try:
            subprocess.run(["sudo", "-n", "systemctl", "restart", "fastapi-audio"],
                           capture_output=True, timeout=20)
        except Exception as e:
            print(f"[admin_update] fastapi-audio restart skipped: {e}", flush=True)
        r = subprocess.run(
            ["sudo", "-n", "systemctl", "restart", "fastapi"],
            capture_output=True, timeout=10
        )
        if r.returncode == 0:
            return
        # 方法2: sudo 不可 → nohup スクリプト + SIGTERM
        # systemd が Restart= で再起動するケースと手動起動のケースを両立するため
        # 「uvicorn が起動していなければ起動する」チェックを入れて2重起動を防ぐ
        restart_sh = (
            "#!/bin/bash\n"
            "sleep 2\n"
            "pkill -TERM -f 'uvicorn api' 2>/dev/null || true\n"
            "sleep 1\n"
            "pkill -9 -f 'uvicorn api' 2>/dev/null || true\n"
            "sleep 15\n"
            # systemd が既に再起動していれば何もしない (Pi Zero は ~10-15s かかる)
            "if pgrep -f 'uvicorn api' >/dev/null 2>&1; then\n"
            "  exit 0\n"
            "fi\n"
            f"cd {_FASTAPI_DIR}\n"
            f"{_VENV_PY.replace('python3','uvicorn')} api:app --host 0.0.0.0 --port 8000 "
            ">>/tmp/uvicorn_restart.log 2>&1 &\n"
            f"{_VENV_PY.replace('python3','uvicorn')} api:app --host 0.0.0.0 --port 50000 "
            ">>/tmp/uvicorn_audio_restart.log 2>&1\n"
        )
        sh = "/tmp/_fastapi_restart.sh"
        with open(sh, "w") as _f:
            _f.write(restart_sh)
        os.chmod(sh, 0o755)
        subprocess.Popen(
            ["nohup", "bash", sh],
            stdout=open("/tmp/uvicorn_restart.log", "w"),
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        # 現プロセスも SIGTERM で終了 (systemd Restart=on-failure があれば自動再起動)
        _time.sleep(0.5)
        os.kill(os.getpid(), signal.SIGTERM)
    threading.Thread(target=_restart, daemon=True).start()
    return {"status": "ok", "message": "restarting"}


@app.post("/admin/update_cw_bridge")
async def admin_update_cw_bridge(request: Request):
    """cw_bridge.py をアップデートして再起動する"""
    content = await request.body()
    if not content:
        raise HTTPException(status_code=400, detail="Empty body")
    try:
        compile(content.decode("utf-8"), "<cw_bridge.py>", "exec")
    except SyntaxError as e:
        raise HTTPException(status_code=422, detail=f"Syntax error: {e}")
    bridge_path = Path(_CW_BRIDGE_PY)
    bak_path = Path(_CW_BRIDGE_PY + ".bak")
    try:
        if bridge_path.exists():
            import shutil
            shutil.copy2(bridge_path, bak_path)
        bridge_path.write_bytes(content)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Write failed: {e}")
    # cw_bridge プロセスを再起動
    global _cw_bridge_proc, _cw_bridge_port
    with _cw_bridge_lock:
        saved_port = _cw_bridge_port
        if _cw_bridge_proc and _cw_bridge_proc.poll() is None:
            _cw_bridge_proc.terminate()
            try:
                _cw_bridge_proc.wait(timeout=2)
            except Exception:
                _cw_bridge_proc.kill()
        try:
            subprocess.run(["pkill", "-f", "cw_bridge.py"], timeout=3)
            time.sleep(0.5)
        except Exception:
            pass
        _cw_bridge_proc = None
        if saved_port:
            try:
                _cw_bridge_proc = subprocess.Popen([_VENV_PY, _CW_BRIDGE_PY, saved_port])
                _cw_bridge_port = saved_port
            except Exception as e:
                return {"status": "updated", "restart": f"failed: {e}"}
    return {"status": "ok", "message": "cw_bridge updated and restarted"}



@app.post("/admin/setup")
async def admin_setup(request: Request):
    """create_api.sh を受け取りホームディレクトリに保存してバックグラウンド実行する"""
    content = await request.body()
    if not content:
        raise HTTPException(status_code=400, detail="Empty body")
    script_path = _HOME_DIR / "create_api.sh"
    try:
        script_path.write_bytes(content)
        script_path.chmod(0o755)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Write failed: {e}")
    log_path = "/tmp/create_api.log"
    subprocess.Popen(
        ["bash", str(script_path)],
        stdout=open(log_path, "w"),
        stderr=subprocess.STDOUT,
        cwd=str(_HOME_DIR),
        start_new_session=True,
    )
    return {"status": "ok", "message": f"setup running in background, log: {log_path}"}


@app.get("/debug/fastapi_log")
def debug_fastapi_log(n: int = 80):
    """FastAPI サービスの直近ログを返す（FT4/FT8 TX診断用）。"""
    try:
        r = subprocess.run(
            ["journalctl", "-u", "fastapi", "-n", str(n), "--no-pager", "--output=short"],
            capture_output=True, text=True, timeout=10)
        return {"log": r.stdout or r.stderr or "(empty)"}
    except Exception as e:
        return {"error": str(e)}


@app.get("/debug/tx")
def debug_tx():
    """直近の audio_tx (ptt=0) の結果を返す — aplay が起動できたか/失敗理由を確認するためのデバッグ用"""
    return _last_tx_debug


@app.post("/debug/test_tx")
async def debug_test_tx(_: None = Depends(verify_key)):
    """Android を介さず Pi 単体で PTT + 700Hz トーン 2 秒再生。Pi→無線機の音声パスを確認するためのデバッグ用"""
    loop = asyncio.get_running_loop()

    def _play():
        import math, struct
        subprocess.run(["pkill", "-9", "aplay"],   capture_output=True)
        subprocess.run(["pkill", "-9", "ffmpeg"],  capture_output=True)
        time.sleep(0.3)

        rate, freq, dur = 8000, 700, 2
        samples = rate * dur
        data = bytearray()
        for i in range(samples):
            v = int(32767 * 0.8 * math.sin(2 * math.pi * freq * i / rate))
            data += struct.pack('<h', v)

        ptt_ok = bool(rigctl_cmd_priority("T 1"))
        time.sleep(0.3)

        proc = subprocess.Popen(
            ["aplay", "-D", _alsa_playback_dev, "-f", "S16_LE", "-r", str(rate), "-c", "1"],
            stdin=subprocess.PIPE, stderr=subprocess.PIPE
        )
        proc.stdin.write(bytes(data))
        proc.stdin.close()
        try:
            rc = proc.wait(timeout=6)
            err = proc.stderr.read(512).decode(errors="replace").strip()
        except subprocess.TimeoutExpired:
            proc.kill()
            rc, err = -1, "timeout"

        rigctl_cmd_priority("T 0")
        return {"ptt_ok": ptt_ok, "aplay_rc": rc, "aplay_err": err,
                "dev": _alsa_playback_dev, "note": "700Hz 2sec tone sent"}

    return await loop.run_in_executor(None, _play)


@app.get("/admin/setup_log")
async def admin_setup_log(lines: int = 60):
    """create_api.sh の実行ログ末尾を返す"""
    log_path = Path("/tmp/create_api.log")
    if not log_path.exists():
        return {"running": False, "log": ""}
    text = log_path.read_text(errors="replace")
    tail = "\n".join(text.splitlines()[-lines:])
    running = Path("/proc").exists() and any(
        "create_api" in Path(f"/proc/{p}/cmdline").read_text(errors="replace")
        for p in os.listdir("/proc") if p.isdigit()
        if Path(f"/proc/{p}/cmdline").exists()
    )
    return {"running": running, "log": tail}


_MFSK_BUILD_LOG = "/tmp/mfsk_build.log"
_CARGO_TOML = r"""
[package]
name        = "mfsk-decode"
version     = "0.16.2"
edition     = "2021"
publish     = false

[[bin]]
name = "mfsk-decode"
path = "src/main.rs"

[dependencies]
mfsk-core = { git = "https://github.com/jl1nie/mfsk-core", tag = "v0.16.2", package = "mfsk-core", features = ["fft-rustfft", "ft8", "ft4"] }
hound = "3"

[profile.release]
opt-level = 3
lto = true
codegen-units = 1
""".strip()

_MAIN_RS = r"""
use std::collections::HashSet;
use std::env;
use std::io::{self, Write};
use mfsk_core::ft8::Ft8;
use mfsk_core::ft4::Ft4;
use mfsk_core::decoder::{DecodeParams, Decoder, Depth, SlotInput};
fn main() {
    let args: Vec<String> = env::args().collect();
    let mut wav_path: Option<String> = None;
    let mut freq_min: f32 = 100.0;
    let mut freq_max: f32 = 3000.0;
    let mut is_ft4 = false;
    let mut depth: u8 = 1;
    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "-c"|"--my-call" => { i+=2; }
            "-x"|"--dx-call" => { i+=2; }
            "--freq-min" => { freq_min = args.get(i+1).and_then(|s|s.parse().ok()).unwrap_or(100.0); i+=2; }
            "--freq-max" => { freq_max = args.get(i+1).and_then(|s|s.parse().ok()).unwrap_or(3000.0); i+=2; }
            "--depth"|"--sic-rounds" => { depth = args.get(i+1).and_then(|s|s.parse().ok()).unwrap_or(1); i+=2; }
            "-k"|"--known-call" => { i+=2; }
            "--ft4" => { is_ft4 = true; i+=1; }
            arg if !arg.starts_with('-') => { wav_path = Some(arg.to_string()); i+=1; }
            _ => { i+=1; }
        }
    }
    let wav_path = match wav_path {
        Some(p) => p,
        None => { eprintln!("Usage: mfsk-decode [--ft4] [--freq-min HZ] [--freq-max HZ] [--depth 1|2|3] <wav>"); std::process::exit(1); }
    };
    let audio = match load_wav_12khz(&wav_path) {
        Ok(a) => a,
        Err(e) => { eprintln!("[mfsk-decode] WAV load error: {}", e); std::process::exit(1); }
    };
    let d = match depth { 1 => Depth::Fast, 3 => Depth::Deep, _ => Depth::Normal };
    let slot = SlotInput::i16(&audio);
    let stdout = io::stdout();
    let mut seen: HashSet<String> = HashSet::new();
    if is_ft4 {
        let mut dec = Decoder::<Ft4>::new(DecodeParams::for_band((freq_min, freq_max)).depth(d));
        let result = dec.decode(&slot);
        for row in &result.rows {
            let decoded = &row.decoded;
            let text = decoded.text.clone();
            if !seen.insert(text.clone()) { continue; }
            let escaped = text.replace('\\', "\\\\").replace('"', "\\\"").replace('\n', "\\n").replace('\r', "\\r");
            let line = format!("{{\"freq\":{:.1},\"snr\":{:.1},\"dt\":{:.2},\"msg\":\"{}\"}}",
                decoded.freq_hz, decoded.snr_db, decoded.dt_sec, escaped);
            let mut out = stdout.lock(); writeln!(out, "{}", line).ok(); let _ = out.flush();
        }
    } else {
        let mut dec = Decoder::<Ft8>::new(DecodeParams::for_band((freq_min, freq_max)).depth(d));
        let result = dec.decode(&slot);
        for row in &result.rows {
            let decoded = &row.decoded;
            let text = decoded.text.clone();
            if !seen.insert(text.clone()) { continue; }
            let escaped = text.replace('\\', "\\\\").replace('"', "\\\"").replace('\n', "\\n").replace('\r', "\\r");
            let line = format!("{{\"freq\":{:.1},\"snr\":{:.1},\"dt\":{:.2},\"msg\":\"{}\"}}",
                decoded.freq_hz, decoded.snr_db, decoded.dt_sec, escaped);
            let mut out = stdout.lock(); writeln!(out, "{}", line).ok(); let _ = out.flush();
        }
    }
}
fn load_wav_12khz(path: &str) -> Result<Vec<i16>, Box<dyn std::error::Error>> {
    let mut reader = hound::WavReader::open(path)?;
    let spec = reader.spec();
    if spec.channels != 1 { return Err(format!("mono expected, got {} ch", spec.channels).into()); }
    if spec.sample_rate != 12000 { eprintln!("[mfsk-decode] warning: {} Hz", spec.sample_rate); }
    let samples: Vec<i16> = match (spec.sample_format, spec.bits_per_sample) {
        (hound::SampleFormat::Int, 16) => reader.samples::<i16>().map(|s| s.unwrap_or(0)).collect(),
        (hound::SampleFormat::Float, _) => reader.samples::<f32>().map(|s| (s.unwrap_or(0.0).clamp(-1.0, 1.0) * 32767.0) as i16).collect(),
        (hound::SampleFormat::Int, b) => { let scale = (1i64 << (b-1)) as f64; reader.samples::<i32>().map(|s| ((s.unwrap_or(0) as f64 / scale) * 32767.0) as i16).collect() }
    };
    Ok(samples)
}
""".strip()


def _mfsk_build_worker():
    import datetime as _dt
    log = open(_MFSK_BUILD_LOG, "w", buffering=1)
    def w(msg):
        ts = _dt.datetime.now().strftime("%H:%M:%S")
        log.write(f"[{ts}] {msg}\n")
        log.flush()
    try:
        w(f"mfsk-decode ビルド開始")
        cargo_env = str(_HOME_DIR / ".cargo" / "env")
        # Rust インストール確認
        cargo_bin = str(_HOME_DIR / ".cargo" / "bin" / "cargo")
        if not os.path.isfile(cargo_bin):
            w("Rust をインストール中 (10〜15分かかります)...")
            r = subprocess.run(
                ["sh", "-c",
                 "curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs"
                 " | sh -s -- -y --no-modify-path"],
                capture_output=True, text=True, timeout=900
            )
            w(r.stdout[-500:] if r.stdout else "")
            if r.returncode != 0:
                w(f"Rust インストール失敗: {r.stderr[-300:]}")
                w("=== 失敗 ===")
                return
            w("Rust インストール完了")

        # ソース展開 (Cargo.lock を削除して最新 mfsk-core を取得)
        src_dir = _HOME_DIR / "mfsk-decode" / "src"
        src_dir.mkdir(parents=True, exist_ok=True)
        (_HOME_DIR / "mfsk-decode" / "Cargo.toml").write_text(_CARGO_TOML)
        (src_dir / "main.rs").write_text(_MAIN_RS)
        lock_path = _HOME_DIR / "mfsk-decode" / "Cargo.lock"
        if lock_path.exists():
            lock_path.unlink()
            w("Cargo.lock 削除 (最新依存関係を取得)")
        w("ソース展開完了")

        # ビルド
        w("cargo build --release 開始 (初回は 10〜15 分かかります)...")
        env = os.environ.copy()
        env["PATH"] = str(_HOME_DIR / ".cargo" / "bin") + ":" + env.get("PATH", "")
        env["HOME"] = str(_HOME_DIR)
        # rustup default が未設定 / toolchain が壊れている場合に備えて再インストール
        r_ru = subprocess.run(
            "rustup default stable",
            shell=True,
            capture_output=True, text=True, timeout=600, env=env
        )
        w(f"rustup default stable: rc={r_ru.returncode}" +
          (f" {r_ru.stderr.strip()[:200]}" if r_ru.returncode != 0 else ""))
        r_inst = subprocess.run(
            "rustup toolchain install stable --no-self-update",
            shell=True,
            capture_output=True, text=True, timeout=900, env=env
        )
        w(f"rustup toolchain install stable: rc={r_inst.returncode}" +
          (f" {r_inst.stderr.strip()[:200]}" if r_inst.returncode != 0 else ""))
        proc = subprocess.Popen(
            [cargo_bin, "build", "--release"],
            cwd=str(_HOME_DIR / "mfsk-decode"),
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, env=env
        )
        for line in proc.stdout:
            log.write(line)
            log.flush()
        proc.wait()
        if proc.returncode == 0:
            bin_path = _HOME_DIR / "mfsk-decode" / "target" / "release" / "mfsk-decode"
            w(f"ビルド完了: {bin_path}")
            w("=== 完了 ===")
        else:
            w(f"ビルド失敗 (returncode={proc.returncode})")
            w("=== 失敗 ===")
    except Exception as e:
        log.write(f"[error] {e}\n=== 失敗 ===\n")
    finally:
        log.close()


@app.post("/admin/build_mfsk")
async def admin_build_mfsk(force: bool = False):
    """mfsk-decode をバックグラウンドでビルドする (初回 Update Pi 後に Android から呼ぶ)"""
    bin_path = _HOME_DIR / "mfsk-decode" / "target" / "release" / "mfsk-decode"
    if bin_path.exists() and not force:
        return {"status": "already_built", "path": str(bin_path)}
    if bin_path.exists() and force:
        try: bin_path.unlink()
        except Exception: pass
    threading.Thread(target=_mfsk_build_worker, daemon=False).start()
    return {"status": "building", "log": _MFSK_BUILD_LOG}


@app.get("/admin/mfsk_build_log")
async def admin_mfsk_build_log():
    """mfsk-decode ビルドログの末尾を返す"""
    log_path = Path(_MFSK_BUILD_LOG)
    if not log_path.exists():
        return {"status": "not_started", "log": ""}
    text = log_path.read_text(errors="replace")
    lines = text.splitlines()
    done = any("=== 完了 ===" in l for l in lines)
    failed = any("=== 失敗 ===" in l for l in lines)
    status = "done" if done else ("failed" if failed else "building")
    return {"status": status, "log": "\n".join(lines[-40:])}


@app.post("/admin/reboot")
async def admin_reboot():
    """ラズパイを再起動する"""
    # start_new_session=True でデタッチ: FastAPI が _restart() で kill されても reboot は実行される
    subprocess.Popen(
        ["bash", "-c", "sleep 2 && sudo -n /bin/systemctl reboot"],
        start_new_session=True,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    return {"ok": True}


@app.post("/admin/set_api_key")
async def admin_set_api_key(request: Request):
    """API キーを設定して FastAPI を再起動する。
    API_KEY 未設定時は認証不要（WireGuard 初回セットアップ用）。
    設定済みの場合は X-API-Key ヘッダーによる認証が必要。"""
    hkey = request.headers.get("X-API-Key", "")
    if API_KEY and not hmac.compare_digest(hkey or "", API_KEY):
        raise HTTPException(status_code=403, detail="Invalid API key")
    body = await request.json()
    new_key = (body.get("new_key") or "").strip()
    if not new_key:
        raise HTTPException(status_code=400, detail="new_key is required")
    import re as _re
    if not _re.match(r'^[^\s]{4,256}$', new_key):
        raise HTTPException(status_code=400, detail=f"Invalid key format (len={len(new_key)}): must be 4-256 non-whitespace chars")

    # .env に API_KEY を直接書き込む（sudo 不要 — ユーザーホーム内）
    env_path = _HOME_DIR / "fastapi" / ".env"
    try:
        env_path.parent.mkdir(parents=True, exist_ok=True)
        lines = env_path.read_text().splitlines() if env_path.exists() else []
        lines = [l for l in lines if not l.startswith("API_KEY=")]
        if new_key:
            lines.append(f"API_KEY={new_key}")
        env_path.write_text("\n".join(lines) + "\n")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to write .env: {e}")

    # systemd drop-in で EnvironmentFile を登録（未設定の場合のみ）
    for svc in ("fastapi", "fastapi-audio"):
        drop_dir = Path(f"/etc/systemd/system/{svc}.service.d")
        drop_file = drop_dir / "env.conf"
        if not drop_file.exists():
            subprocess.run(["sudo", "-n", "mkdir", "-p", str(drop_dir)], capture_output=True)
            content = f"[Service]\nEnvironmentFile=-{env_path}\n"
            subprocess.run(["sudo", "-n", "tee", str(drop_file)],
                           input=content.encode(), capture_output=True)
    subprocess.run(["sudo", "-n", "systemctl", "daemon-reload"], capture_output=True, timeout=10)

    # サービス再起動（/admin/update と同じ nohup フォールバック方式）
    def _restart_for_key():
        import time as _t
        _t.sleep(0.3)
        for svc in ("fastapi-audio", "fastapi"):
            r = subprocess.run(["sudo", "-n", "systemctl", "restart", svc],
                               capture_output=True, timeout=15)
            if r.returncode != 0:
                print(f"[set_api_key] sudo -n restart {svc} failed: {r.stderr.strip()}", flush=True)
        # sudo 失敗時は SIGTERM で自プロセスを終了し systemd に再起動させる
        _t.sleep(0.5)
        if not subprocess.run(["pgrep", "-f", "uvicorn api"], capture_output=True).stdout:
            return  # already restarting
        # fastapi-audio は別プロセスなので pkill で終了
        subprocess.run(["pkill", "-TERM", "-f", "uvicorn.*50000"], capture_output=True)
        _t.sleep(1)
        os.kill(os.getpid(), signal.SIGTERM)

    threading.Thread(target=_restart_for_key, daemon=True).start()
    return {"ok": True}


@app.post("/admin/install_hamlib")
async def admin_install_hamlib(request: Request):
    """install_hamlib.sh を受け取りバックグラウンドで実行する"""
    content = await request.body()
    if not content:
        raise HTTPException(status_code=400, detail="Empty body")
    script_path = _HOME_DIR / "install_hamlib.sh"
    try:
        script_path.write_bytes(content)
        script_path.chmod(0o755)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Write failed: {e}")
    log_path = "/tmp/hamlib_build.log"
    open(log_path, "w").close()
    subprocess.Popen(
        ["bash", str(script_path)],
        stdout=open(log_path, "w"),
        stderr=subprocess.STDOUT,
        cwd=str(_HOME_DIR),
        start_new_session=True,
    )
    return {"status": "ok", "message": f"Hamlib install running, log: {log_path}"}


@app.get("/admin/hamlib_log")
async def admin_hamlib_log(lines: int = 60):
    """Hamlib ビルドログの末尾を返す"""
    log_path = Path("/tmp/hamlib_build.log")
    if not log_path.exists():
        return {"log": "(no log yet)"}
    text = log_path.read_text(errors="replace")
    tail = "\n".join(text.splitlines()[-lines:])
    running = Path("/proc").exists() and any(
        "install_hamlib" in Path(f"/proc/{p}/cmdline").read_text(errors="replace")
        for p in os.listdir("/proc") if p.isdigit()
        if Path(f"/proc/{p}/cmdline").exists()
    )
    return {"running": running, "log": tail}

@app.get("/admin/version")
async def admin_version():
    _local = Path.home() / ".local" / "bin" / "rigctld"
    _bin = str(_local) if _local.exists() else "rigctld"
    try:
        _r = subprocess.run([_bin, "--version"], capture_output=True, text=True, timeout=3)
        _rigctld = _r.stdout.strip().splitlines()[0] if _r.returncode == 0 else "unknown"
    except Exception as _e:
        _rigctld = str(_e)
    _mfsk_ver = "?"
    try:
        for _line in _CARGO_TOML.splitlines():
            if "mfsk-core" in _line and "tag" in _line:
                _idx = _line.find('tag = "')
                if _idx >= 0:
                    _s = _idx + 7
                    _e2 = _line.find('"', _s)
                    if _e2 > _s:
                        _mfsk_ver = _line[_s:_e2]
                        break
    except Exception:
        pass
    return {"api_version": API_VERSION, "rigctld": _rigctld, "mfsk_version": _mfsk_ver}

# ─── RTTY FSK TX via DTR/RTS (FT-991A Data COMポート) ─────────────────────────
# DTR: High=Mark, Low=Space (FSK信号)
# RTS: High=PTT ON
_rtty_tx_lock = threading.Lock()

_ITA2_LTRS = [
    ' ', 'E', '\n', 'A', ' ', 'S', 'I', 'U',
    '\r', 'D', 'R', 'J', 'N', 'F', 'C', 'K',
    'T', 'Z', 'L', 'W', 'H', 'Y', 'P', 'Q',
    'O', 'B', 'G', ' ', 'M', 'X', 'V', ' '
]
_ITA2_FIGS = [
    ' ', '3', '\n', '-', ' ', ' ', '8', '7',
    '\r', '$', '4', "'", ',', '!', ':', '(',
    '5', '"', ')', '2', '#', '6', '0', '1',
    '9', '?', '&', ' ', '.', '/', ';', ' '
]
_ITA2_RESERVED = frozenset({0, 2, 4, 8, 27, 31})
_ITA2_LTRS_SHIFT = 31
_ITA2_FIGS_SHIFT = 27


def _rtty_text_to_codes(text: str) -> list:
    codes = [_ITA2_LTRS_SHIFT]
    in_figs = False
    for c in text.upper():
        if c == ' ':  codes.append(4); in_figs = False; continue
        if c == '\n': codes.append(2); in_figs = False; continue
        if c == '\r': codes.append(8); in_figs = False; continue
        code = -1; need_figs = False
        for i, ch in enumerate(_ITA2_LTRS):
            if i not in _ITA2_RESERVED and ch == c:
                code = i; break
        if code < 0:
            for i, ch in enumerate(_ITA2_FIGS):
                if i not in _ITA2_RESERVED and ch == c:
                    code = i; need_figs = True; break
        if code < 0:
            continue
        if need_figs and not in_figs:
            codes.append(_ITA2_FIGS_SHIFT); in_figs = True
        elif not need_figs and in_figs:
            codes.append(_ITA2_LTRS_SHIFT); in_figs = False
        codes.append(code)
    return codes


def _rtty_fsk_send(port_name: str, text: str, baud: float = 45.45, fsk_pin: str = "DTR"):
    """fsk_pin="DTR": FSK=DTR, PTT=RTS  /  fsk_pin="RTS": FSK=RTS, PTT=DTR"""
    if not _HAS_SERIAL:
        raise RuntimeError("pyserial not installed")
    bit_sec = 1.0 / baud
    use_dtr = fsk_pin.upper() != "RTS"  # True → DTR=FSK, RTS=PTT

    ser = _serial.Serial()
    ser.port     = port_name
    ser.baudrate = 4800
    ser.dtr      = use_dtr      # Mark idle on FSK pin before open
    ser.rts      = not use_dtr  # Mark idle on FSK pin if RTS mode
    ser.open()
    try:
        time.sleep(0.05)
        if use_dtr:
            ser.rts = True
        else:
            ser.dtr = True
        time.sleep(0.3)   # TX settle

        def set_fsk(mark: bool):
            if use_dtr:
                ser.dtr = mark
            else:
                ser.rts = mark

        def send_bit(mark: bool, duration: float):
            t_end = time.perf_counter() + duration
            set_fsk(mark)
            slack = t_end - time.perf_counter() - 0.001
            if slack > 0:
                time.sleep(slack)
            while time.perf_counter() < t_end:
                pass

        def send_code(code: int):
            send_bit(False, bit_sec)           # start bit (Space)
            for b in range(5):
                send_bit(bool((code >> b) & 1), bit_sec)
            # 1.5 stop bits (Mark)
            t_end = time.perf_counter() + bit_sec * 1.5
            set_fsk(True)
            slack = bit_sec * 1.5 - 0.001
            if slack > 0:
                time.sleep(slack)
            while time.perf_counter() < t_end:
                pass

        set_fsk(True)
        time.sleep(bit_sec * 3)   # leading mark idle

        for code in _rtty_text_to_codes(text):
            send_code(code)

        time.sleep(bit_sec * 10)  # trailing mark idle (~220ms at 45.45 baud)

    finally:
        if use_dtr:
            ser.rts = False
            ser.dtr = True
        else:
            ser.dtr = False
            ser.rts = True
        ser.close()


@app.post("/radio/rtty_fsk_tx")
async def rtty_fsk_tx(port: str = Form(...), text: str = Form(...),
                       baud: float = Form(45.45), fsk_pin: str = Form("DTR")):
    """RTTY FSK送信。fsk_pin: DTR(FSK=DTR,PTT=RTS) / RTS(FSK=RTS,PTT=DTR)"""
    if not _HAS_SERIAL:
        raise HTTPException(status_code=501, detail="pyserial not available")
    if not text:
        raise HTTPException(status_code=400, detail="empty text")
    if fsk_pin.upper() not in ("DTR", "RTS"):
        raise HTTPException(status_code=400, detail="fsk_pin must be DTR or RTS")
    # /devices reports bare names ("ttyACM0"); pyserial needs a full path.
    # パストラバーサル対策: /dev/ 配下の正当なデバイス名のみ許可する
    port = f"/dev/{_validate_dev_name(port, 'port')}"
    if not os.path.exists(port):
        raise HTTPException(status_code=400,
                            detail=f"serial port {port} not found "
                                   f"(available: {', '.join(sorted(os.path.basename(p) for p in glob.glob('/dev/ttyUSB*') + glob.glob('/dev/ttyACM*'))) or 'none'})")
    if not _rtty_tx_lock.acquire(blocking=False):
        raise HTTPException(status_code=409, detail="RTTY TX busy")
    try:
        await asyncio.get_event_loop().run_in_executor(
            None, _rtty_fsk_send, port, text, baud, fsk_pin.upper())
        return {"status": "ok"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        _rtty_tx_lock.release()


# ── WireGuard セットアップ ──────────────────────────────────────────────────

@app.post("/wireguard/setup")
async def wireguard_setup(request: Request):
    """WireGuard サーバーセットアップ（ストリーミング SSE）"""
    qkey = request.query_params.get("api_key", "")
    hkey = request.headers.get("X-API-Key", "")
    if API_KEY and not (hmac.compare_digest(qkey or "", API_KEY) or hmac.compare_digest(hkey or "", API_KEY)):
        raise HTTPException(status_code=403, detail="Forbidden")

    body = await request.json()
    ddns_domain = body.get("ddns_domain", "").strip().lower()
    ddns_token  = body.get("ddns_token", "").strip()
    static_ip   = body.get("static_ip", "").strip()   # 空文字 = IP固定スキップ
    setup_ufw   = body.get("setup_ufw", True)
    sudo_pass   = body.get("sudo_pass", "").strip()

    if not ddns_domain or not ddns_token:
        raise HTTPException(status_code=400, detail="ddns_domain and ddns_token are required")

    def _evt(msg_type: str, **kw) -> bytes:
        return ("data: " + _json.dumps({"type": msg_type, **kw}, ensure_ascii=False) + "\n\n").encode()

    async def _run(cmd: str):
        proc = await asyncio.create_subprocess_shell(
            cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        async for raw in proc.stdout:
            line = raw.decode(errors="replace").rstrip()
            if line:
                yield _evt("log", msg=line)
        await proc.wait()

    async def _run_capture(cmd: str) -> str:
        proc = await asyncio.create_subprocess_shell(
            cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL
        )
        out, _ = await proc.communicate()
        return out.decode(errors="replace").strip()

    import shlex as _shlex
    _sudo = (f"echo {_shlex.quote(sudo_pass)} | sudo -S -p ''"
             if sudo_pass else "sudo")

    async def _stream():
        import re as _re
        try:
            yield _evt("log", msg="=== Pi の IP/Gateway を自動検出 ===")
            # wlan* を優先（複数 wlan / wg0 混在対策）
            wlan_route = await _run_capture(
                "ip route | grep default | grep 'dev wlan' | head -1")
            route = wlan_route if wlan_route else await _run_capture(
                "ip route | grep default | head -1")
            gw_m  = _re.search(r'via (\S+)', route)
            if_m  = _re.search(r'dev (\S+)', route)
            gateway = gw_m.group(1) if gw_m else "192.168.1.1"
            iface   = if_m.group(1) if if_m else "wlan0"
            cidr    = await _run_capture(
                f"ip addr show {iface} | grep 'inet ' | awk '{{print $2}}' | head -1")
            pi_ip   = cidr.split('/')[0] if '/' in cidr else cidr
            if not pi_ip:
                yield _evt("log", msg="⚠ IP 検出失敗 — デフォルト 192.168.1.60/24 を使用")
                pi_ip, cidr, gateway = "192.168.1.60", "192.168.1.60/24", "192.168.1.1"
            yield _evt("log", msg=f"IP: {pi_ip}  CIDR: {cidr}  Gateway: {gateway}  IF: {iface}")
            yield _evt("info", pi_ip=pi_ip, gateway=gateway, iface=iface)

            yield _evt("log", msg="=== WireGuard インストール ===")
            async for msg in _run(f"{_sudo} apt-get install -y wireguard wireguard-tools iptables 2>&1"):
                yield msg

            yield _evt("log", msg="=== サーバー/クライアント鍵を生成 ===")
            import os as _os, tempfile as _tmp
            key_dir = _os.path.expanduser("~/wgkeys")
            await _run_capture(f"mkdir -p {key_dir}/server {key_dir}/android1")
            srv_priv = await _run_capture(f"wg genkey | tee {key_dir}/server/privatekey")
            srv_pub  = await _run_capture(f"wg pubkey < {key_dir}/server/privatekey | tee {key_dir}/server/publickey")
            await _run_capture(f"chmod 600 {key_dir}/server/privatekey")
            cli_priv = await _run_capture(f"wg genkey | tee {key_dir}/android1/privatekey")
            cli_pub  = await _run_capture(f"wg pubkey < {key_dir}/android1/privatekey | tee {key_dir}/android1/publickey")
            await _run_capture(f"chmod 600 {key_dir}/android1/privatekey")
            yield _evt("log", msg=f"Server pub: {srv_pub}  Client pub: {cli_pub}")

            # iptables 絶対パスを取得（head -1 パイプを避けて確実に取得）
            _ipt = await _run_capture(
                "command -v iptables 2>/dev/null"
                " || command -v /usr/sbin/iptables 2>/dev/null"
                " || command -v /sbin/iptables 2>/dev/null"
                " || echo /usr/sbin/iptables")
            yield _evt("log", msg=f"iptables: {_ipt}")

            # wg0.conf + 起動 + cron を sudo python3 で一括実行（sudo cp/bash/wg-quick が不要）
            yield _evt("log", msg="=== wg0.conf 生成・WireGuard 起動・cron 設定 ===")
            wg0_full = (
                "[Interface]\n"
                "Address = 10.0.0.1/24\n"
                "ListenPort = 51820\n"
                f"PrivateKey = {srv_priv}\n\n"
                f"PostUp = {_ipt} -A FORWARD -i wg0 -j ACCEPT; {_ipt} -t nat -A POSTROUTING -o {iface} -j MASQUERADE\n"
                f"PostDown = {_ipt} -D FORWARD -i wg0 -j ACCEPT; {_ipt} -t nat -D POSTROUTING -o {iface} -j MASQUERADE\n\n"
                "[Peer]\n"
                f"PublicKey = {cli_pub}\n"
                "AllowedIPs = 10.0.0.2/32\n"
            )
            cron_content = (
                f"*/5 * * * * root curl -s "
                f"\"https://www.duckdns.org/update?domains={_shlex.quote(ddns_domain)}"
                f"&token={_shlex.quote(ddns_token)}&ip=\" > /dev/null 2>&1\n"
            )
            with _tmp.NamedTemporaryFile("w", suffix=".conf", delete=False) as _tf:
                _tf.write(wg0_full)
                _wg_conf_tmp = _tf.name
            with _tmp.NamedTemporaryFile("w", suffix=".cron", delete=False) as _tf:
                _tf.write(cron_content)
                _cron_tmp = _tf.name
            _wg_py = (
                "import pathlib, os, subprocess, shutil\n"
                "# wireguard-tools インストール確認\n"
                "import shutil as _sh\n"
                "if not _sh.which('wg-quick'):\n"
                "    print('wg-quick not found — apt install wireguard...')\n"
                "    ri = subprocess.run(\n"
                "        ['apt-get', 'install', '-y', 'wireguard'],\n"
                "        capture_output=True, text=True)\n"
                "    print('apt install rc:', ri.returncode, ri.stderr[-200:] if ri.stderr else '')\n"
                "else:\n"
                "    print('wg-quick: OK')\n"
                "# カーネルモジュールロード\n"
                "rm = subprocess.run(['modprobe', 'wireguard'], capture_output=True, text=True)\n"
                "print('modprobe wireguard rc:', rm.returncode,\n"
                "      rm.stderr.strip()[:120] if rm.stderr.strip() else 'OK')\n"
                "# iptables パス確認\n"
                "ipt = _sh.which('iptables') or _sh.which('/sbin/iptables') or _sh.which('/usr/sbin/iptables')\n"
                "print('iptables:', ipt or 'NOT FOUND')\n"
                "# wg0.conf\n"
                "d = pathlib.Path('/etc/wireguard')\n"
                "d.mkdir(parents=True, exist_ok=True)\n"
                "os.chmod(str(d), 0o700)\n"
                f"shutil.copy2('{_wg_conf_tmp}', '/etc/wireguard/wg0.conf')\n"
                "os.chmod('/etc/wireguard/wg0.conf', 0o600)\n"
                "print('wg0.conf: OK')\n"
                "# IP 転送\n"
                "try:\n"
                "    pathlib.Path('/proc/sys/net/ipv4/ip_forward').write_text('1')\n"
                "    pathlib.Path('/etc/sysctl.d/99-wireguard.conf').write_text('net.ipv4.ip_forward=1\\n')\n"
                "    print('ip_forward: OK')\n"
                "except Exception as e: print('ip_forward err:', e)\n"
                "# PATH を明示設定\n"
                "_full_path = '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'\n"
                "_env = dict(os.environ); _env['PATH'] = _full_path\n"
                "# 既存 wg0 を停止・削除\n"
                "subprocess.run(['systemctl', 'stop', 'wg-quick@wg0'], capture_output=True)\n"
                "subprocess.run(['ip', 'link', 'del', 'wg0'], capture_output=True)\n"
                "# ip + wg で直接セットアップ（wg-quick 不使用）\n"
                "r_add = subprocess.run(['ip', 'link', 'add', 'dev', 'wg0', 'type', 'wireguard'],\n"
                "    capture_output=True, text=True)\n"
                "print('ip link add wg0 rc:', r_add.returncode, r_add.stderr.strip()[:100])\n"
                "if r_add.returncode == 0:\n"
                "    # wg set: wg-quick 専用フィールド不要の直接設定\n"
                f"    r_set = subprocess.run(\n"
                f"        ['wg', 'set', 'wg0',\n"
                f"         'private-key', '{key_dir}/server/privatekey',\n"
                f"         'listen-port', '51820',\n"
                f"         'peer', '{cli_pub}', 'allowed-ips', '10.0.0.2/32'],\n"
                "        capture_output=True, text=True, env=_env)\n"
                "    print('wg set rc:', r_set.returncode, r_set.stderr.strip()[:100])\n"
                "    subprocess.run(['ip', 'addr', 'add', '10.0.0.1/24', 'dev', 'wg0'],\n"
                "        capture_output=True)\n"
                "    subprocess.run(['ip', 'link', 'set', 'up', 'dev', 'wg0'], capture_output=True)\n"
                "    print('wg0 up: OK')\n"
                "    # iptables NAT\n"
                f"    ipt_bin = '{_ipt}'\n"
                "    subprocess.run([ipt_bin, '-A', 'FORWARD', '-i', 'wg0', '-j', 'ACCEPT'],\n"
                "        capture_output=True, env=_env)\n"
                f"    subprocess.run([ipt_bin, '-t', 'nat', '-A', 'POSTROUTING', '-o', '{iface}', '-j', 'MASQUERADE'],\n"
                "        capture_output=True, env=_env)\n"
                "    print('iptables NAT: OK')\n"
                "    # 自動起動: wg-quick@wg0 を enable（起動は手動セットアップ済みなので不要）\n"
                "    subprocess.run(['systemctl', 'enable', 'wg-quick@wg0'], capture_output=True)\n"
                "    print('systemctl enable: OK')\n"
                "else:\n"
                "    print('[ERROR] ip link add wg0 失敗')\n"
                "    jc = subprocess.run(\n"
                "        ['dmesg', '--level=err,warn', '--since', '1 minute ago'],\n"
                "        capture_output=True, text=True)\n"
                "    print(jc.stdout[-400:] if jc.stdout else '')\n"
                "# DuckDNS cron\n"
                f"shutil.copy2('{_cron_tmp}', '/etc/cron.d/duckdns')\n"
                "os.chmod('/etc/cron.d/duckdns', 0o644)\n"
                "print('duckdns cron: OK')\n"
                "# wg0 状態確認\n"
                "r3 = subprocess.run(['wg', 'show', 'wg0'], capture_output=True, text=True)\n"
                "print('=== wg show wg0 ===')\n"
                "print(r3.stdout.strip() or r3.stderr.strip() or '(no output)')\n"
                "r4 = subprocess.run(['ip', 'link', 'show', 'wg0'], capture_output=True, text=True)\n"
                "print('ip link:', r4.stdout.strip())\n"
            )
            with _tmp.NamedTemporaryFile("w", suffix=".py", delete=False) as _tf:
                _tf.write(_wg_py)
                _wg_py_path = _tf.name
            # sudo 権限チェック
            if sudo_pass:
                _sudo_chk = await _run_capture(
                    f"echo {_shlex.quote(sudo_pass)} | sudo -S -p '' true 2>&1")
                _sudo_ok = not _sudo_chk or (
                    "password" not in _sudo_chk.lower() and "sudo:" not in _sudo_chk.lower())
            else:
                # NOPASSWD チェック: apt-get は NOPASSWD リストに含まれるので -n で確認
                _sudo_chk = await _run_capture("sudo -n /usr/bin/apt-get --version 2>&1")
                _sudo_ok = not _sudo_chk or (
                    "password" not in _sudo_chk.lower() and "sudo:" not in _sudo_chk.lower())
            if not _sudo_ok:
                yield _evt("log", msg="[ERROR] sudo 認証失敗。Pi のパスワードを入力してください。")
                yield _evt("log", msg="（SETUP Pi を実施済みであれば空欄で OK のはずです）")
                yield _evt("error", msg="sudo 認証失敗。Pi のパスワードを入力してください。")
                return
            yield _evt("log", msg="sudo: OK")
            async for msg in _run(f"{_sudo} python3 {_wg_py_path}"): yield msg
            # sudo 不要の ip link で wg0 起動確認
            _wg_status = await _run_capture("ip link show wg0 2>&1")
            if _wg_status and "wg0" in _wg_status:
                yield _evt("log", msg=f"[OK] wg0 起動確認: {_wg_status[:200]}")
            else:
                yield _evt("log", msg=f"[NG] wg0 未起動: {_wg_status[:200]}")

            # ── ufw 設定（オプション）──
            # ★ 旧版は「ufw が既に有効な場合のみルール追加」だったため未設定の Pi では
            #   何もせず FW が無効のままだった。本版では ufw 導入・有効化まで行う。
            #   許可方針: SSH(22)/WireGuard(51820)はどこからでも、アプリ各ポート
            #   (8000/50000/8443 tcp・8889 udp)は LAN + WireGuard サブネットのみ。
            #   8001(direwolf KISS)は localhost 内部用のため開放しない。
            if setup_ufw:
                yield _evt("log", msg="=== ufw ファイアウォール設定 ===")
                _ufw_py = (
                    "import subprocess, re\n"
                    "# ufw 未導入なら導入\n"
                    "if subprocess.run(['which', 'ufw'], capture_output=True).returncode != 0:\n"
                    "    subprocess.run(['apt-get', 'install', '-y', 'ufw'], capture_output=True)\n"
                    "# LAN サブネットを default route から導出 (例: 192.168.0.1 → 192.168.0.0/24)\n"
                    "lan = '192.168.0.0/24'\n"
                    "try:\n"
                    "    r = subprocess.run(['ip', 'route', 'show', 'default'], capture_output=True, text=True)\n"
                    "    m = re.search(r'via (\\d+)\\.(\\d+)\\.(\\d+)\\.\\d+', r.stdout)\n"
                    "    if m: lan = f'{m.group(1)}.{m.group(2)}.{m.group(3)}.0/24'\n"
                    "except Exception as e: print('lan detect err:', e)\n"
                    "print('LAN subnet:', lan)\n"
                    "cmds = [\n"
                    "    # 締め出し防止: SSH と WireGuard を先に許可\n"
                    "    ['ufw', 'allow', '22/tcp'],\n"
                    "    ['ufw', 'allow', '51820/udp'],\n"
                    "    ['ufw', 'default', 'deny', 'incoming'],\n"
                    "    ['ufw', 'default', 'allow', 'outgoing'],\n"
                    "]\n"
                    "for sub in (lan, '10.0.0.0/24'):\n"
                    "    for port, proto in (('8000','tcp'),('50000','tcp'),('8443','tcp'),('8889','udp'),('5001','udp')):\n"
                    "        cmds.append(['ufw', 'allow', 'from', sub, 'to', 'any', 'port', port, 'proto', proto])\n"
                    "cmds += [['ufw', '--force', 'enable'], ['ufw', 'reload']]\n"
                    "for c in cmds:\n"
                    "    r = subprocess.run(c, capture_output=True, text=True)\n"
                    "    print(' '.join(c), '→', r.returncode)\n"
                )
                with _tmp.NamedTemporaryFile("w", suffix=".py", delete=False) as _tf:
                    _tf.write(_ufw_py)
                    _ufw_py_path = _tf.name
                async for msg in _run(f"{_sudo} python3 {_ufw_py_path}"): yield msg
                yield _evt("log", msg="ufw 設定完了")

            yield _evt("log", msg="=== DuckDNS IP を今すぐ更新 ===")
            result = await _run_capture(
                f"curl -s 'https://www.duckdns.org/update?domains={_shlex.quote(ddns_domain)}&token={_shlex.quote(ddns_token)}&ip='")
            if result == "OK":
                yield _evt("log", msg="DuckDNS IP 更新完了（5分ごとに自動更新）")
            else:
                yield _evt("log", msg=f"⚠ DuckDNS 更新失敗: {result} — ドメイン/トークンを確認")

            yield _evt("log", msg="=== Android 設定ファイルを生成 ===")
            client_conf = (
                "[Interface]\n"
                f"PrivateKey = {cli_priv}\n"
                "Address = 10.0.0.2/32\n"
                "DNS = 1.1.1.1\n\n"
                "[Peer]\n"
                f"PublicKey = {srv_pub}\n"
                f"Endpoint = {ddns_domain}.duckdns.org:51820\n"
                "AllowedIPs = 10.0.0.0/24\n"
                "PersistentKeepalive = 25\n"
            )
            yield _evt("log", msg="=== セットアップ完了 ===")
            yield _evt("config", text=client_conf, pi_ip=pi_ip)

            if static_ip:
                prefix = ("/" + cidr.split("/")[1]) if "/" in cidr else "/24"
                fixed_cidr = static_ip + prefix
                yield _evt("log", msg=f"=== {iface} を固定 IP {fixed_cidr} に設定 ===")
                yield _evt("log", msg=f"[診断] iface={iface}  現在IP={pi_ip}  GW={gateway}")
                # nmcli 一覧を Python でパース（シェル grep/cut の引用符問題を回避）
                _nmcli_raw = await _run_capture(
                    "nmcli -t -f NAME,DEVICE connection show --active 2>&1")
                yield _evt("log", msg=f"nmcli一覧: {_nmcli_raw[:300] or '(なし)'}")
                con_name = ""
                for _ln in _nmcli_raw.splitlines():
                    if _ln.endswith(f":{iface}"):
                        con_name = _ln[:-(len(iface) + 1)]
                        break
                yield _evt("log", msg=f"接続名='{con_name}'")
                if con_name:
                    # 1. まず sudo なしで nmcli を試みる（polkit 経由で許可される場合）
                    yield _evt("log", msg="nmcli polkit を試みます（失敗しても sudo で再試行）")
                    for _cmd in [
                        f"nmcli connection modify {_shlex.quote(con_name)} ipv4.addresses '{fixed_cidr}'",
                        f"nmcli connection modify {_shlex.quote(con_name)} ipv4.gateway '{gateway}'",
                        f"nmcli connection modify {_shlex.quote(con_name)} ipv4.dns '1.1.1.1'",
                        f"nmcli connection modify {_shlex.quote(con_name)} ipv4.method manual",
                    ]:
                        _o = await _run_capture(f"{_cmd} 2>&1")
                        if _o and "error" not in _o.lower():
                            yield _evt("log", msg=f"  > {_o[:120]}")
                    _chk = await _run_capture(
                        f"nmcli -f ipv4.addresses,ipv4.method connection show {_shlex.quote(con_name)} 2>/dev/null")
                    yield _evt("log", msg=f"NM設定確認: {_chk}")
                    if "manual" in _chk:
                        async for msg in _run(
                            f"nohup bash -c 'sleep 5 && nmcli connection up {_shlex.quote(con_name)}'"
                            f" > /tmp/nmcli_up.log 2>&1 &"
                        ): yield msg
                        yield _evt("log", msg=f"固定IP設定完了 — 約5秒後に {fixed_cidr} で再接続します")
                    else:
                        # 2. polkit 失敗 → sudo python3 (root) で nmcli modify + ip addr で即時変更
                        yield _evt("log", msg="nmcli polkit 失敗 — sudo python3 (root) で IP を直接変更します")
                        import tempfile as _tempfile2
                        _nm_script = (
                            "import subprocess\n"
                            # NM プロファイルを永続化
                            f"r = subprocess.run(\n"
                            f"    ['nmcli', 'connection', 'modify', '{con_name}',\n"
                            f"     'ipv4.method', 'manual',\n"
                            f"     'ipv4.addresses', '{fixed_cidr}',\n"
                            f"     'ipv4.gateway', '{gateway}',\n"
                            f"     'ipv4.dns', '1.1.1.1'],\n"
                            "    capture_output=True, text=True)\n"
                            "print('nmcli modify rc:', r.returncode, r.stderr.strip())\n"
                            # ip addr add で新 IP を即座に追加（WiFi 切断なし）
                            f"r2 = subprocess.run(['ip', 'addr', 'add', '{fixed_cidr}', 'dev', '{iface}'],\n"
                            "    capture_output=True, text=True)\n"
                            "print('ip addr add rc:', r2.returncode, r2.stderr.strip())\n"
                            # デフォルトルートを更新
                            f"r3 = subprocess.run(['ip', 'route', 'replace', 'default', 'via', '{gateway}', 'dev', '{iface}'],\n"
                            "    capture_output=True, text=True)\n"
                            "print('ip route rc:', r3.returncode, r3.stderr.strip())\n"
                            # 現在の IP を表示
                            f"r4 = subprocess.run(['ip', '-4', 'addr', 'show', 'dev', '{iface}'],\n"
                            "    capture_output=True, text=True)\n"
                            "print('現在のIP:', r4.stdout.strip())\n"
                            # 8秒後に旧 IP を削除（SSE 完了後）
                            f"subprocess.Popen(['bash', '-c', 'sleep 8 && ip addr del {cidr} dev {iface}'],\n"
                            "    start_new_session=True)\n"
                            "print('旧IP削除 8秒後に実行予定')\n"
                        )
                        with _tempfile2.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as _f2:
                            _f2.write(_nm_script)
                            _nm_path = _f2.name
                        async for msg in _run(f"{_sudo} python3 {_nm_path}"): yield msg
                        _chk2 = await _run_capture(
                            f"ip -4 addr show dev {iface} 2>/dev/null | grep 'inet '")
                        yield _evt("log", msg=f"IP確認: {_chk2}")
                        if static_ip in (_chk2 or ""):
                            yield _evt("log", msg=f"固定IP設定完了 — {fixed_cidr} に移行中（約8秒後に旧IPが消えます）")
                        else:
                            yield _evt("log", msg="⚠ 固定IP設定失敗 — UpdatePi→Setup 後に再実行してください")
                else:
                    # dhcpcd フォールバック (Raspberry Pi OS Bullseye 以前)
                    yield _evt("log", msg="nmcli 接続未検出 — dhcpcd.conf を使用")
                    script = (
                        f"import re, pathlib\n"
                        f"p = pathlib.Path('/etc/dhcpcd.conf')\n"
                        f"txt = p.read_text() if p.exists() else ''\n"
                        f"txt = re.sub(r'\\ninterface {iface}(\\n[ \\t]+\\S.*)*', '', txt)\n"
                        f"txt = txt.rstrip() + '\\ninterface {iface}\\nstatic ip_address={fixed_cidr}"
                        f"\\nstatic routers={gateway}\\nstatic domain_name_servers=1.1.1.1\\n'\n"
                        f"p.write_text(txt)\n"
                    )
                    import tempfile as _tempfile
                    with _tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as _f:
                        _f.write(script)
                        _script_path = _f.name
                    async for msg in _run(f"{_sudo} python3 {_script_path}"): yield msg
                    async for msg in _run(
                        f"{_sudo} systemctl restart dhcpcd 2>/dev/null"
                        f" || {_sudo} service dhcpcd restart 2>/dev/null || true"
                    ): yield msg
                    yield _evt("log", msg="固定IP設定完了 (dhcpcd) — Pi が新しい IP で再接続します")

        except Exception as e:
            yield _evt("error", msg=str(e))

    return StreamingResponse(
        _stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
