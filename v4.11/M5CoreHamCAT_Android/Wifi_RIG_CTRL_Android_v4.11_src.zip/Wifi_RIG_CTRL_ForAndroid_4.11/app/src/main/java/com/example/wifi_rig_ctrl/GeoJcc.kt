package com.ji1ore.wifi_rig_ctrl

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import com.ji1ore.wifi_rig_ctrl.data.JccTable
import java.util.Locale

/**
 * 現在地を取得し、住所から JCC(市) / JGC(郡・区) を逆引きする共有ユーティリティ。
 * (元は LogQsoDialogFragment にあった GPS→JCC/JGC ロジックを運用地追加でも使えるよう切り出したもの)
 * onResult は UI スレッドで呼ばれる。
 */
/** 地図上に出す運用地候補(SOTAサミット / POTA公園)。 */
data class GeoRef(val ref: String, val name: String, val lat: Double, val lon: Double)

/** 近傍D-STARレピータ候補。CSV(CS-705形式)はR1/R2を明示で持ち、無ければバンドから導出。 */
data class DstarRepeater(val callsign: String, val lat: Double, val lon: Double,
                         val freqMHz: Double, val distKm: Double,
                         val r1Override: String? = null, val r2Override: String? = null,
                         val dupDir: String = "", val offsetHz: Long = 0L) {
    /** Icom DRモードのポート: 1200M=A / 430M=B / 144M=C。 */
    val port: String get() = when {
        freqMHz in 1200.0..1400.0 -> "A"
        freqMHz in 400.0..500.0   -> "B"
        freqMHz in 140.0..150.0   -> "C"
        else -> "B"
    }
    /** R1(アクセス/エリアレピータ)。CSVの明示値があればそれ、無ければ コール左詰7 + ポート。 */
    val r1: String get() = r1Override?.trim()?.takeIf { it.isNotEmpty() } ?: (callsign.take(7).padEnd(7) + port)
    /** R2(リンク/ゲートウェイ)。CSVの明示値があればそれ、無ければ コール左詰7 + "G"。 */
    val r2: String get() = r2Override?.trim()?.takeIf { it.isNotEmpty() } ?: (callsign.take(7).padEnd(7) + "G")
    val label: String get() = "%s  %.0fkm  %.4fMHz".format(callsign.ifEmpty { r1 }, distKm, freqMHz)
}

object GeoJcc {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val http = okhttp3.OkHttpClient()

    private const val POTA_CSV = "https://pota.app/all_parks_ext.csv"
    private const val SOTA_CSV = "https://www.sotadata.org.uk/summitslist.csv"
    private val bigHttp = okhttp3.OkHttpClient.Builder()
        .connectTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(120, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    /** POTA/SOTA の全エンティティ(座標付き)公式CSVを取得・7日キャッシュし、現在地周辺を抽出。
     *  onResult は UI スレッド。初回はCSVダウンロードで時間がかかる(特にSOTAは大きい)。 */
    fun fetchNearby(ctx: Context, type: String, lat: Double, lon: Double, onResult: (List<GeoRef>, String) -> Unit) {
        val url = when (type) { "POTA" -> POTA_CSV; "SOTA" -> SOTA_CSV; else -> { onResult(emptyList(), "unsupported"); return } }
        val cacheFile = java.io.File(ctx.cacheDir, if (type == "POTA") "pota_parks.csv" else "sota_summits.csv")
        val fresh = cacheFile.exists() && cacheFile.length() > 0 &&
            (System.currentTimeMillis() - cacheFile.lastModified() < 7L * 24 * 3600 * 1000)
        Thread {
            try {
                if (!fresh) {
                    bigHttp.newCall(okhttp3.Request.Builder().url(url).header("User-Agent", "WifiRigCTRL").build()).execute().use { resp ->
                        if (!resp.isSuccessful) { mainHandler.post { onResult(emptyList(), "HTTP ${resp.code} $url") }; return@Thread }
                        resp.body?.byteStream()?.use { input -> cacheFile.outputStream().use { input.copyTo(it) } }
                    }
                }
                val list = parseCsvNearby(cacheFile, lat, lon)
                val dbg = if (list.isEmpty()) ctx.getString(R.string.geojcc_1, cacheFile.length(), url) else ""
                mainHandler.post { onResult(list, dbg) }
            } catch (e: Exception) {
                mainHandler.post { onResult(emptyList(), ctx.getString(R.string.geojcc_2, e.message)) }
            }
        }.start()
    }

    /** 近傍D-STARレピータ(RepeaterBook export API)。token=X-RB-App-Token。onResultはUIスレッド。 */
    fun fetchDstarRepeaters(token: String, ua: String, lat: Double, lon: Double,
                            onResult: (List<DstarRepeater>, String) -> Unit) {
        if (token.isBlank()) { mainHandler.post { onResult(emptyList(), "RepeaterBookトークン未設定") }; return }
        val url = "https://www.repeaterbook.com/api/exportROW.php?country=Japan"
        Thread {
            try {
                val req = okhttp3.Request.Builder().url(url)
                    .header("User-Agent", ua).header("X-RB-App-Token", token).build()
                bigHttp.newCall(req).execute().use { resp ->
                    val body = resp.body?.string() ?: ""
                    if (!resp.isSuccessful) { mainHandler.post { onResult(emptyList(), "HTTP ${resp.code}") }; return@Thread }
                    val arr = org.json.JSONObject(body).optJSONArray("results") ?: org.json.JSONArray()
                    val out = ArrayList<DstarRepeater>()
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val dstar = o.optString("D-Star").equals("Yes", true) ||
                            o.optString("Mode").contains("star", true)
                        if (!dstar) continue
                        val call = o.optString("Callsign").trim()
                        val la = o.optString("Lat").toDoubleOrNull() ?: continue
                        val lo = o.optString("Long").toDoubleOrNull() ?: continue
                        val f  = o.optString("Frequency").toDoubleOrNull() ?: 0.0
                        if (call.isEmpty()) continue
                        out.add(DstarRepeater(call, la, lo, f, haversineKm(lat, lon, la, lo)))
                    }
                    out.sortBy { it.distKm }
                    mainHandler.post { onResult(out.take(40), if (out.isEmpty()) "D-STAR局0件(応答${body.length}B)" else "") }
                }
            } catch (e: Exception) { mainHandler.post { onResult(emptyList(), "取得失敗: ${e.message}") } }
        }.start()
    }

    private fun haversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val dLat = Math.toRadians(lat2 - lat1); val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat/2)*Math.sin(dLat/2) +
            Math.cos(Math.toRadians(lat1))*Math.cos(Math.toRadians(lat2))*Math.sin(dLon/2)*Math.sin(dLon/2)
        return 6371.0 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    }

    private fun splitCsvLine(line: String): List<String> {
        val res = ArrayList<String>(); val sb = StringBuilder(); var q = false
        for (c in line) when {
            c == '"' -> q = !q
            c == ',' && !q -> { res.add(sb.toString()); sb.setLength(0) }
            else -> sb.append(c)
        }
        res.add(sb.toString()); return res
    }

    /** CS-705形式(Icom/RepeaterBookエクスポート)のレピータCSVを読み、近い順に並べる。R1=Repeater Call Sign,
     *  R2=Gateway Call Sign, 緯度経度, 周波数 を列名から自動判定。トークン不要。 */
    private fun parseDstarAll(f: java.io.File): List<DstarRepeater> {
        val out = ArrayList<DstarRepeater>()
        try {
            val bytes = f.readBytes()
            // Icom CSVはShift-JIS(CP932/MS932)、RepeaterBook等はUTF-8。UTF-8で厳密デコードを試し、
            // 不正バイトで失敗したらMS932(Shift-JIS)で読み直す。これで日本語のレピータ名が化けない。
            val cs = try {
                java.nio.charset.StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                    .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
                    .decode(java.nio.ByteBuffer.wrap(bytes))
                Charsets.UTF_8
            } catch (_: Exception) { charset("MS932") }
            val text = String(bytes, cs)
            var r1i=-1; var r2i=-1; var fi=-1; var lai=-1; var loi=-1; var ni=-1; var di=-1; var oi=-1; var header=false
            for (rawLine in text.split("\n")) {
                val line = rawLine.removeSuffix("\r")
                val cols = splitCsvLine(line)
                if (!header) {
                    val low = cols.map { it.trim().lowercase() }
                    if (low.any { it.contains("lat") } && low.any { it.contains("lon") || it.contains("lng") }) {
                        r1i = low.indexOfFirst { it.contains("repeater") && it.contains("call") }
                        r2i = low.indexOfFirst { it.contains("gateway") && it.contains("call") }
                        fi  = low.indexOfFirst { it.contains("frequency") || it == "freq" }
                        lai = low.indexOfFirst { it.contains("lat") }
                        loi = low.indexOfFirst { it.contains("lon") || it.contains("lng") }
                        ni  = low.indexOfFirst { it == "name" || it.contains("sub name") }
                        di  = low.indexOfFirst { it == "dup" || it.contains("duplex") }
                        oi  = low.indexOfFirst { it == "offset" || it.contains("offset") }
                        header = true
                    }
                    continue
                }
                if (lai < 0 || loi < 0 || cols.size <= maxOf(lai, loi)) continue
                val la = cols[lai].trim().toDoubleOrNull() ?: continue
                val lo = cols[loi].trim().toDoubleOrNull() ?: continue
                val r1 = if (r1i in 0 until cols.size) cols[r1i].trim() else ""
                val r2 = if (r2i in 0 until cols.size) cols[r2i].trim() else ""
                val fr = if (fi in 0 until cols.size) cols[fi].trim().toDoubleOrNull() ?: 0.0 else 0.0
                val nm = if (ni in 0 until cols.size) cols[ni].trim() else ""
                // Icom CSV: Dup="DUP-"/"DUP+"/"" , Offset=MHz(例 "5.000000")
                val dupRaw = if (di in 0 until cols.size) cols[di].trim().uppercase() else ""
                val dupDir = when { dupRaw.contains("+") -> "+"; dupRaw.contains("-") -> "-"; else -> "" }
                val offHz  = if (oi in 0 until cols.size)
                    ((cols[oi].trim().toDoubleOrNull() ?: 0.0) * 1_000_000.0).toLong() else 0L
                if (r1.isEmpty() && nm.isEmpty()) continue
                out.add(DstarRepeater(callsign = nm.ifEmpty { r1 }, lat = la, lon = lo, freqMHz = fr,
                    distKm = 0.0, r1Override = r1, r2Override = r2,
                    dupDir = dupDir, offsetHz = offHz))
            }
        } catch (_: Exception) {}
        return out
    }

    /** 近傍レピータ(現在地の近い順, 60件)。アクセスレピータ選択用。 */
    fun loadDstarCsvNearby(f: java.io.File, lat: Double, lon: Double): List<DstarRepeater> =
        parseDstarAll(f).map { it.copy(distKm = haversineKm(lat, lon, it.lat, it.lon)) }
            .sortedBy { it.distKm }.take(60)

    /** 全レピータ(現在地無視, コールサイン順)。繋ぎ先(ゾーンコール)の一覧選択用。 */
    fun loadDstarCsvAll(f: java.io.File): List<DstarRepeater> =
        parseDstarAll(f).sortedBy { (it.r1Override ?: it.callsign) }

    // CSV(ヘッダから列を自動判定: reference/summitCode・name・latitude・longitude)で近傍を抽出。
    private fun parseCsvNearby(f: java.io.File, lat: Double, lon: Double): List<GeoRef> {
        val out = mutableListOf<GeoRef>()
        fun splitCsv(line: String): List<String> {
            val res = mutableListOf<String>(); val sb = StringBuilder(); var q = false
            for (c in line) when {
                c == '"' -> q = !q
                c == ',' && !q -> { res.add(sb.toString()); sb.setLength(0) }
                else -> sb.append(c)
            }
            res.add(sb.toString()); return res
        }
        try {
            f.bufferedReader().use { br ->
                var ri = -1; var ni = -1; var lai = -1; var loi = -1; var ai = -1; var headerFound = false
                br.forEachLine { line ->
                    val cols = splitCsv(line)
                    if (!headerFound) {
                        val lower = cols.map { it.trim().lowercase() }
                        if (lower.any { it.contains("lat") } && lower.any { it.contains("lon") || it.contains("lng") }) {
                            ri = lower.indexOfFirst { it.contains("reference") || it == "summitcode" || it == "ref" || it.contains("code") }
                            ni = lower.indexOfFirst { it == "name" || it.contains("summitname") || it.contains("title") }
                            lai = lower.indexOfFirst { it.contains("lat") }
                            loi = lower.indexOfFirst { it.contains("lon") || it.contains("lng") }
                            ai  = lower.indexOfFirst { it == "active" }   // POTA: 1=active/0=inactive
                            headerFound = true
                        }
                        return@forEachLine
                    }
                    if (ri < 0 || lai < 0 || loi < 0) return@forEachLine
                    if (cols.size <= maxOf(ri, lai, loi)) return@forEachLine
                    // POTAの inactive(active=0)公園は除外(SOTA等 active列が無いCSVはそのまま)
                    if (ai in 0 until cols.size) {
                        val act = cols[ai].trim().lowercase()
                        if (act == "0" || act == "false" || act == "n") return@forEachLine
                    }
                    val la = cols[lai].trim().toDoubleOrNull() ?: return@forEachLine
                    val lo = cols[loi].trim().toDoubleOrNull() ?: return@forEachLine
                    if (kotlin.math.abs(la - lat) < 0.3 && kotlin.math.abs(lo - lon) < 0.35) {
                        val ref = cols[ri].trim()
                        val name = if (ni in 0 until cols.size) cols[ni].trim() else ""
                        if (ref.isNotEmpty()) out.add(GeoRef(ref, name, la, lo))
                    }
                }
            }
        } catch (_: Exception) {}
        return out.take(300)
    }

    /** 緯度経度→Maidenhead グリッドロケーター(6桁)。 */
    fun maidenhead(lat: Double, lon: Double): String {
        val lonv = (lon + 180.0).coerceIn(0.0, 359.9999)
        val latv = (lat + 90.0).coerceIn(0.0, 179.9999)
        val c1 = 'A' + (lonv / 20).toInt()
        val c2 = 'A' + (latv / 10).toInt()
        val d1 = ((lonv % 20) / 2).toInt()
        val d2 = (latv % 10).toInt()
        val e1 = 'A' + ((lonv % 2) / (2.0 / 24.0)).toInt()
        val e2 = 'A' + ((latv % 1) / (1.0 / 24.0)).toInt()
        return "%c%c%d%d%c%c".format(c1, c2, d1, d2, e1, e2)
    }

    @SuppressLint("MissingPermission")
    fun fetch(ctx: Context, onInfo: (String) -> Unit, onResult: (jcc: String, jgc: String, jccMemo: String, jgcMemo: String, info: String, gl: String) -> Unit) {
        val hasFine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val hasCoarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!hasFine && !hasCoarse) { onInfo(ctx.getString(R.string.geojcc_3)); return }
        onInfo(ctx.getString(R.string.geojcc_4))
        val fused = com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(ctx)
        val priority = if (hasFine) com.google.android.gms.location.Priority.PRIORITY_HIGH_ACCURACY
                       else com.google.android.gms.location.Priority.PRIORITY_BALANCED_POWER_ACCURACY
        val cts = com.google.android.gms.tasks.CancellationTokenSource()
        fused.getCurrentLocation(priority, cts.token)
            .addOnSuccessListener { loc ->
                if (loc == null) {
                    fused.lastLocation.addOnSuccessListener { last ->
                        if (last == null) { onInfo(ctx.getString(R.string.geojcc_5)); return@addOnSuccessListener }
                        reverseGeocode(ctx, last, onResult)
                    }
                    return@addOnSuccessListener
                }
                reverseGeocode(ctx, loc, onResult)
            }
            .addOnFailureListener { onInfo(ctx.getString(R.string.geojcc_6, it.localizedMessage)) }
    }

    /** 現在地の緯度経度を取得(地図センタリング用)。onLatLon は UI スレッドで呼ばれる。 */
    @SuppressLint("MissingPermission")
    fun fetchLocation(ctx: Context, onInfo: (String) -> Unit, onLatLon: (Double, Double) -> Unit) {
        val hasFine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val hasCoarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!hasFine && !hasCoarse) { onInfo(ctx.getString(R.string.geojcc_3)); return }
        val fused = com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(ctx)
        val priority = if (hasFine) com.google.android.gms.location.Priority.PRIORITY_HIGH_ACCURACY
                       else com.google.android.gms.location.Priority.PRIORITY_BALANCED_POWER_ACCURACY
        val cts = com.google.android.gms.tasks.CancellationTokenSource()
        fused.getCurrentLocation(priority, cts.token)
            .addOnSuccessListener { loc ->
                if (loc != null) { mainHandler.post { onLatLon(loc.latitude, loc.longitude) } }
                else fused.lastLocation.addOnSuccessListener { last ->
                    if (last != null) mainHandler.post { onLatLon(last.latitude, last.longitude) }
                    else onInfo(ctx.getString(R.string.geojcc_5))
                }
            }
            .addOnFailureListener { onInfo(ctx.getString(R.string.geojcc_6, it.localizedMessage)) }
    }

    private fun reverseGeocode(ctx: Context, loc: Location, onResult: (String, String, String, String, String, String) -> Unit) {
        if (!Geocoder.isPresent()) return
        Thread {
            try {
                @Suppress("DEPRECATION")
                val addrs = Geocoder(ctx, Locale.JAPANESE).getFromLocation(loc.latitude, loc.longitude, 1)
                if (addrs.isNullOrEmpty()) return@Thread
                val addr        = addrs[0]
                val admin       = addr.adminArea    ?: ""
                val subAdmin    = addr.subAdminArea ?: ""
                val locality    = addr.locality     ?: ""
                val subLocality = addr.subLocality  ?: ""
                val addressLine = addr.getAddressLine(0) ?: ""
                val fullLine    = addressLine.ifEmpty { "$admin$subAdmin$locality" }

                fun normCity(s: String) = if (s == "埼玉市") "さいたま市" else s
                val city = normCity(when {
                    subAdmin.endsWith("市") -> subAdmin
                    locality.endsWith("市") -> locality
                    subAdmin.contains("市") && subAdmin.endsWith("区") -> subAdmin.substring(0, subAdmin.indexOf('市') + 1)
                    else -> locality
                })
                val ward = when {
                    subLocality.endsWith("区") -> subLocality
                    locality.endsWith("区")    -> locality
                    subAdmin.endsWith("区")    -> subAdmin.substringAfterLast("市")
                    else -> {
                        val after = addressLine.substringAfter("市", "").trimStart()
                        Regex("^([^\\s\\d丁番号]+区)").find(after)?.groupValues?.getOrNull(1) ?: ""
                    }
                }
                val jcc = run {
                    var found = JccTable.lookupJcc(admin, locality)
                    if (found.isEmpty()) found = JccTable.lookupJcc(admin, city)
                    if (found.isEmpty() && ward.isNotEmpty()) found = JccTable.lookupJcc(admin, "$city$ward")
                    if (found.length == 6) {
                        val cityCode = JccTable.lookupJcc(admin, city)
                        if (cityCode.isNotEmpty()) found = cityCode
                    }
                    found
                }
                val jgc = run {
                    var found = ""
                    if (ward.isNotEmpty() && city.isNotEmpty()) found = JccTable.lookupJcc(admin, "$city$ward")
                    if (found.isEmpty() && subAdmin.isNotEmpty()) found = JccTable.lookupJgc(admin, subAdmin, locality)
                    found
                }
                // メモ用: 都道府県を頭に付ける。JCC=県+市、JGC=県+市+区(政令市)/県+郡+町村(郡部)
                val jccBase = if (city.isNotEmpty()) city else locality
                val jccMemo = if (jccBase.isNotEmpty()) "$admin$jccBase" else fullLine
                val jgcBase = when {
                    city.isNotEmpty() && ward.isNotEmpty() -> "$city$ward"               // 政令市: 市+区
                    subAdmin.endsWith("郡") && locality.isNotEmpty() -> "$subAdmin$locality" // 郡部: 郡+町/村
                    else -> locality
                }
                val jgcMemo = if (jgcBase.isNotEmpty()) "$admin$jgcBase" else fullLine
                val info = when {
                    jcc.isNotEmpty() && jgc.isNotEmpty() -> "$fullLine → JCC:$jcc JGC:$jgc"
                    jcc.isNotEmpty() -> "$fullLine → JCC:$jcc"
                    jgc.isNotEmpty() -> "$fullLine → JGC:$jgc"
                    else -> fullLine
                }
                val gl = maidenhead(loc.latitude, loc.longitude)
                mainHandler.post { onResult(jcc, jgc, jccMemo, jgcMemo, info, gl) }
            } catch (_: Exception) {}
        }.start()
    }
}
