package com.ji1ore.wifi_rig_ctrl

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.Dialog
import android.view.Window
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.ji1ore.wifi_rig_ctrl.ui.theme.ThemePalette
import com.ji1ore.wifi_rig_ctrl.ui.theme.UiTheme
import com.ji1ore.wifi_rig_ctrl.ui.theme.getThemePalette
import com.ji1ore.wifi_rig_ctrl.data.AprsHeardStation
import com.ji1ore.wifi_rig_ctrl.data.aprsSymbolByCode
import com.ji1ore.wifi_rig_ctrl.data.MemoryEntry
import com.ji1ore.wifi_rig_ctrl.data.MenuItem
import com.ji1ore.wifi_rig_ctrl.data.OpSession
import com.ji1ore.wifi_rig_ctrl.data.PRESET_MEMORIES
import com.ji1ore.wifi_rig_ctrl.data.SAMPLING_RATES
import com.ji1ore.wifi_rig_ctrl.data.SCREEN_TIMEOUT_OPTIONS
import com.ji1ore.wifi_rig_ctrl.data.STEP_LIST
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.ji1ore.wifi_rig_ctrl.databinding.FragmentMainControlBinding
import com.ji1ore.wifi_rig_ctrl.viewmodel.MainViewModel
import kotlin.math.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainControlFragment : Fragment() {

    private var _binding: FragmentMainControlBinding? = null
    private val binding get() = _binding!!
    private val vm: MainViewModel by activityViewModels()

    // 位置情報の実行時許可リクエスト(GPS/地図で使用)
    private var pendingLocationAction: (() -> Unit)? = null
    private val locationPermLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val granted = result[android.Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                      result[android.Manifest.permission.ACCESS_COARSE_LOCATION] == true
        val act = pendingLocationAction; pendingLocationAction = null
        if (granted) act?.invoke()
        else Toast.makeText(requireContext(), getString(R.string.main_control_1), Toast.LENGTH_SHORT).show()
    }
    private fun ensureLocationPermission(onGranted: () -> Unit) {
        val ctx = requireContext()
        val ok = androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED ||
                 androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (ok) onGranted()
        else {
            pendingLocationAction = onGranted
            locationPermLauncher.launch(arrayOf(
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.ACCESS_COARSE_LOCATION))
        }
    }
    private var currentThemeIdx: Int = 0
    private var currentDay: Boolean = false   // UI 昼/夜モード（ThemePalette の day 引数）
    private var screenTimeoutJob: Job? = null
    private var aprsToastDialog: Dialog? = null
    private var aprsToastDismissJob: Job? = null

    private var wasCwMode = false
    private var cwTxSheet: BottomSheetDialog? = null
    private var cwSheetStopBtn: android.widget.Button? = null
    private var cwSheetMsgButtons: List<android.widget.Button> = emptyList()
    private var cwPanelUpdateLabels: (() -> Unit)? = null
    private var cwRepeatUpdateFn: (() -> Unit)? = null
    private var cwSheetFreqView: android.widget.TextView? = null
    private var cwSheetShiftView: android.widget.TextView? = null
    private var cwSheetRxView: android.widget.TextView? = null
    private var cwSheetRxScroll: android.widget.HorizontalScrollView? = null
    private var cwSheetTxView: android.widget.TextView? = null
    private var cwSheetTxScroll: android.widget.HorizontalScrollView? = null
    private var cwSheetMorseView: android.widget.TextView? = null
    private var cwSheetMorseScroll: android.widget.HorizontalScrollView? = null
    private var cwSheetSmeter: android.widget.ProgressBar? = null
    private var cwSheetSmeterLabel: android.widget.TextView? = null
    private var cwSheetSpkBtn: android.widget.Button? = null
    private var cwSheetDxCall: android.widget.EditText? = null

    private val requestMicPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            vm.setPttEnabled(true)
        } else {
            Toast.makeText(requireContext(), "Microphone permission required", Toast.LENGTH_SHORT).show()
        }
    }

    // Import a CS-705-format D-STAR repeater CSV (from RepeaterBook web export or Icom). No API token needed.
    private val dstarCsvImportLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                val out = java.io.File(requireContext().filesDir, "dstar_repeaters.csv")
                requireContext().contentResolver.openInputStream(uri)?.use { raw ->
                    val bis = java.io.BufferedInputStream(raw)
                    bis.mark(4)
                    val sig = ByteArray(4); val got = bis.read(sig); bis.reset()
                    val isZip = got >= 2 && sig[0].toInt() == 0x50 && sig[1].toInt() == 0x4B   // "PK"
                    if (isZip) {
                        // Icom repeater download is a ZIP (…_Rpt_*.csv + .icf) — extract the first .csv.
                        java.util.zip.ZipInputStream(bis).use { zis ->
                            var e = zis.nextEntry; var found = false
                            while (e != null) {
                                if (!e.isDirectory && e.name.lowercase().endsWith(".csv")) {
                                    out.outputStream().use { zis.copyTo(it) }; found = true; break
                                }
                                e = zis.nextEntry
                            }
                            if (!found) throw Exception(getString(R.string.main_control_zip_no_csv))
                        }
                    } else {
                        out.outputStream().use { bis.copyTo(it) }
                    }
                }
                Toast.makeText(requireContext(), getString(R.string.main_control_2, out.length()), Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(requireContext(), getString(R.string.main_control_3, e.message), Toast.LENGTH_LONG).show()
            }
        }
    }

    private var sstvPendingMode = "Robot36"
    // SSTV: 画像を選択 → 縮小 → JPEG → base64 → Pi へ送信。
    private val sstvImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            val src = requireContext().contentResolver.openInputStream(uri)?.use {
                android.graphics.BitmapFactory.decodeStream(it)
            } ?: throw Exception("画像を読めません")
            // 長辺640pxに縮小(アップロード軽量化。実解像度はPi側で各モードに合わせる)。
            val maxSide = 640
            val scale = minOf(1f, maxSide.toFloat() / maxOf(src.width, src.height))
            val bmp = if (scale < 1f)
                android.graphics.Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true)
            else src
            val bos = java.io.ByteArrayOutputStream()
            bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, bos)
            val b64 = android.util.Base64.encodeToString(bos.toByteArray(), android.util.Base64.NO_WRAP)
            vm.sendSstvImage(b64, sstvPendingMode)
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "SSTV画像エラー: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentMainControlBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        currentThemeIdx = vm.prefs.colorTheme
        currentDay = vm.prefs.dayMode
        setupSMeter()
        setupTxMeters()
        setupObservers()
        setupButtons()
        applyColorTheme(currentThemeIdx)
        setupVolumeSlider()
        setupMicGainSlider()

        vm.fetchModeList()
        vm.startStatusPolling()
        updateCwUsbStatus()
        updateCwBtStatus()
        updateCwTxButton()
        binding.tvCwUsbPort.text = vm.prefs.cwPort

        parentFragmentManager.setFragmentResultListener("memory_ft8", viewLifecycleOwner) { _, bundle ->
            vm.prefs.ft8IsFt4 = bundle.getBoolean("isFt4", vm.prefs.ft8IsFt4)
            findNavController().navigate(R.id.action_MainControlFragment_to_Ft8Fragment)
        }
        // MEMSET のスポット(POTA/SOTA)選択で相手局コールを受け取り、CWTXシートのDXコール欄へ反映
        parentFragmentManager.setFragmentResultListener("memory_dxcall", viewLifecycleOwner) { _, b ->
            val call = b.getString("call", "").trim().uppercase()
            if (call.isNotEmpty()) {
                cwSheetDxCall?.setText(call)
                vm.prefs.cwDxCall = call
            }
        }

        vm.navigateToFt8.observe(viewLifecycleOwner) { isFt4 ->
            if (isFt4 == null) return@observe
            vm.navigateToFt8.value = null
            vm.prefs.ft8IsFt4 = isFt4
            if (findNavController().currentDestination?.id == R.id.MainControlFragment) {
                findNavController().navigate(R.id.action_MainControlFragment_to_Ft8Fragment)
            }
        }
    }

    private fun setupSMeter() {
        binding.llSmeter.removeAllViews()
        binding.llSmeterLabels.removeAllViews()
        val dp = resources.displayMetrics.density

        // 30 bars: 2バー = 1 Sユニット
        repeat(30) {
            val v = View(requireContext())
            val lp = LinearLayout.LayoutParams(0, (22 * dp).toInt(), 1f)
            lp.marginEnd = (2 * dp).toInt()
            v.layoutParams = lp
            binding.llSmeter.addView(v)
        }

        // Scale labels: S1=bar2, S3=bar6, S5=bar10, S7=bar14, S9=bar18, +10=bar21, +20=bar24, +30=bar28
        val labels = mapOf(2 to "1", 6 to "3", 10 to "5", 14 to "7", 18 to "9",
                           21 to "+10", 24 to "+20", 28 to "+30")
        val labelColors = mapOf(
            2  to 0xFF3A7A4A.toInt(),
            6  to 0xFF3A7A4A.toInt(),
            10 to 0xFF3A7A4A.toInt(),
            14 to 0xFF3A7A4A.toInt(),
            18 to 0xFF00C853.toInt(),
            21 to 0xFFBDA000.toInt(),
            24 to 0xFFFDD835.toInt(),
            28 to 0xFFFF6D00.toInt()
        )
        // テキストが隣のスペーサー・カード境界へはみ出せるようにクリップを解除
        binding.llSmeterLabels.clipChildren = false
        binding.llSmeterLabels.clipToPadding = false
        // 親カード (paddingEnd=4dp) と祖父母 View までクリップ解除
        var p = binding.llSmeterLabels.parent
        repeat(3) {
            (p as? android.view.ViewGroup)?.let { vg ->
                vg.clipChildren = false
                vg.clipToPadding = false
                p = vg.parent
            }
        }
        repeat(30) { i ->
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.marginEnd = (2 * dp).toInt()  // バーと同じmarginで位置を揃える
            val text = labels[i]
            if (text != null) {
                val tv = android.widget.TextView(requireContext())
                tv.layoutParams = lp
                tv.text = text
                // +dBラベル(3文字)は6spで枠内に収める、S単位(1文字)は8sp
                tv.textSize = if (text.length > 2) 6f else 8f
                tv.gravity = android.view.Gravity.CENTER
                tv.maxLines = 1
                tv.isSingleLine = true
                tv.setTextColor(labelColors[i] ?: 0xFF3A7A4A.toInt())
                binding.llSmeterLabels.addView(tv)
            } else {
                val v = View(requireContext())
                v.layoutParams = lp
                binding.llSmeterLabels.addView(v)
            }
        }
    }

    private fun setupTxMeters() {
        val dp = resources.displayMetrics.density
        val barHeight = (14 * dp).toInt()
        val margin = (2 * dp).toInt()
        listOf(binding.llPoMeter, binding.llAlcMeter).filterNotNull().forEach { ll ->
            ll.removeAllViews()
            repeat(30) {
                val v = View(requireContext())
                val lp = LinearLayout.LayoutParams(0, barHeight, 1f)
                lp.marginEnd = margin
                v.layoutParams = lp
                ll.addView(v)
            }
        }
    }

    private fun updateTxMeter(ll: LinearLayout, value: Float, activeColor: Int, darkColor: Int) {
        val bars = ll.childCount
        val threshold = (value * bars).toInt()
        for (i in 0 until bars) {
            ll.getChildAt(i).setBackgroundColor(if (i < threshold) activeColor else darkColor)
        }
    }

    private fun updatePoMeter(value: Float) {
        val ll = binding.llPoMeter ?: return
        val color = when {
            value < 0.6f -> 0xFFFF6D00.toInt()
            value < 0.85f -> 0xFFFDD835.toInt()
            else -> 0xFFD50000.toInt()
        }
        updateTxMeter(ll, value, color, 0xFF1A0800.toInt())
    }

    private fun updateAlcMeter(value: Float) {
        val ll = binding.llAlcMeter ?: return
        updateTxMeter(ll, value, 0xFFD50000.toInt(), 0xFF1A0000.toInt())
    }

    private fun updateTxMeterVisibility(tx: Boolean) {
        val mode = vm.sharedMode.value ?: ""
        val isFtMode = mode.startsWith("FT", ignoreCase = true)
        val vis = if (tx && isFtMode) View.VISIBLE else View.GONE
        binding.llPoMeterRow?.visibility = vis
        binding.llAlcMeterRow?.visibility = vis
        if (vis == View.GONE) {
            binding.llPoMeter?.let { updateTxMeter(it, 0f, 0, 0xFF1A0800.toInt()) }
            binding.llAlcMeter?.let { updateTxMeter(it, 0f, 0, 0xFF1A0000.toInt()) }
        }
    }

    private fun updateModelDisplay() {
        val lost = vm.linkLost.value == true
        val rigLost = vm.rigLinkLost.value == true && vm.useCIV.value != true
        val name = vm.sharedModel.value ?: ""
        val base = when {
            lost && name.isNotEmpty() -> "$name  ⚠ DISCONNECTED"
            lost -> "⚠ DISCONNECTED"
            rigLost && name.isNotEmpty() -> "$name  ⚠ RIG DISCONNECTED"
            rigLost -> "⚠ RIG DISCONNECTED"
            vm.piVersionMismatch.value == true && name.isNotEmpty() -> "$name ⚠UPDATE"
            else -> name
        }
        val prefix = when {
            vm.useCIV.value == true && vm.civConnectionType.value == "BT" -> "[CI-V BT] "
            vm.useCIV.value == true -> "[CI-V] "
            else -> "[WiFi] "
        }
        binding.tvModel.text = "$prefix$base"
        binding.tvModel.setTextColor(if (lost) 0xFFFF6600.toInt() else 0xFF888888.toInt())
        val t = pal
        binding.tvFreq.setTextColor(if (lost) 0xFF444444.toInt() else t.freqText)
        binding.llFreqPanel.setBackgroundColor(if (lost) 0xFF1A0800.toInt() else t.freqPanelBg)
    }

    private fun refreshCwSheetSpk() {
        val btn = cwSheetSpkBtn ?: return
        val on = vm.spkEnabled.value == true
        btn.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (on) 0xFFAEEA00.toInt() else 0xFF1B5E20.toInt())
        btn.setTextColor(if (on) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
    }

    // CW TX シートSメーターのスケールラベルをProgressBar(0..30)に合わせて生成。
    // 2バー=1Sユニット。S1=2,S3=6,S5=10,S7=14,S9=18, +10=21,+20=24,+30=28。
    private fun populateCwSmeterTicks(container: android.widget.LinearLayout) {
        container.removeAllViews()
        val labels = mapOf(2 to "1", 6 to "3", 10 to "5", 14 to "7", 18 to "9",
                           21 to "+10", 24 to "+20", 28 to "+30")
        val colors = mapOf(2 to 0xFF3A7A4A.toInt(), 6 to 0xFF3A7A4A.toInt(), 10 to 0xFF3A7A4A.toInt(),
                           14 to 0xFF3A7A4A.toInt(), 18 to 0xFF00C853.toInt(), 21 to 0xFFBDA000.toInt(),
                           24 to 0xFFFDD835.toInt(), 28 to 0xFFFF6D00.toInt())
        for (i in 0 until 30) {
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            val t = labels[i]
            if (t != null) {
                container.addView(android.widget.TextView(requireContext()).apply {
                    layoutParams = lp; text = t; textSize = if (t.length > 2) 6f else 8f
                    gravity = android.view.Gravity.CENTER; isSingleLine = true
                    setTextColor(colors[i] ?: 0xFF3A7A4A.toInt())
                })
            } else {
                container.addView(View(requireContext()).apply { layoutParams = lp })
            }
        }
    }

    private fun updateSMeter(signal: Float) {
        val bars = binding.llSmeter.childCount
        val threshold = (signal * 2f).toInt()
        for (i in 0 until bars) {
            val v = binding.llSmeter.getChildAt(i)
            val color = if (i < threshold) {
                when {
                    i <= 17 -> 0xFF00C853.toInt()  // Green  S1-S9
                    i <= 23 -> 0xFFFDD835.toInt()  // Yellow S9+
                    i <= 27 -> 0xFFFF6D00.toInt()  // Orange S9+18dB
                    else    -> 0xFFD50000.toInt()  // Red    S9+30dB+
                }
            } else {
                when {
                    i <= 17 -> 0xFF0A2A14.toInt()  // 暗緑
                    i <= 23 -> 0xFF2A2800.toInt()  // 暗黄
                    i <= 27 -> 0xFF2A1400.toInt()  // 暗橙
                    else    -> 0xFF2A0000.toInt()  // 暗赤
                }
            }
            v.setBackgroundColor(color)
        }
        // CW TX シートの簡易Sメーター(表示中のみ)
        cwSheetSmeter?.let { pb ->
            pb.progress = (signal * 2f).toInt().coerceIn(0, pb.max)
            val tint = when {
                signal >= 13.5f -> 0xFFD50000.toInt()
                signal >= 12f   -> 0xFFFF6D00.toInt()
                signal >= 9f    -> 0xFFFDD835.toInt()
                else            -> 0xFF00C853.toInt()
            }
            pb.progressTintList = android.content.res.ColorStateList.valueOf(tint)
            cwSheetSmeterLabel?.text = when {
                signal < 9f  -> "S${signal.toInt().coerceAtLeast(0)}"
                signal < 12f -> "S9"
                signal < 14f -> "S9+20"
                else         -> "S9+40"
            }
        }
    }

    private fun formatShiftHz(hz: Long): String = when {
        hz == 0L -> "0"
        kotlin.math.abs(hz) < 1000L -> "${if (hz > 0) "+" else ""}${hz}Hz"
        else -> "${if (hz > 0) "+" else ""}${"%.1f".format(hz / 1000.0)}kHz"
    }

    private fun showCwShiftStepDialog() {
        val steps = intArrayOf(10, 50, 100, 500, 1000)
        val labels = steps.map { if (it < 1000) "${it}Hz" else "${it / 1000}kHz" }.toTypedArray()
        val current = vm.prefs.cwShiftStep
        val checked = steps.indexOfFirst { it == current }.coerceAtLeast(0)
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("TX OFS Step")
            .setSingleChoiceItems(labels, checked) { d, which ->
                vm.prefs.cwShiftStep = steps[which]
                d.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun updateFreqDisplay() {
        val freq   = vm.sharedFreq.value ?: 0L
        val tx     = vm.txEnabled.value == true
        val dir    = vm.repeaterOffsetDir.value ?: ""
        val offset = vm.repeaterOffsetHz.value ?: 0L
        val isCiv  = vm.useCIV.value == true
        val cwShift = if (isCiv) 0L else vm.cwTxShiftHz.value ?: 0L
        val displayFreq = when {
            tx && dir.isNotEmpty() && offset > 0L -> if (dir == "-") freq - offset else freq + offset
            tx && cwShift != 0L -> freq + cwShift
            else -> freq
        }
        val mhz = displayFreq / 1_000_000.0
        binding.tvFreq.text = "%.5f".format(mhz)
        cwSheetFreqView?.text = "%.5f".format(freq / 1_000_000.0)
        cwSheetShiftView?.let { tv ->
            if (!isCiv && cwShift != 0L) {
                tv.text = "TX OFS: ${formatShiftHz(cwShift)}"
                tv.visibility = View.VISIBLE
            } else {
                tv.visibility = View.GONE
            }
        }
    }

    private fun setupObservers() {
        vm.sharedFreq.observe(viewLifecycleOwner) { updateFreqDisplay(); updateInfoRow(); updateDstarInfo() }
        vm.cwTxShiftHz.observe(viewLifecycleOwner) { updateFreqDisplay() }
        vm.useCIV.observe(viewLifecycleOwner) { updateFreqDisplay(); updateCwTxButton() }
        vm.sharedMode.observe(viewLifecycleOwner) { updateInfoRow(); updateButtonHighlights(); updateTxMeterVisibility(vm.sharedTx.value == true); updateDstarInfo() }
        vm.sharedPower.observe(viewLifecycleOwner) { updateInfoRow() }
        vm.sharedSQL.observe(viewLifecycleOwner) { updateInfoRow() }
        vm.sharedBkIn.observe(viewLifecycleOwner) { updateInfoRow(); updateButtonHighlights() }
        vm.sharedTuner.observe(viewLifecycleOwner) { updateInfoRow() }
        vm.opSessions.observe(viewLifecycleOwner) { refreshOpLocActive() }
        vm.repeaterOffsetDir.observe(viewLifecycleOwner) { updateInfoRow(); updateFreqDisplay() }
        vm.repeaterToneMode.observe(viewLifecycleOwner) { updateInfoRow() }
        vm.sharedWidth.observe(viewLifecycleOwner) { updateInfoRow() }
        vm.sharedSignal.observe(viewLifecycleOwner) { updateSMeter(it) }
        vm.sharedRfOut.observe(viewLifecycleOwner) { updatePoMeter(it) }
        vm.sharedAlc.observe(viewLifecycleOwner) { updateAlcMeter(it) }
        vm.sharedTx.observe(viewLifecycleOwner) { updateTxMeterVisibility(it) }
        vm.useCIV.observe(viewLifecycleOwner) { updateTxMeterVisibility(vm.sharedTx.value == true); updateCwTxButton() }
        vm.sharedModel.observe(viewLifecycleOwner) { updateModelDisplay() }
        vm.piVersionMismatch.observe(viewLifecycleOwner) { updateModelDisplay() }
        vm.linkLost.observe(viewLifecycleOwner) { updateModelDisplay() }
        vm.rigLinkLost.observe(viewLifecycleOwner) { updateModelDisplay() }
        vm.selectedStep.observe(viewLifecycleOwner) { updateInfoRow() }
        vm.selectedMenuItem.observe(viewLifecycleOwner) { updateButtonHighlights() }
        vm.aprsEnabled.observe(viewLifecycleOwner) { updateButtonHighlights() }
        vm.aprsActive.observe(viewLifecycleOwner) { updateButtonHighlights() }
        vm.aprsUseRigModem.observe(viewLifecycleOwner) { updateButtonHighlights() }
        vm.aprsAtPreset2.observe(viewLifecycleOwner) { updateButtonHighlights() }
        vm.spkEnabled.observe(viewLifecycleOwner) { updateButtonHighlights(); refreshCwSheetSpk() }
        vm.btHybridAudioReady.observe(viewLifecycleOwner) { updateButtonHighlights() }
        vm.txEnabled.observe(viewLifecycleOwner) { _ ->
            updateButtonHighlights()
            updateTxIndicator()
            updateFreqDisplay()
        }
        vm.aprsTxInProgress.observe(viewLifecycleOwner) { _ ->
            updateTxIndicator()
        }
        vm.cwKeyOn.observe(viewLifecycleOwner) { _ ->
            updateTxIndicator()
        }
        vm.audioError.observe(viewLifecycleOwner) { msg ->
            if (msg != null) {
                Toast.makeText(requireContext(), msg, Toast.LENGTH_LONG).show()
                vm.audioError.value = null
                // On error, turn SPK back OFF
                vm.spkEnabled.value = false
            }
        }
        vm.errorMessage.observe(viewLifecycleOwner) { msg ->
            if (msg != null) {
                Toast.makeText(requireContext(), msg, Toast.LENGTH_LONG).show()
                vm.errorMessage.value = null
            }
        }

        vm.cwUsbConnected.observe(viewLifecycleOwner) { updateCwUsbStatus() }
        vm.cwUsbEnabled.observe(viewLifecycleOwner) { updateCwUsbStatus() }
        vm.cwServerConnected.observe(viewLifecycleOwner) { updateCwUsbStatus() }
        vm.cwServerSynced.observe(viewLifecycleOwner) { updateCwUsbStatus() }
        vm.cwSidetoneEnabled.observe(viewLifecycleOwner) { updateCwUsbStatus() }
        vm.sharedMode.observe(viewLifecycleOwner) {
            vm.cwUsb.currentMode = it ?: ""
            updateCwUsbStatus()
        }

        vm.cwBleConnected.observe(viewLifecycleOwner) { updateCwBtStatus(); updateCwUsbStatus() }
        vm.cwBleEnabled.observe(viewLifecycleOwner) { updateCwBtStatus(); updateCwUsbStatus() }
        vm.cwBleAudioReady.observe(viewLifecycleOwner) { updateCwBtStatus() }

        vm.dstarStatus.observe(viewLifecycleOwner) { msg ->
            if (!msg.isNullOrEmpty()) Toast.makeText(requireContext(), msg, Toast.LENGTH_LONG).show()
        }
        vm.sstvStatus.observe(viewLifecycleOwner) { msg ->
            if (!msg.isNullOrEmpty()) Toast.makeText(requireContext(), msg, Toast.LENGTH_LONG).show()
        }
        vm.dstarRouting.observe(viewLifecycleOwner) { updateDstarInfo() }
        vm.dstarRxCall.observe(viewLifecycleOwner) { updateDstarInfo() }
        vm.dstarRxMessage.observe(viewLifecycleOwner) { updateDstarInfo() }
        vm.cwDecoding.observe(viewLifecycleOwner) { decoding ->
            binding.llCwDecoder.visibility = if (decoding) View.VISIBLE else View.GONE
            binding.llCwNoiseRow?.visibility = View.GONE   // manual NL hidden; CW RX detect stays automatic (Otsu)
            updateButtonHighlights()
            val vis = if (decoding) View.VISIBLE else View.GONE
            cwSheetRxScroll?.visibility = vis
            // CW TX panel: keep the TX (sent-CW decode) row visible whenever the panel is open, so it's
            // shown on the CW TX screen too (not only while RX decode is active).
            cwSheetTxScroll?.visibility = View.VISIBLE
        }
        // Manual NL slider removed: AUTO (Otsu) adapts to band conditions and copies better in practice;
        // a manual squelch mostly gated out weak-but-audible signals. Force automatic CW RX detection.
        vm.setCwNoiseLevel(-1f)
        vm.cwTxText.observe(viewLifecycleOwner) { text ->
            // Main-screen CW decode panel: TX (sent-CW decode) row restored. The CW TX bottom sheet also echoes it.
            // Always show the TX (sent-CW decode) field while the CW decode panel is up, so the field is
            // visible even before you send (it was hidden-when-empty before, which read as "no TX field").
            binding.tvCwTx?.text = text ?: ""
            binding.tvCwTxLabel?.visibility = View.VISIBLE
            binding.hsvCwTx?.visibility = View.VISIBLE
            if (!text.isNullOrEmpty()) binding.hsvCwTx?.post { binding.hsvCwTx?.fullScroll(HorizontalScrollView.FOCUS_RIGHT) }
            cwSheetTxView?.text = if (text.isNullOrEmpty()) "TX:" else "TX: $text"
            if (!text.isNullOrEmpty()) cwSheetTxScroll?.post { cwSheetTxScroll?.fullScroll(android.view.View.FOCUS_RIGHT) }
        }
        val cwRxTextViews = listOf(binding.tvCwRx0, binding.tvCwRx1, binding.tvCwRx2, binding.tvCwRx3, binding.tvCwRx4)
        val cwRxScrollViews = listOf(binding.hsvCwRx0, binding.hsvCwRx1, binding.hsvCwRx2, binding.hsvCwRx3, binding.hsvCwRx4)
        val cwFreqTextViews = listOf(binding.tvCwFreq0, binding.tvCwFreq1, binding.tvCwFreq2, binding.tvCwFreq3, binding.tvCwFreq4)
        // ch0 shows the DSP decode (the sole CW decoder).
        fun renderCh0() {
            cwRxTextViews[0].text = vm.cwRxTexts[0].value ?: ""
            cwRxScrollViews[0].post { cwRxScrollViews[0].fullScroll(HorizontalScrollView.FOCUS_RIGHT) }
        }
        for (i in cwRxTextViews.indices) {
            val hsv = cwRxScrollViews[i]
            vm.cwRxTexts[i].observe(viewLifecycleOwner) { text ->
                if (i == 0) { renderCh0(); refreshCwSheetMorse() }
                else { cwRxTextViews[i].text = text; hsv.post { hsv.fullScroll(HorizontalScrollView.FOCUS_RIGHT) } }
            }
            vm.cwRxFreqLabels[i].observe(viewLifecycleOwner) { label ->
                cwFreqTextViews[i].text = label
            }
        }
        // Tap the RX (ch0) frequency to toggle CW-decode NR (narrow bandpass) live. Default OFF. ON swaps the
        // wide RX bandpass for a CW-pitch narrow BPF on the Pi — better copy on noisy HF with NO audio dropouts
        // (afftdn is never used while decoding). Off = wider/natural audio. Toast shows the state.
        cwFreqTextViews[0].setOnClickListener {
            val nr = vm.toggleCwDecodeNr()
            Toast.makeText(requireContext(),
                if (nr) getString(R.string.main_control_4) else getString(R.string.main_control_5),
                Toast.LENGTH_SHORT).show()
        }
        vm.cwMultiRx.observe(viewLifecycleOwner) { multi ->
            val vis = if (multi) View.VISIBLE else View.GONE
            for (i in 1 until cwRxScrollViews.size) {
                cwRxScrollViews[i].visibility = vis
                cwFreqTextViews[i].visibility = vis
            }
        }
        vm.cwShowMorse.observe(viewLifecycleOwner) { on ->
            // Keep the accumulated phrase line (tvCwRx0) always visible; just show/hide the
            // dit/dah+char block below it. Both appear by default (no long-press needed).
            binding.hsvCwMorse0?.visibility = if (on) View.VISIBLE else View.GONE
            refreshCwSheetMorse()
        }
        vm.cwRxMorse.observe(viewLifecycleOwner) { m ->
            binding.tvCwMorse0?.text = m
            if (m.isNotEmpty()) binding.hsvCwMorse0?.post {
                binding.hsvCwMorse0?.fullScroll(android.view.View.FOCUS_RIGHT)
            }
            refreshCwSheetMorse()
        }
        vm.noiseReductionLevel.observe(viewLifecycleOwner) { updateButtonHighlights() }
        vm.cwTxBusy.observe(viewLifecycleOwner) { updateCwUsbStatus(); updateCwTxButton(); updateCwTxSheetState() }
        vm.cwCqRepeating.observe(viewLifecycleOwner) { cwRepeatUpdateFn?.invoke() }
        vm.cwCqRepeatStatus.observe(viewLifecycleOwner) { cwRepeatUpdateFn?.invoke() }
        vm.sharedMode.observe(viewLifecycleOwner) { updateCwTxButton() }
        vm.cwTxShiftHz.observe(viewLifecycleOwner) { shiftHz ->
            binding.tvCwShiftHz?.text = formatShiftHz(shiftHz)
        }
        vm.vfoMode.observe(viewLifecycleOwner) { updateInfoRow(); updateButtonHighlights() }
        vm.vfoCurrentSide.observe(viewLifecycleOwner) { updateInfoRow(); updateButtonHighlights() }
        vm.aprsToastStation.observe(viewLifecycleOwner) { station ->
            if (station != null) showAprsToast(station)
        }
        vm.isConnectedToRig.observe(viewLifecycleOwner) { connected ->
            if (connected) vm.startAprsReceivedPolling()
            else vm.stopAprsReceivedPolling()
        }
    }

    private fun updateCwUsbStatus() {
        val connected = vm.cwUsbConnected.value ?: false
        val enabled = vm.cwUsbEnabled.value ?: false
        val mode = vm.sharedMode.value ?: ""
        val isCwMode = mode.contains("CW", ignoreCase = true)
        val svrConnected = vm.cwServerConnected.value ?: false
        val svrSynced = vm.cwServerSynced.value ?: false
        val cwTxBusy = vm.cwTxBusy.value ?: false
        val sidetone = vm.cwSidetoneEnabled.value ?: true
        val sidetoneTag = if (!sidetone && enabled) " [Muted]" else ""

        // USB label: green when connected, gray when not
        val usbLabelColor = if (connected) 0xFF76FF03.toInt() else 0xFF444444.toInt()
        binding.tvCwUsbLabel?.setTextColor(usbLabelColor)

        val (statusText, statusColor) = when {
            cwTxBusy   -> Pair("CW Sending... (tap to stop)", 0xFFFF6600.toInt())
            !connected -> Pair("Not connected",               0xFF555555.toInt())
            !enabled   -> Pair("Idle",                        0xFFFFEB3B.toInt())
            isCwMode   -> Pair("CW relay$sidetoneTag",        0xFF76FF03.toInt())
            else       -> Pair("Audio relay$sidetoneTag",     0xFF40C4FF.toInt())
        }
        binding.tvCwUsbStatus.text = statusText
        binding.tvCwUsbStatus.setTextColor(statusColor)

        val bleEnabled = vm.cwBleEnabled.value ?: false
        val anyEnabled = enabled || bleEnabled
        val (svrText, svrColor) = when {
            !anyEnabled -> Pair("Svr:--",      0xFF555555.toInt())
            svrSynced   -> Pair("Svr:Synced",  0xFF76FF03.toInt())
            svrConnected-> Pair("Svr:Online",  0xFFFFEB3B.toInt())
            else        -> Pair("Svr:Offline", 0xFFFF5252.toInt())
        }
        binding.tvCwServerStatus?.text = svrText
        binding.tvCwServerStatus?.setTextColor(svrColor)
    }

    private fun updateCwBtStatus() {
        val bleConnected = vm.cwBleConnected.value ?: false
        val audioReady   = vm.cwBleAudioReady.value ?: false
        val (text, color) = when {
            bleConnected && audioReady  -> Pair("BLE", 0xFF76FF03.toInt())  // 緑: 音声準備完了
            bleConnected && !audioReady -> Pair("BLE", 0xFFFFEB3B.toInt())  // 黄: GATT接続中/音声未準備
            else                        -> Pair("BLE", 0xFF444444.toInt())  // 灰: 未接続
        }
        binding.tvCwBtStatus.text = text
        binding.tvCwBtStatus.setTextColor(color)
    }

    /** D-STARモード時、DEC欄の位置に現在のUR/R1/R2(設定ルーティング)と受信コール(ブリッジ接続時)を表示。 */
    private fun updateDstarInfo() {
        val b = _binding ?: return
        val panel = b.llDstarInfo ?: return
        val mode = (vm.sharedMode.value ?: "").uppercase()
        val isDstar = mode.contains("DSTAR") || mode.contains("D-STAR") || mode == "DV"
        if (!isDstar) { panel.visibility = View.GONE; return }
        panel.visibility = View.VISIBLE
        // シンプレックス選択中は R1/R2 を出さない(前回DRの保存値が表示に残らないように)。
        // また DRでも現在周波数がDRレピータ周波数から外れている(手動QSY等)なら R1/R2 は無効なので出さない。
        val forceSimplex = vm.prefs.dstarSubMode == "SIMPLEX"
        val repFreq = vm.prefs.dstarFreqHz
        val curFreq = vm.sharedFreq.value ?: 0L
        val offRepeater = !forceSimplex && repFreq > 0L && curFreq > 0L &&
            kotlin.math.abs(curFreq - repFreq) > 100_000L   // 100kHz超のずれ=レピータ外
        val hideRouting = forceSimplex || offRepeater
        val r = vm.dstarRouting.value
        val ur = if (forceSimplex) (r?.first ?: "CQCQCQ") else (r?.first ?: vm.prefs.dstarUr)
        val r1 = if (hideRouting) "" else (r?.second ?: vm.prefs.dstarR1)
        val r2 = if (hideRouting) "" else (r?.third ?: vm.prefs.dstarR2)
        val isSimplex = r1.isBlank() && r2.isBlank() && (ur.isBlank() || ur.uppercase().startsWith("CQCQCQ"))
        val name = vm.prefs.dstarR1Name
        val urName = vm.prefs.dstarUrName
        // 繋ぎ先(ゾーンコール UR="/...")なら「アクセス局→繋ぎ先」を日本語で表示。
        val head = when {
            ur.startsWith("/") && urName.isNotEmpty() -> (name.ifEmpty { getString(R.string.main_control_6) }) + "→" + urName + "  "
            name.isNotEmpty() -> "$name  "
            else -> ""
        }
        b.tvDstarRoute?.text = if (isSimplex) {
            getString(R.string.main_control_7, ur.ifBlank { "CQCQCQ" }) + (if (vm.dstarBridgeActive) "  [BR]" else "")
        } else {
            "D★ " + head + "UR:${ur.ifBlank { "-" }}" +
                (if (r1.isNotBlank()) " R1:$r1" else "") + (if (r2.isNotBlank()) " R2:$r2" else "") +
                (if (vm.dstarBridgeActive) "  [BR]" else "")
        }
        val rx = vm.dstarRxCall.value
        val msg = vm.dstarRxMessage.value ?: ""
        val rxLine = if (rx != null && (rx.first.isNotEmpty() || rx.second.isNotEmpty()))
            "RX: ${rx.first}" + (if (rx.second.isNotEmpty()) " ← ${rx.second}" else "") else ""
        // メッセージは末尾で切れないよう2行目に出す(コール行が無ければ単独表示)。
        val msgLine = if (msg.isNotEmpty()) "「$msg」" else ""
        b.tvDstarRx?.text = when {
            rxLine.isNotEmpty() && msgLine.isNotEmpty() -> "$rxLine\n$msgLine"
            else -> rxLine + msgLine
        }.trim()
    }

    /** D★表示タップで開く送信メッセージ変更ダイアログ。入力→設定でCI-V 1F 02書込(空=消去)。 */
    /** SSTV受信画像ギャラリー: Piから一覧取得→各PNGを読み込んで縦に表示。 */
    private fun showSstvGallery() {
        val ctx = context ?: return
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 16, 32, 8) }
        val scroll = android.widget.ScrollView(ctx).apply { addView(box) }
        val loading = TextView(ctx).apply { text = "読み込み中…"; setTextColor(0xFFCCCCCC.toInt()) }
        box.addView(loading)
        AlertDialog.Builder(ctx).setTitle("SSTV 受信画像").setView(scroll)
            .setPositiveButton("閉じる", null).show()
        viewLifecycleOwner.lifecycleScope.launch {
            val names = vm.sstvFetchList()
            box.removeAllViews()
            if (names.isEmpty()) {
                box.addView(TextView(ctx).apply { text = "受信画像はありません"; setTextColor(0xFF888888.toInt()) })
                return@launch
            }
            for (name in names) {
                box.addView(TextView(ctx).apply { text = name; setTextColor(0xFF00E5FF.toInt()); setPadding(0, 10, 0, 2) })
                val iv = android.widget.ImageView(ctx).apply {
                    adjustViewBounds = true; setPadding(0, 2, 0, 12)
                }
                box.addView(iv)
                launch {
                    val bytes = vm.sstvFetchImage(name)
                    if (bytes != null) {
                        val bmp = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        if (bmp != null) iv.setImageBitmap(bmp)
                    }
                }
            }
        }
    }

    private fun showDstarTxMessageQuick() {
        val ctx = context ?: return
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 8) }
        val e = EditText(ctx).apply {
            setText(vm.prefs.dstarTxMessage)
            hint = getString(R.string.main_control_82)
            filters = arrayOf(android.text.InputFilter.LengthFilter(20))
            setSelection(text.length)
        }
        root.addView(e)
        // 履歴(受信/送信)。TX行はタップで入力欄へ再投入。
        root.addView(TextView(ctx).apply {
            text = "受信履歴"; setTextColor(0xFF00FFFF.toInt()); setPadding(0, 24, 0, 4)
        })
        val listBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        root.addView(android.widget.ScrollView(ctx).apply {
            addView(listBox)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 560)
        })
        val hist = vm.dstarMsgHistory.value ?: emptyList()
        if (hist.isEmpty()) {
            listBox.addView(TextView(ctx).apply { text = "履歴なし"; setTextColor(0xFF888888.toInt()) })
        } else {
            val fmt = java.text.SimpleDateFormat("MM/dd HH:mm", java.util.Locale.getDefault())
            hist.filter { it.isRx }.forEach { en ->   // 受信のみ表示(送信は履歴に出さない)
                val sub = (if (en.callsign.isNotEmpty()) en.callsign + "  " else "") + fmt.format(java.util.Date(en.timeMs))
                listBox.addView(TextView(ctx).apply {
                    text = "${en.text}\n    $sub"
                    setTextColor(0xFF80FF80.toInt())
                    setPadding(0, 8, 0, 8)
                })
            }
        }
        AlertDialog.Builder(ctx)
            .setTitle(getString(R.string.main_control_82))
            .setView(root)
            .setPositiveButton(getString(R.string.main_control_84)) { _, _ ->
                vm.setDstarTxMessage(e.text.toString())
            }
            .setNegativeButton(getString(R.string.main_control_11), null)
            .show()
    }

    private fun updateInfoRow() {
        val step = STEP_LIST.getOrElse(vm.selectedStep.value ?: 0) { STEP_LIST[0] }
        binding.tvStep.text  = "Step\n${step.label}"
        binding.tvWidth.text = "Wid\n${vm.sharedWidth.value ?: 0}"
        binding.tvMode.text = "Mode\n${vm.sharedMode.value ?: "-"}"
        binding.tvPow.text = "Pow\n${((vm.sharedPower.value ?: 0f) * 100).toInt()}"
        binding.tvSQL.text = "SQL\n${((vm.sharedSQL.value ?: 0f) * 100).toInt()}"
        val bkOn = vm.sharedBkIn.value ?: false
        val rptDir  = vm.repeaterOffsetDir.value ?: ""
        val rptTone = vm.repeaterToneMode.value ?: ""
        val rptActive = rptDir.isNotEmpty() || rptTone.isNotEmpty()
        if (rptActive) {
            val dirStr  = if (rptDir.isNotEmpty()) rptDir else "-"
            val toneStr = if (rptTone.isNotEmpty()) rptTone else "-"
            binding.tvBkIn.text = "RPT\n$dirStr $toneStr"
            binding.tvBkIn.setTextColor(0xFFFFD600.toInt())
        } else {
            binding.tvBkIn.text = "BK-IN\n${if (bkOn) "ON" else "OFF"}"
            binding.tvBkIn.setTextColor(if (bkOn) 0xFF00E676.toInt() else 0xFF666666.toInt())
        }
        val tunerOn = vm.sharedTuner.value ?: false
        val vu = isVuFreq()
        binding.tvTuner.text = "TUNER\n${if (vu) "--" else if (tunerOn) "ON" else "OFF"}"
        binding.tvTuner.setTextColor(if (tunerOn && !vu) 0xFF00E676.toInt() else 0xFF666666.toInt())
        binding.tvTuner.alpha = if (vu) 0.35f else 1.0f  // V/U(>6m)はATU非対応のため無効表示
    }

    // V/U(VHF/UHF)判定: 6m(〜54MHz)より上はATU非対応とみなしTUNER操作を無効化する。
    private fun isVuFreq(): Boolean = (vm.sharedFreq.value ?: 0L) >= 60_000_000L

    // ───────── 運用地(POTA/SOTAアクティベーター運用セッション) ─────────

    // メイン画面の「現時点で有効な運用地」チェック行を再構築する。
    private fun refreshOpLocActive() {
        OpLocBar.populate(requireContext(), binding.svOpLocActive, binding.llOpLocActive, vm)
        // CWTX シート表示中なら、そちらの運用地バーも更新する
        refreshCwSheetOpLoc()
    }

    // CWTX ボトムシート内の運用地バー(表示中のみ)
    private var cwSheetOpLocScroll: View? = null
    private var cwSheetOpLocContainer: ViewGroup? = null
    private fun refreshCwSheetOpLoc() {
        val sv = cwSheetOpLocScroll ?: return
        val ll = cwSheetOpLocContainer ?: return
        OpLocBar.populate(requireContext(), sv, ll, vm)
    }

    private fun fmtOpTime(ms: Long): String {
        if (ms == 0L) return getString(R.string.main_control_9)
        val c = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC")).apply { timeInMillis = ms }
        return String.format("%02d/%02d %02d:%02dZ",
            c.get(java.util.Calendar.MONTH) + 1, c.get(java.util.Calendar.DAY_OF_MONTH),
            c.get(java.util.Calendar.HOUR_OF_DAY), c.get(java.util.Calendar.MINUTE))
    }

    private fun showOpSessionPanel() {
        val ctx = requireContext()
        val listBox = android.widget.LinearLayout(ctx).apply { orientation = android.widget.LinearLayout.VERTICAL }
        val scroll = android.widget.ScrollView(ctx).apply { addView(listBox) }
        // ヘッダに タイトル + 新規追加 + 閉じる(上固定)
        val btnAdd = android.widget.Button(ctx).apply { text = getString(R.string.main_control_10); isAllCaps = false }
        val btnClose = android.widget.Button(ctx).apply { text = getString(R.string.main_control_11); isAllCaps = false }
        val header = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL; setPadding(24, 8, 12, 4)
            addView(android.widget.TextView(ctx).apply {
                text = getString(R.string.main_control_12); setTextColor(0xFFFFFFFF.toInt()); textSize = 16f
                layoutParams = android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(btnAdd); addView(btnClose)
        }
        val root = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL; setPadding(24, 0, 24, 0)
            addView(header, android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(scroll, android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, (resources.displayMetrics.density * 360).toInt()))
        }
        val dlg = AlertDialog.Builder(ctx).setView(root).create()
        btnClose.setOnClickListener { dlg.dismiss() }
        fun refresh() {
            listBox.removeAllViews()
            val sessions = vm.opSessions.value ?: emptyList()
            if (sessions.isEmpty()) {
                listBox.addView(android.widget.TextView(ctx).apply {
                    text = getString(R.string.main_control_13)
                    setTextColor(0xFFAAAAAA.toInt()); setPadding(0, 12, 0, 12)
                })
            }
            sessions.forEach { s ->
                val row = android.widget.LinearLayout(ctx).apply {
                    orientation = android.widget.LinearLayout.HORIZONTAL
                    gravity = android.view.Gravity.CENTER_VERTICAL; setPadding(0, 6, 0, 6)
                }
                row.addView(android.widget.TextView(ctx).apply {
                    text = getString(R.string.main_control_14, s.type, s.ref, fmtOpTime(s.startMs), fmtOpTime(s.endMs)) +
                        if (s.label.isNotEmpty()) "  (${s.label})" else ""
                    textSize = 13f; setTextColor(0xFFFFFFFF.toInt())
                    layoutParams = android.widget.LinearLayout.LayoutParams(
                        0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                })
                row.addView(android.widget.Button(ctx).apply {
                    text = getString(R.string.main_control_15); textSize = 11f; setOnClickListener { showOpSessionEdit(s) { refresh() } }
                })
                row.addView(android.widget.Button(ctx).apply {
                    text = getString(R.string.main_control_16); textSize = 11f; setOnClickListener { vm.deleteOpSession(s.id); refresh() }
                })
                listBox.addView(row)
            }
        }
        refresh()
        btnAdd.setOnClickListener { showOpSessionEdit(null) { refresh() } }
        dlg.show()
    }

    private fun showOpSessionEdit(existing: OpSession?, onDone: () -> Unit) {
        val ctx = requireContext()
        val box = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL; setPadding(24, 8, 24, 8)
        }
        val typeSpinner = android.widget.Spinner(ctx).apply {
            adapter = android.widget.ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, OpSession.TYPES)
            setSelection(OpSession.TYPES.indexOf(existing?.type ?: "POTA").coerceAtLeast(0))
        }
        val refEt = android.widget.EditText(ctx).apply {
            hint = getString(R.string.main_control_17)
            setText(existing?.ref ?: "")
        }
        val labelEt = android.widget.EditText(ctx).apply { hint = getString(R.string.main_control_18); setText(existing?.label ?: "") }
        val glEt = android.widget.EditText(ctx).apply {
            hint = getString(R.string.main_control_19)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            setText(existing?.gl ?: "")
        }
        var startMs = existing?.startMs ?: System.currentTimeMillis()
        var endMs = existing?.endMs ?: 0L
        var useLocalTime = false
        // 開始/終了をローカルタイムで入力・表示するトグル(OFF=UTC)
        val swLocal = android.widget.Switch(ctx).apply {
            text = getString(R.string.main_control_20); textSize = 13f; isChecked = false
        }
        // 時刻表示: ローカル時は末尾を"L"、UTC時は"Z"(fmtOpTime)で区別
        fun fmtOp(ms: Long): String {
            if (ms == 0L) return getString(R.string.main_control_9)
            if (!useLocalTime) return fmtOpTime(ms)
            val c = java.util.Calendar.getInstance(java.util.TimeZone.getDefault()).apply { timeInMillis = ms }
            return String.format("%02d/%02d %02d:%02dL",
                c.get(java.util.Calendar.MONTH) + 1, c.get(java.util.Calendar.DAY_OF_MONTH),
                c.get(java.util.Calendar.HOUR_OF_DAY), c.get(java.util.Calendar.MINUTE))
        }
        val startBtn = android.widget.Button(ctx)
        val endBtn = android.widget.Button(ctx)
        fun updBtns() { startBtn.text = getString(R.string.main_control_21, fmtOp(startMs)); endBtn.text = getString(R.string.main_control_22, fmtOp(endMs)) }
        updBtns()
        swLocal.setOnCheckedChangeListener { _, checked -> useLocalTime = checked; updBtns() }
        startBtn.setOnClickListener { pickDateTime(startMs, useLocalTime) { startMs = it; updBtns() } }
        endBtn.setOnClickListener {
            AlertDialog.Builder(ctx).setTitle(getString(R.string.main_control_23))
                .setItems(arrayOf(getString(R.string.main_control_24), getString(R.string.main_control_25))) { _, which ->
                    if (which == 0) pickDateTime(if (endMs == 0L) startMs else endMs, useLocalTime) { endMs = it; updBtns() }
                    else { endMs = 0L; updBtns() }
                }.show()
        }
        // GPSで現在地のJCC/JGCを自動取得(種別も自動でJCC/JGCに切替)
        val gpsBtn = android.widget.Button(ctx).apply { text = getString(R.string.main_control_26); textSize = 13f }
        gpsBtn.setOnClickListener { ensureLocationPermission {
            GeoJcc.fetch(ctx,
                onInfo = { msg -> Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() },
                onResult = { jcc, jgc, jccMemo, jgcMemo, info, gl ->
                    // JCC/JGC と一緒に GL(グリッド)も自動取得して登録
                    if (gl.isNotEmpty()) glEt.setText(gl)
                    // メモはJCC=市/区、JGC=郡+町/村 と行政区分を分ける
                    fun setJcc() { typeSpinner.setSelection(OpSession.TYPES.indexOf("JCC")); refEt.setText(jcc); if (jccMemo.isNotEmpty()) labelEt.setText(jccMemo) }
                    fun setJgc() { typeSpinner.setSelection(OpSession.TYPES.indexOf("JGC")); refEt.setText(jgc); if (jgcMemo.isNotEmpty()) labelEt.setText(jgcMemo) }
                    when {
                        // 両方取れた時(政令市など)は、どちらを登録するか選ばせる(両方同時には入れない)
                        jcc.isNotEmpty() && jgc.isNotEmpty() ->
                            AlertDialog.Builder(ctx).setTitle(getString(R.string.main_control_27))
                                .setItems(arrayOf("JCC  $jcc", "JGC  $jgc")) { _, w -> if (w == 0) setJcc() else setJgc() }
                                .show()
                        jcc.isNotEmpty() -> setJcc()
                        jgc.isNotEmpty() -> setJgc()
                        else -> Toast.makeText(ctx, getString(R.string.main_control_28), Toast.LENGTH_SHORT).show()
                    }
                    Toast.makeText(ctx, info, Toast.LENGTH_LONG).show()
                })
        } }
        // SOTA/POTA は現在地周辺の地図から選択
        val mapBtn = android.widget.Button(ctx).apply { text = getString(R.string.main_control_29); textSize = 13f }
        mapBtn.setOnClickListener {
            val t = OpSession.TYPES[typeSpinner.selectedItemPosition]
            if (t != "SOTA" && t != "POTA") {
                Toast.makeText(ctx, getString(R.string.main_control_30), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            ensureLocationPermission { showMapPicker(t) { ref, name ->
                refEt.setText(ref)
                if (name.isNotBlank()) labelEt.setText(name)   // エンティティ名をメモに残す
            } }
        }
        box.addView(android.widget.TextView(ctx).apply { text = getString(R.string.main_control_31); setTextColor(0xFFAAAAAA.toInt()) })
        box.addView(typeSpinner); box.addView(refEt); box.addView(gpsBtn); box.addView(mapBtn)
        box.addView(swLocal); box.addView(startBtn); box.addView(endBtn); box.addView(labelEt); box.addView(glEt)
        // ヘッダに タイトル + キャンセル/保存(上固定、キーボードで隠れない)
        val btnCancel = android.widget.Button(ctx).apply { text = getString(R.string.main_control_32); isAllCaps = false }
        val btnSave = android.widget.Button(ctx).apply { text = getString(R.string.main_control_33); isAllCaps = false }
        val header = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL; setPadding(24, 8, 12, 4)
            addView(android.widget.TextView(ctx).apply {
                text = if (existing == null) getString(R.string.main_control_34) else getString(R.string.main_control_35)
                setTextColor(0xFFFFFFFF.toInt()); textSize = 16f
                layoutParams = android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(btnCancel); addView(btnSave)
        }
        val outer = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            addView(header, android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(android.widget.ScrollView(ctx).apply { addView(box) },
                android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        val dlg = AlertDialog.Builder(ctx).setView(outer).create()
        btnCancel.setOnClickListener { dlg.dismiss() }
        btnSave.setOnClickListener {
            val ref = refEt.text.toString().trim().uppercase()
            if (ref.isEmpty()) { Toast.makeText(ctx, getString(R.string.main_control_36), Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            if (endMs != 0L && endMs < startMs) { Toast.makeText(ctx, getString(R.string.main_control_37), Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val s = OpSession(
                id = existing?.id ?: java.util.UUID.randomUUID().toString(),
                type = OpSession.TYPES[typeSpinner.selectedItemPosition],
                ref = ref, startMs = startMs, endMs = endMs, label = labelEt.text.toString().trim(),
                gl = glEt.text.toString().trim().uppercase())
            val err = vm.addOpSession(s)
            if (err != null) Toast.makeText(ctx, err, Toast.LENGTH_LONG).show() else {
                // 登録GL: 6桁(フル)は myGrid6(ログMy GL用)へ、先頭4桁は ft8MyGrid(FT8/CW用)へ
                if (s.gl.length >= 4) { vm.prefs.ft8MyGrid = s.gl.take(4); vm.prefs.myGrid6 = s.gl }
                onDone(); dlg.dismiss()
            }
        }
        dlg.window?.apply {
            setBackgroundDrawableResource(android.R.color.background_dark)
            setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        dlg.setOnShowListener {
            dlg.window?.setLayout(
                (ctx.resources.displayMetrics.widthPixels * 0.95).toInt(),
                android.view.WindowManager.LayoutParams.MATCH_PARENT)
        }
        dlg.show()
    }

    // 現在地周辺の地図(osmdroid)でSOTAサミット/POTA公園を選ぶ。マーカータップでref+名称を返す。
    private fun showMapPicker(type: String, onPick: (String, String) -> Unit) {
        val ctx = requireContext()
        org.osmdroid.config.Configuration.getInstance().userAgentValue = ctx.packageName
        val density = ctx.resources.displayMetrics.density
        val map = org.osmdroid.views.MapView(ctx).apply {
            setTileSource(org.osmdroid.tileprovider.tilesource.TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(13.0)
        }
        val info = android.widget.TextView(ctx).apply {
            text = getString(R.string.main_control_38); setPadding(16, 8, 16, 8); setTextColor(0xFFCCCCCC.toInt())
        }
        val reSearchBtn = android.widget.Button(ctx).apply { text = getString(R.string.main_control_39); textSize = 13f }
        val box = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            addView(reSearchBtn)
            addView(info)
            addView(map, android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, (density * 420).toInt()))
        }
        val dlg = AlertDialog.Builder(ctx).setTitle(getString(R.string.main_control_40, type)).setView(box)
            .setNegativeButton(getString(R.string.main_control_11), null).create()

        // 指定座標の周辺エンティティを取得して地図に出す(既存マーカーは消す)
        fun loadFor(lat: Double, lon: Double) {
            map.overlays.removeAll { it is org.osmdroid.views.overlay.Marker }
            map.invalidate()
            info.text = getString(R.string.main_control_41, type)
            GeoJcc.fetchNearby(ctx, type, lat, lon) { items, dbg ->
                if (items.isEmpty()) {
                    info.text = getString(R.string.main_control_42, type, dbg)
                    return@fetchNearby
                }
                info.text = getString(R.string.main_control_43, type, items.size)
                // ピンの色: POTA=緑 / SOTA=赤
                val pinColor = if (type == "POTA") 0xFF2E7D32.toInt() else 0xFFC62828.toInt()
                val pinIcon = androidx.core.content.ContextCompat.getDrawable(
                    ctx, org.osmdroid.library.R.drawable.marker_default)?.mutate()?.also {
                    androidx.core.graphics.drawable.DrawableCompat.setTint(it, pinColor)
                }
                items.forEach { g ->
                    val m = org.osmdroid.views.overlay.Marker(map)
                    m.position = org.osmdroid.util.GeoPoint(g.lat, g.lon)
                    m.title = g.ref
                    m.snippet = g.name
                    if (pinIcon != null) m.icon = pinIcon
                    m.setAnchor(org.osmdroid.views.overlay.Marker.ANCHOR_CENTER, org.osmdroid.views.overlay.Marker.ANCHOR_BOTTOM)
                    m.setOnMarkerClickListener { _, _ ->
                        AlertDialog.Builder(ctx)
                            .setTitle(g.ref)
                            .setMessage("${g.name}\n(${"%.4f".format(g.lat)}, ${"%.4f".format(g.lon)})")
                            .setPositiveButton(getString(R.string.main_control_44)) { _, _ -> onPick(g.ref, g.name); dlg.dismiss() }
                            .setNegativeButton(getString(R.string.main_control_32), null)
                            .show()
                        true
                    }
                    map.overlays.add(m)
                }
                map.invalidate()
            }
        }
        reSearchBtn.setOnClickListener {
            val c = map.mapCenter   // 現在表示している地図中心で再取得
            loadFor(c.latitude, c.longitude)
        }
        dlg.setOnShowListener {
            map.onResume()
            GeoJcc.fetchLocation(ctx, onInfo = { info.text = it }) { lat, lon ->
                map.controller.setZoom(13.0)
                map.controller.setCenter(org.osmdroid.util.GeoPoint(lat, lon))
                loadFor(lat, lon)
            }
        }
        dlg.setOnDismissListener { map.onPause(); map.onDetach() }
        dlg.show()
    }

    private fun pickDateTime(initial: Long, useLocal: Boolean = false, onSet: (Long) -> Unit) {
        val ctx = requireContext()
        val tz = if (useLocal) java.util.TimeZone.getDefault() else java.util.TimeZone.getTimeZone("UTC")
        val c = java.util.Calendar.getInstance(tz).apply {
            timeInMillis = if (initial == 0L) System.currentTimeMillis() else initial
        }
        android.app.DatePickerDialog(ctx, { _, y, mo, d ->
            android.app.TimePickerDialog(ctx, { _, h, mi ->
                val cc = java.util.Calendar.getInstance(tz)
                cc.set(y, mo, d, h, mi, 0); cc.set(java.util.Calendar.MILLISECOND, 0)
                onSet(cc.timeInMillis)
            }, c.get(java.util.Calendar.HOUR_OF_DAY), c.get(java.util.Calendar.MINUTE), true).show()
        }, c.get(java.util.Calendar.YEAR), c.get(java.util.Calendar.MONTH), c.get(java.util.Calendar.DAY_OF_MONTH)).show()
    }

    private fun updateTxIndicator() {
        val tx   = vm.txEnabled.value == true
        val aprs = vm.aprsTxInProgress.value == true
        val cwKey = vm.cwKeyOn.value == true
        val bgColor = when {
            aprs  -> 0xFFFF8800.toInt()  // orange: APRS TX
            tx    -> 0xFFFF0000.toInt()  // red: PTT TX
            cwKey -> 0xFFFF0000.toInt()  // red: CW keying TX
            else  -> 0xFFDDDDDD.toInt()  // grey: RX
        }
        val lit = tx || aprs || cwKey
        binding.tvTxIndicator.setBackgroundColor(bgColor)
        binding.tvTxIndicator.setTextColor(if (lit) 0xFFFFFFFF.toInt() else 0xFF000000.toInt())
        binding.tvTxIndicator.text = if (aprs) "APRS" else "TX"
    }

    private fun updateButtonHighlights() {
        val sel = vm.selectedMenuItem.value ?: MenuItem.NONE
        val theme = pal

        fun tint(color: Int) = ColorStateList.valueOf(color)

        // FREQボタンは常に「FREQ」表示・FREQ選択時のみ点灯（STEPは専用のbtnStepが点灯する）
        binding.btnFreq.backgroundTintList = tint(if (sel == MenuItem.FREQ) 0xFF00BCD4.toInt() else theme.ctrlRowTint)
        binding.btnFreq.text = "FREQ"
        val powWidSqlActive = sel == MenuItem.POW || sel == MenuItem.WIDTH || sel == MenuItem.SQL
        binding.btnPowWidSql.backgroundTintList = tint(if (powWidSqlActive) 0xFF00BCD4.toInt() else theme.ctrlRowTint)
        binding.btnPowWidSql.text = when (sel) {
            MenuItem.POW   -> "P/W/S\nPower"
            MenuItem.WIDTH -> "P/W/S\nWidth"
            MenuItem.SQL   -> "P/W/S\nSQL"
            else           -> "P/W/S"
        }
        // STEP dedicated button (cyan when selected as ◀/▶ target)
        binding.btnStep.backgroundTintList = tint(if (sel == MenuItem.STEP) 0xFF00BCD4.toInt() else theme.ctrlRowTint)
        val nrLevel = vm.noiseReductionLevel.value ?: 0

        // VFO toggle button（CI-V直結でもA/B切替を有効化）
        val vfoMode = vm.vfoMode.value ?: ""
        val vfoSide = vm.vfoCurrentSide.value ?: ""
        if (vfoMode.isNotEmpty() || vm.useCIV.value == true) {
            binding.btnVfoToggle.isEnabled = true
            binding.btnVfoToggle.alpha = 1.0f
            binding.btnVfoToggle.text = vfoSide.ifEmpty { "A/B" }
            binding.btnVfoToggle.backgroundTintList = tint(theme.ctrlRowTint)
            binding.btnVfoToggle.setTextColor(0xFFFFFFFF.toInt())
        } else {
            binding.btnVfoToggle.isEnabled = false
            binding.btnVfoToggle.alpha = 0.3f
            binding.btnVfoToggle.text = "A/B"
        }

        // Info row highlight: selected item → cyan text
        binding.tvStep.setTextColor(if (sel == MenuItem.STEP)   0xFF00FFFF.toInt() else 0xFFCCCCCC.toInt())
        binding.tvWidth.setTextColor(if (sel == MenuItem.WIDTH) 0xFF00FFFF.toInt() else 0xFFCCCCCC.toInt())
        binding.tvMode.setTextColor(if (sel == MenuItem.MODE)  0xFF00FFFF.toInt() else 0xFFCCCCCC.toInt())
        binding.tvPow.setTextColor(if (sel == MenuItem.POW)    0xFF00FFFF.toInt() else 0xFFCCCCCC.toInt())
        binding.tvSQL.setTextColor(if (sel == MenuItem.SQL)    0xFF00FFFF.toInt() else 0xFFCCCCCC.toInt())

        // APRS button — same color scheme as SPK
        val aprsEnabled = vm.aprsEnabled.value ?: false
        val aprsActive = vm.aprsActive.value ?: false
        val aprsRig = vm.aprsUseRigModem.value ?: false
        val aprsAt2 = vm.aprsAtPreset2.value ?: false
        val aprsColor = when {
            !aprsEnabled -> 0xFF455A64.toInt()   // disabled: grey
            aprsActive   -> 0xFFAEEA00.toInt()   // active: bright yellow-green (= SPK ON)
            else         -> 0xFF1B5E20.toInt()   // ready: dark green (= SPK OFF)
        }
        binding.btnAprs.backgroundTintList = tint(aprsColor)
        binding.btnAprs.text = when {
            aprsRig && aprsActive && aprsAt2  -> "AP12"
            aprsRig && aprsActive             -> "AP96"
            aprsRig                           -> "AP96"
            else                              -> "APRS"
        }

        // BT CI-V hybrid: disable audio-dependent buttons when RS-BA1 not connected
        val isBtCiv = (vm.useCIV.value == true) && (vm.civConnectionType.value == "BT")
        val btAudioReady = !isBtCiv || (vm.btHybridAudioReady.value == true)
        binding.btnPtt.isEnabled = btAudioReady
        binding.btnPtt.alpha = if (btAudioReady) 1.0f else 0.3f
        binding.btnSpk.isEnabled = btAudioReady
        binding.btnSpk.alpha = if (btAudioReady) 1.0f else 0.3f
        binding.btnCwTx.isEnabled = btAudioReady
        binding.btnCwTx.alpha = if (btAudioReady) 1.0f else 0.3f

        // PTT button
        val txOn = vm.txEnabled.value ?: false
        val pttColor = if (txOn) 0xFFAD1457.toInt() else 0xFF6A1B9A.toInt()
        binding.btnPtt.backgroundTintList = tint(pttColor)

        // SPK button
        val sampIdx = vm.selectedSamplingIndex.value ?: 2
        val sampRate = SAMPLING_RATES.getOrElse(sampIdx) { 0 }
        val spkEnabled = vm.spkEnabled.value ?: false
        val cwDecoding = vm.cwDecoding.value ?: false
        val spkColor = when {
            sampRate == 0 -> 0xFF455A64.toInt()
            spkEnabled    -> 0xFFAEEA00.toInt()  // Yellow-green: SPK ON
            else          -> 0xFF1B5E20.toInt()  // Dark green: SPK OFF
        }
        binding.btnSpk.backgroundTintList = tint(spkColor)
        binding.btnSpk.text = "SPK"

        // NR/DEC combined button: bg = NR(purple) > DEC(teal) > idle; text = "NR{lvl}\nDEC[•]"
        val nrActive = nrLevel > 0
        val nrBg = when {
            nrActive   -> 0xFF6A1B9A.toInt()  // purple: NR on
            cwDecoding -> 0xFF00897B.toInt()  // teal: DEC (CW decode) on
            else       -> theme.ctrlRowTint
        }
        binding.btnNr.backgroundTintList = tint(nrBg)
        val nrLine  = if (nrActive) "NR$nrLevel" else "NR"
        val decLine = if (cwDecoding) "DEC•" else "DEC"
        binding.btnNr.text = "$nrLine\n$decLine"

        // Mode quick-select buttons (Row 1): base=cyan / PKT variant=teal / inactive=dark indigo
        val curMode = vm.sharedMode.value ?: ""
        val modeBase    = 0xFF00BCD4.toInt()  // cyan:  base mode active
        val modePkt     = 0xFF00897B.toInt()  // teal:  PKT/variant active
        val modeOff     = theme.modeRowTint   // inactive: follows color theme

        val textActive   = 0xFF000000.toInt()  // 黒: 選択時（明るい背景に対してコントラスト確保）
        val textInactive = 0xFF6677CC.toInt()  // 淡青: 非選択時

        // btnModeLsb = SSB統合ボタン（LSB/USB/PKTLSB/PKTUSB）
        val lsbUsbActive = curMode == "LSB" || curMode == "PKTLSB" || curMode == "USB" || curMode == "PKTUSB"
        binding.btnModeLsb.backgroundTintList = tint(when (curMode) {
            "LSB", "USB" -> modeBase; "PKTLSB", "PKTUSB" -> modePkt; else -> modeOff
        })
        binding.btnModeLsb.text = when (curMode) {
            "USB" -> "USB"; "PKTUSB" -> "PKT-U"; "PKTLSB" -> "PKT-L"; "LSB" -> "LSB"; else -> "SSB"
        }
        binding.btnModeLsb.setTextColor(if (lsbUsbActive) textActive else textInactive)

        // btnModeUsb = CWボタン（USBの位置）
        val cwActive = curMode == "CW" || curMode == "CWR"
        binding.btnModeUsb.backgroundTintList = tint(when (curMode) { "CW" -> modeBase; "CWR" -> modePkt; else -> modeOff })
        binding.btnModeUsb.text = if (curMode == "CWR") "CWR" else "CW"
        binding.btnModeUsb.setTextColor(if (cwActive) textActive else textInactive)

        // btnModeCw = AMボタン（CWの位置）
        val amActive = curMode == "AM" || curMode == "SAM" || curMode == "AMS"
        binding.btnModeCw.backgroundTintList = tint(if (amActive) modeBase else modeOff)
        binding.btnModeCw.text = when (curMode) { "SAM" -> "SAM"; "AMS" -> "AMS"; else -> "AM" }
        binding.btnModeCw.setTextColor(if (amActive) textActive else textInactive)

        val fmActive = curMode == "FM" || curMode == "FM-D" || curMode == "PKTFM" ||
            curMode == "C4FM" || curMode == "DSTAR" || curMode == "D-STAR"
        binding.btnModeFm.backgroundTintList  = tint(when (curMode) {
            "FM"    -> modeBase
            "FM-D"  -> modePkt
            "PKTFM" -> modePkt
            "C4FM"  -> modePkt
            "DSTAR", "D-STAR" -> modePkt
            else    -> modeOff
        })
        binding.btnModeFm.text = when (curMode) {
            "FM-D", "PKTFM"   -> "PKT-F"
            "C4FM"            -> "C4FM"
            "DSTAR", "D-STAR" -> "D-STAR"
            else              -> "FM"
        }
        binding.btnModeFm.setTextColor(if (fmActive) textActive else textInactive)
    }

    // --------------- Color theme support ---------------

    private data class ThemeColors(
        val label: String,
        val btnTint: Int,
        val rootBg: Int,
        val freqPanelBg: Int,
        val freqText: Int,
        val freqNavTint: Int,
        val modeRowTint: Int,
        val ctrlRowTint: Int,
    )

    // テーマ総数（配色の実体は ui/theme/ThemePalette.kt の UiTheme / getThemePalette）
    private val themeCount = UiTheme.entries.size

    // 現在のテーマ×昼夜から導出した、この画面用の配色一式（下記 buildThemeColors で生成）。
    // 旧来のハードコード uiThemes 表は廃止し、ブランド共通トークン(ThemePalette)を唯一の出典にした。
    private var pal: ThemeColors = buildThemeColors(0, false)

    /** 正準 ThemePalette から、この画面が使うロール群へ射影する。 */
    private fun buildThemeColors(idx: Int, day: Boolean): ThemeColors {
        val theme = UiTheme.fromIndex(idx)
        val p = getThemePalette(theme, day)
        // モード行/制御行(非選択)のボタン色は v3.26 のオリジナル配色（テーマ別）に戻す。
        // 背景・周波数文字などはパレット由来のまま維持する。
        val (modeTint, ctrlTint) = when (theme) {
            UiTheme.OCEAN -> 0xFF1A237E.toInt() to 0xFF1565C0.toInt()
            UiTheme.AMBER -> 0xFF4A2800.toInt() to 0xFF8B5E00.toInt()
            UiTheme.MONO  -> 0xFF242424.toInt() to 0xFF404040.toInt()
            UiTheme.AQUA  -> 0xFF0A3040.toInt() to 0xFF1A7860.toInt()
        }
        return ThemeColors(
            label       = theme.displayName,
            btnTint     = p.accentTeal,   // テーマチップ＝代表色(accentTeal)。M5 と同じ扱い
            rootBg      = p.bgDark,
            freqPanelBg = p.chipBg,        // 周波数パネルは濃色カード→chipBg
            freqText    = p.accentTeal,    // 周波数のグロー表示色
            freqNavTint = p.accentBlue,
            modeRowTint = modeTint,        // 元の色（OCEAN=濃インディゴ 等）
            ctrlRowTint = ctrlTint,        // 元の色（OCEAN=青 等）
        )
    }

    private fun applyColorTheme(idx: Int) {
        currentThemeIdx = idx.coerceIn(0, themeCount - 1)
        pal = buildThemeColors(currentThemeIdx, currentDay)
        val t = pal
        binding.root.setBackgroundColor(t.rootBg)
        binding.llFreqPanel.setBackgroundColor(t.freqPanelBg)
        binding.tvFreq.setTextColor(t.freqText)
        for (btn in listOf(binding.btnFreqMinus, binding.btnFreqPlus))
            btn.backgroundTintList = ColorStateList.valueOf(t.freqNavTint)
        binding.btnColorTheme.backgroundTintList = ColorStateList.valueOf(t.btnTint)
        binding.btnColorTheme.setTextColor(ThemePalette.contrastTextColor(t.btnTint))
        binding.btnColorTheme.text = t.label
        updateButtonHighlights()
        updateModelDisplay()
    }

    /** 昼/夜モードを切り替えて再適用（テーマチップ長押しから呼ぶ）。 */
    private fun toggleDayMode() {
        currentDay = !currentDay
        vm.prefs.dayMode = currentDay
        applyColorTheme(currentThemeIdx)
        Toast.makeText(requireContext(), if (currentDay) "DAY" else "NIGHT", Toast.LENGTH_SHORT).show()
    }

    // ---------------------------------------------------

    private fun setupButtons() {
        // Freq → frequency input screen; long press → memory panel
        binding.tvFreq.setOnClickListener {
            if (vm.txEnabled.value == true) return@setOnClickListener
            findNavController().navigate(R.id.action_MainControlFragment_to_FreqInputFragment)
        }
        binding.tvFreq.setOnLongClickListener {
            if (vm.txEnabled.value == true) return@setOnLongClickListener true
            showMemoryPanel()
            true
        }

        // FREQ button: toggles FREQ ON/OFF (STEPは専用ボタン(btnStep)があるので循環に含めない)
        binding.btnFreq.setOnClickListener {
            if (vm.txEnabled.value == true) return@setOnClickListener
            vm.selectedMenuItem.value =
                if (vm.selectedMenuItem.value == MenuItem.FREQ) MenuItem.NONE else MenuItem.FREQ
        }

        // P/W/S button: cycles POW → WIDTH → SQL → NONE
        binding.btnPowWidSql.setOnClickListener {
            if (vm.txEnabled.value == true) return@setOnClickListener
            vm.selectedMenuItem.value = when (vm.selectedMenuItem.value) {
                MenuItem.POW   -> MenuItem.WIDTH
                MenuItem.WIDTH -> MenuItem.SQL
                MenuItem.SQL   -> MenuItem.NONE
                else           -> MenuItem.POW
            }
        }

        // 運用地ボタン: POTA/SOTAアクティベーター運用セッションの管理
        binding.btnOpLoc.setOnClickListener { showOpSessionPanel() }

        // MEM button: short tap = show memory list, long tap = manage
        binding.btnMem.apply { text = "MEM\nSET"; maxLines = 2 }
        binding.btnMem.setOnClickListener { showMemoryPanel() }
        binding.btnMem.setOnLongClickListener { showMemoryManagePanel(); true }

        // VFO toggle grid button
        binding.btnVfoToggle.setOnClickListener {
            if (vm.txEnabled.value == true) return@setOnClickListener
            vm.toggleVfo()
        }

        // Info row taps: Step / Width それぞれ独立して選択/解除
        binding.tvStep.setOnClickListener {
            if (vm.txEnabled.value == true) return@setOnClickListener
            vm.selectedMenuItem.value =
                if (vm.selectedMenuItem.value == MenuItem.STEP) MenuItem.NONE else MenuItem.STEP
        }
        binding.tvWidth.setOnClickListener {
            if (vm.txEnabled.value == true) return@setOnClickListener
            vm.selectedMenuItem.value =
                if (vm.selectedMenuItem.value == MenuItem.WIDTH) MenuItem.NONE else MenuItem.WIDTH
        }
        // Long-press Wid: pick the RX filter width directly from a list (applies via setWidth).
        binding.tvWidth.setOnLongClickListener {
            if (vm.txEnabled.value == true) return@setOnLongClickListener false
            val widths = intArrayOf(50, 100, 150, 200, 250, 300, 400, 500, 600, 1000, 1200, 2400, 3000)
            val cur = vm.sharedWidth.value ?: 0
            val labels = widths.map { if (it == cur) "$it Hz  ✓" else "$it Hz" }.toTypedArray()
            android.app.AlertDialog.Builder(requireContext())
                .setTitle(getString(R.string.main_control_45))
                .setItems(labels) { _, which -> vm.setWidth(widths[which]) }
                .setNegativeButton(getString(R.string.main_control_11), null)
                .show()
            true
        }

        // Info row other taps: select parameter for UP/DOWN
        listOf(
            binding.tvMode to MenuItem.MODE,
            binding.tvPow  to MenuItem.POW,
            binding.tvSQL  to MenuItem.SQL
        ).forEach { (tv, item) ->
            tv.setOnClickListener {
                if (vm.txEnabled.value == true) return@setOnClickListener
                vm.selectedMenuItem.value =
                    if (vm.selectedMenuItem.value == item) MenuItem.NONE else item
            }
        }

        // Info row long press: pick value from list
        binding.tvStep.setOnLongClickListener {
            val items = STEP_LIST.map { it.label }.toTypedArray()
            val cur = vm.selectedStep.value ?: 0
            AlertDialog.Builder(requireContext()).setTitle("Step")
                .setSingleChoiceItems(items, cur) { dlg, which ->
                    vm.selectedStep.value = which
                    vm.prefs.setModeStep(vm.sharedMode.value ?: "", which)
                    updateInfoRow(); dlg.dismiss()
                }.setNegativeButton("Cancel", null).show()
            true
        }

        binding.tvMode.setOnLongClickListener {
            val modes = vm.supportedModes.value?.takeIf { it.isNotEmpty() } ?: return@setOnLongClickListener true
            val cur = modes.indexOf(vm.sharedMode.value ?: "").coerceAtLeast(0)
            AlertDialog.Builder(requireContext()).setTitle("Mode")
                .setSingleChoiceItems(modes.toTypedArray(), cur) { dlg, which ->
                    val m = modes[which]
                    val w = modeDefaultWidth(m)
                    vm.sendMode(m, w)
                    if (w > 0) vm.sharedWidth.value = w
                    vm.selectedStep.value = vm.prefs.getModeStep(m)
                    dlg.dismiss()
                }.setNegativeButton("Cancel", null).show()
            true
        }

        val pctSteps = (0..20).map { it * 5 }
        binding.tvPow.setOnLongClickListener {
            val cur = ((vm.sharedPower.value ?: 0f) * 100).toInt()
            val idx = pctSteps.indexOfFirst { it >= cur }.coerceAtLeast(0)
            AlertDialog.Builder(requireContext()).setTitle("Power")
                .setSingleChoiceItems(pctSteps.map { "$it" }.toTypedArray(), idx) { dlg, which ->
                    vm.sendPower(pctSteps[which] / 100f); dlg.dismiss()
                }.setNegativeButton("Cancel", null).show()
            true
        }

        binding.tvSQL.setOnLongClickListener {
            val cur = ((vm.sharedSQL.value ?: 0f) * 100).toInt()
            val idx = pctSteps.indexOfFirst { it >= cur }.coerceAtLeast(0)
            AlertDialog.Builder(requireContext()).setTitle("Squelch")
                .setSingleChoiceItems(pctSteps.map { "$it" }.toTypedArray(), idx) { dlg, which ->
                    vm.sendSQL(pctSteps[which] / 100f); dlg.dismiss()
                }.setNegativeButton("Cancel", null).show()
            true
        }

        // ◀/▶ → 選択中のパラメータを増減（未選択時はデフォルトで周波数）
        binding.btnFreqMinus.setOnClickListener { handleUpDown(-1) }
        binding.btnFreqPlus.setOnClickListener  { handleUpDown(1) }

        // NR/DEC combined button: short tap = cycle NR, long press = toggle CW decode (DEC)
        binding.btnNr.setOnClickListener {
            if (vm.txEnabled.value == true) return@setOnClickListener
            vm.cycleNoiseReduction()
            val level = vm.noiseReductionLevel.value ?: 0
            val msg = when (level) {
                0    -> "Noise Reduction: OFF"
                1    -> "Noise Reduction: Level 1 (Light)"
                2    -> "Noise Reduction: Level 2 (Medium)"
                3    -> "Noise Reduction: Level 3 (Strong)"
                4    -> "Noise Reduction: Level 4 (Max)"
                5    -> "Noise Reduction: Level 5 (Neural)"
                else -> "Noise Reduction: Level $level"
            }
            Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
        }
        binding.btnNr.setOnLongClickListener {
            vm.toggleCwDecoding()
            val decoding = vm.cwDecoding.value ?: false
            val msg = if (decoding) "CW Decode ON (yellow=RX  blue=TX)" else "CW Decode OFF"
            Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
            true
        }

        // STEP button: short tap = select STEP for ◀/▶, long press = pick step value
        binding.btnStep.setOnClickListener {
            if (vm.txEnabled.value == true) return@setOnClickListener
            vm.selectedMenuItem.value =
                if (vm.selectedMenuItem.value == MenuItem.STEP) MenuItem.NONE else MenuItem.STEP
        }
        binding.btnStep.setOnLongClickListener {
            val items = STEP_LIST.map { it.label }.toTypedArray()
            val cur = vm.selectedStep.value ?: 0
            AlertDialog.Builder(requireContext()).setTitle("Step")
                .setSingleChoiceItems(items, cur) { dlg, which ->
                    vm.selectedStep.value = which
                    vm.prefs.setModeStep(vm.sharedMode.value ?: "", which)
                    updateInfoRow(); dlg.dismiss()
                }.setNegativeButton("Cancel", null).show()
            true
        }

        // LOG QSO button (main screen) — pass pending values set by MEMSET/SP2Alert
        binding.btnLogQso?.setOnClickListener {
            LogQsoDialogFragment.newInstance(
                callsign = vm.pendingLogCallsign,
                pota     = vm.pendingLogPota,
                sota     = vm.pendingLogSota
            ).show(parentFragmentManager, "log_qso")
        }

        // LOG LIST button (main screen)
        binding.btnShowLog?.setOnClickListener {
            findNavController().navigate(R.id.action_mainControl_to_qsoLog)
        }

        // BK-IN toggle tap / RPT tap → repeater settings
        binding.tvBkIn.setOnClickListener {
            if (vm.txEnabled.value == true) return@setOnClickListener
            val rptActive = (vm.repeaterOffsetDir.value ?: "").isNotEmpty() ||
                            (vm.repeaterToneMode.value ?: "").isNotEmpty()
            if (rptActive) {
                showRepeaterDialog()
            } else {
                val isCiv = vm.useCIV.value == true
                val supported = vm.bkInSupported.value
                if (!isCiv && supported == false) {
                    Toast.makeText(requireContext(), getString(R.string.bk_in_not_supported), Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val next = !(vm.sharedBkIn.value ?: false)
                vm.sendBkIn(next)
            }
        }

        // TUNER tap = toggle ON/OFF, long press = start tuning (ATU TUNE)
        binding.tvTuner.setOnClickListener {
            if (vm.txEnabled.value == true) return@setOnClickListener
            if (isVuFreq()) {
                Toast.makeText(requireContext(), "V/U: tuner not available", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            vm.sendTuner(if (vm.sharedTuner.value == true) 0 else 1)
        }
        binding.tvTuner.setOnLongClickListener {
            if (vm.txEnabled.value == true) return@setOnLongClickListener true
            if (isVuFreq()) {
                Toast.makeText(requireContext(), "V/U: tuner not available", Toast.LENGTH_SHORT).show()
                return@setOnLongClickListener true
            }
            vm.sendTuner(2)  // TUNE開始
            Toast.makeText(requireContext(), "Tuner: start tuning", Toast.LENGTH_SHORT).show()
            true
        }

        // PTT long press: repeater settings
        binding.btnPtt.setOnLongClickListener { showRepeaterDialog(); true }

        // PTT toggle
        binding.btnPtt.setOnClickListener {
            val on = !(vm.txEnabled.value ?: false)
            if (on && ContextCompat.checkSelfPermission(
                    requireContext(), Manifest.permission.RECORD_AUDIO
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                requestMicPermission.launch(Manifest.permission.RECORD_AUDIO)
            } else {
                vm.setPttEnabled(on)
            }
        }

        // SPK toggle
        binding.btnSpk.setOnClickListener {
            if (vm.txEnabled.value == true) return@setOnClickListener
            val on = !(vm.spkEnabled.value ?: false)
            vm.spkEnabled.value = on
            if (vm.useCIV.value == true) {
                // CI-V mode: toggle AudioTrack in CivTcpService
                vm.civSetSpk(on)
            } else {
                // Pi mode: start/stop aplay stream
                val sampIdx = vm.selectedSamplingIndex.value ?: 2
                val sampRate = SAMPLING_RATES.getOrElse(sampIdx) { 0 }
                if (sampRate == 0) {
                    Toast.makeText(requireContext(), "Sampling rate=OFF", Toast.LENGTH_SHORT).show()
                    vm.spkEnabled.value = false
                    return@setOnClickListener
                }
                if (on) vm.startAudio() else vm.stopAudio()
            }
        }


        // APRS: disabled in CI-V direct mode (no Pi)
        val isCiv = vm.useCIV.value == true
        binding.btnAprs.isEnabled = !isCiv
        binding.btnAprs.alpha = if (isCiv) 0.3f else 1.0f

        // FT8: available in both Pi mode and CI-V mode (CI-V uses local engine)
        binding.btnFt8.setOnClickListener {
            if (vm.isDemoMode.value == true) {
                Toast.makeText(requireContext(), "FT8 is not available in Demo Mode", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            findNavController().navigate(R.id.action_MainControlFragment_to_Ft8Fragment)
        }
        binding.btnFt8.setOnLongClickListener {
            // RTTY is offered on the Pi path only. Over CI-V (RS-BA1) the rig only transmits RTTY as
            // AFSK in a data mode, forcing a PKTLSB↔RTTY mode switch on every over, and FSK keying
            // has no path over RS-BA1 at all — so RTTY is blocked in CI-V mode.
            if (isCiv) {
                Toast.makeText(requireContext(), "RTTY is not available in CI-V mode", Toast.LENGTH_SHORT).show()
                return@setOnLongClickListener true
            }
            findNavController().navigate(R.id.action_MainControlFragment_to_RttyFragment)
            true
        }

        // S-meter long-press → Band Scope (バンドスコープ)。
        // Pi接続: ② CATスイープ。CI-V直接(Wi-Fi/BT, Icom): ① ネイティブスコープ(受信音と両立)。
        // Demo のみ非対応。CI-V BT は帯域が狭く更新は遅いが対応する。
        binding.llSmeter.setOnLongClickListener {
            if (vm.isDemoMode.value == true) {
                Toast.makeText(requireContext(), "Band Scope is not available in Demo Mode", Toast.LENGTH_SHORT).show()
                return@setOnLongClickListener true
            }
            findNavController().navigate(R.id.action_MainControlFragment_to_BandScopeFragment)
            true
        }

        // APRS: short tap = toggle active, long tap = settings
        binding.btnAprs.setOnClickListener {
            if (vm.useCIV.value == true) {
                Toast.makeText(requireContext(), "APRS is not available with direct CI-V connection", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (vm.aprsEnabled.value != true) {
                Toast.makeText(requireContext(), "APRS disabled (hold to configure)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            vm.toggleAprs()
        }
        binding.btnAprs.setOnLongClickListener {
            if (vm.useCIV.value == true) {
                Toast.makeText(requireContext(), "APRS is not available with direct CI-V connection", Toast.LENGTH_SHORT).show()
                return@setOnLongClickListener true
            }
            findNavController().navigate(R.id.action_MainControlFragment_to_AprsSettingsFragment)
            true
        }

        // BACK → rig select
        binding.btnBack.setOnClickListener {
            vm.disconnectFromRig()
            findNavController().navigate(R.id.action_MainControlFragment_to_RigSelectFragment)
        }

        // CW TX button
        binding.btnCwTx.setOnClickListener {
            if (vm.cwTxBusy.value == true) {
                vm.stopCwText()
                cwTxSheet?.dismiss()
                Toast.makeText(requireContext(), "CW TX stopped", Toast.LENGTH_SHORT).show()
            } else {
                if (cwTxSheet?.isShowing != true) showCwTxPanel()
            }
        }

        // CW USB/BLE status bar — tap shows keyer-type chooser dialog
        binding.llCwUsb.setOnClickListener {
            if (vm.cwTxBusy.value == true) {
                vm.stopCwText()
                Toast.makeText(requireContext(), "CW TX stopped", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            showCwKeyerSelectDialog()
        }

        // Long press: CW settings menu (sidetone toggle / Pi port select / VPN buffer)
        binding.llCwUsb.setOnLongClickListener {
            val sidetoneLabel = if (vm.cwSidetoneEnabled.value == true)
                "Sidetone: ON → turn OFF" else "Sidetone: OFF → turn ON"
            val bufMs = vm.prefs.cwDelayMs
            val vpnLabel = "CW VPN buffer: ${bufMs}ms"
            AlertDialog.Builder(requireContext())
                .setTitle("CW USB Settings")
                .setItems(arrayOf(sidetoneLabel, "Select Pi CW Port", vpnLabel)) { _, which ->
                    when (which) {
                        0 -> vm.toggleCwSidetone()
                        1 -> lifecycleScope.launch { showCwPortDialog() }
                        2 -> showCwBufferDialog()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
            true
        }

        // CW BLE tap area — same chooser dialog as llCwUsb tap
        binding.llCwBt.setOnClickListener {
            showCwKeyerSelectDialog()
        }
        binding.llCwBt.setOnLongClickListener {
            val sidetoneLabel = if (vm.cwSidetoneEnabled.value == true)
                "Sidetone: ON → turn OFF" else "Sidetone: OFF → turn ON"
            AlertDialog.Builder(requireContext())
                .setTitle("CW BLE Settings")
                .setItems(arrayOf(sidetoneLabel, "Disconnect BLE")) { _, which ->
                    when (which) {
                        0 -> vm.toggleCwSidetone()
                        1 -> vm.disconnectCwBle()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
            true
        }

        // Mode quick-select buttons (Row 4)
        binding.btnModeLsb.setOnClickListener { quickSetMode("SSB") }
        binding.btnModeUsb.setOnClickListener { quickSetMode("CW") }
        binding.btnModeCw.setOnClickListener  { quickSetMode("AM") }
        binding.btnModeFm.setOnClickListener  { quickSetMode("FM") }
        binding.btnModeFm.setOnLongClickListener { showFmDigitalSettings(); true }

        // D★情報表示をタップ → 送信メッセージを即変更(FM長押し階層を経由せず最短で)。長押しはフル設定へ。
        binding.llDstarInfo?.setOnClickListener { showDstarTxMessageQuick() }
        binding.llDstarInfo?.setOnLongClickListener { showFmDigitalSettings(); true }

        // Color theme cycle button
        binding.btnColorTheme.setOnClickListener {
            val next = (vm.prefs.colorTheme + 1) % themeCount
            vm.prefs.colorTheme = next
            applyColorTheme(next)
        }
        // 長押しで昼/夜モード切替（M5 の DAY/NGT チップに相当）
        binding.btnColorTheme.setOnLongClickListener {
            toggleDayMode()
            true
        }

        binding.btnHelp?.setOnClickListener {
            startActivity(Intent(requireContext(), HelpActivity::class.java))
        }

        // CW TX SHIFT buttons — TX周波数のみシフト(RX変化なし)、短押し±step、長押し±step*10
        binding.btnCwShiftDown?.setOnClickListener {
            val s = vm.prefs.cwShiftStep.toLong()
            vm.setCwTxShift((vm.cwTxShiftHz.value ?: 0L) - s)
        }
        binding.btnCwShiftDown?.setOnLongClickListener {
            val s = vm.prefs.cwShiftStep.toLong() * 10L
            vm.setCwTxShift((vm.cwTxShiftHz.value ?: 0L) - s); true
        }
        binding.btnCwShiftUp?.setOnClickListener {
            val s = vm.prefs.cwShiftStep.toLong()
            vm.setCwTxShift((vm.cwTxShiftHz.value ?: 0L) + s)
        }
        binding.btnCwShiftUp?.setOnLongClickListener {
            val s = vm.prefs.cwShiftStep.toLong() * 10L
            vm.setCwTxShift((vm.cwTxShiftHz.value ?: 0L) + s); true
        }
        binding.tvCwShiftLabel?.setOnLongClickListener { vm.setCwTxShift(0L); true }
        binding.tvCwShiftHz?.setOnLongClickListener { showCwShiftStepDialog(); true }
    }

    private fun quickSetMode(key: String) {
        if (vm.txEnabled.value == true) return
        val current = vm.sharedMode.value ?: ""
        val target = when (key) {
            "SSB" -> {
                val supported = vm.supportedModes.value ?: emptyList()
                val cycle = buildList {
                    add("LSB"); add("USB")
                    if (supported.isEmpty() || "PKTLSB" in supported) add("PKTLSB")
                    if (supported.isEmpty() || "PKTUSB" in supported) add("PKTUSB")
                }
                val idx = cycle.indexOf(current)
                if (idx in 0 until cycle.size - 1) cycle[idx + 1] else "LSB"
            }
            "CW"  -> if (current == "CW")  "CWR"    else "CW"
            "AM"  -> "AM"
            // FM ボタンサイクル: supportedModes から FM 系モードを全て動的に収集する。
            // FM を先頭に固定し、それ以外の FM 系モード(FMN/FM-D/C4FM/PKTFM 等)を
            // supportedModes の順序で追加。DSTAR/D-STAR は設定有効時のみ末尾に追加。
            // Hamlib(Pi)とCI-V直結でD-STAR表記が異なる: Pi="D-STAR" / CI-V="DSTAR"
            "FM"  -> {
                val modes = vm.supportedModes.value ?: emptyList()
                val dstarKey = if (vm.useCIV.value == true) "DSTAR" else "D-STAR"
                val dstarSupported = modes.any { it == "DSTAR" || it == "D-STAR" }
                val cycle = buildList {
                    add("FM")
                    // FM 自身と WFM を除く FM 系モードを supportedModes 順で追加
                    modes.filter { m ->
                        val u = m.uppercase()
                        (u.startsWith("FM") || u == "C4FM" || u == "PKTFM") &&
                            m != "FM" && u != "WFM"
                    }.forEach { add(it) }
                    if (dstarSupported && vm.prefs.fmDstarEnabled) add(dstarKey)
                }
                val idx = cycle.indexOf(current)
                if (idx in 0 until cycle.size - 1) cycle[idx + 1] else "FM"
            }
            else  -> key
        }
        val w = modeDefaultWidth(target)
        vm.sendMode(target, w)
        vm.selectedStep.value = vm.prefs.getModeStep(target)
    }

    private fun showRepeaterDialog() {
        val ctx = requireContext()
        val toneModes = arrayOf("None", "Tone", "TSQL", "DTCS")
        val ctcssTones = doubleArrayOf(
            67.0, 71.9, 74.4, 77.0, 79.7, 82.5, 85.4, 88.5, 91.5, 94.8,
            97.4, 100.0, 103.5, 107.2, 110.9, 114.8, 118.8, 123.0, 127.3, 131.8,
            136.5, 141.3, 146.2, 151.4, 156.7, 162.2, 167.9, 173.8, 179.9, 186.2,
            192.8, 203.5, 210.7, 218.1, 225.7, 233.6, 241.8, 250.3, 254.1
        )
        val toneLabels = ctcssTones.map { "%.1f Hz".format(it) }.toTypedArray()
        val offsetDirs = arrayOf("None", "+", "-")
        val offsetPresets = longArrayOf(0L, 100_000L, 600_000L, 1_000_000L, 1_600_000L, 5_000_000L, 7_600_000L)
        val offsetLabels = arrayOf("Custom", "100 kHz", "600 kHz", "1 MHz", "1.6 MHz", "5 MHz", "7.6 MHz")

        val curToneMode  = vm.repeaterToneMode.value ?: ""
        val curToneHz    = vm.repeaterToneHz.value ?: 0.0
        val curOffsetDir = vm.repeaterOffsetDir.value ?: ""
        val curOffsetHz  = vm.repeaterOffsetHz.value ?: 0L

        val root = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL; setPadding(56, 16, 56, 8)
        }
        fun label(t: String) = android.widget.TextView(ctx).apply {
            text = t; setTextColor(0xFF888888.toInt()); textSize = 11f; setPadding(0, 8, 0, 2)
        }
        val spnToneMode = android.widget.Spinner(ctx).apply {
            adapter = android.widget.ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, toneModes)
            setSelection(when (curToneMode.orEmpty()) { "Tone" -> 1; "TSQL" -> 2; "DTCS" -> 3; else -> 0 })
        }
        val nearestToneIdx = ctcssTones.indices.minByOrNull { Math.abs(ctcssTones[it] - curToneHz) } ?: 7
        val spnToneHz = android.widget.Spinner(ctx).apply {
            adapter = android.widget.ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, toneLabels)
            setSelection(nearestToneIdx)
        }
        val spnOffsetDir = android.widget.Spinner(ctx).apply {
            adapter = android.widget.ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, offsetDirs)
            setSelection(when (curOffsetDir.orEmpty()) { "+" -> 1; "-" -> 2; else -> 0 })
        }
        val presetIdx = offsetPresets.indexOfFirst { it == curOffsetHz }.let { if (it <= 0) 0 else it }
        val spnOffsetPreset = android.widget.Spinner(ctx).apply {
            adapter = android.widget.ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, offsetLabels)
            setSelection(presetIdx)
        }
        val etOffsetKhz = android.widget.EditText(ctx).apply {
            hint = "Offset (kHz)"
            setText(if (curOffsetHz > 0) (curOffsetHz / 1000).toString() else "")
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        spnOffsetPreset.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                if (pos > 0) etOffsetKhz.setText((offsetPresets[pos] / 1000).toString())
            }
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
        }

        root.addView(label("Tone Mode")); root.addView(spnToneMode)
        root.addView(label("CTCSS/Tone (Hz)")); root.addView(spnToneHz)
        root.addView(label("Offset Direction")); root.addView(spnOffsetDir)
        root.addView(label("Offset Preset")); root.addView(spnOffsetPreset)
        root.addView(label("Offset (kHz)")); root.addView(etOffsetKhz)

        AlertDialog.Builder(ctx).setTitle("Repeater Settings")
            .setView(root)
            .setPositiveButton("Apply") { _, _ ->
                val toneMode = when (spnToneMode.selectedItemPosition) { 1 -> "Tone"; 2 -> "TSQL"; 3 -> "DTCS"; else -> "" }
                val toneHz   = if (toneMode.isNotEmpty()) ctcssTones[spnToneHz.selectedItemPosition] else 0.0
                val offsetDir = when (spnOffsetDir.selectedItemPosition) { 1 -> "+"; 2 -> "-"; else -> "" }
                val offsetHz = (etOffsetKhz.text.toString().toLongOrNull() ?: 0L) * 1000L
                vm.setRepeater(toneMode, toneHz, offsetDir, offsetHz)
            }
            .setNeutralButton("Clear") { _, _ -> vm.clearRepeater() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showFmDigitalSettings() {
        val modes = vm.supportedModes.value ?: emptyList()
        val model = vm.sharedModel.value ?: ""
        // 対応機(IC-705/9700)なら常に開く。supportedModesはrigctld再起動(方式3/ブリッジ)後の再接続で
        // 一時的にDSTARが抜けることがあり、それでFM長押しが死ぬとブリッジOFFにも辿れなくなるため。
        val dstarSupported = modes.any { it == "DSTAR" || it == "D-STAR" } ||
            model.contains("705") || model.contains("9700")
        // SSTVはFM対応機ならPi経由で使える。D-STAR非対応機(FT-991等)でもSSTVのためにダイアログを開く。
        val sstvAvail = vm.useCIV.value != true
        if (!dstarSupported && !sstvAvail) return

        val ctx = requireContext()
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 32, 56, 16)
        }
        val dlgRef = arrayOfNulls<AlertDialog>(1)
        var dstarCheck: CheckBox? = null
        if (dstarSupported) {
        root.addView(TextView(ctx).apply {
            text = "D-STAR"
            setTextColor(0xFF00FFFF.toInt())
            textSize = 14f
            setPadding(0, 8, 0, 4)
        })
        // 現在のルーティングを即座に見えるよう表示(設定・確認を開かなくても分かるように)。
        run {
            val cur = vm.dstarRouting.value
            val cUr = (cur?.first ?: vm.prefs.dstarUr).ifBlank { "-" }
            val cR1 = (cur?.second ?: vm.prefs.dstarR1)
            val cR2 = (cur?.third ?: vm.prefs.dstarR2)
            val nm = vm.prefs.dstarR1Name
            val simplex = cR1.isBlank() && cR2.isBlank()
            root.addView(TextView(ctx).apply {
                text = getString(R.string.main_control_46, vm.prefs.dstarSubMode) + " " +
                    (if (simplex) getString(R.string.main_control_47, cUr)
                     else (if (nm.isNotEmpty()) "$nm  " else "") + "UR=$cUr  R1=$cR1  R2=$cR2")
                setTextColor(0xFFFFD54F.toInt()); textSize = 13f; setPadding(0, 0, 0, 8)
            })
        }
        val chk = CheckBox(ctx).apply {
            text = "Include D-STAR in FM cycle"
            isChecked = vm.prefs.fmDstarEnabled
            setTextColor(0xFFDDDDDD.toInt())
        }
        dstarCheck = chk
        root.addView(chk)

        // D-STAR DR / Simplex entry (supported rigs only). Phase 1: switch the rig to D-STAR mode
        // (existing sendMode → works over both CI-V and Pi) and remember the chosen sub-mode; the
        // actual UR/R1/R2 CI-V configuration (1F 01) is wired in Phase 2. (AP/Terminal dropped.)
        root.addView(TextView(ctx).apply {
            text = getString(R.string.main_control_48, vm.prefs.dstarSubMode)
            setTextColor(0xFF00FFFF.toInt()); textSize = 14f; setPadding(0, 20, 0, 4)
        })
        val modeRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        fun enterDstar(sub: String, label: String) {
            vm.prefs.dstarSubMode = sub
            val civ = vm.useCIV.value == true
            val m = vm.sharedModel.value ?: ""
            // Pi接続+対応機+ブリッジ設定ONなら、D-STAR入室時に自動でCI-Vブリッジを張る(受信相手表示+PTT)。
            // 以降のモード/ルーティングはブリッジ経由。D-STAR以外へ切替時に自動でブリッジOFF(sendMode側)。
            val useBridge = !civ && vm.prefs.dstarCivBridge && (m.contains("705") || m.contains("9700"))
            val key = if (civ) "DSTAR" else "D-STAR"
            if (useBridge) {
                Toast.makeText(ctx, getString(R.string.main_control_49, label), Toast.LENGTH_SHORT).show()
                Thread {
                    if (!vm.dstarBridgeActive) vm.startDstarBridge()   // 背景(ブロッキング)
                    // sendMode/applyDstarRoutingはLiveData.setValueを使うのでメインスレッドで呼ぶ。
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        vm.sendMode(key, modeDefaultWidth(key))   // ブリッジ経由でDVモード
                        vm.applyDstarRouting(sub)                 // ブリッジ経由でルーティング
                    }
                }.start()
            } else {
                // モード設定とルーティングを順番に実行(Piの setmode と civ_raw の同時実行=競合を回避)。
                // 既にD-STARなら 06 17 を送らずR1/R2(1F 01)のみ(DRモード維持)。※R1/R2有効化はリグがDRモード時のみ。
                vm.enterDstarRouting(sub)
                Toast.makeText(ctx, getString(R.string.main_control_50, label) + (if (!civ) getString(R.string.main_control_51) else ""), Toast.LENGTH_SHORT).show()
            }
            dlgRef[0]?.dismiss()
        }
        modeRow.addView(android.widget.Button(ctx).apply {
            text = getString(R.string.main_control_52); setOnClickListener { enterDstar("DR", getString(R.string.main_control_52)) }
        })
        modeRow.addView(android.widget.Button(ctx).apply {
            text = getString(R.string.main_control_53); setOnClickListener { enterDstar("SIMPLEX", getString(R.string.main_control_53)) }
        })
        root.addView(modeRow)
        root.addView(android.widget.Button(ctx).apply {
            text = getString(R.string.main_control_54)
            setOnClickListener { dlgRef[0]?.dismiss(); showDstarSettings() }
        })
        }   // end if (dstarSupported)

        // SSTV 画像送信(FM/SSBで運用)。Pi経由のみ。モード選択→画像ピッカー→送信。
        if (vm.useCIV.value != true) {
            root.addView(TextView(ctx).apply {
                text = "SSTV 画像送信 (FM)"; setTextColor(0xFF00FFFF.toInt()); setPadding(0, 20, 0, 2)
            })
            root.addView(android.widget.Button(ctx).apply {
                text = "画像を選んで送信"
                setOnClickListener {
                    // 送信時間(≒画像サイズ/画質)で選択。短い=低負荷、長い=高画質。
                    val labels = arrayOf(
                        "Robot36  約36秒 (低負荷・標準)",
                        "Martin M2  約58秒",
                        "Scottie S2  約71秒",
                        "Scottie S1  約110秒",
                        "Martin M1  約114秒 (高画質)")
                    val modes = arrayOf("Robot36", "MartinM2", "ScottieS2", "ScottieS1", "MartinM1")
                    AlertDialog.Builder(ctx).setTitle("SSTVモード(送信時間)")
                        .setItems(labels) { _, w ->
                            sstvPendingMode = modes[w]
                            dlgRef[0]?.dismiss()
                            sstvImageLauncher.launch("image/*")
                        }
                        .setNegativeButton(getString(R.string.main_control_11), null).show()
                }
            })
            // SSTV 受信(デコード)
            // 受信状態のライブ表示(2秒ごと自動更新)。listening lvl=.. / decoding XX% / decoded.. が出る。
            val sstvStatusTv = TextView(ctx).apply {
                text = "受信状態: —"; setTextColor(0xFFFFD54F.toInt()); textSize = 12f; setPadding(0, 10, 0, 2)
            }
            root.addView(sstvStatusTv)
            viewLifecycleOwner.lifecycleScope.launch {
                kotlinx.coroutines.delay(300)   // dlgRef[0] 確定待ち
                while (dlgRef[0]?.isShowing == true) {
                    val (status, running, _) = vm.sstvFetchStatus()
                    if (running != null)   // 取得失敗(null)時は前回表示を維持し「停止」に化けさせない
                        sstvStatusTv.text = "受信状態: " + (if (running) "動作中" else "停止") + " / " + status
                    kotlinx.coroutines.delay(2000)
                }
            }
            val sstvRxRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            sstvRxRow.addView(android.widget.Button(ctx).apply {
                text = "受信開始"; setOnClickListener { vm.sstvRxStart() }
            })
            sstvRxRow.addView(android.widget.Button(ctx).apply {
                text = "受信停止"; setOnClickListener { vm.sstvRxStop() }
            })
            root.addView(sstvRxRow)
            root.addView(android.widget.Button(ctx).apply {
                text = "受信画像を見る"
                setOnClickListener { dlgRef[0]?.dismiss(); showSstvGallery() }
            })
        }

        dlgRef[0] = AlertDialog.Builder(ctx)
            .setTitle("D-STAR / FM Digital")
            .setView(root)
            .setPositiveButton("Save") { _, _ ->
                dstarCheck?.let { vm.prefs.fmDstarEnabled = it.isChecked }
                Toast.makeText(ctx, "Saved", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** GPS + imported CSV → show a nearest-D-STAR-repeater list (Japanese names) and call onPicked. */
    private fun pickDstarRepeater(onPicked: (DstarRepeater) -> Unit) {
        val ctx = requireContext()
        val csvFile = java.io.File(ctx.filesDir, "dstar_repeaters.csv")
        if (!csvFile.exists()) {
            Toast.makeText(ctx, getString(R.string.main_control_55), Toast.LENGTH_LONG).show(); return
        }
        ensureLocationPermission {
            Toast.makeText(ctx, getString(R.string.main_control_56), Toast.LENGTH_SHORT).show()
            GeoJcc.fetchLocation(requireContext(),
                { info -> Toast.makeText(ctx, info, Toast.LENGTH_LONG).show() },
                { lat, lon ->
                    Thread {
                        val list = GeoJcc.loadDstarCsvNearby(csvFile, lat, lon)
                        requireActivity().runOnUiThread {
                            if (list.isEmpty()) Toast.makeText(ctx, getString(R.string.main_control_57), Toast.LENGTH_LONG).show()
                            else AlertDialog.Builder(ctx).setTitle(getString(R.string.main_control_58))
                                .setItems(list.map { it.label }.toTypedArray()) { _, which -> onPicked(list[which]) }
                                .setNegativeButton(getString(R.string.main_control_11), null).show()
                        }
                    }.start()
                })
        }
    }

    /** 繋ぎ先(ゾーンコール)用: 現在地を無視して全レピータを検索付き一覧から選ぶ。 */
    private fun pickDstarRepeaterAll(onPicked: (DstarRepeater) -> Unit) {
        val ctx = requireContext()
        val csvFile = java.io.File(ctx.filesDir, "dstar_repeaters.csv")
        if (!csvFile.exists()) { Toast.makeText(ctx, getString(R.string.main_control_55), Toast.LENGTH_LONG).show(); return }
        Thread {
            val all = GeoJcc.loadDstarCsvAll(csvFile)
            requireActivity().runOnUiThread {
                if (all.isEmpty()) { Toast.makeText(ctx, getString(R.string.main_control_59), Toast.LENGTH_LONG).show(); return@runOnUiThread }
                fun lbl(r: DstarRepeater) = "%s  %s  %.4fMHz".format(r.r1.trim(), r.callsign, r.freqMHz)
                val search = EditText(ctx).apply { hint = getString(R.string.main_control_60); setTextColor(0xFFFFFFFF.toInt()) }
                val listView = android.widget.ListView(ctx)
                var filtered = all
                val adapter = android.widget.ArrayAdapter(ctx, android.R.layout.simple_list_item_1,
                    all.map { lbl(it) }.toMutableList())
                listView.adapter = adapter
                search.addTextChangedListener(object : android.text.TextWatcher {
                    override fun afterTextChanged(s: android.text.Editable?) {
                        val q = s?.toString()?.trim().orEmpty()
                        filtered = if (q.isEmpty()) all else all.filter {
                            it.callsign.contains(q, true) || it.r1.contains(q, true) || (it.r1Override ?: "").contains(q, true)
                        }
                        adapter.clear(); adapter.addAll(filtered.map { lbl(it) }); adapter.notifyDataSetChanged()
                    }
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                })
                val box = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL; setPadding(40, 16, 40, 8)
                    addView(search)
                    addView(listView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1100))
                }
                val dlg = AlertDialog.Builder(ctx).setTitle(getString(R.string.main_control_61)).setView(box)
                    .setNegativeButton(getString(R.string.main_control_11), null).create()
                listView.setOnItemClickListener { _, _, pos, _ -> if (pos in filtered.indices) { onPicked(filtered[pos]); dlg.dismiss() } }
                dlg.show()
            }
        }.start()
    }

    /** D-STAR UR/R1/R2 (DR routing) view+edit. "リグから読込" fetches the current values via CI-V
     *  (1F 01 read); "設定" writes them (1F 01) and reads back. CI-V = live; Pi = write-only. */
    private fun showDstarSettings() {
        val ctx = requireContext()
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setPadding(56, 16, 56, 8)
        }
        fun field(label: String, value: String): EditText {
            root.addView(TextView(ctx).apply {
                text = label; setTextColor(0xFF00FFFF.toInt()); setPadding(0, 14, 0, 2)
            })
            val e = EditText(ctx).apply {
                setText(value); setTextColor(0xFFFFFFFF.toInt())
                inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
                filters = arrayOf(android.text.InputFilter.AllCaps(), android.text.InputFilter.LengthFilter(8))
            }
            root.addView(e); return e
        }
        val eUr = field(getString(R.string.main_control_62), vm.prefs.dstarUr)
        val eR1 = field(getString(R.string.main_control_63), vm.prefs.dstarR1)
        val eR2 = field(getString(R.string.main_control_64), vm.prefs.dstarR2)
        // 選択中レピータの日本語名(CSVのName列)。レピータ選択で更新。
        val nameLabel = TextView(ctx).apply {
            val fromN = vm.prefs.dstarR1Name; val toN = vm.prefs.dstarUrName
            text = when {
                fromN.isNotEmpty() && toN.isNotEmpty() -> getString(R.string.main_control_65, fromN, toN)
                fromN.isNotEmpty() -> getString(R.string.main_control_66, fromN)
                else -> ""
            }
            setTextColor(0xFFFFD54F.toInt()); setPadding(0, 6, 0, 2); textSize = 15f
        }
        root.addView(nameLabel)

        // 近傍レピータ: CS-705形式CSV(RepeaterBook web export / Icom公式、トークン不要)をインポート→GPSで近い順に選ぶ。
        val csvFile = java.io.File(requireContext().filesDir, "dstar_repeaters.csv")
        root.addView(TextView(ctx).apply {
            text = getString(R.string.main_control_67, if (csvFile.exists()) getString(R.string.main_control_68, csvFile.length()) else getString(R.string.main_control_69))
            setTextColor(0xFF00FFFF.toInt()); setPadding(0, 18, 0, 2)
        })
        fun qsy(rep: DstarRepeater) {
            if (rep.freqMHz > 0) vm.sendFreq((rep.freqMHz * 1_000_000.0).toLong())
            // 無線設定(周波数/DUP方向/オフセット)+日本語名(CSVのName列)を保存。設定/メイン画面表示で使う。
            vm.setDstarRepeaterConfig(rep.freqMHz, rep.dupDir, rep.offsetHz, rep.callsign)
        }
        val urPresets = listOf(
            "CQCQCQ"   to getString(R.string.main_control_70),
            "       U" to getString(R.string.main_control_71),
            "       E" to getString(R.string.main_control_72),
            "       I" to getString(R.string.main_control_73))
        val row1 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(android.widget.Button(ctx).apply {
            text = getString(R.string.main_control_74); setOnClickListener { dstarCsvImportLauncher.launch("*/*") }
        })
        row1.addView(android.widget.Button(ctx).apply {
            text = getString(R.string.main_control_75)
            setOnClickListener {
                pickDstarRepeater { rep ->
                    eR1.setText(rep.r1.trim()); eR2.setText(rep.r2.trim()); qsy(rep)
                    nameLabel.text = getString(R.string.main_control_66, rep.callsign)
                    Toast.makeText(ctx, "%s  QSY %.4fMHz  R1=%s R2=%s".format(rep.callsign, rep.freqMHz, rep.r1.trim(), rep.r2.trim()), Toast.LENGTH_LONG).show()
                }
            }
        })
        root.addView(row1)
        val row2 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(android.widget.Button(ctx).apply {
            text = getString(R.string.main_control_76)
            setOnClickListener {
                AlertDialog.Builder(ctx).setTitle(getString(R.string.main_control_77))
                    .setItems(urPresets.map { it.second }.toTypedArray()) { _, w -> eUr.setText(urPresets[w].first) }
                    .setNegativeButton(getString(R.string.main_control_11), null).show()
            }
        })
        // 繋ぎ先レピータ(ゲートウェイ経由ゾーンコール)。別レピータへ繋ぐ: UR="/"+相手R1(空白除去)。
        // 例: 西東京(R1/R2)はそのまま、UR=/JP6YIKA で都城レピータへ。R1/R2は自分のアクセスレピータのまま。
        row2.addView(android.widget.Button(ctx).apply {
            text = getString(R.string.main_control_78)
            setOnClickListener {
                pickDstarRepeaterAll { rep ->   // 現在地無視・全件から選ぶ(繋ぎ先は遠方)
                    // ゾーンコールUR(8桁): "/" + レピータ基幹コール(6桁左詰) + モジュール(8桁目)。
                    // 例 JP6YIK A → /JP6YIKA、ZL2VH A → /ZL2VH A（モジュールは常に末尾)。
                    val base = rep.r1.take(6).trim()
                    val modCh = rep.r1.getOrNull(7)?.takeIf { it != ' ' }?.toString() ?: ""
                    val routed = ("/" + base.padEnd(6, ' ') + modCh).take(8)
                    eUr.setText(routed)
                    vm.prefs.dstarUrName = rep.callsign   // 繋ぎ先の日本語名を保存(表示用)
                    nameLabel.text = getString(R.string.main_control_65, vm.prefs.dstarR1Name, rep.callsign)
                    Toast.makeText(ctx, getString(R.string.main_control_79, rep.callsign, routed), Toast.LENGTH_LONG).show()
                }
            }
        })
        root.addView(row2)

        // 送信コールサイン(自局 MyCall) / 送信メッセージ
        root.addView(TextView(ctx).apply {
            text = getString(R.string.main_control_80); setTextColor(0xFF00FFFF.toInt()); setPadding(0, 18, 0, 2)
        })
        fun fieldN(label: String, value: String, maxLen: Int, caps: Boolean): EditText {
            root.addView(TextView(ctx).apply { text = label; setTextColor(0xFF00FFFF.toInt()); setPadding(0, 10, 0, 2) })
            val e = EditText(ctx).apply {
                setText(value); setTextColor(0xFFFFFFFF.toInt())
                inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    (if (caps) android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS else 0)
                filters = if (caps) arrayOf(android.text.InputFilter.AllCaps(), android.text.InputFilter.LengthFilter(maxLen))
                          else arrayOf(android.text.InputFilter.LengthFilter(maxLen))
            }
            root.addView(e); return e
        }
        val eMy = fieldN(getString(R.string.main_control_81), vm.prefs.dstarMyCall, 8, true)
        val eMsg = fieldN(getString(R.string.main_control_82), vm.prefs.dstarTxMessage, 20, false)
        val row3 = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        row3.addView(android.widget.Button(ctx).apply {
            text = getString(R.string.main_control_83)
            setOnClickListener { vm.setDstarMyCall(eMy.text.toString().trim(), "") }
        })
        row3.addView(android.widget.Button(ctx).apply {
            text = getString(R.string.main_control_84)
            setOnClickListener { vm.setDstarTxMessage(eMsg.text.toString()) }
        })
        root.addView(row3)

        // 対応機(IC-705/9700)+Pi接続時のみ: 生CI-Vブリッジ(遠隔フルCI-V)。ON=rigctld停止→アプリが
        // 直接CI-Vで喋る→受信コールのライブ表示/クリーンなDR設定。OFF=通常CAT(rigctld)へ復帰。
        val dModel = vm.sharedModel.value ?: ""
        val dstarSupported = dModel.contains("705") || dModel.contains("9700")
        if (dstarSupported && vm.useCIV.value != true) {
            val bridgeBtn = android.widget.Button(ctx)
            fun refreshBridge() {
                bridgeBtn.text = getString(R.string.main_control_85) + " " + if (vm.dstarBridgeActive) "ON ✓" else "OFF"
            }
            refreshBridge()
            bridgeBtn.setOnClickListener {
                val turnOn = !vm.dstarBridgeActive
                bridgeBtn.isEnabled = false
                bridgeBtn.text = if (turnOn) getString(R.string.main_control_86) else getString(R.string.main_control_87)
                Thread {
                    if (turnOn) { vm.prefs.dstarCivBridge = true; vm.startDstarBridge() }
                    else { vm.stopDstarBridge(); vm.prefs.dstarCivBridge = false }
                    bridgeBtn.post {
                        bridgeBtn.isEnabled = true; refreshBridge()
                        Toast.makeText(ctx, if (vm.dstarBridgeActive) getString(R.string.main_control_88) else getString(R.string.main_control_89), Toast.LENGTH_SHORT).show()
                    }
                }.start()
            }
            root.addView(bridgeBtn)
            root.addView(TextView(ctx).apply {
                text = getString(R.string.main_control_90)
                setTextColor(0xFF888888.toInt()); textSize = 11f; setPadding(0, 2, 0, 6)
            })
        }

        // Live update the fields when a read-back arrives, while the dialog is open.
        val obs = androidx.lifecycle.Observer<Triple<String, String, String>?> { rb ->
            if (rb != null) { eUr.setText(rb.first); eR1.setText(rb.second); eR2.setText(rb.third) }
        }
        vm.dstarRouting.observeForever(obs)

        val dlg = AlertDialog.Builder(ctx)
            .setTitle("D-STAR UR / R1 / R2")
            .setView(root)
            .setNeutralButton(getString(R.string.main_control_91), null)   // handler set in OnShow so it doesn't dismiss
            .setPositiveButton(getString(R.string.main_control_92)) { _, _ ->
                vm.setDstarCallSigns(eUr.text.toString().trim(), eR1.text.toString().trim(), eR2.text.toString().trim())
            }
            .setNegativeButton(getString(R.string.main_control_11), null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener { vm.readDstarCallSigns() }
        }
        dlg.setOnDismissListener { vm.dstarRouting.removeObserver(obs) }
        dlg.show()
    }

    private fun showCwKeyerSelectDialog() {
        val usbConnected = vm.cwUsbConnected.value ?: false
        val usbEnabled   = vm.cwUsbEnabled.value  ?: false
        val bleConnected = vm.cwBleConnected.value ?: false

        val usbLabel = when {
            usbConnected && usbEnabled -> "USB Keyer  [Active — tap to deactivate]"
            usbConnected               -> "USB Keyer  [Connected — tap to activate]"
            else                       -> "USB Keyer  [Not connected — scan]"
        }
        val bleLabel = when {
            bleConnected -> "BLE Keyer  [Connected — tap to disconnect]"
            else         -> "BLE Keyer  [Scan for device]"
        }

        AlertDialog.Builder(requireContext())
            .setTitle("CW Keyer")
            .setItems(arrayOf(usbLabel, bleLabel)) { _, which ->
                when (which) {
                    0 -> activateUsbKeyer()
                    1 -> (activity as? MainActivity)?.connectCwBt()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun activateUsbKeyer() {
        val connected = vm.cwUsbConnected.value ?: false
        if (connected) {
            val enable = !(vm.cwUsbEnabled.value ?: false)
            vm.setCwUsbEnabled(enable)
            if (enable) {
                val port = binding.tvCwUsbPort.text.toString()
                vm.prefs.cwPort = port
                lifecycleScope.launch(Dispatchers.IO) { api.cwOpen(port, 0) }
            } else {
                lifecycleScope.launch(Dispatchers.IO) { api.cwClose() }
            }
        } else {
            (activity as? MainActivity)?.scanUsbDevices()
            Toast.makeText(requireContext(), "Scanning USB devices...", Toast.LENGTH_SHORT).show()
        }
    }

    private suspend fun showCwPortDialog() {
        val currentPort = binding.tvCwUsbPort.text.toString()
        val serials = withContext(Dispatchers.IO) {
            api.getDevices().first
        }.ifEmpty { listOf("ttyUSB0", "ttyUSB1", "ttyUSB2", "ttyACM0") }

        val items = (serials + "Manual...").toTypedArray()
        var selectedIdx = serials.indexOf(currentPort).coerceAtLeast(0)

        AlertDialog.Builder(requireContext())
            .setTitle("Pi CW Port")
            .setSingleChoiceItems(items, selectedIdx) { _, which -> selectedIdx = which }
            .setPositiveButton("Set") { _, _ ->
                if (selectedIdx == items.size - 1) {
                    val edit = EditText(requireContext()).apply {
                        setText(currentPort)
                        hint = "e.g. ttyUSB2"
                    }
                    AlertDialog.Builder(requireContext())
                        .setTitle("Pi CW Port (manual)")
                        .setView(edit)
                        .setPositiveButton("Set") { _, _ ->
                            val port = edit.text.toString().trim().ifEmpty { currentPort }
                            applyCwPort(port)
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                } else {
                    applyCwPort(serials[selectedIdx])
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showCwBufferDialog() {
        val measuredMs = vm.cwMeasuredLatencyMs.value ?: 0
        val recommendedMs = if (measuredMs > 0) measuredMs + 200 else 0
        val edit = android.widget.EditText(requireContext()).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(vm.prefs.cwDelayMs.toString())
            hint = "0 (no delay)"
        }
        val measuredNote = if (measuredMs > 0)
            "\n\nMeasured: ${measuredMs}ms late\n→ Recommended: ${recommendedMs}ms"
        else
            "\n\n(No data yet. Key CW to measure latency.)"
        val dlg = AlertDialog.Builder(requireContext())
            .setTitle("VPN Buffer (ms)")
            .setMessage("Sidetone is always instant.\nOnly the CW RF signal is delayed by this value.\n0=instant\nLAN: 50~100ms\nVPN: measured+200ms${measuredNote}")
            .setView(edit)
            .setPositiveButton("Set") { _, _ ->
                val ms = edit.text.toString().toIntOrNull()?.coerceIn(0, 5000) ?: 0
                vm.prefs.cwDelayMs = ms
                vm.cwDelayMs.value = ms
                Toast.makeText(requireContext(), "VPN buffer: ${ms}ms", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
        if (recommendedMs > 0) {
            dlg.setNeutralButton("Recommended ${recommendedMs}ms") { _, _ ->
                vm.prefs.cwDelayMs = recommendedMs
                vm.cwDelayMs.value = recommendedMs
                Toast.makeText(requireContext(), "VPN buffer: ${recommendedMs}ms (recommended)", Toast.LENGTH_SHORT).show()
            }
        }
        dlg.show()
    }

    private fun updateCwTxButton() {
        val mode = vm.sharedMode.value ?: ""
        val isCwMode = mode.contains("CW", ignoreCase = true)
        val isFmMode = mode.contains("FM", ignoreCase = true)  // FM / FMN / PKTFM / D-STAR
                || mode.equals("DSTAR", ignoreCase = true) || mode.equals("D-STAR", ignoreCase = true)
        val busy = vm.cwTxBusy.value ?: false
        val color = when {
            busy     -> 0xFFFF6600.toInt()  // orange: sending
            isCwMode -> 0xFF004D40.toInt()  // teal: CW keyer
            isFmMode -> 0xFF1A237E.toInt()  // dark blue: FM-CW audio
            else     -> 0xFF1A1A1A.toInt()  // dark: inactive
        }
        val textColor = if (isCwMode || isFmMode || busy) 0xFFCCCCCC.toInt() else 0xFF555555.toInt()
        binding.btnCwTx.backgroundTintList = android.content.res.ColorStateList.valueOf(color)
        binding.btnCwTx.setTextColor(textColor)
        binding.btnCwTx.text = if (busy) "STOP\nCW" else "CW TX"
        val showOfs = isCwMode && vm.useCIV.value != true
        binding.llCwShift?.visibility = if (showOfs) View.VISIBLE else View.GONE
        if (!isCwMode && (vm.cwTxShiftHz.value ?: 0L) != 0L) {
            // CWモード解除: 基準周波数へVFOを戻してからシフトをクリア
            val base = vm.cwBaseFreqHz
            if (base != 0L) vm.sendFreq(base)
            vm.setCwTxShift(0L)
        }
        if (isCwMode && !wasCwMode && (vm.cwTxShiftHz.value ?: 0L) != 0L) vm.applySavedCwShift()
        wasCwMode = isCwMode
    }

    // CW TX sheet: text-only phrase line stays in cwSheetRxView; dit/dah+char block is a separate
    // view below it, shown only when enabled.
    private fun refreshCwSheetMorse() {
        cwSheetRxView?.text = android.text.SpannableStringBuilder("RX: ").append(vm.cwRxTexts[0].value ?: "")
        cwSheetRxScroll?.post { cwSheetRxScroll?.fullScroll(android.view.View.FOCUS_RIGHT) }
        val on = vm.cwShowMorse.value == true
        cwSheetMorseScroll?.visibility = if (on) View.VISIBLE else View.GONE
        cwSheetMorseView?.text = vm.cwRxMorse.value ?: ""
        if (on) cwSheetMorseScroll?.post { cwSheetMorseScroll?.fullScroll(android.view.View.FOCUS_RIGHT) }
    }

    private fun showCwTxPanel() {
        val ctx = requireContext()
        val sheet = BottomSheetDialog(ctx)
        cwTxSheet = sheet

        // 横向きの layout-land/dialog_cw_tx は参照ビューが一部欠落しておりクラッシュするため、
        // 常に portrait レイアウトを使う(ルートが ScrollView なので横でもスクロール表示できる)。
        val portraitCfg = android.content.res.Configuration(resources.configuration).apply {
            orientation = android.content.res.Configuration.ORIENTATION_PORTRAIT
        }
        val portraitCtx = ctx.createConfigurationContext(portraitCfg)
        val v = LayoutInflater.from(portraitCtx).inflate(R.layout.dialog_cw_tx, null)
        sheet.setContentView(v)

        fun <T : android.view.View> id(resId: Int): T = v.findViewById(resId)

        val seekWpm      = id<android.widget.SeekBar>(R.id.seekCwWpm)
        val tvWpmLbl     = id<android.widget.TextView>(R.id.tvCwWpmLabel)
        val swPaddleSwap = id<android.widget.Switch>(R.id.switchPaddleSwap)
        val swPttPoll    = id<android.widget.Switch>(R.id.switchPttPoll)
        val tvMyCall     = id<android.widget.TextView>(R.id.tvCwMyCall)
        val etDxCall     = id<EditText>(R.id.etCwDxCall)
        val btnDxClear   = id<android.widget.Button>(R.id.btnCwDxClear)
        val etRst        = id<EditText>(R.id.etCwRst)
        val btnRstClear  = id<android.widget.Button>(R.id.btnCwRstClear)
        val etMyRst      = id<EditText>(R.id.etCwMyRst)
        val btnMyRstClear = id<android.widget.Button>(R.id.btnCwMyRstClear)
        val btnRstR1     = id<android.widget.Button>(R.id.btnRstR1)
        val btnRstR2     = id<android.widget.Button>(R.id.btnRstR2)
        val btnRstR3     = id<android.widget.Button>(R.id.btnRstR3)
        // ASCII filter for DX callsign — blocks full-width chars, auto-uppercase
        etDxCall.filters = arrayOf(android.text.InputFilter { source, _, _, _, _, _ ->
            source.toString().uppercase()
                .filter { it.isLetter() && it.code < 128 || it.isDigit() && it.code < 128 || it == '/' }
        })
        // DX RST preset buttons (519-599, by LinearLayout children)
        val rstVals = listOf("5NN","519","529","539","549","559","569","579","589","599")
        id<android.widget.LinearLayout>(R.id.llCwRstPresets).let { ll ->
            rstVals.forEachIndexed { i, v -> (ll.getChildAt(i) as? android.widget.Button)?.setOnClickListener { etRst.setText(v) } }
        }
        // My RST preset buttons
        id<android.widget.LinearLayout>(R.id.llCwMyRstPresets).let { ll ->
            rstVals.forEachIndexed { i, v -> (ll.getChildAt(i) as? android.widget.Button)?.setOnClickListener { etMyRst.setText(v) } }
        }
        val etPota       = id<EditText>(R.id.etCwPota)
        val btnPotaClear = id<android.widget.Button>(R.id.btnCwPotaClear)
        val etJcc        = id<EditText>(R.id.etCwJcc)
        val btnJccClear  = id<android.widget.Button>(R.id.btnCwJccClear)
        val btnTabCq     = id<android.widget.Button>(R.id.btnTabCq)
        val btnTabAns    = id<android.widget.Button>(R.id.btnTabAns)
        val indCq        = id<android.view.View>(R.id.viewTabIndCq)
        val indAns       = id<android.view.View>(R.id.viewTabIndAns)
        val panelCq      = id<android.widget.LinearLayout>(R.id.panelCq)
        val panelAns     = id<android.widget.LinearLayout>(R.id.panelAns)
        // CQ settings toggles
        val btnCqR1       = id<android.widget.Button>(R.id.btnCqR1)
        val btnCqR2       = id<android.widget.Button>(R.id.btnCqR2)
        val btnCqR3       = id<android.widget.Button>(R.id.btnCqR3)
        val btnCqTogPota  = id<android.widget.Button>(R.id.btnCqTogPota)
        val btnCqTogJcc   = id<android.widget.Button>(R.id.btnCqTogJcc)
        // CQ preset buttons
        val btnCwCq       = id<android.widget.Button>(R.id.btnCwCq)
        val btnCwCqDxK    = id<android.widget.Button>(R.id.btnCwCqDxK)
        val btnCwCall     = id<android.widget.Button>(R.id.btnCwCall)
        val btnCwCqTu     = id<android.widget.Button>(R.id.btnCwCqTu)
        val btnCwCqAgn    = id<android.widget.Button>(R.id.btnCwCqAgn)
        val btnCwCqUr     = id<android.widget.Button>(R.id.btnCwCqUr)
        // CQ greeting
        val btnCqGrNone   = id<android.widget.Button>(R.id.btnCqGrNone)
        val btnCqGrGm     = id<android.widget.Button>(R.id.btnCqGrGm)
        val btnCqGrGe     = id<android.widget.Button>(R.id.btnCqGrGe)
        val btnCqGrGa     = id<android.widget.Button>(R.id.btnCqGrGa)
        val btnCqQslNone  = id<android.widget.Button>(R.id.btnCqQslNone)
        val btnCqQslPse   = id<android.widget.Button>(R.id.btnCqQslPse)
        val btnCqQslNo    = id<android.widget.Button>(R.id.btnCqQslNo)
        // CQ repeat controls
        val btnCqLoop3    = id<android.widget.Button>(R.id.btnCqLoop3)
        val btnCqLoop5    = id<android.widget.Button>(R.id.btnCqLoop5)
        val btnCqLoop10   = id<android.widget.Button>(R.id.btnCqLoop10)
        val btnCqLoopInf  = id<android.widget.Button>(R.id.btnCqLoopInf)
        val btnCqInt10    = id<android.widget.Button>(R.id.btnCqInt10)
        val btnCqInt15    = id<android.widget.Button>(R.id.btnCqInt15)
        val btnCqInt30    = id<android.widget.Button>(R.id.btnCqInt30)
        val btnCqInt60    = id<android.widget.Button>(R.id.btnCqInt60)
        val tvCqStatus    = id<android.widget.TextView>(R.id.tvCqRepeatStatus)
        val btnCqRepeat   = id<android.widget.Button>(R.id.btnCqRepeat)
        // ANS settings toggles
        val btnAnsGrNone  = id<android.widget.Button>(R.id.btnAnsGrNone)
        val btnAnsGrGm    = id<android.widget.Button>(R.id.btnAnsGrGm)
        val btnAnsGrGe    = id<android.widget.Button>(R.id.btnAnsGrGe)
        val btnAnsGrGa    = id<android.widget.Button>(R.id.btnAnsGrGa)
        val btnAnsTogPota = id<android.widget.Button>(R.id.btnAnsTogPota)
        val btnAnsTogJcc  = id<android.widget.Button>(R.id.btnAnsTogJcc)
        // QSL toggles
        val btnQslNone    = id<android.widget.Button>(R.id.btnQslNone)
        val btnQslPse     = id<android.widget.Button>(R.id.btnQslPse)
        val btnQslTnx     = id<android.widget.Button>(R.id.btnQslTnx)
        val btnCwGrid     = id<android.widget.Button>(R.id.btnCwGrid)
        // ANS preset buttons
        val btnCwAnsCall  = id<android.widget.Button>(R.id.btnCwAnsCall)
        val btnCwAnsDE    = id<android.widget.Button>(R.id.btnCwAnsDE)
        val btnCwUr       = id<android.widget.Button>(R.id.btnCwUr)
        val btnCwTu       = id<android.widget.Button>(R.id.btnCwTu)
        val btnCwAgn      = id<android.widget.Button>(R.id.btnCwAgn)
        // NR level
        val btnNrOff = id<android.widget.Button>(R.id.btnCwNrOff)
        val btnNr1   = id<android.widget.Button>(R.id.btnCwNr1)
        val btnNr2   = id<android.widget.Button>(R.id.btnCwNr2)
        val btnNr3   = id<android.widget.Button>(R.id.btnCwNr3)
        val btnNr4   = id<android.widget.Button>(R.id.btnCwNr4)
        val btnNr5   = id<android.widget.Button>(R.id.btnCwNr5)
        val nrButtons = listOf(btnNrOff, btnNr1, btnNr2, btnNr3, btnNr4, btnNr5)

        // Free text
        val etFree        = id<EditText>(R.id.etCwFreeText)
        val btnSend       = id<android.widget.Button>(R.id.btnCwSend)
        val btnStop       = id<android.widget.Button>(R.id.btnCwSheetStop)

        cwSheetStopBtn    = btnStop
        cwSheetMsgButtons = emptyList()

        val tvCwFreqDisplay  = id<android.widget.TextView>(R.id.tvCwFreqDisplay)
        val btnCwFreqDown    = id<android.widget.Button>(R.id.btnCwFreqDown)
        val btnCwFreqUp      = id<android.widget.Button>(R.id.btnCwFreqUp)
        val tvCwPanelRx      = id<android.widget.TextView>(R.id.tvCwPanelRx)
        val hsvCwPanelRx     = id<android.widget.HorizontalScrollView>(R.id.hsvCwPanelRx)
        val tvCwPanelTx      = id<android.widget.TextView>(R.id.tvCwPanelTx)
        val hsvCwPanelTx     = id<android.widget.HorizontalScrollView>(R.id.hsvCwPanelTx)
        val tvCwShiftDisplay = id<android.widget.TextView>(R.id.tvCwShiftDisplay)
        cwSheetFreqView  = tvCwFreqDisplay
        cwSheetShiftView = tvCwShiftDisplay
        cwSheetRxView    = tvCwPanelRx
        cwSheetRxScroll  = hsvCwPanelRx
        cwSheetTxView    = tvCwPanelTx
        cwSheetTxScroll  = hsvCwPanelTx
        cwSheetMorseView  = id<android.widget.TextView>(R.id.tvCwPanelMorse)
        cwSheetMorseScroll = id<android.widget.HorizontalScrollView>(R.id.hsvCwPanelMorse)
        // Initialise the TX (sent-CW) decode field now (the observer only fires on change), so the field is
        // visible as soon as the CW TX panel opens — it shows "TX:" and the current sent text if any.
        val curTx = vm.cwTxText.value.orEmpty()
        tvCwPanelTx.text = if (curTx.isEmpty()) "TX:" else "TX: $curTx"
        hsvCwPanelTx.visibility = View.VISIBLE
        // Long-press the sheet RX area to toggle dit/dah display (same as the main screen).
        val toggleMorse = View.OnLongClickListener {
            if (vm.cwDecoding.value != true) return@OnLongClickListener false
            vm.toggleCwShowMorse()
            true
        }
        hsvCwPanelRx.setOnLongClickListener(toggleMorse)
        tvCwPanelRx.isLongClickable = true
        tvCwPanelRx.setOnLongClickListener(toggleMorse)
        // ── DX callsign Morse (dit/dah) send-preview, shown below the DX field ──
        val tvCwDxMorse = id<android.widget.TextView>(R.id.tvCwDxMorse)
        fun morseOfCall(call: String): String =
            call.trim().uppercase()
                .mapNotNull { ch -> com.ji1ore.wifi_rig_ctrl.data.CwDecoder.CHAR_TO_MORSE[ch] }
                .joinToString("  ")   // two spaces between letters for readability
        fun refreshDxMorse() {
            val m = morseOfCall(etDxCall.text.toString())
            tvCwDxMorse.text = m
            if (m.isEmpty()) return
            // Fit the Morse to the ACTUAL available width: use the largest size (≤18sp) whose measured
            // width fits one line, so a long call (e.g. with /1) fills the row to the right edge and only
            // shrinks when it truly must. Measured after layout so the real width is known.
            tvCwDxMorse.post {
                val avail = (tvCwDxMorse.width - tvCwDxMorse.paddingLeft - tvCwDxMorse.paddingRight).toFloat()
                if (avail <= 0f) return@post
                val density = tvCwDxMorse.resources.displayMetrics.scaledDensity
                val paint = android.graphics.Paint(tvCwDxMorse.paint)
                var size = 18f
                while (size > 6f) {
                    paint.textSize = size * density
                    if (paint.measureText(m) <= avail) break
                    size -= 0.5f
                }
                tvCwDxMorse.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, size)
            }
        }
        etDxCall.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { refreshDxMorse() }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        refreshDxMorse()
        // ── Double-tap a callsign-like token in the RX decode → copy it into the DX field ──
        fun looksLikeCallsign(w: String): Boolean {
            val t = w.trim('/').trim()
            if (t.length !in 3..10) return false
            if (!t.all { it.isLetterOrDigit() || it == '/' }) return false
            return t.any { it.isDigit() } && t.any { it.isLetter() }   // ham calls mix letters+digits
        }
        val rxTapDetector = android.view.GestureDetector(ctx, object : android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: android.view.MotionEvent): Boolean {
                val s = tvCwPanelRx.text?.toString() ?: return false
                if (s.isEmpty()) return false
                val off = tvCwPanelRx.getOffsetForPosition(e.x, e.y).coerceIn(0, s.length)
                var a = off; while (a > 0 && !s[a - 1].isWhitespace()) a--
                var b = off; while (b < s.length && !s[b].isWhitespace()) b++
                val word = s.substring(a, b).trim().trimEnd(':').uppercase()
                if (looksLikeCallsign(word)) {
                    etDxCall.setText(word)                 // fires watchers → DX morse + prefs persist
                    etDxCall.setSelection(etDxCall.text.length)
                    android.widget.Toast.makeText(ctx, "DX ← $word", android.widget.Toast.LENGTH_SHORT).show()
                }
                return true
            }
        })
        tvCwPanelRx.setOnTouchListener { _, ev -> rxTapDetector.onTouchEvent(ev); false }
        refreshCwSheetMorse()   // open in the current mode
        cwSheetSmeter      = id<android.widget.ProgressBar>(R.id.pbCwSmeter)
        cwSheetSmeterLabel = id<android.widget.TextView>(R.id.tvCwSmeter)
        populateCwSmeterTicks(id<android.widget.LinearLayout>(R.id.llCwSmeterTicks))
        updateSMeter(vm.sharedSignal.value ?: 0f)   // 現在値で初期表示

        // SPK トグル(戻るの横 / 横画面はタイトル行)。メイン画面の btnSpk と同じ挙動。
        cwSheetSpkBtn = id<android.widget.Button>(R.id.btnCwSpk)
        refreshCwSheetSpk()
        cwSheetSpkBtn?.setOnClickListener {
            if (vm.txEnabled.value == true) return@setOnClickListener
            val on = !(vm.spkEnabled.value ?: false)
            vm.spkEnabled.value = on
            if (vm.useCIV.value == true) {
                vm.civSetSpk(on)
            } else {
                val sampRate = SAMPLING_RATES.getOrElse(vm.selectedSamplingIndex.value ?: 2) { 0 }
                if (sampRate == 0) {
                    Toast.makeText(requireContext(), "Sampling rate=OFF", Toast.LENGTH_SHORT).show()
                    vm.spkEnabled.value = false; return@setOnClickListener
                }
                if (on) vm.startAudio() else vm.stopAudio()
            }
            refreshCwSheetSpk()
        }

        // 初期値を反映
        val initFreqHz = vm.sharedFreq.value ?: 0L
        val initShiftHz = vm.cwTxShiftHz.value ?: 0L
        val isCivSheet = vm.useCIV.value == true
        tvCwFreqDisplay.text = "%.5f".format(initFreqHz / 1_000_000.0)
        if (!isCivSheet && initShiftHz != 0L) {
            tvCwShiftDisplay.text = "TX OFS: ${formatShiftHz(initShiftHz)}"
            tvCwShiftDisplay.visibility = View.VISIBLE
        } else {
            tvCwShiftDisplay.visibility = View.GONE
        }
        val ofsVis = if (isCivSheet) View.GONE else View.VISIBLE
        btnCwFreqDown.visibility = ofsVis
        btnCwFreqUp.visibility   = ofsVis
        tvCwPanelRx.text = android.text.SpannableStringBuilder("RX: ").append(vm.cwRxTexts[0].value ?: "")
        tvCwPanelTx.text = vm.cwTxText.value?.let { if (it.isEmpty()) "" else "TX: $it" } ?: ""
        val decodeVis = if (vm.cwDecoding.value == true) View.VISIBLE else View.GONE
        hsvCwPanelRx.visibility = decodeVis
        hsvCwPanelTx.visibility = decodeVis

        // 周波数タップ → 入力ダイアログ
        tvCwFreqDisplay.setOnClickListener {
            val et = android.widget.EditText(ctx).apply {
                setText("%.5f".format((vm.sharedFreq.value ?: 0L) / 1_000_000.0))
                inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                selectAll()
            }
            android.app.AlertDialog.Builder(ctx)
                .setTitle("Frequency (MHz)")
                .setView(et)
                .setPositiveButton("OK") { _, _ ->
                    val hz = (et.text.toString().toDoubleOrNull() ?: return@setPositiveButton) * 1_000_000
                    vm.sendFreq(hz.toLong())
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        // 周波数長押し → MEMSET(メモリーダイアログ)。メイン画面の tvFreq 長押しと同じ挙動。
        tvCwFreqDisplay.setOnLongClickListener {
            if (vm.txEnabled.value == true) return@setOnLongClickListener true
            showMemoryPanel()
            true
        }
        // ◀/▶ TX SHIFTのみ(RX変化なし)、短押し±step、長押し±step*10
        btnCwFreqDown.setOnClickListener     { val s = vm.prefs.cwShiftStep.toLong(); vm.setCwTxShift((vm.cwTxShiftHz.value ?: 0L) - s) }
        btnCwFreqDown.setOnLongClickListener { val s = vm.prefs.cwShiftStep.toLong() * 10L; vm.setCwTxShift((vm.cwTxShiftHz.value ?: 0L) - s); true }
        btnCwFreqUp.setOnClickListener       { val s = vm.prefs.cwShiftStep.toLong(); vm.setCwTxShift((vm.cwTxShiftHz.value ?: 0L) + s) }
        btnCwFreqUp.setOnLongClickListener   { val s = vm.prefs.cwShiftStep.toLong() * 10L; vm.setCwTxShift((vm.cwTxShiftHz.value ?: 0L) + s); true }

        // MY callsign
        val myCall = vm.prefs.ft8MyCall.ifEmpty { vm.prefs.aprsCallsign }
        tvMyCall.text = if (myCall.isNotEmpty()) myCall else "(not set)"

        // Input field values
        etDxCall.setText(vm.pendingLogCallsign.ifEmpty { vm.prefs.cwDxCall })
        cwSheetDxCall = etDxCall   // MEMSETスポット選択時にコールを反映できるよう保持
        btnDxClear.setOnClickListener   { etDxCall.setText("") }
        btnRstClear.setOnClickListener   { etRst.setText("") }
        btnMyRstClear.setOnClickListener { etMyRst.setText("") }
        btnPotaClear.setOnClickListener  { etPota.setText("") }
        btnJccClear.setOnClickListener  { etJcc.setText("") }
        etRst.setText(vm.prefs.cwRst.ifEmpty { "599" })
        etPota.setText(vm.prefs.cwPota)
        etJcc.setText(vm.prefs.cwJcc)

        // WPM
        val initWpm = (vm.cwWpm.value ?: vm.prefs.cwWpm).coerceIn(5, 60)
        seekWpm.progress = initWpm - 5
        tvWpmLbl.text = "$initWpm WPM"
        seekWpm.max = 55
        seekWpm.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar, p: Int, fromUser: Boolean) {
                tvWpmLbl.text = "${p + 5} WPM"
            }
            override fun onStartTrackingTouch(sb: android.widget.SeekBar) {}
            // CI-V: updateCwWpm() pushes setKeySpeed so the slider applies to the rig immediately.
            override fun onStopTrackingTouch(sb: android.widget.SeekBar) { vm.updateCwWpm(sb.progress + 5) }
        })
        swPaddleSwap.isChecked = vm.prefs.cwPaddleSwap
        swPaddleSwap.setOnCheckedChangeListener { _, c -> vm.updatePaddleSwap(c) }
        swPttPoll.isChecked = vm.cwPttPoll.value ?: false
        swPttPoll.setOnCheckedChangeListener { _, c -> vm.updateCwPttPoll(c) }

        // NR level buttons
        fun updateNrHighlights() {
            val level = vm.noiseReductionLevel.value ?: 0
            nrButtons.forEachIndexed { idx, btn ->
                val active = idx == level
                btn.backgroundTintList = ColorStateList.valueOf(
                    if (active) 0xFF6A1B9A.toInt() else 0xFF333333.toInt()
                )
                btn.setTextColor(if (active) 0xFFEEEEEE.toInt() else 0xFF888888.toInt())
            }
        }
        updateNrHighlights()
        nrButtons.forEachIndexed { idx, btn ->
            btn.setOnClickListener {
                vm.setNoiseReduction(idx)
                updateNrHighlights()
            }
        }

        // ── CQ/ANS pattern state ──
        var cqRepeat     = vm.prefs.cwCqRepeat
        var cqPota       = vm.prefs.cwCqPota
        var cqJcc        = vm.prefs.cwCqJcc
        var ansGreet     = vm.prefs.cwAnsGreeting
        var ansPota      = vm.prefs.cwAnsPota
        var ansJcc       = vm.prefs.cwAnsJcc
        var ansGrid      = vm.prefs.cwAnsGrid
        var qsl          = vm.prefs.cwQsl
        var cqLoopCount  = vm.prefs.cwCqLoopCount    // 0=∞
        var cqLoopInterv = vm.prefs.cwCqLoopInterval
        var rstRepeat    = vm.prefs.cwRstRepeat

        // Input helpers
        fun getWpm()  = (seekWpm.progress + 5).coerceIn(5, 60)
        fun my()      = myCall
        fun dx()      = etDxCall.text.toString().trim().uppercase()
        fun rst()     = etRst.text.toString().trim().ifEmpty { "599" }
        fun pota()    = etPota.text.toString().trim().uppercase()
        fun jcc()     = etJcc.text.toString().trim()

        fun saveAll() {
            vm.prefs.cwDxCall        = dx()
            vm.prefs.cwRst           = rst()
            vm.prefs.cwPota          = pota()
            vm.prefs.cwJcc           = jcc()
            vm.prefs.cwCqRepeat      = cqRepeat
            vm.prefs.cwCqPota        = cqPota
            vm.prefs.cwCqJcc         = cqJcc
            vm.prefs.cwAnsGreeting   = ansGreet
            vm.prefs.cwAnsPota       = ansPota
            vm.prefs.cwAnsJcc        = ansJcc
            vm.prefs.cwAnsGrid       = ansGrid
            vm.prefs.cwQsl           = qsl
            vm.prefs.cwCqLoopCount   = cqLoopCount
            vm.prefs.cwCqLoopInterval= cqLoopInterv
            vm.prefs.cwRstRepeat     = rstRepeat
        }

        fun send(text: String) {
            saveAll()
            val w = getWpm(); vm.updateCwWpm(w); vm.sendCwText(text, w)
        }

        // ── Toggle highlight helpers ──
        val COL_ON_GREEN  = 0xFF1A5C30.toInt()
        val COL_ON_AMBER  = 0xFF5C3A10.toInt()
        val COL_ON_BLUE   = 0xFF1A3A5C.toInt()
        val COL_OFF       = 0xFF333333.toInt()
        val TXT_ON        = 0xFFEEEEEE.toInt()
        val TXT_OFF       = 0xFF888888.toInt()

        fun hilite(btn: android.widget.Button, on: Boolean, onColor: Int = COL_ON_GREEN) {
            btn.backgroundTintList = ColorStateList.valueOf(if (on) onColor else COL_OFF)
            btn.setTextColor(if (on) TXT_ON else TXT_OFF)
        }

        fun refreshCqToggles() {
            hilite(btnCqR1, cqRepeat == 1, COL_ON_GREEN)
            hilite(btnCqR2, cqRepeat == 2, COL_ON_GREEN)
            hilite(btnCqR3, cqRepeat == 3, COL_ON_GREEN)
            hilite(btnCqTogPota, cqPota, COL_ON_AMBER)
            hilite(btnCqTogJcc,  cqJcc,  COL_ON_BLUE)
        }
        fun refreshRstRepeat() {
            hilite(btnRstR1, rstRepeat == 1, COL_ON_GREEN)
            hilite(btnRstR2, rstRepeat == 2, COL_ON_GREEN)
            hilite(btnRstR3, rstRepeat == 3, COL_ON_GREEN)
        }
        fun refreshGreetToggles() {
            // ANS greeting
            hilite(btnAnsGrNone, ansGreet == "",   COL_ON_GREEN)
            hilite(btnAnsGrGm,   ansGreet == "GM", COL_ON_GREEN)
            hilite(btnAnsGrGe,   ansGreet == "GE", COL_ON_GREEN)
            hilite(btnAnsGrGa,   ansGreet == "GA", COL_ON_GREEN)
            // CQ greeting (same state)
            hilite(btnCqGrNone, ansGreet == "",   COL_ON_GREEN)
            hilite(btnCqGrGm,   ansGreet == "GM", COL_ON_GREEN)
            hilite(btnCqGrGe,   ansGreet == "GE", COL_ON_GREEN)
            hilite(btnCqGrGa,   ansGreet == "GA", COL_ON_GREEN)
        }
        fun refreshAnsToggles() {
            hilite(btnAnsTogPota, ansPota, COL_ON_AMBER)
            hilite(btnAnsTogJcc,  ansJcc,  COL_ON_BLUE)
            hilite(btnCwGrid,     ansGrid, COL_ON_GREEN)
            hilite(btnQslNone, qsl == "",        COL_ON_GREEN)
            hilite(btnQslPse,  qsl == "PSE QSL", COL_ON_AMBER)
            hilite(btnQslTnx,  qsl == "NO QSL",  COL_ON_GREEN)
            hilite(btnCqQslNone, qsl == "",        COL_ON_GREEN)
            hilite(btnCqQslPse,  qsl == "PSE QSL", COL_ON_AMBER)
            hilite(btnCqQslNo,   qsl == "NO QSL",  COL_ON_GREEN)
        }
        fun refreshLoopToggles() {
            hilite(btnCqLoop3,   cqLoopCount == 3,  COL_ON_GREEN)
            hilite(btnCqLoop5,   cqLoopCount == 5,  COL_ON_GREEN)
            hilite(btnCqLoop10,  cqLoopCount == 10, COL_ON_GREEN)
            hilite(btnCqLoopInf, cqLoopCount == 0,  COL_ON_GREEN)
            hilite(btnCqInt10, cqLoopInterv == 10, COL_ON_BLUE)
            hilite(btnCqInt15, cqLoopInterv == 15, COL_ON_BLUE)
            hilite(btnCqInt30, cqLoopInterv == 30, COL_ON_BLUE)
            hilite(btnCqInt60, cqLoopInterv == 60, COL_ON_BLUE)
        }
        fun updateRepeatButton() {
            val repeating = vm.cwCqRepeating.value == true
            val status    = vm.cwCqRepeatStatus.value ?: ""
            tvCqStatus.text = status
            if (repeating) {
                btnCqRepeat.text = "■ STOP REPEAT"
                btnCqRepeat.backgroundTintList = ColorStateList.valueOf(0xFF7A1A1A.toInt())
            } else {
                btnCqRepeat.text = "▶ CQ REPEAT"
                btnCqRepeat.backgroundTintList = ColorStateList.valueOf(0xFF1A5C2A.toInt())
            }
        }

        // ── Tab switching ──
        val TAB_ACTIVE_IND = 0xFF4499FF.toInt()
        val TAB_INACTIVE_IND = 0xFF333333.toInt()
        fun showCqTab() {
            panelCq.visibility  = android.view.View.VISIBLE
            panelAns.visibility = android.view.View.GONE
            btnTabCq.backgroundTintList  = ColorStateList.valueOf(0xFF222222.toInt())
            btnTabCq.setTextColor(0xFFFFFFFF.toInt())
            btnTabAns.backgroundTintList = ColorStateList.valueOf(0xFF222222.toInt())
            btnTabAns.setTextColor(0xFF666666.toInt())
            indCq.setBackgroundColor(TAB_ACTIVE_IND)
            indAns.setBackgroundColor(TAB_INACTIVE_IND)
        }
        fun showAnsTab() {
            panelCq.visibility  = android.view.View.GONE
            panelAns.visibility = android.view.View.VISIBLE
            btnTabCq.backgroundTintList  = ColorStateList.valueOf(0xFF222222.toInt())
            btnTabCq.setTextColor(0xFF666666.toInt())
            btnTabAns.backgroundTintList = ColorStateList.valueOf(0xFF222222.toInt())
            btnTabAns.setTextColor(0xFFFFFFFF.toInt())
            indCq.setBackgroundColor(TAB_INACTIVE_IND)
            indAns.setBackgroundColor(TAB_ACTIVE_IND)
        }
        showCqTab()
        btnTabCq.setOnClickListener  { showCqTab() }
        btnTabAns.setOnClickListener { showAnsTab() }

        // ── updateLabels: assembles messages + enables/disables ──
        fun updateLabels() {
            val m = my(); val d = dx(); val r = rst(); val p = pota(); val j = jcc()
            val myOk = m.isNotEmpty(); val dOk = d.isNotEmpty()
            val pOk  = p.isNotEmpty(); val jOk  = j.isNotEmpty()
            val busy = vm.cwTxBusy.value == true
            val mDisp = if (myOk) m else getString(R.string.main_control_96)
            val dDisp = if (dOk) d else getString(R.string.main_control_97)

            // CQ assembled: POTA and JCC both go AFTER callsign
            val callPart = (1..cqRepeat).joinToString(" ") { mDisp }
            val cqPostExtra = buildString {
                if (cqPota && pOk) append(" POTA $p")
                if (cqJcc  && jOk) append(" JCC $j")
            }
            btnCwCq.text = "CQ CQ CQ DE $callPart$cqPostExtra K"
            btnCwCqDxK.text = "$dDisp K"
            btnCwCall.text = "$dDisp DE $mDisp K"
            btnCwCqTu.text = "TU TU 73 E E"

            // ANS assembled messages — greeting goes into UR (not DE)
            val greetPfx = if (ansGreet.isNotEmpty()) "$ansGreet " else ""
            btnCwAnsCall.text = "$mDisp K"
            btnCwAnsDE.text   = "$dDisp DE $mDisp K"
            val urExtra = buildString {
                if (ansPota && pOk) append(" POTA $p")
                if (ansJcc  && jOk) append(" JCC $j")
            }
            val rstPart = (1..rstRepeat).joinToString(" ") { r }
            val qslInUr = if (qsl.isNotEmpty()) " $qsl" else ""
            // ANS GL トグル: RST の直後に自局グリッドを「/付き」で付加 (例 "/PM95")。設定の自局グリッドを使用
            val gridVal = vm.prefs.ft8MyGrid.trim().uppercase()
            val gridInUr = if (ansGrid && gridVal.isNotEmpty()) " /$gridVal" else ""
            btnCwUr.text   = "${greetPfx}UR $rstPart$gridInUr$urExtra$qslInUr BK"
            btnCwCqUr.text = "${greetPfx}UR $rstPart$gridInUr$urExtra$qslInUr BK"
            btnCwTu.text   = "TU TU 73 E E"

            // Enable/disable per button
            fun setBtn(btn: android.widget.Button, ok: Boolean) {
                val en = ok && !busy
                btn.isEnabled = en
                btn.alpha     = if (en) 1.0f else 0.35f
            }
            setBtn(btnCwCq,      myOk)
            setBtn(btnCwCqDxK,   dOk)
            setBtn(btnCwCall,    myOk && dOk)
            setBtn(btnCwCqTu,    true)
            setBtn(btnCwCqAgn,   true)
            setBtn(btnCwCqUr,    true)
            setBtn(btnCwAnsCall, myOk)
            setBtn(btnCwAnsDE,   myOk && dOk)
            setBtn(btnCwUr,      true)
            setBtn(btnCwTu,      true)
            setBtn(btnCwAgn,     true)
            setBtn(btnSend,      true)
        }
        cwPanelUpdateLabels = { updateLabels() }
        cwRepeatUpdateFn    = { updateRepeatButton() }
        refreshCqToggles(); refreshAnsToggles(); refreshLoopToggles(); refreshGreetToggles(); refreshRstRepeat()
        updateLabels(); updateRepeatButton()

        // ── Toggle button handlers ──
        btnCqR1.setOnClickListener { cqRepeat = 1; refreshCqToggles(); updateLabels() }
        btnCqR2.setOnClickListener { cqRepeat = 2; refreshCqToggles(); updateLabels() }
        btnCqR3.setOnClickListener { cqRepeat = 3; refreshCqToggles(); updateLabels() }
        btnCqTogPota.setOnClickListener { cqPota = !cqPota; refreshCqToggles(); updateLabels() }
        btnCqTogJcc.setOnClickListener  { cqJcc  = !cqJcc;  refreshCqToggles(); updateLabels() }

        fun setGreet(g: String) { ansGreet = g; refreshGreetToggles(); updateLabels() }
        btnAnsGrNone.setOnClickListener  { setGreet("") }
        btnAnsGrGm.setOnClickListener    { setGreet("GM") }
        btnAnsGrGe.setOnClickListener    { setGreet("GE") }
        btnAnsGrGa.setOnClickListener    { setGreet("GA") }
        btnCqGrNone.setOnClickListener   { setGreet("") }
        btnCqGrGm.setOnClickListener     { setGreet("GM") }
        btnCqGrGe.setOnClickListener     { setGreet("GE") }
        btnCqGrGa.setOnClickListener     { setGreet("GA") }
        btnAnsTogPota.setOnClickListener { ansPota = !ansPota; refreshAnsToggles(); updateLabels() }
        btnAnsTogJcc.setOnClickListener  { ansJcc  = !ansJcc;  refreshAnsToggles(); updateLabels() }
        btnQslNone.setOnClickListener    { qsl = "";         refreshAnsToggles(); updateLabels() }
        btnQslPse.setOnClickListener     { qsl = "PSE QSL"; refreshAnsToggles(); updateLabels() }
        btnQslTnx.setOnClickListener     { qsl = "NO QSL";  refreshAnsToggles(); updateLabels() }
        // QSL の横の GL: ON で UR(RSTレポート)に自局グリッドを付加 (QSL と同じトグル方式。即送信しない)
        btnCwGrid.setOnClickListener {
            if (vm.prefs.ft8MyGrid.isBlank()) Toast.makeText(requireContext(), getString(R.string.main_control_93), Toast.LENGTH_SHORT).show()
            ansGrid = !ansGrid; refreshAnsToggles(); updateLabels()
        }
        // GL ボタン長押し: 自局グリッドロケーターを入力・変更 (FT8 と共有の ft8MyGrid)
        btnCwGrid.setOnLongClickListener {
            val et = android.widget.EditText(ctx).apply {
                hint = getString(R.string.main_control_94)
                setText(vm.prefs.ft8MyGrid)
                inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
                filters = arrayOf(android.text.InputFilter.AllCaps())
            }
            android.app.AlertDialog.Builder(ctx)
                .setTitle(getString(R.string.main_control_95))
                .setView(et)
                .setPositiveButton("OK") { _, _ ->
                    vm.prefs.ft8MyGrid = et.text.toString().trim().uppercase()
                    updateLabels()
                }
                .setNegativeButton("Cancel", null)
                .show()
            true
        }
        // CQ tab QSL (mirrors ANS tab)
        btnCqQslNone.setOnClickListener  { qsl = "";         refreshAnsToggles(); updateLabels() }
        btnCqQslPse.setOnClickListener   { qsl = "PSE QSL"; refreshAnsToggles(); updateLabels() }
        btnCqQslNo.setOnClickListener    { qsl = "NO QSL";  refreshAnsToggles(); updateLabels() }
        // CQ tab AGN + UR
        btnCwCqAgn.setOnClickListener    { send("AGN") }
        btnCwCqUr.setOnClickListener     { send(btnCwCqUr.text.toString()) }
        // RST repeat toggles
        btnRstR1.setOnClickListener      { rstRepeat = 1; refreshRstRepeat(); updateLabels() }
        btnRstR2.setOnClickListener      { rstRepeat = 2; refreshRstRepeat(); updateLabels() }
        btnRstR3.setOnClickListener      { rstRepeat = 3; refreshRstRepeat(); updateLabels() }
        // CQ loop toggles
        btnCqLoop3.setOnClickListener    { cqLoopCount = 3;  refreshLoopToggles() }
        btnCqLoop5.setOnClickListener    { cqLoopCount = 5;  refreshLoopToggles() }
        btnCqLoop10.setOnClickListener   { cqLoopCount = 10; refreshLoopToggles() }
        btnCqLoopInf.setOnClickListener  { cqLoopCount = 0;  refreshLoopToggles() }
        btnCqInt10.setOnClickListener    { cqLoopInterv = 10; refreshLoopToggles() }
        btnCqInt15.setOnClickListener    { cqLoopInterv = 15; refreshLoopToggles() }
        btnCqInt30.setOnClickListener    { cqLoopInterv = 30; refreshLoopToggles() }
        btnCqInt60.setOnClickListener    { cqLoopInterv = 60; refreshLoopToggles() }
        // CQ repeat start/stop
        btnCqRepeat.setOnClickListener {
            if (vm.cwCqRepeating.value == true) {
                vm.stopCqRepeat()
            } else {
                saveAll()
                vm.startCqRepeat(btnCwCq.text.toString(), getWpm(), cqLoopInterv, cqLoopCount)
            }
        }

        // Text field changes
        val watcher = object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { updateLabels() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        }
        etDxCall.addTextChangedListener(watcher)
        etRst.addTextChangedListener(watcher)
        etPota.addTextChangedListener(watcher)
        etJcc.addTextChangedListener(watcher)

        // ── Preset button send actions ──
        btnCwCq.setOnClickListener      { send(btnCwCq.text.toString()) }
        btnCwCqDxK.setOnClickListener   { send(btnCwCqDxK.text.toString()) }
        btnCwCall.setOnClickListener    { send(btnCwCall.text.toString()) }
        btnCwCqTu.setOnClickListener    { send("TU TU 73 E E") }
        btnCwAnsCall.setOnClickListener { send(btnCwAnsCall.text.toString()) }
        btnCwAnsDE.setOnClickListener   { send(btnCwAnsDE.text.toString()) }
        btnCwUr.setOnClickListener      { send(btnCwUr.text.toString()) }
        btnCwTu.setOnClickListener      { send(btnCwTu.text.toString()) }
        btnCwAgn.setOnClickListener     { send("AGN") }

        // Back button in CW TX sheet
        id<android.widget.Button>(R.id.btnCwTxBack).setOnClickListener { sheet.dismiss() }

        // LOG QSO button in CW TX sheet
        val btnCwLogQso = id<android.widget.Button>(R.id.btnCwLogQso)
        btnCwLogQso.setOnClickListener {
            saveAll()
            LogQsoDialogFragment.newInstance(
                callsign = dx(),
                pota     = pota(),
                sota     = vm.pendingLogSota,   // CW シートに SOTA 欄は無いので MEMSET で入った値を使う
                rstSent  = rst(),
                rstRcvd  = etMyRst.text.toString().trim().ifEmpty { "599" }
            ).show(parentFragmentManager, "log_qso")
        }

        btnSend.setOnClickListener {
            val text = etFree.text.toString().trim()
            if (text.isNotEmpty()) { vm.prefs.cwLastText = text; send(text) }
            else Toast.makeText(ctx, "Enter text", Toast.LENGTH_SHORT).show()
        }
        btnStop.setOnClickListener {
            vm.stopCwText()
            Toast.makeText(ctx, "CW stopped", Toast.LENGTH_SHORT).show()
        }

        updateCwTxSheetState()

        // 運用地バー(現時点で有効なもの)
        cwSheetOpLocScroll = v.findViewById(R.id.svCwOpLocActive)
        cwSheetOpLocContainer = v.findViewById(R.id.llCwOpLocActive)
        refreshCwSheetOpLoc()

        sheet.setOnDismissListener {
            saveAll()
            cwSheetOpLocScroll = null
            cwSheetOpLocContainer = null
            cwTxSheet = null
            cwSheetStopBtn = null
            cwSheetMsgButtons = emptyList()
            cwPanelUpdateLabels = null
            cwRepeatUpdateFn = null
            cwSheetFreqView = null
            cwSheetShiftView = null
            cwSheetRxView = null
            cwSheetRxScroll = null
            cwSheetTxView = null
            cwSheetTxScroll = null
            cwSheetMorseView = null
            cwSheetMorseScroll = null
            cwSheetSmeter = null
            cwSheetSmeterLabel = null
            cwSheetSpkBtn = null
            cwSheetDxCall = null
        }

        sheet.setOnShowListener {
            val bs = sheet.findViewById<android.view.View>(com.google.android.material.R.id.design_bottom_sheet)
            bs?.let {
                it.layoutParams?.height = android.view.ViewGroup.LayoutParams.MATCH_PARENT
                com.google.android.material.bottomsheet.BottomSheetBehavior.from(it).apply {
                    state = com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED
                    skipCollapsed = true
                }
            }
        }

        sheet.show()
    }

    private fun updateCwTxSheetState() {
        val busy = vm.cwTxBusy.value == true
        cwSheetStopBtn?.visibility = if (busy) View.VISIBLE else View.GONE
        // cwPanelUpdateLabels applies per-button placeholder + busy logic
        cwPanelUpdateLabels?.invoke()
    }

    private fun applyCwPort(port: String) {
        binding.tvCwUsbPort.text = port
        vm.prefs.cwPort = port
        if (vm.cwUsbConnected.value == true) {
            lifecycleScope.launch(Dispatchers.IO) { api.cwOpen(port, 0) }
        }
    }

    // Convenience property to access api directly within the Fragment
    private val api get() = vm.api

    private fun handleUpDown(dir: Int) {
        val modes = vm.supportedModes.value ?: emptyList()
        when (vm.selectedMenuItem.value ?: MenuItem.NONE) {
            MenuItem.FREQ -> {
                val step = STEP_LIST.getOrElse(vm.selectedStep.value ?: 0) { STEP_LIST[0] }
                val base = vm.sharedFreq.value ?: 0L
                vm.sendFreq(base + dir * step.stepHz)
            }
            MenuItem.STEP -> {
                val cur = vm.selectedStep.value ?: 0
                val next = (cur + dir).coerceIn(0, STEP_LIST.size - 1)
                vm.selectedStep.value = next
                vm.prefs.setModeStep(vm.sharedMode.value ?: "", next)
                updateInfoRow()
            }
            MenuItem.MODE -> {
                if (modes.isEmpty()) return
                val curMode = vm.sharedMode.value ?: ""
                var idx = modes.indexOf(curMode).takeIf { it >= 0 } ?: 0
                idx = ((idx + dir) + modes.size) % modes.size
                val newMode = modes[idx]
                val w = modeDefaultWidth(newMode)
                vm.sendMode(newMode, w)
                if (w > 0) vm.sharedWidth.value = w
                val savedStep = vm.prefs.getModeStep(newMode)
                vm.selectedStep.value = savedStep
            }
            MenuItem.WIDTH -> {
                // Width values from status; cycle ±100Hz steps if unknown
                val cur = vm.sharedWidth.value ?: 0
                val newW = (cur + dir * 100).coerceAtLeast(0)
                vm.sharedWidth.value = newW
                vm.sendMode(vm.sharedMode.value ?: "", newW)
            }
            MenuItem.POW -> {
                val cur = vm.sharedPower.value ?: 0f
                vm.sendPower((cur + dir * 0.01f).coerceIn(0f, 1f))
            }
            MenuItem.SQL -> {
                val cur = vm.sharedSQL.value ?: 0f
                vm.sendSQL((cur + dir * 0.01f).coerceIn(0f, 1f))
            }
            MenuItem.RVOL -> {
                val cur = vm.sharedVolume.value ?: 0.5f
                vm.sendVolume((cur + dir * 0.05f).coerceIn(0f, 1f))
            }
            else -> {
                val step = STEP_LIST.getOrElse(vm.selectedStep.value ?: 0) { STEP_LIST[0] }
                val base = vm.sharedFreq.value ?: 0L
                vm.sendFreq(base + dir * step.stepHz)
            }
        }
    }

    private fun setupVolumeSlider() {
        val vol = ((vm.sharedVolume.value ?: 0.5f) * 100).toInt()
        binding.seekVolume.progress = vol

        binding.seekVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) vm.sendVolume(progress / 100f)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        vm.sharedVolume.observe(viewLifecycleOwner) { v ->
            val progress = (v * 100).toInt()
            if (binding.seekVolume.progress != progress)
                binding.seekVolume.progress = progress
        }
    }

    private fun setupMicGainSlider() {
        val gain = vm.sharedMicGain.value ?: 1.0f
        vm.civ.micGain = gain  // initialize CivTcpService from saved pref
        val progress = (gain * 10).toInt().coerceIn(0, 30)
        binding.seekMicGain.progress = progress
        binding.tvMicGain.text = "%.1f".format(gain)

        binding.seekMicGain.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val g = p / 10f
                binding.tvMicGain.text = "%.1f".format(g)
                if (fromUser) {
                    vm.audioTx.gainMultiplier = g
                    vm.civ.micGain = g
                    vm.sharedMicGain.value = g
                    vm.prefs.micGain = g
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        vm.sharedMicGain.observe(viewLifecycleOwner) { g ->
            val p = (g * 10).toInt().coerceIn(0, 30)
            if (binding.seekMicGain.progress != p) binding.seekMicGain.progress = p
            binding.tvMicGain.text = "%.1f".format(g)
        }
    }

    override fun onResume() {
        super.onResume()
        // Other screens (RTTY waterfall) steal the single shared audio listener; restore CW decode feed.
        vm.ensureCwRxFeed()
        refreshOpLocActive()
        if (vm.isConnectedToRig.value == true) {
            vm.fetchVfoState()
            vm.startAprsReceivedPolling()
        }
        applyScreenTimeout()
        if (vm.spkEnabled.value == true) {
            if (!vm.audio.isPlaying && !vm.audio.isStreamActive) {
                vm.startAudio()
            } else if (vm.audio.isStreamActive && !vm.audio.isPlaying) {
                // ゾンビストリーム（接続済みだが再生なし）→ FT8帰還後などに発生 → 強制再起動
                vm.stopAudio()
                vm.startAudio()
            }
        }
    }

    override fun onPause() {
        super.onPause()
        vm.stopAprsReceivedPolling()
        aprsToastDialog?.dismiss()
        aprsToastDialog = null
        screenTimeoutJob?.cancel()
        screenTimeoutJob = null
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun showAprsToast(station: AprsHeardStation) {
        aprsToastDismissJob?.cancel()
        aprsToastDialog?.dismiss()

        val ctx = context ?: return
        val dm  = resources.displayMetrics
        val dialogW   = (dm.widthPixels * 0.85f).toInt()
        val compassPx = (dialogW - (32 * dm.density).toInt()).coerceAtLeast(160)

        val v = LayoutInflater.from(ctx).inflate(R.layout.dialog_aprs_toast, null)

        v.findViewById<android.widget.TextView>(R.id.tvToastCall).text = station.call

        val myLat  = vm.aprsLat.value ?: 0f
        val myLon  = vm.aprsLon.value ?: 0f
        val hasPos = (myLat != 0f || myLon != 0f) && (station.lat != 0.0 || station.lon != 0.0)
        val bearing: Double? = if (hasPos) aprsToastBearing(myLat.toDouble(), myLon.toDouble(), station.lat, station.lon) else null

        val ivCompass = v.findViewById<android.widget.ImageView>(R.id.ivCompass)
        ivCompass.layoutParams = android.widget.LinearLayout.LayoutParams(compassPx, compassPx)
        ivCompass.setImageBitmap(buildCompassBitmap(compassPx, bearing))

        val tvDist    = v.findViewById<android.widget.TextView>(R.id.tvToastDist)
        val tvSymbol  = v.findViewById<android.widget.TextView>(R.id.tvToastSymbol)
        val tvDir     = v.findViewById<android.widget.TextView>(R.id.tvToastDir)
        val tvComment = v.findViewById<android.widget.TextView>(R.id.tvToastComment)

        if (hasPos && bearing != null) {
            val distKm = aprsToastDistKm(myLat.toDouble(), myLon.toDouble(), station.lat, station.lon)
            tvDist.text = if (distKm < 1.0) "%.0fm".format(distKm * 1000) else "%.1fkm".format(distKm)
            tvDir.text  = aprsToastCompassDir(bearing)
        } else {
            v.findViewById<View>(R.id.rowDistDir).visibility = View.GONE
        }

        tvSymbol.text = aprsSymbolByCode(station.symbol).emoji
        if (station.comment.isNotEmpty()) tvComment.text = station.comment
        else tvComment.visibility = View.GONE

        val dialog = Dialog(ctx)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(v)
        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(dialogW, android.view.WindowManager.LayoutParams.WRAP_CONTENT)
        }
        dialog.setCanceledOnTouchOutside(true)
        dialog.show()
        aprsToastDialog = dialog

        aprsToastDismissJob = viewLifecycleOwner.lifecycleScope.launch {
            delay(6000)
            if (isAdded) dialog.dismiss()
        }
    }

    /** M5の drawCompassIcon をBitmapに移植 */
    private fun buildCompassBitmap(sizePx: Int, bearingDeg: Double?): android.graphics.Bitmap {
        val bmp = android.graphics.Bitmap.createBitmap(sizePx, sizePx, android.graphics.Bitmap.Config.ARGB_8888)
        val c   = android.graphics.Canvas(bmp)
        val cx  = sizePx / 2f
        val cy  = sizePx / 2f

        val labelSz    = sizePx * 0.10f
        val labelMargin = labelSz * 1.6f
        val r = (cx - labelMargin).coerceAtLeast(sizePx * 0.25f)

        val pFace = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF0D1117.toInt(); style = android.graphics.Paint.Style.FILL
        }
        val pRing = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF1565C0.toInt(); style = android.graphics.Paint.Style.STROKE
            strokeWidth = (r * 0.035f).coerceAtLeast(2f)
        }
        val pTickMinor = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF334455.toInt(); style = android.graphics.Paint.Style.STROKE
            strokeWidth = (r * 0.025f).coerceAtLeast(1.5f)
        }
        val pTickCard = android.graphics.Paint(pRing).apply {
            strokeWidth = (r * 0.030f).coerceAtLeast(2f)
        }
        val pNeedle = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFD32F2F.toInt(); style = android.graphics.Paint.Style.FILL
        }
        val pTail = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF00BCD4.toInt(); style = android.graphics.Paint.Style.STROKE
            strokeWidth = (r * 0.06f).coerceAtLeast(3f)
            strokeCap = android.graphics.Paint.Cap.ROUND
        }
        val pCenter = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF1565C0.toInt(); style = android.graphics.Paint.Style.FILL
        }
        val pLabel = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF4FC3F7.toInt(); textAlign = android.graphics.Paint.Align.CENTER
            textSize = labelSz; isFakeBoldText = true
        }

        c.drawCircle(cx, cy, r, pFace)
        c.drawCircle(cx, cy, r, pRing)

        for (a in 0 until 360 step 30) {
            val isCard = (a % 90 == 0)
            val rr = Math.toRadians(a.toDouble())
            val inner = if (isCard) r * 0.78f else r * 0.90f
            c.drawLine(
                cx + sin(rr).toFloat() * r,    cy - cos(rr).toFloat() * r,
                cx + sin(rr).toFloat() * inner, cy - cos(rr).toFloat() * inner,
                if (isCard) pTickCard else pTickMinor
            )
        }

        val ld  = r + labelSz * 0.85f
        val fix = labelSz * 0.36f
        c.drawText("N", cx,      cy - ld + fix, pLabel)
        c.drawText("S", cx,      cy + ld + fix, pLabel)
        c.drawText("E", cx + ld, cy + fix,      pLabel)
        c.drawText("W", cx - ld, cy + fix,      pLabel)

        if (bearingDeg != null) {
            val rad     = Math.toRadians(bearingDeg)
            val backRad = rad + Math.PI
            val perpRad = rad + Math.PI / 2.0
            val tipLen  = r * 0.88f
            val baseLen = tipLen * 0.55f
            val tailLen = r * 0.42f
            val headW   = r * 0.18f

            val tipX  = cx + sin(rad).toFloat()      * tipLen
            val tipY  = cy - cos(rad).toFloat()      * tipLen
            val baseX = cx + sin(rad).toFloat()      * baseLen
            val baseY = cy - cos(rad).toFloat()      * baseLen
            val tailX = cx + sin(backRad).toFloat()  * tailLen
            val tailY = cy - cos(backRad).toFloat()  * tailLen
            val lX    = baseX + sin(perpRad).toFloat() * headW
            val lY    = baseY - cos(perpRad).toFloat() * headW
            val rX    = baseX - sin(perpRad).toFloat() * headW
            val rY    = baseY + cos(perpRad).toFloat() * headW

            c.drawLine(tailX, tailY, baseX, baseY, pTail)

            val path = android.graphics.Path()
            path.moveTo(tipX, tipY); path.lineTo(lX, lY); path.lineTo(rX, rY); path.close()
            c.drawPath(path, pNeedle)
            c.drawCircle(cx, cy, r * 0.07f, pCenter)
        }

        return bmp
    }

    private fun aprsToastBearing(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val dLon = Math.toRadians(lon2 - lon1)
        val y = sin(dLon) * cos(Math.toRadians(lat2))
        val x = cos(Math.toRadians(lat1)) * sin(Math.toRadians(lat2)) -
                sin(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * cos(dLon)
        return (Math.toDegrees(atan2(y, x)) + 360) % 360
    }

    private fun aprsToastDistKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
        return 6371.0 * 2 * atan2(sqrt(a), sqrt(1 - a))
    }

    private fun aprsToastCompassDir(bearing: Double): String {
        val dirs = arrayOf("N","NNE","NE","ENE","E","ESE","SE","SSE","S","SSW","SW","WSW","W","WNW","NW","NNW")
        return dirs[((bearing + 11.25) / 22.5).toInt() % 16]
    }

    private fun modeDefaultWidth(mode: String): Int = when {
        mode == "FM" || mode == "PKTFM" -> 12000
        mode == "FMN"                   -> 9000
        mode.startsWith("CW")           -> vm.prefs.defaultCwWidth
        mode == "USB" || mode == "LSB"  -> vm.prefs.defaultSsbWidth
        else                            -> 0
    }

    private fun showMemoryPanel() {
        MemoryDialogFragment.newInstance().show(parentFragmentManager, "memory_dialog")
    }

    private fun showMemoryManagePanel() {
        // Long-press: open directly on User tab
        MemoryDialogFragment.newInstance(startTab = 1).show(parentFragmentManager, "memory_dialog")
    }

    private fun applyScreenTimeout() {
        screenTimeoutJob?.cancel()
        val toIdx = vm.selectedTimeoutIndex.value ?: 2
        val timeoutMin = SCREEN_TIMEOUT_OPTIONS.getOrElse(toIdx) { 10 }

        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        if (timeoutMin > 0) {
            screenTimeoutJob = viewLifecycleOwner.lifecycleScope.launch {
                delay(timeoutMin * 60 * 1000L)
                activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
        // timeoutMin == 0 → "Off" → keep screen on permanently
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}