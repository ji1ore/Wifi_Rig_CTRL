package com.ji1ore.wifi_rig_ctrl

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.ji1ore.wifi_rig_ctrl.data.BAUD_RATES
import com.ji1ore.wifi_rig_ctrl.data.SAMPLING_RATES
import com.ji1ore.wifi_rig_ctrl.data.SCREEN_TIMEOUT_OPTIONS
import com.ji1ore.wifi_rig_ctrl.databinding.FragmentRigSelectBinding
import com.ji1ore.wifi_rig_ctrl.ui.theme.ThemeApply
import com.ji1ore.wifi_rig_ctrl.ui.theme.UiTheme
import com.ji1ore.wifi_rig_ctrl.viewmodel.MainViewModel
import kotlinx.coroutines.launch

class RigSelectFragment : Fragment() {

    private var _binding: FragmentRigSelectBinding? = null
    private val binding get() = _binding!!
    private val vm: MainViewModel by activityViewModels()

    // バックアップ先フォルダ選択(SAF)
    private val backupFolderLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            BackupStore.setFolder(requireContext(), uri)
            AlertDialog.Builder(requireContext())
                .setTitle(getString(R.string.rig_select_1))
                .setMessage(getString(R.string.rig_select_2))
                .setPositiveButton(getString(R.string.rig_select_3)) { _, _ ->
                    if (BackupStore.restore(requireContext()))
                        Toast.makeText(requireContext(), getString(R.string.rig_select_4), Toast.LENGTH_LONG).show()
                    else Toast.makeText(requireContext(), getString(R.string.rig_select_5), Toast.LENGTH_LONG).show()
                }
                .setNegativeButton(getString(R.string.rig_select_6)) { _, _ ->
                    BackupStore.save(requireContext())
                    Toast.makeText(requireContext(), getString(R.string.rig_select_7), Toast.LENGTH_SHORT).show()
                }
                .show()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentRigSelectBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val isCiv = vm.useCIV.value == true
        applyModeVisibility(isCiv)
        updateUI()

        // ブランド・テーマを画面全体へ適用（中立色のみパレット化・機能色は維持）
        ThemeApply.apply(binding.root, UiTheme.fromIndex(vm.prefs.colorTheme), vm.prefs.dayMode)

        if (vm.isDemoMode.value == true) {
            binding.btnUpdate.isEnabled = false
        }

        vm.piVersionMismatch.observe(viewLifecycleOwner) { mismatch ->
            if (mismatch) binding.tvStatus.text = "Pi API version mismatch — update via UPDATE"
        }

        // Start polling immediately so version-mismatch warnings are visible on first display.
        if (vm.isDemoMode.value != true && vm.useCIV.value != true) {
            vm.startStatusPolling()
        }

        // 自局コール(My Call) — 過去登録から選択/追加
        vm.prefs.addMyCall(vm.prefs.ft8MyCall)   // 現在のコールを履歴に入れておく(初回でも選べるように)
        binding.actvMyCall.setText(vm.prefs.ft8MyCall)
        fun refreshCallAdapter() {
            binding.actvMyCall.setAdapter(android.widget.ArrayAdapter(
                requireContext(), android.R.layout.simple_dropdown_item_1line, vm.prefs.myCallHistory()))
        }
        refreshCallAdapter()
        binding.actvMyCall.threshold = 1
        fun saveMyCall() {
            val c = binding.actvMyCall.text.toString().trim().uppercase()
            if (binding.actvMyCall.text.toString() != c) binding.actvMyCall.setText(c)
            vm.prefs.ft8MyCall = c
            vm.prefs.addMyCall(c)
            refreshCallAdapter()
        }
        binding.actvMyCall.setOnFocusChangeListener { _, has -> if (!has) saveMyCall() }
        binding.actvMyCall.setOnItemClickListener { _, _, _, _ -> saveMyCall() }
        binding.actvMyCall.setOnEditorActionListener { _, _, _ -> saveMyCall(); false }
        // 「▼ 選択」: 履歴から選ぶポップアップ
        binding.btnMyCallPick.setOnClickListener {
            val hist = vm.prefs.myCallHistory()
            if (hist.isEmpty()) { Toast.makeText(requireContext(), getString(R.string.rig_select_8), Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val pm = android.widget.PopupMenu(requireContext(), binding.btnMyCallPick)
            hist.forEachIndexed { i, c -> pm.menu.add(0, i, i, c) }
            pm.setOnMenuItemClickListener { mi ->
                binding.actvMyCall.setText(hist[mi.itemId]); saveMyCall(); true
            }
            pm.show()
        }

        // RTTY AUTO 自動追従の最大ずれ(Hz)。入力は 50〜950 にクランプして即保存。
        binding.editRttyAutoOffset.setText(vm.prefs.rttyAutoTuneOffsetHz.toString())
        fun saveRttyAutoOffset() {
            val v = binding.editRttyAutoOffset.text.toString().toIntOrNull()?.coerceIn(50, 950) ?: 500
            vm.prefs.rttyAutoTuneOffsetHz = v
            if (binding.editRttyAutoOffset.text.toString() != v.toString()) binding.editRttyAutoOffset.setText(v.toString())
        }
        binding.editRttyAutoOffset.setOnFocusChangeListener { _, has -> if (!has) saveRttyAutoOffset() }
        binding.editRttyAutoOffset.setOnEditorActionListener { _, _, _ -> saveRttyAutoOffset(); false }

        // SOTA スポット有効時間(時間)。1〜24 にクランプして即保存。
        binding.editSotaSpotHours.setText(vm.prefs.sotaSpotHours.toString())
        fun saveSotaSpotHours() {
            val v = binding.editSotaSpotHours.text.toString().toIntOrNull()?.coerceIn(1, 24) ?: 2
            vm.prefs.sotaSpotHours = v
            if (binding.editSotaSpotHours.text.toString() != v.toString()) binding.editSotaSpotHours.setText(v.toString())
        }
        binding.editSotaSpotHours.setOnFocusChangeListener { _, has -> if (!has) saveSotaSpotHours() }
        binding.editSotaSpotHours.setOnEditorActionListener { _, _, _ -> saveSotaSpotHours(); false }

        // 外部連携トグル (eQSL / Smart Ham Log)
        binding.switchEqsl.isChecked = vm.prefs.eqslEnabled
        binding.switchSmartHamLog.isChecked = vm.prefs.smartHamLogEnabled
        binding.switchEqsl.setOnCheckedChangeListener { _, c -> vm.prefs.eqslEnabled = c }
        binding.switchSmartHamLog.setOnCheckedChangeListener { _, c -> vm.prefs.smartHamLogEnabled = c }
        binding.switchPskReporter.isChecked = vm.prefs.pskrEnabled
        binding.switchPskReporter.setOnCheckedChangeListener { _, c ->
            vm.prefs.pskrEnabled = c
            // Pi に ON/OFF と自局コール/グリッドを通知(RX中に受信レポートが送られる)
            val call = vm.prefs.ft8MyCall; val grid = vm.prefs.ft8MyGrid
            Thread { try { vm.api.setPskReporter(c, call, grid) } catch (_: Exception) {} }.start()
        }
        binding.btnIntegrationSettings.setOnClickListener {
            saveMyCall()   // 入力中の新コールを先に確定(そのコール用のeQSL設定を開くため)
            showIntegrationSettingsDialog()
        }
        binding.btnBackup.setOnClickListener { showBackupDialog() }

        // Rig model tap → dialog (Pi mode only; in CI-V mode it's read-only)
        binding.tvRigName.setOnClickListener {
            if (isCiv) return@setOnClickListener
            val rigs = vm.rigList.value ?: return@setOnClickListener
            if (rigs.isEmpty()) return@setOnClickListener
            val names = rigs.map { it.name }.toTypedArray()
            AlertDialog.Builder(requireContext())
                .setTitle("Rig Model")
                .setItems(names) { _, i ->
                    vm.selectedRigIndex.value = i
                    updateUI()
                }.show()
        }

        // CAT device tap (Pi mode only)
        binding.tvCatDevice.setOnClickListener {
            val cats = vm.catList.value ?: return@setOnClickListener
            val labels = vm.catLabels.value?.takeIf { it.size == cats.size } ?: cats
            val options = (labels + listOf("Manual...")).toTypedArray()
            AlertDialog.Builder(requireContext())
                .setTitle("CAT Device")
                .setItems(options) { _, i ->
                    if (i == options.size - 1) {
                        showCatManualInput()
                    } else {
                        vm.selectedCatIndex.value = i
                        updateUI()
                    }
                }.show()
        }

        // PTT device tap (Pi mode only)
        binding.tvPttDevice.setOnClickListener {
            val cats = vm.catList.value ?: emptyList()
            val labels = vm.catLabels.value?.takeIf { it.size == cats.size } ?: cats
            val display = (listOf("NONE") + labels + listOf("Manual...")).toTypedArray()
            val values  = listOf("NONE") + cats + listOf("Manual...")   // 表示と並行な実値(by-id)
            AlertDialog.Builder(requireContext())
                .setTitle("PTT Device  (type: tap to cycle RTS/DTR/CAT)")
                .setItems(display) { _, i ->
                    when (i) {
                        display.size - 1 -> showPttManualInput()
                        else -> { vm.selectedPttDevice.value = values[i]; updateUI() }
                    }
                }.show()
        }

        // PTT type tap → cycle RTS/DTR/RIG
        binding.tvPttType.setOnClickListener {
            val cur = vm.selectedPttType.value ?: "RIG"
            vm.selectedPttType.value = when (cur) { "RTS" -> "DTR"; "DTR" -> "RIG"; else -> "RTS" }
            updateUI()
        }

        // Timeout tap → cycle (shared between Pi and CI-V modes)
        val timeoutClickListener = View.OnClickListener {
            val cur = vm.selectedTimeoutIndex.value ?: 0
            vm.selectedTimeoutIndex.value = (cur + 1) % SCREEN_TIMEOUT_OPTIONS.size
            updateUI()
        }
        binding.tvTimeout.setOnClickListener(timeoutClickListener)
        binding.tvTimeoutCiv.setOnClickListener(timeoutClickListener)

        // Baud rate tap (Pi mode only)
        binding.tvBaudRate.setOnClickListener {
            val cur = vm.selectedBaudIndex.value ?: 0
            vm.selectedBaudIndex.value = (cur + 1) % BAUD_RATES.size
            updateUI()
        }

        // Sampling rate tap (Pi mode only)
        binding.tvSampling.setOnClickListener {
            val cur = vm.selectedSamplingIndex.value ?: 0
            vm.selectedSamplingIndex.value = (cur + 1) % SAMPLING_RATES.size
            updateUI()
        }

        // TX rate tap (Pi mode only)
        binding.tvTxRate.setOnClickListener {
            val cur = vm.selectedTxSamplingIndex.value ?: 2
            vm.selectedTxSamplingIndex.value = (cur % (SAMPLING_RATES.size - 1)) + 1
            updateUI()
        }

        // Audio Device (SPK/TX) tap (Pi mode only)
        binding.tvAudioDevice.setOnClickListener {
            val devices = vm.soundDeviceList.value ?: emptyList()
            val labels = (listOf("Default (plughw:CARD=CODEC,DEV=0)") +
                devices.map { it.label } + listOf("Manual...")).toTypedArray()
            val ids = (listOf("") + devices.map { it.id } + listOf("__manual__")).toTypedArray()
            AlertDialog.Builder(requireContext())
                .setTitle("Audio Device (SPK/TX)")
                .setItems(labels) { _, i ->
                    if (ids[i] == "__manual__") showAudioManualInput()
                    else { vm.selectedAudioDevice.value = ids[i]; updateUI() }
                }.show()
        }

        // Audio Device (FT8) tap (Pi mode only)
        binding.tvAudioDeviceFt8.setOnClickListener {
            val devices = vm.soundDeviceList.value ?: emptyList()
            val labels = (listOf("Same as SPK/TX") +
                devices.map { it.label } + listOf("Manual...")).toTypedArray()
            val ids = (listOf("") + devices.map { it.id } + listOf("__manual__")).toTypedArray()
            AlertDialog.Builder(requireContext())
                .setTitle("Audio Device (FT8)")
                .setItems(labels) { _, i ->
                    if (ids[i] == "__manual__") showAudioFt8ManualInput()
                    else { vm.selectedAudioDeviceFt8.value = ids[i]; updateUI() }
                }.show()
        }

        binding.btnUpdate.setOnClickListener {
            findNavController().navigate(R.id.action_RigSelectFragment_to_UpdateFragment)
        }

        binding.btnSyncTime.setOnClickListener {
            binding.tvStatus.text = "Syncing Pi time..."
            lifecycleScope.launch {
                val result = vm.syncPiTime()
                binding.tvStatus.text = result
                Toast.makeText(requireContext(), result, Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnAbout.setOnClickListener {
            findNavController().navigate(R.id.action_RigSelectFragment_to_AboutFragment)
        }

        binding.btnBack.setOnClickListener {
            findNavController().navigate(R.id.action_RigSelectFragment_to_ConnectFragment)
        }

        binding.btnPttSettings.setOnClickListener {
            findNavController().navigate(R.id.action_RigSelectFragment_to_PttSettingsFragment)
        }

        binding.btnConnect.setOnClickListener {
            if (isCiv) {
                // CI-V mode: connect directly (CIV already connected from ConnectFragment)
                binding.btnConnect.isEnabled = false
                binding.progressBar.visibility = View.VISIBLE
                binding.tvStatus.text = "Connecting..."
                lifecycleScope.launch {
                    val error = vm.connectRig()
                    binding.btnConnect.isEnabled = true
                    binding.progressBar.visibility = View.GONE
                    if (error == null) {
                        vm.isConnectedToRig.value = true
                        findNavController().navigate(R.id.action_RigSelectFragment_to_MainControlFragment)
                    } else {
                        binding.tvStatus.text = error
                        Toast.makeText(requireContext(), error, Toast.LENGTH_LONG).show()
                    }
                }
            } else {
                // Pi mode: original flow
                val rigs = vm.rigList.value
                if (rigs.isNullOrEmpty()) {
                    Toast.makeText(requireContext(), "No rig found", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                binding.btnConnect.isEnabled = false
                binding.progressBar.visibility = View.VISIBLE
                binding.tvStatus.text = "Connecting..."
                lifecycleScope.launch {
                    val error = vm.connectRig()
                    binding.btnConnect.isEnabled = true
                    binding.progressBar.visibility = View.GONE
                    if (error == null) {
                        vm.isConnectedToRig.value = true
                        findNavController().navigate(R.id.action_RigSelectFragment_to_MainControlFragment)
                    } else {
                        binding.tvStatus.text = error
                        Toast.makeText(requireContext(), error, Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    // eQSL / Smart Ham Log の資格情報入力ダイアログ(認証情報はセキュアに保存)
    private fun showIntegrationSettingsDialog() {
        val ctx = requireContext()
        val prefs = vm.prefs
        fun field(label: String, value: String, pass: Boolean = false): EditText =
            EditText(ctx).apply {
                hint = label; setText(value)
                if (pass) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
        val etUser  = field(getString(R.string.rig_select_9), prefs.eqslUser)
        val etPass  = field(getString(R.string.rig_select_10), prefs.eqslPassword, pass = true)
        val etNick  = field(getString(R.string.rig_select_11), prefs.eqslQthNickname)
        // Smart HAMLOG = Cloudlog API 方式(FT8TW/Greyline連携)
        val etUrl   = field(getString(R.string.rig_select_12), prefs.shlCloudlogUrl)
        val etKey   = field(getString(R.string.rig_select_13), prefs.shlApiKey, pass = true)
        val etSid   = field(getString(R.string.rig_select_14), prefs.shlStationId)
        val tvTest  = android.widget.TextView(ctx).apply { textSize = 12f; setTextColor(0xFFAAAAAA.toInt()) }
        val btnTest = android.widget.Button(ctx).apply { text = getString(R.string.rig_select_15); textSize = 13f }
        btnTest.setOnClickListener {
            val url = etUrl.text.toString().trim(); val key = etKey.text.toString().trim()
            val sid = etSid.text.toString().trim().ifEmpty { "1" }
            tvTest.text = getString(R.string.rig_select_16)
            Thread {
                val r = SmartHamLogSync.checkAuth(requireContext(), url, key, sid)
                requireActivity().runOnUiThread { tvTest.text = r }
            }.start()
        }
        val box = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL; setPadding(40, 16, 40, 0)
            addView(android.widget.TextView(ctx).apply {
                val mc = prefs.ft8MyCall.trim().uppercase()
                text = if (mc.isEmpty()) getString(R.string.rig_select_17) else getString(R.string.rig_select_18, mc)
                setTextColor(0xFFCCCCCC.toInt())
            })
            addView(etUser); addView(etPass); addView(etNick)
            addView(android.widget.TextView(ctx).apply { text = getString(R.string.rig_select_19); setTextColor(0xFFCCCCCC.toInt()); setPadding(0, 24, 0, 0) })
            addView(android.widget.TextView(ctx).apply { text = getString(R.string.rig_select_20); textSize = 11f; setTextColor(0xFF888888.toInt()) })
            addView(etUrl); addView(etKey); addView(etSid); addView(btnTest); addView(tvTest)
        }
        // ヘッダに タイトル + キャンセル/保存(キーボードで隠れないよう上固定)
        val btnCancel = android.widget.Button(ctx).apply { text = getString(R.string.rig_select_21); isAllCaps = false }
        val btnSave = android.widget.Button(ctx).apply { text = getString(R.string.rig_select_22); isAllCaps = false }
        val header = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(24, 8, 12, 8)
            addView(android.widget.TextView(ctx).apply {
                text = getString(R.string.rig_select_23); setTextColor(0xFFFFFFFF.toInt()); textSize = 17f
                layoutParams = android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(btnCancel); addView(btnSave)
        }
        val outer = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            addView(header, android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(androidx.core.widget.NestedScrollView(ctx).apply { addView(box) },
                android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        val dlg = AlertDialog.Builder(ctx, android.R.style.Theme_Material_Dialog_NoActionBar)
            .setView(outer).create()
        btnSave.setOnClickListener {
            prefs.eqslUser = etUser.text.toString().trim()
            prefs.eqslPassword = etPass.text.toString()
            prefs.eqslQthNickname = etNick.text.toString().trim()
            prefs.shlCloudlogUrl = etUrl.text.toString().trim()
            prefs.shlApiKey = etKey.text.toString().trim()
            prefs.shlStationId = etSid.text.toString().trim().ifEmpty { "1" }
            Toast.makeText(ctx, getString(R.string.rig_select_24), Toast.LENGTH_SHORT).show()
            dlg.dismiss()
        }
        btnCancel.setOnClickListener { dlg.dismiss() }
        dlg.window?.apply {
            setBackgroundDrawableResource(android.R.color.background_dark)
            setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        dlg.setOnShowListener {
            dlg.window?.setLayout(
                (ctx.resources.displayMetrics.widthPixels * 0.95).toInt(),
                android.view.WindowManager.LayoutParams.MATCH_PARENT)
        }
        dlg.show()
    }

    // 設定/ログのバックアップ(SAF)。認証情報は含めない。
    private fun showBackupDialog() {
        val ctx = requireContext()
        val has = BackupStore.hasFolder(ctx)
        val msg = if (has) getString(R.string.rig_select_25)
                  else getString(R.string.rig_select_26)
        AlertDialog.Builder(ctx)
            .setTitle(getString(R.string.rig_select_27))
            .setMessage(msg)
            .setPositiveButton(getString(R.string.rig_select_28)) { _, _ -> try { backupFolderLauncher.launch(null) } catch (_: Exception) {} }
            .apply {
                if (has) {
                    setNeutralButton(getString(R.string.rig_select_29)) { _, _ ->
                        Toast.makeText(ctx, if (BackupStore.save(ctx)) getString(R.string.rig_select_30) else getString(R.string.rig_select_31), Toast.LENGTH_SHORT).show()
                    }
                    setNegativeButton(getString(R.string.rig_select_32)) { _, _ ->
                        if (BackupStore.restore(ctx)) Toast.makeText(ctx, getString(R.string.rig_select_33), Toast.LENGTH_LONG).show()
                        else Toast.makeText(ctx, getString(R.string.rig_select_34), Toast.LENGTH_LONG).show()
                    }
                } else setNegativeButton(getString(R.string.rig_select_35), null)
            }
            .show()
    }

    private fun applyModeVisibility(isCiv: Boolean) {
        binding.groupPiSettings.visibility = if (isCiv) View.GONE else View.VISIBLE
        binding.groupCivSettings.visibility = if (isCiv) View.VISIBLE else View.GONE
        binding.tvRigSelectTitle.text = if (isCiv) "RIG CONNECT (CI-V)" else "RIG CONNECT"
        // Hide Pi-specific buttons in CI-V mode
        binding.btnUpdate.visibility = if (isCiv) View.GONE else View.VISIBLE
        binding.btnSyncTime.visibility = if (isCiv) View.GONE else View.VISIBLE
        binding.btnPttSettings.visibility = if (isCiv) View.GONE else View.VISIBLE
    }

    /** PTT 表示用: by-id 値なら対応する「tty · by-id短縮」ラベルに、それ以外(NONE/手入力)はそのまま。 */
    private fun pttDisplayLabel(value: String): String {
        if (value.isEmpty() || value == "NONE") return "NONE"
        val cats = vm.catList.value ?: emptyList()
        val labels = vm.catLabels.value
        val idx = cats.indexOf(value)
        if (idx >= 0 && labels != null && idx < labels.size) return labels[idx]
        return value
    }

    private fun updateUI() {
        val rigs = vm.rigList.value ?: emptyList()
        val cats = vm.catList.value ?: emptyList()
        val rigIdx = vm.selectedRigIndex.value ?: 0
        val catIdx = vm.selectedCatIndex.value ?: 0
        val baudIdx = vm.selectedBaudIndex.value ?: 2
        val sampIdx = vm.selectedSamplingIndex.value ?: 1
        val toIdx = vm.selectedTimeoutIndex.value ?: 2
        val isCiv = vm.useCIV.value == true

        val rigName = rigs.getOrNull(rigIdx)?.name ?: "---"
        binding.tvRigName.text = rigName

        val timeout = SCREEN_TIMEOUT_OPTIONS.getOrElse(toIdx) { 10 }
        val timeoutText = if (timeout == 0) "Off" else "$timeout min"
        binding.tvTimeout.text = timeoutText
        binding.tvTimeoutCiv.text = timeoutText

        if (isCiv) {
            val addr = (vm.civAddress.value ?: 0xA4).toString(16).uppercase()
            binding.tvCivInfo.text = "CI-V: ${vm.civHost.value}\nPort1=${vm.civPort.value}  Port3=${vm.civPort3.value}  addr=0x$addr\nUser: ${vm.civUser.value?.ifEmpty { "(none)" }}"
            return
        }

        val catLbls = vm.catLabels.value?.takeIf { it.size == cats.size } ?: cats
        binding.tvCatDevice.text = catLbls.getOrElse(catIdx) { "None" }
        binding.tvPttDevice.text = pttDisplayLabel(vm.selectedPttDevice.value ?: "NONE")
        val pttDev = vm.selectedPttDevice.value ?: "NONE"
        val pttTypeDisplay = when (vm.selectedPttType.value ?: "RTS") { "RIG" -> "CAT"; else -> vm.selectedPttType.value ?: "RTS" }
        binding.tvPttType.text = if (pttDev == "NONE") "-" else pttTypeDisplay
        binding.tvBaudRate.text = "${BAUD_RATES.getOrElse(baudIdx) { 9600 }} bps"

        val rate = SAMPLING_RATES.getOrElse(sampIdx) { 0 }
        binding.tvSampling.text = if (rate == 0) "OFF" else "$rate Hz"

        val txIdx = vm.selectedTxSamplingIndex.value ?: 2
        val txRate = SAMPLING_RATES.getOrElse(txIdx) { 8000 }
        binding.tvTxRate.text = "$txRate Hz"

        val audioDev = vm.selectedAudioDevice.value ?: ""
        binding.tvAudioDevice.text = if (audioDev.isEmpty()) "Default" else audioDev

        val audioFt8Dev = vm.selectedAudioDeviceFt8.value ?: ""
        binding.tvAudioDeviceFt8.text = if (audioFt8Dev.isEmpty()) "Same as SPK/TX" else audioFt8Dev
    }

    private fun showPttManualInput() {
        val edit = EditText(requireContext()).apply { hint = "e.g. ttyUSB1" }
        AlertDialog.Builder(requireContext())
            .setTitle("PTT Device (manual)")
            .setView(edit)
            .setPositiveButton("OK") { _, _ ->
                val input = edit.text.toString().trim()
                if (input.isNotEmpty()) { vm.selectedPttDevice.value = input; updateUI() }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAudioManualInput() {
        val edit = EditText(requireContext()).apply {
            hint = "e.g. plughw:CARD=CODEC,DEV=0"
            val cur = vm.selectedAudioDevice.value ?: ""
            if (cur.isNotEmpty()) setText(cur)
        }
        AlertDialog.Builder(requireContext())
            .setTitle("Audio Device (manual)")
            .setView(edit)
            .setPositiveButton("OK") { _, _ ->
                vm.selectedAudioDevice.value = edit.text.toString().trim()
                updateUI()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAudioFt8ManualInput() {
        val edit = EditText(requireContext()).apply {
            hint = "e.g. plughw:CARD=CODEC,DEV=0"
            val cur = vm.selectedAudioDeviceFt8.value ?: ""
            if (cur.isNotEmpty()) setText(cur)
        }
        AlertDialog.Builder(requireContext())
            .setTitle("Audio Device FT8 (manual)")
            .setView(edit)
            .setPositiveButton("OK") { _, _ ->
                vm.selectedAudioDeviceFt8.value = edit.text.toString().trim()
                updateUI()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showCatManualInput() {
        val edit = EditText(requireContext()).apply {
            hint = "e.g. ttyUSB0"
            val cur = vm.catList.value?.getOrNull(vm.selectedCatIndex.value ?: 0)
            if (cur != null && cur != "None") setText(cur)
        }
        AlertDialog.Builder(requireContext())
            .setTitle("CAT Device (manual)")
            .setView(edit)
            .setPositiveButton("OK") { _, _ ->
                val input = edit.text.toString().trim()
                if (input.isNotEmpty()) { vm.setCustomCatDevice(input); updateUI() }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
