package com.ji1ore.wifi_rig_ctrl
import com.ji1ore.wifi_rig_ctrl.ui.theme.ThemeApply
import com.ji1ore.wifi_rig_ctrl.ui.theme.UiTheme

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.ji1ore.wifi_rig_ctrl.data.SAMPLING_RATES
import com.ji1ore.wifi_rig_ctrl.databinding.FragmentRttyBinding
import com.ji1ore.wifi_rig_ctrl.viewmodel.MainViewModel
import kotlinx.coroutines.*
import okhttp3.Call
import okhttp3.Request
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.sqrt

class RttyFragment : Fragment() {

    private var _binding: FragmentRttyBinding? = null
    private val binding get() = _binding!!
    private val vm: MainViewModel by activityViewModels()

    private val myCall: String
        get() = vm.prefs.ft8MyCall.ifEmpty { vm.prefs.aprsCallsign }.uppercase().ifEmpty { "MYCALL" }

    private var isRttyR = false   // false=RTTY, true=RTTYR
    private var pttActive = false
    private var txJob: Job? = null
    private var cqRepeatJob: Job? = null


    @Volatile private var modem: RttyModem? = null
    private var recorder: AudioRecord? = null
    private var rxJob: Job? = null
    // RTTY RX は Pi の minimodem 復調結果を SSE で購読する
    private var rttySseJob: Job? = null
    @Volatile private var rttySseCall: Call? = null
    // RX ウォッチドッグ: SSE は readTimeout 無限なので、サーバが「接続は生きているが無データ」で
    // 固まるとテキストもグラフも出ないまま復帰しない。最後にデータを受けた時刻を見張り、一定時間
    // 沈黙したら(送信中を除く)現在の接続を切って張り直す。再接続でサーバの gen() が sox/minimodem を
    // kill→再購読し、キャプチャ経路ごと作り直されるため自動復帰する。
    @Volatile private var lastRxDataMs = 0L
    // Separate from lastRxDataMs: the SSE can deliver text/audio/keepalive (which bump lastRxDataMs) while
    // NO spectrum frames arrive — e.g. right after CW RX-decode → RTTY, when stopAudio() + reopening the
    // SSE briefly disturbs the Pi's shared capture (_mgr_sub) and its spectrum generation fails to start.
    // Then the general watchdog never fires and the waterfall stays blank ("スコープが出ないことあり").
    // A spectrum-specific watchdog reconnects when connected-but-no-spectrum, so the scope auto-recovers.
    @Volatile private var lastSpectrumMs = 0L
    private var rttyWatchdogJob: Job? = null
    // 受信音のスマホ再生(SPK)。SSE の audio イベント(base64 PCM)を AudioTrack で再生
    private var rttySpk = false
    @Volatile private var rttyAudioTrack: AudioTrack? = null
    private val rxSpan = SpannableStringBuilder()
    @Volatile private var usingPiAudio = false
    @Volatile private var usingCivAudio = false
    private var rttyStartedAudio = false

    // Peak detection
    private companion object {
        const val PEAK_BUF_SIZE = 2048
        // 手動(Tuneボタン/タップ): スキャン窓 1200–3200Hz 内ならどこでも 2125 へ寄せられる。
        // ユーザーが意図的に選んだ位置なので上限は実質スキャン窓いっぱい(2125−1200=925 を丸めて950)。
        const val MAX_TUNE_OFFSET_HZ = 950L
        // AUTO 連続追従の最大ずれは RIG CONNECT 画面で設定(AppPrefs.rttyAutoTuneOffsetHz, 既定500Hz)。
        // RX が無データのまま沈黙してよい最大時間(ms)。正常時はスペクトラムが約47行/秒で流れ続けるので、
        // これを超える沈黙は経路の固まりとみなして再接続する。送信中は判定しない。
        const val RX_WATCHDOG_MS = 7000L
        // No-spectrum watchdog: the Pi streams a spectrum frame continuously (noise floor shows even with
        // no signal), so a connected SSE with no spectrum for this long means its capture never started —
        // reconnect. Shorter than RX_WATCHDOG_MS so a blank waterfall recovers quickly.
        const val SPECTRUM_WATCHDOG_MS = 4000L
    }
    private var peakBuf = ShortArray(PEAK_BUF_SIZE)
    private var peakPos = 0
    private var detectedMarkHz  = 0.0
    private var detectedSpaceHz = 0.0
    private var lastMarkHz  = 2125.0   // persists across modem restarts
    private var lastSpaceHz = 2295.0
    // Auto-tune hysteresis: the candidate pair, how many consecutive analyses it has held,
    // and when the modem was last retuned. See the auto-tune block in startRx().
    private var candMarkHz   = 0.0
    private var candSpaceHz  = 0.0
    private var candCount    = 0
    private var lastRetuneMs = 0L
    // RTTYはFSKでマーク/スペースが交互。1フレームには片トーンしか写らないことが多いので、
    // ピーク検出(findPeaks=2トーンのペア要求)は直近フレームの平均スペクトラムに対して行う。
    private val peakAvgRows = ArrayDeque<DoubleArray>()
    /** When a convincing tone pair was last seen; drives the fall-back to the standard tones. */
    private var lastPairSeenMs = System.currentTimeMillis()
    /**
     * FIX(固定)モード。長押しTuneで切替。FIX中は自動追従OFF。画面を開くたびに AUTO(=false)で開始する
     * (永続化して FIX のまま固まる事故を防ぐ)。
     */
    private var tuneFixed = false
    private var currentBaud = 45.45
    @Volatile private var rxLevelDb: Int = -100
    private var logChunkCount = 0

    private val recordPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startRx() else updateStatus("RECORD_AUDIO permission denied")
    }

    // --- Lifecycle ---

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentRttyBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // ブランド・テーマを画面全体へ適用（中立色のみパレット化・機能色は維持）
        ThemeApply.apply(binding.root, UiTheme.fromIndex(vm.prefs.colorTheme), vm.prefs.dayMode)

        // Enter RTTY once (not on every rotation): remember the pre-RTTY mode and move the dial so
        // the RTTY "true mark frequency" display equals the frequency the main screen was showing.
        // AFSK LSB puts the mark at dial−2125 (+band calibration), so rttyToDial() raises the dial
        // accordingly; on exit (onDestroyView) dialToRtty() moves it back. The rttyAnchorActive flag
        // guards against re-applying the shift when the view is recreated (rotation/config change).
        if (!vm.rttyAnchorActive) {
            vm.rttyAnchorActive = true
            vm.rttyPreMode  = vm.sharedMode.value  ?: ""
            vm.rttyPreWidth = vm.sharedWidth.value ?: 0
            val cur = vm.sharedFreq.value ?: 0L
            if (cur > 0L) vm.sendFreq(rttyToDial(cur))
        }

        // Keep screen on
        requireActivity().window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Observe freq / mode from rig
        updateFreqDisplay(vm.sharedFreq.value ?: 0L)
        vm.sharedFreq.observe(viewLifecycleOwner) { updateFreqDisplay(it) }
        binding.tvMode.text = vm.sharedMode.value?.takeIf { it.isNotEmpty() } ?: "---"
        vm.sharedMode.observe(viewLifecycleOwner) { binding.tvMode.text = it.ifEmpty { "---" } }

        // 現時点で有効な運用地バー
        val refreshOpLoc = { OpLocBar.populate(requireContext(), binding.svRttyOpLocActive, binding.llRttyOpLocActive, vm) }
        refreshOpLoc()
        vm.opSessions.observe(viewLifecycleOwner) { refreshOpLoc() }
        vm.opSessionDeselected.observe(viewLifecycleOwner) { refreshOpLoc() }

        setupButtons()
        binding.tvFreq.setOnClickListener { showFreqDirectInput() }
        binding.tvFreq.setOnLongClickListener {
            MemoryDialogFragment.newInstance(fromRtty = true)
                .show(parentFragmentManager, "rtty_memory")
            true
        }
        binding.btnFreqDown.setOnClickListener {
            val f = vm.sharedFreq.value ?: 0L; if (f > 0L) vm.sendFreq(f - 100L)
        }
        binding.btnFreqUp.setOnClickListener {
            val f = vm.sharedFreq.value ?: 0L; if (f > 0L) vm.sendFreq(f + 100L)
        }

        // Waterfall: show initial markers, wire touch → update modem decode frequency
        binding.rttyWaterfall.setMarkers(lastMarkHz, lastSpaceHz)
        binding.rttyWaterfall.onDecodeFreqSelected = { mark, space ->
            // Only in Fix mode. In Tune mode the auto-tuner owns the decode position and
            // would immediately override a tap.
            if (tuneFixed) {
                lastMarkHz = mark; lastSpaceHz = space
                modem?.updateFrequencies(mark, space)
                binding.rttyWaterfall.setMarkers(mark, space)
                updateTuneButton()
                updateStatus("FIX: ${mark.toInt()} / ${space.toInt()} Hz")
            } else {
                updateStatus(getString(R.string.rtty_1))
            }
        }
        updateTuneButton()

        // Set rig to RTTY mode on entry
        applyRigMode()

        // RTTY RX は Pi の RX SSE(共有キャプチャ _mgr_sub)からスペクトラムも受け取るので、別系統の
        // 音声モニタ(:50000)は使わない。動いていると minimodem のキャプチャと同じ CODEC を奪い合うため、
        // 入っていれば止めてデバイスを解放する。
        rttyStartedAudio = false
        // RTTY's own SSE owns the Pi capture while this screen is up. Mark the screen active BEFORE
        // stopping /radio/audio so the SPK watchdog won't immediately restart it (which would steal the
        // capture and leave the waterfall blank when SPK was ON — the "SPKをOFFにしてからだと大丈夫" case).
        vm.rttyFragmentActive = true
        if (vm.audio.isStreamActive) vm.stopAudio()

        // PO / ALC meters
        setupRttyPoMeter()
        setupRttyAlcMeter()
        vm.sharedRfOut.observe(viewLifecycleOwner) { updateRttyPoMeter(it) }
        vm.sharedAlc.observe(viewLifecycleOwner) { updateRttyAlcMeter(it) }

        // Start receiver
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED) {
            startRx()
        } else {
            recordPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    override fun onResume() {
        super.onResume()
        requireActivity().window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onPause() {
        super.onPause()
        requireActivity().window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        vm.rttyFragmentActive = false   // leaving RTTY: let the SPK watchdog manage /radio/audio again
        stopRx()
        cancelTx()
        stopCqRepeat()
        if (pttActive) vm.setPttEnabled(false)
        // Stop Pi audio only if RTTY started it (SPK was off)
        if (rttyStartedAudio && vm.spkEnabled.value != true) {
            vm.audio.stop()
            rttyStartedAudio = false
        }
        // Only when genuinely leaving RTTY (not a rotation / config change): move the dial back so
        // the restored main-screen frequency equals what the RTTY screen was showing, then restore
        // the previous mode. sendMode re-sends the frequency after the mode change, so set the
        // corrected frequency first.
        if (activity?.isChangingConfigurations != true) {
            val pre = vm.rttyPreMode
            if (pre.isNotEmpty()) {
                val d = vm.sharedFreq.value ?: 0L
                if (d > 0L) vm.sendFreq(dialToRtty(d))
                vm.sendMode(pre, vm.rttyPreWidth)
            }
            vm.rttyAnchorActive = false
        }
        _binding = null
    }

    // --- UI setup ---

    private fun setupButtons() {
        binding.btnBack.setOnClickListener { findNavController().popBackStack() }

        binding.btnRttyR.setOnClickListener {
            isRttyR = !isRttyR
            binding.btnRttyR.text = if (isRttyR) "RTTYR" else "RTTY"
            applyRigMode()                                   // LSB⇄USB
            updateFreqDisplay(vm.sharedFreq.value ?: 0L)     // オフセット符号が反転するので表示更新
            binding.rttyWaterfall.setMarkers(RttyModem.TX_MARK_HZ, RttyModem.TX_SPACE_HZ)
            stopRx(); startRx()                              // minimodem の mark/space を入れ替えて張り直し
            updateStatus(if (isRttyR) "RTTYR" else "RTTY")
        }

        binding.btnBaud.setOnClickListener {
            // Future: baud rate selection. For now toggle 45.45 / 75
            val newBaud = if (modem?.baudRate == 45.45) 75.0 else 45.45
            restartModem(newBaud)
            binding.btnBaud.text = if (newBaud == 45.45) "45.45bd" else "75bd"
        }

        binding.btnClear.setOnClickListener {
            rxSpan.clear()
            binding.tvRx.text = ""
        }

        // TX amplitude slider (progress 0–99 → amplitude 1%–100%)
        binding.seekTxGain.progress = ((vm.prefs.rttyTxAmplitude(currentRigId(), bandKey()) * 100).toInt() - 1).coerceIn(0, 99)
        binding.seekTxGain.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    val amp = (p + 1) / 100f
                    vm.prefs.setRttyTxAmplitude(currentRigId(), bandKey(), amp)
                    if (_binding != null) binding.btnTxGain.text = "${p + 1}%"
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        setupCwStylePanel()
        binding.btnTx.setOnClickListener  { startTx(binding.etTx.text.toString().trim()) }
        binding.btnTx2.setOnClickListener { startTx(binding.etTx.text.toString().trim(), txCount = 2) }
        binding.btnLog.setOnClickListener {
            val callsign = binding.etDxCall.text.toString().trim().uppercase()
            val rstSent  = binding.etMyRst.text.toString().trim().ifEmpty { "599" }
            val rstRcvd  = binding.etRst.text.toString().trim().ifEmpty { "599" }
            val pota     = binding.etPota.text.toString().trim().uppercase()
            LogQsoDialogFragment.newInstance(
                callsign = callsign, pota = pota, rstSent = rstSent, rstRcvd = rstRcvd,
                freqHzOverride = dialToRtty(vm.sharedFreq.value ?: 0L),  // AFSK補正: 本来のRTTY周波数で記録
                modeOverride = "RTTY"                                    // リグが LSB/USB(AFSK) でもログは RTTY で記録
            ).show(parentFragmentManager, "rtty_log")
        }
        binding.btnStop.setOnClickListener {
            stopCqRepeat()
            cancelTx()
        }
        parentFragmentManager.setFragmentResultListener("memory_freq_for_rtty", viewLifecycleOwner) { _, _ ->
            // Frequency was set by MEMSET; reassert RTTY mode so the band switch doesn't escape
            applyRigMode()
        }
        parentFragmentManager.setFragmentResultListener("memory_nav_from_rtty", viewLifecycleOwner) { _, _ ->
            // MEM recall already set the final freq+mode directly (not in RTTY dial space),
            // so suppress both the mode restore and the dial shift-back on exit.
            vm.rttyPreMode = ""
            vm.rttyAnchorActive = false
            findNavController().popBackStack()
        }
        // Tune 短押し: 今すぐ検出ピークを 2125 へ。長押し: 自動追従の固定(FIX)ON/OFF。
        binding.btnTune.setOnClickListener { applyTune() }
        binding.btnTune.setOnLongClickListener { toggleTuneFixed(); true }

        // SPK: 受信音をスマホから再生(ON/OFF)。切替で SSE を張り直し(audio要求を変える)。
        updateSpkButton()
        binding.btnRttySpk.setOnClickListener {
            rttySpk = !rttySpk
            updateSpkButton()
            stopRx(); startRx()
        }
        // ウォーターフォールをタップ: その位置の信号をリグ周波数で 2125(デコード位置)へ寄せる。
        binding.rttyWaterfall.setOnClickListener { /* performClick 用 */ }
        binding.rttyWaterfall.setOnTouchListener { v, e ->
            if (e.action == android.view.MotionEvent.ACTION_UP) {
                v.performClick()
                tuneAudioToMark(binding.rttyWaterfall.xToFreq(e.x))
            }
            true
        }

        for ((btn, hz) in listOf(
            binding.btnShiftMinus20 to -20.0,
            binding.btnShiftMinus5  to  -5.0,
            binding.btnShiftPlus5   to   5.0,
            binding.btnShiftPlus20  to  20.0
        )) {
            btn.setOnClickListener { shiftFreq(hz) }
        }

        binding.btnPtt.setOnClickListener {
            if (txJob?.isActive == true) {
                cancelTx()
            } else {
                toggleManualPtt()
            }
        }

        binding.etTx.setOnEditorActionListener { _, _, _ -> startTx(binding.etTx.text.toString().trim()); true }

        // Power button
        val updatePowerBtn = {
            val pct = ((vm.sharedPower.value ?: 0f) * 100).toInt()
            binding.btnRttyPower.text = if (pct > 0) "${pct}%" else "---"
        }
        updatePowerBtn()
        vm.sharedPower.observe(viewLifecycleOwner) { updatePowerBtn() }
        binding.btnRttyPower.setOnClickListener { showPowerDialog() }
        binding.btnRttyPowerDown.setOnClickListener {
            val cur = ((vm.sharedPower.value ?: 0f) * 100).toInt()
            val next = ((cur - 5).coerceAtLeast(5) / 100f)
            vm.sendPower(next)
        }
        binding.btnRttyPowerUp.setOnClickListener {
            val cur = ((vm.sharedPower.value ?: 0f) * 100).toInt()
            val next = ((cur + 5).coerceAtMost(100) / 100f)
            vm.sendPower(next)
        }
    }

    // --- CW-style panel setup ---

    private fun setupCwStylePanel() {
        val prefs = vm.prefs

        // Restore persisted values into fields
        binding.etDxCall.setText(prefs.rttyDxCall)
        binding.etRst.setText(prefs.rttyRst)
        binding.etMyRst.setText(prefs.rttyMyRst)
        binding.etPota.setText(prefs.rttyPota)
        binding.etJcc.setText(prefs.rttyJcc)

        // Persist field changes
        binding.etDxCall.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) prefs.rttyDxCall = binding.etDxCall.text.toString().trim().uppercase() }
        binding.etRst.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) prefs.rttyRst = binding.etRst.text.toString().trim() }
        // RST の変更を UR ボタンのプレビューへ即反映(プリセット/手入力/クリア/×n すべて)
        binding.etRst.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { refreshUrButton() }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        binding.etMyRst.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) prefs.rttyMyRst = binding.etMyRst.text.toString().trim() }
        binding.etPota.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) prefs.rttyPota = binding.etPota.text.toString().trim().uppercase() }
        binding.etJcc.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) prefs.rttyJcc = binding.etJcc.text.toString().trim() }

        // Clear buttons
        binding.btnDxClear.setOnClickListener { binding.etDxCall.setText(""); prefs.rttyDxCall = "" }
        binding.btnRstClear.setOnClickListener { binding.etRst.setText(""); prefs.rttyRst = "599" }
        binding.btnMyRstClear.setOnClickListener { binding.etMyRst.setText(""); prefs.rttyMyRst = "599" }
        binding.btnPotaClear.setOnClickListener { binding.etPota.setText(""); prefs.rttyPota = "" }
        binding.btnJccClear.setOnClickListener { binding.etJcc.setText(""); prefs.rttyJcc = "" }

        // RST presets (their RST)
        for ((btn, value) in listOf(
            binding.btnRst519 to "519", binding.btnRst529 to "529",
            binding.btnRst539 to "539", binding.btnRst549 to "549",
            binding.btnRst559 to "559", binding.btnRst569 to "569",
            binding.btnRst579 to "579", binding.btnRst589 to "589",
            binding.btnRst599 to "599"
        )) { btn.setOnClickListener { binding.etRst.setText(value); prefs.rttyRst = value } }

        // My RST presets
        for ((btn, value) in listOf(
            binding.btnMyRst519 to "519", binding.btnMyRst529 to "529",
            binding.btnMyRst539 to "539", binding.btnMyRst549 to "549",
            binding.btnMyRst559 to "559", binding.btnMyRst569 to "569",
            binding.btnMyRst579 to "579", binding.btnMyRst589 to "589",
            binding.btnMyRst599 to "599"
        )) { btn.setOnClickListener { binding.etMyRst.setText(value); prefs.rttyMyRst = value } }

        // CQ/ANS tab
        fun selectTab(cq: Boolean) {
            binding.panelCq.visibility = if (cq) View.VISIBLE else View.GONE
            binding.panelAns.visibility = if (!cq) View.VISIBLE else View.GONE
            binding.btnTabCq.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (cq) 0xFF2A2000.toInt() else 0xFF1A1A1A.toInt())
            binding.btnTabCq.setTextColor(if (cq) 0xFFFFDD44.toInt() else 0xFF888888.toInt())
            binding.btnTabAns.backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (!cq) 0xFF002A2A.toInt() else 0xFF1A1A1A.toInt())
            binding.btnTabAns.setTextColor(if (!cq) 0xFF80CBC4.toInt() else 0xFF888888.toInt())
        }
        binding.btnTabCq.setOnClickListener { selectTab(true) }
        binding.btnTabAns.setOnClickListener { selectTab(false) }
        selectTab(true)

        // ---- CQ panel ----
        // Call repeat selector
        fun selectCqRepeat(n: Int) {
            prefs.rttyCqRepeat = n
            val active = 0xFF1A2A1A.toInt(); val idle = 0xFF1A1A1A.toInt()
            binding.btnCqCall1.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 1) active else idle)
            binding.btnCqCall2.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 2) active else idle)
            binding.btnCqCall3.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 3) active else idle)
            refreshCqButton()
        }
        binding.btnCqCall1.setOnClickListener { selectCqRepeat(1) }
        binding.btnCqCall2.setOnClickListener { selectCqRepeat(2) }
        binding.btnCqCall3.setOnClickListener { selectCqRepeat(3) }
        selectCqRepeat(prefs.rttyCqRepeat.coerceIn(1, 3))

        refreshCqButton()

        // Greeting selector (shared CQ+ANS)
        fun selectGreeting(g: String) {
            prefs.rttyGreeting = g
            val active = 0xFF1A2A1A.toInt(); val idle = 0xFF1A1A1A.toInt()
            for ((btn, v) in listOf(
                binding.btnGreetNone to "", binding.btnGreetGm to "GM",
                binding.btnGreetGe to "GE", binding.btnGreetGa to "GA",
                binding.btnAnsGreetNone to "", binding.btnAnsGreetGm to "GM",
                binding.btnAnsGreetGe to "GE", binding.btnAnsGreetGa to "GA"
            )) {
                btn.backgroundTintList = android.content.res.ColorStateList.valueOf(if (v == g) active else idle)
                btn.setTextColor(if (v == g) 0xFFFFFFFF.toInt() else 0xFF888888.toInt())
            }
            refreshUrButton()
        }
        binding.btnGreetNone.setOnClickListener { selectGreeting("") }
        binding.btnGreetGm.setOnClickListener { selectGreeting("GM") }
        binding.btnGreetGe.setOnClickListener { selectGreeting("GE") }
        binding.btnGreetGa.setOnClickListener { selectGreeting("GA") }
        binding.btnAnsGreetNone.setOnClickListener { selectGreeting("") }
        binding.btnAnsGreetGm.setOnClickListener { selectGreeting("GM") }
        binding.btnAnsGreetGe.setOnClickListener { selectGreeting("GE") }
        binding.btnAnsGreetGa.setOnClickListener { selectGreeting("GA") }
        selectGreeting(prefs.rttyGreeting)

        // QSL selector (shared CQ+ANS)
        fun selectQsl(q: String) {
            prefs.rttyQsl = q
            val active = 0xFF1A2A1A.toInt(); val idle = 0xFF1A1A1A.toInt()
            for ((btn, v) in listOf(
                binding.btnQslNone to "", binding.btnQslPse to "PSE QSL", binding.btnQslNo to "NO QSL",
                binding.btnAnsQslNone to "", binding.btnAnsQslPse to "PSE QSL", binding.btnAnsQslNo to "NO QSL"
            )) {
                btn.backgroundTintList = android.content.res.ColorStateList.valueOf(if (v == q) active else idle)
                btn.setTextColor(if (v == q) 0xFFFFFFFF.toInt() else 0xFF888888.toInt())
            }
            refreshUrButton()
        }
        binding.btnQslNone.setOnClickListener { selectQsl("") }
        binding.btnQslPse.setOnClickListener { selectQsl("PSE QSL") }
        binding.btnQslNo.setOnClickListener { selectQsl("NO QSL") }
        binding.btnAnsQslNone.setOnClickListener { selectQsl("") }
        binding.btnAnsQslPse.setOnClickListener { selectQsl("PSE QSL") }
        binding.btnAnsQslNo.setOnClickListener { selectQsl("NO QSL") }
        selectQsl(prefs.rttyQsl)

        // RST repeat (CQ panel) — both CQ and ANS panels share the same prefs value
        fun selectRstRep(n: Int) {
            prefs.rttyRstRepeat = n
            val active = 0xFF1A2A1A.toInt(); val idle = 0xFF1A1A1A.toInt()
            binding.btnRstRep1.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 1) active else idle)
            binding.btnRstRep1.setTextColor(if (n == 1) 0xFFFFFFFF.toInt() else 0xFF888888.toInt())
            binding.btnRstRep2.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 2) active else idle)
            binding.btnRstRep2.setTextColor(if (n == 2) 0xFFFFFFFF.toInt() else 0xFF888888.toInt())
            binding.btnRstRep3.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 3) active else idle)
            binding.btnRstRep3.setTextColor(if (n == 3) 0xFFFFFFFF.toInt() else 0xFF888888.toInt())
            binding.btnAnsRstRep1.backgroundTintList = binding.btnRstRep1.backgroundTintList
            binding.btnAnsRstRep1.setTextColor(binding.btnRstRep1.currentTextColor)
            binding.btnAnsRstRep2.backgroundTintList = binding.btnRstRep2.backgroundTintList
            binding.btnAnsRstRep2.setTextColor(binding.btnRstRep2.currentTextColor)
            binding.btnAnsRstRep3.backgroundTintList = binding.btnRstRep3.backgroundTintList
            binding.btnAnsRstRep3.setTextColor(binding.btnRstRep3.currentTextColor)
            refreshUrButton()   // UR ボタンのプレビューに RST 繰り返しを反映(599 599 等)
        }
        binding.btnRstRep1.setOnClickListener { selectRstRep(1) }
        binding.btnRstRep2.setOnClickListener { selectRstRep(2) }
        binding.btnRstRep3.setOnClickListener { selectRstRep(3) }
        binding.btnAnsRstRep1.setOnClickListener { selectRstRep(1) }
        binding.btnAnsRstRep2.setOnClickListener { selectRstRep(2) }
        binding.btnAnsRstRep3.setOnClickListener { selectRstRep(3) }
        selectRstRep(prefs.rttyRstRepeat.coerceIn(1, 3))

        // Loop count selector
        fun selectLoopCount(n: Int) {
            prefs.rttyCqLoopCount = n
            val active = 0xFF1A2A1A.toInt(); val idle = 0xFF1A1A1A.toInt()
            binding.btnLoop3.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 3) active else idle)
            binding.btnLoop5.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 5) active else idle)
            binding.btnLoop10.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 10) active else idle)
            binding.btnLoopInf.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 0) active else idle)
        }
        binding.btnLoop3.setOnClickListener { selectLoopCount(3) }
        binding.btnLoop5.setOnClickListener { selectLoopCount(5) }
        binding.btnLoop10.setOnClickListener { selectLoopCount(10) }
        binding.btnLoopInf.setOnClickListener { selectLoopCount(0) }
        selectLoopCount(prefs.rttyCqLoopCount)

        // Interval selector
        fun selectInterval(s: Int) {
            prefs.rttyCqLoopInterval = s
            val active = 0xFF1A2A1A.toInt(); val idle = 0xFF1A1A1A.toInt()
            binding.btnInt10.backgroundTintList = android.content.res.ColorStateList.valueOf(if (s == 10) active else idle)
            binding.btnInt15.backgroundTintList = android.content.res.ColorStateList.valueOf(if (s == 15) active else idle)
            binding.btnInt30.backgroundTintList = android.content.res.ColorStateList.valueOf(if (s == 30) active else idle)
            binding.btnInt60.backgroundTintList = android.content.res.ColorStateList.valueOf(if (s == 60) active else idle)
        }
        binding.btnInt10.setOnClickListener { selectInterval(10) }
        binding.btnInt15.setOnClickListener { selectInterval(15) }
        binding.btnInt30.setOnClickListener { selectInterval(30) }
        binding.btnInt60.setOnClickListener { selectInterval(60) }
        selectInterval(prefs.rttyCqLoopInterval)

        // TX amplitude button
        val ampPct = (prefs.rttyTxAmplitude(currentRigId(), bandKey()) * 100).toInt()
        binding.btnTxGain.text = "$ampPct%"
        binding.btnTxGain.setOnClickListener { showAmplitudeDialog() }

        // Carrier calibration button (per-rig per-band offset)
        binding.btnRttyCalibration.setOnClickListener { showCarrierCalibrationDialog() }

        // Assembled message buttons
        binding.btnCq.setOnClickListener { startTx(buildCqText()) }
        binding.btnCq.setOnLongClickListener { fillTxField(buildCqText()); true }

        binding.btnCqDxK.setOnClickListener {
            val dx = binding.etDxCall.text.toString().trim().uppercase().ifEmpty { "?" }
            startTx("$dx K")
        }
        binding.btnCqDxK.setOnLongClickListener {
            val dx = binding.etDxCall.text.toString().trim().uppercase().ifEmpty { "?" }
            fillTxField("$dx K"); true
        }
        binding.btnCqDxDeMyK.setOnClickListener {
            val dx = binding.etDxCall.text.toString().trim().uppercase().ifEmpty { "?" }
            val my = myCall
            startTx("$dx DE $my K")
        }
        binding.btnCqDxDeMyK.setOnLongClickListener {
            val dx = binding.etDxCall.text.toString().trim().uppercase().ifEmpty { "?" }
            val my = myCall
            fillTxField("$dx DE $my K"); true
        }
        binding.btnCqUr.setOnClickListener { startTx(buildUrText()) }
        binding.btnCqUr.setOnLongClickListener { fillTxField(buildUrText()); true }
        binding.btnCqTu.setOnClickListener { startTx("TU TU 73 E E") }
        binding.btnCqTu.setOnLongClickListener { fillTxField("TU TU 73 E E"); true }
        binding.btnCqAgn.setOnClickListener { startTx("PSE AGN") }
        binding.btnCqAgn.setOnLongClickListener { fillTxField("PSE AGN"); true }
        binding.btnCq73.setOnClickListener { startTx("73 DE $myCall K") }
        binding.btnCq73.setOnLongClickListener { fillTxField("73 DE $myCall K"); true }
        binding.btnCqQrz.setOnClickListener { startTx("QRZ? DE $myCall K") }
        binding.btnCqQrz.setOnLongClickListener { fillTxField("QRZ? DE $myCall K"); true }

        binding.btnAnsMyK.setOnClickListener {
            val my = myCall
            val repeat = prefs.rttyAnsCallRepeat.coerceIn(1, 3)
            startTx((1..repeat).joinToString(" ") { my } + " K")
        }
        binding.btnAnsMyK.setOnLongClickListener {
            val my = myCall
            val repeat = prefs.rttyAnsCallRepeat.coerceIn(1, 3)
            fillTxField((1..repeat).joinToString(" ") { my } + " K"); true
        }
        binding.btnAnsDxDeMyK.setOnClickListener {
            val dx = binding.etDxCall.text.toString().trim().uppercase().ifEmpty { "?" }
            val my = myCall
            val repeat = prefs.rttyAnsCallRepeat.coerceIn(1, 3)
            startTx("$dx DE " + (1..repeat).joinToString(" ") { my } + " K")
        }
        binding.btnAnsDxDeMyK.setOnLongClickListener {
            val dx = binding.etDxCall.text.toString().trim().uppercase().ifEmpty { "?" }
            val my = myCall
            val repeat = prefs.rttyAnsCallRepeat.coerceIn(1, 3)
            fillTxField("$dx DE " + (1..repeat).joinToString(" ") { my } + " K"); true
        }
        binding.btnAnsUr.setOnClickListener { startTx(buildUrText()) }
        binding.btnAnsUr.setOnLongClickListener { fillTxField(buildUrText()); true }
        binding.btnAnsTu.setOnClickListener { startTx("TU TU 73 E E") }
        binding.btnAnsTu.setOnLongClickListener { fillTxField("TU TU 73 E E"); true }
        binding.btnAnsAgn.setOnClickListener { startTx("PSE AGN") }
        binding.btnAnsAgn.setOnLongClickListener { fillTxField("PSE AGN"); true }
        binding.btnAns73.setOnClickListener { startTx("73 DE $myCall K") }
        binding.btnAns73.setOnLongClickListener { fillTxField("73 DE $myCall K"); true }
        binding.btnAnsQsl.setOnClickListener { startTx("QSL QSL") }
        binding.btnAnsQsl.setOnLongClickListener { fillTxField("QSL QSL"); true }

        // Show actual callsign on buttons
        val mc = myCall
        binding.btnCqDxDeMyK.text = "{dx}DE $mc K"
        binding.btnCq73.text = "73 DE $mc K"
        binding.btnCqQrz.text = "QRZ? DE $mc K"
        binding.btnAnsMyK.text = "$mc K"
        binding.btnAnsDxDeMyK.text = "{dx}DE $mc K"
        binding.btnAns73.text = "73 DE $mc K"

        // CQ REPEAT
        binding.btnCqRepeat.setOnClickListener {
            if (cqRepeatJob?.isActive == true) {
                stopCqRepeat()
            } else {
                startCqRepeat()
            }
        }

        // ANS MyCall repeat count (×1 / ×2 / ×3)
        fun selectAnsCallRepeat(n: Int) {
            prefs.rttyAnsCallRepeat = n
            val active = 0xFF1A2A1A.toInt(); val idle = 0xFF1A1A1A.toInt()
            binding.btnAnsCallRep1.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 1) active else idle)
            binding.btnAnsCallRep2.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 2) active else idle)
            binding.btnAnsCallRep3.backgroundTintList = android.content.res.ColorStateList.valueOf(if (n == 3) active else idle)
            val mc = myCall
            val callPart = (1..n).joinToString(" ") { mc }
            binding.btnAnsMyK.text = "$callPart K"
            val dx = binding.etDxCall.text.toString().trim().uppercase().ifEmpty { "{dx}" }
            binding.btnAnsDxDeMyK.text = "$dx DE $callPart K"
        }
        binding.btnAnsCallRep1.setOnClickListener { selectAnsCallRepeat(1) }
        binding.btnAnsCallRep2.setOnClickListener { selectAnsCallRepeat(2) }
        binding.btnAnsCallRep3.setOnClickListener { selectAnsCallRepeat(3) }
        selectAnsCallRepeat(prefs.rttyAnsCallRepeat.coerceIn(1, 3))
    }

    private fun fillTxField(text: String) {
        binding.etTx.setText(text)
        binding.etTx.setSelection(text.length)
        binding.etTx.requestFocus()
    }

    private fun buildCqText(): String {
        val my = myCall
        val repeat = vm.prefs.rttyCqRepeat.coerceIn(1, 3)
        val callPart = (1..repeat).joinToString(" ") { my }
        return "CQ CQ CQ DE $callPart K"
    }

    private fun buildUrText(): String {
        val greet = vm.prefs.rttyGreeting
        val rst = binding.etRst.text.toString().trim().ifEmpty { "599" }
        val repeat = vm.prefs.rttyRstRepeat.coerceIn(1, 3)
        val rstPart = (1..repeat).joinToString(" ") { rst }
        val qsl = vm.prefs.rttyQsl
        val extras = if (qsl.isNotEmpty()) qsl else ""
        val my = myCall
        return "${if (greet.isNotEmpty()) "$greet " else ""}UR $rstPart${if (extras.isNotEmpty()) " $extras" else ""} DE $my BK"
    }

    private fun refreshCqButton() {
        binding.btnCq.text = buildCqText()
    }

    /** UR ボタン(CQ/ANS 両パネル)のラベルを現在の挨拶/RST/×n/QSL のプレビューに更新。
     *  RST×2 等が反映されず「599」が1つしか出ない不具合の対策(CQ ボタンと同様に動的更新)。 */
    private fun refreshUrButton() {
        _binding ?: return
        val t = buildUrText()
        binding.btnCqUr.text = t
        binding.btnAnsUr.text = t
    }

    private fun showAmplitudeDialog() {
        val rigId = currentRigId()
        val band  = bandKey()
        val seekBar = android.widget.SeekBar(requireContext()).apply {
            max = 99  // 1% to 100% in 1% steps
            progress = ((vm.prefs.rttyTxAmplitude(rigId, band) * 100).toInt() - 1).coerceIn(0, 99)
        }
        val label = android.widget.TextView(requireContext()).apply {
            text = "TX Gain: ${(vm.prefs.rttyTxAmplitude(rigId, band) * 100).toInt()}%"
            textSize = 14f
            setPadding(48, 16, 48, 8)
        }
        seekBar.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar, p: Int, u: Boolean) {
                label.text = "TX Gain: ${p + 1}%"
            }
            override fun onStartTrackingTouch(sb: android.widget.SeekBar) {}
            override fun onStopTrackingTouch(sb: android.widget.SeekBar) {}
        })
        val layout = android.widget.LinearLayout(requireContext()).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            addView(label)
            addView(seekBar.also { it.setPadding(48, 0, 48, 16) })
        }
        android.app.AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.rtty_2))
            .setView(layout)
            .setPositiveButton("OK") { _, _ ->
                val amp = ((seekBar.progress + 1) / 100f).coerceIn(0.01f, 1.00f)
                vm.prefs.setRttyTxAmplitude(rigId, band, amp)
                val pct = (amp * 100).toInt()
                binding.btnTxGain.text = "$pct%"
                binding.seekTxGain.progress = (pct - 1).coerceIn(0, 99)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showCarrierCalibrationDialog() {
        val rigId = currentRigId()
        val ctx = requireContext()
        val dp = resources.displayMetrics.density

        fun makeRow(labelText: String, initialHz: Int): Triple<android.widget.LinearLayout, android.widget.TextView, IntArray> {
            val current = intArrayOf(initialHz)
            val valueView = android.widget.TextView(ctx).apply {
                text = "${if (current[0] >= 0) "+" else ""}${current[0]} Hz"
                textSize = 14f
                setTextColor(0xFFFFFFFF.toInt())
                gravity = android.view.Gravity.CENTER
                minWidth = (72 * dp).toInt()
            }
            val btnMinus = android.widget.Button(ctx).apply {
                text = "−20"
                textSize = 11f
                minWidth = 0; minimumWidth = 0
            }
            val btnPlus = android.widget.Button(ctx).apply {
                text = "+20"
                textSize = 11f
                minWidth = 0; minimumWidth = 0
            }
            fun refresh() { valueView.text = "${if (current[0] >= 0) "+" else ""}${current[0]} Hz" }
            btnMinus.setOnClickListener { current[0] -= 20; refresh() }
            btnPlus.setOnClickListener  { current[0] += 20; refresh() }
            val label = android.widget.TextView(ctx).apply {
                text = labelText; textSize = 13f
                setTextColor(0xFFAAAAAA.toInt())
                minWidth = (60 * dp).toInt()
            }
            val row = android.widget.LinearLayout(ctx).apply {
                orientation = android.widget.LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding((16 * dp).toInt(), (6 * dp).toInt(), (16 * dp).toInt(), (6 * dp).toInt())
                addView(label)
                addView(btnMinus)
                addView(valueView)
                addView(btnPlus)
            }
            return Triple(row, valueView, current)
        }

        val (rowHf,  _, curHf)  = makeRow("HF (< 50MHz)",  vm.prefs.rttyDataShiftOffset(rigId, "Hf"))
        val (row50,  _, cur50)  = makeRow("50 MHz",         vm.prefs.rttyDataShiftOffset(rigId, "50"))
        val (row144, _, cur144) = makeRow("144 MHz",        vm.prefs.rttyDataShiftOffset(rigId, "144"))
        val (row430, _, cur430) = makeRow("430 MHz",        vm.prefs.rttyDataShiftOffset(rigId, "430"))

        val note = android.widget.TextView(ctx).apply {
            text = getString(R.string.rtty_3)
            textSize = 11f
            setTextColor(0xFF888888.toInt())
            setPadding((16 * dp).toInt(), (4 * dp).toInt(), (16 * dp).toInt(), (8 * dp).toInt())
        }
        val layout = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            addView(rowHf); addView(row50); addView(row144); addView(row430); addView(note)
        }
        android.app.AlertDialog.Builder(ctx)
            .setTitle(getString(R.string.rtty_4))
            .setView(layout)
            .setPositiveButton("OK") { _, _ ->
                vm.prefs.setRttyDataShiftOffset(rigId, "Hf",  curHf[0])
                vm.prefs.setRttyDataShiftOffset(rigId, "50",  cur50[0])
                vm.prefs.setRttyDataShiftOffset(rigId, "144", cur144[0])
                vm.prefs.setRttyDataShiftOffset(rigId, "430", cur430[0])
            }
            .setNeutralButton(getString(R.string.rtty_5)) { _, _ ->
                vm.prefs.setRttyDataShiftOffset(rigId, "Hf",  0)
                vm.prefs.setRttyDataShiftOffset(rigId, "50",  0)
                vm.prefs.setRttyDataShiftOffset(rigId, "144", 0)
                vm.prefs.setRttyDataShiftOffset(rigId, "430", 0)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun startCqRepeat() {
        val text = buildCqText()
        val loopCount = vm.prefs.rttyCqLoopCount  // 0 = ∞
        val intervalMs = vm.prefs.rttyCqLoopInterval * 1000L
        var sent = 0
        cqRepeatJob = lifecycleScope.launch(Dispatchers.Main) {
            binding.btnCqRepeat.text = "■ STOP CQ"
            binding.btnCqRepeat.backgroundTintList = android.content.res.ColorStateList.valueOf(0xFFB71C1C.toInt())
            while (loopCount == 0 || sent < loopCount) {
                sent++
                val countStr = if (loopCount == 0) "∞" else "$sent/$loopCount"
                binding.tvCqRepeatStatus.text = "CQ $countStr…"
                startTx(text)
                // Wait for TX to complete
                while (txJob?.isActive == true) delay(200)
                if (!isActive) break
                if (loopCount != 0 && sent >= loopCount) break
                // Count down interval
                var remaining = intervalMs / 1000L
                while (remaining > 0 && isActive) {
                    binding.tvCqRepeatStatus.text = getString(R.string.rtty_6, countStr, remaining)
                    delay(1000)
                    remaining--
                }
            }
            stopCqRepeat()
        }
    }

    private fun stopCqRepeat() {
        cqRepeatJob?.cancel()
        cqRepeatJob = null
        if (_binding != null) {
            binding.tvCqRepeatStatus.text = ""
            binding.btnCqRepeat.text = "CQ REPEAT"
            binding.btnCqRepeat.backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF2A1A00.toInt())
        }
    }

    // --- PO / ALC meters ---

    private fun setupRttyPoMeter() {
        val ll = _binding?.llRttyPoMeter ?: return
        val dp = resources.displayMetrics.density
        val barH = (10 * dp).toInt()
        val gap  = (2 * dp).toInt()
        ll.removeAllViews()
        repeat(20) {
            val v = android.view.View(requireContext())
            val lp = android.widget.LinearLayout.LayoutParams(0, barH, 1f)
            lp.marginEnd = gap
            v.layoutParams = lp
            ll.addView(v)
        }
    }

    private fun updateRttyPoMeter(value: Float) {
        val ll = _binding?.llRttyPoMeter ?: return
        val bars = ll.childCount
        val active = (value * bars).toInt()
        val color = when {
            value < 0.6f  -> 0xFFFF6D00.toInt()
            value < 0.85f -> 0xFFFDD835.toInt()
            else          -> 0xFFD50000.toInt()
        }
        val dark = 0xFF1A0800.toInt()
        for (i in 0 until bars) {
            ll.getChildAt(i).setBackgroundColor(if (i < active) color else dark)
        }
        _binding?.tvRttyPoValue?.text = "${(value * 100).toInt()}%"
    }

    private fun setupRttyAlcMeter() {
        val ll = _binding?.llRttyAlcMeter ?: return
        val dp = resources.displayMetrics.density
        val barH = (10 * dp).toInt()
        val gap  = (2 * dp).toInt()
        ll.removeAllViews()
        repeat(20) {
            val v = android.view.View(requireContext())
            val lp = android.widget.LinearLayout.LayoutParams(0, barH, 1f)
            lp.marginEnd = gap
            v.layoutParams = lp
            ll.addView(v)
        }
    }

    private fun updateRttyAlcMeter(value: Float) {
        val ll = _binding?.llRttyAlcMeter ?: return
        val bars = ll.childCount
        val active = (value * bars).toInt()
        val color = when {
            value < 0.15f -> 0xFF00C853.toInt()
            value < 0.35f -> 0xFFFDD835.toInt()
            else          -> 0xFFD50000.toInt()
        }
        val dark = 0xFF001A00.toInt()
        for (i in 0 until bars) {
            ll.getChildAt(i).setBackgroundColor(if (i < active) color else dark)
        }
        _binding?.tvRttyAlcValue?.text = "${(value * 100).toInt()}%"
    }

    // --- Rig mode ---

    private fun applyRigMode() {
        // AFSK RTTY: 通常=LSB、RTTYR=USB。送受信とも同じモードなので切替は不要。
        // ※USB音声がTXに乗らない機種はデータモード(PKTLSB/PKTUSB)が必要。その場合は要変更。
        val mode = if (isRttyR) "USB" else "LSB"
        vm.sendMode(mode, 0)
        updateStatus("Mode: $mode (AFSK/minimodem)")
    }

    // --- RX (minimodem via Pi): decoded text + waterfall spectrum, both over one SSE ---

    private fun startRx() {
        android.util.Log.i("RTTYSCOPE", "startRx() audioStreamActive=${vm.audio.isStreamActive} spk=${vm.spkEnabled.value}")
        peakPos = 0
        lastRxDataMs = 0L
        lastSpectrumMs = 0L
        // 復調テキストもウォーターフォール用スペクトラムも、Pi の RX SSE(共有キャプチャ _mgr_sub 由来)から
        // 受け取る。別系統の音声モニタ(:50000)は使わない — 同じ CODEC を minimodem のキャプチャと
        // 奪い合って両方止まるため。
        startRttyRxSse()
        startRxWatchdog()
    }

    /** RX 無データ監視。沈黙が続いたら接続を切って張り直し、経路ごと作り直させる(自動復帰)。 */
    private fun startRxWatchdog() {
        rttyWatchdogJob?.cancel()
        rttyWatchdogJob = lifecycleScope.launch(Dispatchers.IO) {
            while (isActive && _binding != null) {
                delay(2000)
                val now = System.currentTimeMillis()
                val quietMs = now - lastRxDataMs
                val noSpectrumMs = now - lastSpectrumMs
                val transmitting = pttActive || txJob?.isActive == true
                // lastRxDataMs==0 の間はまだ一度も接続成功していない → SSE ループ側の 3 秒リトライに任せる。
                if (lastRxDataMs > 0L && !transmitting &&
                    (quietMs > RX_WATCHDOG_MS || noSpectrumMs > SPECTRUM_WATCHDOG_MS)) {
                    // Either no data at all, OR connected-but-no-spectrum (blank waterfall after CW→RTTY).
                    val why = if (quietMs > RX_WATCHDOG_MS) getString(R.string.rtty_7) else getString(R.string.rtty_8)
                    lastRxDataMs = now; lastSpectrumMs = now   // 再接続でデータが来るまでの連続発火を抑止
                    try { rttySseCall?.cancel() } catch (_: Exception) {}   // forEachLine が抜け→ループが再接続
                    withContext(Dispatchers.Main) { if (_binding != null) updateStatus(getString(R.string.rtty_9, why)) }
                }
            }
        }
    }

    /** Subscribe to the Pi's minimodem RTTY SSE: {"type":"text"} を表示、{"type":"spectrum"} を滝表示。 */
    private fun startRttyRxSse() {
        rttySseJob?.cancel()
        rttySseJob = lifecycleScope.launch(Dispatchers.IO) {
            while (isActive && _binding != null) {
                try {
                    // minimodem decodes at fixed tones; mark/space match the TX tones (RTTYR swaps them).
                    val mark  = (if (isRttyR) RttyModem.TX_SPACE_HZ else RttyModem.TX_MARK_HZ).toInt()
                    val space = (if (isRttyR) RttyModem.TX_MARK_HZ else RttyModem.TX_SPACE_HZ).toInt()
                    val wantAudio = rttySpk
                    val req = Request.Builder().url(vm.api.rttyRxUrl(mark, space, currentBaud, wantAudio))
                        .addHeader("Accept", "text/event-stream")
                        .apply { if (vm.api.apiKey.isNotEmpty()) addHeader("X-API-Key", vm.api.apiKey) }
                        .build()
                    val call = vm.api.sseClient.newCall(req)
                    rttySseCall = call
                    android.util.Log.i("RTTYSCOPE", "SSE connecting url=${vm.api.rttyRxUrl(mark, space, currentBaud, wantAudio)}")
                    val resp = call.execute()
                    if (!resp.isSuccessful) {
                        android.util.Log.w("RTTYSCOPE", "SSE HTTP ${resp.code}")
                        withContext(Dispatchers.Main) { if (_binding != null) updateStatus("RX: HTTP ${resp.code} (Update Pi?)") }
                        resp.close(); delay(3000); continue
                    }
                    android.util.Log.i("RTTYSCOPE", "SSE connected OK")
                    var specCount = 0
                    lastRxDataMs = System.currentTimeMillis()
                    lastSpectrumMs = System.currentTimeMillis()   // start the no-spectrum timer from connect
                    withContext(Dispatchers.Main) { if (_binding != null) updateStatus("RX (minimodem)") }
                    val reader = BufferedReader(InputStreamReader(resp.body!!.byteStream()))
                    reader.forEachLine { line ->
                        lastRxDataMs = System.currentTimeMillis()   // ウォッチドッグ用: データ受信を記録
                        if (!line.startsWith("data: ")) return@forEachLine
                        try {
                            val o = JSONObject(line.removePrefix("data: "))
                            when (o.optString("type")) {
                                "text" -> {
                                    val txt = o.optString("text", "")
                                    if (txt.isNotEmpty()) activity?.runOnUiThread {
                                        if (_binding != null) for (c in txt) appendRx(c)
                                    }
                                }
                                "audio" -> {
                                    // 受信音: base64 PCM(S16LE mono)。AudioTrack.write(MODE_STREAM) はバッファが
                                    // 満ちるまでブロックするため、ここ(SSE読み取りスレッド)で直接 write すると
                                    // text/spectrum の処理が音声の実時間速度に律速され、ウォーターフォールが止まる。
                                    // 専用スレッドのキューへ渡すだけにして読み取りループを決してブロックしない(iOSと同方式)。
                                    val b64 = o.optString("pcm", "")
                                    if (b64.isNotEmpty() && rttySpk) {
                                        val rate = o.optInt("rate", 12000)
                                        try {
                                            val pcm = android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
                                            enqueueRttyAudio(pcm, rate)
                                        } catch (_: Exception) {}
                                    }
                                }
                                "spectrum" -> {
                                    lastSpectrumMs = System.currentTimeMillis()   // no-spectrum watchdog
                                    val arr = o.optJSONArray("pows") ?: return@forEachLine
                                    val pows = DoubleArray(arr.length()) { arr.optDouble(it, 0.0) }
                                    activity?.runOnUiThread {
                                        if (_binding == null) return@runOnUiThread
                                        binding.rttyWaterfall.addRow(pows)            // 表示は毎フレーム(密)
                                        binding.rttyWaterfall.setMarkers(RttyModem.TX_MARK_HZ, RttyModem.TX_SPACE_HZ)
                                        // ピーク検出は直近~8フレーム(≈170ms)の平均で。FSKの両トーンが揃う。
                                        peakAvgRows.addLast(pows)
                                        while (peakAvgRows.size > 8) peakAvgRows.removeFirst()
                                        val avg = DoubleArray(pows.size)
                                        for (row in peakAvgRows) for (i in row.indices) avg[i] += row[i]
                                        for (i in avg.indices) avg[i] /= peakAvgRows.size
                                        updatePeakDisplay(RttyModem.findPeaks(avg))   // detectedMarkHz 更新
                                        autoTuneCheck()                                // 自動追従(FIX中は無効)
                                    }
                                }
                            }
                        } catch (_: Exception) {}
                    }
                    resp.close()
                } catch (e: CancellationException) { break }
                  catch (_: Exception) {}
                if (isActive) delay(3000)
            }
        }
    }

    /** 受信音再生用 AudioTrack を(必要なら)作る。レート変更時は作り直す。 */
    private fun ensureRttyAudioTrack(rate: Int): AudioTrack? {
        rttyAudioTrack?.let { if (it.sampleRate == rate) return it; try { it.stop(); it.release() } catch (_: Exception) {}; rttyAudioTrack = null }
        val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) return null
        val track = AudioTrack(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build(),
            AudioFormat.Builder().setSampleRate(rate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build(),
            maxOf(minBuf * 2, rate), AudioTrack.MODE_STREAM, AudioManager.AUDIO_SESSION_ID_GENERATE)
        track.play()
        rttyAudioTrack = track
        return track
    }

    private fun releaseRttyAudioTrack() {
        rttyAudioTrack?.let { try { it.stop(); it.release() } catch (_: Exception) {} }
        rttyAudioTrack = null
    }

    // --- 受信音の再生スレッド(SSE読み取りをブロックしないための分離) ---
    @Volatile private var rttyAudioRate = 12000
    private val rttyAudioQueue = java.util.concurrent.LinkedBlockingQueue<ByteArray>(64)
    @Volatile private var rttyAudioRunning = false
    private var rttyAudioThread: Thread? = null

    /** SSE読み取りスレッドから呼ぶ: PCM を再生キューへ入れるだけ(ブロックしない)。 */
    private fun enqueueRttyAudio(pcm: ByteArray, rate: Int) {
        rttyAudioRate = rate
        startRttyAudioWriter()
        // キューが満ちたら最古を捨てて最新を優先(遅延の蓄積を防ぐ)。
        if (!rttyAudioQueue.offer(pcm)) {
            rttyAudioQueue.poll()
            rttyAudioQueue.offer(pcm)
        }
    }

    private fun startRttyAudioWriter() {
        if (rttyAudioRunning) return
        rttyAudioRunning = true
        rttyAudioThread = Thread {
            try {
                while (rttyAudioRunning) {
                    val pcm = rttyAudioQueue.poll(200, java.util.concurrent.TimeUnit.MILLISECONDS) ?: continue
                    if (!rttySpk) continue
                    try { ensureRttyAudioTrack(rttyAudioRate)?.write(pcm, 0, pcm.size) } catch (_: Exception) {}
                }
            } catch (_: InterruptedException) {
            } catch (_: Exception) {}
        }.apply { isDaemon = true; name = "rtty-audio"; start() }
    }

    private fun stopRttyAudioWriter() {
        rttyAudioRunning = false
        rttyAudioThread?.let { it.interrupt(); try { it.join(300) } catch (_: Exception) {} }
        rttyAudioThread = null
        rttyAudioQueue.clear()
    }

    private fun updateSpkButton() {
        if (_binding == null) return
        binding.btnRttySpk.setTextColor(if (rttySpk) 0xFF00E676.toInt() else 0xFFAAAAAA.toInt())
        binding.btnRttySpk.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (rttySpk) 0xFF1B5E20.toInt() else 0xFF263238.toInt())
    }

    private fun processForWaterfall(buf: ShortArray, n: Int, sampleRate: Int) {
        var src = 0; var rem = n
        while (rem > 0) {
            val take = minOf(rem, PEAK_BUF_SIZE - peakPos)
            buf.copyInto(peakBuf, peakPos, src, src + take)
            peakPos += take; src += take; rem -= take
            if (peakPos >= PEAK_BUF_SIZE) {
                peakPos = 0
                val snap   = peakBuf.copyOf()
                val sq     = snap.sumOf { it.toDouble() * it.toDouble() }
                val rms    = sqrt(sq / PEAK_BUF_SIZE.toDouble()) / 32768.0
                rxLevelDb  = if (rms > 1e-10) log10(rms).times(20).toInt() else -100
                val powers = RttyModem.scanPowers(snap, PEAK_BUF_SIZE, sampleRate)
                val peaks  = RttyModem.findPeaks(powers)
                lifecycleScope.launch(Dispatchers.Main) {
                    if (_binding == null) return@launch
                    binding.rttyWaterfall.addRow(powers)
                    updatePeakDisplay(peaks)
                    // minimodem は固定トーン(2125/2295)で復調するので、マーカーは固定表示にする。
                    // 信号をそこへ合わせるのは Tune(リグ周波数の自動調整)と ±微調整ボタン。
                    binding.rttyWaterfall.setMarkers(RttyModem.TX_MARK_HZ, RttyModem.TX_SPACE_HZ)
                }
            }
        }
    }

    private fun stopRx() {
        vm.audio.audioSampleListener = null  // stop feeding the waterfall
        rttyWatchdogJob?.cancel(); rttyWatchdogJob = null
        lastRxDataMs = 0L
        lastSpectrumMs = 0L
        rttySseJob?.cancel(); rttySseJob = null
        try { rttySseCall?.cancel() } catch (_: Exception) {}; rttySseCall = null
        peakAvgRows.clear()
        stopRttyAudioWriter()      // 先に再生スレッドを止めてから AudioTrack を解放(作成と解放の競合回避)
        releaseRttyAudioTrack()
        if (usingCivAudio) { vm.civ.rxAudioCallback = null; usingCivAudio = false }
        usingPiAudio = false
        rxJob?.cancel(); rxJob = null
        recorder?.stop(); recorder?.release(); recorder = null
    }

    private fun updatePeakDisplay(peaks: Pair<Double, Double>?) {
        if (_binding == null) return
        val lvl = rxLevelDb.let { if (it > -100) "  ${it}dB" else "" }
        if (peaks != null) {
            detectedMarkHz  = peaks.first
            detectedSpaceHz = peaks.second
            // 整合(2125Hz)まで、ダイヤルをどちら向きに何Hz動かせばよいかを表示。±ボタンのHzに直結し、
            // tuneAudioToMark/AUTO と同じ符号(newFreq = rxFreq ± (mark−2125))なので方向も一致する。
            val delta    = peaks.first - RttyModem.TX_MARK_HZ
            val dialMove = (if (isRttyR) delta else -delta).toInt()
            val hint = when {
                abs(delta) < 2.0                           -> getString(R.string.rtty_10)
                abs(delta) > MAX_TUNE_OFFSET_HZ.toDouble() -> getString(R.string.rtty_11)
                else -> getString(R.string.rtty_12, "${if (dialMove >= 0) "+" else ""}${dialMove}")
            }
            binding.tvPeakFreq.text = "${peaks.first.toInt()} / ${peaks.second.toInt()} Hz$lvl$hint"
        } else {
            // ペア未検出 → 現在ピークを無効化(0)。古い値を残すと AUTO が存在しない古い m に向かって
            // 2.5秒ごとにリグを動かし続け「どんどんずれる」暴走になる。iOS版と同じく 0 にリセットし、
            // ピークが無い/不安定なときは追従しない(autoTuneCheck が m<=0 で早期 return)。
            detectedMarkHz  = 0.0
            detectedSpaceHz = 0.0
            binding.tvPeakFreq.text = "--- / --- Hz$lvl"
        }
        binding.btnTune.isEnabled = true   // 長押しFIX切替のため常に有効
    }

    /** Tune 長押し: 自動追従の固定(FIX)を ON/OFF。FIX中は自動追従せず、周波数はその場に固定。 */
    private fun toggleTuneFixed() {
        tuneFixed = !tuneFixed
        candCount = 0
        updateTuneButton()
        updateStatus(if (tuneFixed) getString(R.string.rtty_13) else getString(R.string.rtty_14))
    }

    private fun updateTuneButton() {
        if (_binding == null) return
        binding.btnTune.text = if (tuneFixed) "FIX" else "AUTO"
        binding.btnTune.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (tuneFixed) 0xFF5A3A00.toInt() else 0xFF1A2A0A.toInt())
        binding.btnTune.isEnabled = true
    }

    /** ±ボタン: リグ周波数を微調整して、信号を固定デコードトーン(2125/2295)へ寄せる。 */
    private fun shiftFreq(deltaHz: Double) {
        val f = vm.sharedFreq.value ?: 0L
        if (f <= 0L) { updateStatus(getString(R.string.rtty_15)); return }
        vm.sendFreq(f + deltaHz.toLong())
        updateStatus(getString(R.string.rtty_16, "${if (deltaHz > 0) "+" else ""}${deltaHz.toInt()}"))
    }

    /**
     * 指定した音声周波数(ウォーターフォール上の信号位置)が固定デコードトーン(2125 Hz)に乗るよう、
     * リグ周波数を動かす。LSB は RF=ダイヤル−音声 なので、高い音声を2125へ下げるにはダイヤルを下げる:
     * dial −= (audioHz − 2125)。RTTYR(USB)は逆符号。
     */
    private fun tuneAudioToMark(audioHz: Double, maxOffsetHz: Long = MAX_TUNE_OFFSET_HZ) {
        val rxFreq = vm.sharedFreq.value ?: 0L
        if (rxFreq <= 0L) { updateStatus(getString(R.string.rtty_15)); return }
        val delta = (audioHz - RttyModem.TX_MARK_HZ).toLong()
        if (abs(delta) < 2) { updateStatus(getString(R.string.rtty_17, audioHz.toInt())); return }
        // これより遠いピークは別信号/ノイズとみなし動かさない(バンドを跨ぐ大ジャンプ防止)。
        // 手動(タップ/Tune)はスキャン窓いっぱい、AUTO連続追従は暴走防止で狭め(呼び出し側で指定)。
        if (abs(delta) > maxOffsetHz) {
            updateStatus(getString(R.string.rtty_18, audioHz.toInt(), maxOffsetHz))
            return
        }
        val newFreq = if (isRttyR) rxFreq + delta else rxFreq - delta
        vm.sendFreq(newFreq)
        updateStatus("Tune: ${audioHz.toInt()}Hz→2125 (${if (delta > 0) "-" else "+"}${abs(delta)}Hz)")
    }

    /** Tune ボタン(短押し): 検出した信号ピークを今すぐ 2125 Hz に合わせる。 */
    private fun applyTune() {
        if (detectedMarkHz <= 0.0) { updateStatus(getString(R.string.rtty_19)); return }
        tuneAudioToMark(detectedMarkHz)
    }

    /**
     * 自動追従: 検出ピークが 2125 Hz から外れていれば、リグ周波数を自動で合わせる。
     * スペクトラム更新ごと(約47/s)に呼ばれるので、ヒステリシスで CAT 連打を防ぐ:
     * ずれ>30Hz、同じピークが連続3フレーム、前回リチューンから2.5秒以上。FIX(ロック)中は何もしない。
     */
    private fun autoTuneCheck() {
        if (tuneFixed) { candCount = 0; return }
        val m = detectedMarkHz
        if (m <= 0.0) { candCount = 0; return }
        // AUTO追従の最大ずれは RIG CONNECT 画面で設定(既定500Hz)。
        val autoMax = vm.prefs.rttyAutoTuneOffsetHz.toLong()
        val off = abs(m - RttyModem.TX_MARK_HZ)
        if (off <= 30.0) { candCount = 0; return }                   // 既に十分近い
        if (off > autoMax.toDouble()) { candCount = 0; return }      // AUTO上限超は別信号とみなし追従しない
        if (abs(m - candMarkHz) <= 25.0) candCount++ else { candMarkHz = m; candCount = 1 }
        val now = System.currentTimeMillis()
        if (candCount >= 3 && now - lastRetuneMs >= 2500L) {
            lastRetuneMs = now; candCount = 0
            tuneAudioToMark(m, autoMax)
            // リグが動く前の古いフレームで再発火してオーバーシュートしないよう、平均バッファと
            // 現在ピークをリセット。次の判定は移動後の新しいスペクトラムだけで行う。
            peakAvgRows.clear()
            detectedMarkHz = 0.0; detectedSpaceHz = 0.0
        }
    }

    private fun restartModem(newBaud: Double) {
        currentBaud = newBaud
        stopRx()
        startRx()
    }

    private fun appendRx(ch: Char) {
        if (_binding == null) return
        if (rxSpan.length > 8000) rxSpan.delete(0, rxSpan.length - 6000)
        val ss = SpannableString(ch.toString())
        ss.setSpan(ForegroundColorSpan(Color.GREEN), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        rxSpan.append(ss)
        binding.tvRx.text = rxSpan
        binding.scrollRx.post { binding.scrollRx.fullScroll(View.FOCUS_DOWN) }
    }

    // --- TX mode ---


    /**
     * The transmit path, always decided automatically: CI-V when the radio is reached
     * directly, otherwise AFSK audio through the Pi.
     *
     * There used to be a selector that also offered serial FSK keying. Neither rig here can
     * use it. The IC-705 has no external FSK shift input, since its USB ports are CDC-ACM, so
     * toggling DTR keys nothing while the Pi still returns HTTP 200. The FT-991A does accept
     * DTR as FSK shift, but the Pi times the keying in software and every DTR change costs a
     * USB control transfer of 15-50 ms against a 22 ms bit period at 45.45 baud. Measured for
     * 27 characters, where 5.3 s was expected: 8.2, 15.1, 18.2, 30.5 s. It also saturated the
     * shared CP2105 and starved rigctld's polling, taking CAT control down for about 16 s each
     * time. There was nothing worth choosing, so the selector is gone.
     */
    private fun resolvedTxMode(): String = if (vm.useCIV.value == true) "civ" else "pi_afsk"

    /**
     * The rig's DATA-mode audio reference tone, in Hz: the audio frequency that its data-mode
     * dial reading actually refers to. Subtracted from the mark offset.
     *
     * The app's model is that in PKTLSB the displayed frequency *is* the suppressed carrier, so
     * an audio tone f lands at `display - f` and the dial has to sit one mark tone above the
     * RTTY mark. That holds on the IC-705, which transmitted RTTY on frequency with no
     * correction at all.
     *
     * The FT-991A's DATA SHIFT menu makes its dial refer to a 1000 Hz audio tone instead of the
     * carrier, the convention PSK31 uses. A tone f therefore lands at `display - f + 1000` and
     * the dial must sit only `2125 - 1000` above the RTTY mark, not the full 2125. The CAT path
     * was already correct when this was found: the frequency read back as exactly the
     * 144.602125 the app asked for, which rules out a control bug and leaves the rig's own
     * shift as the only candidate.
     *
     * The sign was wrong on the first attempt. Adding this value instead of subtracting it made
     * the error larger, which is what settled the direction: the original observation that
     * 144.601 decoded while 144.600 did not was the *receiver* being retuned up to meet a
     * signal already transmitting 1000 Hz high, not the transmitter needing to go up.
     *
     * Setting that menu to 0 on the rig makes this correction unnecessary, and then this should
     * be 0 too.
     */
    private fun currentRigId(): Int =
        (vm.rigList.value ?: emptyList()).getOrNull(vm.selectedRigIndex.value ?: 0)?.id ?: -1

    private fun bandKey(freqHz: Long = vm.sharedFreq.value ?: 0L): String = when {
        freqHz in 50_000_000L..54_000_000L   -> "50"
        freqHz in 144_000_000L..146_000_000L -> "144"
        freqHz in 430_000_000L..440_000_000L -> "430"
        else                                  -> "Hf"
    }

    private fun dataShiftHz(rxFreq: Long = 0L): Long {
        // 表示/記録/入力周波数に効くバンド別キャリア微調整(Hz)。既定は全バンド0。
        // HF は素のLSB(ダイヤル=抑圧搬送波)で固定2125オフセットが正しく合うため基準シフトは持たない。
        // 430 など、リグ内部のバンド依存オフセットで微ずれする分だけ「RTTYキャリア補正」で詰める。
        return vm.prefs.rttyDataShiftOffset(currentRigId(), bandKey(rxFreq)).toLong()
    }

    // --- TX ---

    private fun startTx(text: String, txCount: Int = 1) {
        if (txJob?.isActive == true) return
        if (text.isEmpty()) return

        // Refuse to transmit while the dial is unknown. sharedFreq is 0 whenever the control
        // link has dropped, and a transmission started then went out with no frequency or mode
        // command at all, on whatever the rig happened to be tuned to.
        if ((vm.sharedFreq.value ?: 0L) <= 0L) {
            updateStatus(getString(R.string.rtty_20))
            Toast.makeText(requireContext(), getString(R.string.rtty_21), Toast.LENGTH_SHORT).show()
            return
        }

        val baud  = currentBaud
        // minimodem のデコード/生成トーン。RTTYR はマーク/スペースを入れ替える。
        val mark  = (if (isRttyR) RttyModem.TX_SPACE_HZ else RttyModem.TX_MARK_HZ).toInt()
        val space = (if (isRttyR) RttyModem.TX_MARK_HZ else RttyModem.TX_SPACE_HZ).toInt()
        val body  = if (txCount <= 1) text else (1..txCount).joinToString("  ") { text }

        txJob = lifecycleScope.launch(Dispatchers.IO) {
            stopRx()   // 送信中は SSE 受信を止める
            withContext(Dispatchers.Main) {
                setPttUi(true)
                val txLabel = "\n[TX] $text\n"
                val ss = SpannableString(txLabel)
                ss.setSpan(ForegroundColorSpan(Color.YELLOW), 0, txLabel.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                if (rxSpan.length > 8000 - txLabel.length)
                    rxSpan.delete(0, rxSpan.length - (6000 - txLabel.length).coerceAtLeast(0))
                rxSpan.append(ss)
                binding.tvRx.text = rxSpan
                binding.scrollRx.post { binding.scrollRx.fullScroll(View.FOCUS_DOWN) }
            }
            pttActive = true
            try {
                // Pi 側 minimodem が PTT(T 1)→AFSK送出(aplay)→PTT解除(T 0)まで行う。
                // この呼び出しは送信完了までブロックして返る。モードは applyRigMode で PKTLSB/PKTUSB 済み。
                Log.d("RTTY", "startTx(minimodem): baud=$baud mark=$mark space=$space len=${body.length}")
                val ok = vm.api.rttyTx(body, baud, mark, space)
                if (!ok) withContext(Dispatchers.Main) { if (_binding != null) updateStatus(getString(R.string.rtty_22)) }
            } finally {
                pttActive = false
                withContext(Dispatchers.Main) {
                    if (_binding != null) { setPttUi(false); binding.etTx.text?.clear() }
                }
                startRx()
            }
        }
    }

    private fun cancelTx() {
        txJob?.cancel()
        txJob = null
        if (pttActive) { vm.setPttEnabled(false); pttActive = false }
        lifecycleScope.launch(Dispatchers.Main) { if (_binding != null) setPttUi(false) }
        lifecycleScope.launch(Dispatchers.IO) { startRx() }
    }

    private fun toggleManualPtt() {
        pttActive = !pttActive
        vm.setPttEnabled(pttActive)
        setPttUi(pttActive)
        updateStatus(if (pttActive) "TX (manual PTT)" else "RX")
    }

    private fun setPttUi(tx: Boolean) {
        binding.tvRxTx.text  = if (tx) "TX" else "RX"
        binding.tvRxTx.setTextColor(if (tx) 0xFFFF4444.toInt() else 0xFF44FF44.toInt())
        binding.btnPtt.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (tx) 0xFFD32F2F.toInt() else 0xFF6A1B9A.toInt()
        )
        binding.btnTx.isEnabled  = !tx
        binding.btnTx.alpha      = if (tx) 0.4f else 1.0f
        binding.btnTx2.isEnabled = !tx
        binding.btnTx2.alpha     = if (tx) 0.4f else 1.0f
        binding.btnStop.visibility = if (tx) View.VISIBLE else View.GONE
    }

    // suspend so delay() can wait for all samples to play before releasing the track.
    private suspend fun playAudio(samples: ShortArray, sampleRate: Int) {
        val bufBytes = samples.size * 2
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufBytes)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        track.write(samples, 0, samples.size)
        track.play()
        // Wait for the full message to play out before releasing.
        val durationMs = samples.size.toLong() * 1000L / sampleRate
        delay(durationMs + 200)
        track.stop()
        track.release()
    }

    // --- Power dialog ---

    private fun showPowerDialog() {
        val steps = (0..20).map { it * 5 }
        val cur = ((vm.sharedPower.value ?: 0f) * 100).toInt()
        val idx = steps.indexOfFirst { it >= cur }.coerceAtLeast(0)
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Power (%)")
            .setSingleChoiceItems(steps.map { "$it%" }.toTypedArray(), idx) { dlg, which ->
                val v = steps[which] / 100f
                vm.sendPower(v)
                binding.btnRttyPower.text = "${steps[which]}%"
                dlg.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // --- Frequency dialog ---

    private fun showFreqDirectInput() {
        val ctx = requireContext()
        val current = dialToRtty(vm.sharedFreq.value ?: 0L)  // 表示は本来のRTTY周波数
        val et = android.widget.EditText(ctx).apply {
            hint = getString(R.string.rtty_23)
            if (current > 0) {
                val s = "%.6f".format(current / 1_000_000.0).trimEnd('0').trimEnd('.')
                setText(s)
                selectAll()
            }
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                    android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setPadding(48, 24, 48, 8)
        }
        android.app.AlertDialog.Builder(ctx)
            .setTitle(getString(R.string.rtty_24))
            .setView(et)
            .setPositiveButton("OK") { _, _ ->
                val mhz = et.text.toString().replace(',', '.').toDoubleOrNull()
                // 入力はRTTY周波数。リグへは +2125(LSB) したダイヤルを送る。
                if (mhz != null && mhz > 0) vm.sendFreq(rttyToDial((mhz * 1_000_000 + 0.5).toLong()))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showFreqDialog() {
        val labels = arrayOf(
            "160m   1.838 MHz",
            " 80m   3.535 MHz (JP)", " 80m   3.580 MHz",
            " 40m   7.030 MHz (JP)", " 40m   7.035 MHz",
            " 30m  10.142 MHz",
            " 20m  14.080 MHz",      " 20m  14.090 MHz",
            " 17m  18.102 MHz",
            " 15m  21.080 MHz",
            " 12m  24.920 MHz",
            " 10m  28.080 MHz",
            "  6m  50.300 MHz",
            "  2m 144.600 MHz (JP)", "  2m 144.800 MHz",
            " 70c 430.600 MHz (JP)", " 70c 432.600 MHz"
        )
        val freqs = longArrayOf(
            1_838_000L,
            3_535_000L,  3_580_000L,
            7_030_000L,  7_035_000L,
            10_142_000L,
            14_080_000L, 14_090_000L,
            18_102_000L,
            21_080_000L,
            24_920_000L,
            28_080_000L,
            50_300_000L,
            144_600_000L, 144_800_000L,
            430_600_000L, 432_600_000L
        )
        val current = dialToRtty(vm.sharedFreq.value ?: 0L)  // バンド表はRTTY周波数
        val idx = freqs.indexOfFirst { it == current }.coerceAtLeast(-1)
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("RTTY Band")
            .setSingleChoiceItems(labels, idx) { dialog, which ->
                vm.sendFreq(rttyToDial(freqs[which]))  // RTTY周波数 → ダイヤル(+2125)
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // --- Helpers ---

    private fun updateStatus(msg: String) {
        activity?.runOnUiThread { _binding?.tvStatus?.text = msg }
    }

    // --- AFSK 周波数オフセット補正 ---
    // LSB の AFSK では 表示ダイヤル=抑圧搬送波 で、実際のRTTYマークは ダイヤル−2125Hz に出る。
    // 表示/入力/ログは「本来のRTTYマーク周波数」で扱い、リグへは +2125 したダイヤルを送る。
    // RTTYR(USB)は符号反転。
    private val rttyMarkHz get() = RttyModem.TX_MARK_HZ.toLong()  // 2125
    /** rig dial → 表示用RTTY周波数 (バンド別キャリア補正込み) */
    private fun dialToRtty(dial: Long): Long {
        if (dial <= 0L) return dial
        val ds = dataShiftHz(dial)
        return if (isRttyR) dial + rttyMarkHz + ds else dial - rttyMarkHz + ds
    }
    /** 表示用RTTY周波数 → rig dial (バンド別キャリア補正込み) */
    private fun rttyToDial(rtty: Long): Long {
        if (rtty <= 0L) return rtty
        val ds = dataShiftHz(rtty)
        return if (isRttyR) rtty - rttyMarkHz - ds else rtty + rttyMarkHz - ds
    }

    private fun updateFreqDisplay(hz: Long) {
        if (hz <= 0L) { binding.tvFreq.text = "---.--- MHz"; return }
        val mhz = dialToRtty(hz) / 1_000_000.0
        binding.tvFreq.text = "%,.3f MHz".format(mhz)
    }
}
