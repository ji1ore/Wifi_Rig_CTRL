package com.ji1ore.wifi_rig_ctrl
import com.ji1ore.wifi_rig_ctrl.ui.theme.ThemeApply
import com.ji1ore.wifi_rig_ctrl.ui.theme.UiTheme

import android.app.AlertDialog
import android.content.Context
import android.net.wifi.WifiManager
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.jcraft.jsch.ChannelExec
import com.jcraft.jsch.ChannelSftp
import com.jcraft.jsch.JSch
import com.jcraft.jsch.UserInfo
import com.ji1ore.wifi_rig_ctrl.databinding.FragmentSshSetupBinding
import com.ji1ore.wifi_rig_ctrl.viewmodel.MainViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.util.Properties

class SshSetupFragment : Fragment() {

    private var _binding: FragmentSshSetupBinding? = null
    private val binding get() = _binding!!
    private val vm: MainViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSshSetupBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // ブランド・テーマを画面全体へ適用（中立色のみパレット化・機能色は維持）
        ThemeApply.apply(binding.root, UiTheme.fromIndex(vm.prefs.colorTheme), vm.prefs.dayMode)

        val savedHost = vm.hostName.value ?: ""
        if (savedHost.isNotEmpty()) binding.editSshHost.setText(savedHost)

        // Restore saved VNC desktop flavor (none / xfce / pixel)
        when (vm.prefs.vncDesktop) {
            "none"  -> binding.rbVncNone.isChecked = true
            "pixel" -> binding.rbDesktopPixel.isChecked = true
            else    -> binding.rbDesktopXfce.isChecked = true
        }

        binding.btnSshBack.setOnClickListener { findNavController().navigateUp() }

        binding.btnSearchPi.setOnClickListener { startPiSearch() }

        binding.btnRunSetup.setOnClickListener {
            val host = binding.editSshHost.text.toString().trim()
            val user = binding.editSshUser.text.toString().trim().ifEmpty { "pi" }
            val password = binding.editSshPassword.text.toString()
            val desktop = when {
                binding.rbVncNone.isChecked    -> "none"
                binding.rbDesktopPixel.isChecked -> "pixel"
                else                            -> "xfce"
            }
            vm.prefs.vncDesktop = desktop

            if (host.isEmpty()) {
                binding.tvSshStatus.text = getString(R.string.ssh_1)
                return@setOnClickListener
            }

            binding.btnRunSetup.isEnabled = false
            binding.tvSshStatus.text = getString(R.string.ssh_2, host)
            binding.tvSshLog.text = ""
            // Keep screen on during setup (can take 5-10 min on Pi Zero)
            activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

            lifecycleScope.launch {
                runSshSetup(host, user, password, desktop)
                binding.btnRunSetup.isEnabled = true
                activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }

    private suspend fun runSshSetup(host: String, user: String, password: String, desktop: String) {
        // assets からアップロードするファイル一覧（GitHub 依存を排除し常に最新版を使用）
        val assetNames = listOf("api.py", "create_api.sh", "cw_bridge.py",
                                "setup_fastapi_radio.sh", "set_api_key.sh")
        val assetFiles: List<Pair<String, ByteArray>> = assetNames.map { name ->
            name to requireContext().assets.open(name).readBytes()
        }
        // sudo -S reads password from stdin; we feed it via channel.setInputStream()
        // 第1引数に VNC デスクトップ種別 (xfce / pixel) を渡す
        val command = "chmod +x ~/create_api.sh ~/setup_fastapi_radio.sh ~/set_api_key.sh" +
            " && sudo -S bash ~/setup_fastapi_radio.sh $desktop 2>&1"

        withContext(Dispatchers.IO) {
            Log.d("SshSetup", "Starting SSH setup: host=$host user=$user")

            // Resolve hostname — for .local, acquire MulticastLock first so Android's
            // WiFi driver doesn't filter the mDNS multicast packets
            val resolvedHost: String
            try {
                resolvedHost = resolveHostWithTimeout(host)
                Log.d("SshSetup", "Resolved $host → $resolvedHost")
            } catch (e: Exception) {
                Log.e("SshSetup", "Hostname resolution failed: host=$host", e)
                val msg = e.message ?: getString(R.string.ssh_3)
                withContext(Dispatchers.Main) {
                    binding.tvSshStatus.text = "Error: $msg"
                    appendLog("ERROR: $msg")
                }
                return@withContext
            }

            val jsch = JSch()
            // Log JSch activity to logcat
            JSch.setLogger(object : com.jcraft.jsch.Logger {
                override fun isEnabled(level: Int) = true
                override fun log(level: Int, message: String) {
                    val tag = "JSch"
                    when (level) {
                        com.jcraft.jsch.Logger.DEBUG -> Log.d(tag, message)
                        com.jcraft.jsch.Logger.INFO  -> Log.i(tag, message)
                        com.jcraft.jsch.Logger.WARN  -> Log.w(tag, message)
                        else                          -> Log.e(tag, message)
                    }
                }
            })

            var session: com.jcraft.jsch.Session? = null
            var channel: ChannelExec? = null
            try {
                Log.d("SshSetup", "Creating session: $user@$resolvedHost:22")
                session = jsch.getSession(user, resolvedHost, 22)
                session.setPassword(password)

                // Accept any host key (private LAN setup)
                val config = Properties()
                config["StrictHostKeyChecking"] = "no"
                config["PreferredAuthentications"] = "password,keyboard-interactive"
                config["MaxAuthTries"] = "1"
                session.setConfig(config)

                // Pi Zero 2W のセットアップは Hamlib ビルド等で長時間 無通信になりがち。
                // SSH キープアライブが無いと NAT/Wi-Fi 省電力でTCPが切れ「タイムアウト」する。
                // 20秒ごとに keepalive を送り、最大 ~1時間(180回)の無通信まで接続維持する。
                session.serverAliveInterval = 20_000
                session.serverAliveCountMax = 180

                // Provide password for keyboard-interactive prompts (PAM)
                session.userInfo = object : UserInfo {
                    override fun getPassword() = password
                    override fun getPassphrase(): String? = null
                    override fun promptPassword(msg: String): Boolean {
                        Log.d("SshSetup", "UserInfo.promptPassword: $msg")
                        return true
                    }
                    override fun promptPassphrase(msg: String): Boolean {
                        Log.d("SshSetup", "UserInfo.promptPassphrase: $msg")
                        return false
                    }
                    override fun promptYesNo(msg: String): Boolean {
                        Log.d("SshSetup", "UserInfo.promptYesNo: $msg")
                        return true
                    }
                    override fun showMessage(msg: String) {
                        Log.d("SshSetup", "UserInfo.showMessage: $msg")
                    }
                }

                Log.d("SshSetup", "Calling session.connect(30000)")
                session.connect(30_000)
                Log.d("SshSetup", "Session connected successfully")

                withContext(Dispatchers.Main) {
                    binding.tvSshStatus.text = getString(R.string.ssh_4)
                }

                // SFTP でアプリ assets のファイルを Pi ホームディレクトリへアップロード
                val sftp = session.openChannel("sftp") as ChannelSftp
                sftp.connect(10_000)
                try {
                    for ((name, bytes) in assetFiles) {
                        sftp.put(java.io.ByteArrayInputStream(bytes), name)
                        val kb = bytes.size / 1024
                        withContext(Dispatchers.Main) { appendLog(getString(R.string.ssh_5, name, kb)) }
                    }
                } finally {
                    sftp.disconnect()
                }
                withContext(Dispatchers.Main) {
                    appendLog(getString(R.string.ssh_6))
                    binding.tvSshStatus.text = getString(R.string.ssh_7)
                }

                // 1コマンドを exec して stdout 全文を返す短命チャネル。
                fun execOnce(sess: com.jcraft.jsch.Session, cmd: String): String {
                    val ch = sess.openChannel("exec") as ChannelExec
                    ch.setCommand(cmd)
                    ch.setInputStream(java.io.ByteArrayInputStream("$password\n".toByteArray()))
                    val out = ch.inputStream
                    ch.connect(15_000)
                    val txt = out.bufferedReader().readText()
                    ch.disconnect()
                    return txt
                }

                // Step 3: セットアップを detached 起動（SSH/ネットワークが切れても Pi 側で走り続ける）。
                // 以前は同期 exec で完了まで待っていたため、遅い工程(ffmpeg/Hamlib)の最中に切断すると
                // “毎回同じ所でセットアップが死ぬ”原因になっていた(その恒久対策)。
                // sudo 配下では ~ が /root を指し ~/setup_fastapi_radio.sh が見つからず起動に失敗していた。
                // ログインユーザの \$HOME を外側シェルで展開した絶対パスで起動し、ログは曖昧さの無い
                // /tmp/wrc_setup.log に出す(poll も同じファイルを読む)。
                val launchCmd = "chmod +x ~/create_api.sh ~/setup_fastapi_radio.sh ~/set_api_key.sh" +
                    " && S=\"\$HOME/setup_fastapi_radio.sh\"" +
                    " && printf '%s\\n' '$password' | sudo -S setsid bash -c " +
                    "\"nohup bash '\$S' $desktop > /tmp/wrc_setup.log 2>&1 </dev/null &\"" +
                    " && echo LAUNCHED"
                execOnce(session!!, launchCmd)
                withContext(Dispatchers.Main) {
                    appendLog("Setup started in the background — monitoring (survives disconnection)")
                }

                // Step 4: ~/setup.log をポーリングして進捗表示。切断時はセッションを再接続。
                val setupStart = System.currentTimeMillis()
                var shownLines = 0
                var setupDone = false
                var lastOutput = System.currentTimeMillis()
                var aliveFlag = true
                val deadlineMs = setupStart + 45 * 60 * 1000L
                while (System.currentTimeMillis() < deadlineMs && !setupDone) {
                    kotlinx.coroutines.delay(8_000)
                    val elapsed = (System.currentTimeMillis() - setupStart) / 1000
                    // ハートビート: 毎回ステータスに経過秒＋生存状態を出し「生きている」ことを示す
                    withContext(Dispatchers.Main) {
                        binding.tvSshStatus.text = "⏳ Setting up on the Pi… ${elapsed}s (" + (if (aliveFlag) "running" else "finishing") + ")"
                    }
                    if (session == null || session?.isConnected != true) {
                        try {
                            session = jsch.getSession(user, resolvedHost, 22)
                            session!!.setPassword(password)
                            session!!.setConfig(config)
                            session!!.serverAliveInterval = 20_000
                            session!!.serverAliveCountMax = 180
                            session!!.connect(15_000)
                        } catch (_: Exception) {
                            withContext(Dispatchers.Main) { appendLog("… reconnecting (${elapsed}s)") }
                            continue
                        }
                    }
                    val pollCmd = "tail -n +${shownLines + 1} /tmp/wrc_setup.log 2>/dev/null; " +
                        "echo \"@@LINES=\$(wc -l < /tmp/wrc_setup.log 2>/dev/null || echo 0)\"; " +
                        "echo \"@@ALIVE=\$(pgrep -f setup_fastapi_radio.sh >/dev/null && echo 1 || echo 0)\"; " +
                        "grep -q 'セットアップ完了' /tmp/wrc_setup.log 2>/dev/null && echo '@@DONE' || true"
                    val text = try {
                        execOnce(session!!, pollCmd)
                    } catch (_: Exception) {
                        try { session?.disconnect() } catch (_: Exception) {}
                        session = null
                        continue
                    }
                    var gotLine = false
                    for (l in text.split("\n")) {
                        when {
                            l.startsWith("@@LINES=") -> l.removePrefix("@@LINES=").trim().toIntOrNull()?.let { shownLines = it }
                            l.startsWith("@@ALIVE=") -> aliveFlag = l.trim().endsWith("1")
                            l.trim() == "@@DONE" -> setupDone = true
                            l.isNotBlank() -> { withContext(Dispatchers.Main) { appendLog(l) }; gotLine = true }
                        }
                    }
                    if (gotLine) {
                        lastOutput = System.currentTimeMillis()
                    } else if (System.currentTimeMillis() - lastOutput > 25_000) {
                        // ログが静かでも生きていることを示す(例: Hamlibコンパイル中)
                        withContext(Dispatchers.Main) {
                            appendLog("⏳ still running… ${elapsed}s" + (if (aliveFlag) "" else " (process ended — finalizing)"))
                        }
                        lastOutput = System.currentTimeMillis()
                    }
                }
                val exitCode = if (setupDone) 0 else 1
                if (!setupDone) withContext(Dispatchers.Main) {
                    appendLog("(Timed out monitoring — the setup keeps running on the Pi. Check ~/setup.log or connect later.)")
                }
                Log.d("SshSetup", "Setup monitoring finished, done=$setupDone")

                withContext(Dispatchers.Main) {
                    if (exitCode == 0) {
                        binding.tvSshStatus.setTextColor(0xFF00C853.toInt())
                        binding.tvSshStatus.text = getString(R.string.ssh_8)
                        appendLog(getString(R.string.ssh_9))
                    } else {
                        binding.tvSshStatus.text = getString(R.string.ssh_10, exitCode)
                        appendLog(getString(R.string.ssh_11, exitCode))
                    }
                }

                if (exitCode == 0) {
                    withContext(Dispatchers.Main) {
                        appendLog(getString(R.string.ssh_12))
                        appendLog("")
                        appendLog(getString(R.string.ssh_13))
                        appendLog(getString(R.string.ssh_14))
                        appendLog(getString(R.string.ssh_15))
                        appendLog(getString(R.string.ssh_16))
                        binding.tvSshStatus.text = getString(R.string.ssh_17)
                        binding.tvSshStatus.setTextColor(0xFF00C853.toInt())
                    }
                }

            } catch (e: Exception) {
                Log.e("SshSetup", "SSH exception: ${e.javaClass.name}: ${e.message}", e)
                withContext(Dispatchers.Main) {
                    val detail = "${e.javaClass.simpleName}: ${e.message ?: "(no message)"}" +
                        (e.cause?.let { "\nCause: ${it.javaClass.simpleName}: ${it.message}" } ?: "")
                    binding.tvSshStatus.text = "Error: $detail"
                    appendLog("ERROR: $detail")
                }
            } finally {
                try { channel?.disconnect() } catch (_: Exception) {}
                try { session?.disconnect() } catch (_: Exception) {}
            }
        }
    }

    private data class SshHost(val ip: String, val hostname: String)

    // SSH(22番)が開いているホストをサブネット走査で探す。
    // Connect画面のUDP探索と違い api.py 不要なので、セットアップ前の素のPiでも見つかる。
    private fun startPiSearch() {
        val progress = AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.ssh_search_title))
            .setMessage(getString(R.string.ssh_search_scanning))
            .setNegativeButton(android.R.string.cancel, null)
            .show()

        lifecycleScope.launch {
            val results = withContext(Dispatchers.IO) { discoverSshHosts() }
            progress.dismiss()
            if (!isAdded) return@launch
            if (results.isEmpty()) {
                AlertDialog.Builder(requireContext())
                    .setTitle(getString(R.string.ssh_search_none_title))
                    .setMessage(getString(R.string.ssh_search_none_msg))
                    .setPositiveButton(android.R.string.ok, null)
                    .show()
            } else {
                val labels = results.map {
                    if (it.hostname.isNotEmpty()) "${it.hostname}  (${it.ip})" else it.ip
                }.toTypedArray()
                AlertDialog.Builder(requireContext())
                    .setTitle(getString(R.string.ssh_search_found_title))
                    .setItems(labels) { _, idx -> binding.editSshHost.setText(results[idx].ip) }
                    .show()
            }
        }
    }

    private suspend fun discoverSshHosts(): List<SshHost> = coroutineScope {
        val targets = mutableListOf<String>()
        try {
            NetworkInterface.getNetworkInterfaces()?.toList()?.forEach { iface ->
                if (!iface.isUp || iface.isLoopback) return@forEach
                iface.interfaceAddresses.forEach { ia ->
                    val local = ia.address ?: return@forEach
                    if (local.address.size != 4) return@forEach  // IPv4 の /24 のみ
                    val base = local.address.clone()
                    val selfLast = base[3].toInt() and 0xFF
                    for (i in 1..254) {
                        if (i == selfLast) continue
                        base[3] = i.toByte()
                        (runCatching { InetAddress.getByAddress(base.clone()) }.getOrNull())
                            ?.hostAddress?.let { targets.add(it) }
                    }
                }
            }
        } catch (_: Exception) {}

        targets.distinct().map { ip ->
            async {
                val open = runCatching {
                    Socket().use { s ->
                        s.connect(InetSocketAddress(ip, 22), 400)
                        true
                    }
                }.getOrDefault(false)
                if (open) {
                    val name = runCatching {
                        val h = InetAddress.getByName(ip).canonicalHostName
                        if (h == ip) "" else h.removeSuffix(".")
                    }.getOrDefault("")
                    SshHost(ip, name)
                } else null
            }
        }.mapNotNull { it.await() }.sortedBy { it.ip }
    }

    private fun appendLog(line: String) {
        val current = binding.tvSshLog.text
        binding.tvSshLog.text = if (current.isEmpty()) line else "$current\n$line"
        binding.scrollSshLog.post { binding.scrollSshLog.fullScroll(View.FOCUS_DOWN) }
    }

    // Resolve hostname with 10s timeout.
    // For .local hostnames, acquires a MulticastLock so Android's WiFi driver
    // passes mDNS multicast packets through to InetAddress.getByName().
    private fun resolveHostWithTimeout(host: String): String {
        val wifiMgr = requireContext().applicationContext
            .getSystemService(Context.WIFI_SERVICE) as WifiManager
        val lock = if (host.endsWith(".local")) {
            wifiMgr.createMulticastLock("ssh_mdns").also {
                it.setReferenceCounted(false)
                it.acquire()
            }
        } else null

        try {
            val future = java.util.concurrent.FutureTask {
                val addrs = InetAddress.getAllByName(host)
                // Prefer IPv4 — Android sometimes resolves .local to IPv6 which
                // times out even if the Pi doesn't have reachable IPv6 SSH
                val ipv4 = addrs.filterIsInstance<java.net.Inet4Address>().firstOrNull()
                (ipv4 ?: addrs.firstOrNull())?.hostAddress ?: host
            }
            Thread(future).also { it.isDaemon = true; it.start() }
            return try {
                future.get(10, java.util.concurrent.TimeUnit.SECONDS)
            } catch (e: java.util.concurrent.TimeoutException) {
                future.cancel(true)
                throw Exception(
                    if (host.endsWith(".local"))
                        "「$host」が見つかりません（10秒タイムアウト）\nIPアドレスを直接入力してください"
                    else
                        "「$host」への接続がタイムアウトしました"
                )
            }
        } finally {
            lock?.release()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
