package com.ji1ore.wifi_rig_ctrl
import com.ji1ore.wifi_rig_ctrl.ui.theme.ThemeApply
import com.ji1ore.wifi_rig_ctrl.ui.theme.UiTheme

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.ji1ore.wifi_rig_ctrl.databinding.FragmentWireguardSetupBinding
import com.ji1ore.wifi_rig_ctrl.viewmodel.MainViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class WireGuardSetupFragment : Fragment() {

    private var _binding: FragmentWireguardSetupBinding? = null
    private val binding get() = _binding!!
    private val vm: MainViewModel by activityViewModels()

    private var pendingConfText: String? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentWireguardSetupBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // ブランド・テーマを画面全体へ適用（中立色のみパレット化・機能色は維持）
        ThemeApply.apply(binding.root, UiTheme.fromIndex(vm.prefs.colorTheme), vm.prefs.dayMode)

        binding.btnWgBack.setOnClickListener { findNavController().navigateUp() }

        // Connect 画面で入力済みの Pi IP を初期値として表示
        val savedHost = vm.hostName.value ?: ""
        if (savedHost.isNotEmpty()) {
            binding.editWgPiHost.setText(savedHost)
        }

        // API キー: 既存キーがあれば表示、なければ UUID 自動生成
        val existingKey = vm.apiKey.value ?: ""
        binding.editWgApiKey.setText(
            if (existingKey.isNotEmpty()) existingKey
            else java.util.UUID.randomUUID().toString()
        )

        // 固定IP変更は Connect 画面の「固定IP設定」メニューへ分離（WireGuardでは扱わない）。

        // DuckDNS サイトをブラウザで開く。ユーザーはここでログインし、token を
        // 長押しコピー→アプリに戻って📋で貼付する（カメラOCRの誤読を回避）。
        binding.btnOpenDuckDns.setOnClickListener {
            try {
                startActivity(android.content.Intent(
                    android.content.Intent.ACTION_VIEW,
                    android.net.Uri.parse("https://www.duckdns.org/")))
            } catch (e: Exception) {
                appendLog("DuckDNS を開けませんでした: ${e.message}")
            }
        }

        // クリップボード貼付: カメラOCRの UUID 誤読を避ける確実な取り込み。
        // DuckDNS ページで token をコピー→この📋ボタンで貼付。
        binding.btnPasteToken.setOnClickListener {
            val raw = clipboardText()
            // トークンは UUID。クリップボードから UUID を厳密抽出（余計な文字が混ざっても拾う）。
            val uuid = Regex(
                "[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
            ).find(raw)?.value
            binding.editWgToken.setText((uuid ?: raw.trim()).lowercase())
            if (uuid != null) appendLog(getString(R.string.wireguard_27))
        }
        binding.btnPasteDomain.setOnClickListener {
            val raw = clipboardText().trim()
            // "xxx.duckdns.org" を貼ってもサブドメイン(xxx)のみ抽出（サーバも正規化するが入口で整える）。
            val sub = Regex("([A-Za-z0-9][A-Za-z0-9-]*)\\.duckdns\\.org", RegexOption.IGNORE_CASE)
                .find(raw)?.groupValues?.get(1)
            binding.editWgDomain.setText((sub ?: raw).lowercase())
        }

        binding.btnWgRun.setOnClickListener {
            val piHost    = binding.editWgPiHost.text.toString().trim()
            val domain    = binding.editWgDomain.text.toString().trim().lowercase()
            val token     = binding.editWgToken.text.toString().trim()
            val apiKeyNew = binding.editWgApiKey.text.toString().trim()
            if (piHost.isEmpty() || domain.isEmpty() || token.isEmpty()) {
                binding.tvWgStatus.text = getString(R.string.wireguard_2)
                return@setOnClickListener
            }
            if (apiKeyNew.isEmpty()) {
                binding.tvWgStatus.text = getString(R.string.wireguard_3)
                return@setOnClickListener
            }
            val sudoPass = binding.editWgSudoPass.text.toString()
            startSetup(piHost, domain, token, "", sudoPass, apiKeyNew)
        }

        binding.btnWgImport.setOnClickListener {
            pendingConfText?.let { importToWireGuard(it) }
        }
    }

    // クリップボードの現在のテキストを返す（空なら ""）。
    private fun clipboardText(): String {
        val cm = requireContext().getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                as? android.content.ClipboardManager
        return cm?.primaryClip?.takeIf { it.itemCount > 0 }
            ?.getItemAt(0)?.coerceToText(requireContext())?.toString() ?: ""
    }


    private fun startSetup(piHost: String, domain: String, token: String, staticIp: String, sudoPass: String = "", newApiKey: String) {
        binding.btnWgRun.isEnabled = false
        binding.btnWgImport.visibility = View.GONE
        binding.tvWgLog.text = ""
        binding.tvWgStatus.text = getString(R.string.wireguard_5)
        pendingConfText = null
        switchedIp = ""
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val port   = vm.apiPort.value ?: 8000
        val apiKey = vm.apiKey.value ?: ""

        lifecycleScope.launch {
            val host = piHost
            // Step 1: api.py を先に更新
            val updateOk = pushApiPy(piHost, port, apiKey)
            if (updateOk) {
                appendLog(getString(R.string.wireguard_6))
                kotlinx.coroutines.delay(5_000)
            } else {
                appendLog(getString(R.string.wireguard_7))
            }

            // 固定IPの変更は Connect 画面の「固定IP設定」メニューに分離済み。
            // ここでは IP を変更しない(static_ip="")ため、途中でIP切替による切断は起きない。
            binding.tvWgStatus.text = getString(R.string.wireguard_8)
            runSseSetup(host, port, apiKey, domain, token, "", sudoPass)

            // Step 3: API キーを Pi(host) に設定
            binding.tvWgStatus.text = getString(R.string.wireguard_10)
            var keyOk = false
            for (attempt in 1..4) {
                if (attempt > 1) {
                    appendLog(getString(R.string.wireguard_12, attempt, 4))
                    kotlinx.coroutines.delay(4_000)
                }
                val (ok, statusCode, errMsg) = setApiKeyOnPi(host, port, apiKey, newApiKey)
                appendLog(getString(R.string.wireguard_13, attempt, statusCode)
                    + if (errMsg.isNotEmpty()) " — $errMsg" else "")
                if (ok) { keyOk = true; break }
            }
            withContext(Dispatchers.Main) {
                if (keyOk) {
                    vm.apiKey.value = newApiKey
                    vm.prefs.apiKey = newApiKey
                    vm.api.apiKey = newApiKey
                    appendLog(getString(R.string.wireguard_14))
                    binding.tvWgStatus.text = if (pendingConfText != null)
                        getString(R.string.wireguard_15)
                    else getString(R.string.wireguard_16)
                } else {
                    appendLog(getString(R.string.wireguard_17))
                    binding.tvWgStatus.text = getString(R.string.wireguard_18)
                }
            }

            binding.btnWgRun.isEnabled = true
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private suspend fun pushApiPy(host: String, port: Int, apiKey: String): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val bytes = requireContext().assets.open("api.py").readBytes()
                val url = URL("http://$host:$port/admin/update")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    setRequestProperty("Content-Type", "application/octet-stream")
                    if (apiKey.isNotEmpty()) setRequestProperty("X-API-Key", apiKey)
                    connectTimeout = 10_000
                    readTimeout = 30_000
                    doOutput = true
                    outputStream.write(bytes)
                }
                val ok = conn.responseCode == 200
                conn.disconnect()
                ok
            } catch (_: Exception) { false }
        }

    private suspend fun setApiKeyOnPi(host: String, port: Int, currentApiKey: String, newApiKey: String): Triple<Boolean, Int, String> =
        withContext(Dispatchers.IO) {
            val body = JSONObject().put("new_key", newApiKey).toString().toByteArray(Charsets.UTF_8)
            // まず現在のキーで認証。403 の場合は、直前の試行で既に Pi のキーが newApiKey に
            // 変更済み(＆再起動)の可能性があるため newApiKey で再認証する(同じ値の再設定＝冪等)。
            // これで「実はキー設定済みなのに古いキーで 403 → 橙色失敗」のレースを解消する。
            val keys = if (currentApiKey == newApiKey) listOf(currentApiKey) else listOf(currentApiKey, newApiKey)
            var lastCode = 0; var lastMsg = ""
            for (k in keys) {
                try {
                    val url = URL("http://$host:$port/admin/set_api_key")
                    val conn = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        setRequestProperty("Content-Type", "application/json")
                        if (k.isNotEmpty()) setRequestProperty("X-API-Key", k)
                        connectTimeout = 8_000
                        readTimeout = 20_000
                        doOutput = true
                        outputStream.write(body)
                    }
                    val code = conn.responseCode
                    val errBody = if (code != 200) {
                        try { (conn.errorStream ?: conn.inputStream).bufferedReader().readText().take(120) } catch (_: Exception) { "" }
                    } else ""
                    conn.disconnect()
                    if (code == 200) return@withContext Triple(true, 200, "")
                    lastCode = code; lastMsg = errBody
                    if (code != 403) return@withContext Triple(false, code, errBody)  // 認証以外の失敗はキー違い再試行しても無駄
                } catch (e: Exception) {
                    return@withContext Triple(false, 0, e.message ?: "connection error")  // 接続不可 → 上位のリトライに任せる
                }
            }
            Triple(false, lastCode, lastMsg)
        }

    // 固定IP変更時、Pi が新IPへ移行してストリームが切れるのは想定内。その切断をエラー表示にしない。
    private var expectingIpSwitch = false
    private var switchedIp = ""   // ip_switch イベントで通知された新IP(続行先)

    private suspend fun runSseSetup(
        host: String, port: Int, apiKey: String,
        domain: String, token: String, staticIp: String,
        sudoPass: String = ""
    ) = withContext(Dispatchers.IO) {
        expectingIpSwitch = false
        try {
            val url = URL("http://$host:$port/wireguard/setup")
            val body = JSONObject().apply {
                put("ddns_domain", domain)
                put("ddns_token", token)
                put("static_ip", staticIp)
                put("sudo_pass", sudoPass)
            }.toString().toByteArray(Charsets.UTF_8)

            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Accept", "text/event-stream")
                if (apiKey.isNotEmpty()) setRequestProperty("X-API-Key", apiKey)
                connectTimeout = 10_000
                readTimeout = 600_000
                doOutput = true
                outputStream.write(body)
            }

            if (conn.responseCode != 200) {
                val raw = conn.errorStream?.bufferedReader()?.readText() ?: ""
                val msg = if (raw.isNotEmpty()) {
                    try { JSONObject(raw).optString("detail", raw) } catch (_: Exception) { raw }
                } else "HTTP ${conn.responseCode}"
                withContext(Dispatchers.Main) {
                    appendLog("ERROR: $msg")
                    binding.tvWgStatus.text = getString(R.string.wireguard_19, msg)
                }
                return@withContext
            }

            val reader = BufferedReader(InputStreamReader(conn.inputStream))
            var dataLine = ""
            reader.forEachLine { line ->
                when {
                    line.startsWith("data: ") -> dataLine = line.removePrefix("data: ")
                    line.isEmpty() && dataLine.isNotEmpty() -> {
                        handleEvent(dataLine)
                        dataLine = ""
                    }
                }
            }
            conn.disconnect()

        } catch (e: Exception) {
            // 固定IP移行による想定内の切断(切替予告あり or config 受信済み)はエラー表示にしない。
            // 後続の set_api_key が新IPへ再接続して完了処理を続行する。
            if (expectingIpSwitch || !pendingConfText.isNullOrEmpty()) {
                withContext(Dispatchers.Main) {
                    appendLog("Stream ended for IP switch — reconnecting to the new IP")
                }
            } else {
                withContext(Dispatchers.Main) {
                    appendLog(getString(R.string.wireguard_20, e.message ?: ""))
                    binding.tvWgStatus.text = getString(R.string.wireguard_19, e.message ?: "")
                }
            }
        }
    }

    private fun handleEvent(data: String) {
        try {
            val json = JSONObject(data)
            when (json.optString("type")) {
                "log" -> {
                    val msg = json.optString("msg", "")
                    lifecycleScope.launch(Dispatchers.Main) { appendLog(msg) }
                }
                "info" -> {
                    val piIp = json.optString("pi_ip", "")
                    if (piIp.isNotEmpty()) {
                        lifecycleScope.launch(Dispatchers.Main) {
                            binding.tvWgStatus.text = getString(R.string.wireguard_21, piIp)
                        }
                    }
                }
                "config" -> {
                    val confText = json.optString("text", "")
                    val piIp    = json.optString("pi_ip", "")
                    if (confText.isNotEmpty()) {
                        pendingConfText = confText
                        lifecycleScope.launch(Dispatchers.Main) {
                            appendLog(getString(R.string.wireguard_22))
                            if (piIp.isNotEmpty()) appendLog("Pi IP: $piIp")
                            binding.btnWgImport.visibility = View.VISIBLE
                        }
                    }
                }
                "ip_switch" -> {
                    expectingIpSwitch = true
                    val newIp = json.optString("new_ip", "")
                    if (newIp.isNotEmpty()) switchedIp = newIp
                    lifecycleScope.launch(Dispatchers.Main) {
                        appendLog("Pi is moving to the new IP $newIp — the app will reconnect there and continue")
                    }
                }
                "error" -> {
                    val msg = json.optString("msg", "Unknown error")
                    // kind=ddns: ドメイン/トークンの読み取りミス等。見逃すと今回の
                    // 二重ドメイン事故のように後で繋がらないため、大きなダイアログで
                    // 明確に警告する。server 側は error 送出後に中断するので config
                    // は届かず import には進まない（＝セットアップは先に進めない）。
                    val kind = json.optString("kind", "")
                    lifecycleScope.launch(Dispatchers.Main) {
                        if (!isAdded) return@launch
                        appendLog("ERROR: $msg")
                        binding.tvWgStatus.text = getString(R.string.wireguard_19, msg)
                        binding.btnWgImport.visibility = View.GONE
                        val titleRes = if (kind == "ddns") R.string.wireguard_25
                                       else R.string.wireguard_26
                        try {
                            androidx.appcompat.app.AlertDialog.Builder(requireContext())
                                .setTitle(getString(titleRes))
                                .setMessage(msg)
                                .setPositiveButton(android.R.string.ok, null)
                                .setCancelable(false)
                                .show()
                        } catch (_: Exception) { /* fragment detached */ }
                    }
                }
            }
        } catch (_: Exception) {
            lifecycleScope.launch(Dispatchers.Main) { appendLog(data) }
        }
    }

    private fun appendLog(msg: String) {
        val current = binding.tvWgLog.text.toString()
        val combined = if (current.isEmpty()) msg else "$current\n$msg"
        val lines = combined.lines()
        binding.tvWgLog.text = if (lines.size > 80) lines.takeLast(80).joinToString("\n") else combined
        binding.scrollWgLog.post {
            binding.scrollWgLog.scrollTo(0, binding.scrollWgLog.getChildAt(0).height)
        }
    }

    private fun importToWireGuard(confText: String) {
        try {
            val confFile = File(requireContext().cacheDir, "WG_Raspi.conf")
            confFile.writeText(confText)

            val uri = FileProvider.getUriForFile(
                requireContext(),
                "${requireContext().packageName}.provider",
                confFile
            )

            // ACTION_SEND でシェアシートを表示 — WireGuard が受け取れる最も互換性の高い方法
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/x-wireguard-config"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(sendIntent, getString(R.string.wireguard_23)))
        } catch (e: Exception) {
            Toast.makeText(requireContext(), getString(R.string.wireguard_24, e.message ?: ""), Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
