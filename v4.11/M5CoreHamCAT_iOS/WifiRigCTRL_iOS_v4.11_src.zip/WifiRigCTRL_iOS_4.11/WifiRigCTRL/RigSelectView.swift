import SwiftUI

struct RigSelectView: View {
    @Bindable var vm: MainViewModel
    @State private var localError: String?
    @State private var backupStatus: String?
    // RTTY AUTO 自動追従の最大ずれ(Hz)。RttyView と同じキーを共有。
    @AppStorage("rttyAutoTuneOffsetHz") private var rttyAutoTuneOffsetHz = 500
    @AppStorage("sotaSpotHours") private var sotaSpotHours = 2

    private var audioCaptureName: String {
        guard !vm.selectedAudioCapture.isEmpty else { return "Default" }
        return vm.selectedAudioCapture
    }
    private var audioPlaybackName: String {
        guard !vm.selectedAudioPlayback.isEmpty else { return "Same as SPK/TX" }
        return vm.selectedAudioPlayback
    }
    private var sampleRateLabel: String {
        // Guard against an out-of-range index (stale profile) — avoids a crash that
        // would leave this pushed screen blank/black.
        guard AppConstants.samplingRates.indices.contains(vm.selectedSamplingIndex) else { return "Off" }
        let r = AppConstants.samplingRates[vm.selectedSamplingIndex]
        return r == 0 ? "Off" : "\(r) Hz"
    }

    /// シリアルポート1行: 左 ttyUSBn / 右 by-id(短縮)。Picker 内のインライン化は型チェッカーが
    /// 重くなるためヘルパーに分離する。
    @ViewBuilder
    private func catRow(_ i: Int) -> some View {
        HStack {
            Text(vm.catTitles[i])
            if !vm.catSubtitles[i].isEmpty {
                Spacer()
                Text(vm.catSubtitles[i])
                    .font(.caption).foregroundStyle(.secondary)
                    .lineLimit(1).truncationMode(.middle)
            }
        }
    }

    var body: some View {
        Form {
            Section(header: Label("Rig Model", systemImage: "antenna.radiowaves.left.and.right").foregroundStyle(.indigo)) {
                if vm.rigList.isEmpty {
                    Text("No rigs returned by server").foregroundStyle(.secondary)
                } else {
                    Picker("Rig Model", selection: $vm.selectedRigIndex) {
                        ForEach(vm.rigList.indices, id: \.self) { i in
                            Text(vm.rigList[i].name).tag(i)
                        }
                    }
                }
            }

            Section(header: Label("CAT Device", systemImage: "cable.connector").foregroundStyle(.teal)) {
                if vm.catList.isEmpty {
                    Text("No serial devices").foregroundStyle(.secondary)
                } else {
                    Picker("CAT Device", selection: $vm.selectedCatIndex) {
                        ForEach(vm.catList.indices, id: \.self) { i in
                            catRow(i).tag(i)
                        }
                    }
                }
                Picker("Baud Rate", selection: $vm.selectedBaudIndex) {
                    ForEach(AppConstants.baudRates.indices, id: \.self) { i in
                        Text(String(AppConstants.baudRates[i])).tag(i)
                    }
                }
            }

            Section(header: Label("PTT", systemImage: "dot.radiowaves.left.and.right").foregroundStyle(.red)) {
                Picker("PTT Device", selection: $vm.selectedPttDevice) {
                    Text("NONE").tag("NONE")
                    ForEach(vm.catList.indices, id: \.self) { i in
                        catRow(i).tag(vm.catList[i])
                    }
                }
                Picker("PTT Type", selection: $vm.selectedPttType) {
                    ForEach(PttType.allCases, id: \.self) { t in
                        Text(t.displayName).tag(t)
                    }
                }
            }

            Section {
                if vm.soundDeviceList.isEmpty {
                    Text("No audio devices").foregroundStyle(.secondary)
                } else {
                    Picker("SPK / TX", selection: $vm.selectedAudioCapture) {
                        Text("Default").tag("")
                        ForEach(vm.soundDeviceList) { d in
                            VStack(alignment: .leading, spacing: 1) {
                                Text(d.id)
                                Text(d.label).font(.caption2).foregroundStyle(.secondary)
                            }.tag(d.id)
                        }
                    }
                    Picker("FT8", selection: $vm.selectedAudioPlayback) {
                        Text("Same as SPK/TX").tag("")
                        ForEach(vm.soundDeviceList) { d in
                            VStack(alignment: .leading, spacing: 1) {
                                Text(d.id)
                                Text(d.label).font(.caption2).foregroundStyle(.secondary)
                            }.tag(d.id)
                        }
                    }
                }
                Picker("Sample Rate", selection: $vm.selectedSamplingIndex) {
                    ForEach(AppConstants.samplingRates.indices, id: \.self) { i in
                        let r = AppConstants.samplingRates[i]
                        Text(r == 0 ? "Off" : "\(r) Hz").tag(i)
                    }
                }
            } header: {
                Label("Audio", systemImage: "waveform").foregroundStyle(.cyan)
            } footer: {
                VStack(alignment: .leading, spacing: 2) {
                    if !vm.soundDeviceList.isEmpty {
                        Label("SPK/TX: \(audioCaptureName)", systemImage: "speaker.wave.2")
                        Label("FT8: \(audioPlaybackName)", systemImage: "waveform.badge.mic")
                    }
                    Label("Rate: \(sampleRateLabel)", systemImage: "metronome")
                }
                .font(.caption)
            }

            Section("My Call") {
                HStack {
                    TextField("JA1XXX", text: $vm.ft8MyCall)
                        .textInputAutocapitalization(.characters).autocorrectionDisabled()
                        .onChange(of: vm.ft8MyCall) { _, v in
                            vm.ft8MyCall = v.uppercased()
                            vm.loadEqslForCurrentCall()   // コールに紐づくeQSLアカウントへ切替
                        }
                        .onSubmit { vm.addMyCall(vm.ft8MyCall); vm.persistFt8Settings() }
                    if !vm.myCallHistory.isEmpty {
                        Menu {
                            ForEach(vm.myCallHistory, id: \.self) { c in
                                Button(c) { vm.ft8MyCall = c; vm.loadEqslForCurrentCall(); vm.persistFt8Settings() }
                            }
                        } label: { Image(systemName: "chevron.down.circle") }
                    }
                }
            }

            Section(header: Label("RTTY AUTO Offset", systemImage: "waveform.path").foregroundStyle(.green)) {
                Stepper(value: $rttyAutoTuneOffsetHz, in: 50...950, step: 50) {
                    Text("±\(rttyAutoTuneOffsetHz) Hz")
                }
                Text("Maximum drift corrected by RTTY auto-tracking. Larger values follow signals farther away but are more likely to pick up a nearby signal (recommended 500)")
                    .font(.caption).foregroundStyle(.secondary)
            }

            Section(header: Label("SOTA Spot Time Window", systemImage: "clock").foregroundStyle(.green)) {
                Stepper(value: $sotaSpotHours, in: 1...24, step: 1) {
                    Text("Fetch spots from the last \(sotaSpotHours) hours")
                }
                Text("Time window of spots shown on the SOTA tab in MEMSET, etc. (1–24, recommended 2)")
                    .font(.caption).foregroundStyle(.secondary)
            }

            Section("External Services (Auto QSL Upload)") {
                Toggle("eQSL (auto-upload on each log entry)", isOn: $vm.eqslEnabled)
                    .onChange(of: vm.eqslEnabled) { _, _ in vm.persistIntegrationSettings() }
                Toggle("Smart Ham Log", isOn: $vm.smartHamLogEnabled)
                    .onChange(of: vm.smartHamLogEnabled) { _, _ in vm.persistIntegrationSettings() }
                Toggle("PSKReporter (send FT8 reception reports)", isOn: $vm.pskrEnabled)
                    .onChange(of: vm.pskrEnabled) { _, v in vm.setPskReporter(v) }
                Button {
                    vm.path.append(.integrationSettings)
                } label: { Label("eQSL / Smart Ham Log Settings…", systemImage: "gearshape") }
            }

            // QSO Log 一覧(自局コール設定後にここで管理)。コールサイン無しではeQSL/SHL連携の
            // 管理ができないため、接続画面からこの画面へ移設。
            Section(header: Label("QSO Log", systemImage: "note.text").foregroundStyle(.orange)) {
                Button {
                    vm.path.append(.qsoLog)
                } label: {
                    HStack {
                        Label("LOG List", systemImage: "list.bullet.rectangle.portrait")
                            .foregroundStyle(.orange)
                        Spacer()
                        let count = QsoStore.load().count
                        if count > 0 {
                            Text("\(count)")
                                .font(.caption.monospacedDigit())
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }

            Section {
                if BackupStore.isAvailable {
                    Button {
                        backupStatus = BackupStore.save() ? String(localized: "Saved to iCloud") : String(localized: "Save failed")
                    } label: { Label("Save to iCloud Now", systemImage: "icloud.and.arrow.up") }
                    Button {
                        backupStatus = BackupStore.restore()
                            ? String(localized: "Restored. Please restart the app to apply.")
                            : String(localized: "Restore failed (there may be no backup).")
                    } label: { Label("Restore from iCloud", systemImage: "icloud.and.arrow.down") }
                    if let s = backupStatus {
                        Text(s).font(.caption).foregroundStyle(.secondary)
                    }
                } else {
                    Label("Available when signed in to iCloud", systemImage: "icloud.slash")
                        .foregroundStyle(.secondary)
                }
            } header: {
                Label("Backup (iCloud)", systemImage: "icloud").foregroundStyle(.blue)
            } footer: {
                Text("Saves settings and QSO logs to iCloud Drive. Credentials (passwords and API keys) are not included. Automatically restored after reinstalling.")
                    .font(.caption)
            }

            Section {
                Button {
                    Task { await open() }
                } label: {
                    HStack {
                        if vm.isBusy { ProgressView().padding(.trailing, 4) }
                        Text(vm.isBusy ? "Connecting…" : "Open Rig")
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(vm.isBusy || vm.rigList.isEmpty)
            }

            if let msg = localError {
                Section { Text(msg).foregroundStyle(.red).font(.callout) }
            }

            if vm.piVersionMismatch {
                Section {
                    Label("Pi API version mismatch — update via UPDATE", systemImage: "exclamationmark.triangle.fill")
                        .foregroundStyle(.red)
                        .font(.callout)
                }
            }
            #if DEBUG
            Section(header: Label("Debug", systemImage: "ladybug.fill").foregroundStyle(.orange)) {
                Button {
                    vm.isConnectedToRig = true
                    vm.path.append(.mainControl)
                } label: {
                    Label("Skip to Main Control", systemImage: "forward.fill")
                }
                .foregroundStyle(.orange)
            }
            #endif
        }
        .navigationTitle(Text("Select Rig"))
        .onAppear {
            // Start polling immediately so version-mismatch warnings are visible on first display.
            // Skip if polling was suppressed by auto-disconnect (Pi unreachable) — will resume
            // when the user explicitly opens a rig (openSelectedRig calls startStatusPolling).
            if !vm.demoMode && !vm.useCivMode && !vm.pollSuppressed {
                vm.startStatusPolling()
            }
        }
        .onChange(of: vm.selectedRigIndex) { _, _ in vm.persistSelections() }
        .onChange(of: vm.selectedCatIndex) { _, _ in vm.persistSelections() }
        .onChange(of: vm.selectedBaudIndex) { _, _ in vm.persistSelections() }
        .onChange(of: vm.selectedSamplingIndex) { _, _ in vm.persistSelections() }
        .onChange(of: vm.selectedPttDevice) { _, _ in vm.persistSelections() }
        .onChange(of: vm.selectedPttType) { _, _ in vm.persistSelections() }
        .onChange(of: vm.selectedAudioCapture) { _, _ in vm.persistSelections() }
        .onChange(of: vm.selectedAudioPlayback) { _, _ in vm.persistSelections() }
    }

    private func open() async {
        localError = nil
        if let err = await vm.openSelectedRig() {
            localError = err
        } else {
            vm.path.append(.mainControl)
        }
    }
}
