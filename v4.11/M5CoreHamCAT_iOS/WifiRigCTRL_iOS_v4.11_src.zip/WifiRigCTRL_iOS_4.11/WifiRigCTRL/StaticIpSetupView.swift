import SwiftUI

// 固定IP設定の独立画面（⋮メニュー → 固定IP設定）。WireGuardセットアップとは分離。
// 現在のIP(検索可・対象マシンを選ぶ) + 新しいIP(手入力) + sudoパスワード + 固定IPへ変更。
struct StaticIpSetupView: View {
    @Bindable var vm: MainViewModel

    @State private var isScanning = false
    @State private var staticIpHosts: [DiscoveredHost] = []   // 検出マシン一覧(複数台対応)
    @State private var showNoHostsAlert = false

    var body: some View {
        Form {
            // ── 対象マシン(現在のIP): 検索可 ──
            Section(header: Label("対象マシン (現在のIP)", systemImage: "desktopcomputer").foregroundStyle(.indigo),
                    footer: Text("「Piを検索」で対象を選ぶか、IPを直接入力できます。")) {
                LabeledContent("現在のIP") {
                    TextField("例: 192.168.1.60", text: $vm.staticIpCurrent)
                        .multilineTextAlignment(.trailing)
                        .keyboardType(.numbersAndPunctuation)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                }
                Button {
                    Task { await scanForStaticIp() }
                } label: {
                    HStack {
                        if isScanning { ProgressView().padding(.trailing, 4) }
                        Label("Piを検索", systemImage: "magnifyingglass")
                    }
                }
                .disabled(vm.staticIpBusy || isScanning)
                // 検出マシン一覧。タップで現在のIP(対象)に選択。
                if !staticIpHosts.isEmpty {
                    ForEach(staticIpHosts) { host in
                        Button {
                            vm.staticIpCurrent = host.ip
                        } label: {
                            HStack {
                                Image(systemName: vm.staticIpCurrent == host.ip ? "checkmark.circle.fill" : "circle")
                                    .foregroundStyle(vm.staticIpCurrent == host.ip ? .green : .secondary)
                                Text(host.label)
                                Spacer()
                            }
                        }
                    }
                }
            }

            // ── 新しいIP(変更先): 手入力のみ ──
            Section(header: Label("新しいIP (変更先)", systemImage: "arrow.right.circle").foregroundStyle(.teal)) {
                LabeledContent("新しいIP") {
                    TextField("例: 192.168.1.60", text: $vm.staticIpTarget)
                        .multilineTextAlignment(.trailing)
                        .keyboardType(.numbersAndPunctuation)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                }
            }

            // ── sudoパスワード ──
            Section(header: Label("sudoパスワード (Pi)", systemImage: "key.fill").foregroundStyle(.yellow)) {
                LabeledContent("sudoパスワード") {
                    SecureField("Piのsudoパスワード", text: $vm.staticIpSudoPass)
                        .multilineTextAlignment(.trailing)
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                }
            }

            // ── 実行 ──
            Section(footer: statusFooter) {
                Button {
                    Task { await vm.changeStaticIp() }
                } label: {
                    HStack {
                        if vm.staticIpBusy { ProgressView().padding(.trailing, 4) }
                        Label(vm.staticIpBusy ? "設定中…" : "固定IPに変更", systemImage: "lock.fill")
                    }
                }
                .disabled(vm.staticIpBusy
                          || vm.staticIpCurrent.isEmpty
                          || vm.staticIpTarget.isEmpty
                          || vm.staticIpSudoPass.isEmpty)
            }
        }
        .navigationTitle("固定IP設定")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            if vm.staticIpCurrent.isEmpty { vm.staticIpCurrent = vm.hostName }
            if vm.staticIpTarget.isEmpty { vm.staticIpTarget = vm.hostName }
        }
        .alert("Piが見つかりません", isPresented: $showNoHostsAlert) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("WIFI_RIG_CTRL サーバーが見つかりませんでした。\nPiが起動し api.py が動作しているか確認してください。")
        }
    }

    @ViewBuilder
    private var statusFooter: some View {
        if !vm.staticIpStatus.isEmpty {
            Text(vm.staticIpStatus)
        } else {
            Text("対象マシンを選び、新しいIPとsudoパスワードを入力して「固定IPに変更」を押してください。変更後は接続先が自動で新IPに切り替わります。")
        }
    }

    // 検出マシンを staticIpHosts(一覧)に格納。単一なら現在のIP(対象)に自動反映。
    private func scanForStaticIp() async {
        isScanning = true
        let hosts = await discoverWifiRigCtrlHosts()
        isScanning = false
        staticIpHosts = hosts
        if hosts.isEmpty {
            showNoHostsAlert = true
        } else if hosts.count == 1 {
            vm.staticIpCurrent = hosts[0].ip
        }
    }
}
