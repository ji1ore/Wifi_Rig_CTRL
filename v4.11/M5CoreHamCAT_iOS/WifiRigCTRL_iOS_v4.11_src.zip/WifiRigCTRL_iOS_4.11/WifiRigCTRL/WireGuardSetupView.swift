import SwiftUI
import UIKit

struct WireGuardSetupView: View {
    @Bindable var vm: MainViewModel

    @State private var piHost: String = ""
    @State private var domain: String = ""
    @State private var token: String = ""
    @State private var newApiKey: String = ""
    @State private var sudoPass: String = ""
    @State private var statusText: String = String(localized: "Enter domain and token (run after SSH setup completes)")
    @State private var statusColor: Color = .secondary
    @State private var logLines: [String] = []
    @State private var isRunning: Bool = false
    @State private var pendingConf: String? = nil
    // 固定IP変更時、Pi が新IPへ移行してストリームが切れるのは想定内。その切断をエラー表示にしない。
    @State private var expectingIpSwitch: Bool = false
    @State private var switchedIp: String = ""   // ip_switch イベントで通知された新IP(続行先)
    // 致命エラー(特に DuckDNS 読み取りミス)はログに流すだけでなく、大きなアラートで
    // 明確に警告しセットアップを先に進めさせない。server 側は error 送出後に中断する。
    @State private var showErrorAlert: Bool = false
    @State private var errorAlertTitle: String = ""
    @State private var errorAlertMessage: String = ""

    var body: some View {
        VStack(spacing: 0) {
            Form {
                Section(header: Label("Pi Connection", systemImage: "network").foregroundStyle(.indigo)) {
                    LabeledContent("Pi IP") {
                        TextField("192.168.1.100", text: $piHost)
                            .multilineTextAlignment(.trailing)
                            .keyboardType(.numbersAndPunctuation)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                    }
                    // 固定IPの変更は Connect 画面の「固定IP設定」メニューへ分離。
                }

                Section(header: Label("DuckDNS", systemImage: "globe").foregroundStyle(.teal)) {
                    // DuckDNS サイトを開く導線: システムブラウザで開く(Google の埋め込み
                    // WebView ログイン制約を回避)。ログイン→token を長押しコピー→戻って貼付。
                    Link(destination: URL(string: "https://www.duckdns.org/")!) {
                        Label("Open DuckDNS site", systemImage: "safari")
                            .foregroundStyle(.green)
                    }
                    Text("Open DuckDNS, sign in, then long-press the token to copy it — come back and tap the paste icon.")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                    LabeledContent("Domain") {
                        HStack(spacing: 6) {
                            TextField("myhome", text: $domain)
                                .multilineTextAlignment(.trailing)
                                .autocapitalization(.none)
                                .disableAutocorrection(true)
                            Button {
                                pasteDomain()
                            } label: {
                                Image(systemName: "doc.on.clipboard")
                                    .foregroundStyle(.teal)
                            }
                            .buttonStyle(.borderless)
                        }
                    }
                    LabeledContent("Token") {
                        HStack(spacing: 6) {
                            TextField("xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx", text: $token)
                                .multilineTextAlignment(.trailing)
                                .autocapitalization(.none)
                                .disableAutocorrection(true)
                            // クリップボード貼付: カメラOCRのUUID誤読を避ける確実な取り込み
                            Button {
                                pasteToken()
                            } label: {
                                Image(systemName: "doc.on.clipboard")
                                    .foregroundStyle(.teal)
                            }
                            .buttonStyle(.borderless)
                        }
                    }
                }

                Section(header: Label("API key (required)", systemImage: "key.fill").foregroundStyle(.yellow)) {
                    LabeledContent("API key") {
                        TextField("Auto-generated", text: $newApiKey)
                            .multilineTextAlignment(.trailing)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                            .foregroundStyle(.yellow)
                    }
                    Text("Set on the Pi during WireGuard setup and saved automatically in the app. Matches the \"API Key\" on the Connect screen.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section(header: Label("Pi password (for sudo)", systemImage: "lock").foregroundStyle(.orange)) {
                    LabeledContent("Password") {
                        SecureField("Pi login password (for sudo)", text: $sudoPass)
                            .multilineTextAlignment(.trailing)
                    }
                    Text("Enter the Pi login password. Used to install WireGuard and set the API key.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section {
                    Button {
                        Task { await runSetup() }
                    } label: {
                        HStack {
                            if isRunning { ProgressView().padding(.trailing, 4) }
                            Text(isRunning ? String(localized: "Setting up...") : String(localized: "Start WireGuard setup"))
                                .frame(maxWidth: .infinity)
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.blue)
                    .disabled(isRunning || piHost.isEmpty || domain.isEmpty || token.isEmpty || newApiKey.isEmpty)
                }

                if let conf = pendingConf {
                    Section {
                        ShareLink(
                            item: conf,
                            preview: SharePreview(
                                "WG_Raspi.conf",
                                icon: Image(systemName: "doc.fill")
                            )
                        ) {
                            Label("Import into WireGuard app", systemImage: "square.and.arrow.up")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(.green)
                    }
                }
            }
            .frame(maxHeight: 520)

            Text(statusText)
                .font(.callout)
                .foregroundStyle(statusColor)
                .padding(.horizontal)
                .padding(.vertical, 4)

            ScrollViewReader { proxy in
                ScrollView {
                    Text(logLines.joined(separator: "\n"))
                        .font(.system(.caption, design: .monospaced))
                        .foregroundStyle(.green)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(8)
                        .id("logEnd")
                }
                .background(Color(white: 0.05))
                .onChange(of: logLines.count) { _, _ in
                    withAnimation { proxy.scrollTo("logEnd", anchor: .bottom) }
                }
            }
        }
        .alert(errorAlertTitle, isPresented: $showErrorAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(errorAlertMessage)
        }
        .navigationTitle("WireGuard Setup")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            if piHost.isEmpty { piHost = vm.hostName }
            // API キー: 既存キーがあれば表示、なければ UUID 自動生成
            if newApiKey.isEmpty {
                newApiKey = vm.apiKey.isEmpty ? UUID().uuidString.lowercased() : vm.apiKey
            }
        }
    }

    // MARK: - Actions

    @MainActor
    private func appendLog(_ line: String) {
        logLines.append(line)
        if logLines.count > 80 { logLines.removeFirst(logLines.count - 80) }
    }

    @MainActor
    private func runSetup() async {
        guard !piHost.isEmpty, !domain.isEmpty, !token.isEmpty, !newApiKey.isEmpty else { return }
        logLines = []
        pendingConf = nil
        expectingIpSwitch = false
        switchedIp = ""
        isRunning = true
        statusText = String(localized: "Sending api.py to the Pi...")
        statusColor = .secondary

        let port = vm.apiPort
        let apiKey = vm.apiKey
        // Step 1: push api.py
        statusText = String(localized: "Sending api.py to the Pi…")
        let pushOk = await pushApiPy(host: piHost, port: port, apiKey: apiKey)
        if pushOk {
            appendLog(String(localized: "[Prep] api.py sent — waiting 5 seconds…"))
            try? await Task.sleep(nanoseconds: 5_000_000_000)
        } else {
            appendLog(String(localized: "[Warning] api.py send failed — continuing anyway"))
        }

        // Step 2: WireGuard setup。固定IP変更はここでは行わない(撤去)。固定IPにしたい場合は
        // Connect 画面の「Set the Pi's static IP」で“先に”設定してから、このセットアップを実行する。
        statusText = String(localized: "Setting up WireGuard…")
        await runSseSetup(host: piHost, port: port, apiKey: apiKey)

        // Step 3: set API key on the Pi and save locally.
        statusText = String(localized: "Setting the API key on the Pi…")
        var keyOk = false
        for attempt in 1...4 {
            if attempt > 1 {
                appendLog(String(localized: "[API Key] Retrying… (\(attempt)/4)"))
                try? await Task.sleep(nanoseconds: 4_000_000_000)
            }
            if await setApiKeyOnPi(host: piHost, port: port, currentApiKey: apiKey, newApiKey: newApiKey) {
                keyOk = true; break
            }
        }
        if keyOk {
            vm.apiKey = newApiKey
            KeychainHelper.save(newApiKey, forKey: "apiKey")
            appendLog(String(localized: "[API Key] Set on the Pi and saved in the app"))
            statusText = pendingConf != nil ? String(localized: "Done! Import it into the WireGuard app") : String(localized: "Setup complete")
            statusColor = .green
        } else {
            appendLog(String(localized: "⚠ Failed to set the API key on the Pi. Set it manually on the Connect screen."))
            statusText = String(localized: "WireGuard done (API Key setup failed)")
            statusColor = .orange
        }

        isRunning = false
    }

    private func pushApiPy(host: String, port: Int, apiKey: String) async -> Bool {
        guard let url = Bundle.main.url(forResource: "api", withExtension: "py"),
              let data = try? Data(contentsOf: url) else { return false }
        guard let endpoint = URL(string: "http://\(host):\(port)/admin/update") else { return false }
        var req = URLRequest(url: endpoint)
        req.httpMethod = "POST"
        req.setValue("application/octet-stream", forHTTPHeaderField: "Content-Type")
        if !apiKey.isEmpty { req.setValue(apiKey, forHTTPHeaderField: "X-API-Key") }
        req.timeoutInterval = 30
        req.httpBody = data
        do {
            let (_, resp) = try await URLSession.shared.data(for: req)
            return (resp as? HTTPURLResponse)?.statusCode == 200
        } catch { return false }
    }

    private func setApiKeyOnPi(host: String, port: Int, currentApiKey: String, newApiKey: String) async -> Bool {
        guard let endpoint = URL(string: "http://\(host):\(port)/admin/set_api_key") else { return false }
        guard let body = try? JSONSerialization.data(withJSONObject: ["new_key": newApiKey]) else { return false }
        // まず現在のキーで認証。403 の場合は、直前の試行で既に Pi のキーが newApiKey に変更済み
        // (＆再起動)の可能性があるため newApiKey で再認証する(同じ値の再設定＝冪等)。これで
        // 「実はキー設定済みなのに古いキーで 403 → 橙色失敗」のレースを解消する。
        let keys: [String] = (currentApiKey == newApiKey) ? [currentApiKey] : [currentApiKey, newApiKey]
        for k in keys {
            var req = URLRequest(url: endpoint)
            req.httpMethod = "POST"
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
            if !k.isEmpty { req.setValue(k, forHTTPHeaderField: "X-API-Key") }
            req.timeoutInterval = 20
            req.httpBody = body
            do {
                let (_, resp) = try await URLSession.shared.data(for: req)
                let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
                if code == 200 { return true }
                if code != 403 { return false }   // 認証以外の失敗はキー違い再試行しても無駄
            } catch { return false }               // 接続不可 → 上位のリトライに任せる
        }
        return false
    }

    @MainActor
    private func runSseSetup(host: String, port: Int, apiKey: String) async {
        guard let url = URL(string: "http://\(host):\(port)/wireguard/setup") else { return }

        var body: [String: Any] = [
            "ddns_domain": domain.trimmingCharacters(in: .whitespaces).lowercased(),
            "ddns_token":  token.trimmingCharacters(in: .whitespaces),
            "static_ip":   "",   // 固定IP変更は Connect画面の「固定IP設定」へ分離。ここでは変更しない
        ]
        let pass = sudoPass.trimmingCharacters(in: .whitespaces)
        if !pass.isEmpty { body["sudo_pass"] = pass }
        guard let bodyData = try? JSONSerialization.data(withJSONObject: body) else { return }

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("text/event-stream", forHTTPHeaderField: "Accept")
        if !apiKey.isEmpty { req.setValue(apiKey, forHTTPHeaderField: "X-API-Key") }
        req.timeoutInterval = 600
        req.httpBody = bodyData

        do {
            let (asyncBytes, response) = try await URLSession.shared.bytes(for: req)
            guard let http = response as? HTTPURLResponse else { return }
            if http.statusCode != 200 {
                appendLog("ERROR: HTTP \(http.statusCode)")
                statusText = String(localized: "Error: HTTP \(http.statusCode)")
                statusColor = .red
                return
            }

            var lineBuffer = ""
            for try await byte in asyncBytes {
                guard let ch = String(bytes: [byte], encoding: .utf8) else { continue }
                lineBuffer += ch
                guard lineBuffer.hasSuffix("\n") else { continue }
                let line = lineBuffer.trimmingCharacters(in: .newlines)
                lineBuffer = ""
                guard line.hasPrefix("data: ") else { continue }
                let jsonStr = String(line.dropFirst(6))
                guard let jsonData = jsonStr.data(using: .utf8),
                      let obj = try? JSONSerialization.jsonObject(with: jsonData) as? [String: Any]
                else { continue }
                handleEvent(obj)
            }

        } catch {
            // 固定IP移行による想定内の切断(切替予告あり or config 受信済み)はエラー表示にしない。
            // 後続の Step 3 が新IPへ再接続して完了処理を続行する。
            if expectingIpSwitch || pendingConf != nil {
                appendLog(String(localized: "Stream ended for IP switch — reconnecting to the new IP"))
                statusText = String(localized: "Switching to the new IP...")
                statusColor = .secondary
            } else {
                appendLog(String(localized: "Connection error: \(error.localizedDescription)"))
                statusText = String(localized: "Error: \(error.localizedDescription)")
                statusColor = .red
            }
        }
    }

    // クリップボードから DuckDNS トークン(UUID)を厳密抽出して取り込む。
    // カメラOCRは UUID を誤読しやすいため、DuckDNSページでトークンをコピー→貼付が確実。
    private func pasteToken() {
        let s = UIPasteboard.general.string ?? ""
        let uuid = #"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"#
        if let r = s.range(of: uuid, options: .regularExpression) {
            token = String(s[r]).lowercased()
            appendLog(String(localized: "Token pasted from clipboard"))
        } else {
            token = s.trimmingCharacters(in: .whitespacesAndNewlines)
        }
    }

    // クリップボードから DuckDNS ドメインを取り込む。"xxx.duckdns.org" を貼っても
    // サブドメイン(xxx)のみ抽出する(サーバ側も正規化するが、入口でも整えておく)。
    private func pasteDomain() {
        let s = (UIPasteboard.general.string ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        if let r = s.range(of: #"[A-Za-z0-9][A-Za-z0-9-]*\.duckdns\.org"#, options: .regularExpression) {
            domain = String(s[r]).replacingOccurrences(
                of: ".duckdns.org", with: "", options: .caseInsensitive)
        } else {
            domain = s
        }
    }

    @MainActor
    private func handleEvent(_ obj: [String: Any]) {
        switch obj["type"] as? String {
        case "log":
            if let msg = obj["msg"] as? String { appendLog(msg) }
        case "info":
            if let ip = obj["pi_ip"] as? String, !ip.isEmpty {
                statusText = String(localized: "Pi IP: \(ip) — configuring...")
            }
        case "config":
            if let text = obj["text"] as? String, !text.isEmpty {
                pendingConf = text
                appendLog(String(localized: "=== Client config file generated ==="))
            }
        case "ip_switch":
            expectingIpSwitch = true
            let ip = obj["new_ip"] as? String ?? ""
            if !ip.isEmpty { switchedIp = ip }
            appendLog(String(localized: "Pi is moving to the new IP \(ip) — the app will reconnect there and continue"))
        case "error":
            let msg = obj["msg"] as? String ?? "Unknown error"
            let kind = obj["kind"] as? String ?? ""
            appendLog("ERROR: \(msg)")
            statusText = String(localized: "Error: \(msg)")
            statusColor = .red
            pendingConf = nil   // import ボタンを出さない(セットアップは先に進めない)
            errorAlertTitle = (kind == "ddns")
                ? String(localized: "⚠ DuckDNS verification failed")
                : String(localized: "⚠ Setup aborted")
            errorAlertMessage = msg
            showErrorAlert = true
        default: break
        }
    }
}
